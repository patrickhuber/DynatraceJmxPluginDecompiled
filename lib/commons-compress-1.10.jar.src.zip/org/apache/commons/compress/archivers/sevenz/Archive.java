/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ import java.util.BitSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Archive
/*    */ {
/*    */   long packPos;
/*    */   long[] packSizes;
/*    */   BitSet packCrcsDefined;
/*    */   long[] packCrcs;
/*    */   Folder[] folders;
/*    */   SubStreamsInfo subStreamsInfo;
/*    */   SevenZArchiveEntry[] files;
/*    */   StreamMap streamMap;
/*    */   
/*    */   public String toString()
/*    */   {
/* 42 */     return "Archive with packed streams starting at offset " + this.packPos + ", " + lengthOf(this.packSizes) + " pack sizes, " + lengthOf(this.packCrcs) + " CRCs, " + lengthOf(this.folders) + " folders, " + lengthOf(this.files) + " files and " + this.streamMap;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private static String lengthOf(long[] a)
/*    */   {
/* 49 */     return a == null ? "(null)" : String.valueOf(a.length);
/*    */   }
/*    */   
/*    */   private static String lengthOf(Object[] a) {
/* 53 */     return a == null ? "(null)" : String.valueOf(a.length);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\Archive.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */