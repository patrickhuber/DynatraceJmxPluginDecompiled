/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import java.util.zip.Inflater;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
/*     */ import org.tukaani.xz.ARMOptions;
/*     */ import org.tukaani.xz.ARMThumbOptions;
/*     */ import org.tukaani.xz.FilterOptions;
/*     */ import org.tukaani.xz.FinishableOutputStream;
/*     */ import org.tukaani.xz.FinishableWrapperOutputStream;
/*     */ import org.tukaani.xz.IA64Options;
/*     */ import org.tukaani.xz.LZMAInputStream;
/*     */ import org.tukaani.xz.PowerPCOptions;
/*     */ import org.tukaani.xz.SPARCOptions;
/*     */ import org.tukaani.xz.X86Options;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Coders
/*     */ {
/*  47 */   private static final Map<SevenZMethod, CoderBase> CODER_MAP = new HashMap()
/*     */   {
/*     */     private static final long serialVersionUID = 1664829131806520867L;
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static CoderBase findByMethod(SevenZMethod method)
/*     */   {
/*  67 */     return (CoderBase)CODER_MAP.get(method);
/*     */   }
/*     */   
/*     */   static InputStream addDecoder(String archiveName, InputStream is, long uncompressedLength, Coder coder, byte[] password) throws IOException
/*     */   {
/*  72 */     CoderBase cb = findByMethod(SevenZMethod.byId(coder.decompressionMethodId));
/*  73 */     if (cb == null) {
/*  74 */       throw new IOException("Unsupported compression method " + Arrays.toString(coder.decompressionMethodId) + " used in " + archiveName);
/*     */     }
/*     */     
/*     */ 
/*  78 */     return cb.decode(archiveName, is, uncompressedLength, coder, password);
/*     */   }
/*     */   
/*     */   static OutputStream addEncoder(OutputStream out, SevenZMethod method, Object options) throws IOException
/*     */   {
/*  83 */     CoderBase cb = findByMethod(method);
/*  84 */     if (cb == null) {
/*  85 */       throw new IOException("Unsupported compression method " + method);
/*     */     }
/*  87 */     return cb.encode(out, options);
/*     */   }
/*     */   
/*  90 */   static class CopyDecoder extends CoderBase { CopyDecoder() { super(); }
/*     */     
/*     */     InputStream decode(String archiveName, InputStream in, long uncompressedLength, Coder coder, byte[] password) throws IOException
/*     */     {
/*  94 */       return in;
/*     */     }
/*     */     
/*     */ 
/*  98 */     OutputStream encode(OutputStream out, Object options) { return out; }
/*     */   }
/*     */   
/*     */   static class LZMADecoder extends CoderBase {
/* 102 */     LZMADecoder() { super(); }
/*     */     
/*     */     InputStream decode(String archiveName, InputStream in, long uncompressedLength, Coder coder, byte[] password) throws IOException
/*     */     {
/* 106 */       byte propsByte = coder.properties[0];
/* 107 */       long dictSize = coder.properties[1];
/* 108 */       for (int i = 1; i < 4; i++) {
/* 109 */         dictSize |= (coder.properties[(i + 1)] & 0xFF) << 8 * i;
/*     */       }
/* 111 */       if (dictSize > 2147483632L) {
/* 112 */         throw new IOException("Dictionary larger than 4GiB maximum size used in " + archiveName);
/*     */       }
/* 114 */       return new LZMAInputStream(in, uncompressedLength, propsByte, (int)dictSize);
/*     */     }
/*     */   }
/*     */   
/*     */   static class BCJDecoder extends CoderBase { private final FilterOptions opts;
/*     */     
/* 120 */     BCJDecoder(FilterOptions opts) { super();
/* 121 */       this.opts = opts;
/*     */     }
/*     */     
/*     */     InputStream decode(String archiveName, InputStream in, long uncompressedLength, Coder coder, byte[] password) throws IOException
/*     */     {
/*     */       try
/*     */       {
/* 128 */         return this.opts.getInputStream(in);
/*     */       } catch (AssertionError e) {
/* 130 */         IOException ex = new IOException("BCJ filter used in " + archiveName + " needs XZ for Java > 1.4 - see " + "http://commons.apache.org/proper/commons-compress/limitations.html#7Z");
/*     */         
/*     */ 
/* 133 */         ex.initCause(e);
/* 134 */         throw ex;
/*     */       }
/*     */     }
/*     */     
/*     */     OutputStream encode(OutputStream out, Object options) {
/* 139 */       FinishableOutputStream fo = this.opts.getOutputStream(new FinishableWrapperOutputStream(out));
/* 140 */       new FilterOutputStream(fo)
/*     */       {
/*     */         public void flush() {}
/*     */       };
/*     */     }
/*     */   }
/*     */   
/*     */   static class DeflateDecoder extends CoderBase
/*     */   {
/*     */     DeflateDecoder() {
/* 150 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */     InputStream decode(String archiveName, InputStream in, long uncompressedLength, Coder coder, byte[] password)
/*     */       throws IOException
/*     */     {
/* 157 */       return new InflaterInputStream(new Coders.DummyByteAddingInputStream(in, null), new Inflater(true));
/*     */     }
/*     */     
/*     */     OutputStream encode(OutputStream out, Object options)
/*     */     {
/* 162 */       int level = numberOptionOrDefault(options, 9);
/* 163 */       return new DeflaterOutputStream(out, new Deflater(level, true));
/*     */     }
/*     */   }
/*     */   
/*     */   static class BZIP2Decoder extends CoderBase {
/*     */     BZIP2Decoder() {
/* 169 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */     InputStream decode(String archiveName, InputStream in, long uncompressedLength, Coder coder, byte[] password)
/*     */       throws IOException
/*     */     {
/* 176 */       return new BZip2CompressorInputStream(in);
/*     */     }
/*     */     
/*     */     OutputStream encode(OutputStream out, Object options) throws IOException
/*     */     {
/* 181 */       int blockSize = numberOptionOrDefault(options, 9);
/* 182 */       return new BZip2CompressorOutputStream(out, blockSize);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class DummyByteAddingInputStream
/*     */     extends FilterInputStream
/*     */   {
/* 193 */     private boolean addDummyByte = true;
/*     */     
/*     */     private DummyByteAddingInputStream(InputStream in) {
/* 196 */       super();
/*     */     }
/*     */     
/*     */     public int read() throws IOException
/*     */     {
/* 201 */       int result = super.read();
/* 202 */       if ((result == -1) && (this.addDummyByte)) {
/* 203 */         this.addDummyByte = false;
/* 204 */         result = 0;
/*     */       }
/* 206 */       return result;
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException
/*     */     {
/* 211 */       int result = super.read(b, off, len);
/* 212 */       if ((result == -1) && (this.addDummyByte)) {
/* 213 */         this.addDummyByte = false;
/* 214 */         b[off] = 0;
/* 215 */         return 1;
/*     */       }
/* 217 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\Coders.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */