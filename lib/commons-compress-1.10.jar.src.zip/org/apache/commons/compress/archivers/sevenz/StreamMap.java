/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StreamMap
/*    */ {
/*    */   int[] folderFirstPackStreamIndex;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   long[] packStreamOffsets;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   int[] folderFirstFileIndex;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   int[] fileFolderIndex;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return "StreamMap with indices of " + this.folderFirstPackStreamIndex.length + " folders, offsets of " + this.packStreamOffsets.length + " packed streams," + " first files of " + this.folderFirstFileIndex.length + " folders and" + " folder indices for " + this.fileFolderIndex.length + " files";
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\StreamMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */