package org.apache.commons.compress.archivers.sevenz;

class StartHeader
{
  long nextHeaderOffset;
  long nextHeaderSize;
  long nextHeaderCrc;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\StartHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */