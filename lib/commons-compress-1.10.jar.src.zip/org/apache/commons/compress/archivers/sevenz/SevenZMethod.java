/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum SevenZMethod
/*     */ {
/*  38 */   COPY(new byte[] { 0 }), 
/*     */   
/*  40 */   LZMA(new byte[] { 3, 1, 1 }), 
/*     */   
/*  42 */   LZMA2(new byte[] { 33 }), 
/*     */   
/*  44 */   DEFLATE(new byte[] { 4, 1, 8 }), 
/*     */   
/*  46 */   BZIP2(new byte[] { 4, 2, 2 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  51 */   AES256SHA256(new byte[] { 6, -15, 7, 1 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  56 */   BCJ_X86_FILTER(new byte[] { 3, 3, 1, 3 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   BCJ_PPC_FILTER(new byte[] { 3, 3, 2, 5 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  66 */   BCJ_IA64_FILTER(new byte[] { 3, 3, 4, 1 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   BCJ_ARM_FILTER(new byte[] { 3, 3, 5, 1 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   BCJ_ARM_THUMB_FILTER(new byte[] { 3, 3, 7, 1 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  81 */   BCJ_SPARC_FILTER(new byte[] { 3, 3, 8, 5 }), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  86 */   DELTA_FILTER(new byte[] { 3 });
/*     */   
/*     */   private final byte[] id;
/*     */   
/*     */   private SevenZMethod(byte[] id) {
/*  91 */     this.id = id;
/*     */   }
/*     */   
/*     */   byte[] getId() {
/*  95 */     byte[] copy = new byte[this.id.length];
/*  96 */     System.arraycopy(this.id, 0, copy, 0, this.id.length);
/*  97 */     return copy;
/*     */   }
/*     */   
/*     */   static SevenZMethod byId(byte[] id) {
/* 101 */     for (SevenZMethod m : (SevenZMethod[])SevenZMethod.class.getEnumConstants()) {
/* 102 */       if (Arrays.equals(m.id, id)) {
/* 103 */         return m;
/*     */       }
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\SevenZMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */