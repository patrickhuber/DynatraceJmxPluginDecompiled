/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CLI
/*     */ {
/*  26 */   private static final byte[] BUF = new byte[' '];
/*     */   
/*     */   private static abstract enum Mode {
/*  29 */     LIST("Analysing"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     EXTRACT("Extracting");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private final String message;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private Mode(String message)
/*     */     {
/* 110 */       this.message = message;
/*     */     }
/*     */     
/* 113 */     public String getMessage() { return this.message; }
/*     */     
/*     */     public abstract void takeAction(SevenZFile paramSevenZFile, SevenZArchiveEntry paramSevenZArchiveEntry) throws IOException;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception
/*     */   {
/* 120 */     if (args.length == 0) {
/* 121 */       usage();
/* 122 */       return;
/*     */     }
/* 124 */     Mode mode = grabMode(args);
/* 125 */     System.out.println(mode.getMessage() + " " + args[0]);
/* 126 */     File f = new File(args[0]);
/* 127 */     if (!f.isFile()) {
/* 128 */       System.err.println(f + " doesn't exist or is a directory");
/*     */     }
/* 130 */     SevenZFile archive = new SevenZFile(f);
/*     */     try {
/*     */       SevenZArchiveEntry ae;
/* 133 */       while ((ae = archive.getNextEntry()) != null) {
/* 134 */         mode.takeAction(archive, ae);
/*     */       }
/*     */     } finally {
/* 137 */       archive.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void usage() {
/* 142 */     System.out.println("Parameters: archive-name [list|extract]");
/*     */   }
/*     */   
/*     */   private static Mode grabMode(String[] args) {
/* 146 */     if (args.length < 2) {
/* 147 */       return Mode.LIST;
/*     */     }
/* 149 */     return (Mode)Enum.valueOf(Mode.class, args[1].toUpperCase());
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\CLI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */