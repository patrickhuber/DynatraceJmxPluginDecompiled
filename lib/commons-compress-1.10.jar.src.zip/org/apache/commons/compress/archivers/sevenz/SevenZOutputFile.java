/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.CRC32;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.utils.CountingOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SevenZOutputFile
/*     */   implements Closeable
/*     */ {
/*     */   private final RandomAccessFile file;
/*  47 */   private final List<SevenZArchiveEntry> files = new ArrayList();
/*  48 */   private int numNonEmptyStreams = 0;
/*  49 */   private final CRC32 crc32 = new CRC32();
/*  50 */   private final CRC32 compressedCrc32 = new CRC32();
/*  51 */   private long fileBytesWritten = 0L;
/*  52 */   private boolean finished = false;
/*     */   private CountingOutputStream currentOutputStream;
/*     */   private CountingOutputStream[] additionalCountingStreams;
/*  55 */   private Iterable<? extends SevenZMethodConfiguration> contentMethods = Collections.singletonList(new SevenZMethodConfiguration(SevenZMethod.LZMA2));
/*     */   
/*  57 */   private final Map<SevenZArchiveEntry, long[]> additionalSizes = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SevenZOutputFile(File filename)
/*     */     throws IOException
/*     */   {
/*  66 */     this.file = new RandomAccessFile(filename, "rw");
/*  67 */     this.file.seek(32L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentCompression(SevenZMethod method)
/*     */   {
/*  83 */     setContentMethods(Collections.singletonList(new SevenZMethodConfiguration(method)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentMethods(Iterable<? extends SevenZMethodConfiguration> methods)
/*     */   {
/* 101 */     this.contentMethods = reverse(methods);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 110 */     if (!this.finished) {
/* 111 */       finish();
/*     */     }
/* 113 */     this.file.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SevenZArchiveEntry createArchiveEntry(File inputFile, String entryName)
/*     */     throws IOException
/*     */   {
/* 127 */     SevenZArchiveEntry entry = new SevenZArchiveEntry();
/* 128 */     entry.setDirectory(inputFile.isDirectory());
/* 129 */     entry.setName(entryName);
/* 130 */     entry.setLastModifiedDate(new Date(inputFile.lastModified()));
/* 131 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putArchiveEntry(ArchiveEntry archiveEntry)
/*     */     throws IOException
/*     */   {
/* 144 */     SevenZArchiveEntry entry = (SevenZArchiveEntry)archiveEntry;
/* 145 */     this.files.add(entry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeArchiveEntry()
/*     */     throws IOException
/*     */   {
/* 153 */     if (this.currentOutputStream != null) {
/* 154 */       this.currentOutputStream.flush();
/* 155 */       this.currentOutputStream.close();
/*     */     }
/*     */     
/* 158 */     SevenZArchiveEntry entry = (SevenZArchiveEntry)this.files.get(this.files.size() - 1);
/* 159 */     if (this.fileBytesWritten > 0L) {
/* 160 */       entry.setHasStream(true);
/* 161 */       this.numNonEmptyStreams += 1;
/* 162 */       entry.setSize(this.currentOutputStream.getBytesWritten());
/* 163 */       entry.setCompressedSize(this.fileBytesWritten);
/* 164 */       entry.setCrcValue(this.crc32.getValue());
/* 165 */       entry.setCompressedCrcValue(this.compressedCrc32.getValue());
/* 166 */       entry.setHasCrc(true);
/* 167 */       if (this.additionalCountingStreams != null) {
/* 168 */         long[] sizes = new long[this.additionalCountingStreams.length];
/* 169 */         for (int i = 0; i < this.additionalCountingStreams.length; i++) {
/* 170 */           sizes[i] = this.additionalCountingStreams[i].getBytesWritten();
/*     */         }
/* 172 */         this.additionalSizes.put(entry, sizes);
/*     */       }
/*     */     } else {
/* 175 */       entry.setHasStream(false);
/* 176 */       entry.setSize(0L);
/* 177 */       entry.setCompressedSize(0L);
/* 178 */       entry.setHasCrc(false);
/*     */     }
/* 180 */     this.currentOutputStream = null;
/* 181 */     this.additionalCountingStreams = null;
/* 182 */     this.crc32.reset();
/* 183 */     this.compressedCrc32.reset();
/* 184 */     this.fileBytesWritten = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/* 193 */     getCurrentOutputStream().write(b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] b)
/*     */     throws IOException
/*     */   {
/* 202 */     write(b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 213 */     if (len > 0) {
/* 214 */       getCurrentOutputStream().write(b, off, len);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finish()
/*     */     throws IOException
/*     */   {
/* 224 */     if (this.finished) {
/* 225 */       throw new IOException("This archive has already been finished");
/*     */     }
/* 227 */     this.finished = true;
/*     */     
/* 229 */     long headerPosition = this.file.getFilePointer();
/*     */     
/* 231 */     ByteArrayOutputStream headerBaos = new ByteArrayOutputStream();
/* 232 */     DataOutputStream header = new DataOutputStream(headerBaos);
/*     */     
/* 234 */     writeHeader(header);
/* 235 */     header.flush();
/* 236 */     byte[] headerBytes = headerBaos.toByteArray();
/* 237 */     this.file.write(headerBytes);
/*     */     
/* 239 */     CRC32 crc32 = new CRC32();
/*     */     
/*     */ 
/* 242 */     this.file.seek(0L);
/* 243 */     this.file.write(SevenZFile.sevenZSignature);
/*     */     
/* 245 */     this.file.write(0);
/* 246 */     this.file.write(2);
/*     */     
/*     */ 
/* 249 */     ByteArrayOutputStream startHeaderBaos = new ByteArrayOutputStream();
/* 250 */     DataOutputStream startHeaderStream = new DataOutputStream(startHeaderBaos);
/* 251 */     startHeaderStream.writeLong(Long.reverseBytes(headerPosition - 32L));
/* 252 */     startHeaderStream.writeLong(Long.reverseBytes(0xFFFFFFFF & headerBytes.length));
/* 253 */     crc32.reset();
/* 254 */     crc32.update(headerBytes);
/* 255 */     startHeaderStream.writeInt(Integer.reverseBytes((int)crc32.getValue()));
/* 256 */     startHeaderStream.flush();
/* 257 */     byte[] startHeaderBytes = startHeaderBaos.toByteArray();
/* 258 */     crc32.reset();
/* 259 */     crc32.update(startHeaderBytes);
/* 260 */     this.file.writeInt(Integer.reverseBytes((int)crc32.getValue()));
/* 261 */     this.file.write(startHeaderBytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private OutputStream getCurrentOutputStream()
/*     */     throws IOException
/*     */   {
/* 270 */     if (this.currentOutputStream == null) {
/* 271 */       this.currentOutputStream = setupFileOutputStream();
/*     */     }
/* 273 */     return this.currentOutputStream;
/*     */   }
/*     */   
/*     */   private CountingOutputStream setupFileOutputStream() throws IOException {
/* 277 */     if (this.files.isEmpty()) {
/* 278 */       throw new IllegalStateException("No current 7z entry");
/*     */     }
/*     */     
/* 281 */     OutputStream out = new OutputStreamWrapper(null);
/* 282 */     ArrayList<CountingOutputStream> moreStreams = new ArrayList();
/* 283 */     boolean first = true;
/* 284 */     for (SevenZMethodConfiguration m : getContentMethods((SevenZArchiveEntry)this.files.get(this.files.size() - 1))) {
/* 285 */       if (!first) {
/* 286 */         CountingOutputStream cos = new CountingOutputStream(out);
/* 287 */         moreStreams.add(cos);
/* 288 */         out = cos;
/*     */       }
/* 290 */       out = Coders.addEncoder(out, m.getMethod(), m.getOptions());
/* 291 */       first = false;
/*     */     }
/* 293 */     if (!moreStreams.isEmpty()) {
/* 294 */       this.additionalCountingStreams = ((CountingOutputStream[])moreStreams.toArray(new CountingOutputStream[moreStreams.size()]));
/*     */     }
/* 296 */     new CountingOutputStream(out)
/*     */     {
/*     */       public void write(int b) throws IOException {
/* 299 */         super.write(b);
/* 300 */         SevenZOutputFile.this.crc32.update(b);
/*     */       }
/*     */       
/*     */       public void write(byte[] b) throws IOException
/*     */       {
/* 305 */         super.write(b);
/* 306 */         SevenZOutputFile.this.crc32.update(b);
/*     */       }
/*     */       
/*     */       public void write(byte[] b, int off, int len)
/*     */         throws IOException
/*     */       {
/* 312 */         super.write(b, off, len);
/* 313 */         SevenZOutputFile.this.crc32.update(b, off, len);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private Iterable<? extends SevenZMethodConfiguration> getContentMethods(SevenZArchiveEntry entry) {
/* 319 */     Iterable<? extends SevenZMethodConfiguration> ms = entry.getContentMethods();
/* 320 */     return ms == null ? this.contentMethods : ms;
/*     */   }
/*     */   
/*     */   private void writeHeader(DataOutput header) throws IOException {
/* 324 */     header.write(1);
/*     */     
/* 326 */     header.write(4);
/* 327 */     writeStreamsInfo(header);
/* 328 */     writeFilesInfo(header);
/* 329 */     header.write(0);
/*     */   }
/*     */   
/*     */   private void writeStreamsInfo(DataOutput header) throws IOException {
/* 333 */     if (this.numNonEmptyStreams > 0) {
/* 334 */       writePackInfo(header);
/* 335 */       writeUnpackInfo(header);
/*     */     }
/*     */     
/* 338 */     writeSubStreamsInfo(header);
/*     */     
/* 340 */     header.write(0);
/*     */   }
/*     */   
/*     */   private void writePackInfo(DataOutput header) throws IOException {
/* 344 */     header.write(6);
/*     */     
/* 346 */     writeUint64(header, 0L);
/* 347 */     writeUint64(header, 0xFFFFFFFF & this.numNonEmptyStreams);
/*     */     
/* 349 */     header.write(9);
/* 350 */     for (SevenZArchiveEntry entry : this.files) {
/* 351 */       if (entry.hasStream()) {
/* 352 */         writeUint64(header, entry.getCompressedSize());
/*     */       }
/*     */     }
/*     */     
/* 356 */     header.write(10);
/* 357 */     header.write(1);
/* 358 */     for (SevenZArchiveEntry entry : this.files) {
/* 359 */       if (entry.hasStream()) {
/* 360 */         header.writeInt(Integer.reverseBytes((int)entry.getCompressedCrcValue()));
/*     */       }
/*     */     }
/*     */     
/* 364 */     header.write(0);
/*     */   }
/*     */   
/*     */   private void writeUnpackInfo(DataOutput header) throws IOException {
/* 368 */     header.write(7);
/*     */     
/* 370 */     header.write(11);
/* 371 */     writeUint64(header, this.numNonEmptyStreams);
/* 372 */     header.write(0);
/* 373 */     for (SevenZArchiveEntry entry : this.files) {
/* 374 */       if (entry.hasStream()) {
/* 375 */         writeFolder(header, entry);
/*     */       }
/*     */     }
/*     */     
/* 379 */     header.write(12);
/* 380 */     for (SevenZArchiveEntry entry : this.files) {
/* 381 */       if (entry.hasStream()) {
/* 382 */         long[] moreSizes = (long[])this.additionalSizes.get(entry);
/* 383 */         if (moreSizes != null) {
/* 384 */           for (long s : moreSizes) {
/* 385 */             writeUint64(header, s);
/*     */           }
/*     */         }
/* 388 */         writeUint64(header, entry.getSize());
/*     */       }
/*     */     }
/*     */     
/* 392 */     header.write(10);
/* 393 */     header.write(1);
/* 394 */     for (SevenZArchiveEntry entry : this.files) {
/* 395 */       if (entry.hasStream()) {
/* 396 */         header.writeInt(Integer.reverseBytes((int)entry.getCrcValue()));
/*     */       }
/*     */     }
/*     */     
/* 400 */     header.write(0);
/*     */   }
/*     */   
/*     */   private void writeFolder(DataOutput header, SevenZArchiveEntry entry) throws IOException {
/* 404 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 405 */     int numCoders = 0;
/* 406 */     for (SevenZMethodConfiguration m : getContentMethods(entry)) {
/* 407 */       numCoders++;
/* 408 */       writeSingleCodec(m, bos);
/*     */     }
/*     */     
/* 411 */     writeUint64(header, numCoders);
/* 412 */     header.write(bos.toByteArray());
/* 413 */     for (int i = 0; i < numCoders - 1; i++) {
/* 414 */       writeUint64(header, i + 1);
/* 415 */       writeUint64(header, i);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeSingleCodec(SevenZMethodConfiguration m, OutputStream bos) throws IOException {
/* 420 */     byte[] id = m.getMethod().getId();
/* 421 */     byte[] properties = Coders.findByMethod(m.getMethod()).getOptionsAsProperties(m.getOptions());
/*     */     
/*     */ 
/* 424 */     int codecFlags = id.length;
/* 425 */     if (properties.length > 0) {
/* 426 */       codecFlags |= 0x20;
/*     */     }
/* 428 */     bos.write(codecFlags);
/* 429 */     bos.write(id);
/*     */     
/* 431 */     if (properties.length > 0) {
/* 432 */       bos.write(properties.length);
/* 433 */       bos.write(properties);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeSubStreamsInfo(DataOutput header) throws IOException {
/* 438 */     header.write(8);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 448 */     header.write(0);
/*     */   }
/*     */   
/*     */   private void writeFilesInfo(DataOutput header) throws IOException {
/* 452 */     header.write(5);
/*     */     
/* 454 */     writeUint64(header, this.files.size());
/*     */     
/* 456 */     writeFileEmptyStreams(header);
/* 457 */     writeFileEmptyFiles(header);
/* 458 */     writeFileAntiItems(header);
/* 459 */     writeFileNames(header);
/* 460 */     writeFileCTimes(header);
/* 461 */     writeFileATimes(header);
/* 462 */     writeFileMTimes(header);
/* 463 */     writeFileWindowsAttributes(header);
/* 464 */     header.write(0);
/*     */   }
/*     */   
/*     */   private void writeFileEmptyStreams(DataOutput header) throws IOException {
/* 468 */     boolean hasEmptyStreams = false;
/* 469 */     for (SevenZArchiveEntry entry : this.files) {
/* 470 */       if (!entry.hasStream()) {
/* 471 */         hasEmptyStreams = true;
/* 472 */         break;
/*     */       }
/*     */     }
/* 475 */     if (hasEmptyStreams) {
/* 476 */       header.write(14);
/* 477 */       BitSet emptyStreams = new BitSet(this.files.size());
/* 478 */       for (int i = 0; i < this.files.size(); i++) {
/* 479 */         emptyStreams.set(i, !((SevenZArchiveEntry)this.files.get(i)).hasStream());
/*     */       }
/* 481 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 482 */       DataOutputStream out = new DataOutputStream(baos);
/* 483 */       writeBits(out, emptyStreams, this.files.size());
/* 484 */       out.flush();
/* 485 */       byte[] contents = baos.toByteArray();
/* 486 */       writeUint64(header, contents.length);
/* 487 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeFileEmptyFiles(DataOutput header) throws IOException {
/* 492 */     boolean hasEmptyFiles = false;
/* 493 */     int emptyStreamCounter = 0;
/* 494 */     BitSet emptyFiles = new BitSet(0);
/* 495 */     for (SevenZArchiveEntry file1 : this.files) {
/* 496 */       if (!file1.hasStream()) {
/* 497 */         boolean isDir = file1.isDirectory();
/* 498 */         emptyFiles.set(emptyStreamCounter++, !isDir);
/* 499 */         hasEmptyFiles |= !isDir;
/*     */       }
/*     */     }
/* 502 */     if (hasEmptyFiles) {
/* 503 */       header.write(15);
/* 504 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 505 */       DataOutputStream out = new DataOutputStream(baos);
/* 506 */       writeBits(out, emptyFiles, emptyStreamCounter);
/* 507 */       out.flush();
/* 508 */       byte[] contents = baos.toByteArray();
/* 509 */       writeUint64(header, contents.length);
/* 510 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeFileAntiItems(DataOutput header) throws IOException {
/* 515 */     boolean hasAntiItems = false;
/* 516 */     BitSet antiItems = new BitSet(0);
/* 517 */     int antiItemCounter = 0;
/* 518 */     for (SevenZArchiveEntry file1 : this.files) {
/* 519 */       if (!file1.hasStream()) {
/* 520 */         boolean isAnti = file1.isAntiItem();
/* 521 */         antiItems.set(antiItemCounter++, isAnti);
/* 522 */         hasAntiItems |= isAnti;
/*     */       }
/*     */     }
/* 525 */     if (hasAntiItems) {
/* 526 */       header.write(16);
/* 527 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 528 */       DataOutputStream out = new DataOutputStream(baos);
/* 529 */       writeBits(out, antiItems, antiItemCounter);
/* 530 */       out.flush();
/* 531 */       byte[] contents = baos.toByteArray();
/* 532 */       writeUint64(header, contents.length);
/* 533 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeFileNames(DataOutput header) throws IOException {
/* 538 */     header.write(17);
/*     */     
/* 540 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 541 */     DataOutputStream out = new DataOutputStream(baos);
/* 542 */     out.write(0);
/* 543 */     for (SevenZArchiveEntry entry : this.files) {
/* 544 */       out.write(entry.getName().getBytes("UTF-16LE"));
/* 545 */       out.writeShort(0);
/*     */     }
/* 547 */     out.flush();
/* 548 */     byte[] contents = baos.toByteArray();
/* 549 */     writeUint64(header, contents.length);
/* 550 */     header.write(contents);
/*     */   }
/*     */   
/*     */   private void writeFileCTimes(DataOutput header) throws IOException {
/* 554 */     int numCreationDates = 0;
/* 555 */     for (SevenZArchiveEntry entry : this.files) {
/* 556 */       if (entry.getHasCreationDate()) {
/* 557 */         numCreationDates++;
/*     */       }
/*     */     }
/* 560 */     if (numCreationDates > 0) {
/* 561 */       header.write(18);
/*     */       
/* 563 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 564 */       DataOutputStream out = new DataOutputStream(baos);
/* 565 */       if (numCreationDates != this.files.size()) {
/* 566 */         out.write(0);
/* 567 */         BitSet cTimes = new BitSet(this.files.size());
/* 568 */         for (int i = 0; i < this.files.size(); i++) {
/* 569 */           cTimes.set(i, ((SevenZArchiveEntry)this.files.get(i)).getHasCreationDate());
/*     */         }
/* 571 */         writeBits(out, cTimes, this.files.size());
/*     */       } else {
/* 573 */         out.write(1);
/*     */       }
/* 575 */       out.write(0);
/* 576 */       for (SevenZArchiveEntry entry : this.files) {
/* 577 */         if (entry.getHasCreationDate()) {
/* 578 */           out.writeLong(Long.reverseBytes(SevenZArchiveEntry.javaTimeToNtfsTime(entry.getCreationDate())));
/*     */         }
/*     */       }
/*     */       
/* 582 */       out.flush();
/* 583 */       byte[] contents = baos.toByteArray();
/* 584 */       writeUint64(header, contents.length);
/* 585 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeFileATimes(DataOutput header) throws IOException {
/* 590 */     int numAccessDates = 0;
/* 591 */     for (SevenZArchiveEntry entry : this.files) {
/* 592 */       if (entry.getHasAccessDate()) {
/* 593 */         numAccessDates++;
/*     */       }
/*     */     }
/* 596 */     if (numAccessDates > 0) {
/* 597 */       header.write(19);
/*     */       
/* 599 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 600 */       DataOutputStream out = new DataOutputStream(baos);
/* 601 */       if (numAccessDates != this.files.size()) {
/* 602 */         out.write(0);
/* 603 */         BitSet aTimes = new BitSet(this.files.size());
/* 604 */         for (int i = 0; i < this.files.size(); i++) {
/* 605 */           aTimes.set(i, ((SevenZArchiveEntry)this.files.get(i)).getHasAccessDate());
/*     */         }
/* 607 */         writeBits(out, aTimes, this.files.size());
/*     */       } else {
/* 609 */         out.write(1);
/*     */       }
/* 611 */       out.write(0);
/* 612 */       for (SevenZArchiveEntry entry : this.files) {
/* 613 */         if (entry.getHasAccessDate()) {
/* 614 */           out.writeLong(Long.reverseBytes(SevenZArchiveEntry.javaTimeToNtfsTime(entry.getAccessDate())));
/*     */         }
/*     */       }
/*     */       
/* 618 */       out.flush();
/* 619 */       byte[] contents = baos.toByteArray();
/* 620 */       writeUint64(header, contents.length);
/* 621 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeFileMTimes(DataOutput header) throws IOException {
/* 626 */     int numLastModifiedDates = 0;
/* 627 */     for (SevenZArchiveEntry entry : this.files) {
/* 628 */       if (entry.getHasLastModifiedDate()) {
/* 629 */         numLastModifiedDates++;
/*     */       }
/*     */     }
/* 632 */     if (numLastModifiedDates > 0) {
/* 633 */       header.write(20);
/*     */       
/* 635 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 636 */       DataOutputStream out = new DataOutputStream(baos);
/* 637 */       if (numLastModifiedDates != this.files.size()) {
/* 638 */         out.write(0);
/* 639 */         BitSet mTimes = new BitSet(this.files.size());
/* 640 */         for (int i = 0; i < this.files.size(); i++) {
/* 641 */           mTimes.set(i, ((SevenZArchiveEntry)this.files.get(i)).getHasLastModifiedDate());
/*     */         }
/* 643 */         writeBits(out, mTimes, this.files.size());
/*     */       } else {
/* 645 */         out.write(1);
/*     */       }
/* 647 */       out.write(0);
/* 648 */       for (SevenZArchiveEntry entry : this.files) {
/* 649 */         if (entry.getHasLastModifiedDate()) {
/* 650 */           out.writeLong(Long.reverseBytes(SevenZArchiveEntry.javaTimeToNtfsTime(entry.getLastModifiedDate())));
/*     */         }
/*     */       }
/*     */       
/* 654 */       out.flush();
/* 655 */       byte[] contents = baos.toByteArray();
/* 656 */       writeUint64(header, contents.length);
/* 657 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeFileWindowsAttributes(DataOutput header) throws IOException {
/* 662 */     int numWindowsAttributes = 0;
/* 663 */     for (SevenZArchiveEntry entry : this.files) {
/* 664 */       if (entry.getHasWindowsAttributes()) {
/* 665 */         numWindowsAttributes++;
/*     */       }
/*     */     }
/* 668 */     if (numWindowsAttributes > 0) {
/* 669 */       header.write(21);
/*     */       
/* 671 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 672 */       DataOutputStream out = new DataOutputStream(baos);
/* 673 */       if (numWindowsAttributes != this.files.size()) {
/* 674 */         out.write(0);
/* 675 */         BitSet attributes = new BitSet(this.files.size());
/* 676 */         for (int i = 0; i < this.files.size(); i++) {
/* 677 */           attributes.set(i, ((SevenZArchiveEntry)this.files.get(i)).getHasWindowsAttributes());
/*     */         }
/* 679 */         writeBits(out, attributes, this.files.size());
/*     */       } else {
/* 681 */         out.write(1);
/*     */       }
/* 683 */       out.write(0);
/* 684 */       for (SevenZArchiveEntry entry : this.files) {
/* 685 */         if (entry.getHasWindowsAttributes()) {
/* 686 */           out.writeInt(Integer.reverseBytes(entry.getWindowsAttributes()));
/*     */         }
/*     */       }
/* 689 */       out.flush();
/* 690 */       byte[] contents = baos.toByteArray();
/* 691 */       writeUint64(header, contents.length);
/* 692 */       header.write(contents);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeUint64(DataOutput header, long value) throws IOException {
/* 697 */     int firstByte = 0;
/* 698 */     int mask = 128;
/*     */     
/* 700 */     for (int i = 0; i < 8; i++) {
/* 701 */       if (value < 1L << 7 * (i + 1)) {
/* 702 */         firstByte = (int)(firstByte | value >>> 8 * i);
/* 703 */         break;
/*     */       }
/* 705 */       firstByte |= mask;
/* 706 */       mask >>>= 1;
/*     */     }
/* 708 */     header.write(firstByte);
/* 709 */     for (; i > 0; i--) {
/* 710 */       header.write((int)(0xFF & value));
/* 711 */       value >>>= 8;
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeBits(DataOutput header, BitSet bits, int length) throws IOException {
/* 716 */     int cache = 0;
/* 717 */     int shift = 7;
/* 718 */     for (int i = 0; i < length; i++) {
/* 719 */       cache |= (bits.get(i) ? 1 : 0) << shift;
/* 720 */       shift--; if (shift < 0) {
/* 721 */         header.write(cache);
/* 722 */         shift = 7;
/* 723 */         cache = 0;
/*     */       }
/*     */     }
/* 726 */     if (shift != 7) {
/* 727 */       header.write(cache);
/*     */     }
/*     */   }
/*     */   
/*     */   private static <T> Iterable<T> reverse(Iterable<T> i) {
/* 732 */     LinkedList<T> l = new LinkedList();
/* 733 */     for (T t : i) {
/* 734 */       l.addFirst(t);
/*     */     }
/* 736 */     return l;
/*     */   }
/*     */   
/*     */   private class OutputStreamWrapper extends OutputStream {
/*     */     private OutputStreamWrapper() {}
/*     */     
/* 742 */     public void write(int b) throws IOException { SevenZOutputFile.this.file.write(b);
/* 743 */       SevenZOutputFile.this.compressedCrc32.update(b);
/* 744 */       SevenZOutputFile.access$408(SevenZOutputFile.this);
/*     */     }
/*     */     
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 749 */       write(b, 0, b.length);
/*     */     }
/*     */     
/*     */     public void write(byte[] b, int off, int len)
/*     */       throws IOException
/*     */     {
/* 755 */       SevenZOutputFile.this.file.write(b, off, len);
/* 756 */       SevenZOutputFile.this.compressedCrc32.update(b, off, len);
/* 757 */       SevenZOutputFile.access$414(SevenZOutputFile.this, len);
/*     */     }
/*     */     
/*     */     public void flush()
/*     */       throws IOException
/*     */     {}
/*     */     
/*     */     public void close()
/*     */       throws IOException
/*     */     {}
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\SevenZOutputFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */