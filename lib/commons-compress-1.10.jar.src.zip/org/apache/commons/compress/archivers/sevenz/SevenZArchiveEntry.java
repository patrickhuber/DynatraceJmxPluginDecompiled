/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedList;
/*     */ import java.util.TimeZone;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SevenZArchiveEntry
/*     */   implements ArchiveEntry
/*     */ {
/*     */   private String name;
/*     */   private boolean hasStream;
/*     */   private boolean isDirectory;
/*     */   private boolean isAntiItem;
/*     */   private boolean hasCreationDate;
/*     */   private boolean hasLastModifiedDate;
/*     */   private boolean hasAccessDate;
/*     */   private long creationDate;
/*     */   private long lastModifiedDate;
/*     */   private long accessDate;
/*     */   private boolean hasWindowsAttributes;
/*     */   private int windowsAttributes;
/*     */   private boolean hasCrc;
/*     */   private long crc;
/*     */   private long compressedCrc;
/*     */   private long size;
/*     */   private long compressedSize;
/*     */   private Iterable<? extends SevenZMethodConfiguration> contentMethods;
/*     */   
/*     */   public String getName()
/*     */   {
/*  61 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  70 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasStream()
/*     */   {
/*  78 */     return this.hasStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHasStream(boolean hasStream)
/*     */   {
/*  86 */     this.hasStream = hasStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/*  95 */     return this.isDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectory(boolean isDirectory)
/*     */   {
/* 104 */     this.isDirectory = isDirectory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isAntiItem()
/*     */   {
/* 113 */     return this.isAntiItem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAntiItem(boolean isAntiItem)
/*     */   {
/* 122 */     this.isAntiItem = isAntiItem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getHasCreationDate()
/*     */   {
/* 130 */     return this.hasCreationDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHasCreationDate(boolean hasCreationDate)
/*     */   {
/* 138 */     this.hasCreationDate = hasCreationDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getCreationDate()
/*     */   {
/* 148 */     if (this.hasCreationDate) {
/* 149 */       return ntfsTimeToJavaTime(this.creationDate);
/*     */     }
/* 151 */     throw new UnsupportedOperationException("The entry doesn't have this timestamp");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreationDate(long ntfsCreationDate)
/*     */   {
/* 162 */     this.creationDate = ntfsCreationDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreationDate(Date creationDate)
/*     */   {
/* 170 */     this.hasCreationDate = (creationDate != null);
/* 171 */     if (this.hasCreationDate) {
/* 172 */       this.creationDate = javaTimeToNtfsTime(creationDate);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getHasLastModifiedDate()
/*     */   {
/* 181 */     return this.hasLastModifiedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHasLastModifiedDate(boolean hasLastModifiedDate)
/*     */   {
/* 190 */     this.hasLastModifiedDate = hasLastModifiedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLastModifiedDate()
/*     */   {
/* 200 */     if (this.hasLastModifiedDate) {
/* 201 */       return ntfsTimeToJavaTime(this.lastModifiedDate);
/*     */     }
/* 203 */     throw new UnsupportedOperationException("The entry doesn't have this timestamp");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastModifiedDate(long ntfsLastModifiedDate)
/*     */   {
/* 214 */     this.lastModifiedDate = ntfsLastModifiedDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastModifiedDate(Date lastModifiedDate)
/*     */   {
/* 222 */     this.hasLastModifiedDate = (lastModifiedDate != null);
/* 223 */     if (this.hasLastModifiedDate) {
/* 224 */       this.lastModifiedDate = javaTimeToNtfsTime(lastModifiedDate);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getHasAccessDate()
/*     */   {
/* 233 */     return this.hasAccessDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHasAccessDate(boolean hasAcessDate)
/*     */   {
/* 241 */     this.hasAccessDate = hasAcessDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getAccessDate()
/*     */   {
/* 251 */     if (this.hasAccessDate) {
/* 252 */       return ntfsTimeToJavaTime(this.accessDate);
/*     */     }
/* 254 */     throw new UnsupportedOperationException("The entry doesn't have this timestamp");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessDate(long ntfsAccessDate)
/*     */   {
/* 265 */     this.accessDate = ntfsAccessDate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessDate(Date accessDate)
/*     */   {
/* 273 */     this.hasAccessDate = (accessDate != null);
/* 274 */     if (this.hasAccessDate) {
/* 275 */       this.accessDate = javaTimeToNtfsTime(accessDate);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getHasWindowsAttributes()
/*     */   {
/* 284 */     return this.hasWindowsAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHasWindowsAttributes(boolean hasWindowsAttributes)
/*     */   {
/* 292 */     this.hasWindowsAttributes = hasWindowsAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWindowsAttributes()
/*     */   {
/* 300 */     return this.windowsAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWindowsAttributes(int windowsAttributes)
/*     */   {
/* 308 */     this.windowsAttributes = windowsAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getHasCrc()
/*     */   {
/* 318 */     return this.hasCrc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHasCrc(boolean hasCrc)
/*     */   {
/* 326 */     this.hasCrc = hasCrc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public int getCrc()
/*     */   {
/* 336 */     return (int)this.crc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setCrc(int crc)
/*     */   {
/* 346 */     this.crc = crc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCrcValue()
/*     */   {
/* 355 */     return this.crc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCrcValue(long crc)
/*     */   {
/* 364 */     this.crc = crc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   int getCompressedCrc()
/*     */   {
/* 374 */     return (int)this.compressedCrc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   void setCompressedCrc(int crc)
/*     */   {
/* 384 */     this.compressedCrc = crc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long getCompressedCrcValue()
/*     */   {
/* 393 */     return this.compressedCrc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCompressedCrcValue(long crc)
/*     */   {
/* 402 */     this.compressedCrc = crc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 411 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(long size)
/*     */   {
/* 420 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long getCompressedSize()
/*     */   {
/* 429 */     return this.compressedSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCompressedSize(long size)
/*     */   {
/* 438 */     this.compressedSize = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContentMethods(Iterable<? extends SevenZMethodConfiguration> methods)
/*     */   {
/* 456 */     if (methods != null) {
/* 457 */       LinkedList<SevenZMethodConfiguration> l = new LinkedList();
/* 458 */       for (SevenZMethodConfiguration m : methods) {
/* 459 */         l.addLast(m);
/*     */       }
/* 461 */       this.contentMethods = Collections.unmodifiableList(l);
/*     */     } else {
/* 463 */       this.contentMethods = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterable<? extends SevenZMethodConfiguration> getContentMethods()
/*     */   {
/* 482 */     return this.contentMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date ntfsTimeToJavaTime(long ntfsTime)
/*     */   {
/* 492 */     Calendar ntfsEpoch = Calendar.getInstance();
/* 493 */     ntfsEpoch.setTimeZone(TimeZone.getTimeZone("GMT+0"));
/* 494 */     ntfsEpoch.set(1601, 0, 1, 0, 0, 0);
/* 495 */     ntfsEpoch.set(14, 0);
/* 496 */     long realTime = ntfsEpoch.getTimeInMillis() + ntfsTime / 10000L;
/* 497 */     return new Date(realTime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long javaTimeToNtfsTime(Date date)
/*     */   {
/* 506 */     Calendar ntfsEpoch = Calendar.getInstance();
/* 507 */     ntfsEpoch.setTimeZone(TimeZone.getTimeZone("GMT+0"));
/* 508 */     ntfsEpoch.set(1601, 0, 1, 0, 0, 0);
/* 509 */     ntfsEpoch.set(14, 0);
/* 510 */     return (date.getTime() - ntfsEpoch.getTimeInMillis()) * 1000L * 10L;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\SevenZArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */