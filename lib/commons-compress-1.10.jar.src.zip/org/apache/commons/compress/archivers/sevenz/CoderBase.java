/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class CoderBase
/*    */ {
/*    */   private final Class<?>[] acceptableOptions;
/* 29 */   private static final byte[] NONE = new byte[0];
/*    */   
/*    */ 
/*    */ 
/*    */   protected CoderBase(Class<?>... acceptableOptions)
/*    */   {
/* 35 */     this.acceptableOptions = acceptableOptions;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   boolean canAcceptOptions(Object opts)
/*    */   {
/* 42 */     for (Class<?> c : this.acceptableOptions) {
/* 43 */       if (c.isInstance(opts)) {
/* 44 */         return true;
/*    */       }
/*    */     }
/* 47 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   byte[] getOptionsAsProperties(Object options)
/*    */   {
/* 54 */     return NONE;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   Object getOptionsFromCoder(Coder coder, InputStream in)
/*    */   {
/* 61 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   abstract InputStream decode(String paramString, InputStream paramInputStream, long paramLong, Coder paramCoder, byte[] paramArrayOfByte)
/*    */     throws IOException;
/*    */   
/*    */ 
/*    */ 
/*    */   OutputStream encode(OutputStream out, Object options)
/*    */     throws IOException
/*    */   {
/* 75 */     throw new UnsupportedOperationException("method doesn't support writing");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected static int numberOptionOrDefault(Object options, int defaultValue)
/*    */   {
/* 83 */     return (options instanceof Number) ? ((Number)options).intValue() : defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\CoderBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */