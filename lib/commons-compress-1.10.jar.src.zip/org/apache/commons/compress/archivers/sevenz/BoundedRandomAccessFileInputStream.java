/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.RandomAccessFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BoundedRandomAccessFileInputStream
/*    */   extends InputStream
/*    */ {
/*    */   private final RandomAccessFile file;
/*    */   private long bytesRemaining;
/*    */   
/*    */   public BoundedRandomAccessFileInputStream(RandomAccessFile file, long size)
/*    */   {
/* 30 */     this.file = file;
/* 31 */     this.bytesRemaining = size;
/*    */   }
/*    */   
/*    */   public int read() throws IOException
/*    */   {
/* 36 */     if (this.bytesRemaining > 0L) {
/* 37 */       this.bytesRemaining -= 1L;
/* 38 */       return this.file.read();
/*    */     }
/* 40 */     return -1;
/*    */   }
/*    */   
/*    */   public int read(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 46 */     if (this.bytesRemaining == 0L) {
/* 47 */       return -1;
/*    */     }
/* 49 */     int bytesToRead = len;
/* 50 */     if (bytesToRead > this.bytesRemaining) {
/* 51 */       bytesToRead = (int)this.bytesRemaining;
/*    */     }
/* 53 */     int bytesRead = this.file.read(b, off, bytesToRead);
/* 54 */     if (bytesRead >= 0) {
/* 55 */       this.bytesRemaining -= bytesRead;
/*    */     }
/* 57 */     return bytesRead;
/*    */   }
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\BoundedRandomAccessFileInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */