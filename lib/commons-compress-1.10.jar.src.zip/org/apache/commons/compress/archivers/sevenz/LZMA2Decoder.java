/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import org.tukaani.xz.FinishableOutputStream;
/*    */ import org.tukaani.xz.FinishableWrapperOutputStream;
/*    */ import org.tukaani.xz.LZMA2InputStream;
/*    */ import org.tukaani.xz.LZMA2Options;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LZMA2Decoder
/*    */   extends CoderBase
/*    */ {
/*    */   LZMA2Decoder()
/*    */   {
/* 31 */     super(new Class[] { LZMA2Options.class, Number.class });
/*    */   }
/*    */   
/*    */   InputStream decode(String archiveName, InputStream in, long uncompressedLength, Coder coder, byte[] password) throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 38 */       int dictionarySize = getDictionarySize(coder);
/* 39 */       return new LZMA2InputStream(in, dictionarySize);
/*    */     } catch (IllegalArgumentException ex) {
/* 41 */       throw new IOException(ex.getMessage());
/*    */     }
/*    */   }
/*    */   
/*    */   OutputStream encode(OutputStream out, Object opts)
/*    */     throws IOException
/*    */   {
/* 48 */     LZMA2Options options = getOptions(opts);
/* 49 */     FinishableOutputStream wrapped = new FinishableWrapperOutputStream(out);
/* 50 */     return options.getOutputStream(wrapped);
/*    */   }
/*    */   
/*    */   byte[] getOptionsAsProperties(Object opts)
/*    */   {
/* 55 */     int dictSize = getDictSize(opts);
/* 56 */     int lead = Integer.numberOfLeadingZeros(dictSize);
/* 57 */     int secondBit = (dictSize >>> 30 - lead) - 2;
/* 58 */     return new byte[] { (byte)((19 - lead) * 2 + secondBit) };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   Object getOptionsFromCoder(Coder coder, InputStream in)
/*    */   {
/* 65 */     return Integer.valueOf(getDictionarySize(coder));
/*    */   }
/*    */   
/*    */   private int getDictSize(Object opts) {
/* 69 */     if ((opts instanceof LZMA2Options)) {
/* 70 */       return ((LZMA2Options)opts).getDictSize();
/*    */     }
/* 72 */     return numberOptionOrDefault(opts);
/*    */   }
/*    */   
/*    */   private int getDictionarySize(Coder coder) throws IllegalArgumentException {
/* 76 */     int dictionarySizeBits = 0xFF & coder.properties[0];
/* 77 */     if ((dictionarySizeBits & 0xFFFFFFC0) != 0) {
/* 78 */       throw new IllegalArgumentException("Unsupported LZMA2 property bits");
/*    */     }
/* 80 */     if (dictionarySizeBits > 40) {
/* 81 */       throw new IllegalArgumentException("Dictionary larger than 4GiB maximum size");
/*    */     }
/* 83 */     if (dictionarySizeBits == 40) {
/* 84 */       return -1;
/*    */     }
/* 86 */     return (0x2 | dictionarySizeBits & 0x1) << dictionarySizeBits / 2 + 11;
/*    */   }
/*    */   
/*    */   private LZMA2Options getOptions(Object opts) throws IOException {
/* 90 */     if ((opts instanceof LZMA2Options)) {
/* 91 */       return (LZMA2Options)opts;
/*    */     }
/* 93 */     LZMA2Options options = new LZMA2Options();
/* 94 */     options.setDictSize(numberOptionOrDefault(opts));
/* 95 */     return options;
/*    */   }
/*    */   
/*    */   private int numberOptionOrDefault(Object opts) {
/* 99 */     return numberOptionOrDefault(opts, 8388608);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\LZMA2Decoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */