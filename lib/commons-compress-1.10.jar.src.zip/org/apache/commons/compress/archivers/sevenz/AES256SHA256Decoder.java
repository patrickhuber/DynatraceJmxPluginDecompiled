/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.security.GeneralSecurityException;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.CipherInputStream;
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ import org.apache.commons.compress.PasswordRequiredException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AES256SHA256Decoder
/*    */   extends CoderBase
/*    */ {
/*    */   AES256SHA256Decoder()
/*    */   {
/* 32 */     super(new Class[0]);
/*    */   }
/*    */   
/*    */   InputStream decode(final String archiveName, final InputStream in, long uncompressedLength, final Coder coder, final byte[] passwordBytes) throws IOException {
/* 36 */     new InputStream() {
/* 37 */       private boolean isInitialized = false;
/* 38 */       private CipherInputStream cipherInputStream = null;
/*    */       
/*    */       private CipherInputStream init() throws IOException {
/* 41 */         if (this.isInitialized) {
/* 42 */           return this.cipherInputStream;
/*    */         }
/* 44 */         int byte0 = 0xFF & coder.properties[0];
/* 45 */         int numCyclesPower = byte0 & 0x3F;
/* 46 */         int byte1 = 0xFF & coder.properties[1];
/* 47 */         int ivSize = (byte0 >> 6 & 0x1) + (byte1 & 0xF);
/* 48 */         int saltSize = (byte0 >> 7 & 0x1) + (byte1 >> 4);
/* 49 */         if (2 + saltSize + ivSize > coder.properties.length) {
/* 50 */           throw new IOException("Salt size + IV size too long in " + archiveName);
/*    */         }
/* 52 */         byte[] salt = new byte[saltSize];
/* 53 */         System.arraycopy(coder.properties, 2, salt, 0, saltSize);
/* 54 */         byte[] iv = new byte[16];
/* 55 */         System.arraycopy(coder.properties, 2 + saltSize, iv, 0, ivSize);
/*    */         
/* 57 */         if (passwordBytes == null) {
/* 58 */           throw new PasswordRequiredException(archiveName);
/*    */         }
/*    */         byte[] aesKeyBytes;
/* 61 */         if (numCyclesPower == 63) {
/* 62 */           byte[] aesKeyBytes = new byte[32];
/* 63 */           System.arraycopy(salt, 0, aesKeyBytes, 0, saltSize);
/* 64 */           System.arraycopy(passwordBytes, 0, aesKeyBytes, saltSize, Math.min(passwordBytes.length, aesKeyBytes.length - saltSize));
/*    */         }
/*    */         else {
/*    */           MessageDigest digest;
/*    */           try {
/* 69 */             digest = MessageDigest.getInstance("SHA-256");
/*    */           } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/* 71 */             IOException ioe = new IOException("SHA-256 is unsupported by your Java implementation");
/* 72 */             ioe.initCause(noSuchAlgorithmException);
/* 73 */             throw ioe;
/*    */           }
/*    */           
/*    */ 
/*    */ 
/* 78 */           byte[] extra = new byte[8];
/* 79 */           for (long j = 0L; j < 1L << numCyclesPower; j += 1L) {
/* 80 */             digest.update(salt);
/* 81 */             digest.update(passwordBytes);
/* 82 */             digest.update(extra);
/* 83 */             for (int k = 0; k < extra.length; k++) {
/* 84 */               int tmp326_324 = k; byte[] tmp326_322 = extra;tmp326_322[tmp326_324] = ((byte)(tmp326_322[tmp326_324] + 1));
/* 85 */               if (extra[k] != 0) {
/*    */                 break;
/*    */               }
/*    */             }
/*    */           }
/* 90 */           aesKeyBytes = digest.digest();
/*    */         }
/*    */         
/* 93 */         SecretKey aesKey = new SecretKeySpec(aesKeyBytes, "AES");
/*    */         try {
/* 95 */           Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
/* 96 */           cipher.init(2, aesKey, new IvParameterSpec(iv));
/* 97 */           this.cipherInputStream = new CipherInputStream(in, cipher);
/* 98 */           this.isInitialized = true;
/* 99 */           return this.cipherInputStream;
/*    */         } catch (GeneralSecurityException generalSecurityException) {
/* :1 */           IOException ioe = new IOException("Decryption error (do you have the JCE Unlimited Strength Jurisdiction Policy Files installed?)");
/*    */           
/* :3 */           ioe.initCause(generalSecurityException);
/* :4 */           throw ioe;
/*    */         }
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */       public int read()
/*    */         throws IOException
/*    */       {
/* ;4 */         return init().read();
/*    */       }
/*    */       
/*    */       public int read(byte[] b, int off, int len) throws IOException
/*    */       {
/* ;9 */         return init().read(b, off, len);
/*    */       }
/*    */       
/*    */       public void close() {}
/*    */     };
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\AES256SHA256Decoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */