/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Coder
/*    */ {
/*    */   byte[] decompressionMethodId;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   long numInStreams;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   long numOutStreams;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 24 */   byte[] properties = null;
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\Coder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */