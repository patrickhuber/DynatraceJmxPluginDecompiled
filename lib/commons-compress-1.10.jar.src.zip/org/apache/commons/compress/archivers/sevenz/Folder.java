/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Folder
/*     */ {
/*     */   Coder[] coders;
/*     */   long totalInputStreams;
/*     */   long totalOutputStreams;
/*     */   BindPair[] bindPairs;
/*     */   long[] packedStreams;
/*     */   long[] unpackSizes;
/*     */   boolean hasCrc;
/*     */   long crc;
/*     */   int numUnpackSubStreams;
/*     */   
/*     */   Iterable<Coder> getOrderedCoders()
/*     */   {
/*  55 */     LinkedList<Coder> l = new LinkedList();
/*  56 */     int current = (int)this.packedStreams[0];
/*  57 */     while (current != -1) {
/*  58 */       l.addLast(this.coders[current]);
/*  59 */       int pair = findBindPairForOutStream(current);
/*  60 */       current = pair != -1 ? (int)this.bindPairs[pair].inIndex : -1;
/*     */     }
/*  62 */     return l;
/*     */   }
/*     */   
/*     */   int findBindPairForInStream(int index) {
/*  66 */     for (int i = 0; i < this.bindPairs.length; i++) {
/*  67 */       if (this.bindPairs[i].inIndex == index) {
/*  68 */         return i;
/*     */       }
/*     */     }
/*  71 */     return -1;
/*     */   }
/*     */   
/*     */   int findBindPairForOutStream(int index) {
/*  75 */     for (int i = 0; i < this.bindPairs.length; i++) {
/*  76 */       if (this.bindPairs[i].outIndex == index) {
/*  77 */         return i;
/*     */       }
/*     */     }
/*  80 */     return -1;
/*     */   }
/*     */   
/*     */   long getUnpackSize() {
/*  84 */     if (this.totalOutputStreams == 0L) {
/*  85 */       return 0L;
/*     */     }
/*  87 */     for (int i = (int)this.totalOutputStreams - 1; i >= 0; i--) {
/*  88 */       if (findBindPairForOutStream(i) < 0) {
/*  89 */         return this.unpackSizes[i];
/*     */       }
/*     */     }
/*  92 */     return 0L;
/*     */   }
/*     */   
/*     */   long getUnpackSizeForCoder(Coder coder) {
/*  96 */     if (this.coders != null) {
/*  97 */       for (int i = 0; i < this.coders.length; i++) {
/*  98 */         if (this.coders[i] == coder) {
/*  99 */           return this.unpackSizes[i];
/*     */         }
/*     */       }
/*     */     }
/* 103 */     return 0L;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 108 */     return "Folder with " + this.coders.length + " coders, " + this.totalInputStreams + " input streams, " + this.totalOutputStreams + " output streams, " + this.bindPairs.length + " bind pairs, " + this.packedStreams.length + " packed streams, " + this.unpackSizes.length + " unpack sizes, " + (this.hasCrc ? "with CRC " + this.crc : "without CRC") + " and " + this.numUnpackSubStreams + " unpack streams";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\Folder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */