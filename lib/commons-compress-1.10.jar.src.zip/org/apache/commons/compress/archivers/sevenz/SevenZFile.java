/*     */ package org.apache.commons.compress.archivers.sevenz;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.zip.CRC32;
/*     */ import org.apache.commons.compress.utils.BoundedInputStream;
/*     */ import org.apache.commons.compress.utils.CRC32VerifyingInputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SevenZFile
/*     */   implements Closeable
/*     */ {
/*     */   static final int SIGNATURE_HEADER_SIZE = 32;
/*     */   private final String fileName;
/*     */   private RandomAccessFile file;
/*     */   private final Archive archive;
/*  73 */   private int currentEntryIndex = -1;
/*  74 */   private int currentFolderIndex = -1;
/*  75 */   private InputStream currentFolderInputStream = null;
/*  76 */   private InputStream currentEntryInputStream = null;
/*     */   
/*     */   private byte[] password;
/*  79 */   static final byte[] sevenZSignature = { 55, 122, -68, -81, 39, 28 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SevenZFile(File filename, byte[] password)
/*     */     throws IOException
/*     */   {
/*  93 */     boolean succeeded = false;
/*  94 */     this.file = new RandomAccessFile(filename, "r");
/*  95 */     this.fileName = filename.getAbsolutePath();
/*     */     try {
/*  97 */       this.archive = readHeaders(password);
/*  98 */       if (password != null) {
/*  99 */         this.password = new byte[password.length];
/* 100 */         System.arraycopy(password, 0, this.password, 0, password.length);
/*     */       } else {
/* 102 */         this.password = null;
/*     */       }
/* 104 */       succeeded = true;
/*     */     } finally {
/* 106 */       if (!succeeded) {
/* 107 */         this.file.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SevenZFile(File filename)
/*     */     throws IOException
/*     */   {
/* 119 */     this(filename, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 127 */     if (this.file != null) {
/*     */       try {
/* 129 */         this.file.close();
/*     */       } finally {
/* 131 */         this.file = null;
/* 132 */         if (this.password != null) {
/* 133 */           Arrays.fill(this.password, (byte)0);
/*     */         }
/* 135 */         this.password = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SevenZArchiveEntry getNextEntry()
/*     */     throws IOException
/*     */   {
/* 148 */     if (this.currentEntryIndex >= this.archive.files.length - 1) {
/* 149 */       return null;
/*     */     }
/* 151 */     this.currentEntryIndex += 1;
/* 152 */     SevenZArchiveEntry entry = this.archive.files[this.currentEntryIndex];
/* 153 */     buildDecodingStream();
/* 154 */     return entry;
/*     */   }
/*     */   
/*     */   private Archive readHeaders(byte[] password) throws IOException {
/* 158 */     byte[] signature = new byte[6];
/* 159 */     this.file.readFully(signature);
/* 160 */     if (!Arrays.equals(signature, sevenZSignature)) {
/* 161 */       throw new IOException("Bad 7z signature");
/*     */     }
/*     */     
/* 164 */     byte archiveVersionMajor = this.file.readByte();
/* 165 */     byte archiveVersionMinor = this.file.readByte();
/* 166 */     if (archiveVersionMajor != 0) {
/* 167 */       throw new IOException(String.format("Unsupported 7z version (%d,%d)", new Object[] { Byte.valueOf(archiveVersionMajor), Byte.valueOf(archiveVersionMinor) }));
/*     */     }
/*     */     
/*     */ 
/* 171 */     long startHeaderCrc = 0xFFFFFFFF & Integer.reverseBytes(this.file.readInt());
/* 172 */     StartHeader startHeader = readStartHeader(startHeaderCrc);
/*     */     
/* 174 */     int nextHeaderSizeInt = (int)startHeader.nextHeaderSize;
/* 175 */     if (nextHeaderSizeInt != startHeader.nextHeaderSize) {
/* 176 */       throw new IOException("cannot handle nextHeaderSize " + startHeader.nextHeaderSize);
/*     */     }
/* 178 */     this.file.seek(32L + startHeader.nextHeaderOffset);
/* 179 */     byte[] nextHeader = new byte[nextHeaderSizeInt];
/* 180 */     this.file.readFully(nextHeader);
/* 181 */     CRC32 crc = new CRC32();
/* 182 */     crc.update(nextHeader);
/* 183 */     if (startHeader.nextHeaderCrc != crc.getValue()) {
/* 184 */       throw new IOException("NextHeader CRC mismatch");
/*     */     }
/*     */     
/* 187 */     ByteArrayInputStream byteStream = new ByteArrayInputStream(nextHeader);
/* 188 */     DataInputStream nextHeaderInputStream = new DataInputStream(byteStream);
/*     */     
/* 190 */     Archive archive = new Archive();
/* 191 */     int nid = nextHeaderInputStream.readUnsignedByte();
/* 192 */     if (nid == 23) {
/* 193 */       nextHeaderInputStream = readEncodedHeader(nextHeaderInputStream, archive, password);
/*     */       
/*     */ 
/* 196 */       archive = new Archive();
/* 197 */       nid = nextHeaderInputStream.readUnsignedByte();
/*     */     }
/* 199 */     if (nid == 1) {
/* 200 */       readHeader(nextHeaderInputStream, archive);
/* 201 */       nextHeaderInputStream.close();
/*     */     } else {
/* 203 */       throw new IOException("Broken or unsupported archive: no Header");
/*     */     }
/* 205 */     return archive;
/*     */   }
/*     */   
/*     */   private StartHeader readStartHeader(long startHeaderCrc) throws IOException {
/* 209 */     StartHeader startHeader = new StartHeader();
/* 210 */     DataInputStream dataInputStream = null;
/*     */     try {
/* 212 */       dataInputStream = new DataInputStream(new CRC32VerifyingInputStream(new BoundedRandomAccessFileInputStream(this.file, 20L), 20L, startHeaderCrc));
/*     */       
/* 214 */       startHeader.nextHeaderOffset = Long.reverseBytes(dataInputStream.readLong());
/* 215 */       startHeader.nextHeaderSize = Long.reverseBytes(dataInputStream.readLong());
/* 216 */       startHeader.nextHeaderCrc = (0xFFFFFFFF & Integer.reverseBytes(dataInputStream.readInt()));
/* 217 */       return startHeader;
/*     */     } finally {
/* 219 */       if (dataInputStream != null) {
/* 220 */         dataInputStream.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void readHeader(DataInput header, Archive archive) throws IOException {
/* 226 */     int nid = header.readUnsignedByte();
/*     */     
/* 228 */     if (nid == 2) {
/* 229 */       readArchiveProperties(header);
/* 230 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 233 */     if (nid == 3) {
/* 234 */       throw new IOException("Additional streams unsupported");
/*     */     }
/*     */     
/*     */ 
/* 238 */     if (nid == 4) {
/* 239 */       readStreamsInfo(header, archive);
/* 240 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 243 */     if (nid == 5) {
/* 244 */       readFilesInfo(header, archive);
/* 245 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 248 */     if (nid != 0) {
/* 249 */       throw new IOException("Badly terminated header, found " + nid);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readArchiveProperties(DataInput input) throws IOException
/*     */   {
/* 255 */     int nid = input.readUnsignedByte();
/* 256 */     while (nid != 0) {
/* 257 */       long propertySize = readUint64(input);
/* 258 */       byte[] property = new byte[(int)propertySize];
/* 259 */       input.readFully(property);
/* 260 */       nid = input.readUnsignedByte();
/*     */     }
/*     */   }
/*     */   
/*     */   private DataInputStream readEncodedHeader(DataInputStream header, Archive archive, byte[] password) throws IOException
/*     */   {
/* 266 */     readStreamsInfo(header, archive);
/*     */     
/*     */ 
/* 269 */     Folder folder = archive.folders[0];
/* 270 */     int firstPackStreamIndex = 0;
/* 271 */     long folderOffset = 32L + archive.packPos + 0L;
/*     */     
/*     */ 
/* 274 */     this.file.seek(folderOffset);
/* 275 */     InputStream inputStreamStack = new BoundedRandomAccessFileInputStream(this.file, archive.packSizes[0]);
/*     */     
/* 277 */     for (Coder coder : folder.getOrderedCoders()) {
/* 278 */       if ((coder.numInStreams != 1L) || (coder.numOutStreams != 1L)) {
/* 279 */         throw new IOException("Multi input/output stream coders are not yet supported");
/*     */       }
/* 281 */       inputStreamStack = Coders.addDecoder(this.fileName, inputStreamStack, folder.getUnpackSizeForCoder(coder), coder, password);
/*     */     }
/*     */     
/* 284 */     if (folder.hasCrc) {
/* 285 */       inputStreamStack = new CRC32VerifyingInputStream(inputStreamStack, folder.getUnpackSize(), folder.crc);
/*     */     }
/*     */     
/* 288 */     byte[] nextHeader = new byte[(int)folder.getUnpackSize()];
/* 289 */     DataInputStream nextHeaderInputStream = new DataInputStream(inputStreamStack);
/*     */     try {
/* 291 */       nextHeaderInputStream.readFully(nextHeader);
/*     */     } finally {
/* 293 */       nextHeaderInputStream.close();
/*     */     }
/* 295 */     return new DataInputStream(new ByteArrayInputStream(nextHeader));
/*     */   }
/*     */   
/*     */   private void readStreamsInfo(DataInput header, Archive archive) throws IOException {
/* 299 */     int nid = header.readUnsignedByte();
/*     */     
/* 301 */     if (nid == 6) {
/* 302 */       readPackInfo(header, archive);
/* 303 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 306 */     if (nid == 7) {
/* 307 */       readUnpackInfo(header, archive);
/* 308 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     else {
/* 311 */       archive.folders = new Folder[0];
/*     */     }
/*     */     
/* 314 */     if (nid == 8) {
/* 315 */       readSubStreamsInfo(header, archive);
/* 316 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 319 */     if (nid != 0) {
/* 320 */       throw new IOException("Badly terminated StreamsInfo");
/*     */     }
/*     */   }
/*     */   
/*     */   private void readPackInfo(DataInput header, Archive archive) throws IOException {
/* 325 */     archive.packPos = readUint64(header);
/* 326 */     long numPackStreams = readUint64(header);
/* 327 */     int nid = header.readUnsignedByte();
/* 328 */     if (nid == 9) {
/* 329 */       archive.packSizes = new long[(int)numPackStreams];
/* 330 */       for (int i = 0; i < archive.packSizes.length; i++) {
/* 331 */         archive.packSizes[i] = readUint64(header);
/*     */       }
/* 333 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 336 */     if (nid == 10) {
/* 337 */       archive.packCrcsDefined = readAllOrBits(header, (int)numPackStreams);
/* 338 */       archive.packCrcs = new long[(int)numPackStreams];
/* 339 */       for (int i = 0; i < (int)numPackStreams; i++) {
/* 340 */         if (archive.packCrcsDefined.get(i)) {
/* 341 */           archive.packCrcs[i] = (0xFFFFFFFF & Integer.reverseBytes(header.readInt()));
/*     */         }
/*     */       }
/*     */       
/* 345 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 348 */     if (nid != 0) {
/* 349 */       throw new IOException("Badly terminated PackInfo (" + nid + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   private void readUnpackInfo(DataInput header, Archive archive) throws IOException {
/* 354 */     int nid = header.readUnsignedByte();
/* 355 */     if (nid != 11) {
/* 356 */       throw new IOException("Expected kFolder, got " + nid);
/*     */     }
/* 358 */     long numFolders = readUint64(header);
/* 359 */     Folder[] folders = new Folder[(int)numFolders];
/* 360 */     archive.folders = folders;
/* 361 */     int external = header.readUnsignedByte();
/* 362 */     if (external != 0) {
/* 363 */       throw new IOException("External unsupported");
/*     */     }
/* 365 */     for (int i = 0; i < (int)numFolders; i++) {
/* 366 */       folders[i] = readFolder(header);
/*     */     }
/*     */     
/*     */ 
/* 370 */     nid = header.readUnsignedByte();
/* 371 */     if (nid != 12) {
/* 372 */       throw new IOException("Expected kCodersUnpackSize, got " + nid);
/*     */     }
/* 374 */     for (Folder folder : folders) {
/* 375 */       folder.unpackSizes = new long[(int)folder.totalOutputStreams];
/* 376 */       for (int i = 0; i < folder.totalOutputStreams; i++) {
/* 377 */         folder.unpackSizes[i] = readUint64(header);
/*     */       }
/*     */     }
/*     */     
/* 381 */     nid = header.readUnsignedByte();
/* 382 */     if (nid == 10) {
/* 383 */       BitSet crcsDefined = readAllOrBits(header, (int)numFolders);
/* 384 */       for (int i = 0; i < (int)numFolders; i++) {
/* 385 */         if (crcsDefined.get(i)) {
/* 386 */           folders[i].hasCrc = true;
/* 387 */           folders[i].crc = (0xFFFFFFFF & Integer.reverseBytes(header.readInt()));
/*     */         } else {
/* 389 */           folders[i].hasCrc = false;
/*     */         }
/*     */       }
/*     */       
/* 393 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 396 */     if (nid != 0) {
/* 397 */       throw new IOException("Badly terminated UnpackInfo");
/*     */     }
/*     */   }
/*     */   
/*     */   private void readSubStreamsInfo(DataInput header, Archive archive) throws IOException {
/* 402 */     for (Folder folder : archive.folders) {
/* 403 */       folder.numUnpackSubStreams = 1;
/*     */     }
/* 405 */     int totalUnpackStreams = archive.folders.length;
/*     */     
/* 407 */     int nid = header.readUnsignedByte();
/* 408 */     if (nid == 13) {
/* 409 */       totalUnpackStreams = 0;
/* 410 */       for (Folder folder : archive.folders) {
/* 411 */         long numStreams = readUint64(header);
/* 412 */         folder.numUnpackSubStreams = ((int)numStreams);
/* 413 */         totalUnpackStreams = (int)(totalUnpackStreams + numStreams);
/*     */       }
/* 415 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 418 */     SubStreamsInfo subStreamsInfo = new SubStreamsInfo();
/* 419 */     subStreamsInfo.unpackSizes = new long[totalUnpackStreams];
/* 420 */     subStreamsInfo.hasCrc = new BitSet(totalUnpackStreams);
/* 421 */     subStreamsInfo.crcs = new long[totalUnpackStreams];
/*     */     
/* 423 */     int nextUnpackStream = 0;
/* 424 */     for (Folder folder : archive.folders)
/* 425 */       if (folder.numUnpackSubStreams != 0)
/*     */       {
/*     */ 
/* 428 */         long sum = 0L;
/* 429 */         if (nid == 9) {
/* 430 */           for (int i = 0; i < folder.numUnpackSubStreams - 1; i++) {
/* 431 */             long size = readUint64(header);
/* 432 */             subStreamsInfo.unpackSizes[(nextUnpackStream++)] = size;
/* 433 */             sum += size;
/*     */           }
/*     */         }
/* 436 */         subStreamsInfo.unpackSizes[(nextUnpackStream++)] = (folder.getUnpackSize() - sum);
/*     */       }
/* 438 */     if (nid == 9) {
/* 439 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 442 */     int numDigests = 0;
/* 443 */     for (Folder folder : archive.folders) {
/* 444 */       if ((folder.numUnpackSubStreams != 1) || (!folder.hasCrc)) {
/* 445 */         numDigests += folder.numUnpackSubStreams;
/*     */       }
/*     */     }
/*     */     
/* 449 */     if (nid == 10) {
/* 450 */       BitSet hasMissingCrc = readAllOrBits(header, numDigests);
/* 451 */       long[] missingCrcs = new long[numDigests];
/* 452 */       for (int i = 0; i < numDigests; i++) {
/* 453 */         if (hasMissingCrc.get(i)) {
/* 454 */           missingCrcs[i] = (0xFFFFFFFF & Integer.reverseBytes(header.readInt()));
/*     */         }
/*     */       }
/* 457 */       int nextCrc = 0;
/* 458 */       int nextMissingCrc = 0;
/* 459 */       for (Folder folder : archive.folders) {
/* 460 */         if ((folder.numUnpackSubStreams == 1) && (folder.hasCrc)) {
/* 461 */           subStreamsInfo.hasCrc.set(nextCrc, true);
/* 462 */           subStreamsInfo.crcs[nextCrc] = folder.crc;
/* 463 */           nextCrc++;
/*     */         } else {
/* 465 */           for (int i = 0; i < folder.numUnpackSubStreams; i++) {
/* 466 */             subStreamsInfo.hasCrc.set(nextCrc, hasMissingCrc.get(nextMissingCrc));
/* 467 */             subStreamsInfo.crcs[nextCrc] = missingCrcs[nextMissingCrc];
/* 468 */             nextCrc++;
/* 469 */             nextMissingCrc++;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 474 */       nid = header.readUnsignedByte();
/*     */     }
/*     */     
/* 477 */     if (nid != 0) {
/* 478 */       throw new IOException("Badly terminated SubStreamsInfo");
/*     */     }
/*     */     
/* 481 */     archive.subStreamsInfo = subStreamsInfo;
/*     */   }
/*     */   
/*     */   private Folder readFolder(DataInput header) throws IOException {
/* 485 */     Folder folder = new Folder();
/*     */     
/* 487 */     long numCoders = readUint64(header);
/* 488 */     Coder[] coders = new Coder[(int)numCoders];
/* 489 */     long totalInStreams = 0L;
/* 490 */     long totalOutStreams = 0L;
/* 491 */     for (int i = 0; i < coders.length; i++) {
/* 492 */       coders[i] = new Coder();
/* 493 */       int bits = header.readUnsignedByte();
/* 494 */       int idSize = bits & 0xF;
/* 495 */       boolean isSimple = (bits & 0x10) == 0;
/* 496 */       boolean hasAttributes = (bits & 0x20) != 0;
/* 497 */       boolean moreAlternativeMethods = (bits & 0x80) != 0;
/*     */       
/* 499 */       coders[i].decompressionMethodId = new byte[idSize];
/* 500 */       header.readFully(coders[i].decompressionMethodId);
/* 501 */       if (isSimple) {
/* 502 */         coders[i].numInStreams = 1L;
/* 503 */         coders[i].numOutStreams = 1L;
/*     */       } else {
/* 505 */         coders[i].numInStreams = readUint64(header);
/* 506 */         coders[i].numOutStreams = readUint64(header);
/*     */       }
/* 508 */       totalInStreams += coders[i].numInStreams;
/* 509 */       totalOutStreams += coders[i].numOutStreams;
/* 510 */       if (hasAttributes) {
/* 511 */         long propertiesSize = readUint64(header);
/* 512 */         coders[i].properties = new byte[(int)propertiesSize];
/* 513 */         header.readFully(coders[i].properties);
/*     */       }
/*     */       
/* 516 */       if (moreAlternativeMethods) {
/* 517 */         throw new IOException("Alternative methods are unsupported, please report. The reference implementation doesn't support them either.");
/*     */       }
/*     */     }
/*     */     
/* 521 */     folder.coders = coders;
/* 522 */     folder.totalInputStreams = totalInStreams;
/* 523 */     folder.totalOutputStreams = totalOutStreams;
/*     */     
/* 525 */     if (totalOutStreams == 0L) {
/* 526 */       throw new IOException("Total output streams can't be 0");
/*     */     }
/* 528 */     long numBindPairs = totalOutStreams - 1L;
/* 529 */     BindPair[] bindPairs = new BindPair[(int)numBindPairs];
/* 530 */     for (int i = 0; i < bindPairs.length; i++) {
/* 531 */       bindPairs[i] = new BindPair();
/* 532 */       bindPairs[i].inIndex = readUint64(header);
/* 533 */       bindPairs[i].outIndex = readUint64(header);
/*     */     }
/* 535 */     folder.bindPairs = bindPairs;
/*     */     
/* 537 */     if (totalInStreams < numBindPairs) {
/* 538 */       throw new IOException("Total input streams can't be less than the number of bind pairs");
/*     */     }
/* 540 */     long numPackedStreams = totalInStreams - numBindPairs;
/* 541 */     long[] packedStreams = new long[(int)numPackedStreams];
/* 542 */     if (numPackedStreams == 1L)
/*     */     {
/* 544 */       for (int i = 0; i < (int)totalInStreams; i++) {
/* 545 */         if (folder.findBindPairForInStream(i) < 0) {
/*     */           break;
/*     */         }
/*     */       }
/* 549 */       if (i == (int)totalInStreams) {
/* 550 */         throw new IOException("Couldn't find stream's bind pair index");
/*     */       }
/* 552 */       packedStreams[0] = i;
/*     */     } else {
/* 554 */       for (int i = 0; i < (int)numPackedStreams; i++) {
/* 555 */         packedStreams[i] = readUint64(header);
/*     */       }
/*     */     }
/* 558 */     folder.packedStreams = packedStreams;
/*     */     
/* 560 */     return folder;
/*     */   }
/*     */   
/*     */   private BitSet readAllOrBits(DataInput header, int size) throws IOException {
/* 564 */     int areAllDefined = header.readUnsignedByte();
/*     */     BitSet bits;
/* 566 */     if (areAllDefined != 0) {
/* 567 */       BitSet bits = new BitSet(size);
/* 568 */       for (int i = 0; i < size; i++) {
/* 569 */         bits.set(i, true);
/*     */       }
/*     */     } else {
/* 572 */       bits = readBits(header, size);
/*     */     }
/* 574 */     return bits;
/*     */   }
/*     */   
/*     */   private BitSet readBits(DataInput header, int size) throws IOException {
/* 578 */     BitSet bits = new BitSet(size);
/* 579 */     int mask = 0;
/* 580 */     int cache = 0;
/* 581 */     for (int i = 0; i < size; i++) {
/* 582 */       if (mask == 0) {
/* 583 */         mask = 128;
/* 584 */         cache = header.readUnsignedByte();
/*     */       }
/* 586 */       bits.set(i, (cache & mask) != 0);
/* 587 */       mask >>>= 1;
/*     */     }
/* 589 */     return bits;
/*     */   }
/*     */   
/*     */   private void readFilesInfo(DataInput header, Archive archive) throws IOException {
/* 593 */     long numFiles = readUint64(header);
/* 594 */     SevenZArchiveEntry[] files = new SevenZArchiveEntry[(int)numFiles];
/* 595 */     for (int i = 0; i < files.length; i++) {
/* 596 */       files[i] = new SevenZArchiveEntry();
/*     */     }
/* 598 */     BitSet isEmptyStream = null;
/* 599 */     BitSet isEmptyFile = null;
/* 600 */     BitSet isAnti = null;
/*     */     for (;;) {
/* 602 */       int propertyType = header.readUnsignedByte();
/* 603 */       if (propertyType == 0) {
/*     */         break;
/*     */       }
/* 606 */       long size = readUint64(header);
/* 607 */       switch (propertyType) {
/*     */       case 14: 
/* 609 */         isEmptyStream = readBits(header, files.length);
/* 610 */         break;
/*     */       
/*     */       case 15: 
/* 613 */         if (isEmptyStream == null) {
/* 614 */           throw new IOException("Header format error: kEmptyStream must appear before kEmptyFile");
/*     */         }
/* 616 */         isEmptyFile = readBits(header, isEmptyStream.cardinality());
/* 617 */         break;
/*     */       
/*     */       case 16: 
/* 620 */         if (isEmptyStream == null) {
/* 621 */           throw new IOException("Header format error: kEmptyStream must appear before kAnti");
/*     */         }
/* 623 */         isAnti = readBits(header, isEmptyStream.cardinality());
/* 624 */         break;
/*     */       
/*     */       case 17: 
/* 627 */         int external = header.readUnsignedByte();
/* 628 */         if (external != 0) {
/* 629 */           throw new IOException("Not implemented");
/*     */         }
/* 631 */         if ((size - 1L & 1L) != 0L) {
/* 632 */           throw new IOException("File names length invalid");
/*     */         }
/* 634 */         byte[] names = new byte[(int)(size - 1L)];
/* 635 */         header.readFully(names);
/* 636 */         int nextFile = 0;
/* 637 */         int nextName = 0;
/* 638 */         for (int i = 0; i < names.length; i += 2) {
/* 639 */           if ((names[i] == 0) && (names[(i + 1)] == 0)) {
/* 640 */             files[(nextFile++)].setName(new String(names, nextName, i - nextName, "UTF-16LE"));
/* 641 */             nextName = i + 2;
/*     */           }
/*     */         }
/* 644 */         if ((nextName != names.length) || (nextFile != files.length)) {
/* 645 */           throw new IOException("Error parsing file names");
/*     */         }
/*     */         
/* 648 */         break;
/*     */       
/*     */       case 18: 
/* 651 */         BitSet timesDefined = readAllOrBits(header, files.length);
/* 652 */         int external = header.readUnsignedByte();
/* 653 */         if (external != 0) {
/* 654 */           throw new IOException("Unimplemented");
/*     */         }
/* 656 */         for (int i = 0; i < files.length; i++) {
/* 657 */           files[i].setHasCreationDate(timesDefined.get(i));
/* 658 */           if (files[i].getHasCreationDate()) {
/* 659 */             files[i].setCreationDate(Long.reverseBytes(header.readLong()));
/*     */           }
/*     */         }
/*     */         
/* 663 */         break;
/*     */       
/*     */       case 19: 
/* 666 */         BitSet timesDefined = readAllOrBits(header, files.length);
/* 667 */         int external = header.readUnsignedByte();
/* 668 */         if (external != 0) {
/* 669 */           throw new IOException("Unimplemented");
/*     */         }
/* 671 */         for (int i = 0; i < files.length; i++) {
/* 672 */           files[i].setHasAccessDate(timesDefined.get(i));
/* 673 */           if (files[i].getHasAccessDate()) {
/* 674 */             files[i].setAccessDate(Long.reverseBytes(header.readLong()));
/*     */           }
/*     */         }
/*     */         
/* 678 */         break;
/*     */       
/*     */       case 20: 
/* 681 */         BitSet timesDefined = readAllOrBits(header, files.length);
/* 682 */         int external = header.readUnsignedByte();
/* 683 */         if (external != 0) {
/* 684 */           throw new IOException("Unimplemented");
/*     */         }
/* 686 */         for (int i = 0; i < files.length; i++) {
/* 687 */           files[i].setHasLastModifiedDate(timesDefined.get(i));
/* 688 */           if (files[i].getHasLastModifiedDate()) {
/* 689 */             files[i].setLastModifiedDate(Long.reverseBytes(header.readLong()));
/*     */           }
/*     */         }
/*     */         
/* 693 */         break;
/*     */       
/*     */       case 21: 
/* 696 */         BitSet attributesDefined = readAllOrBits(header, files.length);
/* 697 */         int external = header.readUnsignedByte();
/* 698 */         if (external != 0) {
/* 699 */           throw new IOException("Unimplemented");
/*     */         }
/* 701 */         for (int i = 0; i < files.length; i++) {
/* 702 */           files[i].setHasWindowsAttributes(attributesDefined.get(i));
/* 703 */           if (files[i].getHasWindowsAttributes()) {
/* 704 */             files[i].setWindowsAttributes(Integer.reverseBytes(header.readInt()));
/*     */           }
/*     */         }
/*     */         
/* 708 */         break;
/*     */       
/*     */       case 24: 
/* 711 */         throw new IOException("kStartPos is unsupported, please report");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 25: 
/* 717 */         if (skipBytesFully(header, size) < size) {
/* 718 */           throw new IOException("Incomplete kDummy property");
/*     */         }
/*     */         
/*     */         break;
/*     */       case 22: 
/*     */       case 23: 
/*     */       default: 
/* 725 */         if (skipBytesFully(header, size) < size) {
/* 726 */           throw new IOException("Incomplete property of type " + propertyType);
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/* 732 */     int nonEmptyFileCounter = 0;
/* 733 */     int emptyFileCounter = 0;
/* 734 */     for (int i = 0; i < files.length; i++) {
/* 735 */       files[i].setHasStream(isEmptyStream == null);
/* 736 */       if (files[i].hasStream()) {
/* 737 */         files[i].setDirectory(false);
/* 738 */         files[i].setAntiItem(false);
/* 739 */         files[i].setHasCrc(archive.subStreamsInfo.hasCrc.get(nonEmptyFileCounter));
/* 740 */         files[i].setCrcValue(archive.subStreamsInfo.crcs[nonEmptyFileCounter]);
/* 741 */         files[i].setSize(archive.subStreamsInfo.unpackSizes[nonEmptyFileCounter]);
/* 742 */         nonEmptyFileCounter++;
/*     */       } else {
/* 744 */         files[i].setDirectory(isEmptyFile == null);
/* 745 */         files[i].setAntiItem(isAnti == null ? false : isAnti.get(emptyFileCounter));
/* 746 */         files[i].setHasCrc(false);
/* 747 */         files[i].setSize(0L);
/* 748 */         emptyFileCounter++;
/*     */       }
/*     */     }
/* 751 */     archive.files = files;
/* 752 */     calculateStreamMap(archive);
/*     */   }
/*     */   
/*     */   private void calculateStreamMap(Archive archive) throws IOException {
/* 756 */     StreamMap streamMap = new StreamMap();
/*     */     
/* 758 */     int nextFolderPackStreamIndex = 0;
/* 759 */     int numFolders = archive.folders != null ? archive.folders.length : 0;
/* 760 */     streamMap.folderFirstPackStreamIndex = new int[numFolders];
/* 761 */     for (int i = 0; i < numFolders; i++) {
/* 762 */       streamMap.folderFirstPackStreamIndex[i] = nextFolderPackStreamIndex;
/* 763 */       nextFolderPackStreamIndex += archive.folders[i].packedStreams.length;
/*     */     }
/*     */     
/* 766 */     long nextPackStreamOffset = 0L;
/* 767 */     int numPackSizes = archive.packSizes != null ? archive.packSizes.length : 0;
/* 768 */     streamMap.packStreamOffsets = new long[numPackSizes];
/* 769 */     for (int i = 0; i < numPackSizes; i++) {
/* 770 */       streamMap.packStreamOffsets[i] = nextPackStreamOffset;
/* 771 */       nextPackStreamOffset += archive.packSizes[i];
/*     */     }
/*     */     
/* 774 */     streamMap.folderFirstFileIndex = new int[numFolders];
/* 775 */     streamMap.fileFolderIndex = new int[archive.files.length];
/* 776 */     int nextFolderIndex = 0;
/* 777 */     int nextFolderUnpackStreamIndex = 0;
/* 778 */     for (int i = 0; i < archive.files.length; i++)
/* 779 */       if ((!archive.files[i].hasStream()) && (nextFolderUnpackStreamIndex == 0)) {
/* 780 */         streamMap.fileFolderIndex[i] = -1;
/*     */       }
/*     */       else {
/* 783 */         if (nextFolderUnpackStreamIndex == 0) {
/* 784 */           for (; nextFolderIndex < archive.folders.length; nextFolderIndex++) {
/* 785 */             streamMap.folderFirstFileIndex[nextFolderIndex] = i;
/* 786 */             if (archive.folders[nextFolderIndex].numUnpackSubStreams > 0) {
/*     */               break;
/*     */             }
/*     */           }
/* 790 */           if (nextFolderIndex >= archive.folders.length) {
/* 791 */             throw new IOException("Too few folders in archive");
/*     */           }
/*     */         }
/* 794 */         streamMap.fileFolderIndex[i] = nextFolderIndex;
/* 795 */         if (archive.files[i].hasStream())
/*     */         {
/*     */ 
/* 798 */           nextFolderUnpackStreamIndex++;
/* 799 */           if (nextFolderUnpackStreamIndex >= archive.folders[nextFolderIndex].numUnpackSubStreams) {
/* 800 */             nextFolderIndex++;
/* 801 */             nextFolderUnpackStreamIndex = 0;
/*     */           }
/*     */         }
/*     */       }
/* 805 */     archive.streamMap = streamMap;
/*     */   }
/*     */   
/*     */   private void buildDecodingStream() throws IOException {
/* 809 */     int folderIndex = this.archive.streamMap.fileFolderIndex[this.currentEntryIndex];
/* 810 */     if (folderIndex < 0) {
/* 811 */       this.currentEntryInputStream = new BoundedInputStream(new ByteArrayInputStream(new byte[0]), 0L);
/*     */       
/* 813 */       return;
/*     */     }
/* 815 */     SevenZArchiveEntry file = this.archive.files[this.currentEntryIndex];
/* 816 */     if (this.currentFolderIndex == folderIndex)
/*     */     {
/* 818 */       drainPreviousEntry();
/* 819 */       file.setContentMethods(this.archive.files[(this.currentEntryIndex - 1)].getContentMethods());
/*     */     } else {
/* 821 */       this.currentFolderIndex = folderIndex;
/* 822 */       if (this.currentFolderInputStream != null) {
/* 823 */         this.currentFolderInputStream.close();
/* 824 */         this.currentFolderInputStream = null;
/*     */       }
/*     */       
/* 827 */       Folder folder = this.archive.folders[folderIndex];
/* 828 */       int firstPackStreamIndex = this.archive.streamMap.folderFirstPackStreamIndex[folderIndex];
/* 829 */       long folderOffset = 32L + this.archive.packPos + this.archive.streamMap.packStreamOffsets[firstPackStreamIndex];
/*     */       
/* 831 */       this.currentFolderInputStream = buildDecoderStack(folder, folderOffset, firstPackStreamIndex, file);
/*     */     }
/* 833 */     InputStream fileStream = new BoundedInputStream(this.currentFolderInputStream, file.getSize());
/*     */     
/* 835 */     if (file.getHasCrc()) {
/* 836 */       this.currentEntryInputStream = new CRC32VerifyingInputStream(fileStream, file.getSize(), file.getCrcValue());
/*     */     }
/*     */     else {
/* 839 */       this.currentEntryInputStream = fileStream;
/*     */     }
/*     */   }
/*     */   
/*     */   private void drainPreviousEntry() throws IOException
/*     */   {
/* 845 */     if (this.currentEntryInputStream != null)
/*     */     {
/* 847 */       IOUtils.skip(this.currentEntryInputStream, Long.MAX_VALUE);
/* 848 */       this.currentEntryInputStream.close();
/* 849 */       this.currentEntryInputStream = null;
/*     */     }
/*     */   }
/*     */   
/*     */   private InputStream buildDecoderStack(Folder folder, long folderOffset, int firstPackStreamIndex, SevenZArchiveEntry entry) throws IOException
/*     */   {
/* 855 */     this.file.seek(folderOffset);
/* 856 */     InputStream inputStreamStack = new BoundedRandomAccessFileInputStream(this.file, this.archive.packSizes[firstPackStreamIndex]);
/*     */     
/* 858 */     LinkedList<SevenZMethodConfiguration> methods = new LinkedList();
/* 859 */     for (Coder coder : folder.getOrderedCoders()) {
/* 860 */       if ((coder.numInStreams != 1L) || (coder.numOutStreams != 1L)) {
/* 861 */         throw new IOException("Multi input/output stream coders are not yet supported");
/*     */       }
/* 863 */       SevenZMethod method = SevenZMethod.byId(coder.decompressionMethodId);
/* 864 */       inputStreamStack = Coders.addDecoder(this.fileName, inputStreamStack, folder.getUnpackSizeForCoder(coder), coder, this.password);
/*     */       
/* 866 */       methods.addFirst(new SevenZMethodConfiguration(method, Coders.findByMethod(method).getOptionsFromCoder(coder, inputStreamStack)));
/*     */     }
/*     */     
/* 869 */     entry.setContentMethods(methods);
/* 870 */     if (folder.hasCrc) {
/* 871 */       return new CRC32VerifyingInputStream(inputStreamStack, folder.getUnpackSize(), folder.crc);
/*     */     }
/*     */     
/* 874 */     return inputStreamStack;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 886 */     if (this.currentEntryInputStream == null) {
/* 887 */       throw new IllegalStateException("No current 7z entry");
/*     */     }
/* 889 */     return this.currentEntryInputStream.read();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 901 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 915 */     if (this.currentEntryInputStream == null) {
/* 916 */       throw new IllegalStateException("No current 7z entry");
/*     */     }
/* 918 */     return this.currentEntryInputStream.read(b, off, len);
/*     */   }
/*     */   
/*     */   private static long readUint64(DataInput in) throws IOException
/*     */   {
/* 923 */     long firstByte = in.readUnsignedByte();
/* 924 */     int mask = 128;
/* 925 */     long value = 0L;
/* 926 */     for (int i = 0; i < 8; i++) {
/* 927 */       if ((firstByte & mask) == 0L) {
/* 928 */         return value | (firstByte & mask - 1) << 8 * i;
/*     */       }
/* 930 */       long nextByte = in.readUnsignedByte();
/* 931 */       value |= nextByte << 8 * i;
/* 932 */       mask >>>= 1;
/*     */     }
/* 934 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 948 */     if (length < sevenZSignature.length) {
/* 949 */       return false;
/*     */     }
/*     */     
/* 952 */     for (int i = 0; i < sevenZSignature.length; i++) {
/* 953 */       if (signature[i] != sevenZSignature[i]) {
/* 954 */         return false;
/*     */       }
/*     */     }
/* 957 */     return true;
/*     */   }
/*     */   
/*     */   private static long skipBytesFully(DataInput input, long bytesToSkip) throws IOException {
/* 961 */     if (bytesToSkip < 1L) {
/* 962 */       return 0L;
/*     */     }
/* 964 */     long skipped = 0L;
/* 965 */     while (bytesToSkip > 2147483647L) {
/* 966 */       long skippedNow = skipBytesFully(input, 2147483647L);
/* 967 */       if (skippedNow == 0L) {
/* 968 */         return skipped;
/*     */       }
/* 970 */       skipped += skippedNow;
/* 971 */       bytesToSkip -= skippedNow;
/*     */     }
/* 973 */     while (bytesToSkip > 0L) {
/* 974 */       int skippedNow = input.skipBytes((int)bytesToSkip);
/* 975 */       if (skippedNow == 0) {
/* 976 */         return skipped;
/*     */       }
/* 978 */       skipped += skippedNow;
/* 979 */       bytesToSkip -= skippedNow;
/*     */     }
/* 981 */     return skipped;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\SevenZFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */