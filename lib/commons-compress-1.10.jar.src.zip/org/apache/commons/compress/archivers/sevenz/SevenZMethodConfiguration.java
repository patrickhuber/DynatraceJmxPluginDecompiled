/*    */ package org.apache.commons.compress.archivers.sevenz;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SevenZMethodConfiguration
/*    */ {
/*    */   private final SevenZMethod method;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final Object options;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SevenZMethodConfiguration(SevenZMethod method)
/*    */   {
/* 47 */     this(method, null);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SevenZMethodConfiguration(SevenZMethod method, Object options)
/*    */   {
/* 57 */     this.method = method;
/* 58 */     this.options = options;
/* 59 */     if ((options != null) && (!Coders.findByMethod(method).canAcceptOptions(options))) {
/* 60 */       throw new IllegalArgumentException("The " + method + " method doesn't support options of type " + options.getClass());
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SevenZMethod getMethod()
/*    */   {
/* 70 */     return this.method;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getOptions()
/*    */   {
/* 78 */     return this.options;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\sevenz\SevenZMethodConfiguration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */