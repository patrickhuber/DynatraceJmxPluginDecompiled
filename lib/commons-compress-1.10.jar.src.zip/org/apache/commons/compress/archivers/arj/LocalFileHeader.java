/*     */ package org.apache.commons.compress.archivers.arj;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LocalFileHeader
/*     */ {
/*     */   int archiverVersionNumber;
/*     */   int minVersionToExtract;
/*     */   int hostOS;
/*     */   int arjFlags;
/*     */   int method;
/*     */   int fileType;
/*     */   int reserved;
/*     */   int dateTimeModified;
/*     */   long compressedSize;
/*     */   long originalSize;
/*     */   long originalCrc32;
/*     */   int fileSpecPosition;
/*     */   int fileAccessMode;
/*     */   int firstChapter;
/*     */   int lastChapter;
/*     */   int extendedFilePosition;
/*     */   int dateTimeAccessed;
/*     */   int dateTimeCreated;
/*     */   int originalSizeEvenForVolumes;
/*     */   String name;
/*     */   String comment;
/*     */   byte[][] extendedHeaders;
/*     */   
/*     */   LocalFileHeader()
/*     */   {
/*  47 */     this.extendedHeaders = ((byte[][])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  75 */     StringBuilder builder = new StringBuilder();
/*  76 */     builder.append("LocalFileHeader [archiverVersionNumber=");
/*  77 */     builder.append(this.archiverVersionNumber);
/*  78 */     builder.append(", minVersionToExtract=");
/*  79 */     builder.append(this.minVersionToExtract);
/*  80 */     builder.append(", hostOS=");
/*  81 */     builder.append(this.hostOS);
/*  82 */     builder.append(", arjFlags=");
/*  83 */     builder.append(this.arjFlags);
/*  84 */     builder.append(", method=");
/*  85 */     builder.append(this.method);
/*  86 */     builder.append(", fileType=");
/*  87 */     builder.append(this.fileType);
/*  88 */     builder.append(", reserved=");
/*  89 */     builder.append(this.reserved);
/*  90 */     builder.append(", dateTimeModified=");
/*  91 */     builder.append(this.dateTimeModified);
/*  92 */     builder.append(", compressedSize=");
/*  93 */     builder.append(this.compressedSize);
/*  94 */     builder.append(", originalSize=");
/*  95 */     builder.append(this.originalSize);
/*  96 */     builder.append(", originalCrc32=");
/*  97 */     builder.append(this.originalCrc32);
/*  98 */     builder.append(", fileSpecPosition=");
/*  99 */     builder.append(this.fileSpecPosition);
/* 100 */     builder.append(", fileAccessMode=");
/* 101 */     builder.append(this.fileAccessMode);
/* 102 */     builder.append(", firstChapter=");
/* 103 */     builder.append(this.firstChapter);
/* 104 */     builder.append(", lastChapter=");
/* 105 */     builder.append(this.lastChapter);
/* 106 */     builder.append(", extendedFilePosition=");
/* 107 */     builder.append(this.extendedFilePosition);
/* 108 */     builder.append(", dateTimeAccessed=");
/* 109 */     builder.append(this.dateTimeAccessed);
/* 110 */     builder.append(", dateTimeCreated=");
/* 111 */     builder.append(this.dateTimeCreated);
/* 112 */     builder.append(", originalSizeEvenForVolumes=");
/* 113 */     builder.append(this.originalSizeEvenForVolumes);
/* 114 */     builder.append(", name=");
/* 115 */     builder.append(this.name);
/* 116 */     builder.append(", comment=");
/* 117 */     builder.append(this.comment);
/* 118 */     builder.append(", extendedHeaders=");
/* 119 */     builder.append(Arrays.toString(this.extendedHeaders));
/* 120 */     builder.append("]");
/* 121 */     return builder.toString();
/*     */   }
/*     */   
/*     */   static class Methods
/*     */   {
/*     */     static final int STORED = 0;
/*     */     static final int COMPRESSED_MOST = 1;
/*     */     static final int COMPRESSED_FASTEST = 4;
/*     */     static final int NO_DATA_NO_CRC = 8;
/*     */     static final int NO_DATA = 9;
/*     */   }
/*     */   
/*     */   static class FileTypes
/*     */   {
/*     */     static final int BINARY = 0;
/*     */     static final int SEVEN_BIT_TEXT = 1;
/*     */     static final int DIRECTORY = 3;
/*     */     static final int VOLUME_LABEL = 4;
/*     */     static final int CHAPTER_LABEL = 5;
/*     */   }
/*     */   
/*     */   static class Flags
/*     */   {
/*     */     static final int GARBLED = 1;
/*     */     static final int VOLUME = 4;
/*     */     static final int EXTFILE = 8;
/*     */     static final int PATHSYM = 16;
/*     */     static final int BACKUP = 32;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\arj\LocalFileHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */