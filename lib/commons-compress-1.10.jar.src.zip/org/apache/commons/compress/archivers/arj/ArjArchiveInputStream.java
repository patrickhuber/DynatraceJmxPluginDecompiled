/*     */ package org.apache.commons.compress.archivers.arj;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.zip.CRC32;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveException;
/*     */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*     */ import org.apache.commons.compress.utils.BoundedInputStream;
/*     */ import org.apache.commons.compress.utils.CRC32VerifyingInputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArjArchiveInputStream
/*     */   extends ArchiveInputStream
/*     */ {
/*     */   private static final int ARJ_MAGIC_1 = 96;
/*     */   private static final int ARJ_MAGIC_2 = 234;
/*     */   private final DataInputStream in;
/*     */   private final String charsetName;
/*     */   private final MainHeader mainHeader;
/*  48 */   private LocalFileHeader currentLocalFileHeader = null;
/*  49 */   private InputStream currentInputStream = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArjArchiveInputStream(InputStream inputStream, String charsetName)
/*     */     throws ArchiveException
/*     */   {
/*  60 */     this.in = new DataInputStream(inputStream);
/*  61 */     this.charsetName = charsetName;
/*     */     try {
/*  63 */       this.mainHeader = readMainHeader();
/*  64 */       if ((this.mainHeader.arjFlags & 0x1) != 0) {
/*  65 */         throw new ArchiveException("Encrypted ARJ files are unsupported");
/*     */       }
/*  67 */       if ((this.mainHeader.arjFlags & 0x4) != 0) {
/*  68 */         throw new ArchiveException("Multi-volume ARJ files are unsupported");
/*     */       }
/*     */     } catch (IOException ioException) {
/*  71 */       throw new ArchiveException(ioException.getMessage(), ioException);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArjArchiveInputStream(InputStream inputStream)
/*     */     throws ArchiveException
/*     */   {
/*  83 */     this(inputStream, "CP437");
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  88 */     this.in.close();
/*     */   }
/*     */   
/*     */   private int read8(DataInputStream dataIn) throws IOException {
/*  92 */     int value = dataIn.readUnsignedByte();
/*  93 */     count(1);
/*  94 */     return value;
/*     */   }
/*     */   
/*     */   private int read16(DataInputStream dataIn) throws IOException {
/*  98 */     int value = dataIn.readUnsignedShort();
/*  99 */     count(2);
/* 100 */     return Integer.reverseBytes(value) >>> 16;
/*     */   }
/*     */   
/*     */   private int read32(DataInputStream dataIn) throws IOException {
/* 104 */     int value = dataIn.readInt();
/* 105 */     count(4);
/* 106 */     return Integer.reverseBytes(value);
/*     */   }
/*     */   
/*     */   private String readString(DataInputStream dataIn) throws IOException {
/* 110 */     ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/*     */     int nextByte;
/* 112 */     while ((nextByte = dataIn.readUnsignedByte()) != 0) {
/* 113 */       buffer.write(nextByte);
/*     */     }
/* 115 */     if (this.charsetName != null) {
/* 116 */       return new String(buffer.toByteArray(), this.charsetName);
/*     */     }
/*     */     
/* 119 */     return new String(buffer.toByteArray());
/*     */   }
/*     */   
/*     */   private void readFully(DataInputStream dataIn, byte[] b)
/*     */     throws IOException
/*     */   {
/* 125 */     dataIn.readFully(b);
/* 126 */     count(b.length);
/*     */   }
/*     */   
/*     */   private byte[] readHeader() throws IOException {
/* 130 */     boolean found = false;
/* 131 */     byte[] basicHeaderBytes = null;
/*     */     do {
/* 133 */       int first = 0;
/* 134 */       int second = read8(this.in);
/*     */       do {
/* 136 */         first = second;
/* 137 */         second = read8(this.in);
/* 138 */       } while ((first != 96) && (second != 234));
/* 139 */       int basicHeaderSize = read16(this.in);
/* 140 */       if (basicHeaderSize == 0)
/*     */       {
/* 142 */         return null;
/*     */       }
/* 144 */       if (basicHeaderSize <= 2600) {
/* 145 */         basicHeaderBytes = new byte[basicHeaderSize];
/* 146 */         readFully(this.in, basicHeaderBytes);
/* 147 */         long basicHeaderCrc32 = read32(this.in) & 0xFFFFFFFF;
/* 148 */         CRC32 crc32 = new CRC32();
/* 149 */         crc32.update(basicHeaderBytes);
/* 150 */         if (basicHeaderCrc32 == crc32.getValue()) {
/* 151 */           found = true;
/*     */         }
/*     */       }
/* 154 */     } while (!found);
/* 155 */     return basicHeaderBytes;
/*     */   }
/*     */   
/*     */   private MainHeader readMainHeader() throws IOException {
/* 159 */     byte[] basicHeaderBytes = readHeader();
/* 160 */     if (basicHeaderBytes == null) {
/* 161 */       throw new IOException("Archive ends without any headers");
/*     */     }
/* 163 */     DataInputStream basicHeader = new DataInputStream(new ByteArrayInputStream(basicHeaderBytes));
/*     */     
/*     */ 
/* 166 */     int firstHeaderSize = basicHeader.readUnsignedByte();
/* 167 */     byte[] firstHeaderBytes = new byte[firstHeaderSize - 1];
/* 168 */     basicHeader.readFully(firstHeaderBytes);
/* 169 */     DataInputStream firstHeader = new DataInputStream(new ByteArrayInputStream(firstHeaderBytes));
/*     */     
/*     */ 
/* 172 */     MainHeader hdr = new MainHeader();
/* 173 */     hdr.archiverVersionNumber = firstHeader.readUnsignedByte();
/* 174 */     hdr.minVersionToExtract = firstHeader.readUnsignedByte();
/* 175 */     hdr.hostOS = firstHeader.readUnsignedByte();
/* 176 */     hdr.arjFlags = firstHeader.readUnsignedByte();
/* 177 */     hdr.securityVersion = firstHeader.readUnsignedByte();
/* 178 */     hdr.fileType = firstHeader.readUnsignedByte();
/* 179 */     hdr.reserved = firstHeader.readUnsignedByte();
/* 180 */     hdr.dateTimeCreated = read32(firstHeader);
/* 181 */     hdr.dateTimeModified = read32(firstHeader);
/* 182 */     hdr.archiveSize = (0xFFFFFFFF & read32(firstHeader));
/* 183 */     hdr.securityEnvelopeFilePosition = read32(firstHeader);
/* 184 */     hdr.fileSpecPosition = read16(firstHeader);
/* 185 */     hdr.securityEnvelopeLength = read16(firstHeader);
/* 186 */     pushedBackBytes(20L);
/* 187 */     hdr.encryptionVersion = firstHeader.readUnsignedByte();
/* 188 */     hdr.lastChapter = firstHeader.readUnsignedByte();
/*     */     
/* 190 */     if (firstHeaderSize >= 33) {
/* 191 */       hdr.arjProtectionFactor = firstHeader.readUnsignedByte();
/* 192 */       hdr.arjFlags2 = firstHeader.readUnsignedByte();
/* 193 */       firstHeader.readUnsignedByte();
/* 194 */       firstHeader.readUnsignedByte();
/*     */     }
/*     */     
/* 197 */     hdr.name = readString(basicHeader);
/* 198 */     hdr.comment = readString(basicHeader);
/*     */     
/* 200 */     int extendedHeaderSize = read16(this.in);
/* 201 */     if (extendedHeaderSize > 0) {
/* 202 */       hdr.extendedHeaderBytes = new byte[extendedHeaderSize];
/* 203 */       readFully(this.in, hdr.extendedHeaderBytes);
/* 204 */       long extendedHeaderCrc32 = 0xFFFFFFFF & read32(this.in);
/* 205 */       CRC32 crc32 = new CRC32();
/* 206 */       crc32.update(hdr.extendedHeaderBytes);
/* 207 */       if (extendedHeaderCrc32 != crc32.getValue()) {
/* 208 */         throw new IOException("Extended header CRC32 verification failure");
/*     */       }
/*     */     }
/*     */     
/* 212 */     return hdr;
/*     */   }
/*     */   
/*     */   private LocalFileHeader readLocalFileHeader() throws IOException {
/* 216 */     byte[] basicHeaderBytes = readHeader();
/* 217 */     if (basicHeaderBytes == null) {
/* 218 */       return null;
/*     */     }
/* 220 */     DataInputStream basicHeader = new DataInputStream(new ByteArrayInputStream(basicHeaderBytes));
/*     */     
/*     */ 
/* 223 */     int firstHeaderSize = basicHeader.readUnsignedByte();
/* 224 */     byte[] firstHeaderBytes = new byte[firstHeaderSize - 1];
/* 225 */     basicHeader.readFully(firstHeaderBytes);
/* 226 */     DataInputStream firstHeader = new DataInputStream(new ByteArrayInputStream(firstHeaderBytes));
/*     */     
/*     */ 
/* 229 */     LocalFileHeader localFileHeader = new LocalFileHeader();
/* 230 */     localFileHeader.archiverVersionNumber = firstHeader.readUnsignedByte();
/* 231 */     localFileHeader.minVersionToExtract = firstHeader.readUnsignedByte();
/* 232 */     localFileHeader.hostOS = firstHeader.readUnsignedByte();
/* 233 */     localFileHeader.arjFlags = firstHeader.readUnsignedByte();
/* 234 */     localFileHeader.method = firstHeader.readUnsignedByte();
/* 235 */     localFileHeader.fileType = firstHeader.readUnsignedByte();
/* 236 */     localFileHeader.reserved = firstHeader.readUnsignedByte();
/* 237 */     localFileHeader.dateTimeModified = read32(firstHeader);
/* 238 */     localFileHeader.compressedSize = (0xFFFFFFFF & read32(firstHeader));
/* 239 */     localFileHeader.originalSize = (0xFFFFFFFF & read32(firstHeader));
/* 240 */     localFileHeader.originalCrc32 = (0xFFFFFFFF & read32(firstHeader));
/* 241 */     localFileHeader.fileSpecPosition = read16(firstHeader);
/* 242 */     localFileHeader.fileAccessMode = read16(firstHeader);
/* 243 */     pushedBackBytes(20L);
/* 244 */     localFileHeader.firstChapter = firstHeader.readUnsignedByte();
/* 245 */     localFileHeader.lastChapter = firstHeader.readUnsignedByte();
/*     */     
/* 247 */     readExtraData(firstHeaderSize, firstHeader, localFileHeader);
/*     */     
/* 249 */     localFileHeader.name = readString(basicHeader);
/* 250 */     localFileHeader.comment = readString(basicHeader);
/*     */     
/* 252 */     ArrayList<byte[]> extendedHeaders = new ArrayList();
/*     */     int extendedHeaderSize;
/* 254 */     while ((extendedHeaderSize = read16(this.in)) > 0) {
/* 255 */       byte[] extendedHeaderBytes = new byte[extendedHeaderSize];
/* 256 */       readFully(this.in, extendedHeaderBytes);
/* 257 */       long extendedHeaderCrc32 = 0xFFFFFFFF & read32(this.in);
/* 258 */       CRC32 crc32 = new CRC32();
/* 259 */       crc32.update(extendedHeaderBytes);
/* 260 */       if (extendedHeaderCrc32 != crc32.getValue()) {
/* 261 */         throw new IOException("Extended header CRC32 verification failure");
/*     */       }
/* 263 */       extendedHeaders.add(extendedHeaderBytes);
/*     */     }
/* 265 */     localFileHeader.extendedHeaders = ((byte[][])extendedHeaders.toArray(new byte[extendedHeaders.size()][]));
/*     */     
/* 267 */     return localFileHeader;
/*     */   }
/*     */   
/*     */   private void readExtraData(int firstHeaderSize, DataInputStream firstHeader, LocalFileHeader localFileHeader) throws IOException
/*     */   {
/* 272 */     if (firstHeaderSize >= 33) {
/* 273 */       localFileHeader.extendedFilePosition = read32(firstHeader);
/* 274 */       if (firstHeaderSize >= 45) {
/* 275 */         localFileHeader.dateTimeAccessed = read32(firstHeader);
/* 276 */         localFileHeader.dateTimeCreated = read32(firstHeader);
/* 277 */         localFileHeader.originalSizeEvenForVolumes = read32(firstHeader);
/* 278 */         pushedBackBytes(12L);
/*     */       }
/* 280 */       pushedBackBytes(4L);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 294 */     return (length >= 2) && ((0xFF & signature[0]) == 96) && ((0xFF & signature[1]) == 234);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getArchiveName()
/*     */   {
/* 304 */     return this.mainHeader.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getArchiveComment()
/*     */   {
/* 312 */     return this.mainHeader.comment;
/*     */   }
/*     */   
/*     */   public ArjArchiveEntry getNextEntry() throws IOException
/*     */   {
/* 317 */     if (this.currentInputStream != null)
/*     */     {
/* 319 */       IOUtils.skip(this.currentInputStream, Long.MAX_VALUE);
/* 320 */       this.currentInputStream.close();
/* 321 */       this.currentLocalFileHeader = null;
/* 322 */       this.currentInputStream = null;
/*     */     }
/*     */     
/* 325 */     this.currentLocalFileHeader = readLocalFileHeader();
/* 326 */     if (this.currentLocalFileHeader != null) {
/* 327 */       this.currentInputStream = new BoundedInputStream(this.in, this.currentLocalFileHeader.compressedSize);
/* 328 */       if (this.currentLocalFileHeader.method == 0) {
/* 329 */         this.currentInputStream = new CRC32VerifyingInputStream(this.currentInputStream, this.currentLocalFileHeader.originalSize, this.currentLocalFileHeader.originalCrc32);
/*     */       }
/*     */       
/* 332 */       return new ArjArchiveEntry(this.currentLocalFileHeader);
/*     */     }
/* 334 */     this.currentInputStream = null;
/* 335 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean canReadEntryData(ArchiveEntry ae)
/*     */   {
/* 341 */     return ((ae instanceof ArjArchiveEntry)) && (((ArjArchiveEntry)ae).getMethod() == 0);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 347 */     if (this.currentLocalFileHeader == null) {
/* 348 */       throw new IllegalStateException("No current arj entry");
/*     */     }
/* 350 */     if (this.currentLocalFileHeader.method != 0) {
/* 351 */       throw new IOException("Unsupported compression method " + this.currentLocalFileHeader.method);
/*     */     }
/* 353 */     return this.currentInputStream.read(b, off, len);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\arj\ArjArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */