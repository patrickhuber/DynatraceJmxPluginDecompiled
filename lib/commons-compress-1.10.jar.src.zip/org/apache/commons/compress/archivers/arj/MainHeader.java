/*     */ package org.apache.commons.compress.archivers.arj;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MainHeader
/*     */ {
/*     */   int archiverVersionNumber;
/*     */   int minVersionToExtract;
/*     */   int hostOS;
/*     */   int arjFlags;
/*     */   int securityVersion;
/*     */   int fileType;
/*     */   int reserved;
/*     */   int dateTimeCreated;
/*     */   int dateTimeModified;
/*     */   long archiveSize;
/*     */   int securityEnvelopeFilePosition;
/*     */   int fileSpecPosition;
/*     */   int securityEnvelopeLength;
/*     */   int encryptionVersion;
/*     */   int lastChapter;
/*     */   int arjProtectionFactor;
/*     */   int arjFlags2;
/*     */   String name;
/*     */   String comment;
/*     */   byte[] extendedHeaderBytes;
/*     */   
/*     */   MainHeader()
/*     */   {
/*  42 */     this.extendedHeaderBytes = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  58 */     StringBuilder builder = new StringBuilder();
/*  59 */     builder.append("MainHeader [archiverVersionNumber=");
/*  60 */     builder.append(this.archiverVersionNumber);
/*  61 */     builder.append(", minVersionToExtract=");
/*  62 */     builder.append(this.minVersionToExtract);
/*  63 */     builder.append(", hostOS=");
/*  64 */     builder.append(this.hostOS);
/*  65 */     builder.append(", arjFlags=");
/*  66 */     builder.append(this.arjFlags);
/*  67 */     builder.append(", securityVersion=");
/*  68 */     builder.append(this.securityVersion);
/*  69 */     builder.append(", fileType=");
/*  70 */     builder.append(this.fileType);
/*  71 */     builder.append(", reserved=");
/*  72 */     builder.append(this.reserved);
/*  73 */     builder.append(", dateTimeCreated=");
/*  74 */     builder.append(this.dateTimeCreated);
/*  75 */     builder.append(", dateTimeModified=");
/*  76 */     builder.append(this.dateTimeModified);
/*  77 */     builder.append(", archiveSize=");
/*  78 */     builder.append(this.archiveSize);
/*  79 */     builder.append(", securityEnvelopeFilePosition=");
/*  80 */     builder.append(this.securityEnvelopeFilePosition);
/*  81 */     builder.append(", fileSpecPosition=");
/*  82 */     builder.append(this.fileSpecPosition);
/*  83 */     builder.append(", securityEnvelopeLength=");
/*  84 */     builder.append(this.securityEnvelopeLength);
/*  85 */     builder.append(", encryptionVersion=");
/*  86 */     builder.append(this.encryptionVersion);
/*  87 */     builder.append(", lastChapter=");
/*  88 */     builder.append(this.lastChapter);
/*  89 */     builder.append(", arjProtectionFactor=");
/*  90 */     builder.append(this.arjProtectionFactor);
/*  91 */     builder.append(", arjFlags2=");
/*  92 */     builder.append(this.arjFlags2);
/*  93 */     builder.append(", name=");
/*  94 */     builder.append(this.name);
/*  95 */     builder.append(", comment=");
/*  96 */     builder.append(this.comment);
/*  97 */     builder.append(", extendedHeaderBytes=");
/*  98 */     builder.append(Arrays.toString(this.extendedHeaderBytes));
/*  99 */     builder.append("]");
/* 100 */     return builder.toString();
/*     */   }
/*     */   
/*     */   static class Flags
/*     */   {
/*     */     static final int GARBLED = 1;
/*     */     static final int OLD_SECURED_NEW_ANSI_PAGE = 2;
/*     */     static final int VOLUME = 4;
/*     */     static final int ARJPROT = 8;
/*     */     static final int PATHSYM = 16;
/*     */     static final int BACKUP = 32;
/*     */     static final int SECURED = 64;
/*     */     static final int ALTNAME = 128;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\arj\MainHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */