package org.apache.commons.compress.archivers;

import java.util.Date;

public abstract interface ArchiveEntry
{
  public static final long SIZE_UNKNOWN = -1L;
  
  public abstract String getName();
  
  public abstract long getSize();
  
  public abstract boolean isDirectory();
  
  public abstract Date getLastModifiedDate();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\ArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */