/*     */ package org.apache.commons.compress.archivers;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.compress.archivers.ar.ArArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.ar.ArArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.arj.ArjArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.dump.DumpArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.jar.JarArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.jar.JarArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.sevenz.SevenZFile;
/*     */ import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArchiveStreamFactory
/*     */ {
/*     */   public static final String AR = "ar";
/*     */   public static final String ARJ = "arj";
/*     */   public static final String CPIO = "cpio";
/*     */   public static final String DUMP = "dump";
/*     */   public static final String JAR = "jar";
/*     */   public static final String TAR = "tar";
/*     */   public static final String ZIP = "zip";
/*     */   public static final String SEVEN_Z = "7z";
/*     */   private final String encoding;
/* 130 */   private volatile String entryEncoding = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public ArchiveStreamFactory()
/*     */   {
/* 136 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveStreamFactory(String encoding)
/*     */   {
/* 148 */     this.encoding = encoding;
/*     */     
/* 150 */     this.entryEncoding = encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEntryEncoding()
/*     */   {
/* 161 */     return this.entryEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setEntryEncoding(String entryEncoding)
/*     */   {
/* 176 */     if (this.encoding != null) {
/* 177 */       throw new IllegalStateException("Cannot overide encoding set by the constructor");
/*     */     }
/* 179 */     this.entryEncoding = entryEncoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveInputStream createArchiveInputStream(String archiverName, InputStream in)
/*     */     throws ArchiveException
/*     */   {
/* 198 */     if (archiverName == null) {
/* 199 */       throw new IllegalArgumentException("Archivername must not be null.");
/*     */     }
/*     */     
/* 202 */     if (in == null) {
/* 203 */       throw new IllegalArgumentException("InputStream must not be null.");
/*     */     }
/*     */     
/* 206 */     if ("ar".equalsIgnoreCase(archiverName)) {
/* 207 */       return new ArArchiveInputStream(in);
/*     */     }
/* 209 */     if ("arj".equalsIgnoreCase(archiverName)) {
/* 210 */       if (this.entryEncoding != null) {
/* 211 */         return new ArjArchiveInputStream(in, this.entryEncoding);
/*     */       }
/* 213 */       return new ArjArchiveInputStream(in);
/*     */     }
/*     */     
/* 216 */     if ("zip".equalsIgnoreCase(archiverName)) {
/* 217 */       if (this.entryEncoding != null) {
/* 218 */         return new ZipArchiveInputStream(in, this.entryEncoding);
/*     */       }
/* 220 */       return new ZipArchiveInputStream(in);
/*     */     }
/*     */     
/* 223 */     if ("tar".equalsIgnoreCase(archiverName)) {
/* 224 */       if (this.entryEncoding != null) {
/* 225 */         return new TarArchiveInputStream(in, this.entryEncoding);
/*     */       }
/* 227 */       return new TarArchiveInputStream(in);
/*     */     }
/*     */     
/* 230 */     if ("jar".equalsIgnoreCase(archiverName)) {
/* 231 */       if (this.entryEncoding != null) {
/* 232 */         return new JarArchiveInputStream(in, this.entryEncoding);
/*     */       }
/* 234 */       return new JarArchiveInputStream(in);
/*     */     }
/*     */     
/* 237 */     if ("cpio".equalsIgnoreCase(archiverName)) {
/* 238 */       if (this.entryEncoding != null) {
/* 239 */         return new CpioArchiveInputStream(in, this.entryEncoding);
/*     */       }
/* 241 */       return new CpioArchiveInputStream(in);
/*     */     }
/*     */     
/* 244 */     if ("dump".equalsIgnoreCase(archiverName)) {
/* 245 */       if (this.entryEncoding != null) {
/* 246 */         return new DumpArchiveInputStream(in, this.entryEncoding);
/*     */       }
/* 248 */       return new DumpArchiveInputStream(in);
/*     */     }
/*     */     
/* 251 */     if ("7z".equalsIgnoreCase(archiverName)) {
/* 252 */       throw new StreamingNotSupportedException("7z");
/*     */     }
/*     */     
/* 255 */     throw new ArchiveException("Archiver: " + archiverName + " not found.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveOutputStream createArchiveOutputStream(String archiverName, OutputStream out)
/*     */     throws ArchiveException
/*     */   {
/* 273 */     if (archiverName == null) {
/* 274 */       throw new IllegalArgumentException("Archivername must not be null.");
/*     */     }
/* 276 */     if (out == null) {
/* 277 */       throw new IllegalArgumentException("OutputStream must not be null.");
/*     */     }
/*     */     
/* 280 */     if ("ar".equalsIgnoreCase(archiverName)) {
/* 281 */       return new ArArchiveOutputStream(out);
/*     */     }
/* 283 */     if ("zip".equalsIgnoreCase(archiverName)) {
/* 284 */       ZipArchiveOutputStream zip = new ZipArchiveOutputStream(out);
/* 285 */       if (this.entryEncoding != null) {
/* 286 */         zip.setEncoding(this.entryEncoding);
/*     */       }
/* 288 */       return zip;
/*     */     }
/* 290 */     if ("tar".equalsIgnoreCase(archiverName)) {
/* 291 */       if (this.entryEncoding != null) {
/* 292 */         return new TarArchiveOutputStream(out, this.entryEncoding);
/*     */       }
/* 294 */       return new TarArchiveOutputStream(out);
/*     */     }
/*     */     
/* 297 */     if ("jar".equalsIgnoreCase(archiverName)) {
/* 298 */       if (this.entryEncoding != null) {
/* 299 */         return new JarArchiveOutputStream(out, this.entryEncoding);
/*     */       }
/* 301 */       return new JarArchiveOutputStream(out);
/*     */     }
/*     */     
/* 304 */     if ("cpio".equalsIgnoreCase(archiverName)) {
/* 305 */       if (this.entryEncoding != null) {
/* 306 */         return new CpioArchiveOutputStream(out, this.entryEncoding);
/*     */       }
/* 308 */       return new CpioArchiveOutputStream(out);
/*     */     }
/*     */     
/* 311 */     if ("7z".equalsIgnoreCase(archiverName)) {
/* 312 */       throw new StreamingNotSupportedException("7z");
/*     */     }
/* 314 */     throw new ArchiveException("Archiver: " + archiverName + " not found.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveInputStream createArchiveInputStream(InputStream in)
/*     */     throws ArchiveException
/*     */   {
/* 331 */     if (in == null) {
/* 332 */       throw new IllegalArgumentException("Stream must not be null.");
/*     */     }
/*     */     
/* 335 */     if (!in.markSupported()) {
/* 336 */       throw new IllegalArgumentException("Mark is not supported.");
/*     */     }
/*     */     
/* 339 */     byte[] signature = new byte[12];
/* 340 */     in.mark(signature.length);
/*     */     try {
/* 342 */       int signatureLength = IOUtils.readFully(in, signature);
/* 343 */       in.reset();
/* 344 */       if (ZipArchiveInputStream.matches(signature, signatureLength)) {
/* 345 */         if (this.entryEncoding != null) {
/* 346 */           return new ZipArchiveInputStream(in, this.entryEncoding);
/*     */         }
/* 348 */         return new ZipArchiveInputStream(in);
/*     */       }
/* 350 */       if (JarArchiveInputStream.matches(signature, signatureLength)) {
/* 351 */         if (this.entryEncoding != null) {
/* 352 */           return new JarArchiveInputStream(in, this.entryEncoding);
/*     */         }
/* 354 */         return new JarArchiveInputStream(in);
/*     */       }
/* 356 */       if (ArArchiveInputStream.matches(signature, signatureLength))
/* 357 */         return new ArArchiveInputStream(in);
/* 358 */       if (CpioArchiveInputStream.matches(signature, signatureLength)) {
/* 359 */         if (this.entryEncoding != null) {
/* 360 */           return new CpioArchiveInputStream(in, this.entryEncoding);
/*     */         }
/* 362 */         return new CpioArchiveInputStream(in);
/*     */       }
/* 364 */       if (ArjArchiveInputStream.matches(signature, signatureLength)) {
/* 365 */         if (this.entryEncoding != null) {
/* 366 */           return new ArjArchiveInputStream(in, this.entryEncoding);
/*     */         }
/* 368 */         return new ArjArchiveInputStream(in);
/*     */       }
/* 370 */       if (SevenZFile.matches(signature, signatureLength)) {
/* 371 */         throw new StreamingNotSupportedException("7z");
/*     */       }
/*     */       
/*     */ 
/* 375 */       byte[] dumpsig = new byte[32];
/* 376 */       in.mark(dumpsig.length);
/* 377 */       signatureLength = IOUtils.readFully(in, dumpsig);
/* 378 */       in.reset();
/* 379 */       if (DumpArchiveInputStream.matches(dumpsig, signatureLength)) {
/* 380 */         return new DumpArchiveInputStream(in, this.entryEncoding);
/*     */       }
/*     */       
/*     */ 
/* 384 */       byte[] tarheader = new byte['Ȁ'];
/* 385 */       in.mark(tarheader.length);
/* 386 */       signatureLength = IOUtils.readFully(in, tarheader);
/* 387 */       in.reset();
/* 388 */       if (TarArchiveInputStream.matches(tarheader, signatureLength)) {
/* 389 */         return new TarArchiveInputStream(in, this.entryEncoding);
/*     */       }
/*     */       
/* 392 */       if (signatureLength >= 512) {
/* 393 */         TarArchiveInputStream tais = null;
/*     */         try {
/* 395 */           tais = new TarArchiveInputStream(new ByteArrayInputStream(tarheader));
/*     */           
/* 397 */           if (tais.getNextTarEntry().isCheckSumOK()) {
/* 398 */             return new TarArchiveInputStream(in, this.encoding);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         catch (Exception e) {}finally
/*     */         {
/*     */ 
/* 406 */           IOUtils.closeQuietly(tais);
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 410 */       throw new ArchiveException("Could not use reset and mark operations.", e);
/*     */     }
/*     */     
/* 413 */     throw new ArchiveException("No Archiver found for the stream signature");
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\ArchiveStreamFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */