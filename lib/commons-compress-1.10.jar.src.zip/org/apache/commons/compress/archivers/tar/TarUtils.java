/*     */ package org.apache.commons.compress.archivers.tar;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TarUtils
/*     */ {
/*     */   private static final int BYTE_MASK = 255;
/*  40 */   static final ZipEncoding DEFAULT_ENCODING = ZipEncodingHelper.getZipEncoding(null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */   static final ZipEncoding FALLBACK_ENCODING = new ZipEncoding() {
/*  48 */     public boolean canEncode(String name) { return true; }
/*     */     
/*     */     public ByteBuffer encode(String name) {
/*  51 */       int length = name.length();
/*  52 */       byte[] buf = new byte[length];
/*     */       
/*     */ 
/*  55 */       for (int i = 0; i < length; i++) {
/*  56 */         buf[i] = ((byte)name.charAt(i));
/*     */       }
/*  58 */       return ByteBuffer.wrap(buf);
/*     */     }
/*     */     
/*     */     public String decode(byte[] buffer) {
/*  62 */       int length = buffer.length;
/*  63 */       StringBuilder result = new StringBuilder(length);
/*     */       
/*  65 */       for (byte b : buffer) {
/*  66 */         if (b == 0) {
/*     */           break;
/*     */         }
/*  69 */         result.append((char)(b & 0xFF));
/*     */       }
/*     */       
/*  72 */       return result.toString();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long parseOctal(byte[] buffer, int offset, int length)
/*     */   {
/* 102 */     long result = 0L;
/* 103 */     int end = offset + length;
/* 104 */     int start = offset;
/*     */     
/* 106 */     if (length < 2) {
/* 107 */       throw new IllegalArgumentException("Length " + length + " must be at least 2");
/*     */     }
/*     */     
/* 110 */     if (buffer[start] == 0) {
/* 111 */       return 0L;
/*     */     }
/*     */     
/*     */ 
/* 115 */     while ((start < end) && 
/* 116 */       (buffer[start] == 32)) {
/* 117 */       start++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 127 */     byte trailer = buffer[(end - 1)];
/* 128 */     while ((start < end) && ((trailer == 0) || (trailer == 32))) {
/* 129 */       end--;
/* 130 */       trailer = buffer[(end - 1)];
/*     */     }
/* 133 */     for (; 
/* 133 */         start < end; start++) {
/* 134 */       byte currentByte = buffer[start];
/*     */       
/* 136 */       if ((currentByte < 48) || (currentByte > 55)) {
/* 137 */         throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, start, currentByte));
/*     */       }
/*     */       
/* 140 */       result = (result << 3) + (currentByte - 48);
/*     */     }
/*     */     
/*     */ 
/* 144 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long parseOctalOrBinary(byte[] buffer, int offset, int length)
/*     */   {
/* 167 */     if ((buffer[offset] & 0x80) == 0) {
/* 168 */       return parseOctal(buffer, offset, length);
/*     */     }
/* 170 */     boolean negative = buffer[offset] == -1;
/* 171 */     if (length < 9) {
/* 172 */       return parseBinaryLong(buffer, offset, length, negative);
/*     */     }
/* 174 */     return parseBinaryBigInteger(buffer, offset, length, negative);
/*     */   }
/*     */   
/*     */ 
/*     */   private static long parseBinaryLong(byte[] buffer, int offset, int length, boolean negative)
/*     */   {
/* 180 */     if (length >= 9) {
/* 181 */       throw new IllegalArgumentException("At offset " + offset + ", " + length + " byte binary number" + " exceeds maximum signed long" + " value");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 186 */     long val = 0L;
/* 187 */     for (int i = 1; i < length; i++) {
/* 188 */       val = (val << 8) + (buffer[(offset + i)] & 0xFF);
/*     */     }
/* 190 */     if (negative)
/*     */     {
/* 192 */       val -= 1L;
/* 193 */       val ^= Math.pow(2.0D, (length - 1) * 8) - 1L;
/*     */     }
/* 195 */     return negative ? -val : val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static long parseBinaryBigInteger(byte[] buffer, int offset, int length, boolean negative)
/*     */   {
/* 202 */     byte[] remainder = new byte[length - 1];
/* 203 */     System.arraycopy(buffer, offset + 1, remainder, 0, length - 1);
/* 204 */     BigInteger val = new BigInteger(remainder);
/* 205 */     if (negative)
/*     */     {
/* 207 */       val = val.add(BigInteger.valueOf(-1L)).not();
/*     */     }
/* 209 */     if (val.bitLength() > 63) {
/* 210 */       throw new IllegalArgumentException("At offset " + offset + ", " + length + " byte binary number" + " exceeds maximum signed long" + " value");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 215 */     return negative ? -val.longValue() : val.longValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean parseBoolean(byte[] buffer, int offset)
/*     */   {
/* 229 */     return buffer[offset] == 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String exceptionMessage(byte[] buffer, int offset, int length, int current, byte currentByte)
/*     */   {
/* 242 */     String string = new String(buffer, offset, length);
/*     */     
/* 244 */     string = string.replaceAll("\000", "{NUL}");
/* 245 */     String s = "Invalid byte " + currentByte + " at offset " + (current - offset) + " in '" + string + "' len=" + length;
/* 246 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String parseName(byte[] buffer, int offset, int length)
/*     */   {
/*     */     try
/*     */     {
/* 261 */       return parseName(buffer, offset, length, DEFAULT_ENCODING);
/*     */     } catch (IOException ex) {
/*     */       try {
/* 264 */         return parseName(buffer, offset, length, FALLBACK_ENCODING);
/*     */       }
/*     */       catch (IOException ex2) {
/* 267 */         throw new RuntimeException(ex2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String parseName(byte[] buffer, int offset, int length, ZipEncoding encoding)
/*     */     throws IOException
/*     */   {
/* 290 */     for (int len = length; 
/* 291 */         len > 0; len--) {
/* 292 */       if (buffer[(offset + len - 1)] != 0) {
/*     */         break;
/*     */       }
/*     */     }
/* 296 */     if (len > 0) {
/* 297 */       byte[] b = new byte[len];
/* 298 */       System.arraycopy(buffer, offset, b, 0, len);
/* 299 */       return encoding.decode(b);
/*     */     }
/* 301 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int formatNameBytes(String name, byte[] buf, int offset, int length)
/*     */   {
/*     */     try
/*     */     {
/* 321 */       return formatNameBytes(name, buf, offset, length, DEFAULT_ENCODING);
/*     */     } catch (IOException ex) {
/*     */       try {
/* 324 */         return formatNameBytes(name, buf, offset, length, FALLBACK_ENCODING);
/*     */       }
/*     */       catch (IOException ex2)
/*     */       {
/* 328 */         throw new RuntimeException(ex2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int formatNameBytes(String name, byte[] buf, int offset, int length, ZipEncoding encoding)
/*     */     throws IOException
/*     */   {
/* 355 */     int len = name.length();
/* 356 */     ByteBuffer b = encoding.encode(name);
/* 357 */     while ((b.limit() > length) && (len > 0)) {
/* 358 */       b = encoding.encode(name.substring(0, --len));
/*     */     }
/* 360 */     int limit = b.limit() - b.position();
/* 361 */     System.arraycopy(b.array(), b.arrayOffset(), buf, offset, limit);
/*     */     
/*     */ 
/* 364 */     for (int i = limit; i < length; i++) {
/* 365 */       buf[(offset + i)] = 0;
/*     */     }
/*     */     
/* 368 */     return offset + length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void formatUnsignedOctalString(long value, byte[] buffer, int offset, int length)
/*     */   {
/* 382 */     int remaining = length;
/* 383 */     remaining--;
/* 384 */     if (value == 0L) {
/* 385 */       buffer[(offset + remaining--)] = 48;
/*     */     } else {
/* 387 */       long val = value;
/* 388 */       for (; (remaining >= 0) && (val != 0L); remaining--)
/*     */       {
/* 390 */         buffer[(offset + remaining)] = ((byte)(48 + (byte)(int)(val & 0x7)));
/* 391 */         val >>>= 3;
/*     */       }
/*     */       
/* 394 */       if (val != 0L) {
/* 395 */         throw new IllegalArgumentException(value + "=" + Long.toOctalString(value) + " will not fit in octal number buffer of length " + length);
/*     */       }
/*     */     }
/* 400 */     for (; 
/*     */         
/* 400 */         remaining >= 0; remaining--) {
/* 401 */       buffer[(offset + remaining)] = 48;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int formatOctalBytes(long value, byte[] buf, int offset, int length)
/*     */   {
/* 421 */     int idx = length - 2;
/* 422 */     formatUnsignedOctalString(value, buf, offset, idx);
/*     */     
/* 424 */     buf[(offset + idx++)] = 32;
/* 425 */     buf[(offset + idx)] = 0;
/*     */     
/* 427 */     return offset + length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int formatLongOctalBytes(long value, byte[] buf, int offset, int length)
/*     */   {
/* 446 */     int idx = length - 1;
/*     */     
/* 448 */     formatUnsignedOctalString(value, buf, offset, idx);
/* 449 */     buf[(offset + idx)] = 32;
/*     */     
/* 451 */     return offset + length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int formatLongOctalOrBinaryBytes(long value, byte[] buf, int offset, int length)
/*     */   {
/* 475 */     long maxAsOctalChar = length == 8 ? 2097151L : 8589934591L;
/*     */     
/* 477 */     boolean negative = value < 0L;
/* 478 */     if ((!negative) && (value <= maxAsOctalChar)) {
/* 479 */       return formatLongOctalBytes(value, buf, offset, length);
/*     */     }
/*     */     
/* 482 */     if (length < 9) {
/* 483 */       formatLongBinary(value, buf, offset, length, negative);
/*     */     }
/* 485 */     formatBigIntegerBinary(value, buf, offset, length, negative);
/*     */     
/* 487 */     buf[offset] = ((byte)(negative ? 'ÿ' : ''));
/* 488 */     return offset + length;
/*     */   }
/*     */   
/*     */ 
/*     */   private static void formatLongBinary(long value, byte[] buf, int offset, int length, boolean negative)
/*     */   {
/* 494 */     int bits = (length - 1) * 8;
/* 495 */     long max = 1L << bits;
/* 496 */     long val = Math.abs(value);
/* 497 */     if (val >= max) {
/* 498 */       throw new IllegalArgumentException("Value " + value + " is too large for " + length + " byte field.");
/*     */     }
/*     */     
/* 501 */     if (negative) {
/* 502 */       val ^= max - 1L;
/* 503 */       val |= 255 << bits;
/* 504 */       val += 1L;
/*     */     }
/* 506 */     for (int i = offset + length - 1; i >= offset; i--) {
/* 507 */       buf[i] = ((byte)(int)val);
/* 508 */       val >>= 8;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static void formatBigIntegerBinary(long value, byte[] buf, int offset, int length, boolean negative)
/*     */   {
/* 516 */     BigInteger val = BigInteger.valueOf(value);
/* 517 */     byte[] b = val.toByteArray();
/* 518 */     int len = b.length;
/* 519 */     int off = offset + length - len;
/* 520 */     System.arraycopy(b, 0, buf, off, len);
/* 521 */     byte fill = (byte)(negative ? 255 : 0);
/* 522 */     for (int i = offset + 1; i < off; i++) {
/* 523 */       buf[i] = fill;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int formatCheckSumOctalBytes(long value, byte[] buf, int offset, int length)
/*     */   {
/* 543 */     int idx = length - 2;
/* 544 */     formatUnsignedOctalString(value, buf, offset, idx);
/*     */     
/* 546 */     buf[(offset + idx++)] = 0;
/* 547 */     buf[(offset + idx)] = 32;
/*     */     
/* 549 */     return offset + length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long computeCheckSum(byte[] buf)
/*     */   {
/* 559 */     long sum = 0L;
/*     */     
/* 561 */     for (byte element : buf) {
/* 562 */       sum += (0xFF & element);
/*     */     }
/*     */     
/* 565 */     return sum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean verifyCheckSum(byte[] header)
/*     */   {
/* 604 */     long storedSum = 0L;
/* 605 */     long unsignedSum = 0L;
/* 606 */     long signedSum = 0L;
/*     */     
/* 608 */     int digits = 0;
/* 609 */     for (int i = 0; i < header.length; i++) {
/* 610 */       byte b = header[i];
/* 611 */       if ((148 <= i) && (i < 156)) {
/* 612 */         if ((48 <= b) && (b <= 55) && (digits++ < 6)) {
/* 613 */           storedSum = storedSum * 8L + b - 48L;
/* 614 */         } else if (digits > 0) {
/* 615 */           digits = 6;
/*     */         }
/* 617 */         b = 32;
/*     */       }
/* 619 */       unsignedSum += (0xFF & b);
/* 620 */       signedSum += b;
/*     */     }
/*     */     
/* 623 */     return (storedSum == unsignedSum) || (storedSum == signedSum) || (storedSum > unsignedSum);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\tar\TarUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */