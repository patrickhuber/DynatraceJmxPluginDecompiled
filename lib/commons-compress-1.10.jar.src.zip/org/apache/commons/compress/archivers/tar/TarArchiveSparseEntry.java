/*    */ package org.apache.commons.compress.archivers.tar;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TarArchiveSparseEntry
/*    */   implements TarConstants
/*    */ {
/*    */   private final boolean isExtended;
/*    */   
/*    */   public TarArchiveSparseEntry(byte[] headerBuf)
/*    */     throws IOException
/*    */   {
/* 55 */     int offset = 0;
/* 56 */     offset += 504;
/* 57 */     this.isExtended = TarUtils.parseBoolean(headerBuf, offset);
/*    */   }
/*    */   
/*    */   public boolean isExtended() {
/* 61 */     return this.isExtended;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\tar\TarArchiveSparseEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */