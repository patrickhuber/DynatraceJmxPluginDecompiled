/*     */ package org.apache.commons.compress.archivers.tar;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
/*     */ import org.apache.commons.compress.utils.ArchiveUtils;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TarArchiveInputStream
/*     */   extends ArchiveInputStream
/*     */ {
/*     */   private static final int SMALL_BUFFER_SIZE = 256;
/*  52 */   private final byte[] SMALL_BUF = new byte['Ā'];
/*     */   
/*     */ 
/*     */ 
/*     */   private final int recordSize;
/*     */   
/*     */ 
/*     */   private final int blockSize;
/*     */   
/*     */ 
/*     */   private boolean hasHitEOF;
/*     */   
/*     */ 
/*     */   private long entrySize;
/*     */   
/*     */ 
/*     */   private long entryOffset;
/*     */   
/*     */ 
/*     */   private final InputStream is;
/*     */   
/*     */ 
/*     */   private TarArchiveEntry currEntry;
/*     */   
/*     */ 
/*     */   private final ZipEncoding zipEncoding;
/*     */   
/*     */ 
/*     */   final String encoding;
/*     */   
/*     */ 
/*     */ 
/*     */   public TarArchiveInputStream(InputStream is)
/*     */   {
/*  86 */     this(is, 10240, 512);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveInputStream(InputStream is, String encoding)
/*     */   {
/*  96 */     this(is, 10240, 512, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveInputStream(InputStream is, int blockSize)
/*     */   {
/* 106 */     this(is, blockSize, 512);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveInputStream(InputStream is, int blockSize, String encoding)
/*     */   {
/* 118 */     this(is, blockSize, 512, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveInputStream(InputStream is, int blockSize, int recordSize)
/*     */   {
/* 128 */     this(is, blockSize, recordSize, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveInputStream(InputStream is, int blockSize, int recordSize, String encoding)
/*     */   {
/* 141 */     this.is = is;
/* 142 */     this.hasHitEOF = false;
/* 143 */     this.encoding = encoding;
/* 144 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/* 145 */     this.recordSize = recordSize;
/* 146 */     this.blockSize = blockSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 155 */     this.is.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordSize()
/*     */   {
/* 164 */     return this.recordSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 181 */     if (this.entrySize - this.entryOffset > 2147483647L) {
/* 182 */       return Integer.MAX_VALUE;
/*     */     }
/* 184 */     return (int)(this.entrySize - this.entryOffset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 206 */     if (n <= 0L) {
/* 207 */       return 0L;
/*     */     }
/*     */     
/* 210 */     long available = this.entrySize - this.entryOffset;
/* 211 */     long skipped = this.is.skip(Math.min(n, available));
/* 212 */     count(skipped);
/* 213 */     this.entryOffset += skipped;
/* 214 */     return skipped;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 224 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mark(int markLimit) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void reset() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveEntry getNextTarEntry()
/*     */     throws IOException
/*     */   {
/* 257 */     if (this.hasHitEOF) {
/* 258 */       return null;
/*     */     }
/*     */     
/* 261 */     if (this.currEntry != null)
/*     */     {
/* 263 */       IOUtils.skip(this, Long.MAX_VALUE);
/*     */       
/*     */ 
/* 266 */       skipRecordPadding();
/*     */     }
/*     */     
/* 269 */     byte[] headerBuf = getRecord();
/*     */     
/* 271 */     if (headerBuf == null)
/*     */     {
/* 273 */       this.currEntry = null;
/* 274 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 278 */       this.currEntry = new TarArchiveEntry(headerBuf, this.zipEncoding);
/*     */     } catch (IllegalArgumentException e) {
/* 280 */       IOException ioe = new IOException("Error detected parsing the header");
/* 281 */       ioe.initCause(e);
/* 282 */       throw ioe;
/*     */     }
/*     */     
/* 285 */     this.entryOffset = 0L;
/* 286 */     this.entrySize = this.currEntry.getSize();
/*     */     
/* 288 */     if (this.currEntry.isGNULongLinkEntry()) {
/* 289 */       byte[] longLinkData = getLongNameData();
/* 290 */       if (longLinkData == null)
/*     */       {
/*     */ 
/*     */ 
/* 294 */         return null;
/*     */       }
/* 296 */       this.currEntry.setLinkName(this.zipEncoding.decode(longLinkData));
/*     */     }
/*     */     
/* 299 */     if (this.currEntry.isGNULongNameEntry()) {
/* 300 */       byte[] longNameData = getLongNameData();
/* 301 */       if (longNameData == null)
/*     */       {
/*     */ 
/*     */ 
/* 305 */         return null;
/*     */       }
/* 307 */       this.currEntry.setName(this.zipEncoding.decode(longNameData));
/*     */     }
/*     */     
/* 310 */     if (this.currEntry.isPaxHeader()) {
/* 311 */       paxHeaders();
/*     */     }
/*     */     
/* 314 */     if (this.currEntry.isGNUSparse()) {
/* 315 */       readGNUSparse();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 322 */     this.entrySize = this.currEntry.getSize();
/*     */     
/* 324 */     return this.currEntry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void skipRecordPadding()
/*     */     throws IOException
/*     */   {
/* 332 */     if ((this.entrySize > 0L) && (this.entrySize % this.recordSize != 0L)) {
/* 333 */       long numRecords = this.entrySize / this.recordSize + 1L;
/* 334 */       long padding = numRecords * this.recordSize - this.entrySize;
/* 335 */       long skipped = IOUtils.skip(this.is, padding);
/* 336 */       count(skipped);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] getLongNameData()
/*     */     throws IOException
/*     */   {
/* 348 */     ByteArrayOutputStream longName = new ByteArrayOutputStream();
/* 349 */     int length = 0;
/* 350 */     while ((length = read(this.SMALL_BUF)) >= 0) {
/* 351 */       longName.write(this.SMALL_BUF, 0, length);
/*     */     }
/* 353 */     getNextEntry();
/* 354 */     if (this.currEntry == null)
/*     */     {
/*     */ 
/* 357 */       return null;
/*     */     }
/* 359 */     byte[] longNameData = longName.toByteArray();
/*     */     
/* 361 */     length = longNameData.length;
/* 362 */     while ((length > 0) && (longNameData[(length - 1)] == 0)) {
/* 363 */       length--;
/*     */     }
/* 365 */     if (length != longNameData.length) {
/* 366 */       byte[] l = new byte[length];
/* 367 */       System.arraycopy(longNameData, 0, l, 0, length);
/* 368 */       longNameData = l;
/*     */     }
/* 370 */     return longNameData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] getRecord()
/*     */     throws IOException
/*     */   {
/* 388 */     byte[] headerBuf = readRecord();
/* 389 */     this.hasHitEOF = isEOFRecord(headerBuf);
/* 390 */     if ((this.hasHitEOF) && (headerBuf != null)) {
/* 391 */       tryToConsumeSecondEOFRecord();
/* 392 */       consumeRemainderOfLastBlock();
/* 393 */       headerBuf = null;
/*     */     }
/* 395 */     return headerBuf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isEOFRecord(byte[] record)
/*     */   {
/* 406 */     return (record == null) || (ArchiveUtils.isArrayZero(record, this.recordSize));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected byte[] readRecord()
/*     */     throws IOException
/*     */   {
/* 417 */     byte[] record = new byte[this.recordSize];
/*     */     
/* 419 */     int readNow = IOUtils.readFully(this.is, record);
/* 420 */     count(readNow);
/* 421 */     if (readNow != this.recordSize) {
/* 422 */       return null;
/*     */     }
/*     */     
/* 425 */     return record;
/*     */   }
/*     */   
/*     */   private void paxHeaders() throws IOException {
/* 429 */     Map<String, String> headers = parsePaxHeaders(this);
/* 430 */     getNextEntry();
/* 431 */     applyPaxHeadersToCurrentEntry(headers);
/*     */   }
/*     */   
/*     */   Map<String, String> parsePaxHeaders(InputStream i) throws IOException {
/* 435 */     Map<String, String> headers = new HashMap();
/*     */     
/*     */     for (;;)
/*     */     {
/* 439 */       int len = 0;
/* 440 */       int read = 0;
/* 441 */       int ch; while ((ch = i.read()) != -1) {
/* 442 */         read++;
/* 443 */         if (ch == 32)
/*     */         {
/* 445 */           ByteArrayOutputStream coll = new ByteArrayOutputStream();
/* 446 */           while ((ch = i.read()) != -1) {
/* 447 */             read++;
/* 448 */             if (ch == 61) {
/* 449 */               String keyword = coll.toString("UTF-8");
/*     */               
/* 451 */               int restLen = len - read;
/* 452 */               byte[] rest = new byte[restLen];
/* 453 */               int got = IOUtils.readFully(i, rest);
/* 454 */               if (got != restLen) {
/* 455 */                 throw new IOException("Failed to read Paxheader. Expected " + restLen + " bytes, read " + got);
/*     */               }
/*     */               
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 462 */               String value = new String(rest, 0, restLen - 1, "UTF-8");
/*     */               
/* 464 */               headers.put(keyword, value);
/* 465 */               break;
/*     */             }
/* 467 */             coll.write((byte)ch);
/*     */           }
/*     */         }
/*     */         
/* 471 */         len *= 10;
/* 472 */         len += ch - 48;
/*     */       }
/* 474 */       if (ch == -1) {
/*     */         break;
/*     */       }
/*     */     }
/* 478 */     return headers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void applyPaxHeadersToCurrentEntry(Map<String, String> headers)
/*     */   {
/* 493 */     for (Map.Entry<String, String> ent : headers.entrySet()) {
/* 494 */       String key = (String)ent.getKey();
/* 495 */       String val = (String)ent.getValue();
/* 496 */       if ("path".equals(key)) {
/* 497 */         this.currEntry.setName(val);
/* 498 */       } else if ("linkpath".equals(key)) {
/* 499 */         this.currEntry.setLinkName(val);
/* 500 */       } else if ("gid".equals(key)) {
/* 501 */         this.currEntry.setGroupId(Long.parseLong(val));
/* 502 */       } else if ("gname".equals(key)) {
/* 503 */         this.currEntry.setGroupName(val);
/* 504 */       } else if ("uid".equals(key)) {
/* 505 */         this.currEntry.setUserId(Long.parseLong(val));
/* 506 */       } else if ("uname".equals(key)) {
/* 507 */         this.currEntry.setUserName(val);
/* 508 */       } else if ("size".equals(key)) {
/* 509 */         this.currEntry.setSize(Long.parseLong(val));
/* 510 */       } else if ("mtime".equals(key)) {
/* 511 */         this.currEntry.setModTime((Double.parseDouble(val) * 1000.0D));
/* 512 */       } else if ("SCHILY.devminor".equals(key)) {
/* 513 */         this.currEntry.setDevMinor(Integer.parseInt(val));
/* 514 */       } else if ("SCHILY.devmajor".equals(key)) {
/* 515 */         this.currEntry.setDevMajor(Integer.parseInt(val));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readGNUSparse()
/*     */     throws IOException
/*     */   {
/* 533 */     if (this.currEntry.isExtended()) {
/*     */       TarArchiveSparseEntry entry;
/*     */       do {
/* 536 */         byte[] headerBuf = getRecord();
/* 537 */         if (headerBuf == null) {
/* 538 */           this.currEntry = null;
/* 539 */           break;
/*     */         }
/* 541 */         entry = new TarArchiveSparseEntry(headerBuf);
/*     */ 
/*     */ 
/*     */       }
/* 545 */       while (entry.isExtended());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveEntry getNextEntry()
/*     */     throws IOException
/*     */   {
/* 558 */     return getNextTarEntry();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void tryToConsumeSecondEOFRecord()
/*     */     throws IOException
/*     */   {
/* 572 */     boolean shouldReset = true;
/* 573 */     boolean marked = this.is.markSupported();
/* 574 */     if (marked) {
/* 575 */       this.is.mark(this.recordSize);
/*     */     }
/*     */     try {
/* 578 */       shouldReset = !isEOFRecord(readRecord());
/*     */     } finally {
/* 580 */       if ((shouldReset) && (marked)) {
/* 581 */         pushedBackBytes(this.recordSize);
/* 582 */         this.is.reset();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] buf, int offset, int numToRead)
/*     */     throws IOException
/*     */   {
/* 602 */     int totalRead = 0;
/*     */     
/* 604 */     if ((this.hasHitEOF) || (this.entryOffset >= this.entrySize)) {
/* 605 */       return -1;
/*     */     }
/*     */     
/* 608 */     if (this.currEntry == null) {
/* 609 */       throw new IllegalStateException("No current tar entry");
/*     */     }
/*     */     
/* 612 */     numToRead = Math.min(numToRead, available());
/*     */     
/* 614 */     totalRead = this.is.read(buf, offset, numToRead);
/*     */     
/* 616 */     if (totalRead == -1) {
/* 617 */       if (numToRead > 0) {
/* 618 */         throw new IOException("Truncated TAR archive");
/*     */       }
/* 620 */       this.hasHitEOF = true;
/*     */     } else {
/* 622 */       count(totalRead);
/* 623 */       this.entryOffset += totalRead;
/*     */     }
/*     */     
/* 626 */     return totalRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean canReadEntryData(ArchiveEntry ae)
/*     */   {
/* 636 */     if ((ae instanceof TarArchiveEntry)) {
/* 637 */       TarArchiveEntry te = (TarArchiveEntry)ae;
/* 638 */       return !te.isGNUSparse();
/*     */     }
/* 640 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveEntry getCurrentEntry()
/*     */   {
/* 649 */     return this.currEntry;
/*     */   }
/*     */   
/*     */   protected final void setCurrentEntry(TarArchiveEntry e) {
/* 653 */     this.currEntry = e;
/*     */   }
/*     */   
/*     */   protected final boolean isAtEOF() {
/* 657 */     return this.hasHitEOF;
/*     */   }
/*     */   
/*     */   protected final void setAtEOF(boolean b) {
/* 661 */     this.hasHitEOF = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void consumeRemainderOfLastBlock()
/*     */     throws IOException
/*     */   {
/* 670 */     long bytesReadOfLastBlock = getBytesRead() % this.blockSize;
/* 671 */     if (bytesReadOfLastBlock > 0L) {
/* 672 */       long skipped = IOUtils.skip(this.is, this.blockSize - bytesReadOfLastBlock);
/* 673 */       count(skipped);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 687 */     if (length < 265) {
/* 688 */       return false;
/*     */     }
/*     */     
/* 691 */     if ((ArchiveUtils.matchAsciiBuffer("ustar\000", signature, 257, 6)) && (ArchiveUtils.matchAsciiBuffer("00", signature, 263, 2)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 697 */       return true;
/*     */     }
/* 699 */     if ((ArchiveUtils.matchAsciiBuffer("ustar ", signature, 257, 6)) && ((ArchiveUtils.matchAsciiBuffer(" \000", signature, 263, 2)) || (ArchiveUtils.matchAsciiBuffer("0\000", signature, 263, 2))))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 710 */       return true;
/*     */     }
/*     */     
/* 713 */     if ((ArchiveUtils.matchAsciiBuffer("ustar\000", signature, 257, 6)) && (ArchiveUtils.matchAsciiBuffer("\000\000", signature, 263, 2)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 719 */       return true;
/*     */     }
/* 721 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\tar\TarArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */