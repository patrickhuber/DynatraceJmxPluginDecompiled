/*     */ package org.apache.commons.compress.archivers.tar;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringWriter;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
/*     */ import org.apache.commons.compress.utils.CountingOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TarArchiveOutputStream
/*     */   extends ArchiveOutputStream
/*     */ {
/*     */   public static final int LONGFILE_ERROR = 0;
/*     */   public static final int LONGFILE_TRUNCATE = 1;
/*     */   public static final int LONGFILE_GNU = 2;
/*     */   public static final int LONGFILE_POSIX = 3;
/*     */   public static final int BIGNUMBER_ERROR = 0;
/*     */   public static final int BIGNUMBER_STAR = 1;
/*     */   public static final int BIGNUMBER_POSIX = 2;
/*     */   private long currSize;
/*     */   private String currName;
/*     */   private long currBytes;
/*     */   private final byte[] recordBuf;
/*     */   private int assemLen;
/*     */   private final byte[] assemBuf;
/*  71 */   private int longFileMode = 0;
/*  72 */   private int bigNumberMode = 0;
/*     */   
/*     */   private int recordsWritten;
/*     */   private final int recordsPerBlock;
/*     */   private final int recordSize;
/*  77 */   private boolean closed = false;
/*     */   
/*     */ 
/*  80 */   private boolean haveUnclosedEntry = false;
/*     */   
/*     */ 
/*  83 */   private boolean finished = false;
/*     */   
/*     */ 
/*     */   private final OutputStream out;
/*     */   
/*     */   private final ZipEncoding zipEncoding;
/*     */   
/*     */   final String encoding;
/*     */   
/*  92 */   private boolean addPaxHeadersForNonAsciiNames = false;
/*  93 */   private static final ZipEncoding ASCII = ZipEncodingHelper.getZipEncoding("ASCII");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveOutputStream(OutputStream os)
/*     */   {
/* 101 */     this(os, 10240, 512);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveOutputStream(OutputStream os, String encoding)
/*     */   {
/* 111 */     this(os, 10240, 512, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveOutputStream(OutputStream os, int blockSize)
/*     */   {
/* 120 */     this(os, blockSize, 512);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveOutputStream(OutputStream os, int blockSize, String encoding)
/*     */   {
/* 132 */     this(os, blockSize, 512, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveOutputStream(OutputStream os, int blockSize, int recordSize)
/*     */   {
/* 142 */     this(os, blockSize, recordSize, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TarArchiveOutputStream(OutputStream os, int blockSize, int recordSize, String encoding)
/*     */   {
/* 155 */     this.out = new CountingOutputStream(os);
/* 156 */     this.encoding = encoding;
/* 157 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*     */     
/* 159 */     this.assemLen = 0;
/* 160 */     this.assemBuf = new byte[recordSize];
/* 161 */     this.recordBuf = new byte[recordSize];
/* 162 */     this.recordSize = recordSize;
/* 163 */     this.recordsPerBlock = (blockSize / recordSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLongFileMode(int longFileMode)
/*     */   {
/* 174 */     this.longFileMode = longFileMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBigNumberMode(int bigNumberMode)
/*     */   {
/* 186 */     this.bigNumberMode = bigNumberMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddPaxHeadersForNonAsciiNames(boolean b)
/*     */   {
/* 195 */     this.addPaxHeadersForNonAsciiNames = b;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public int getCount()
/*     */   {
/* 201 */     return (int)getBytesWritten();
/*     */   }
/*     */   
/*     */   public long getBytesWritten()
/*     */   {
/* 206 */     return ((CountingOutputStream)this.out).getBytesWritten();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finish()
/*     */     throws IOException
/*     */   {
/* 220 */     if (this.finished) {
/* 221 */       throw new IOException("This archive has already been finished");
/*     */     }
/*     */     
/* 224 */     if (this.haveUnclosedEntry) {
/* 225 */       throw new IOException("This archives contains unclosed entries.");
/*     */     }
/* 227 */     writeEOFRecord();
/* 228 */     writeEOFRecord();
/* 229 */     padAsNeeded();
/* 230 */     this.out.flush();
/* 231 */     this.finished = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 240 */     if (!this.finished) {
/* 241 */       finish();
/*     */     }
/*     */     
/* 244 */     if (!this.closed) {
/* 245 */       this.out.close();
/* 246 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordSize()
/*     */   {
/* 256 */     return this.recordSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putArchiveEntry(ArchiveEntry archiveEntry)
/*     */     throws IOException
/*     */   {
/* 274 */     if (this.finished) {
/* 275 */       throw new IOException("Stream has already been finished");
/*     */     }
/* 277 */     TarArchiveEntry entry = (TarArchiveEntry)archiveEntry;
/* 278 */     Map<String, String> paxHeaders = new HashMap();
/* 279 */     String entryName = entry.getName();
/* 280 */     boolean paxHeaderContainsPath = handleLongName(entry, entryName, paxHeaders, "path", (byte)76, "file name");
/*     */     
/*     */ 
/* 283 */     String linkName = entry.getLinkName();
/* 284 */     boolean paxHeaderContainsLinkPath = (linkName != null) && (linkName.length() > 0) && (handleLongName(entry, linkName, paxHeaders, "linkpath", (byte)75, "link name"));
/*     */     
/*     */ 
/*     */ 
/* 288 */     if (this.bigNumberMode == 2) {
/* 289 */       addPaxHeadersForBigNumbers(paxHeaders, entry);
/* 290 */     } else if (this.bigNumberMode != 1) {
/* 291 */       failForBigNumbers(entry);
/*     */     }
/*     */     
/* 294 */     if ((this.addPaxHeadersForNonAsciiNames) && (!paxHeaderContainsPath) && (!ASCII.canEncode(entryName)))
/*     */     {
/* 296 */       paxHeaders.put("path", entryName);
/*     */     }
/*     */     
/* 299 */     if ((this.addPaxHeadersForNonAsciiNames) && (!paxHeaderContainsLinkPath) && ((entry.isLink()) || (entry.isSymbolicLink())) && (!ASCII.canEncode(linkName)))
/*     */     {
/*     */ 
/* 302 */       paxHeaders.put("linkpath", linkName);
/*     */     }
/*     */     
/* 305 */     if (paxHeaders.size() > 0) {
/* 306 */       writePaxHeaders(entry, entryName, paxHeaders);
/*     */     }
/*     */     
/* 309 */     entry.writeEntryHeader(this.recordBuf, this.zipEncoding, this.bigNumberMode == 1);
/*     */     
/* 311 */     writeRecord(this.recordBuf);
/*     */     
/* 313 */     this.currBytes = 0L;
/*     */     
/* 315 */     if (entry.isDirectory()) {
/* 316 */       this.currSize = 0L;
/*     */     } else {
/* 318 */       this.currSize = entry.getSize();
/*     */     }
/* 320 */     this.currName = entryName;
/* 321 */     this.haveUnclosedEntry = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeArchiveEntry()
/*     */     throws IOException
/*     */   {
/* 336 */     if (this.finished) {
/* 337 */       throw new IOException("Stream has already been finished");
/*     */     }
/* 339 */     if (!this.haveUnclosedEntry) {
/* 340 */       throw new IOException("No current entry to close");
/*     */     }
/* 342 */     if (this.assemLen > 0) {
/* 343 */       for (int i = this.assemLen; i < this.assemBuf.length; i++) {
/* 344 */         this.assemBuf[i] = 0;
/*     */       }
/*     */       
/* 347 */       writeRecord(this.assemBuf);
/*     */       
/* 349 */       this.currBytes += this.assemLen;
/* 350 */       this.assemLen = 0;
/*     */     }
/*     */     
/* 353 */     if (this.currBytes < this.currSize) {
/* 354 */       throw new IOException("entry '" + this.currName + "' closed at '" + this.currBytes + "' before the '" + this.currSize + "' bytes specified in the header were written");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 359 */     this.haveUnclosedEntry = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] wBuf, int wOffset, int numToWrite)
/*     */     throws IOException
/*     */   {
/* 378 */     if (!this.haveUnclosedEntry) {
/* 379 */       throw new IllegalStateException("No current tar entry");
/*     */     }
/* 381 */     if (this.currBytes + numToWrite > this.currSize) {
/* 382 */       throw new IOException("request to write '" + numToWrite + "' bytes exceeds size in header of '" + this.currSize + "' bytes for entry '" + this.currName + "'");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */     if (this.assemLen > 0) {
/* 397 */       if (this.assemLen + numToWrite >= this.recordBuf.length) {
/* 398 */         int aLen = this.recordBuf.length - this.assemLen;
/*     */         
/* 400 */         System.arraycopy(this.assemBuf, 0, this.recordBuf, 0, this.assemLen);
/*     */         
/* 402 */         System.arraycopy(wBuf, wOffset, this.recordBuf, this.assemLen, aLen);
/*     */         
/* 404 */         writeRecord(this.recordBuf);
/*     */         
/* 406 */         this.currBytes += this.recordBuf.length;
/* 407 */         wOffset += aLen;
/* 408 */         numToWrite -= aLen;
/* 409 */         this.assemLen = 0;
/*     */       } else {
/* 411 */         System.arraycopy(wBuf, wOffset, this.assemBuf, this.assemLen, numToWrite);
/*     */         
/*     */ 
/* 414 */         wOffset += numToWrite;
/* 415 */         this.assemLen += numToWrite;
/* 416 */         numToWrite = 0;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 425 */     while (numToWrite > 0) {
/* 426 */       if (numToWrite < this.recordBuf.length) {
/* 427 */         System.arraycopy(wBuf, wOffset, this.assemBuf, this.assemLen, numToWrite);
/*     */         
/*     */ 
/* 430 */         this.assemLen += numToWrite;
/*     */         
/* 432 */         break;
/*     */       }
/*     */       
/* 435 */       writeRecord(wBuf, wOffset);
/*     */       
/* 437 */       int num = this.recordBuf.length;
/*     */       
/* 439 */       this.currBytes += num;
/* 440 */       numToWrite -= num;
/* 441 */       wOffset += num;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void writePaxHeaders(TarArchiveEntry entry, String entryName, Map<String, String> headers)
/*     */     throws IOException
/*     */   {
/* 452 */     String name = "./PaxHeaders.X/" + stripTo7Bits(entryName);
/* 453 */     if (name.length() >= 100) {
/* 454 */       name = name.substring(0, 99);
/*     */     }
/* 456 */     TarArchiveEntry pex = new TarArchiveEntry(name, (byte)120);
/*     */     
/* 458 */     transferModTime(entry, pex);
/*     */     
/* 460 */     StringWriter w = new StringWriter();
/* 461 */     for (Map.Entry<String, String> h : headers.entrySet()) {
/* 462 */       String key = (String)h.getKey();
/* 463 */       String value = (String)h.getValue();
/* 464 */       int len = key.length() + value.length() + 3 + 2;
/*     */       
/*     */ 
/* 467 */       String line = len + " " + key + "=" + value + "\n";
/* 468 */       int actualLength = line.getBytes("UTF-8").length;
/* 469 */       while (len != actualLength)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 475 */         len = actualLength;
/* 476 */         line = len + " " + key + "=" + value + "\n";
/* 477 */         actualLength = line.getBytes("UTF-8").length;
/*     */       }
/* 479 */       w.write(line);
/*     */     }
/* 481 */     byte[] data = w.toString().getBytes("UTF-8");
/* 482 */     pex.setSize(data.length);
/* 483 */     putArchiveEntry(pex);
/* 484 */     write(data);
/* 485 */     closeArchiveEntry();
/*     */   }
/*     */   
/*     */   private String stripTo7Bits(String name) {
/* 489 */     int length = name.length();
/* 490 */     StringBuilder result = new StringBuilder(length);
/* 491 */     for (int i = 0; i < length; i++) {
/* 492 */       char stripped = (char)(name.charAt(i) & 0x7F);
/* 493 */       if (shouldBeReplaced(stripped)) {
/* 494 */         result.append("_");
/*     */       } else {
/* 496 */         result.append(stripped);
/*     */       }
/*     */     }
/* 499 */     return result.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean shouldBeReplaced(char c)
/*     */   {
/* 507 */     return (c == 0) || (c == '/') || (c == '\\');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeEOFRecord()
/*     */     throws IOException
/*     */   {
/* 517 */     Arrays.fill(this.recordBuf, (byte)0);
/* 518 */     writeRecord(this.recordBuf);
/*     */   }
/*     */   
/*     */   public void flush() throws IOException
/*     */   {
/* 523 */     this.out.flush();
/*     */   }
/*     */   
/*     */   public ArchiveEntry createArchiveEntry(File inputFile, String entryName)
/*     */     throws IOException
/*     */   {
/* 529 */     if (this.finished) {
/* 530 */       throw new IOException("Stream has already been finished");
/*     */     }
/* 532 */     return new TarArchiveEntry(inputFile, entryName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeRecord(byte[] record)
/*     */     throws IOException
/*     */   {
/* 542 */     if (record.length != this.recordSize) {
/* 543 */       throw new IOException("record to write has length '" + record.length + "' which is not the record size of '" + this.recordSize + "'");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 549 */     this.out.write(record);
/* 550 */     this.recordsWritten += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeRecord(byte[] buf, int offset)
/*     */     throws IOException
/*     */   {
/* 564 */     if (offset + this.recordSize > buf.length) {
/* 565 */       throw new IOException("record has length '" + buf.length + "' with offset '" + offset + "' which is less than the record size of '" + this.recordSize + "'");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 571 */     this.out.write(buf, offset, this.recordSize);
/* 572 */     this.recordsWritten += 1;
/*     */   }
/*     */   
/*     */   private void padAsNeeded() throws IOException {
/* 576 */     int start = this.recordsWritten % this.recordsPerBlock;
/* 577 */     if (start != 0) {
/* 578 */       for (int i = start; i < this.recordsPerBlock; i++) {
/* 579 */         writeEOFRecord();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addPaxHeadersForBigNumbers(Map<String, String> paxHeaders, TarArchiveEntry entry)
/*     */   {
/* 586 */     addPaxHeaderForBigNumber(paxHeaders, "size", entry.getSize(), 8589934591L);
/*     */     
/* 588 */     addPaxHeaderForBigNumber(paxHeaders, "gid", entry.getLongGroupId(), 2097151L);
/*     */     
/* 590 */     addPaxHeaderForBigNumber(paxHeaders, "mtime", entry.getModTime().getTime() / 1000L, 8589934591L);
/*     */     
/*     */ 
/* 593 */     addPaxHeaderForBigNumber(paxHeaders, "uid", entry.getLongUserId(), 2097151L);
/*     */     
/*     */ 
/* 596 */     addPaxHeaderForBigNumber(paxHeaders, "SCHILY.devmajor", entry.getDevMajor(), 2097151L);
/*     */     
/* 598 */     addPaxHeaderForBigNumber(paxHeaders, "SCHILY.devminor", entry.getDevMinor(), 2097151L);
/*     */     
/*     */ 
/* 601 */     failForBigNumber("mode", entry.getMode(), 2097151L);
/*     */   }
/*     */   
/*     */ 
/*     */   private void addPaxHeaderForBigNumber(Map<String, String> paxHeaders, String header, long value, long maxValue)
/*     */   {
/* 607 */     if ((value < 0L) || (value > maxValue)) {
/* 608 */       paxHeaders.put(header, String.valueOf(value));
/*     */     }
/*     */   }
/*     */   
/*     */   private void failForBigNumbers(TarArchiveEntry entry) {
/* 613 */     failForBigNumber("entry size", entry.getSize(), 8589934591L);
/* 614 */     failForBigNumberWithPosixMessage("group id", entry.getLongGroupId(), 2097151L);
/* 615 */     failForBigNumber("last modification time", entry.getModTime().getTime() / 1000L, 8589934591L);
/*     */     
/*     */ 
/* 618 */     failForBigNumber("user id", entry.getLongUserId(), 2097151L);
/* 619 */     failForBigNumber("mode", entry.getMode(), 2097151L);
/* 620 */     failForBigNumber("major device number", entry.getDevMajor(), 2097151L);
/*     */     
/* 622 */     failForBigNumber("minor device number", entry.getDevMinor(), 2097151L);
/*     */   }
/*     */   
/*     */   private void failForBigNumber(String field, long value, long maxValue)
/*     */   {
/* 627 */     failForBigNumber(field, value, maxValue, "");
/*     */   }
/*     */   
/*     */   private void failForBigNumberWithPosixMessage(String field, long value, long maxValue) {
/* 631 */     failForBigNumber(field, value, maxValue, " Use STAR or POSIX extensions to overcome this limit");
/*     */   }
/*     */   
/*     */   private void failForBigNumber(String field, long value, long maxValue, String additionalMsg) {
/* 635 */     if ((value < 0L) || (value > maxValue)) {
/* 636 */       throw new RuntimeException(field + " '" + value + "' is too big ( > " + maxValue + " )." + additionalMsg);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean handleLongName(TarArchiveEntry entry, String name, Map<String, String> paxHeaders, String paxHeaderName, byte linkType, String fieldName)
/*     */     throws IOException
/*     */   {
/* 668 */     ByteBuffer encodedName = this.zipEncoding.encode(name);
/* 669 */     int len = encodedName.limit() - encodedName.position();
/* 670 */     if (len >= 100)
/*     */     {
/* 672 */       if (this.longFileMode == 3) {
/* 673 */         paxHeaders.put(paxHeaderName, name);
/* 674 */         return true; }
/* 675 */       if (this.longFileMode == 2)
/*     */       {
/*     */ 
/* 678 */         TarArchiveEntry longLinkEntry = new TarArchiveEntry("././@LongLink", linkType);
/*     */         
/* 680 */         longLinkEntry.setSize(len + 1);
/* 681 */         transferModTime(entry, longLinkEntry);
/* 682 */         putArchiveEntry(longLinkEntry);
/* 683 */         write(encodedName.array(), encodedName.arrayOffset(), len);
/* 684 */         write(0);
/* 685 */         closeArchiveEntry();
/* 686 */       } else if (this.longFileMode != 1) {
/* 687 */         throw new RuntimeException(fieldName + " '" + name + "' is too long ( > " + 100 + " bytes)");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 692 */     return false;
/*     */   }
/*     */   
/*     */   private void transferModTime(TarArchiveEntry from, TarArchiveEntry to) {
/* 696 */     Date fromModTime = from.getModTime();
/* 697 */     long fromModTimeSeconds = fromModTime.getTime() / 1000L;
/* 698 */     if ((fromModTimeSeconds < 0L) || (fromModTimeSeconds > 8589934591L)) {
/* 699 */       fromModTime = new Date(0L);
/*     */     }
/* 701 */     to.setModTime(fromModTime);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\tar\TarArchiveOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */