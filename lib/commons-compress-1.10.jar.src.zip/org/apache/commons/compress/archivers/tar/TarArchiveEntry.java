/*      */ package org.apache.commons.compress.archivers.tar;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*      */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*      */ import org.apache.commons.compress.utils.ArchiveUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TarArchiveEntry
/*      */   implements TarConstants, ArchiveEntry
/*      */ {
/*  118 */   private String name = "";
/*      */   
/*      */ 
/*      */   private int mode;
/*      */   
/*      */ 
/*  124 */   private long userId = 0L;
/*      */   
/*      */ 
/*  127 */   private long groupId = 0L;
/*      */   
/*      */ 
/*  130 */   private long size = 0L;
/*      */   
/*      */ 
/*      */   private long modTime;
/*      */   
/*      */ 
/*      */   private boolean checkSumOK;
/*      */   
/*      */ 
/*      */   private byte linkFlag;
/*      */   
/*      */ 
/*  142 */   private String linkName = "";
/*      */   
/*      */ 
/*  145 */   private String magic = "ustar\000";
/*      */   
/*  147 */   private String version = "00";
/*      */   
/*      */ 
/*      */   private String userName;
/*      */   
/*      */ 
/*  153 */   private String groupName = "";
/*      */   
/*      */ 
/*  156 */   private int devMajor = 0;
/*      */   
/*      */ 
/*  159 */   private int devMinor = 0;
/*      */   
/*      */ 
/*      */   private boolean isExtended;
/*      */   
/*      */ 
/*      */   private long realSize;
/*      */   
/*      */ 
/*      */   private final File file;
/*      */   
/*      */ 
/*      */   public static final int MAX_NAMELEN = 31;
/*      */   
/*      */ 
/*      */   public static final int DEFAULT_DIR_MODE = 16877;
/*      */   
/*      */ 
/*      */   public static final int DEFAULT_FILE_MODE = 33188;
/*      */   
/*      */ 
/*      */   public static final int MILLIS_PER_SECOND = 1000;
/*      */   
/*      */ 
/*      */ 
/*      */   private TarArchiveEntry()
/*      */   {
/*  186 */     String user = System.getProperty("user.name", "");
/*      */     
/*  188 */     if (user.length() > 31) {
/*  189 */       user = user.substring(0, 31);
/*      */     }
/*      */     
/*  192 */     this.userName = user;
/*  193 */     this.file = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(String name)
/*      */   {
/*  203 */     this(name, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(String name, boolean preserveLeadingSlashes)
/*      */   {
/*  217 */     this();
/*      */     
/*  219 */     name = normalizeFileName(name, preserveLeadingSlashes);
/*  220 */     boolean isDir = name.endsWith("/");
/*      */     
/*      */ 
/*  223 */     this.mode = (isDir ? 16877 : 33188);
/*  224 */     this.linkFlag = (isDir ? 53 : 48);
/*  225 */     this.modTime = (new Date().getTime() / 1000L);
/*  226 */     this.userName = "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(String name, byte linkFlag)
/*      */   {
/*  236 */     this(name, linkFlag, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(String name, byte linkFlag, boolean preserveLeadingSlashes)
/*      */   {
/*  250 */     this(name, preserveLeadingSlashes);
/*  251 */     this.linkFlag = linkFlag;
/*  252 */     if (linkFlag == 76) {
/*  253 */       this.magic = "ustar ";
/*  254 */       this.version = " \000";
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(File file)
/*      */   {
/*  266 */     this(file, file.getPath());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(File file, String fileName)
/*      */   {
/*  277 */     String normalizedName = normalizeFileName(fileName, false);
/*  278 */     this.file = file;
/*      */     
/*  280 */     if (file.isDirectory()) {
/*  281 */       this.mode = 16877;
/*  282 */       this.linkFlag = 53;
/*      */       
/*  284 */       int nameLength = normalizedName.length();
/*  285 */       if ((nameLength == 0) || (normalizedName.charAt(nameLength - 1) != '/')) {
/*  286 */         this.name = (normalizedName + "/");
/*      */       } else {
/*  288 */         this.name = normalizedName;
/*      */       }
/*      */     } else {
/*  291 */       this.mode = 33188;
/*  292 */       this.linkFlag = 48;
/*  293 */       this.size = file.length();
/*  294 */       this.name = normalizedName;
/*      */     }
/*      */     
/*  297 */     this.modTime = (file.lastModified() / 1000L);
/*  298 */     this.userName = "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(byte[] headerBuf)
/*      */   {
/*  309 */     this();
/*  310 */     parseTarHeader(headerBuf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry(byte[] headerBuf, ZipEncoding encoding)
/*      */     throws IOException
/*      */   {
/*  325 */     this();
/*  326 */     parseTarHeader(headerBuf, encoding);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(TarArchiveEntry it)
/*      */   {
/*  337 */     return getName().equals(it.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object it)
/*      */   {
/*  349 */     if ((it == null) || (getClass() != it.getClass())) {
/*  350 */       return false;
/*      */     }
/*  352 */     return equals((TarArchiveEntry)it);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  362 */     return getName().hashCode();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDescendent(TarArchiveEntry desc)
/*      */   {
/*  374 */     return desc.getName().startsWith(getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getName()
/*      */   {
/*  383 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setName(String name)
/*      */   {
/*  392 */     this.name = normalizeFileName(name, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMode(int mode)
/*      */   {
/*  401 */     this.mode = mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLinkName()
/*      */   {
/*  410 */     return this.linkName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLinkName(String link)
/*      */   {
/*  421 */     this.linkName = link;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public int getUserId()
/*      */   {
/*  433 */     return (int)(this.userId & 0xFFFFFFFFFFFFFFFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserId(int userId)
/*      */   {
/*  442 */     setUserId(userId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLongUserId()
/*      */   {
/*  452 */     return this.userId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserId(long userId)
/*      */   {
/*  462 */     this.userId = userId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public int getGroupId()
/*      */   {
/*  474 */     return (int)(this.groupId & 0xFFFFFFFFFFFFFFFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGroupId(int groupId)
/*      */   {
/*  483 */     setGroupId(groupId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLongGroupId()
/*      */   {
/*  493 */     return this.groupId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGroupId(long groupId)
/*      */   {
/*  503 */     this.groupId = groupId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUserName()
/*      */   {
/*  512 */     return this.userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUserName(String userName)
/*      */   {
/*  521 */     this.userName = userName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getGroupName()
/*      */   {
/*  530 */     return this.groupName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGroupName(String groupName)
/*      */   {
/*  539 */     this.groupName = groupName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIds(int userId, int groupId)
/*      */   {
/*  549 */     setUserId(userId);
/*  550 */     setGroupId(groupId);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNames(String userName, String groupName)
/*      */   {
/*  560 */     setUserName(userName);
/*  561 */     setGroupName(groupName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setModTime(long time)
/*      */   {
/*  571 */     this.modTime = (time / 1000L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setModTime(Date time)
/*      */   {
/*  580 */     this.modTime = (time.getTime() / 1000L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Date getModTime()
/*      */   {
/*  589 */     return new Date(this.modTime * 1000L);
/*      */   }
/*      */   
/*      */   public Date getLastModifiedDate() {
/*  593 */     return getModTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCheckSumOK()
/*      */   {
/*  604 */     return this.checkSumOK;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public File getFile()
/*      */   {
/*  613 */     return this.file;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMode()
/*      */   {
/*  622 */     return this.mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getSize()
/*      */   {
/*  631 */     return this.size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSize(long size)
/*      */   {
/*  641 */     if (size < 0L) {
/*  642 */       throw new IllegalArgumentException("Size is out of range: " + size);
/*      */     }
/*  644 */     this.size = size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDevMajor()
/*      */   {
/*  654 */     return this.devMajor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDevMajor(int devNo)
/*      */   {
/*  665 */     if (devNo < 0) {
/*  666 */       throw new IllegalArgumentException("Major device number is out of range: " + devNo);
/*      */     }
/*      */     
/*  669 */     this.devMajor = devNo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDevMinor()
/*      */   {
/*  679 */     return this.devMinor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDevMinor(int devNo)
/*      */   {
/*  690 */     if (devNo < 0) {
/*  691 */       throw new IllegalArgumentException("Minor device number is out of range: " + devNo);
/*      */     }
/*      */     
/*  694 */     this.devMinor = devNo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isExtended()
/*      */   {
/*  704 */     return this.isExtended;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getRealSize()
/*      */   {
/*  713 */     return this.realSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isGNUSparse()
/*      */   {
/*  722 */     return this.linkFlag == 83;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isGNULongLinkEntry()
/*      */   {
/*  731 */     return (this.linkFlag == 75) && (this.name.equals("././@LongLink"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isGNULongNameEntry()
/*      */   {
/*  741 */     return (this.linkFlag == 76) && (this.name.equals("././@LongLink"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isPaxHeader()
/*      */   {
/*  754 */     return (this.linkFlag == 120) || (this.linkFlag == 88);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isGlobalPaxHeader()
/*      */   {
/*  766 */     return this.linkFlag == 103;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDirectory()
/*      */   {
/*  775 */     if (this.file != null) {
/*  776 */       return this.file.isDirectory();
/*      */     }
/*      */     
/*  779 */     if (this.linkFlag == 53) {
/*  780 */       return true;
/*      */     }
/*      */     
/*  783 */     if (getName().endsWith("/")) {
/*  784 */       return true;
/*      */     }
/*      */     
/*  787 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFile()
/*      */   {
/*  797 */     if (this.file != null) {
/*  798 */       return this.file.isFile();
/*      */     }
/*  800 */     if ((this.linkFlag == 0) || (this.linkFlag == 48)) {
/*  801 */       return true;
/*      */     }
/*  803 */     return !getName().endsWith("/");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSymbolicLink()
/*      */   {
/*  813 */     return this.linkFlag == 50;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLink()
/*      */   {
/*  823 */     return this.linkFlag == 49;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCharacterDevice()
/*      */   {
/*  833 */     return this.linkFlag == 51;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBlockDevice()
/*      */   {
/*  843 */     return this.linkFlag == 52;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFIFO()
/*      */   {
/*  853 */     return this.linkFlag == 54;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TarArchiveEntry[] getDirectoryEntries()
/*      */   {
/*  863 */     if ((this.file == null) || (!this.file.isDirectory())) {
/*  864 */       return new TarArchiveEntry[0];
/*      */     }
/*      */     
/*  867 */     String[] list = this.file.list();
/*  868 */     TarArchiveEntry[] result = new TarArchiveEntry[list.length];
/*      */     
/*  870 */     for (int i = 0; i < list.length; i++) {
/*  871 */       result[i] = new TarArchiveEntry(new File(this.file, list[i]));
/*      */     }
/*      */     
/*  874 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeEntryHeader(byte[] outbuf)
/*      */   {
/*      */     try
/*      */     {
/*  886 */       writeEntryHeader(outbuf, TarUtils.DEFAULT_ENCODING, false);
/*      */     } catch (IOException ex) {
/*      */       try {
/*  889 */         writeEntryHeader(outbuf, TarUtils.FALLBACK_ENCODING, false);
/*      */       }
/*      */       catch (IOException ex2) {
/*  892 */         throw new RuntimeException(ex2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeEntryHeader(byte[] outbuf, ZipEncoding encoding, boolean starMode)
/*      */     throws IOException
/*      */   {
/*  910 */     int offset = 0;
/*      */     
/*  912 */     offset = TarUtils.formatNameBytes(this.name, outbuf, offset, 100, encoding);
/*      */     
/*  914 */     offset = writeEntryHeaderField(this.mode, outbuf, offset, 8, starMode);
/*  915 */     offset = writeEntryHeaderField(this.userId, outbuf, offset, 8, starMode);
/*      */     
/*  917 */     offset = writeEntryHeaderField(this.groupId, outbuf, offset, 8, starMode);
/*      */     
/*  919 */     offset = writeEntryHeaderField(this.size, outbuf, offset, 12, starMode);
/*  920 */     offset = writeEntryHeaderField(this.modTime, outbuf, offset, 12, starMode);
/*      */     
/*      */ 
/*  923 */     int csOffset = offset;
/*      */     
/*  925 */     for (int c = 0; c < 8; c++) {
/*  926 */       outbuf[(offset++)] = 32;
/*      */     }
/*      */     
/*  929 */     outbuf[(offset++)] = this.linkFlag;
/*  930 */     offset = TarUtils.formatNameBytes(this.linkName, outbuf, offset, 100, encoding);
/*      */     
/*  932 */     offset = TarUtils.formatNameBytes(this.magic, outbuf, offset, 6);
/*  933 */     offset = TarUtils.formatNameBytes(this.version, outbuf, offset, 2);
/*  934 */     offset = TarUtils.formatNameBytes(this.userName, outbuf, offset, 32, encoding);
/*      */     
/*  936 */     offset = TarUtils.formatNameBytes(this.groupName, outbuf, offset, 32, encoding);
/*      */     
/*  938 */     offset = writeEntryHeaderField(this.devMajor, outbuf, offset, 8, starMode);
/*      */     
/*  940 */     offset = writeEntryHeaderField(this.devMinor, outbuf, offset, 8, starMode);
/*      */     
/*      */ 
/*  943 */     while (offset < outbuf.length) {
/*  944 */       outbuf[(offset++)] = 0;
/*      */     }
/*      */     
/*  947 */     long chk = TarUtils.computeCheckSum(outbuf);
/*      */     
/*  949 */     TarUtils.formatCheckSumOctalBytes(chk, outbuf, csOffset, 8);
/*      */   }
/*      */   
/*      */   private int writeEntryHeaderField(long value, byte[] outbuf, int offset, int length, boolean starMode)
/*      */   {
/*  954 */     if ((!starMode) && ((value < 0L) || (value >= 1L << 3 * (length - 1))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  959 */       return TarUtils.formatLongOctalBytes(0L, outbuf, offset, length);
/*      */     }
/*  961 */     return TarUtils.formatLongOctalOrBinaryBytes(value, outbuf, offset, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void parseTarHeader(byte[] header)
/*      */   {
/*      */     try
/*      */     {
/*  973 */       parseTarHeader(header, TarUtils.DEFAULT_ENCODING);
/*      */     } catch (IOException ex) {
/*      */       try {
/*  976 */         parseTarHeader(header, TarUtils.DEFAULT_ENCODING, true);
/*      */       }
/*      */       catch (IOException ex2) {
/*  979 */         throw new RuntimeException(ex2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void parseTarHeader(byte[] header, ZipEncoding encoding)
/*      */     throws IOException
/*      */   {
/*  996 */     parseTarHeader(header, encoding, false);
/*      */   }
/*      */   
/*      */   private void parseTarHeader(byte[] header, ZipEncoding encoding, boolean oldStyle)
/*      */     throws IOException
/*      */   {
/* 1002 */     int offset = 0;
/*      */     
/* 1004 */     this.name = (oldStyle ? TarUtils.parseName(header, offset, 100) : TarUtils.parseName(header, offset, 100, encoding));
/*      */     
/* 1006 */     offset += 100;
/* 1007 */     this.mode = ((int)TarUtils.parseOctalOrBinary(header, offset, 8));
/* 1008 */     offset += 8;
/* 1009 */     this.userId = ((int)TarUtils.parseOctalOrBinary(header, offset, 8));
/* 1010 */     offset += 8;
/* 1011 */     this.groupId = ((int)TarUtils.parseOctalOrBinary(header, offset, 8));
/* 1012 */     offset += 8;
/* 1013 */     this.size = TarUtils.parseOctalOrBinary(header, offset, 12);
/* 1014 */     offset += 12;
/* 1015 */     this.modTime = TarUtils.parseOctalOrBinary(header, offset, 12);
/* 1016 */     offset += 12;
/* 1017 */     this.checkSumOK = TarUtils.verifyCheckSum(header);
/* 1018 */     offset += 8;
/* 1019 */     this.linkFlag = header[(offset++)];
/* 1020 */     this.linkName = (oldStyle ? TarUtils.parseName(header, offset, 100) : TarUtils.parseName(header, offset, 100, encoding));
/*      */     
/* 1022 */     offset += 100;
/* 1023 */     this.magic = TarUtils.parseName(header, offset, 6);
/* 1024 */     offset += 6;
/* 1025 */     this.version = TarUtils.parseName(header, offset, 2);
/* 1026 */     offset += 2;
/* 1027 */     this.userName = (oldStyle ? TarUtils.parseName(header, offset, 32) : TarUtils.parseName(header, offset, 32, encoding));
/*      */     
/* 1029 */     offset += 32;
/* 1030 */     this.groupName = (oldStyle ? TarUtils.parseName(header, offset, 32) : TarUtils.parseName(header, offset, 32, encoding));
/*      */     
/* 1032 */     offset += 32;
/* 1033 */     this.devMajor = ((int)TarUtils.parseOctalOrBinary(header, offset, 8));
/* 1034 */     offset += 8;
/* 1035 */     this.devMinor = ((int)TarUtils.parseOctalOrBinary(header, offset, 8));
/* 1036 */     offset += 8;
/*      */     
/* 1038 */     int type = evaluateType(header);
/* 1039 */     switch (type) {
/*      */     case 2: 
/* 1041 */       offset += 12;
/* 1042 */       offset += 12;
/* 1043 */       offset += 12;
/* 1044 */       offset += 4;
/* 1045 */       offset++;
/* 1046 */       offset += 96;
/* 1047 */       this.isExtended = TarUtils.parseBoolean(header, offset);
/* 1048 */       offset++;
/* 1049 */       this.realSize = TarUtils.parseOctal(header, offset, 12);
/* 1050 */       offset += 12;
/* 1051 */       break;
/*      */     
/*      */     case 3: 
/*      */     default: 
/* 1055 */       String prefix = oldStyle ? TarUtils.parseName(header, offset, 155) : TarUtils.parseName(header, offset, 155, encoding);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1060 */       if ((isDirectory()) && (!this.name.endsWith("/"))) {
/* 1061 */         this.name += "/";
/*      */       }
/* 1063 */       if (prefix.length() > 0) {
/* 1064 */         this.name = (prefix + "/" + this.name);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */   private static String normalizeFileName(String fileName, boolean preserveLeadingSlashes)
/*      */   {
/* 1076 */     String osname = System.getProperty("os.name").toLowerCase(Locale.ENGLISH);
/*      */     
/* 1078 */     if (osname != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1083 */       if (osname.startsWith("windows")) {
/* 1084 */         if (fileName.length() > 2) {
/* 1085 */           char ch1 = fileName.charAt(0);
/* 1086 */           char ch2 = fileName.charAt(1);
/*      */           
/* 1088 */           if ((ch2 == ':') && (((ch1 >= 'a') && (ch1 <= 'z')) || ((ch1 >= 'A') && (ch1 <= 'Z'))))
/*      */           {
/*      */ 
/* 1091 */             fileName = fileName.substring(2);
/*      */           }
/*      */         }
/* 1094 */       } else if (osname.contains("netware")) {
/* 1095 */         int colon = fileName.indexOf(':');
/* 1096 */         if (colon != -1) {
/* 1097 */           fileName = fileName.substring(colon + 1);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1102 */     fileName = fileName.replace(File.separatorChar, '/');
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1107 */     while ((!preserveLeadingSlashes) && (fileName.startsWith("/"))) {
/* 1108 */       fileName = fileName.substring(1);
/*      */     }
/* 1110 */     return fileName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int evaluateType(byte[] header)
/*      */   {
/* 1120 */     if (ArchiveUtils.matchAsciiBuffer("ustar ", header, 257, 6)) {
/* 1121 */       return 2;
/*      */     }
/* 1123 */     if (ArchiveUtils.matchAsciiBuffer("ustar\000", header, 257, 6)) {
/* 1124 */       return 3;
/*      */     }
/* 1126 */     return 0;
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\tar\TarArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */