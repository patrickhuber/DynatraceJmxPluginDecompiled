/*     */ package org.apache.commons.compress.archivers.cpio;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
/*     */ import org.apache.commons.compress.utils.ArchiveUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CpioArchiveOutputStream
/*     */   extends ArchiveOutputStream
/*     */   implements CpioConstants
/*     */ {
/*     */   private CpioArchiveEntry entry;
/*  69 */   private boolean closed = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean finished;
/*     */   
/*     */ 
/*     */   private final short entryFormat;
/*     */   
/*     */ 
/*  79 */   private final HashMap<String, CpioArchiveEntry> names = new HashMap();
/*     */   
/*     */ 
/*  82 */   private long crc = 0L;
/*     */   
/*     */   private long written;
/*     */   
/*     */   private final OutputStream out;
/*     */   
/*     */   private final int blockSize;
/*     */   
/*  90 */   private long nextArtificalDeviceAndInode = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ZipEncoding zipEncoding;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   final String encoding;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveOutputStream(OutputStream out, short format)
/*     */   {
/* 111 */     this(out, format, 512, "US-ASCII");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveOutputStream(OutputStream out, short format, int blockSize)
/*     */   {
/* 129 */     this(out, format, blockSize, "US-ASCII");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveOutputStream(OutputStream out, short format, int blockSize, String encoding)
/*     */   {
/* 150 */     this.out = out;
/* 151 */     switch (format) {
/*     */     case 1: case 2: 
/*     */     case 4: case 8: 
/*     */       break;
/*     */     case 3: case 5: 
/*     */     case 6: case 7: 
/*     */     default: 
/* 158 */       throw new IllegalArgumentException("Unknown format: " + format);
/*     */     }
/*     */     
/* 161 */     this.entryFormat = format;
/* 162 */     this.blockSize = blockSize;
/* 163 */     this.encoding = encoding;
/* 164 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveOutputStream(OutputStream out)
/*     */   {
/* 175 */     this(out, (short)1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveOutputStream(OutputStream out, String encoding)
/*     */   {
/* 190 */     this(out, (short)1, 512, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureOpen()
/*     */     throws IOException
/*     */   {
/* 200 */     if (this.closed) {
/* 201 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putArchiveEntry(ArchiveEntry entry)
/*     */     throws IOException
/*     */   {
/* 221 */     if (this.finished) {
/* 222 */       throw new IOException("Stream has already been finished");
/*     */     }
/*     */     
/* 225 */     CpioArchiveEntry e = (CpioArchiveEntry)entry;
/* 226 */     ensureOpen();
/* 227 */     if (this.entry != null) {
/* 228 */       closeArchiveEntry();
/*     */     }
/* 230 */     if (e.getTime() == -1L) {
/* 231 */       e.setTime(System.currentTimeMillis() / 1000L);
/*     */     }
/*     */     
/* 234 */     short format = e.getFormat();
/* 235 */     if (format != this.entryFormat) {
/* 236 */       throw new IOException("Header format: " + format + " does not match existing format: " + this.entryFormat);
/*     */     }
/*     */     
/* 239 */     if (this.names.put(e.getName(), e) != null) {
/* 240 */       throw new IOException("duplicate entry: " + e.getName());
/*     */     }
/*     */     
/* 243 */     writeHeader(e);
/* 244 */     this.entry = e;
/* 245 */     this.written = 0L;
/*     */   }
/*     */   
/*     */   private void writeHeader(CpioArchiveEntry e) throws IOException {
/* 249 */     switch (e.getFormat()) {
/*     */     case 1: 
/* 251 */       this.out.write(ArchiveUtils.toAsciiBytes("070701"));
/* 252 */       count(6);
/* 253 */       writeNewEntry(e);
/* 254 */       break;
/*     */     case 2: 
/* 256 */       this.out.write(ArchiveUtils.toAsciiBytes("070702"));
/* 257 */       count(6);
/* 258 */       writeNewEntry(e);
/* 259 */       break;
/*     */     case 4: 
/* 261 */       this.out.write(ArchiveUtils.toAsciiBytes("070707"));
/* 262 */       count(6);
/* 263 */       writeOldAsciiEntry(e);
/* 264 */       break;
/*     */     case 8: 
/* 266 */       boolean swapHalfWord = true;
/* 267 */       writeBinaryLong(29127L, 2, swapHalfWord);
/* 268 */       writeOldBinaryEntry(e, swapHalfWord);
/* 269 */       break;
/*     */     case 3: case 5: case 6: case 7: default: 
/* 271 */       throw new IOException("unknown format " + e.getFormat());
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeNewEntry(CpioArchiveEntry entry) throws IOException {
/* 276 */     long inode = entry.getInode();
/* 277 */     long devMin = entry.getDeviceMin();
/* 278 */     if ("TRAILER!!!".equals(entry.getName())) {
/* 279 */       inode = devMin = 0L;
/*     */     }
/* 281 */     else if ((inode == 0L) && (devMin == 0L)) {
/* 282 */       inode = this.nextArtificalDeviceAndInode & 0xFFFFFFFFFFFFFFFF;
/* 283 */       devMin = this.nextArtificalDeviceAndInode++ >> 32 & 0xFFFFFFFFFFFFFFFF;
/*     */     } else {
/* 285 */       this.nextArtificalDeviceAndInode = (Math.max(this.nextArtificalDeviceAndInode, inode + 4294967296L * devMin) + 1L);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 291 */     writeAsciiLong(inode, 8, 16);
/* 292 */     writeAsciiLong(entry.getMode(), 8, 16);
/* 293 */     writeAsciiLong(entry.getUID(), 8, 16);
/* 294 */     writeAsciiLong(entry.getGID(), 8, 16);
/* 295 */     writeAsciiLong(entry.getNumberOfLinks(), 8, 16);
/* 296 */     writeAsciiLong(entry.getTime(), 8, 16);
/* 297 */     writeAsciiLong(entry.getSize(), 8, 16);
/* 298 */     writeAsciiLong(entry.getDeviceMaj(), 8, 16);
/* 299 */     writeAsciiLong(devMin, 8, 16);
/* 300 */     writeAsciiLong(entry.getRemoteDeviceMaj(), 8, 16);
/* 301 */     writeAsciiLong(entry.getRemoteDeviceMin(), 8, 16);
/* 302 */     writeAsciiLong(entry.getName().length() + 1, 8, 16);
/* 303 */     writeAsciiLong(entry.getChksum(), 8, 16);
/* 304 */     writeCString(entry.getName());
/* 305 */     pad(entry.getHeaderPadCount());
/*     */   }
/*     */   
/*     */   private void writeOldAsciiEntry(CpioArchiveEntry entry) throws IOException
/*     */   {
/* 310 */     long inode = entry.getInode();
/* 311 */     long device = entry.getDevice();
/* 312 */     if ("TRAILER!!!".equals(entry.getName())) {
/* 313 */       inode = device = 0L;
/*     */     }
/* 315 */     else if ((inode == 0L) && (device == 0L)) {
/* 316 */       inode = this.nextArtificalDeviceAndInode & 0x3FFFF;
/* 317 */       device = this.nextArtificalDeviceAndInode++ >> 18 & 0x3FFFF;
/*     */     } else {
/* 319 */       this.nextArtificalDeviceAndInode = (Math.max(this.nextArtificalDeviceAndInode, inode + 262144L * device) + 1L);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 325 */     writeAsciiLong(device, 6, 8);
/* 326 */     writeAsciiLong(inode, 6, 8);
/* 327 */     writeAsciiLong(entry.getMode(), 6, 8);
/* 328 */     writeAsciiLong(entry.getUID(), 6, 8);
/* 329 */     writeAsciiLong(entry.getGID(), 6, 8);
/* 330 */     writeAsciiLong(entry.getNumberOfLinks(), 6, 8);
/* 331 */     writeAsciiLong(entry.getRemoteDevice(), 6, 8);
/* 332 */     writeAsciiLong(entry.getTime(), 11, 8);
/* 333 */     writeAsciiLong(entry.getName().length() + 1, 6, 8);
/* 334 */     writeAsciiLong(entry.getSize(), 11, 8);
/* 335 */     writeCString(entry.getName());
/*     */   }
/*     */   
/*     */   private void writeOldBinaryEntry(CpioArchiveEntry entry, boolean swapHalfWord) throws IOException
/*     */   {
/* 340 */     long inode = entry.getInode();
/* 341 */     long device = entry.getDevice();
/* 342 */     if ("TRAILER!!!".equals(entry.getName())) {
/* 343 */       inode = device = 0L;
/*     */     }
/* 345 */     else if ((inode == 0L) && (device == 0L)) {
/* 346 */       inode = this.nextArtificalDeviceAndInode & 0xFFFF;
/* 347 */       device = this.nextArtificalDeviceAndInode++ >> 16 & 0xFFFF;
/*     */     } else {
/* 349 */       this.nextArtificalDeviceAndInode = (Math.max(this.nextArtificalDeviceAndInode, inode + 65536L * device) + 1L);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 355 */     writeBinaryLong(device, 2, swapHalfWord);
/* 356 */     writeBinaryLong(inode, 2, swapHalfWord);
/* 357 */     writeBinaryLong(entry.getMode(), 2, swapHalfWord);
/* 358 */     writeBinaryLong(entry.getUID(), 2, swapHalfWord);
/* 359 */     writeBinaryLong(entry.getGID(), 2, swapHalfWord);
/* 360 */     writeBinaryLong(entry.getNumberOfLinks(), 2, swapHalfWord);
/* 361 */     writeBinaryLong(entry.getRemoteDevice(), 2, swapHalfWord);
/* 362 */     writeBinaryLong(entry.getTime(), 4, swapHalfWord);
/* 363 */     writeBinaryLong(entry.getName().length() + 1, 2, swapHalfWord);
/* 364 */     writeBinaryLong(entry.getSize(), 4, swapHalfWord);
/* 365 */     writeCString(entry.getName());
/* 366 */     pad(entry.getHeaderPadCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void closeArchiveEntry()
/*     */     throws IOException
/*     */   {
/* 377 */     if (this.finished) {
/* 378 */       throw new IOException("Stream has already been finished");
/*     */     }
/*     */     
/* 381 */     ensureOpen();
/*     */     
/* 383 */     if (this.entry == null) {
/* 384 */       throw new IOException("Trying to close non-existent entry");
/*     */     }
/*     */     
/* 387 */     if (this.entry.getSize() != this.written) {
/* 388 */       throw new IOException("invalid entry size (expected " + this.entry.getSize() + " but got " + this.written + " bytes)");
/*     */     }
/*     */     
/*     */ 
/* 392 */     pad(this.entry.getDataPadCount());
/* 393 */     if ((this.entry.getFormat() == 2) && (this.crc != this.entry.getChksum()))
/*     */     {
/* 395 */       throw new IOException("CRC Error");
/*     */     }
/* 397 */     this.entry = null;
/* 398 */     this.crc = 0L;
/* 399 */     this.written = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 419 */     ensureOpen();
/* 420 */     if ((off < 0) || (len < 0) || (off > b.length - len))
/* 421 */       throw new IndexOutOfBoundsException();
/* 422 */     if (len == 0) {
/* 423 */       return;
/*     */     }
/*     */     
/* 426 */     if (this.entry == null) {
/* 427 */       throw new IOException("no current CPIO entry");
/*     */     }
/* 429 */     if (this.written + len > this.entry.getSize()) {
/* 430 */       throw new IOException("attempt to write past end of STORED entry");
/*     */     }
/* 432 */     this.out.write(b, off, len);
/* 433 */     this.written += len;
/* 434 */     if (this.entry.getFormat() == 2) {
/* 435 */       for (int pos = 0; pos < len; pos++) {
/* 436 */         this.crc += (b[pos] & 0xFF);
/*     */       }
/*     */     }
/* 439 */     count(len);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finish()
/*     */     throws IOException
/*     */   {
/* 453 */     ensureOpen();
/* 454 */     if (this.finished) {
/* 455 */       throw new IOException("This archive has already been finished");
/*     */     }
/*     */     
/* 458 */     if (this.entry != null) {
/* 459 */       throw new IOException("This archive contains unclosed entries.");
/*     */     }
/* 461 */     this.entry = new CpioArchiveEntry(this.entryFormat);
/* 462 */     this.entry.setName("TRAILER!!!");
/* 463 */     this.entry.setNumberOfLinks(1L);
/* 464 */     writeHeader(this.entry);
/* 465 */     closeArchiveEntry();
/*     */     
/* 467 */     int lengthOfLastBlock = (int)(getBytesWritten() % this.blockSize);
/* 468 */     if (lengthOfLastBlock != 0) {
/* 469 */       pad(this.blockSize - lengthOfLastBlock);
/*     */     }
/*     */     
/* 472 */     this.finished = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 484 */     if (!this.finished) {
/* 485 */       finish();
/*     */     }
/*     */     
/* 488 */     if (!this.closed) {
/* 489 */       this.out.close();
/* 490 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void pad(int count) throws IOException {
/* 495 */     if (count > 0) {
/* 496 */       byte[] buff = new byte[count];
/* 497 */       this.out.write(buff);
/* 498 */       count(count);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeBinaryLong(long number, int length, boolean swapHalfWord) throws IOException
/*     */   {
/* 504 */     byte[] tmp = CpioUtil.long2byteArray(number, length, swapHalfWord);
/* 505 */     this.out.write(tmp);
/* 506 */     count(tmp.length);
/*     */   }
/*     */   
/*     */   private void writeAsciiLong(long number, int length, int radix) throws IOException
/*     */   {
/* 511 */     StringBuilder tmp = new StringBuilder();
/*     */     
/* 513 */     if (radix == 16) {
/* 514 */       tmp.append(Long.toHexString(number));
/* 515 */     } else if (radix == 8) {
/* 516 */       tmp.append(Long.toOctalString(number));
/*     */     } else
/* 518 */       tmp.append(Long.toString(number));
/*     */     String tmpStr;
/*     */     String tmpStr;
/* 521 */     if (tmp.length() <= length) {
/* 522 */       long insertLength = length - tmp.length();
/* 523 */       for (int pos = 0; pos < insertLength; pos++) {
/* 524 */         tmp.insert(0, "0");
/*     */       }
/* 526 */       tmpStr = tmp.toString();
/*     */     } else {
/* 528 */       tmpStr = tmp.substring(tmp.length() - length);
/*     */     }
/* 530 */     byte[] b = ArchiveUtils.toAsciiBytes(tmpStr);
/* 531 */     this.out.write(b);
/* 532 */     count(b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeCString(String str)
/*     */     throws IOException
/*     */   {
/* 541 */     ByteBuffer buf = this.zipEncoding.encode(str);
/* 542 */     int len = buf.limit() - buf.position();
/* 543 */     this.out.write(buf.array(), buf.arrayOffset(), len);
/* 544 */     this.out.write(0);
/* 545 */     count(len + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveEntry createArchiveEntry(File inputFile, String entryName)
/*     */     throws IOException
/*     */   {
/* 556 */     if (this.finished) {
/* 557 */       throw new IOException("Stream has already been finished");
/*     */     }
/* 559 */     return new CpioArchiveEntry(inputFile, entryName);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\cpio\CpioArchiveOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */