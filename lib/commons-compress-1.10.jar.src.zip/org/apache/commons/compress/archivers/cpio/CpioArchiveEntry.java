/*     */ package org.apache.commons.compress.archivers.cpio;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CpioArchiveEntry
/*     */   implements CpioConstants, ArchiveEntry
/*     */ {
/*     */   private final short fileFormat;
/*     */   private final int headerSize;
/*     */   private final int alignmentBoundary;
/* 163 */   private long chksum = 0L;
/*     */   
/*     */ 
/* 166 */   private long filesize = 0L;
/*     */   
/* 168 */   private long gid = 0L;
/*     */   
/* 170 */   private long inode = 0L;
/*     */   
/* 172 */   private long maj = 0L;
/*     */   
/* 174 */   private long min = 0L;
/*     */   
/* 176 */   private long mode = 0L;
/*     */   
/* 178 */   private long mtime = 0L;
/*     */   
/*     */   private String name;
/*     */   
/* 182 */   private long nlink = 0L;
/*     */   
/* 184 */   private long rmaj = 0L;
/*     */   
/* 186 */   private long rmin = 0L;
/*     */   
/* 188 */   private long uid = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(short format)
/*     */   {
/* 205 */     switch (format) {
/*     */     case 1: 
/* 207 */       this.headerSize = 110;
/* 208 */       this.alignmentBoundary = 4;
/* 209 */       break;
/*     */     case 2: 
/* 211 */       this.headerSize = 110;
/* 212 */       this.alignmentBoundary = 4;
/* 213 */       break;
/*     */     case 4: 
/* 215 */       this.headerSize = 76;
/* 216 */       this.alignmentBoundary = 0;
/* 217 */       break;
/*     */     case 8: 
/* 219 */       this.headerSize = 26;
/* 220 */       this.alignmentBoundary = 2;
/* 221 */       break;
/*     */     case 3: case 5: case 6: case 7: default: 
/* 223 */       throw new IllegalArgumentException("Unknown header type");
/*     */     }
/* 225 */     this.fileFormat = format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(String name)
/*     */   {
/* 236 */     this((short)1, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(short format, String name)
/*     */   {
/* 258 */     this(format);
/* 259 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(String name, long size)
/*     */   {
/* 272 */     this(name);
/* 273 */     setSize(size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(short format, String name, long size)
/*     */   {
/* 298 */     this(format, name);
/* 299 */     setSize(size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(File inputFile, String entryName)
/*     */   {
/* 313 */     this((short)1, inputFile, entryName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry(short format, File inputFile, String entryName)
/*     */   {
/* 339 */     this(format, entryName, inputFile.isFile() ? inputFile.length() : 0L);
/* 340 */     if (inputFile.isDirectory()) {
/* 341 */       setMode(16384L);
/* 342 */     } else if (inputFile.isFile()) {
/* 343 */       setMode(32768L);
/*     */     } else {
/* 345 */       throw new IllegalArgumentException("Cannot determine type of file " + inputFile.getName());
/*     */     }
/*     */     
/*     */ 
/* 349 */     setTime(inputFile.lastModified() / 1000L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkNewFormat()
/*     */   {
/* 356 */     if ((this.fileFormat & 0x3) == 0) {
/* 357 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkOldFormat()
/*     */   {
/* 365 */     if ((this.fileFormat & 0xC) == 0) {
/* 366 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getChksum()
/*     */   {
/* 378 */     checkNewFormat();
/* 379 */     return this.chksum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getDevice()
/*     */   {
/* 391 */     checkOldFormat();
/* 392 */     return this.min;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getDeviceMaj()
/*     */   {
/* 404 */     checkNewFormat();
/* 405 */     return this.maj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getDeviceMin()
/*     */   {
/* 415 */     checkNewFormat();
/* 416 */     return this.min;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 426 */     return this.filesize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short getFormat()
/*     */   {
/* 435 */     return this.fileFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getGID()
/*     */   {
/* 444 */     return this.gid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeaderSize()
/*     */   {
/* 453 */     return this.headerSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAlignmentBoundary()
/*     */   {
/* 462 */     return this.alignmentBoundary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeaderPadCount()
/*     */   {
/* 471 */     if (this.alignmentBoundary == 0) return 0;
/* 472 */     int size = this.headerSize + 1;
/* 473 */     if (this.name != null) {
/* 474 */       size += this.name.length();
/*     */     }
/* 476 */     int remain = size % this.alignmentBoundary;
/* 477 */     if (remain > 0) {
/* 478 */       return this.alignmentBoundary - remain;
/*     */     }
/* 480 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDataPadCount()
/*     */   {
/* 489 */     if (this.alignmentBoundary == 0) return 0;
/* 490 */     long size = this.filesize;
/* 491 */     int remain = (int)(size % this.alignmentBoundary);
/* 492 */     if (remain > 0) {
/* 493 */       return this.alignmentBoundary - remain;
/*     */     }
/* 495 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getInode()
/*     */   {
/* 504 */     return this.inode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMode()
/*     */   {
/* 513 */     return (this.mode == 0L) && (!"TRAILER!!!".equals(this.name)) ? 32768L : this.mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 522 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getNumberOfLinks()
/*     */   {
/* 531 */     return this.nlink == 0L ? 1L : isDirectory() ? 2L : this.nlink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getRemoteDevice()
/*     */   {
/* 545 */     checkOldFormat();
/* 546 */     return this.rmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getRemoteDeviceMaj()
/*     */   {
/* 558 */     checkNewFormat();
/* 559 */     return this.rmaj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getRemoteDeviceMin()
/*     */   {
/* 571 */     checkNewFormat();
/* 572 */     return this.rmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTime()
/*     */   {
/* 581 */     return this.mtime;
/*     */   }
/*     */   
/*     */   public Date getLastModifiedDate() {
/* 585 */     return new Date(1000L * getTime());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getUID()
/*     */   {
/* 594 */     return this.uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBlockDevice()
/*     */   {
/* 603 */     return CpioUtil.fileType(this.mode) == 24576L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCharacterDevice()
/*     */   {
/* 612 */     return CpioUtil.fileType(this.mode) == 8192L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/* 621 */     return CpioUtil.fileType(this.mode) == 16384L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isNetwork()
/*     */   {
/* 630 */     return CpioUtil.fileType(this.mode) == 36864L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isPipe()
/*     */   {
/* 639 */     return CpioUtil.fileType(this.mode) == 4096L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRegularFile()
/*     */   {
/* 648 */     return CpioUtil.fileType(this.mode) == 32768L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSocket()
/*     */   {
/* 657 */     return CpioUtil.fileType(this.mode) == 49152L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSymbolicLink()
/*     */   {
/* 666 */     return CpioUtil.fileType(this.mode) == 40960L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChksum(long chksum)
/*     */   {
/* 677 */     checkNewFormat();
/* 678 */     this.chksum = chksum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDevice(long device)
/*     */   {
/* 691 */     checkOldFormat();
/* 692 */     this.min = device;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeviceMaj(long maj)
/*     */   {
/* 702 */     checkNewFormat();
/* 703 */     this.maj = maj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeviceMin(long min)
/*     */   {
/* 713 */     checkNewFormat();
/* 714 */     this.min = min;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(long size)
/*     */   {
/* 724 */     if ((size < 0L) || (size > 4294967295L)) {
/* 725 */       throw new IllegalArgumentException("invalid entry size <" + size + ">");
/*     */     }
/*     */     
/* 728 */     this.filesize = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGID(long gid)
/*     */   {
/* 738 */     this.gid = gid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInode(long inode)
/*     */   {
/* 748 */     this.inode = inode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMode(long mode)
/*     */   {
/* 758 */     long maskedMode = mode & 0xF000;
/* 759 */     switch ((int)maskedMode) {
/*     */     case 4096: 
/*     */     case 8192: 
/*     */     case 16384: 
/*     */     case 24576: 
/*     */     case 32768: 
/*     */     case 36864: 
/*     */     case 40960: 
/*     */     case 49152: 
/*     */       break;
/*     */     default: 
/* 770 */       throw new IllegalArgumentException("Unknown mode. Full: " + Long.toHexString(mode) + " Masked: " + Long.toHexString(maskedMode));
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/* 776 */     this.mode = mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 786 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumberOfLinks(long nlink)
/*     */   {
/* 796 */     this.nlink = nlink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteDevice(long device)
/*     */   {
/* 809 */     checkOldFormat();
/* 810 */     this.rmin = device;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteDeviceMaj(long rmaj)
/*     */   {
/* 823 */     checkNewFormat();
/* 824 */     this.rmaj = rmaj;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteDeviceMin(long rmin)
/*     */   {
/* 837 */     checkNewFormat();
/* 838 */     this.rmin = rmin;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTime(long time)
/*     */   {
/* 848 */     this.mtime = time;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUID(long uid)
/*     */   {
/* 858 */     this.uid = uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 866 */     int prime = 31;
/* 867 */     int result = 1;
/* 868 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 869 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 877 */     if (this == obj) {
/* 878 */       return true;
/*     */     }
/* 880 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 881 */       return false;
/*     */     }
/* 883 */     CpioArchiveEntry other = (CpioArchiveEntry)obj;
/* 884 */     if (this.name == null) {
/* 885 */       if (other.name != null) {
/* 886 */         return false;
/*     */       }
/* 888 */     } else if (!this.name.equals(other.name)) {
/* 889 */       return false;
/*     */     }
/* 891 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\cpio\CpioArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */