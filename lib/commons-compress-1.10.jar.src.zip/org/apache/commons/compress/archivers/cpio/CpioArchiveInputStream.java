/*     */ package org.apache.commons.compress.archivers.cpio;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
/*     */ import org.apache.commons.compress.utils.ArchiveUtils;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CpioArchiveInputStream
/*     */   extends ArchiveInputStream
/*     */   implements CpioConstants
/*     */ {
/*  70 */   private boolean closed = false;
/*     */   
/*     */   private CpioArchiveEntry entry;
/*     */   
/*  74 */   private long entryBytesRead = 0L;
/*     */   
/*  76 */   private boolean entryEOF = false;
/*     */   
/*  78 */   private final byte[] tmpbuf = new byte['က'];
/*     */   
/*  80 */   private long crc = 0L;
/*     */   
/*     */ 
/*     */   private final InputStream in;
/*     */   
/*  85 */   private final byte[] TWO_BYTES_BUF = new byte[2];
/*  86 */   private final byte[] FOUR_BYTES_BUF = new byte[4];
/*  87 */   private final byte[] SIX_BYTES_BUF = new byte[6];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int blockSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ZipEncoding zipEncoding;
/*     */   
/*     */ 
/*     */ 
/*     */   final String encoding;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveInputStream(InputStream in)
/*     */   {
/* 108 */     this(in, 512, "US-ASCII");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveInputStream(InputStream in, String encoding)
/*     */   {
/* 123 */     this(in, 512, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveInputStream(InputStream in, int blockSize)
/*     */   {
/* 138 */     this(in, blockSize, "US-ASCII");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveInputStream(InputStream in, int blockSize, String encoding)
/*     */   {
/* 154 */     this.in = in;
/* 155 */     this.blockSize = blockSize;
/* 156 */     this.encoding = encoding;
/* 157 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 174 */     ensureOpen();
/* 175 */     if (this.entryEOF) {
/* 176 */       return 0;
/*     */     }
/* 178 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 189 */     if (!this.closed) {
/* 190 */       this.in.close();
/* 191 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void closeEntry()
/*     */     throws IOException
/*     */   {
/* 206 */     while (skip(2147483647L) == 2147483647L) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureOpen()
/*     */     throws IOException
/*     */   {
/* 218 */     if (this.closed) {
/* 219 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CpioArchiveEntry getNextCPIOEntry()
/*     */     throws IOException
/*     */   {
/* 233 */     ensureOpen();
/* 234 */     if (this.entry != null) {
/* 235 */       closeEntry();
/*     */     }
/* 237 */     readFully(this.TWO_BYTES_BUF, 0, this.TWO_BYTES_BUF.length);
/* 238 */     if (CpioUtil.byteArray2long(this.TWO_BYTES_BUF, false) == 29127L) {
/* 239 */       this.entry = readOldBinaryEntry(false);
/* 240 */     } else if (CpioUtil.byteArray2long(this.TWO_BYTES_BUF, true) == 29127L)
/*     */     {
/* 242 */       this.entry = readOldBinaryEntry(true);
/*     */     } else {
/* 244 */       System.arraycopy(this.TWO_BYTES_BUF, 0, this.SIX_BYTES_BUF, 0, this.TWO_BYTES_BUF.length);
/*     */       
/* 246 */       readFully(this.SIX_BYTES_BUF, this.TWO_BYTES_BUF.length, this.FOUR_BYTES_BUF.length);
/*     */       
/* 248 */       String magicString = ArchiveUtils.toAsciiString(this.SIX_BYTES_BUF);
/* 249 */       if (magicString.equals("070701")) {
/* 250 */         this.entry = readNewEntry(false);
/* 251 */       } else if (magicString.equals("070702")) {
/* 252 */         this.entry = readNewEntry(true);
/* 253 */       } else if (magicString.equals("070707")) {
/* 254 */         this.entry = readOldAsciiEntry();
/*     */       } else {
/* 256 */         throw new IOException("Unknown magic [" + magicString + "]. Occured at byte: " + getBytesRead());
/*     */       }
/*     */     }
/*     */     
/* 260 */     this.entryBytesRead = 0L;
/* 261 */     this.entryEOF = false;
/* 262 */     this.crc = 0L;
/*     */     
/* 264 */     if (this.entry.getName().equals("TRAILER!!!")) {
/* 265 */       this.entryEOF = true;
/* 266 */       skipRemainderOfLastBlock();
/* 267 */       return null;
/*     */     }
/* 269 */     return this.entry;
/*     */   }
/*     */   
/*     */   private void skip(int bytes) throws IOException
/*     */   {
/* 274 */     if (bytes > 0) {
/* 275 */       readFully(this.FOUR_BYTES_BUF, 0, bytes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 298 */     ensureOpen();
/* 299 */     if ((off < 0) || (len < 0) || (off > b.length - len))
/* 300 */       throw new IndexOutOfBoundsException();
/* 301 */     if (len == 0) {
/* 302 */       return 0;
/*     */     }
/*     */     
/* 305 */     if ((this.entry == null) || (this.entryEOF)) {
/* 306 */       return -1;
/*     */     }
/* 308 */     if (this.entryBytesRead == this.entry.getSize()) {
/* 309 */       skip(this.entry.getDataPadCount());
/* 310 */       this.entryEOF = true;
/* 311 */       if ((this.entry.getFormat() == 2) && (this.crc != this.entry.getChksum()))
/*     */       {
/* 313 */         throw new IOException("CRC Error. Occured at byte: " + getBytesRead());
/*     */       }
/*     */       
/* 316 */       return -1;
/*     */     }
/* 318 */     int tmplength = (int)Math.min(len, this.entry.getSize() - this.entryBytesRead);
/*     */     
/* 320 */     if (tmplength < 0) {
/* 321 */       return -1;
/*     */     }
/*     */     
/* 324 */     int tmpread = readFully(b, off, tmplength);
/* 325 */     if (this.entry.getFormat() == 2) {
/* 326 */       for (int pos = 0; pos < tmpread; pos++) {
/* 327 */         this.crc += (b[pos] & 0xFF);
/*     */       }
/*     */     }
/* 330 */     this.entryBytesRead += tmpread;
/*     */     
/* 332 */     return tmpread;
/*     */   }
/*     */   
/*     */   private final int readFully(byte[] b, int off, int len) throws IOException
/*     */   {
/* 337 */     int count = IOUtils.readFully(this.in, b, off, len);
/* 338 */     count(count);
/* 339 */     if (count < len) {
/* 340 */       throw new EOFException();
/*     */     }
/* 342 */     return count;
/*     */   }
/*     */   
/*     */   private long readBinaryLong(int length, boolean swapHalfWord) throws IOException
/*     */   {
/* 347 */     byte[] tmp = new byte[length];
/* 348 */     readFully(tmp, 0, tmp.length);
/* 349 */     return CpioUtil.byteArray2long(tmp, swapHalfWord);
/*     */   }
/*     */   
/*     */   private long readAsciiLong(int length, int radix) throws IOException
/*     */   {
/* 354 */     byte[] tmpBuffer = new byte[length];
/* 355 */     readFully(tmpBuffer, 0, tmpBuffer.length);
/* 356 */     return Long.parseLong(ArchiveUtils.toAsciiString(tmpBuffer), radix);
/*     */   }
/*     */   
/*     */   private CpioArchiveEntry readNewEntry(boolean hasCrc) throws IOException {
/*     */     CpioArchiveEntry ret;
/*     */     CpioArchiveEntry ret;
/* 362 */     if (hasCrc) {
/* 363 */       ret = new CpioArchiveEntry((short)2);
/*     */     } else {
/* 365 */       ret = new CpioArchiveEntry((short)1);
/*     */     }
/*     */     
/* 368 */     ret.setInode(readAsciiLong(8, 16));
/* 369 */     long mode = readAsciiLong(8, 16);
/* 370 */     if (CpioUtil.fileType(mode) != 0L) {
/* 371 */       ret.setMode(mode);
/*     */     }
/* 373 */     ret.setUID(readAsciiLong(8, 16));
/* 374 */     ret.setGID(readAsciiLong(8, 16));
/* 375 */     ret.setNumberOfLinks(readAsciiLong(8, 16));
/* 376 */     ret.setTime(readAsciiLong(8, 16));
/* 377 */     ret.setSize(readAsciiLong(8, 16));
/* 378 */     ret.setDeviceMaj(readAsciiLong(8, 16));
/* 379 */     ret.setDeviceMin(readAsciiLong(8, 16));
/* 380 */     ret.setRemoteDeviceMaj(readAsciiLong(8, 16));
/* 381 */     ret.setRemoteDeviceMin(readAsciiLong(8, 16));
/* 382 */     long namesize = readAsciiLong(8, 16);
/* 383 */     ret.setChksum(readAsciiLong(8, 16));
/* 384 */     String name = readCString((int)namesize);
/* 385 */     ret.setName(name);
/* 386 */     if ((CpioUtil.fileType(mode) == 0L) && (!name.equals("TRAILER!!!"))) {
/* 387 */       throw new IOException("Mode 0 only allowed in the trailer. Found entry name: " + name + " Occured at byte: " + getBytesRead());
/*     */     }
/* 389 */     skip(ret.getHeaderPadCount());
/*     */     
/* 391 */     return ret;
/*     */   }
/*     */   
/*     */   private CpioArchiveEntry readOldAsciiEntry() throws IOException {
/* 395 */     CpioArchiveEntry ret = new CpioArchiveEntry((short)4);
/*     */     
/* 397 */     ret.setDevice(readAsciiLong(6, 8));
/* 398 */     ret.setInode(readAsciiLong(6, 8));
/* 399 */     long mode = readAsciiLong(6, 8);
/* 400 */     if (CpioUtil.fileType(mode) != 0L) {
/* 401 */       ret.setMode(mode);
/*     */     }
/* 403 */     ret.setUID(readAsciiLong(6, 8));
/* 404 */     ret.setGID(readAsciiLong(6, 8));
/* 405 */     ret.setNumberOfLinks(readAsciiLong(6, 8));
/* 406 */     ret.setRemoteDevice(readAsciiLong(6, 8));
/* 407 */     ret.setTime(readAsciiLong(11, 8));
/* 408 */     long namesize = readAsciiLong(6, 8);
/* 409 */     ret.setSize(readAsciiLong(11, 8));
/* 410 */     String name = readCString((int)namesize);
/* 411 */     ret.setName(name);
/* 412 */     if ((CpioUtil.fileType(mode) == 0L) && (!name.equals("TRAILER!!!"))) {
/* 413 */       throw new IOException("Mode 0 only allowed in the trailer. Found entry: " + name + " Occured at byte: " + getBytesRead());
/*     */     }
/*     */     
/* 416 */     return ret;
/*     */   }
/*     */   
/*     */   private CpioArchiveEntry readOldBinaryEntry(boolean swapHalfWord) throws IOException
/*     */   {
/* 421 */     CpioArchiveEntry ret = new CpioArchiveEntry((short)8);
/*     */     
/* 423 */     ret.setDevice(readBinaryLong(2, swapHalfWord));
/* 424 */     ret.setInode(readBinaryLong(2, swapHalfWord));
/* 425 */     long mode = readBinaryLong(2, swapHalfWord);
/* 426 */     if (CpioUtil.fileType(mode) != 0L) {
/* 427 */       ret.setMode(mode);
/*     */     }
/* 429 */     ret.setUID(readBinaryLong(2, swapHalfWord));
/* 430 */     ret.setGID(readBinaryLong(2, swapHalfWord));
/* 431 */     ret.setNumberOfLinks(readBinaryLong(2, swapHalfWord));
/* 432 */     ret.setRemoteDevice(readBinaryLong(2, swapHalfWord));
/* 433 */     ret.setTime(readBinaryLong(4, swapHalfWord));
/* 434 */     long namesize = readBinaryLong(2, swapHalfWord);
/* 435 */     ret.setSize(readBinaryLong(4, swapHalfWord));
/* 436 */     String name = readCString((int)namesize);
/* 437 */     ret.setName(name);
/* 438 */     if ((CpioUtil.fileType(mode) == 0L) && (!name.equals("TRAILER!!!"))) {
/* 439 */       throw new IOException("Mode 0 only allowed in the trailer. Found entry: " + name + "Occured at byte: " + getBytesRead());
/*     */     }
/* 441 */     skip(ret.getHeaderPadCount());
/*     */     
/* 443 */     return ret;
/*     */   }
/*     */   
/*     */   private String readCString(int length) throws IOException
/*     */   {
/* 448 */     byte[] tmpBuffer = new byte[length - 1];
/* 449 */     readFully(tmpBuffer, 0, tmpBuffer.length);
/* 450 */     this.in.read();
/* 451 */     return this.zipEncoding.decode(tmpBuffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 467 */     if (n < 0L) {
/* 468 */       throw new IllegalArgumentException("negative skip length");
/*     */     }
/* 470 */     ensureOpen();
/* 471 */     int max = (int)Math.min(n, 2147483647L);
/* 472 */     int total = 0;
/*     */     
/* 474 */     while (total < max) {
/* 475 */       int len = max - total;
/* 476 */       if (len > this.tmpbuf.length) {
/* 477 */         len = this.tmpbuf.length;
/*     */       }
/* 479 */       len = read(this.tmpbuf, 0, len);
/* 480 */       if (len == -1) {
/* 481 */         this.entryEOF = true;
/* 482 */         break;
/*     */       }
/* 484 */       total += len;
/*     */     }
/* 486 */     return total;
/*     */   }
/*     */   
/*     */   public ArchiveEntry getNextEntry() throws IOException
/*     */   {
/* 491 */     return getNextCPIOEntry();
/*     */   }
/*     */   
/*     */ 
/*     */   private void skipRemainderOfLastBlock()
/*     */     throws IOException
/*     */   {
/* 498 */     long readFromLastBlock = getBytesRead() % this.blockSize;
/* 499 */     long remainingBytes = readFromLastBlock == 0L ? 0L : this.blockSize - readFromLastBlock;
/*     */     
/* 501 */     while (remainingBytes > 0L) {
/* 502 */       long skipped = skip(this.blockSize - readFromLastBlock);
/* 503 */       if (skipped <= 0L) {
/*     */         break;
/*     */       }
/* 506 */       remainingBytes -= skipped;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 527 */     if (length < 6) {
/* 528 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 532 */     if ((signature[0] == 113) && ((signature[1] & 0xFF) == 199)) {
/* 533 */       return true;
/*     */     }
/* 535 */     if ((signature[1] == 113) && ((signature[0] & 0xFF) == 199)) {
/* 536 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 541 */     if (signature[0] != 48) {
/* 542 */       return false;
/*     */     }
/* 544 */     if (signature[1] != 55) {
/* 545 */       return false;
/*     */     }
/* 547 */     if (signature[2] != 48) {
/* 548 */       return false;
/*     */     }
/* 550 */     if (signature[3] != 55) {
/* 551 */       return false;
/*     */     }
/* 553 */     if (signature[4] != 48) {
/* 554 */       return false;
/*     */     }
/*     */     
/* 557 */     if (signature[5] == 49) {
/* 558 */       return true;
/*     */     }
/* 560 */     if (signature[5] == 50) {
/* 561 */       return true;
/*     */     }
/* 563 */     if (signature[5] == 55) {
/* 564 */       return true;
/*     */     }
/*     */     
/* 567 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\cpio\CpioArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */