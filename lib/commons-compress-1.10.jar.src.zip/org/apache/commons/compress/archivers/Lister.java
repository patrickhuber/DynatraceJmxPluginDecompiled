/*    */ package org.apache.commons.compress.archivers;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Lister
/*    */ {
/* 35 */   private static final ArchiveStreamFactory factory = new ArchiveStreamFactory();
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 38 */     if (args.length == 0) {
/* 39 */       usage();
/* 40 */       return;
/*    */     }
/* 42 */     System.out.println("Analysing " + args[0]);
/* 43 */     File f = new File(args[0]);
/* 44 */     if (!f.isFile()) {
/* 45 */       System.err.println(f + " doesn't exist or is a directory");
/*    */     }
/* 47 */     InputStream fis = new BufferedInputStream(new FileInputStream(f));
/*    */     ArchiveInputStream ais;
/* 49 */     ArchiveInputStream ais; if (args.length > 1) {
/* 50 */       ais = factory.createArchiveInputStream(args[1], fis);
/*    */     } else {
/* 52 */       ais = factory.createArchiveInputStream(fis);
/*    */     }
/* 54 */     System.out.println("Created " + ais.toString());
/*    */     ArchiveEntry ae;
/* 56 */     while ((ae = ais.getNextEntry()) != null) {
/* 57 */       System.out.println(ae.getName());
/*    */     }
/* 59 */     ais.close();
/* 60 */     fis.close();
/*    */   }
/*    */   
/*    */   private static void usage() {
/* 64 */     System.out.println("Parameters: archive-name [archive-type]");
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\Lister.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */