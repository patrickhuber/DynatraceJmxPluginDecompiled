/*    */ package org.apache.commons.compress.archivers.jar;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*    */ import org.apache.commons.compress.archivers.zip.JarMarker;
/*    */ import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
/*    */ import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarArchiveOutputStream
/*    */   extends ZipArchiveOutputStream
/*    */ {
/* 38 */   private boolean jarMarkerAdded = false;
/*    */   
/*    */   public JarArchiveOutputStream(OutputStream out) {
/* 41 */     super(out);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JarArchiveOutputStream(OutputStream out, String encoding)
/*    */   {
/* 52 */     super(out);
/* 53 */     setEncoding(encoding);
/*    */   }
/*    */   
/*    */   public void putArchiveEntry(ArchiveEntry ze)
/*    */     throws IOException
/*    */   {
/* 59 */     if (!this.jarMarkerAdded) {
/* 60 */       ((ZipArchiveEntry)ze).addAsFirstExtraField(JarMarker.getInstance());
/* 61 */       this.jarMarkerAdded = true;
/*    */     }
/* 63 */     super.putArchiveEntry(ze);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\jar\JarArchiveOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */