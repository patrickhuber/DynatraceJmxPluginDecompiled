/*    */ package org.apache.commons.compress.archivers.jar;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*    */ import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
/*    */ import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarArchiveInputStream
/*    */   extends ZipArchiveInputStream
/*    */ {
/*    */   public JarArchiveInputStream(InputStream inputStream)
/*    */   {
/* 41 */     super(inputStream);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JarArchiveInputStream(InputStream inputStream, String encoding)
/*    */   {
/* 52 */     super(inputStream, encoding);
/*    */   }
/*    */   
/*    */   public JarArchiveEntry getNextJarEntry() throws IOException {
/* 56 */     ZipArchiveEntry entry = getNextZipEntry();
/* 57 */     return entry == null ? null : new JarArchiveEntry(entry);
/*    */   }
/*    */   
/*    */   public ArchiveEntry getNextEntry() throws IOException
/*    */   {
/* 62 */     return getNextJarEntry();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static boolean matches(byte[] signature, int length)
/*    */   {
/* 76 */     return ZipArchiveInputStream.matches(signature, length);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\jar\JarArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */