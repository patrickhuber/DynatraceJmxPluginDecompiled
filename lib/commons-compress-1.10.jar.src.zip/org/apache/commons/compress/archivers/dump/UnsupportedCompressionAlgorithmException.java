/*    */ package org.apache.commons.compress.archivers.dump;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsupportedCompressionAlgorithmException
/*    */   extends DumpArchiveException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnsupportedCompressionAlgorithmException()
/*    */   {
/* 31 */     super("this file uses an unsupported compression algorithm.");
/*    */   }
/*    */   
/*    */   public UnsupportedCompressionAlgorithmException(String alg) {
/* 35 */     super("this file uses an unsupported compression algorithm: " + alg + ".");
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\dump\UnsupportedCompressionAlgorithmException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */