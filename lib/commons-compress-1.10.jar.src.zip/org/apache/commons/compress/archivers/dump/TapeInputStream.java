/*     */ package org.apache.commons.compress.archivers.dump;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TapeInputStream
/*     */   extends FilterInputStream
/*     */ {
/*  38 */   private byte[] blockBuffer = new byte['Ѐ'];
/*  39 */   private int currBlkIdx = -1;
/*  40 */   private int blockSize = 1024;
/*     */   private static final int recordSize = 1024;
/*  42 */   private int readOffset = 1024;
/*  43 */   private boolean isCompressed = false;
/*  44 */   private long bytesRead = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */   public TapeInputStream(InputStream in)
/*     */   {
/*  50 */     super(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetBlockSize(int recsPerBlock, boolean isCompressed)
/*     */     throws IOException
/*     */   {
/*  69 */     this.isCompressed = isCompressed;
/*     */     
/*  71 */     this.blockSize = (1024 * recsPerBlock);
/*     */     
/*     */ 
/*  74 */     byte[] oldBuffer = this.blockBuffer;
/*     */     
/*     */ 
/*  77 */     this.blockBuffer = new byte[this.blockSize];
/*  78 */     System.arraycopy(oldBuffer, 0, this.blockBuffer, 0, 1024);
/*  79 */     readFully(this.blockBuffer, 1024, this.blockSize - 1024);
/*     */     
/*  81 */     this.currBlkIdx = 0;
/*  82 */     this.readOffset = 1024;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/*  90 */     if (this.readOffset < this.blockSize) {
/*  91 */       return this.blockSize - this.readOffset;
/*     */     }
/*     */     
/*  94 */     return this.in.available();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 102 */     throw new IllegalArgumentException("all reads must be multiple of record size (1024 bytes.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 117 */     if (len % 1024 != 0) {
/* 118 */       throw new IllegalArgumentException("all reads must be multiple of record size (1024 bytes.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 123 */     int bytes = 0;
/*     */     
/* 125 */     while (bytes < len)
/*     */     {
/*     */ 
/*     */ 
/* 129 */       if ((this.readOffset == this.blockSize) && (!readBlock(true))) {
/* 130 */         return -1;
/*     */       }
/*     */       
/* 133 */       int n = 0;
/*     */       
/* 135 */       if (this.readOffset + (len - bytes) <= this.blockSize)
/*     */       {
/* 137 */         n = len - bytes;
/*     */       }
/*     */       else {
/* 140 */         n = this.blockSize - this.readOffset;
/*     */       }
/*     */       
/*     */ 
/* 144 */       System.arraycopy(this.blockBuffer, this.readOffset, b, off, n);
/* 145 */       this.readOffset += n;
/* 146 */       bytes += n;
/* 147 */       off += n;
/*     */     }
/*     */     
/* 150 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long len)
/*     */     throws IOException
/*     */   {
/* 163 */     if (len % 1024L != 0L) {
/* 164 */       throw new IllegalArgumentException("all reads must be multiple of record size (1024 bytes.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 169 */     long bytes = 0L;
/*     */     
/* 171 */     while (bytes < len)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 176 */       if (this.readOffset == this.blockSize) { if (!readBlock(len - bytes < this.blockSize))
/*     */         {
/* 178 */           return -1L;
/*     */         }
/*     */       }
/* 181 */       long n = 0L;
/*     */       
/* 183 */       if (this.readOffset + (len - bytes) <= this.blockSize)
/*     */       {
/* 185 */         n = len - bytes;
/*     */       }
/*     */       else {
/* 188 */         n = this.blockSize - this.readOffset;
/*     */       }
/*     */       
/*     */ 
/* 192 */       this.readOffset = ((int)(this.readOffset + n));
/* 193 */       bytes += n;
/*     */     }
/*     */     
/* 196 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 206 */     if ((this.in != null) && (this.in != System.in)) {
/* 207 */       this.in.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] peek()
/*     */     throws IOException
/*     */   {
/* 221 */     if ((this.readOffset == this.blockSize) && (!readBlock(true))) {
/* 222 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 226 */     byte[] b = new byte['Ѐ'];
/* 227 */     System.arraycopy(this.blockBuffer, this.readOffset, b, 0, b.length);
/*     */     
/* 229 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] readRecord()
/*     */     throws IOException
/*     */   {
/* 239 */     byte[] result = new byte['Ѐ'];
/*     */     
/*     */ 
/*     */ 
/* 243 */     if (-1 == read(result, 0, result.length)) {
/* 244 */       throw new ShortFileException();
/*     */     }
/*     */     
/* 247 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean readBlock(boolean decompress)
/*     */     throws IOException
/*     */   {
/* 258 */     boolean success = true;
/*     */     
/* 260 */     if (this.in == null) {
/* 261 */       throw new IOException("input buffer is closed");
/*     */     }
/*     */     
/* 264 */     if ((!this.isCompressed) || (this.currBlkIdx == -1))
/*     */     {
/* 266 */       success = readFully(this.blockBuffer, 0, this.blockSize);
/* 267 */       this.bytesRead += this.blockSize;
/*     */     } else {
/* 269 */       if (!readFully(this.blockBuffer, 0, 4)) {
/* 270 */         return false;
/*     */       }
/* 272 */       this.bytesRead += 4L;
/*     */       
/* 274 */       int h = DumpArchiveUtil.convert32(this.blockBuffer, 0);
/* 275 */       boolean compressed = (h & 0x1) == 1;
/*     */       
/* 277 */       if (!compressed)
/*     */       {
/* 279 */         success = readFully(this.blockBuffer, 0, this.blockSize);
/* 280 */         this.bytesRead += this.blockSize;
/*     */       }
/*     */       else {
/* 283 */         int flags = h >> 1 & 0x7;
/* 284 */         int length = h >> 4 & 0xFFFFFFF;
/* 285 */         byte[] compBuffer = new byte[length];
/* 286 */         success = readFully(compBuffer, 0, length);
/* 287 */         this.bytesRead += length;
/*     */         
/* 289 */         if (!decompress)
/*     */         {
/* 291 */           Arrays.fill(this.blockBuffer, (byte)0);
/*     */         } else {
/* 293 */           switch (DumpArchiveConstants.COMPRESSION_TYPE.find(flags & 0x3))
/*     */           {
/*     */           case ZLIB: 
/*     */             try
/*     */             {
/* 298 */               Inflater inflator = new Inflater();
/* 299 */               inflator.setInput(compBuffer, 0, compBuffer.length);
/* 300 */               length = inflator.inflate(this.blockBuffer);
/*     */               
/* 302 */               if (length != this.blockSize) {
/* 303 */                 throw new ShortFileException();
/*     */               }
/*     */               
/* 306 */               inflator.end();
/*     */             } catch (DataFormatException e) {
/* 308 */               throw new DumpArchiveException("bad data", e);
/*     */             }
/*     */           
/*     */ 
/*     */ 
/*     */           case BZLIB: 
/* 314 */             throw new UnsupportedCompressionAlgorithmException("BZLIB2");
/*     */           
/*     */ 
/*     */           case LZO: 
/* 318 */             throw new UnsupportedCompressionAlgorithmException("LZO");
/*     */           
/*     */ 
/*     */           default: 
/* 322 */             throw new UnsupportedCompressionAlgorithmException();
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */     }
/* 328 */     this.currBlkIdx += 1;
/* 329 */     this.readOffset = 0;
/*     */     
/* 331 */     return success;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean readFully(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 339 */     int count = IOUtils.readFully(this.in, b, off, len);
/* 340 */     if (count < len) {
/* 341 */       throw new ShortFileException();
/*     */     }
/*     */     
/* 344 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getBytesRead()
/*     */   {
/* 351 */     return this.bytesRead;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\dump\TapeInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */