/*    */ package org.apache.commons.compress.archivers.dump;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidFormatException
/*    */   extends DumpArchiveException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected long offset;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidFormatException()
/*    */   {
/* 31 */     super("there was an error decoding a tape segment");
/*    */   }
/*    */   
/*    */   public InvalidFormatException(long offset) {
/* 35 */     super("there was an error decoding a tape segment header at offset " + offset + ".");
/*    */     
/* 37 */     this.offset = offset;
/*    */   }
/*    */   
/*    */   public long getOffset() {
/* 41 */     return this.offset;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\dump\InvalidFormatException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */