/*     */ package org.apache.commons.compress.archivers.dump;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.Queue;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.compress.archivers.ArchiveException;
/*     */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncodingHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DumpArchiveInputStream
/*     */   extends ArchiveInputStream
/*     */ {
/*     */   private DumpArchiveSummary summary;
/*     */   private DumpArchiveEntry active;
/*     */   private boolean isClosed;
/*     */   private boolean hasHitEOF;
/*     */   private long entrySize;
/*     */   private long entryOffset;
/*     */   private int readIdx;
/*  59 */   private final byte[] readBuf = new byte['Ѐ'];
/*     */   
/*     */   private byte[] blockBuffer;
/*     */   
/*     */   private int recordOffset;
/*     */   private long filepos;
/*     */   protected TapeInputStream raw;
/*  66 */   private final Map<Integer, Dirent> names = new HashMap();
/*     */   
/*     */ 
/*  69 */   private final Map<Integer, DumpArchiveEntry> pending = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Queue<DumpArchiveEntry> queue;
/*     */   
/*     */ 
/*     */ 
/*     */   private final ZipEncoding zipEncoding;
/*     */   
/*     */ 
/*     */ 
/*     */   final String encoding;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DumpArchiveInputStream(InputStream is)
/*     */     throws ArchiveException
/*     */   {
/*  90 */     this(is, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DumpArchiveInputStream(InputStream is, String encoding)
/*     */     throws ArchiveException
/*     */   {
/* 104 */     this.raw = new TapeInputStream(is);
/* 105 */     this.hasHitEOF = false;
/* 106 */     this.encoding = encoding;
/* 107 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*     */     
/*     */     try
/*     */     {
/* 111 */       byte[] headerBytes = this.raw.readRecord();
/*     */       
/* 113 */       if (!DumpArchiveUtil.verify(headerBytes)) {
/* 114 */         throw new UnrecognizedFormatException();
/*     */       }
/*     */       
/*     */ 
/* 118 */       this.summary = new DumpArchiveSummary(headerBytes, this.zipEncoding);
/*     */       
/*     */ 
/* 121 */       this.raw.resetBlockSize(this.summary.getNTRec(), this.summary.isCompressed());
/*     */       
/*     */ 
/* 124 */       this.blockBuffer = new byte['က'];
/*     */       
/*     */ 
/* 127 */       readCLRI();
/* 128 */       readBITS();
/*     */     } catch (IOException ex) {
/* 130 */       throw new ArchiveException(ex.getMessage(), ex);
/*     */     }
/*     */     
/*     */ 
/* 134 */     Dirent root = new Dirent(2, 2, 4, ".");
/* 135 */     this.names.put(Integer.valueOf(2), root);
/*     */     
/*     */ 
/*     */ 
/* 139 */     this.queue = new PriorityQueue(10, new Comparator()
/*     */     {
/*     */       public int compare(DumpArchiveEntry p, DumpArchiveEntry q) {
/* 142 */         if ((p.getOriginalName() == null) || (q.getOriginalName() == null)) {
/* 143 */           return Integer.MAX_VALUE;
/*     */         }
/*     */         
/* 146 */         return p.getOriginalName().compareTo(q.getOriginalName());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public int getCount()
/*     */   {
/* 154 */     return (int)getBytesRead();
/*     */   }
/*     */   
/*     */   public long getBytesRead()
/*     */   {
/* 159 */     return this.raw.getBytesRead();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DumpArchiveSummary getSummary()
/*     */   {
/* 167 */     return this.summary;
/*     */   }
/*     */   
/*     */ 
/*     */   private void readCLRI()
/*     */     throws IOException
/*     */   {
/* 174 */     byte[] buffer = this.raw.readRecord();
/*     */     
/* 176 */     if (!DumpArchiveUtil.verify(buffer)) {
/* 177 */       throw new InvalidFormatException();
/*     */     }
/*     */     
/* 180 */     this.active = DumpArchiveEntry.parse(buffer);
/*     */     
/* 182 */     if (DumpArchiveConstants.SEGMENT_TYPE.CLRI != this.active.getHeaderType()) {
/* 183 */       throw new InvalidFormatException();
/*     */     }
/*     */     
/*     */ 
/* 187 */     if (this.raw.skip(1024 * this.active.getHeaderCount()) == -1L)
/*     */     {
/* 189 */       throw new EOFException();
/*     */     }
/* 191 */     this.readIdx = this.active.getHeaderCount();
/*     */   }
/*     */   
/*     */ 
/*     */   private void readBITS()
/*     */     throws IOException
/*     */   {
/* 198 */     byte[] buffer = this.raw.readRecord();
/*     */     
/* 200 */     if (!DumpArchiveUtil.verify(buffer)) {
/* 201 */       throw new InvalidFormatException();
/*     */     }
/*     */     
/* 204 */     this.active = DumpArchiveEntry.parse(buffer);
/*     */     
/* 206 */     if (DumpArchiveConstants.SEGMENT_TYPE.BITS != this.active.getHeaderType()) {
/* 207 */       throw new InvalidFormatException();
/*     */     }
/*     */     
/*     */ 
/* 211 */     if (this.raw.skip(1024 * this.active.getHeaderCount()) == -1L)
/*     */     {
/* 213 */       throw new EOFException();
/*     */     }
/* 215 */     this.readIdx = this.active.getHeaderCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DumpArchiveEntry getNextDumpEntry()
/*     */     throws IOException
/*     */   {
/* 224 */     return getNextEntry();
/*     */   }
/*     */   
/*     */   public DumpArchiveEntry getNextEntry() throws IOException
/*     */   {
/* 229 */     DumpArchiveEntry entry = null;
/* 230 */     String path = null;
/*     */     
/*     */ 
/* 233 */     if (!this.queue.isEmpty()) {
/* 234 */       return (DumpArchiveEntry)this.queue.remove();
/*     */     }
/*     */     
/* 237 */     while (entry == null) {
/* 238 */       if (this.hasHitEOF) {
/* 239 */         return null;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */       while (this.readIdx < this.active.getHeaderCount()) {
/* 247 */         if ((!this.active.isSparseRecord(this.readIdx++)) && (this.raw.skip(1024L) == -1L))
/*     */         {
/* 249 */           throw new EOFException();
/*     */         }
/*     */       }
/*     */       
/* 253 */       this.readIdx = 0;
/* 254 */       this.filepos = this.raw.getBytesRead();
/*     */       
/* 256 */       byte[] headerBytes = this.raw.readRecord();
/*     */       
/* 258 */       if (!DumpArchiveUtil.verify(headerBytes)) {
/* 259 */         throw new InvalidFormatException();
/*     */       }
/*     */       
/* 262 */       this.active = DumpArchiveEntry.parse(headerBytes);
/*     */       
/*     */ 
/* 265 */       while (DumpArchiveConstants.SEGMENT_TYPE.ADDR == this.active.getHeaderType()) {
/* 266 */         if (this.raw.skip(1024 * (this.active.getHeaderCount() - this.active.getHeaderHoles())) == -1L)
/*     */         {
/*     */ 
/* 269 */           throw new EOFException();
/*     */         }
/*     */         
/* 272 */         this.filepos = this.raw.getBytesRead();
/* 273 */         headerBytes = this.raw.readRecord();
/*     */         
/* 275 */         if (!DumpArchiveUtil.verify(headerBytes)) {
/* 276 */           throw new InvalidFormatException();
/*     */         }
/*     */         
/* 279 */         this.active = DumpArchiveEntry.parse(headerBytes);
/*     */       }
/*     */       
/*     */ 
/* 283 */       if (DumpArchiveConstants.SEGMENT_TYPE.END == this.active.getHeaderType()) {
/* 284 */         this.hasHitEOF = true;
/*     */         
/* 286 */         return null;
/*     */       }
/*     */       
/* 289 */       entry = this.active;
/*     */       
/* 291 */       if (entry.isDirectory()) {
/* 292 */         readDirectoryEntry(this.active);
/*     */         
/*     */ 
/* 295 */         this.entryOffset = 0L;
/* 296 */         this.entrySize = 0L;
/* 297 */         this.readIdx = this.active.getHeaderCount();
/*     */       } else {
/* 299 */         this.entryOffset = 0L;
/* 300 */         this.entrySize = this.active.getEntrySize();
/* 301 */         this.readIdx = 0;
/*     */       }
/*     */       
/* 304 */       this.recordOffset = this.readBuf.length;
/*     */       
/* 306 */       path = getPath(entry);
/*     */       
/* 308 */       if (path == null) {
/* 309 */         entry = null;
/*     */       }
/*     */     }
/*     */     
/* 313 */     entry.setName(path);
/* 314 */     entry.setSimpleName(((Dirent)this.names.get(Integer.valueOf(entry.getIno()))).getName());
/* 315 */     entry.setOffset(this.filepos);
/*     */     
/* 317 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void readDirectoryEntry(DumpArchiveEntry entry)
/*     */     throws IOException
/*     */   {
/* 325 */     long size = entry.getEntrySize();
/* 326 */     boolean first = true;
/*     */     
/* 328 */     while ((first) || (DumpArchiveConstants.SEGMENT_TYPE.ADDR == entry.getHeaderType()))
/*     */     {
/*     */ 
/* 331 */       if (!first) {
/* 332 */         this.raw.readRecord();
/*     */       }
/*     */       
/* 335 */       if ((!this.names.containsKey(Integer.valueOf(entry.getIno()))) && (DumpArchiveConstants.SEGMENT_TYPE.INODE == entry.getHeaderType()))
/*     */       {
/* 337 */         this.pending.put(Integer.valueOf(entry.getIno()), entry);
/*     */       }
/*     */       
/* 340 */       int datalen = 1024 * entry.getHeaderCount();
/*     */       
/* 342 */       if (this.blockBuffer.length < datalen) {
/* 343 */         this.blockBuffer = new byte[datalen];
/*     */       }
/*     */       
/* 346 */       if (this.raw.read(this.blockBuffer, 0, datalen) != datalen) {
/* 347 */         throw new EOFException();
/*     */       }
/*     */       
/* 350 */       int reclen = 0;
/*     */       
/* 352 */       for (int i = 0; (i < datalen - 8) && (i < size - 8L); 
/* 353 */           i += reclen) {
/* 354 */         int ino = DumpArchiveUtil.convert32(this.blockBuffer, i);
/* 355 */         reclen = DumpArchiveUtil.convert16(this.blockBuffer, i + 4);
/*     */         
/* 357 */         byte type = this.blockBuffer[(i + 6)];
/*     */         
/* 359 */         String name = DumpArchiveUtil.decode(this.zipEncoding, this.blockBuffer, i + 8, this.blockBuffer[(i + 7)]);
/*     */         
/* 361 */         if ((!".".equals(name)) && (!"..".equals(name)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 366 */           Dirent d = new Dirent(ino, entry.getIno(), type, name);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 375 */           this.names.put(Integer.valueOf(ino), d);
/*     */           
/*     */ 
/* 378 */           for (Map.Entry<Integer, DumpArchiveEntry> e : this.pending.entrySet()) {
/* 379 */             String path = getPath((DumpArchiveEntry)e.getValue());
/*     */             
/* 381 */             if (path != null) {
/* 382 */               ((DumpArchiveEntry)e.getValue()).setName(path);
/* 383 */               ((DumpArchiveEntry)e.getValue()).setSimpleName(((Dirent)this.names.get(e.getKey())).getName());
/*     */               
/* 385 */               this.queue.add(e.getValue());
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/* 391 */           for (DumpArchiveEntry e : this.queue) {
/* 392 */             this.pending.remove(Integer.valueOf(e.getIno()));
/*     */           }
/*     */         }
/*     */       }
/* 396 */       byte[] peekBytes = this.raw.peek();
/*     */       
/* 398 */       if (!DumpArchiveUtil.verify(peekBytes)) {
/* 399 */         throw new InvalidFormatException();
/*     */       }
/*     */       
/* 402 */       entry = DumpArchiveEntry.parse(peekBytes);
/* 403 */       first = false;
/* 404 */       size -= 1024L;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getPath(DumpArchiveEntry entry)
/*     */   {
/* 417 */     Stack<String> elements = new Stack();
/* 418 */     Dirent dirent = null;
/*     */     
/* 420 */     for (int i = entry.getIno();; i = dirent.getParentIno()) {
/* 421 */       if (!this.names.containsKey(Integer.valueOf(i))) {
/* 422 */         elements.clear();
/*     */       }
/*     */       else
/*     */       {
/* 426 */         dirent = (Dirent)this.names.get(Integer.valueOf(i));
/* 427 */         elements.push(dirent.getName());
/*     */         
/* 429 */         if (dirent.getIno() == dirent.getParentIno()) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 435 */     if (elements.isEmpty()) {
/* 436 */       this.pending.put(Integer.valueOf(entry.getIno()), entry);
/*     */       
/* 438 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 442 */     StringBuilder sb = new StringBuilder((String)elements.pop());
/*     */     
/* 444 */     while (!elements.isEmpty()) {
/* 445 */       sb.append('/');
/* 446 */       sb.append((String)elements.pop());
/*     */     }
/*     */     
/* 449 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 467 */     int totalRead = 0;
/*     */     
/* 469 */     if ((this.hasHitEOF) || (this.isClosed) || (this.entryOffset >= this.entrySize)) {
/* 470 */       return -1;
/*     */     }
/*     */     
/* 473 */     if (this.active == null) {
/* 474 */       throw new IllegalStateException("No current dump entry");
/*     */     }
/*     */     
/* 477 */     if (len + this.entryOffset > this.entrySize) {
/* 478 */       len = (int)(this.entrySize - this.entryOffset);
/*     */     }
/*     */     
/* 481 */     while (len > 0) {
/* 482 */       int sz = len > this.readBuf.length - this.recordOffset ? this.readBuf.length - this.recordOffset : len;
/*     */       
/*     */ 
/*     */ 
/* 486 */       if (this.recordOffset + sz <= this.readBuf.length) {
/* 487 */         System.arraycopy(this.readBuf, this.recordOffset, buf, off, sz);
/* 488 */         totalRead += sz;
/* 489 */         this.recordOffset += sz;
/* 490 */         len -= sz;
/* 491 */         off += sz;
/*     */       }
/*     */       
/*     */ 
/* 495 */       if (len > 0) {
/* 496 */         if (this.readIdx >= 512) {
/* 497 */           byte[] headerBytes = this.raw.readRecord();
/*     */           
/* 499 */           if (!DumpArchiveUtil.verify(headerBytes)) {
/* 500 */             throw new InvalidFormatException();
/*     */           }
/*     */           
/* 503 */           this.active = DumpArchiveEntry.parse(headerBytes);
/* 504 */           this.readIdx = 0;
/*     */         }
/*     */         
/* 507 */         if (!this.active.isSparseRecord(this.readIdx++)) {
/* 508 */           int r = this.raw.read(this.readBuf, 0, this.readBuf.length);
/* 509 */           if (r != this.readBuf.length) {
/* 510 */             throw new EOFException();
/*     */           }
/*     */         } else {
/* 513 */           Arrays.fill(this.readBuf, (byte)0);
/*     */         }
/*     */         
/* 516 */         this.recordOffset = 0;
/*     */       }
/*     */     }
/*     */     
/* 520 */     this.entryOffset += totalRead;
/*     */     
/* 522 */     return totalRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 530 */     if (!this.isClosed) {
/* 531 */       this.isClosed = true;
/* 532 */       this.raw.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] buffer, int length)
/*     */   {
/* 546 */     if (length < 32) {
/* 547 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 551 */     if (length >= 1024) {
/* 552 */       return DumpArchiveUtil.verify(buffer);
/*     */     }
/*     */     
/*     */ 
/* 556 */     return 60012 == DumpArchiveUtil.convert32(buffer, 24);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\dump\DumpArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */