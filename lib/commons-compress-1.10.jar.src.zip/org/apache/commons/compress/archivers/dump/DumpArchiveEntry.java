/*     */ package org.apache.commons.compress.archivers.dump;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DumpArchiveEntry
/*     */   implements ArchiveEntry
/*     */ {
/*     */   private String name;
/* 183 */   private TYPE type = TYPE.UNKNOWN;
/*     */   private int mode;
/* 185 */   private Set<PERMISSION> permissions = Collections.emptySet();
/*     */   
/*     */   private long size;
/*     */   
/*     */   private long atime;
/*     */   
/*     */   private long mtime;
/*     */   
/*     */   private int uid;
/*     */   private int gid;
/* 195 */   private final DumpArchiveSummary summary = null;
/*     */   
/*     */ 
/* 198 */   private final TapeSegmentHeader header = new TapeSegmentHeader();
/*     */   
/*     */   private String simpleName;
/*     */   
/*     */   private String originalName;
/*     */   
/*     */   private int volume;
/*     */   
/*     */   private long offset;
/*     */   
/*     */   private int ino;
/*     */   
/*     */   private int nlink;
/*     */   
/*     */   private long ctime;
/*     */   
/*     */   private int generation;
/*     */   
/*     */   private boolean isDeleted;
/*     */   
/*     */ 
/*     */   public DumpArchiveEntry() {}
/*     */   
/*     */   public DumpArchiveEntry(String name, String simpleName)
/*     */   {
/* 223 */     setName(name);
/* 224 */     this.simpleName = simpleName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected DumpArchiveEntry(String name, String simpleName, int ino, TYPE type)
/*     */   {
/* 237 */     setType(type);
/* 238 */     setName(name);
/* 239 */     this.simpleName = simpleName;
/* 240 */     this.ino = ino;
/* 241 */     this.offset = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSimpleName()
/*     */   {
/* 249 */     return this.simpleName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSimpleName(String simpleName)
/*     */   {
/* 257 */     this.simpleName = simpleName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIno()
/*     */   {
/* 265 */     return this.header.getIno();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNlink()
/*     */   {
/* 273 */     return this.nlink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNlink(int nlink)
/*     */   {
/* 281 */     this.nlink = nlink;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getCreationTime()
/*     */   {
/* 289 */     return new Date(this.ctime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreationTime(Date ctime)
/*     */   {
/* 297 */     this.ctime = ctime.getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getGeneration()
/*     */   {
/* 305 */     return this.generation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGeneration(int generation)
/*     */   {
/* 313 */     this.generation = generation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDeleted()
/*     */   {
/* 321 */     return this.isDeleted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDeleted(boolean isDeleted)
/*     */   {
/* 329 */     this.isDeleted = isDeleted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getOffset()
/*     */   {
/* 337 */     return this.offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOffset(long offset)
/*     */   {
/* 345 */     this.offset = offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getVolume()
/*     */   {
/* 353 */     return this.volume;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVolume(int volume)
/*     */   {
/* 361 */     this.volume = volume;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DumpArchiveConstants.SEGMENT_TYPE getHeaderType()
/*     */   {
/* 369 */     return this.header.getType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeaderCount()
/*     */   {
/* 377 */     return this.header.getCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeaderHoles()
/*     */   {
/* 385 */     return this.header.getHoles();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSparseRecord(int idx)
/*     */   {
/* 394 */     return (this.header.getCdata(idx) & 0x1) == 0;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 399 */     return this.ino;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 404 */     if (o == this)
/* 405 */       return true;
/* 406 */     if ((o == null) || (!o.getClass().equals(getClass()))) {
/* 407 */       return false;
/*     */     }
/*     */     
/* 410 */     DumpArchiveEntry rhs = (DumpArchiveEntry)o;
/*     */     
/* 412 */     if ((this.header == null) || (rhs.header == null)) {
/* 413 */       return false;
/*     */     }
/*     */     
/* 416 */     if (this.ino != rhs.ino) {
/* 417 */       return false;
/*     */     }
/*     */     
/* 420 */     if (((this.summary == null) && (rhs.summary != null)) || ((this.summary != null) && (!this.summary.equals(rhs.summary))))
/*     */     {
/* 422 */       return false;
/*     */     }
/*     */     
/* 425 */     return true;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 430 */     return getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static DumpArchiveEntry parse(byte[] buffer)
/*     */   {
/* 440 */     DumpArchiveEntry entry = new DumpArchiveEntry();
/* 441 */     TapeSegmentHeader header = entry.header;
/*     */     
/* 443 */     header.type = DumpArchiveConstants.SEGMENT_TYPE.find(DumpArchiveUtil.convert32(buffer, 0));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 449 */     header.volume = DumpArchiveUtil.convert32(buffer, 12);
/*     */     
/* 451 */     entry.ino = header.ino = DumpArchiveUtil.convert32(buffer, 20);
/*     */     
/*     */ 
/*     */ 
/* 455 */     int m = DumpArchiveUtil.convert16(buffer, 32);
/*     */     
/*     */ 
/* 458 */     entry.setType(TYPE.find(m >> 12 & 0xF));
/*     */     
/*     */ 
/* 461 */     entry.setMode(m);
/*     */     
/* 463 */     entry.nlink = DumpArchiveUtil.convert16(buffer, 34);
/*     */     
/* 465 */     entry.setSize(DumpArchiveUtil.convert64(buffer, 40));
/*     */     
/* 467 */     long t = 1000L * DumpArchiveUtil.convert32(buffer, 48) + DumpArchiveUtil.convert32(buffer, 52) / 1000;
/*     */     
/* 469 */     entry.setAccessTime(new Date(t));
/* 470 */     t = 1000L * DumpArchiveUtil.convert32(buffer, 56) + DumpArchiveUtil.convert32(buffer, 60) / 1000;
/*     */     
/* 472 */     entry.setLastModifiedDate(new Date(t));
/* 473 */     t = 1000L * DumpArchiveUtil.convert32(buffer, 64) + DumpArchiveUtil.convert32(buffer, 68) / 1000;
/*     */     
/* 475 */     entry.ctime = t;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 481 */     entry.generation = DumpArchiveUtil.convert32(buffer, 140);
/* 482 */     entry.setUserId(DumpArchiveUtil.convert32(buffer, 144));
/* 483 */     entry.setGroupId(DumpArchiveUtil.convert32(buffer, 148));
/*     */     
/* 485 */     header.count = DumpArchiveUtil.convert32(buffer, 160);
/*     */     
/* 487 */     header.holes = 0;
/*     */     
/* 489 */     for (int i = 0; (i < 512) && (i < header.count); i++) {
/* 490 */       if (buffer[(164 + i)] == 0) {
/* 491 */         TapeSegmentHeader.access$408(header);
/*     */       }
/*     */     }
/*     */     
/* 495 */     System.arraycopy(buffer, 164, header.cdata, 0, 512);
/*     */     
/* 497 */     entry.volume = header.getVolume();
/*     */     
/*     */ 
/* 500 */     return entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void update(byte[] buffer)
/*     */   {
/* 507 */     this.header.volume = DumpArchiveUtil.convert32(buffer, 16);
/* 508 */     this.header.count = DumpArchiveUtil.convert32(buffer, 160);
/*     */     
/* 510 */     this.header.holes = 0;
/*     */     
/* 512 */     for (int i = 0; (i < 512) && (i < this.header.count); i++) {
/* 513 */       if (buffer[(164 + i)] == 0) {
/* 514 */         TapeSegmentHeader.access$408(this.header);
/*     */       }
/*     */     }
/*     */     
/* 518 */     System.arraycopy(buffer, 164, this.header.cdata, 0, 512);
/*     */   }
/*     */   
/*     */ 
/*     */   static class TapeSegmentHeader
/*     */   {
/*     */     private DumpArchiveConstants.SEGMENT_TYPE type;
/*     */     
/*     */     private int volume;
/*     */     
/*     */     private int ino;
/*     */     private int count;
/*     */     private int holes;
/* 531 */     private final byte[] cdata = new byte['Ȁ'];
/*     */     
/*     */     public DumpArchiveConstants.SEGMENT_TYPE getType() {
/* 534 */       return this.type;
/*     */     }
/*     */     
/*     */     public int getVolume() {
/* 538 */       return this.volume;
/*     */     }
/*     */     
/*     */     public int getIno() {
/* 542 */       return this.ino;
/*     */     }
/*     */     
/*     */     void setIno(int ino) {
/* 546 */       this.ino = ino;
/*     */     }
/*     */     
/*     */     public int getCount() {
/* 550 */       return this.count;
/*     */     }
/*     */     
/*     */     public int getHoles() {
/* 554 */       return this.holes;
/*     */     }
/*     */     
/*     */     public int getCdata(int idx) {
/* 558 */       return this.cdata[idx];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 567 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getOriginalName()
/*     */   {
/* 575 */     return this.originalName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setName(String name)
/*     */   {
/* 583 */     this.originalName = name;
/* 584 */     if (name != null) {
/* 585 */       if ((isDirectory()) && (!name.endsWith("/"))) {
/* 586 */         name = name + "/";
/*     */       }
/* 588 */       if (name.startsWith("./")) {
/* 589 */         name = name.substring(2);
/*     */       }
/*     */     }
/* 592 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getLastModifiedDate()
/*     */   {
/* 600 */     return new Date(this.mtime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/* 608 */     return this.type == TYPE.DIRECTORY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFile()
/*     */   {
/* 616 */     return this.type == TYPE.FILE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSocket()
/*     */   {
/* 624 */     return this.type == TYPE.SOCKET;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isChrDev()
/*     */   {
/* 632 */     return this.type == TYPE.CHRDEV;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBlkDev()
/*     */   {
/* 640 */     return this.type == TYPE.BLKDEV;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFifo()
/*     */   {
/* 648 */     return this.type == TYPE.FIFO;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TYPE getType()
/*     */   {
/* 656 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(TYPE type)
/*     */   {
/* 664 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMode()
/*     */   {
/* 672 */     return this.mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMode(int mode)
/*     */   {
/* 680 */     this.mode = (mode & 0xFFF);
/* 681 */     this.permissions = PERMISSION.find(mode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Set<PERMISSION> getPermissions()
/*     */   {
/* 689 */     return this.permissions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 697 */     return isDirectory() ? -1L : this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   long getEntrySize()
/*     */   {
/* 704 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(long size)
/*     */   {
/* 712 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLastModifiedDate(Date mtime)
/*     */   {
/* 720 */     this.mtime = mtime.getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getAccessTime()
/*     */   {
/* 728 */     return new Date(this.atime);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessTime(Date atime)
/*     */   {
/* 736 */     this.atime = atime.getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUserId()
/*     */   {
/* 744 */     return this.uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserId(int uid)
/*     */   {
/* 752 */     this.uid = uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getGroupId()
/*     */   {
/* 760 */     return this.gid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGroupId(int gid)
/*     */   {
/* 768 */     this.gid = gid;
/*     */   }
/*     */   
/*     */   public static enum TYPE {
/* 772 */     WHITEOUT(14), 
/* 773 */     SOCKET(12), 
/* 774 */     LINK(10), 
/* 775 */     FILE(8), 
/* 776 */     BLKDEV(6), 
/* 777 */     DIRECTORY(4), 
/* 778 */     CHRDEV(2), 
/* 779 */     FIFO(1), 
/* 780 */     UNKNOWN(15);
/*     */     
/*     */     private int code;
/*     */     
/*     */     private TYPE(int code) {
/* 785 */       this.code = code;
/*     */     }
/*     */     
/*     */     public static TYPE find(int code) {
/* 789 */       TYPE type = UNKNOWN;
/*     */       
/* 791 */       for (TYPE t : values()) {
/* 792 */         if (code == t.code) {
/* 793 */           type = t;
/*     */         }
/*     */       }
/*     */       
/* 797 */       return type;
/*     */     }
/*     */   }
/*     */   
/*     */   public static enum PERMISSION {
/* 802 */     SETUID(2048), 
/* 803 */     SETGUI(1024), 
/* 804 */     STICKY(512), 
/* 805 */     USER_READ(256), 
/* 806 */     USER_WRITE(128), 
/* 807 */     USER_EXEC(64), 
/* 808 */     GROUP_READ(32), 
/* 809 */     GROUP_WRITE(16), 
/* 810 */     GROUP_EXEC(8), 
/* 811 */     WORLD_READ(4), 
/* 812 */     WORLD_WRITE(2), 
/* 813 */     WORLD_EXEC(1);
/*     */     
/*     */     private int code;
/*     */     
/*     */     private PERMISSION(int code) {
/* 818 */       this.code = code;
/*     */     }
/*     */     
/*     */     public static Set<PERMISSION> find(int code) {
/* 822 */       Set<PERMISSION> set = new HashSet();
/*     */       
/* 824 */       for (PERMISSION p : values()) {
/* 825 */         if ((code & p.code) == p.code) {
/* 826 */           set.add(p);
/*     */         }
/*     */       }
/*     */       
/* 830 */       if (set.isEmpty()) {
/* 831 */         return Collections.emptySet();
/*     */       }
/*     */       
/* 834 */       return EnumSet.copyOf(set);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\dump\DumpArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */