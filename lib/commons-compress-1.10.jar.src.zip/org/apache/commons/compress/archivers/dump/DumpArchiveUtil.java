/*     */ package org.apache.commons.compress.archivers.dump;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.compress.archivers.zip.ZipEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DumpArchiveUtil
/*     */ {
/*     */   public static int calculateChecksum(byte[] buffer)
/*     */   {
/*  41 */     int calc = 0;
/*     */     
/*  43 */     for (int i = 0; i < 256; i++) {
/*  44 */       calc += convert32(buffer, 4 * i);
/*     */     }
/*     */     
/*  47 */     return 84446 - (calc - convert32(buffer, 28));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean verify(byte[] buffer)
/*     */   {
/*  58 */     int magic = convert32(buffer, 24);
/*     */     
/*  60 */     if (magic != 60012) {
/*  61 */       return false;
/*     */     }
/*     */     
/*     */ 
/*  65 */     int checksum = convert32(buffer, 28);
/*     */     
/*  67 */     if (checksum != calculateChecksum(buffer)) {
/*  68 */       return false;
/*     */     }
/*     */     
/*  71 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int getIno(byte[] buffer)
/*     */   {
/*  80 */     return convert32(buffer, 20);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final long convert64(byte[] buffer, int offset)
/*     */   {
/*  91 */     long i = 0L;
/*  92 */     i += (buffer[(offset + 7)] << 56);
/*  93 */     i += (buffer[(offset + 6)] << 48 & 0xFF000000000000);
/*  94 */     i += (buffer[(offset + 5)] << 40 & 0xFF0000000000);
/*  95 */     i += (buffer[(offset + 4)] << 32 & 0xFF00000000);
/*  96 */     i += (buffer[(offset + 3)] << 24 & 0xFF000000);
/*  97 */     i += (buffer[(offset + 2)] << 16 & 0xFF0000);
/*  98 */     i += (buffer[(offset + 1)] << 8 & 0xFF00);
/*  99 */     i += (buffer[offset] & 0xFF);
/*     */     
/* 101 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int convert32(byte[] buffer, int offset)
/*     */   {
/* 112 */     int i = 0;
/* 113 */     i = buffer[(offset + 3)] << 24;
/* 114 */     i += (buffer[(offset + 2)] << 16 & 0xFF0000);
/* 115 */     i += (buffer[(offset + 1)] << 8 & 0xFF00);
/* 116 */     i += (buffer[offset] & 0xFF);
/*     */     
/* 118 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int convert16(byte[] buffer, int offset)
/*     */   {
/* 129 */     int i = 0;
/* 130 */     i += (buffer[(offset + 1)] << 8 & 0xFF00);
/* 131 */     i += (buffer[offset] & 0xFF);
/*     */     
/* 133 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static String decode(ZipEncoding encoding, byte[] b, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 141 */     byte[] copy = new byte[len];
/* 142 */     System.arraycopy(b, offset, copy, 0, len);
/* 143 */     return encoding.decode(copy);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\dump\DumpArchiveUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */