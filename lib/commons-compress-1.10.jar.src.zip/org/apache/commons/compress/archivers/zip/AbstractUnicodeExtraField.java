/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUnicodeExtraField
/*     */   implements ZipExtraField
/*     */ {
/*     */   private long nameCRC32;
/*     */   private byte[] unicodeName;
/*     */   private byte[] data;
/*     */   
/*     */   protected AbstractUnicodeExtraField() {}
/*     */   
/*     */   protected AbstractUnicodeExtraField(String text, byte[] bytes, int off, int len)
/*     */   {
/*  52 */     CRC32 crc32 = new CRC32();
/*  53 */     crc32.update(bytes, off, len);
/*  54 */     this.nameCRC32 = crc32.getValue();
/*     */     try
/*     */     {
/*  57 */       this.unicodeName = text.getBytes("UTF-8");
/*     */     } catch (UnsupportedEncodingException e) {
/*  59 */       throw new RuntimeException("FATAL: UTF-8 encoding not supported.", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractUnicodeExtraField(String text, byte[] bytes)
/*     */   {
/*  72 */     this(text, bytes, 0, bytes.length);
/*     */   }
/*     */   
/*     */   private void assembleData() {
/*  76 */     if (this.unicodeName == null) {
/*  77 */       return;
/*     */     }
/*     */     
/*  80 */     this.data = new byte[5 + this.unicodeName.length];
/*     */     
/*  82 */     this.data[0] = 1;
/*  83 */     System.arraycopy(ZipLong.getBytes(this.nameCRC32), 0, this.data, 1, 4);
/*  84 */     System.arraycopy(this.unicodeName, 0, this.data, 5, this.unicodeName.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getNameCRC32()
/*     */   {
/*  92 */     return this.nameCRC32;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNameCRC32(long nameCRC32)
/*     */   {
/* 100 */     this.nameCRC32 = nameCRC32;
/* 101 */     this.data = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getUnicodeName()
/*     */   {
/* 108 */     byte[] b = null;
/* 109 */     if (this.unicodeName != null) {
/* 110 */       b = new byte[this.unicodeName.length];
/* 111 */       System.arraycopy(this.unicodeName, 0, b, 0, b.length);
/*     */     }
/* 113 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setUnicodeName(byte[] unicodeName)
/*     */   {
/* 120 */     if (unicodeName != null) {
/* 121 */       this.unicodeName = new byte[unicodeName.length];
/* 122 */       System.arraycopy(unicodeName, 0, this.unicodeName, 0, unicodeName.length);
/*     */     }
/*     */     else {
/* 125 */       this.unicodeName = null;
/*     */     }
/* 127 */     this.data = null;
/*     */   }
/*     */   
/*     */   public byte[] getCentralDirectoryData() {
/* 131 */     if (this.data == null) {
/* 132 */       assembleData();
/*     */     }
/* 134 */     byte[] b = null;
/* 135 */     if (this.data != null) {
/* 136 */       b = new byte[this.data.length];
/* 137 */       System.arraycopy(this.data, 0, b, 0, b.length);
/*     */     }
/* 139 */     return b;
/*     */   }
/*     */   
/*     */   public ZipShort getCentralDirectoryLength() {
/* 143 */     if (this.data == null) {
/* 144 */       assembleData();
/*     */     }
/* 146 */     return new ZipShort(this.data != null ? this.data.length : 0);
/*     */   }
/*     */   
/*     */   public byte[] getLocalFileDataData() {
/* 150 */     return getCentralDirectoryData();
/*     */   }
/*     */   
/*     */   public ZipShort getLocalFileDataLength() {
/* 154 */     return getCentralDirectoryLength();
/*     */   }
/*     */   
/*     */   public void parseFromLocalFileData(byte[] buffer, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 160 */     if (length < 5) {
/* 161 */       throw new ZipException("UniCode path extra data must have at least 5 bytes.");
/*     */     }
/*     */     
/* 164 */     int version = buffer[offset];
/*     */     
/* 166 */     if (version != 1) {
/* 167 */       throw new ZipException("Unsupported version [" + version + "] for UniCode path extra data.");
/*     */     }
/*     */     
/*     */ 
/* 171 */     this.nameCRC32 = ZipLong.getValue(buffer, offset + 1);
/* 172 */     this.unicodeName = new byte[length - 5];
/* 173 */     System.arraycopy(buffer, offset + 5, this.unicodeName, 0, length - 5);
/* 174 */     this.data = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromCentralDirectoryData(byte[] buffer, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 184 */     parseFromLocalFileData(buffer, offset, length);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\AbstractUnicodeExtraField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */