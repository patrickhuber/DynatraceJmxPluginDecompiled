/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExplodingInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final InputStream in;
/*     */   private BitStream bits;
/*     */   private final int dictionarySize;
/*     */   private final int numberOfTrees;
/*     */   private final int minimumMatchLength;
/*     */   private BinaryTree literalTree;
/*     */   private BinaryTree lengthTree;
/*     */   private BinaryTree distanceTree;
/*  63 */   private final CircularBuffer buffer = new CircularBuffer(32768);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExplodingInputStream(int dictionarySize, int numberOfTrees, InputStream in)
/*     */   {
/*  74 */     if ((dictionarySize != 4096) && (dictionarySize != 8192)) {
/*  75 */       throw new IllegalArgumentException("The dictionary size must be 4096 or 8192");
/*     */     }
/*  77 */     if ((numberOfTrees != 2) && (numberOfTrees != 3)) {
/*  78 */       throw new IllegalArgumentException("The number of trees must be 2 or 3");
/*     */     }
/*  80 */     this.dictionarySize = dictionarySize;
/*  81 */     this.numberOfTrees = numberOfTrees;
/*  82 */     this.minimumMatchLength = numberOfTrees;
/*  83 */     this.in = in;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init()
/*     */     throws IOException
/*     */   {
/*  92 */     if (this.bits == null) {
/*  93 */       if (this.numberOfTrees == 3) {
/*  94 */         this.literalTree = BinaryTree.decode(this.in, 256);
/*     */       }
/*     */       
/*  97 */       this.lengthTree = BinaryTree.decode(this.in, 64);
/*  98 */       this.distanceTree = BinaryTree.decode(this.in, 64);
/*     */       
/* 100 */       this.bits = new BitStream(this.in);
/*     */     }
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 106 */     if (!this.buffer.available()) {
/* 107 */       fillBuffer();
/*     */     }
/*     */     
/* 110 */     return this.buffer.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void fillBuffer()
/*     */     throws IOException
/*     */   {
/* 118 */     init();
/*     */     
/* 120 */     int bit = this.bits.nextBit();
/* 121 */     if (bit == 1) {
/*     */       int literal;
/*     */       int literal;
/* 124 */       if (this.literalTree != null) {
/* 125 */         literal = this.literalTree.read(this.bits);
/*     */       } else {
/* 127 */         literal = this.bits.nextByte();
/*     */       }
/*     */       
/* 130 */       if (literal == -1)
/*     */       {
/* 132 */         return;
/*     */       }
/*     */       
/* 135 */       this.buffer.put(literal);
/*     */     }
/* 137 */     else if (bit == 0)
/*     */     {
/* 139 */       int distanceLowSize = this.dictionarySize == 4096 ? 6 : 7;
/* 140 */       int distanceLow = (int)this.bits.nextBits(distanceLowSize);
/* 141 */       int distanceHigh = this.distanceTree.read(this.bits);
/* 142 */       if ((distanceHigh == -1) && (distanceLow <= 0))
/*     */       {
/* 144 */         return;
/*     */       }
/* 146 */       int distance = distanceHigh << distanceLowSize | distanceLow;
/*     */       
/* 148 */       int length = this.lengthTree.read(this.bits);
/* 149 */       if (length == 63) {
/* 150 */         length = (int)(length + this.bits.nextBits(8));
/*     */       }
/* 152 */       length += this.minimumMatchLength;
/*     */       
/* 154 */       this.buffer.copy(distance + 1, length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ExplodingInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */