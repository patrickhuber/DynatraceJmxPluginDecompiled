/*    */ package org.apache.commons.compress.archivers.zip;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScatterStatistics
/*    */ {
/*    */   private final long compressionElapsed;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final long mergingElapsed;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ScatterStatistics(long compressionElapsed, long mergingElapsed)
/*    */   {
/* 31 */     this.compressionElapsed = compressionElapsed;
/* 32 */     this.mergingElapsed = mergingElapsed;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getCompressionElapsed()
/*    */   {
/* 40 */     return this.compressionElapsed;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long getMergingElapsed()
/*    */   {
/* 48 */     return this.mergingElapsed;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 53 */     return "compressionElapsed=" + this.compressionElapsed + "ms, mergingElapsed=" + this.mergingElapsed + "ms";
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ScatterStatistics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */