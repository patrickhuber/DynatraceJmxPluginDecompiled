/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsupportedZipFeatureException
/*     */   extends ZipException
/*     */ {
/*     */   private final Feature reason;
/*     */   private final ZipArchiveEntry entry;
/*     */   private static final long serialVersionUID = 20130101L;
/*     */   
/*     */   public UnsupportedZipFeatureException(Feature reason, ZipArchiveEntry entry)
/*     */   {
/*  41 */     super("unsupported feature " + reason + " used in entry " + entry.getName());
/*     */     
/*  43 */     this.reason = reason;
/*  44 */     this.entry = entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnsupportedZipFeatureException(ZipMethod method, ZipArchiveEntry entry)
/*     */   {
/*  56 */     super("unsupported feature method '" + method.name() + "' used in entry " + entry.getName());
/*     */     
/*  58 */     this.reason = Feature.METHOD;
/*  59 */     this.entry = entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnsupportedZipFeatureException(Feature reason)
/*     */   {
/*  70 */     super("unsupported feature " + reason + " used in archive.");
/*  71 */     this.reason = reason;
/*  72 */     this.entry = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Feature getFeature()
/*     */   {
/*  80 */     return this.reason;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipArchiveEntry getEntry()
/*     */   {
/*  88 */     return this.entry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Feature
/*     */   {
/*  99 */     public static final Feature ENCRYPTION = new Feature("encryption");
/*     */     
/*     */ 
/*     */ 
/* 103 */     public static final Feature METHOD = new Feature("compression method");
/*     */     
/*     */ 
/*     */ 
/* 107 */     public static final Feature DATA_DESCRIPTOR = new Feature("data descriptor");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 112 */     public static final Feature SPLITTING = new Feature("splitting");
/*     */     private final String name;
/*     */     
/*     */     private Feature(String name)
/*     */     {
/* 117 */       this.name = name;
/*     */     }
/*     */     
/*     */     public String toString()
/*     */     {
/* 122 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\UnsupportedZipFeatureException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */