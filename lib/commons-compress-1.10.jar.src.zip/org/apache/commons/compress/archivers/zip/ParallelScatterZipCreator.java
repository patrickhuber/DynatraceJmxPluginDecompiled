/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.compress.parallel.FileBasedScatterGatherBackingStore;
/*     */ import org.apache.commons.compress.parallel.InputStreamSupplier;
/*     */ import org.apache.commons.compress.parallel.ScatterGatherBackingStore;
/*     */ import org.apache.commons.compress.parallel.ScatterGatherBackingStoreSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParallelScatterZipCreator
/*     */ {
/*  55 */   private final List<ScatterZipOutputStream> streams = Collections.synchronizedList(new ArrayList());
/*     */   private final ExecutorService es;
/*     */   private final ScatterGatherBackingStoreSupplier backingStoreSupplier;
/*  58 */   private final List<Future<Object>> futures = new ArrayList();
/*     */   
/*  60 */   private final long startedAt = System.currentTimeMillis();
/*  61 */   private long compressionDoneAt = 0L;
/*     */   private long scatterDoneAt;
/*     */   
/*     */   private static class DefaultBackingStoreSupplier implements ScatterGatherBackingStoreSupplier {
/*  65 */     final AtomicInteger storeNum = new AtomicInteger(0);
/*     */     
/*     */     public ScatterGatherBackingStore get() throws IOException {
/*  68 */       File tempFile = File.createTempFile("parallelscatter", "n" + this.storeNum.incrementAndGet());
/*  69 */       return new FileBasedScatterGatherBackingStore(tempFile);
/*     */     }
/*     */   }
/*     */   
/*     */   private ScatterZipOutputStream createDeferred(ScatterGatherBackingStoreSupplier scatterGatherBackingStoreSupplier) throws IOException
/*     */   {
/*  75 */     ScatterGatherBackingStore bs = scatterGatherBackingStoreSupplier.get();
/*  76 */     StreamCompressor sc = StreamCompressor.create(-1, bs);
/*  77 */     return new ScatterZipOutputStream(bs, sc);
/*     */   }
/*     */   
/*  80 */   private final ThreadLocal<ScatterZipOutputStream> tlScatterStreams = new ThreadLocal()
/*     */   {
/*     */     protected ScatterZipOutputStream initialValue() {
/*     */       try {
/*  84 */         ScatterZipOutputStream scatterStream = ParallelScatterZipCreator.this.createDeferred(ParallelScatterZipCreator.this.backingStoreSupplier);
/*  85 */         ParallelScatterZipCreator.this.streams.add(scatterStream);
/*  86 */         return scatterStream;
/*     */       } catch (IOException e) {
/*  88 */         throw new RuntimeException(e);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParallelScatterZipCreator()
/*     */   {
/*  98 */     this(Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParallelScatterZipCreator(ExecutorService executorService)
/*     */   {
/* 108 */     this(executorService, new DefaultBackingStoreSupplier(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParallelScatterZipCreator(ExecutorService executorService, ScatterGatherBackingStoreSupplier backingStoreSupplier)
/*     */   {
/* 120 */     this.backingStoreSupplier = backingStoreSupplier;
/* 121 */     this.es = executorService;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addArchiveEntry(ZipArchiveEntry zipArchiveEntry, InputStreamSupplier source)
/*     */   {
/* 135 */     submit(createCallable(zipArchiveEntry, source));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void submit(Callable<Object> callable)
/*     */   {
/* 146 */     this.futures.add(this.es.submit(callable));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Callable<Object> createCallable(ZipArchiveEntry zipArchiveEntry, InputStreamSupplier source)
/*     */   {
/* 168 */     int method = zipArchiveEntry.getMethod();
/* 169 */     if (method == -1) {
/* 170 */       throw new IllegalArgumentException("Method must be set on zipArchiveEntry: " + zipArchiveEntry);
/*     */     }
/* 172 */     final ZipArchiveEntryRequest zipArchiveEntryRequest = ZipArchiveEntryRequest.createZipArchiveEntryRequest(zipArchiveEntry, source);
/* 173 */     new Callable() {
/*     */       public Object call() throws Exception {
/* 175 */         ((ScatterZipOutputStream)ParallelScatterZipCreator.this.tlScatterStreams.get()).addArchiveEntry(zipArchiveEntryRequest);
/* 176 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(ZipArchiveOutputStream targetStream)
/*     */     throws IOException, InterruptedException, ExecutionException
/*     */   {
/* 198 */     for (Future<?> future : this.futures) {
/* 199 */       future.get();
/*     */     }
/*     */     
/* 202 */     this.es.shutdown();
/* 203 */     this.es.awaitTermination(60000L, TimeUnit.SECONDS);
/*     */     
/*     */ 
/* 206 */     this.compressionDoneAt = System.currentTimeMillis();
/*     */     
/* 208 */     for (ScatterZipOutputStream scatterStream : this.streams) {
/* 209 */       scatterStream.writeTo(targetStream);
/* 210 */       scatterStream.close();
/*     */     }
/*     */     
/* 213 */     this.scatterDoneAt = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScatterStatistics getStatisticsMessage()
/*     */   {
/* 222 */     return new ScatterStatistics(this.compressionDoneAt - this.startedAt, this.scatterDoneAt - this.compressionDoneAt);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ParallelScatterZipCreator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */