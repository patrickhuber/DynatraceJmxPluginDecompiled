/*      */ package org.apache.commons.compress.archivers.zip;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.Closeable;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.zip.Inflater;
/*      */ import java.util.zip.InflaterInputStream;
/*      */ import java.util.zip.ZipException;
/*      */ import org.apache.commons.compress.utils.IOUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ZipFile
/*      */   implements Closeable
/*      */ {
/*      */   private static final int HASH_SIZE = 509;
/*      */   static final int NIBLET_MASK = 15;
/*      */   static final int BYTE_SHIFT = 8;
/*      */   private static final int POS_0 = 0;
/*      */   private static final int POS_1 = 1;
/*      */   private static final int POS_2 = 2;
/*      */   private static final int POS_3 = 3;
/*   91 */   private final List<ZipArchiveEntry> entries = new LinkedList();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   97 */   private final Map<String, LinkedList<ZipArchiveEntry>> nameMap = new HashMap(509);
/*      */   private final String encoding;
/*      */   private final ZipEncoding zipEncoding;
/*      */   
/*  101 */   private static final class OffsetEntry { private long headerOffset = -1L;
/*  102 */     private long dataOffset = -1L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final String archiveName;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final RandomAccessFile archive;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final boolean useUnicodeExtraFields;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */   private volatile boolean closed = true;
/*      */   
/*      */ 
/*  140 */   private final byte[] DWORD_BUF = new byte[8];
/*  141 */   private final byte[] WORD_BUF = new byte[4];
/*  142 */   private final byte[] CFH_BUF = new byte[42];
/*  143 */   private final byte[] SHORT_BUF = new byte[2];
/*      */   
/*      */ 
/*      */   private static final int CFH_LEN = 42;
/*      */   
/*      */ 
/*      */ 
/*      */   public ZipFile(File f)
/*      */     throws IOException
/*      */   {
/*  153 */     this(f, "UTF8");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipFile(String name)
/*      */     throws IOException
/*      */   {
/*  164 */     this(new File(name), "UTF8");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipFile(String name, String encoding)
/*      */     throws IOException
/*      */   {
/*  178 */     this(new File(name), encoding, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipFile(File f, String encoding)
/*      */     throws IOException
/*      */   {
/*  192 */     this(f, encoding, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipFile(File f, String encoding, boolean useUnicodeExtraFields)
/*      */     throws IOException
/*      */   {
/*  209 */     this.archiveName = f.getAbsolutePath();
/*  210 */     this.encoding = encoding;
/*  211 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*  212 */     this.useUnicodeExtraFields = useUnicodeExtraFields;
/*  213 */     this.archive = new RandomAccessFile(f, "r");
/*  214 */     boolean success = false;
/*      */     try {
/*  216 */       Map<ZipArchiveEntry, NameAndComment> entriesWithoutUTF8Flag = populateFromCentralDirectory();
/*      */       
/*  218 */       resolveLocalFileHeaderData(entriesWithoutUTF8Flag);
/*  219 */       success = true;
/*      */     } finally {
/*  221 */       this.closed = (!success);
/*  222 */       if (!success) {
/*  223 */         IOUtils.closeQuietly(this.archive);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  234 */     return this.encoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  245 */     this.closed = true;
/*      */     
/*  247 */     this.archive.close();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void closeQuietly(ZipFile zipfile)
/*      */   {
/*  256 */     IOUtils.closeQuietly(zipfile);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<ZipArchiveEntry> getEntries()
/*      */   {
/*  268 */     return Collections.enumeration(this.entries);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Enumeration<ZipArchiveEntry> getEntriesInPhysicalOrder()
/*      */   {
/*  282 */     ZipArchiveEntry[] allEntries = (ZipArchiveEntry[])this.entries.toArray(new ZipArchiveEntry[this.entries.size()]);
/*  283 */     Arrays.sort(allEntries, this.OFFSET_COMPARATOR);
/*  284 */     return Collections.enumeration(Arrays.asList(allEntries));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveEntry getEntry(String name)
/*      */   {
/*  300 */     LinkedList<ZipArchiveEntry> entriesOfThatName = (LinkedList)this.nameMap.get(name);
/*  301 */     return entriesOfThatName != null ? (ZipArchiveEntry)entriesOfThatName.getFirst() : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterable<ZipArchiveEntry> getEntries(String name)
/*      */   {
/*  314 */     List<ZipArchiveEntry> entriesOfThatName = (List)this.nameMap.get(name);
/*  315 */     return entriesOfThatName != null ? entriesOfThatName : Collections.emptyList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Iterable<ZipArchiveEntry> getEntriesInPhysicalOrder(String name)
/*      */   {
/*  329 */     ZipArchiveEntry[] entriesOfThatName = new ZipArchiveEntry[0];
/*  330 */     if (this.nameMap.containsKey(name)) {
/*  331 */       entriesOfThatName = (ZipArchiveEntry[])((LinkedList)this.nameMap.get(name)).toArray(entriesOfThatName);
/*  332 */       Arrays.sort(entriesOfThatName, this.OFFSET_COMPARATOR);
/*      */     }
/*  334 */     return Arrays.asList(entriesOfThatName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canReadEntryData(ZipArchiveEntry ze)
/*      */   {
/*  347 */     return ZipUtil.canHandleEntryData(ze);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private InputStream getRawInputStream(ZipArchiveEntry ze)
/*      */   {
/*  360 */     if (!(ze instanceof Entry)) {
/*  361 */       return null;
/*      */     }
/*  363 */     OffsetEntry offsetEntry = ((Entry)ze).getOffsetEntry();
/*  364 */     long start = offsetEntry.dataOffset;
/*  365 */     return new BoundedInputStream(start, ze.getCompressedSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyRawEntries(ZipArchiveOutputStream target, ZipArchiveEntryPredicate predicate)
/*      */     throws IOException
/*      */   {
/*  380 */     Enumeration<ZipArchiveEntry> src = getEntriesInPhysicalOrder();
/*  381 */     while (src.hasMoreElements()) {
/*  382 */       ZipArchiveEntry entry = (ZipArchiveEntry)src.nextElement();
/*  383 */       if (predicate.test(entry)) {
/*  384 */         target.addRawArchiveEntry(entry, getRawInputStream(entry));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public InputStream getInputStream(ZipArchiveEntry ze)
/*      */     throws IOException, ZipException
/*      */   {
/*  399 */     if (!(ze instanceof Entry)) {
/*  400 */       return null;
/*      */     }
/*      */     
/*  403 */     OffsetEntry offsetEntry = ((Entry)ze).getOffsetEntry();
/*  404 */     ZipUtil.checkRequestedFeatures(ze);
/*  405 */     long start = offsetEntry.dataOffset;
/*  406 */     BoundedInputStream bis = new BoundedInputStream(start, ze.getCompressedSize());
/*      */     
/*  408 */     switch (ZipMethod.getMethodByCode(ze.getMethod())) {
/*      */     case STORED: 
/*  410 */       return bis;
/*      */     case UNSHRINKING: 
/*  412 */       return new UnshrinkingInputStream(bis);
/*      */     case IMPLODING: 
/*  414 */       return new ExplodingInputStream(ze.getGeneralPurposeBit().getSlidingDictionarySize(), ze.getGeneralPurposeBit().getNumberOfShannonFanoTrees(), new BufferedInputStream(bis));
/*      */     
/*      */     case DEFLATED: 
/*  417 */       bis.addDummy();
/*  418 */       final Inflater inflater = new Inflater(true);
/*  419 */       new InflaterInputStream(bis, inflater)
/*      */       {
/*      */         public void close() throws IOException {
/*  422 */           super.close();
/*  423 */           inflater.end();
/*      */         }
/*      */       };
/*      */     }
/*  427 */     throw new ZipException("Found unsupported compression method " + ze.getMethod());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUnixSymlink(ZipArchiveEntry entry)
/*      */     throws IOException
/*      */   {
/*  447 */     if ((entry != null) && (entry.isUnixSymlink())) {
/*  448 */       InputStream in = null;
/*      */       try {
/*  450 */         in = getInputStream(entry);
/*  451 */         byte[] symlinkBytes = IOUtils.toByteArray(in);
/*  452 */         return this.zipEncoding.decode(symlinkBytes);
/*      */       } finally {
/*  454 */         if (in != null) {
/*  455 */           in.close();
/*      */         }
/*      */       }
/*      */     }
/*  459 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void finalize()
/*      */     throws Throwable
/*      */   {
/*      */     try
/*      */     {
/*  471 */       if (!this.closed) {
/*  472 */         System.err.println("Cleaning up unclosed ZipFile for archive " + this.archiveName);
/*      */         
/*  474 */         close();
/*      */       }
/*      */     } finally {
/*  477 */       super.finalize();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  503 */   private static final long CFH_SIG = ZipLong.getValue(ZipArchiveOutputStream.CFH_SIG);
/*      */   
/*      */   static final int MIN_EOCD_SIZE = 22;
/*      */   
/*      */   private static final int MAX_EOCD_SIZE = 65557;
/*      */   
/*      */   private static final int CFD_LOCATOR_OFFSET = 16;
/*      */   
/*      */   private static final int ZIP64_EOCDL_LENGTH = 20;
/*      */   private static final int ZIP64_EOCDL_LOCATOR_OFFSET = 8;
/*      */   private static final int ZIP64_EOCD_CFD_LOCATOR_OFFSET = 48;
/*      */   private static final long LFH_OFFSET_FOR_FILENAME_LENGTH = 26L;
/*      */   
/*      */   private Map<ZipArchiveEntry, NameAndComment> populateFromCentralDirectory()
/*      */     throws IOException
/*      */   {
/*  519 */     HashMap<ZipArchiveEntry, NameAndComment> noUTF8Flag = new HashMap();
/*      */     
/*      */ 
/*  522 */     positionAtCentralDirectory();
/*      */     
/*  524 */     this.archive.readFully(this.WORD_BUF);
/*  525 */     long sig = ZipLong.getValue(this.WORD_BUF);
/*      */     
/*  527 */     if ((sig != CFH_SIG) && (startsWithLocalFileHeader())) {
/*  528 */       throw new IOException("central directory is empty, can't expand corrupt archive.");
/*      */     }
/*      */     
/*      */ 
/*  532 */     while (sig == CFH_SIG) {
/*  533 */       readCentralDirectoryEntry(noUTF8Flag);
/*  534 */       this.archive.readFully(this.WORD_BUF);
/*  535 */       sig = ZipLong.getValue(this.WORD_BUF);
/*      */     }
/*  537 */     return noUTF8Flag;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readCentralDirectoryEntry(Map<ZipArchiveEntry, NameAndComment> noUTF8Flag)
/*      */     throws IOException
/*      */   {
/*  552 */     this.archive.readFully(this.CFH_BUF);
/*  553 */     int off = 0;
/*  554 */     OffsetEntry offset = new OffsetEntry(null);
/*  555 */     Entry ze = new Entry(offset);
/*      */     
/*  557 */     int versionMadeBy = ZipShort.getValue(this.CFH_BUF, off);
/*  558 */     off += 2;
/*  559 */     ze.setPlatform(versionMadeBy >> 8 & 0xF);
/*      */     
/*  561 */     off += 2;
/*      */     
/*  563 */     GeneralPurposeBit gpFlag = GeneralPurposeBit.parse(this.CFH_BUF, off);
/*  564 */     boolean hasUTF8Flag = gpFlag.usesUTF8ForNames();
/*  565 */     ZipEncoding entryEncoding = hasUTF8Flag ? ZipEncodingHelper.UTF8_ZIP_ENCODING : this.zipEncoding;
/*      */     
/*  567 */     ze.setGeneralPurposeBit(gpFlag);
/*      */     
/*  569 */     off += 2;
/*      */     
/*  571 */     ze.setMethod(ZipShort.getValue(this.CFH_BUF, off));
/*  572 */     off += 2;
/*      */     
/*  574 */     long time = ZipUtil.dosToJavaTime(ZipLong.getValue(this.CFH_BUF, off));
/*  575 */     ze.setTime(time);
/*  576 */     off += 4;
/*      */     
/*  578 */     ze.setCrc(ZipLong.getValue(this.CFH_BUF, off));
/*  579 */     off += 4;
/*      */     
/*  581 */     ze.setCompressedSize(ZipLong.getValue(this.CFH_BUF, off));
/*  582 */     off += 4;
/*      */     
/*  584 */     ze.setSize(ZipLong.getValue(this.CFH_BUF, off));
/*  585 */     off += 4;
/*      */     
/*  587 */     int fileNameLen = ZipShort.getValue(this.CFH_BUF, off);
/*  588 */     off += 2;
/*      */     
/*  590 */     int extraLen = ZipShort.getValue(this.CFH_BUF, off);
/*  591 */     off += 2;
/*      */     
/*  593 */     int commentLen = ZipShort.getValue(this.CFH_BUF, off);
/*  594 */     off += 2;
/*      */     
/*  596 */     int diskStart = ZipShort.getValue(this.CFH_BUF, off);
/*  597 */     off += 2;
/*      */     
/*  599 */     ze.setInternalAttributes(ZipShort.getValue(this.CFH_BUF, off));
/*  600 */     off += 2;
/*      */     
/*  602 */     ze.setExternalAttributes(ZipLong.getValue(this.CFH_BUF, off));
/*  603 */     off += 4;
/*      */     
/*  605 */     byte[] fileName = new byte[fileNameLen];
/*  606 */     this.archive.readFully(fileName);
/*  607 */     ze.setName(entryEncoding.decode(fileName), fileName);
/*      */     
/*      */ 
/*  610 */     offset.headerOffset = ZipLong.getValue(this.CFH_BUF, off);
/*      */     
/*  612 */     this.entries.add(ze);
/*      */     
/*  614 */     byte[] cdExtraData = new byte[extraLen];
/*  615 */     this.archive.readFully(cdExtraData);
/*  616 */     ze.setCentralDirectoryExtra(cdExtraData);
/*      */     
/*  618 */     setSizesAndOffsetFromZip64Extra(ze, offset, diskStart);
/*      */     
/*  620 */     byte[] comment = new byte[commentLen];
/*  621 */     this.archive.readFully(comment);
/*  622 */     ze.setComment(entryEncoding.decode(comment));
/*      */     
/*  624 */     if ((!hasUTF8Flag) && (this.useUnicodeExtraFields)) {
/*  625 */       noUTF8Flag.put(ze, new NameAndComment(fileName, comment, null));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setSizesAndOffsetFromZip64Extra(ZipArchiveEntry ze, OffsetEntry offset, int diskStart)
/*      */     throws IOException
/*      */   {
/*  645 */     Zip64ExtendedInformationExtraField z64 = (Zip64ExtendedInformationExtraField)ze.getExtraField(Zip64ExtendedInformationExtraField.HEADER_ID);
/*      */     
/*      */ 
/*  648 */     if (z64 != null) {
/*  649 */       boolean hasUncompressedSize = ze.getSize() == 4294967295L;
/*  650 */       boolean hasCompressedSize = ze.getCompressedSize() == 4294967295L;
/*  651 */       boolean hasRelativeHeaderOffset = offset.headerOffset == 4294967295L;
/*      */       
/*  653 */       z64.reparseCentralDirectoryData(hasUncompressedSize, hasCompressedSize, hasRelativeHeaderOffset, diskStart == 65535);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  658 */       if (hasUncompressedSize) {
/*  659 */         ze.setSize(z64.getSize().getLongValue());
/*  660 */       } else if (hasCompressedSize) {
/*  661 */         z64.setSize(new ZipEightByteInteger(ze.getSize()));
/*      */       }
/*      */       
/*  664 */       if (hasCompressedSize) {
/*  665 */         ze.setCompressedSize(z64.getCompressedSize().getLongValue());
/*  666 */       } else if (hasUncompressedSize) {
/*  667 */         z64.setCompressedSize(new ZipEightByteInteger(ze.getCompressedSize()));
/*      */       }
/*      */       
/*  670 */       if (hasRelativeHeaderOffset) {
/*  671 */         offset.headerOffset = z64.getRelativeHeaderOffset().getLongValue();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void positionAtCentralDirectory()
/*      */     throws IOException
/*      */   {
/*  777 */     positionAtEndOfCentralDirectoryRecord();
/*  778 */     boolean found = false;
/*  779 */     boolean searchedForZip64EOCD = this.archive.getFilePointer() > 20L;
/*      */     
/*  781 */     if (searchedForZip64EOCD) {
/*  782 */       this.archive.seek(this.archive.getFilePointer() - 20L);
/*  783 */       this.archive.readFully(this.WORD_BUF);
/*  784 */       found = Arrays.equals(ZipArchiveOutputStream.ZIP64_EOCD_LOC_SIG, this.WORD_BUF);
/*      */     }
/*      */     
/*  787 */     if (!found)
/*      */     {
/*  789 */       if (searchedForZip64EOCD) {
/*  790 */         skipBytes(16);
/*      */       }
/*  792 */       positionAtCentralDirectory32();
/*      */     } else {
/*  794 */       positionAtCentralDirectory64();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void positionAtCentralDirectory64()
/*      */     throws IOException
/*      */   {
/*  809 */     skipBytes(4);
/*      */     
/*  811 */     this.archive.readFully(this.DWORD_BUF);
/*  812 */     this.archive.seek(ZipEightByteInteger.getLongValue(this.DWORD_BUF));
/*  813 */     this.archive.readFully(this.WORD_BUF);
/*  814 */     if (!Arrays.equals(this.WORD_BUF, ZipArchiveOutputStream.ZIP64_EOCD_SIG)) {
/*  815 */       throw new ZipException("archive's ZIP64 end of central directory locator is corrupt.");
/*      */     }
/*      */     
/*  818 */     skipBytes(44);
/*      */     
/*  820 */     this.archive.readFully(this.DWORD_BUF);
/*  821 */     this.archive.seek(ZipEightByteInteger.getLongValue(this.DWORD_BUF));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void positionAtCentralDirectory32()
/*      */     throws IOException
/*      */   {
/*  833 */     skipBytes(16);
/*  834 */     this.archive.readFully(this.WORD_BUF);
/*  835 */     this.archive.seek(ZipLong.getValue(this.WORD_BUF));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void positionAtEndOfCentralDirectoryRecord()
/*      */     throws IOException
/*      */   {
/*  844 */     boolean found = tryToLocateSignature(22L, 65557L, ZipArchiveOutputStream.EOCD_SIG);
/*      */     
/*  846 */     if (!found) {
/*  847 */       throw new ZipException("archive is not a ZIP archive");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean tryToLocateSignature(long minDistanceFromEnd, long maxDistanceFromEnd, byte[] sig)
/*      */     throws IOException
/*      */   {
/*  859 */     boolean found = false;
/*  860 */     long off = this.archive.length() - minDistanceFromEnd;
/*  861 */     long stopSearching = Math.max(0L, this.archive.length() - maxDistanceFromEnd);
/*      */     
/*  863 */     if (off >= 0L) {
/*  864 */       for (; off >= stopSearching; off -= 1L) {
/*  865 */         this.archive.seek(off);
/*  866 */         int curr = this.archive.read();
/*  867 */         if (curr == -1) {
/*      */           break;
/*      */         }
/*  870 */         if (curr == sig[0]) {
/*  871 */           curr = this.archive.read();
/*  872 */           if (curr == sig[1]) {
/*  873 */             curr = this.archive.read();
/*  874 */             if (curr == sig[2]) {
/*  875 */               curr = this.archive.read();
/*  876 */               if (curr == sig[3]) {
/*  877 */                 found = true;
/*  878 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  885 */     if (found) {
/*  886 */       this.archive.seek(off);
/*      */     }
/*  888 */     return found;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void skipBytes(int count)
/*      */     throws IOException
/*      */   {
/*  896 */     int totalSkipped = 0;
/*  897 */     while (totalSkipped < count) {
/*  898 */       int skippedNow = this.archive.skipBytes(count - totalSkipped);
/*  899 */       if (skippedNow <= 0) {
/*  900 */         throw new EOFException();
/*      */       }
/*  902 */       totalSkipped += skippedNow;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void resolveLocalFileHeaderData(Map<ZipArchiveEntry, NameAndComment> entriesWithoutUTF8Flag)
/*      */     throws IOException
/*      */   {
/*  931 */     for (ZipArchiveEntry zipArchiveEntry : this.entries)
/*      */     {
/*      */ 
/*  934 */       Entry ze = (Entry)zipArchiveEntry;
/*  935 */       OffsetEntry offsetEntry = ze.getOffsetEntry();
/*  936 */       long offset = offsetEntry.headerOffset;
/*  937 */       this.archive.seek(offset + 26L);
/*  938 */       this.archive.readFully(this.SHORT_BUF);
/*  939 */       int fileNameLen = ZipShort.getValue(this.SHORT_BUF);
/*  940 */       this.archive.readFully(this.SHORT_BUF);
/*  941 */       int extraFieldLen = ZipShort.getValue(this.SHORT_BUF);
/*  942 */       int lenToSkip = fileNameLen;
/*  943 */       while (lenToSkip > 0) {
/*  944 */         int skipped = this.archive.skipBytes(lenToSkip);
/*  945 */         if (skipped <= 0) {
/*  946 */           throw new IOException("failed to skip file name in local file header");
/*      */         }
/*      */         
/*  949 */         lenToSkip -= skipped;
/*      */       }
/*  951 */       byte[] localExtraData = new byte[extraFieldLen];
/*  952 */       this.archive.readFully(localExtraData);
/*  953 */       ze.setExtra(localExtraData);
/*  954 */       offsetEntry.dataOffset = (offset + 26L + 2L + 2L + fileNameLen + extraFieldLen);
/*      */       
/*      */ 
/*  957 */       if (entriesWithoutUTF8Flag.containsKey(ze)) {
/*  958 */         NameAndComment nc = (NameAndComment)entriesWithoutUTF8Flag.get(ze);
/*  959 */         ZipUtil.setNameAndCommentFromExtraFields(ze, nc.name, nc.comment);
/*      */       }
/*      */       
/*      */ 
/*  963 */       String name = ze.getName();
/*  964 */       LinkedList<ZipArchiveEntry> entriesOfThatName = (LinkedList)this.nameMap.get(name);
/*  965 */       if (entriesOfThatName == null) {
/*  966 */         entriesOfThatName = new LinkedList();
/*  967 */         this.nameMap.put(name, entriesOfThatName);
/*      */       }
/*  969 */       entriesOfThatName.addLast(ze);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean startsWithLocalFileHeader()
/*      */     throws IOException
/*      */   {
/*  978 */     this.archive.seek(0L);
/*  979 */     this.archive.readFully(this.WORD_BUF);
/*  980 */     return Arrays.equals(this.WORD_BUF, ZipArchiveOutputStream.LFH_SIG);
/*      */   }
/*      */   
/*      */ 
/*      */   private class BoundedInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private long remaining;
/*      */     
/*      */     private long loc;
/*      */     
/*  991 */     private boolean addDummyByte = false;
/*      */     
/*      */     BoundedInputStream(long start, long remaining) {
/*  994 */       this.remaining = remaining;
/*  995 */       this.loc = start;
/*      */     }
/*      */     
/*      */     public int read() throws IOException
/*      */     {
/* 1000 */       if (this.remaining-- <= 0L) {
/* 1001 */         if (this.addDummyByte) {
/* 1002 */           this.addDummyByte = false;
/* 1003 */           return 0;
/*      */         }
/* 1005 */         return -1;
/*      */       }
/* 1007 */       synchronized (ZipFile.this.archive) {
/* 1008 */         ZipFile.this.archive.seek(this.loc++);
/* 1009 */         return ZipFile.this.archive.read();
/*      */       }
/*      */     }
/*      */     
/*      */     public int read(byte[] b, int off, int len) throws IOException
/*      */     {
/* 1015 */       if (this.remaining <= 0L) {
/* 1016 */         if (this.addDummyByte) {
/* 1017 */           this.addDummyByte = false;
/* 1018 */           b[off] = 0;
/* 1019 */           return 1;
/*      */         }
/* 1021 */         return -1;
/*      */       }
/*      */       
/* 1024 */       if (len <= 0) {
/* 1025 */         return 0;
/*      */       }
/*      */       
/* 1028 */       if (len > this.remaining) {
/* 1029 */         len = (int)this.remaining;
/*      */       }
/* 1031 */       int ret = -1;
/* 1032 */       synchronized (ZipFile.this.archive) {
/* 1033 */         ZipFile.this.archive.seek(this.loc);
/* 1034 */         ret = ZipFile.this.archive.read(b, off, len);
/*      */       }
/* 1036 */       if (ret > 0) {
/* 1037 */         this.loc += ret;
/* 1038 */         this.remaining -= ret;
/*      */       }
/* 1040 */       return ret;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1048 */     void addDummy() { this.addDummyByte = true; }
/*      */   }
/*      */   
/*      */   private static final class NameAndComment {
/*      */     private final byte[] name;
/*      */     private final byte[] comment;
/*      */     
/*      */     private NameAndComment(byte[] name, byte[] comment) {
/* 1056 */       this.name = name;
/* 1057 */       this.comment = comment;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1069 */   private final Comparator<ZipArchiveEntry> OFFSET_COMPARATOR = new Comparator()
/*      */   {
/*      */     public int compare(ZipArchiveEntry e1, ZipArchiveEntry e2) {
/* 1072 */       if (e1 == e2) {
/* 1073 */         return 0;
/*      */       }
/*      */       
/* 1076 */       ZipFile.Entry ent1 = (e1 instanceof ZipFile.Entry) ? (ZipFile.Entry)e1 : null;
/* 1077 */       ZipFile.Entry ent2 = (e2 instanceof ZipFile.Entry) ? (ZipFile.Entry)e2 : null;
/* 1078 */       if (ent1 == null) {
/* 1079 */         return 1;
/*      */       }
/* 1081 */       if (ent2 == null) {
/* 1082 */         return -1;
/*      */       }
/* 1084 */       long val = ent1.getOffsetEntry().headerOffset - ent2.getOffsetEntry().headerOffset;
/*      */       
/* 1086 */       return val < 0L ? -1 : val == 0L ? 0 : 1;
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */   private static class Entry
/*      */     extends ZipArchiveEntry
/*      */   {
/*      */     private final ZipFile.OffsetEntry offsetEntry;
/*      */     
/*      */     Entry(ZipFile.OffsetEntry offset)
/*      */     {
/* 1098 */       this.offsetEntry = offset;
/*      */     }
/*      */     
/*      */     ZipFile.OffsetEntry getOffsetEntry() {
/* 1102 */       return this.offsetEntry;
/*      */     }
/*      */     
/*      */     public int hashCode()
/*      */     {
/* 1107 */       return 3 * super.hashCode() + (int)(ZipFile.OffsetEntry.access$200(this.offsetEntry) % 2147483647L);
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean equals(Object other)
/*      */     {
/* 1113 */       if (super.equals(other))
/*      */       {
/* 1115 */         Entry otherEntry = (Entry)other;
/* 1116 */         return (ZipFile.OffsetEntry.access$200(this.offsetEntry) == ZipFile.OffsetEntry.access$200(otherEntry.offsetEntry)) && (ZipFile.OffsetEntry.access$000(this.offsetEntry) == ZipFile.OffsetEntry.access$000(otherEntry.offsetEntry));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1121 */       return false;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */