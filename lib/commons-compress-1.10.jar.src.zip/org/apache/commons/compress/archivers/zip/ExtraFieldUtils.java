/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtraFieldUtils
/*     */ {
/*     */   private static final int WORD = 4;
/*  41 */   private static final Map<ZipShort, Class<?>> implementations = new ConcurrentHashMap();
/*  42 */   static { register(AsiExtraField.class);
/*  43 */     register(X5455_ExtendedTimestamp.class);
/*  44 */     register(X7875_NewUnix.class);
/*  45 */     register(JarMarker.class);
/*  46 */     register(UnicodePathExtraField.class);
/*  47 */     register(UnicodeCommentExtraField.class);
/*  48 */     register(Zip64ExtendedInformationExtraField.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void register(Class<?> c)
/*     */   {
/*     */     try
/*     */     {
/*  60 */       ZipExtraField ze = (ZipExtraField)c.newInstance();
/*  61 */       implementations.put(ze.getHeaderId(), c);
/*     */     } catch (ClassCastException cc) {
/*  63 */       throw new RuntimeException(c + " doesn't implement ZipExtraField");
/*     */     } catch (InstantiationException ie) {
/*  65 */       throw new RuntimeException(c + " is not a concrete class");
/*     */     } catch (IllegalAccessException ie) {
/*  67 */       throw new RuntimeException(c + "'s no-arg constructor is not public");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipExtraField createExtraField(ZipShort headerId)
/*     */     throws InstantiationException, IllegalAccessException
/*     */   {
/*  81 */     Class<?> c = (Class)implementations.get(headerId);
/*  82 */     if (c != null) {
/*  83 */       return (ZipExtraField)c.newInstance();
/*     */     }
/*  85 */     UnrecognizedExtraField u = new UnrecognizedExtraField();
/*  86 */     u.setHeaderId(headerId);
/*  87 */     return u;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipExtraField[] parse(byte[] data)
/*     */     throws ZipException
/*     */   {
/*  99 */     return parse(data, true, UnparseableExtraField.THROW);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipExtraField[] parse(byte[] data, boolean local)
/*     */     throws ZipException
/*     */   {
/* 113 */     return parse(data, local, UnparseableExtraField.THROW);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipExtraField[] parse(byte[] data, boolean local, UnparseableExtraField onUnparseableData)
/*     */     throws ZipException
/*     */   {
/* 132 */     List<ZipExtraField> v = new ArrayList();
/* 133 */     int start = 0;
/*     */     
/* 135 */     while (start <= data.length - 4) {
/* 136 */       ZipShort headerId = new ZipShort(data, start);
/* 137 */       int length = new ZipShort(data, start + 2).getValue();
/* 138 */       if (start + 4 + length > data.length) {
/* 139 */         switch (onUnparseableData.getKey()) {
/*     */         case 0: 
/* 141 */           throw new ZipException("bad extra field starting at " + start + ".  Block length of " + length + " bytes exceeds remaining" + " data of " + (data.length - start - 4) + " bytes.");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         case 2: 
/* 148 */           UnparseableExtraFieldData field = new UnparseableExtraFieldData();
/*     */           
/* 150 */           if (local) {
/* 151 */             field.parseFromLocalFileData(data, start, data.length - start);
/*     */           }
/*     */           else {
/* 154 */             field.parseFromCentralDirectoryData(data, start, data.length - start);
/*     */           }
/*     */           
/* 157 */           v.add(field);
/*     */         
/*     */ 
/*     */         case 1: 
/*     */           break;
/*     */         
/*     */ 
/*     */         default: 
/* 165 */           throw new ZipException("unknown UnparseableExtraField key: " + onUnparseableData.getKey());
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 170 */         ZipExtraField ze = createExtraField(headerId);
/* 171 */         if (local) {
/* 172 */           ze.parseFromLocalFileData(data, start + 4, length);
/*     */         } else {
/* 174 */           ze.parseFromCentralDirectoryData(data, start + 4, length);
/*     */         }
/*     */         
/* 177 */         v.add(ze);
/*     */       } catch (InstantiationException ie) {
/* 179 */         throw ((ZipException)new ZipException(ie.getMessage()).initCause(ie));
/*     */       } catch (IllegalAccessException iae) {
/* 181 */         throw ((ZipException)new ZipException(iae.getMessage()).initCause(iae));
/*     */       }
/* 183 */       start += length + 4;
/*     */     }
/*     */     
/* 186 */     ZipExtraField[] result = new ZipExtraField[v.size()];
/* 187 */     return (ZipExtraField[])v.toArray(result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] mergeLocalFileDataData(ZipExtraField[] data)
/*     */   {
/* 196 */     boolean lastIsUnparseableHolder = (data.length > 0) && ((data[(data.length - 1)] instanceof UnparseableExtraFieldData));
/*     */     
/* 198 */     int regularExtraFieldCount = lastIsUnparseableHolder ? data.length - 1 : data.length;
/*     */     
/*     */ 
/* 201 */     int sum = 4 * regularExtraFieldCount;
/* 202 */     for (ZipExtraField element : data) {
/* 203 */       sum += element.getLocalFileDataLength().getValue();
/*     */     }
/*     */     
/* 206 */     byte[] result = new byte[sum];
/* 207 */     int start = 0;
/* 208 */     for (int i = 0; i < regularExtraFieldCount; i++) {
/* 209 */       System.arraycopy(data[i].getHeaderId().getBytes(), 0, result, start, 2);
/*     */       
/* 211 */       System.arraycopy(data[i].getLocalFileDataLength().getBytes(), 0, result, start + 2, 2);
/*     */       
/* 213 */       start += 4;
/* 214 */       byte[] local = data[i].getLocalFileDataData();
/* 215 */       if (local != null) {
/* 216 */         System.arraycopy(local, 0, result, start, local.length);
/* 217 */         start += local.length;
/*     */       }
/*     */     }
/* 220 */     if (lastIsUnparseableHolder) {
/* 221 */       byte[] local = data[(data.length - 1)].getLocalFileDataData();
/* 222 */       if (local != null) {
/* 223 */         System.arraycopy(local, 0, result, start, local.length);
/*     */       }
/*     */     }
/* 226 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] mergeCentralDirectoryData(ZipExtraField[] data)
/*     */   {
/* 235 */     boolean lastIsUnparseableHolder = (data.length > 0) && ((data[(data.length - 1)] instanceof UnparseableExtraFieldData));
/*     */     
/* 237 */     int regularExtraFieldCount = lastIsUnparseableHolder ? data.length - 1 : data.length;
/*     */     
/*     */ 
/* 240 */     int sum = 4 * regularExtraFieldCount;
/* 241 */     for (ZipExtraField element : data) {
/* 242 */       sum += element.getCentralDirectoryLength().getValue();
/*     */     }
/* 244 */     byte[] result = new byte[sum];
/* 245 */     int start = 0;
/* 246 */     for (int i = 0; i < regularExtraFieldCount; i++) {
/* 247 */       System.arraycopy(data[i].getHeaderId().getBytes(), 0, result, start, 2);
/*     */       
/* 249 */       System.arraycopy(data[i].getCentralDirectoryLength().getBytes(), 0, result, start + 2, 2);
/*     */       
/* 251 */       start += 4;
/* 252 */       byte[] local = data[i].getCentralDirectoryData();
/* 253 */       if (local != null) {
/* 254 */         System.arraycopy(local, 0, result, start, local.length);
/* 255 */         start += local.length;
/*     */       }
/*     */     }
/* 258 */     if (lastIsUnparseableHolder) {
/* 259 */       byte[] local = data[(data.length - 1)].getCentralDirectoryData();
/* 260 */       if (local != null) {
/* 261 */         System.arraycopy(local, 0, result, start, local.length);
/*     */       }
/*     */     }
/* 264 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final class UnparseableExtraField
/*     */   {
/*     */     public static final int THROW_KEY = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public static final int SKIP_KEY = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public static final int READ_KEY = 2;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 290 */     public static final UnparseableExtraField THROW = new UnparseableExtraField(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 297 */     public static final UnparseableExtraField SKIP = new UnparseableExtraField(1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 304 */     public static final UnparseableExtraField READ = new UnparseableExtraField(2);
/*     */     
/*     */     private final int key;
/*     */     
/*     */     private UnparseableExtraField(int k)
/*     */     {
/* 310 */       this.key = k;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getKey()
/*     */     {
/* 317 */       return this.key;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ExtraFieldUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */