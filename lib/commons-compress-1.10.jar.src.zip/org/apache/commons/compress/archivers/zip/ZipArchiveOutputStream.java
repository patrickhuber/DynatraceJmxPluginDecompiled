/*      */ package org.apache.commons.compress.archivers.zip;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.zip.Deflater;
/*      */ import java.util.zip.ZipException;
/*      */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*      */ import org.apache.commons.compress.archivers.ArchiveOutputStream;
/*      */ import org.apache.commons.compress.utils.IOUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ZipArchiveOutputStream
/*      */   extends ArchiveOutputStream
/*      */ {
/*      */   static final int BUFFER_SIZE = 512;
/*      */   private static final int LFH_SIG_OFFSET = 0;
/*      */   private static final int LFH_VERSION_NEEDED_OFFSET = 4;
/*      */   private static final int LFH_GPB_OFFSET = 6;
/*      */   private static final int LFH_METHOD_OFFSET = 8;
/*      */   private static final int LFH_TIME_OFFSET = 10;
/*      */   private static final int LFH_CRC_OFFSET = 14;
/*      */   private static final int LFH_COMPRESSED_SIZE_OFFSET = 18;
/*      */   private static final int LFH_ORIGINAL_SIZE_OFFSET = 22;
/*      */   private static final int LFH_FILENAME_LENGTH_OFFSET = 26;
/*      */   private static final int LFH_EXTRA_LENGTH_OFFSET = 28;
/*      */   private static final int LFH_FILENAME_OFFSET = 30;
/*      */   private static final int CFH_SIG_OFFSET = 0;
/*      */   private static final int CFH_VERSION_MADE_BY_OFFSET = 4;
/*      */   private static final int CFH_VERSION_NEEDED_OFFSET = 6;
/*      */   private static final int CFH_GPB_OFFSET = 8;
/*      */   private static final int CFH_METHOD_OFFSET = 10;
/*      */   private static final int CFH_TIME_OFFSET = 12;
/*      */   private static final int CFH_CRC_OFFSET = 16;
/*      */   private static final int CFH_COMPRESSED_SIZE_OFFSET = 20;
/*      */   private static final int CFH_ORIGINAL_SIZE_OFFSET = 24;
/*      */   private static final int CFH_FILENAME_LENGTH_OFFSET = 28;
/*      */   private static final int CFH_EXTRA_LENGTH_OFFSET = 30;
/*      */   private static final int CFH_COMMENT_LENGTH_OFFSET = 32;
/*      */   private static final int CFH_DISK_NUMBER_OFFSET = 34;
/*      */   private static final int CFH_INTERNAL_ATTRIBUTES_OFFSET = 36;
/*      */   private static final int CFH_EXTERNAL_ATTRIBUTES_OFFSET = 38;
/*      */   private static final int CFH_LFH_OFFSET = 42;
/*      */   private static final int CFH_FILENAME_OFFSET = 46;
/*  112 */   protected boolean finished = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int DEFLATER_BLOCK_SIZE = 8192;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DEFLATED = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int DEFAULT_COMPRESSION = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int STORED = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final String DEFAULT_ENCODING = "UTF8";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static final int EFS_FLAG = 2048;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  151 */   private static final byte[] EMPTY = new byte[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private CurrentEntry entry;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  161 */   private String comment = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  166 */   private int level = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  172 */   private boolean hasCompressionLevelChanged = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  177 */   private int method = 8;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  182 */   private final List<ZipArchiveEntry> entries = new LinkedList();
/*      */   
/*      */ 
/*      */ 
/*      */   private final StreamCompressor streamCompressor;
/*      */   
/*      */ 
/*      */ 
/*  190 */   private long cdOffset = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  195 */   private long cdLength = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  200 */   private static final byte[] ZERO = { 0, 0 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  205 */   private static final byte[] LZERO = { 0, 0, 0, 0 };
/*      */   
/*  207 */   private static final byte[] ONE = ZipLong.getBytes(1L);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  212 */   private final Map<ZipArchiveEntry, Long> offsets = new HashMap();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  222 */   private String encoding = "UTF8";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  230 */   private ZipEncoding zipEncoding = ZipEncodingHelper.getZipEncoding("UTF8");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final Deflater def;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final RandomAccessFile raf;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final OutputStream out;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  250 */   private boolean useUTF8Flag = true;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  255 */   private boolean fallbackToUTF8 = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  260 */   private UnicodeExtraFieldPolicy createUnicodeExtraFields = UnicodeExtraFieldPolicy.NEVER;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  267 */   private boolean hasUsedZip64 = false;
/*      */   
/*  269 */   private Zip64Mode zip64Mode = Zip64Mode.AsNeeded;
/*      */   
/*  271 */   private final byte[] copyBuffer = new byte[32768];
/*  272 */   private final Calendar calendarInstance = Calendar.getInstance();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveOutputStream(OutputStream out)
/*      */   {
/*  279 */     this.out = out;
/*  280 */     this.raf = null;
/*  281 */     this.def = new Deflater(this.level, true);
/*  282 */     this.streamCompressor = StreamCompressor.create(out, this.def);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveOutputStream(File file)
/*      */     throws IOException
/*      */   {
/*  292 */     OutputStream o = null;
/*  293 */     RandomAccessFile _raf = null;
/*      */     try {
/*  295 */       _raf = new RandomAccessFile(file, "rw");
/*  296 */       _raf.setLength(0L);
/*      */     } catch (IOException e) {
/*  298 */       IOUtils.closeQuietly(_raf);
/*  299 */       _raf = null;
/*  300 */       o = new FileOutputStream(file);
/*      */     }
/*  302 */     this.def = new Deflater(this.level, true);
/*  303 */     this.streamCompressor = StreamCompressor.create(_raf, this.def);
/*  304 */     this.out = o;
/*  305 */     this.raf = _raf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSeekable()
/*      */   {
/*  318 */     return this.raf != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEncoding(String encoding)
/*      */   {
/*  331 */     this.encoding = encoding;
/*  332 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*  333 */     if ((this.useUTF8Flag) && (!ZipEncodingHelper.isUTF8(encoding))) {
/*  334 */       this.useUTF8Flag = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  344 */     return this.encoding;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseLanguageEncodingFlag(boolean b)
/*      */   {
/*  357 */     this.useUTF8Flag = ((b) && (ZipEncodingHelper.isUTF8(this.encoding)));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCreateUnicodeExtraFields(UnicodeExtraFieldPolicy b)
/*      */   {
/*  368 */     this.createUnicodeExtraFields = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFallbackToUTF8(boolean b)
/*      */   {
/*  382 */     this.fallbackToUTF8 = b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setUseZip64(Zip64Mode mode)
/*      */   {
/*  431 */     this.zip64Mode = mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void finish()
/*      */     throws IOException
/*      */   {
/*  442 */     if (this.finished) {
/*  443 */       throw new IOException("This archive has already been finished");
/*      */     }
/*      */     
/*  446 */     if (this.entry != null) {
/*  447 */       throw new IOException("This archive contains unclosed entries.");
/*      */     }
/*      */     
/*  450 */     this.cdOffset = this.streamCompressor.getTotalBytesWritten();
/*  451 */     writeCentralDirectoryInChunks();
/*      */     
/*  453 */     this.cdLength = (this.streamCompressor.getTotalBytesWritten() - this.cdOffset);
/*  454 */     writeZip64CentralDirectory();
/*  455 */     writeCentralDirectoryEnd();
/*  456 */     this.offsets.clear();
/*  457 */     this.entries.clear();
/*  458 */     this.streamCompressor.close();
/*  459 */     this.finished = true;
/*      */   }
/*      */   
/*      */   private void writeCentralDirectoryInChunks() throws IOException {
/*  463 */     int NUM_PER_WRITE = 1000;
/*  464 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(70 * NUM_PER_WRITE);
/*  465 */     int count = 0;
/*  466 */     for (ZipArchiveEntry ze : this.entries) {
/*  467 */       byteArrayOutputStream.write(createCentralFileHeader(ze));
/*  468 */       count++; if (count > NUM_PER_WRITE) {
/*  469 */         writeCounted(byteArrayOutputStream.toByteArray());
/*  470 */         byteArrayOutputStream.reset();
/*  471 */         count = 0;
/*      */       }
/*      */     }
/*  474 */     writeCounted(byteArrayOutputStream.toByteArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeArchiveEntry()
/*      */     throws IOException
/*      */   {
/*  486 */     preClose();
/*      */     
/*  488 */     flushDeflater();
/*      */     
/*  490 */     long bytesWritten = this.streamCompressor.getTotalBytesWritten() - this.entry.dataStart;
/*  491 */     long realCrc = this.streamCompressor.getCrc32();
/*  492 */     this.entry.bytesRead = this.streamCompressor.getBytesRead();
/*  493 */     Zip64Mode effectiveMode = getEffectiveZip64Mode(this.entry.entry);
/*  494 */     boolean actuallyNeedsZip64 = handleSizesAndCrc(bytesWritten, realCrc, effectiveMode);
/*  495 */     closeEntry(actuallyNeedsZip64, false);
/*  496 */     this.streamCompressor.reset();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void closeCopiedEntry(boolean phased)
/*      */     throws IOException
/*      */   {
/*  510 */     preClose();
/*  511 */     this.entry.bytesRead = this.entry.entry.getSize();
/*  512 */     Zip64Mode effectiveMode = getEffectiveZip64Mode(this.entry.entry);
/*  513 */     boolean actuallyNeedsZip64 = checkIfNeedsZip64(effectiveMode);
/*  514 */     closeEntry(actuallyNeedsZip64, phased);
/*      */   }
/*      */   
/*      */   private void closeEntry(boolean actuallyNeedsZip64, boolean phased) throws IOException {
/*  518 */     if ((!phased) && (this.raf != null)) {
/*  519 */       rewriteSizesAndCrc(actuallyNeedsZip64);
/*      */     }
/*      */     
/*  522 */     writeDataDescriptor(this.entry.entry);
/*  523 */     this.entry = null;
/*      */   }
/*      */   
/*      */   private void preClose() throws IOException {
/*  527 */     if (this.finished) {
/*  528 */       throw new IOException("Stream has already been finished");
/*      */     }
/*      */     
/*  531 */     if (this.entry == null) {
/*  532 */       throw new IOException("No current entry to close");
/*      */     }
/*      */     
/*  535 */     if (!this.entry.hasWritten) {
/*  536 */       write(EMPTY, 0, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRawArchiveEntry(ZipArchiveEntry entry, InputStream rawStream)
/*      */     throws IOException
/*      */   {
/*  555 */     ZipArchiveEntry ae = new ZipArchiveEntry(entry);
/*  556 */     if (hasZip64Extra(ae))
/*      */     {
/*      */ 
/*      */ 
/*  560 */       ae.removeExtraField(Zip64ExtendedInformationExtraField.HEADER_ID);
/*      */     }
/*  562 */     boolean is2PhaseSource = (ae.getCrc() != -1L) && (ae.getSize() != -1L) && (ae.getCompressedSize() != -1L);
/*      */     
/*      */ 
/*  565 */     putArchiveEntry(ae, is2PhaseSource);
/*  566 */     copyFromZipInputStream(rawStream);
/*  567 */     closeCopiedEntry(is2PhaseSource);
/*      */   }
/*      */   
/*      */ 
/*      */   private void flushDeflater()
/*      */     throws IOException
/*      */   {
/*  574 */     if (this.entry.entry.getMethod() == 8) {
/*  575 */       this.streamCompressor.flushDeflater();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean handleSizesAndCrc(long bytesWritten, long crc, Zip64Mode effectiveMode)
/*      */     throws ZipException
/*      */   {
/*  588 */     if (this.entry.entry.getMethod() == 8)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  593 */       this.entry.entry.setSize(this.entry.bytesRead);
/*  594 */       this.entry.entry.setCompressedSize(bytesWritten);
/*  595 */       this.entry.entry.setCrc(crc);
/*      */     }
/*  597 */     else if (this.raf == null) {
/*  598 */       if (this.entry.entry.getCrc() != crc) {
/*  599 */         throw new ZipException("bad CRC checksum for entry " + this.entry.entry.getName() + ": " + Long.toHexString(this.entry.entry.getCrc()) + " instead of " + Long.toHexString(crc));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  606 */       if (this.entry.entry.getSize() != bytesWritten) {
/*  607 */         throw new ZipException("bad size for entry " + this.entry.entry.getName() + ": " + this.entry.entry.getSize() + " instead of " + bytesWritten);
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  614 */       this.entry.entry.setSize(bytesWritten);
/*  615 */       this.entry.entry.setCompressedSize(bytesWritten);
/*  616 */       this.entry.entry.setCrc(crc);
/*      */     }
/*      */     
/*  619 */     return checkIfNeedsZip64(effectiveMode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkIfNeedsZip64(Zip64Mode effectiveMode)
/*      */     throws ZipException
/*      */   {
/*  630 */     boolean actuallyNeedsZip64 = isZip64Required(this.entry.entry, effectiveMode);
/*  631 */     if ((actuallyNeedsZip64) && (effectiveMode == Zip64Mode.Never)) {
/*  632 */       throw new Zip64RequiredException(Zip64RequiredException.getEntryTooBigMessage(this.entry.entry));
/*      */     }
/*  634 */     return actuallyNeedsZip64;
/*      */   }
/*      */   
/*      */   private boolean isZip64Required(ZipArchiveEntry entry1, Zip64Mode requestedMode) {
/*  638 */     return (requestedMode == Zip64Mode.Always) || (isTooLageForZip32(entry1));
/*      */   }
/*      */   
/*      */   private boolean isTooLageForZip32(ZipArchiveEntry zipArchiveEntry) {
/*  642 */     return (zipArchiveEntry.getSize() >= 4294967295L) || (zipArchiveEntry.getCompressedSize() >= 4294967295L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void rewriteSizesAndCrc(boolean actuallyNeedsZip64)
/*      */     throws IOException
/*      */   {
/*  652 */     long save = this.raf.getFilePointer();
/*      */     
/*  654 */     this.raf.seek(this.entry.localDataStart);
/*  655 */     writeOut(ZipLong.getBytes(this.entry.entry.getCrc()));
/*  656 */     if ((!hasZip64Extra(this.entry.entry)) || (!actuallyNeedsZip64)) {
/*  657 */       writeOut(ZipLong.getBytes(this.entry.entry.getCompressedSize()));
/*  658 */       writeOut(ZipLong.getBytes(this.entry.entry.getSize()));
/*      */     } else {
/*  660 */       writeOut(ZipLong.ZIP64_MAGIC.getBytes());
/*  661 */       writeOut(ZipLong.ZIP64_MAGIC.getBytes());
/*      */     }
/*      */     
/*  664 */     if (hasZip64Extra(this.entry.entry)) {
/*  665 */       ByteBuffer name = getName(this.entry.entry);
/*  666 */       int nameLen = name.limit() - name.position();
/*      */       
/*  668 */       this.raf.seek(this.entry.localDataStart + 12L + 4L + nameLen + 4L);
/*      */       
/*      */ 
/*      */ 
/*  672 */       writeOut(ZipEightByteInteger.getBytes(this.entry.entry.getSize()));
/*  673 */       writeOut(ZipEightByteInteger.getBytes(this.entry.entry.getCompressedSize()));
/*      */       
/*  675 */       if (!actuallyNeedsZip64)
/*      */       {
/*      */ 
/*  678 */         this.raf.seek(this.entry.localDataStart - 10L);
/*  679 */         writeOut(ZipShort.getBytes(10));
/*      */         
/*      */ 
/*      */ 
/*  683 */         this.entry.entry.removeExtraField(Zip64ExtendedInformationExtraField.HEADER_ID);
/*      */         
/*  685 */         this.entry.entry.setExtra();
/*      */         
/*      */ 
/*      */ 
/*  689 */         if (this.entry.causedUseOfZip64) {
/*  690 */           this.hasUsedZip64 = false;
/*      */         }
/*      */       }
/*      */     }
/*  694 */     this.raf.seek(save);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void putArchiveEntry(ArchiveEntry archiveEntry)
/*      */     throws IOException
/*      */   {
/*  706 */     putArchiveEntry(archiveEntry, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void putArchiveEntry(ArchiveEntry archiveEntry, boolean phased)
/*      */     throws IOException
/*      */   {
/*  722 */     if (this.finished) {
/*  723 */       throw new IOException("Stream has already been finished");
/*      */     }
/*      */     
/*  726 */     if (this.entry != null) {
/*  727 */       closeArchiveEntry();
/*      */     }
/*      */     
/*  730 */     this.entry = new CurrentEntry((ZipArchiveEntry)archiveEntry, null);
/*  731 */     this.entries.add(this.entry.entry);
/*      */     
/*  733 */     setDefaults(this.entry.entry);
/*      */     
/*  735 */     Zip64Mode effectiveMode = getEffectiveZip64Mode(this.entry.entry);
/*  736 */     validateSizeInformation(effectiveMode);
/*      */     
/*  738 */     if (shouldAddZip64Extra(this.entry.entry, effectiveMode))
/*      */     {
/*  740 */       Zip64ExtendedInformationExtraField z64 = getZip64Extra(this.entry.entry);
/*      */       
/*      */ 
/*      */ 
/*  744 */       ZipEightByteInteger size = ZipEightByteInteger.ZERO;
/*  745 */       ZipEightByteInteger compressedSize = ZipEightByteInteger.ZERO;
/*  746 */       if (phased) {
/*  747 */         size = new ZipEightByteInteger(this.entry.entry.getSize());
/*  748 */         compressedSize = new ZipEightByteInteger(this.entry.entry.getCompressedSize());
/*  749 */       } else if ((this.entry.entry.getMethod() == 0) && (this.entry.entry.getSize() != -1L))
/*      */       {
/*      */ 
/*  752 */         size = new ZipEightByteInteger(this.entry.entry.getSize());
/*  753 */         compressedSize = size;
/*      */       }
/*  755 */       z64.setSize(size);
/*  756 */       z64.setCompressedSize(compressedSize);
/*  757 */       this.entry.entry.setExtra();
/*      */     }
/*      */     
/*  760 */     if ((this.entry.entry.getMethod() == 8) && (this.hasCompressionLevelChanged)) {
/*  761 */       this.def.setLevel(this.level);
/*  762 */       this.hasCompressionLevelChanged = false;
/*      */     }
/*  764 */     writeLocalFileHeader((ZipArchiveEntry)archiveEntry, phased);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setDefaults(ZipArchiveEntry entry)
/*      */   {
/*  772 */     if (entry.getMethod() == -1) {
/*  773 */       entry.setMethod(this.method);
/*      */     }
/*      */     
/*  776 */     if (entry.getTime() == -1L) {
/*  777 */       entry.setTime(System.currentTimeMillis());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void validateSizeInformation(Zip64Mode effectiveMode)
/*      */     throws ZipException
/*      */   {
/*  790 */     if ((this.entry.entry.getMethod() == 0) && (this.raf == null)) {
/*  791 */       if (this.entry.entry.getSize() == -1L) {
/*  792 */         throw new ZipException("uncompressed size is required for STORED method when not writing to a file");
/*      */       }
/*      */       
/*      */ 
/*  796 */       if (this.entry.entry.getCrc() == -1L) {
/*  797 */         throw new ZipException("crc checksum is required for STORED method when not writing to a file");
/*      */       }
/*      */       
/*  800 */       this.entry.entry.setCompressedSize(this.entry.entry.getSize());
/*      */     }
/*      */     
/*  803 */     if (((this.entry.entry.getSize() >= 4294967295L) || (this.entry.entry.getCompressedSize() >= 4294967295L)) && (effectiveMode == Zip64Mode.Never))
/*      */     {
/*      */ 
/*  806 */       throw new Zip64RequiredException(Zip64RequiredException.getEntryTooBigMessage(this.entry.entry));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean shouldAddZip64Extra(ZipArchiveEntry entry, Zip64Mode mode)
/*      */   {
/*  826 */     return (mode == Zip64Mode.Always) || (entry.getSize() >= 4294967295L) || (entry.getCompressedSize() >= 4294967295L) || ((entry.getSize() == -1L) && (this.raf != null) && (mode != Zip64Mode.Never));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setComment(String comment)
/*      */   {
/*  838 */     this.comment = comment;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLevel(int level)
/*      */   {
/*  850 */     if ((level < -1) || (level > 9))
/*      */     {
/*  852 */       throw new IllegalArgumentException("Invalid compression level: " + level);
/*      */     }
/*      */     
/*  855 */     this.hasCompressionLevelChanged = (this.level != level);
/*  856 */     this.level = level;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMethod(int method)
/*      */   {
/*  866 */     this.method = method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canWriteEntryData(ArchiveEntry ae)
/*      */   {
/*  878 */     if ((ae instanceof ZipArchiveEntry)) {
/*  879 */       ZipArchiveEntry zae = (ZipArchiveEntry)ae;
/*  880 */       return (zae.getMethod() != ZipMethod.IMPLODING.getCode()) && (zae.getMethod() != ZipMethod.UNSHRINKING.getCode()) && (ZipUtil.canHandleEntryData(zae));
/*      */     }
/*      */     
/*      */ 
/*  884 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void write(byte[] b, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  896 */     if (this.entry == null) {
/*  897 */       throw new IllegalStateException("No current entry");
/*      */     }
/*  899 */     ZipUtil.checkRequestedFeatures(this.entry.entry);
/*  900 */     long writtenThisTime = this.streamCompressor.write(b, offset, length, this.entry.entry.getMethod());
/*  901 */     count(writtenThisTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeCounted(byte[] data)
/*      */     throws IOException
/*      */   {
/*  910 */     this.streamCompressor.writeCounted(data);
/*      */   }
/*      */   
/*      */   private void copyFromZipInputStream(InputStream src) throws IOException {
/*  914 */     if (this.entry == null) {
/*  915 */       throw new IllegalStateException("No current entry");
/*      */     }
/*  917 */     ZipUtil.checkRequestedFeatures(this.entry.entry);
/*  918 */     this.entry.hasWritten = true;
/*      */     int length;
/*  920 */     while ((length = src.read(this.copyBuffer)) >= 0)
/*      */     {
/*  922 */       this.streamCompressor.writeCounted(this.copyBuffer, 0, length);
/*  923 */       count(length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */     throws IOException
/*      */   {
/*  938 */     if (!this.finished) {
/*  939 */       finish();
/*      */     }
/*  941 */     destroy();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flush()
/*      */     throws IOException
/*      */   {
/*  952 */     if (this.out != null) {
/*  953 */       this.out.flush();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  963 */   static final byte[] LFH_SIG = ZipLong.LFH_SIG.getBytes();
/*      */   
/*      */ 
/*      */ 
/*  967 */   static final byte[] DD_SIG = ZipLong.DD_SIG.getBytes();
/*      */   
/*      */ 
/*      */ 
/*  971 */   static final byte[] CFH_SIG = ZipLong.CFH_SIG.getBytes();
/*      */   
/*      */ 
/*      */ 
/*  975 */   static final byte[] EOCD_SIG = ZipLong.getBytes(101010256L);
/*      */   
/*      */ 
/*      */ 
/*  979 */   static final byte[] ZIP64_EOCD_SIG = ZipLong.getBytes(101075792L);
/*      */   
/*      */ 
/*      */ 
/*  983 */   static final byte[] ZIP64_EOCD_LOC_SIG = ZipLong.getBytes(117853008L);
/*      */   
/*      */ 
/*      */ 
/*      */   protected final void deflate()
/*      */     throws IOException
/*      */   {
/*  990 */     this.streamCompressor.deflate();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeLocalFileHeader(ZipArchiveEntry ze)
/*      */     throws IOException
/*      */   {
/*  999 */     writeLocalFileHeader(ze, false);
/*      */   }
/*      */   
/*      */   private void writeLocalFileHeader(ZipArchiveEntry ze, boolean phased) throws IOException {
/* 1003 */     boolean encodable = this.zipEncoding.canEncode(ze.getName());
/* 1004 */     ByteBuffer name = getName(ze);
/*      */     
/* 1006 */     if (this.createUnicodeExtraFields != UnicodeExtraFieldPolicy.NEVER) {
/* 1007 */       addUnicodeExtraFields(ze, encodable, name);
/*      */     }
/*      */     
/* 1010 */     byte[] localHeader = createLocalFileHeader(ze, name, encodable, phased);
/* 1011 */     long localHeaderStart = this.streamCompressor.getTotalBytesWritten();
/* 1012 */     this.offsets.put(ze, Long.valueOf(localHeaderStart));
/* 1013 */     this.entry.localDataStart = (localHeaderStart + 14L);
/* 1014 */     writeCounted(localHeader);
/* 1015 */     this.entry.dataStart = this.streamCompressor.getTotalBytesWritten();
/*      */   }
/*      */   
/*      */ 
/*      */   private byte[] createLocalFileHeader(ZipArchiveEntry ze, ByteBuffer name, boolean encodable, boolean phased)
/*      */   {
/* 1021 */     byte[] extra = ze.getLocalFileDataExtra();
/* 1022 */     int nameLen = name.limit() - name.position();
/* 1023 */     int len = 30 + nameLen + extra.length;
/* 1024 */     byte[] buf = new byte[len];
/*      */     
/* 1026 */     System.arraycopy(LFH_SIG, 0, buf, 0, 4);
/*      */     
/*      */ 
/* 1029 */     int zipMethod = ze.getMethod();
/*      */     
/* 1031 */     if ((phased) && (!isZip64Required(this.entry.entry, this.zip64Mode))) {
/* 1032 */       ZipShort.putShort(10, buf, 4);
/*      */     } else {
/* 1034 */       ZipShort.putShort(versionNeededToExtract(zipMethod, hasZip64Extra(ze)), buf, 4);
/*      */     }
/*      */     
/* 1037 */     GeneralPurposeBit generalPurposeBit = getGeneralPurposeBits(zipMethod, (!encodable) && (this.fallbackToUTF8));
/* 1038 */     generalPurposeBit.encode(buf, 6);
/*      */     
/*      */ 
/* 1041 */     ZipShort.putShort(zipMethod, buf, 8);
/*      */     
/* 1043 */     ZipUtil.toDosTime(this.calendarInstance, ze.getTime(), buf, 10);
/*      */     
/*      */ 
/* 1046 */     if (phased) {
/* 1047 */       ZipLong.putLong(ze.getCrc(), buf, 14);
/* 1048 */     } else if ((zipMethod == 8) || (this.raf != null)) {
/* 1049 */       System.arraycopy(LZERO, 0, buf, 14, 4);
/*      */     } else {
/* 1051 */       ZipLong.putLong(ze.getCrc(), buf, 14);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1056 */     if (hasZip64Extra(this.entry.entry))
/*      */     {
/*      */ 
/*      */ 
/* 1060 */       ZipLong.ZIP64_MAGIC.putLong(buf, 18);
/* 1061 */       ZipLong.ZIP64_MAGIC.putLong(buf, 22);
/* 1062 */     } else if (phased) {
/* 1063 */       ZipLong.putLong(ze.getCompressedSize(), buf, 18);
/* 1064 */       ZipLong.putLong(ze.getSize(), buf, 22);
/* 1065 */     } else if ((zipMethod == 8) || (this.raf != null)) {
/* 1066 */       System.arraycopy(LZERO, 0, buf, 18, 4);
/* 1067 */       System.arraycopy(LZERO, 0, buf, 22, 4);
/*      */     } else {
/* 1069 */       ZipLong.putLong(ze.getSize(), buf, 18);
/* 1070 */       ZipLong.putLong(ze.getSize(), buf, 22);
/*      */     }
/*      */     
/* 1073 */     ZipShort.putShort(nameLen, buf, 26);
/*      */     
/*      */ 
/* 1076 */     ZipShort.putShort(extra.length, buf, 28);
/*      */     
/*      */ 
/* 1079 */     System.arraycopy(name.array(), name.arrayOffset(), buf, 30, nameLen);
/*      */     
/* 1081 */     System.arraycopy(extra, 0, buf, 30 + nameLen, extra.length);
/* 1082 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addUnicodeExtraFields(ZipArchiveEntry ze, boolean encodable, ByteBuffer name)
/*      */     throws IOException
/*      */   {
/* 1094 */     if ((this.createUnicodeExtraFields == UnicodeExtraFieldPolicy.ALWAYS) || (!encodable))
/*      */     {
/* 1096 */       ze.addExtraField(new UnicodePathExtraField(ze.getName(), name.array(), name.arrayOffset(), name.limit() - name.position()));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1103 */     String comm = ze.getComment();
/* 1104 */     if ((comm != null) && (!"".equals(comm)))
/*      */     {
/* 1106 */       boolean commentEncodable = this.zipEncoding.canEncode(comm);
/*      */       
/* 1108 */       if ((this.createUnicodeExtraFields == UnicodeExtraFieldPolicy.ALWAYS) || (!commentEncodable))
/*      */       {
/* 1110 */         ByteBuffer commentB = getEntryEncoding(ze).encode(comm);
/* 1111 */         ze.addExtraField(new UnicodeCommentExtraField(comm, commentB.array(), commentB.arrayOffset(), commentB.limit() - commentB.position()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeDataDescriptor(ZipArchiveEntry ze)
/*      */     throws IOException
/*      */   {
/* 1127 */     if ((ze.getMethod() != 8) || (this.raf != null)) {
/* 1128 */       return;
/*      */     }
/* 1130 */     writeCounted(DD_SIG);
/* 1131 */     writeCounted(ZipLong.getBytes(ze.getCrc()));
/* 1132 */     if (!hasZip64Extra(ze)) {
/* 1133 */       writeCounted(ZipLong.getBytes(ze.getCompressedSize()));
/* 1134 */       writeCounted(ZipLong.getBytes(ze.getSize()));
/*      */     } else {
/* 1136 */       writeCounted(ZipEightByteInteger.getBytes(ze.getCompressedSize()));
/* 1137 */       writeCounted(ZipEightByteInteger.getBytes(ze.getSize()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeCentralFileHeader(ZipArchiveEntry ze)
/*      */     throws IOException
/*      */   {
/* 1150 */     byte[] centralFileHeader = createCentralFileHeader(ze);
/* 1151 */     writeCounted(centralFileHeader);
/*      */   }
/*      */   
/*      */   private byte[] createCentralFileHeader(ZipArchiveEntry ze) throws IOException
/*      */   {
/* 1156 */     long lfhOffset = ((Long)this.offsets.get(ze)).longValue();
/* 1157 */     boolean needsZip64Extra = (hasZip64Extra(ze)) || (ze.getCompressedSize() >= 4294967295L) || (ze.getSize() >= 4294967295L) || (lfhOffset >= 4294967295L);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1162 */     if ((needsZip64Extra) && (this.zip64Mode == Zip64Mode.Never))
/*      */     {
/*      */ 
/*      */ 
/* 1166 */       throw new Zip64RequiredException("archive's size exceeds the limit of 4GByte.");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1171 */     handleZip64Extra(ze, lfhOffset, needsZip64Extra);
/*      */     
/* 1173 */     return createCentralFileHeader(ze, getName(ze), lfhOffset, needsZip64Extra);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private byte[] createCentralFileHeader(ZipArchiveEntry ze, ByteBuffer name, long lfhOffset, boolean needsZip64Extra)
/*      */     throws IOException
/*      */   {
/* 1185 */     byte[] extra = ze.getCentralDirectoryExtra();
/*      */     
/*      */ 
/* 1188 */     String comm = ze.getComment();
/* 1189 */     if (comm == null) {
/* 1190 */       comm = "";
/*      */     }
/*      */     
/* 1193 */     ByteBuffer commentB = getEntryEncoding(ze).encode(comm);
/* 1194 */     int nameLen = name.limit() - name.position();
/* 1195 */     int commentLen = commentB.limit() - commentB.position();
/* 1196 */     int len = 46 + nameLen + extra.length + commentLen;
/* 1197 */     byte[] buf = new byte[len];
/*      */     
/* 1199 */     System.arraycopy(CFH_SIG, 0, buf, 0, 4);
/*      */     
/*      */ 
/*      */ 
/* 1203 */     ZipShort.putShort(ze.getPlatform() << 8 | (!this.hasUsedZip64 ? 20 : 45), buf, 4);
/*      */     
/*      */ 
/* 1206 */     int zipMethod = ze.getMethod();
/* 1207 */     boolean encodable = this.zipEncoding.canEncode(ze.getName());
/* 1208 */     ZipShort.putShort(versionNeededToExtract(zipMethod, needsZip64Extra), buf, 6);
/* 1209 */     getGeneralPurposeBits(zipMethod, (!encodable) && (this.fallbackToUTF8)).encode(buf, 8);
/*      */     
/*      */ 
/* 1212 */     ZipShort.putShort(zipMethod, buf, 10);
/*      */     
/*      */ 
/*      */ 
/* 1216 */     ZipUtil.toDosTime(this.calendarInstance, ze.getTime(), buf, 12);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1221 */     ZipLong.putLong(ze.getCrc(), buf, 16);
/* 1222 */     if ((ze.getCompressedSize() >= 4294967295L) || (ze.getSize() >= 4294967295L))
/*      */     {
/* 1224 */       ZipLong.ZIP64_MAGIC.putLong(buf, 20);
/* 1225 */       ZipLong.ZIP64_MAGIC.putLong(buf, 24);
/*      */     } else {
/* 1227 */       ZipLong.putLong(ze.getCompressedSize(), buf, 20);
/* 1228 */       ZipLong.putLong(ze.getSize(), buf, 24);
/*      */     }
/*      */     
/* 1231 */     ZipShort.putShort(nameLen, buf, 28);
/*      */     
/*      */ 
/* 1234 */     ZipShort.putShort(extra.length, buf, 30);
/*      */     
/* 1236 */     ZipShort.putShort(commentLen, buf, 32);
/*      */     
/*      */ 
/* 1239 */     System.arraycopy(ZERO, 0, buf, 34, 2);
/*      */     
/*      */ 
/* 1242 */     ZipShort.putShort(ze.getInternalAttributes(), buf, 36);
/*      */     
/*      */ 
/* 1245 */     ZipLong.putLong(ze.getExternalAttributes(), buf, 38);
/*      */     
/*      */ 
/* 1248 */     ZipLong.putLong(Math.min(lfhOffset, 4294967295L), buf, 42);
/*      */     
/*      */ 
/* 1251 */     System.arraycopy(name.array(), name.arrayOffset(), buf, 46, nameLen);
/*      */     
/* 1253 */     int extraStart = 46 + nameLen;
/* 1254 */     System.arraycopy(extra, 0, buf, extraStart, extra.length);
/*      */     
/* 1256 */     int commentStart = extraStart + extra.length;
/*      */     
/*      */ 
/* 1259 */     System.arraycopy(commentB.array(), commentB.arrayOffset(), buf, commentStart, commentLen);
/* 1260 */     return buf;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleZip64Extra(ZipArchiveEntry ze, long lfhOffset, boolean needsZip64Extra)
/*      */   {
/* 1269 */     if (needsZip64Extra) {
/* 1270 */       Zip64ExtendedInformationExtraField z64 = getZip64Extra(ze);
/* 1271 */       if ((ze.getCompressedSize() >= 4294967295L) || (ze.getSize() >= 4294967295L))
/*      */       {
/* 1273 */         z64.setCompressedSize(new ZipEightByteInteger(ze.getCompressedSize()));
/* 1274 */         z64.setSize(new ZipEightByteInteger(ze.getSize()));
/*      */       }
/*      */       else {
/* 1277 */         z64.setCompressedSize(null);
/* 1278 */         z64.setSize(null);
/*      */       }
/* 1280 */       if (lfhOffset >= 4294967295L) {
/* 1281 */         z64.setRelativeHeaderOffset(new ZipEightByteInteger(lfhOffset));
/*      */       }
/* 1283 */       ze.setExtra();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeCentralDirectoryEnd()
/*      */     throws IOException
/*      */   {
/* 1295 */     writeCounted(EOCD_SIG);
/*      */     
/*      */ 
/* 1298 */     writeCounted(ZERO);
/* 1299 */     writeCounted(ZERO);
/*      */     
/*      */ 
/* 1302 */     int numberOfEntries = this.entries.size();
/* 1303 */     if ((numberOfEntries > 65535) && (this.zip64Mode == Zip64Mode.Never))
/*      */     {
/* 1305 */       throw new Zip64RequiredException("archive contains more than 65535 entries.");
/*      */     }
/*      */     
/* 1308 */     if ((this.cdOffset > 4294967295L) && (this.zip64Mode == Zip64Mode.Never)) {
/* 1309 */       throw new Zip64RequiredException("archive's size exceeds the limit of 4GByte.");
/*      */     }
/*      */     
/*      */ 
/* 1313 */     byte[] num = ZipShort.getBytes(Math.min(numberOfEntries, 65535));
/*      */     
/* 1315 */     writeCounted(num);
/* 1316 */     writeCounted(num);
/*      */     
/*      */ 
/* 1319 */     writeCounted(ZipLong.getBytes(Math.min(this.cdLength, 4294967295L)));
/* 1320 */     writeCounted(ZipLong.getBytes(Math.min(this.cdOffset, 4294967295L)));
/*      */     
/*      */ 
/* 1323 */     ByteBuffer data = this.zipEncoding.encode(this.comment);
/* 1324 */     int dataLen = data.limit() - data.position();
/* 1325 */     writeCounted(ZipShort.getBytes(dataLen));
/* 1326 */     this.streamCompressor.writeCounted(data.array(), data.arrayOffset(), dataLen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void writeZip64CentralDirectory()
/*      */     throws IOException
/*      */   {
/* 1336 */     if (this.zip64Mode == Zip64Mode.Never) {
/* 1337 */       return;
/*      */     }
/*      */     
/* 1340 */     if ((!this.hasUsedZip64) && ((this.cdOffset >= 4294967295L) || (this.cdLength >= 4294967295L) || (this.entries.size() >= 65535)))
/*      */     {
/*      */ 
/*      */ 
/* 1344 */       this.hasUsedZip64 = true;
/*      */     }
/*      */     
/* 1347 */     if (!this.hasUsedZip64) {
/* 1348 */       return;
/*      */     }
/*      */     
/* 1351 */     long offset = this.streamCompressor.getTotalBytesWritten();
/*      */     
/* 1353 */     writeOut(ZIP64_EOCD_SIG);
/*      */     
/*      */ 
/* 1356 */     writeOut(ZipEightByteInteger.getBytes(44L));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1368 */     writeOut(ZipShort.getBytes(45));
/* 1369 */     writeOut(ZipShort.getBytes(45));
/*      */     
/*      */ 
/* 1372 */     writeOut(LZERO);
/* 1373 */     writeOut(LZERO);
/*      */     
/*      */ 
/* 1376 */     byte[] num = ZipEightByteInteger.getBytes(this.entries.size());
/* 1377 */     writeOut(num);
/* 1378 */     writeOut(num);
/*      */     
/*      */ 
/* 1381 */     writeOut(ZipEightByteInteger.getBytes(this.cdLength));
/* 1382 */     writeOut(ZipEightByteInteger.getBytes(this.cdOffset));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1387 */     writeOut(ZIP64_EOCD_LOC_SIG);
/*      */     
/*      */ 
/* 1390 */     writeOut(LZERO);
/*      */     
/* 1392 */     writeOut(ZipEightByteInteger.getBytes(offset));
/*      */     
/* 1394 */     writeOut(ONE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void writeOut(byte[] data)
/*      */     throws IOException
/*      */   {
/* 1403 */     this.streamCompressor.writeOut(data, 0, data.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void writeOut(byte[] data, int offset, int length)
/*      */     throws IOException
/*      */   {
/* 1416 */     this.streamCompressor.writeOut(data, offset, length);
/*      */   }
/*      */   
/*      */   private GeneralPurposeBit getGeneralPurposeBits(int zipMethod, boolean utfFallback)
/*      */   {
/* 1421 */     GeneralPurposeBit b = new GeneralPurposeBit();
/* 1422 */     b.useUTF8ForNames((this.useUTF8Flag) || (utfFallback));
/* 1423 */     if (isDeflatedToOutputStream(zipMethod)) {
/* 1424 */       b.useDataDescriptor(true);
/*      */     }
/* 1426 */     return b;
/*      */   }
/*      */   
/*      */   private int versionNeededToExtract(int zipMethod, boolean zip64) {
/* 1430 */     if (zip64) {
/* 1431 */       return 45;
/*      */     }
/*      */     
/*      */ 
/* 1435 */     return isDeflatedToOutputStream(zipMethod) ? 20 : 10;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean isDeflatedToOutputStream(int zipMethod)
/*      */   {
/* 1441 */     return (zipMethod == 8) && (this.raf == null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ArchiveEntry createArchiveEntry(File inputFile, String entryName)
/*      */     throws IOException
/*      */   {
/* 1459 */     if (this.finished) {
/* 1460 */       throw new IOException("Stream has already been finished");
/*      */     }
/* 1462 */     return new ZipArchiveEntry(inputFile, entryName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Zip64ExtendedInformationExtraField getZip64Extra(ZipArchiveEntry ze)
/*      */   {
/* 1473 */     if (this.entry != null) {
/* 1474 */       this.entry.causedUseOfZip64 = (!this.hasUsedZip64);
/*      */     }
/* 1476 */     this.hasUsedZip64 = true;
/* 1477 */     Zip64ExtendedInformationExtraField z64 = (Zip64ExtendedInformationExtraField)ze.getExtraField(Zip64ExtendedInformationExtraField.HEADER_ID);
/*      */     
/*      */ 
/*      */ 
/* 1481 */     if (z64 == null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1488 */       z64 = new Zip64ExtendedInformationExtraField();
/*      */     }
/*      */     
/*      */ 
/* 1492 */     ze.addAsFirstExtraField(z64);
/*      */     
/* 1494 */     return z64;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean hasZip64Extra(ZipArchiveEntry ze)
/*      */   {
/* 1504 */     return ze.getExtraField(Zip64ExtendedInformationExtraField.HEADER_ID) != null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Zip64Mode getEffectiveZip64Mode(ZipArchiveEntry ze)
/*      */   {
/* 1517 */     if ((this.zip64Mode != Zip64Mode.AsNeeded) || (this.raf != null) || (ze.getMethod() != 8) || (ze.getSize() != -1L))
/*      */     {
/*      */ 
/*      */ 
/* 1521 */       return this.zip64Mode;
/*      */     }
/* 1523 */     return Zip64Mode.Never;
/*      */   }
/*      */   
/*      */   private ZipEncoding getEntryEncoding(ZipArchiveEntry ze) {
/* 1527 */     boolean encodable = this.zipEncoding.canEncode(ze.getName());
/* 1528 */     return (!encodable) && (this.fallbackToUTF8) ? ZipEncodingHelper.UTF8_ZIP_ENCODING : this.zipEncoding;
/*      */   }
/*      */   
/*      */   private ByteBuffer getName(ZipArchiveEntry ze) throws IOException
/*      */   {
/* 1533 */     return getEntryEncoding(ze).encode(ze.getName());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void destroy()
/*      */     throws IOException
/*      */   {
/* 1544 */     if (this.raf != null) {
/* 1545 */       this.raf.close();
/*      */     }
/* 1547 */     if (this.out != null) {
/* 1548 */       this.out.close();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final class UnicodeExtraFieldPolicy
/*      */   {
/* 1560 */     public static final UnicodeExtraFieldPolicy ALWAYS = new UnicodeExtraFieldPolicy("always");
/*      */     
/*      */ 
/*      */ 
/* 1564 */     public static final UnicodeExtraFieldPolicy NEVER = new UnicodeExtraFieldPolicy("never");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1569 */     public static final UnicodeExtraFieldPolicy NOT_ENCODEABLE = new UnicodeExtraFieldPolicy("not encodeable");
/*      */     private final String name;
/*      */     
/*      */     private UnicodeExtraFieldPolicy(String n)
/*      */     {
/* 1574 */       this.name = n;
/*      */     }
/*      */     
/*      */     public String toString() {
/* 1578 */       return this.name;
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class CurrentEntry
/*      */   {
/*      */     private final ZipArchiveEntry entry;
/*      */     
/*      */     private CurrentEntry(ZipArchiveEntry entry)
/*      */     {
/* 1588 */       this.entry = entry;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1598 */     private long localDataStart = 0L;
/*      */     
/*      */ 
/*      */ 
/* 1602 */     private long dataStart = 0L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1607 */     private long bytesRead = 0L;
/*      */     
/*      */ 
/*      */ 
/* 1611 */     private boolean causedUseOfZip64 = false;
/*      */     private boolean hasWritten;
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipArchiveOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */