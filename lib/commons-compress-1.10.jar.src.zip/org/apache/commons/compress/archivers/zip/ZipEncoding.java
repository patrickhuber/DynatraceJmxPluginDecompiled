package org.apache.commons.compress.archivers.zip;

import java.io.IOException;
import java.nio.ByteBuffer;

public abstract interface ZipEncoding
{
  public abstract boolean canEncode(String paramString);
  
  public abstract ByteBuffer encode(String paramString)
    throws IOException;
  
  public abstract String decode(byte[] paramArrayOfByte)
    throws IOException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipEncoding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */