/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigInteger;
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X7875_NewUnix
/*     */   implements ZipExtraField, Cloneable, Serializable
/*     */ {
/*  48 */   private static final ZipShort HEADER_ID = new ZipShort(30837);
/*  49 */   private static final BigInteger ONE_THOUSAND = BigInteger.valueOf(1000L);
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*  52 */   private int version = 1;
/*     */   
/*     */ 
/*     */ 
/*     */   private BigInteger uid;
/*     */   
/*     */ 
/*     */ 
/*     */   private BigInteger gid;
/*     */   
/*     */ 
/*     */ 
/*     */   public X7875_NewUnix()
/*     */   {
/*  66 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getHeaderId()
/*     */   {
/*  75 */     return HEADER_ID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getUID()
/*     */   {
/*  86 */     return ZipUtil.bigToLong(this.uid);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getGID()
/*     */   {
/*  96 */     return ZipUtil.bigToLong(this.gid);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUID(long l)
/*     */   {
/* 104 */     this.uid = ZipUtil.longToBig(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGID(long l)
/*     */   {
/* 113 */     this.gid = ZipUtil.longToBig(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getLocalFileDataLength()
/*     */   {
/* 123 */     int uidSize = trimLeadingZeroesForceMinLength(this.uid.toByteArray()).length;
/* 124 */     int gidSize = trimLeadingZeroesForceMinLength(this.gid.toByteArray()).length;
/*     */     
/*     */ 
/* 127 */     return new ZipShort(3 + uidSize + gidSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getCentralDirectoryLength()
/*     */   {
/* 137 */     return getLocalFileDataLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getLocalFileDataData()
/*     */   {
/* 147 */     byte[] uidBytes = this.uid.toByteArray();
/* 148 */     byte[] gidBytes = this.gid.toByteArray();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 153 */     uidBytes = trimLeadingZeroesForceMinLength(uidBytes);
/* 154 */     gidBytes = trimLeadingZeroesForceMinLength(gidBytes);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 161 */     byte[] data = new byte[3 + uidBytes.length + gidBytes.length];
/*     */     
/*     */ 
/* 164 */     ZipUtil.reverse(uidBytes);
/* 165 */     ZipUtil.reverse(gidBytes);
/*     */     
/* 167 */     int pos = 0;
/* 168 */     data[(pos++)] = ZipUtil.unsignedIntToSignedByte(this.version);
/* 169 */     data[(pos++)] = ZipUtil.unsignedIntToSignedByte(uidBytes.length);
/* 170 */     System.arraycopy(uidBytes, 0, data, pos, uidBytes.length);
/* 171 */     pos += uidBytes.length;
/* 172 */     data[(pos++)] = ZipUtil.unsignedIntToSignedByte(gidBytes.length);
/* 173 */     System.arraycopy(gidBytes, 0, data, pos, gidBytes.length);
/* 174 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCentralDirectoryData()
/*     */   {
/* 184 */     return getLocalFileDataData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromLocalFileData(byte[] data, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 198 */     reset();
/* 199 */     this.version = ZipUtil.signedByteToUnsignedInt(data[(offset++)]);
/* 200 */     int uidSize = ZipUtil.signedByteToUnsignedInt(data[(offset++)]);
/* 201 */     byte[] uidBytes = new byte[uidSize];
/* 202 */     System.arraycopy(data, offset, uidBytes, 0, uidSize);
/* 203 */     offset += uidSize;
/* 204 */     this.uid = new BigInteger(1, ZipUtil.reverse(uidBytes));
/*     */     
/* 206 */     int gidSize = ZipUtil.signedByteToUnsignedInt(data[(offset++)]);
/* 207 */     byte[] gidBytes = new byte[gidSize];
/* 208 */     System.arraycopy(data, offset, gidBytes, 0, gidSize);
/* 209 */     this.gid = new BigInteger(1, ZipUtil.reverse(gidBytes));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromCentralDirectoryData(byte[] buffer, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 219 */     reset();
/* 220 */     parseFromLocalFileData(buffer, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reset()
/*     */   {
/* 229 */     this.uid = ONE_THOUSAND;
/* 230 */     this.gid = ONE_THOUSAND;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 242 */     return "0x7875 Zip Extra Field: UID=" + this.uid + " GID=" + this.gid;
/*     */   }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/* 247 */     return super.clone();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 252 */     if ((o instanceof X7875_NewUnix)) {
/* 253 */       X7875_NewUnix xf = (X7875_NewUnix)o;
/*     */       
/* 255 */       return (this.version == xf.version) && (this.uid.equals(xf.uid)) && (this.gid.equals(xf.gid));
/*     */     }
/* 257 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 262 */     int hc = -1234567 * this.version;
/*     */     
/*     */ 
/*     */ 
/* 266 */     hc ^= Integer.rotateLeft(this.uid.hashCode(), 16);
/* 267 */     hc ^= this.gid.hashCode();
/* 268 */     return hc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] trimLeadingZeroesForceMinLength(byte[] array)
/*     */   {
/* 281 */     if (array == null) {
/* 282 */       return array;
/*     */     }
/*     */     
/* 285 */     int pos = 0;
/* 286 */     for (byte b : array) {
/* 287 */       if (b != 0) break;
/* 288 */       pos++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 331 */     int MIN_LENGTH = 1;
/*     */     
/* 333 */     byte[] trimmedArray = new byte[Math.max(1, array.length - pos)];
/* 334 */     int startPos = trimmedArray.length - (array.length - pos);
/* 335 */     System.arraycopy(array, pos, trimmedArray, startPos, trimmedArray.length - startPos);
/* 336 */     return trimmedArray;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\X7875_NewUnix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */