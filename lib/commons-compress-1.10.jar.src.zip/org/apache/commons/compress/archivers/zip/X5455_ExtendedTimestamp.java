/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class X5455_ExtendedTimestamp
/*     */   implements ZipExtraField, Cloneable, Serializable
/*     */ {
/*  84 */   private static final ZipShort HEADER_ID = new ZipShort(21589);
/*     */   
/*     */ 
/*     */ 
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final byte MODIFY_TIME_BIT = 1;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final byte ACCESS_TIME_BIT = 2;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final byte CREATE_TIME_BIT = 4;
/*     */   
/*     */ 
/*     */ 
/*     */   private byte flags;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean bit0_modifyTimePresent;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean bit1_accessTimePresent;
/*     */   
/*     */ 
/*     */   private boolean bit2_createTimePresent;
/*     */   
/*     */ 
/*     */   private ZipLong modifyTime;
/*     */   
/*     */ 
/*     */   private ZipLong accessTime;
/*     */   
/*     */ 
/*     */   private ZipLong createTime;
/*     */   
/*     */ 
/*     */ 
/*     */   public ZipShort getHeaderId()
/*     */   {
/* 130 */     return HEADER_ID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getLocalFileDataLength()
/*     */   {
/* 140 */     return new ZipShort(1 + (this.bit0_modifyTimePresent ? 4 : 0) + ((this.bit1_accessTimePresent) && (this.accessTime != null) ? 4 : 0) + ((this.bit2_createTimePresent) && (this.createTime != null) ? 4 : 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getCentralDirectoryLength()
/*     */   {
/* 158 */     return new ZipShort(1 + (this.bit0_modifyTimePresent ? 4 : 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getLocalFileDataData()
/*     */   {
/* 170 */     byte[] data = new byte[getLocalFileDataLength().getValue()];
/* 171 */     int pos = 0;
/* 172 */     data[(pos++)] = 0;
/* 173 */     if (this.bit0_modifyTimePresent) {
/* 174 */       int tmp28_27 = 0; byte[] tmp28_26 = data;tmp28_26[tmp28_27] = ((byte)(tmp28_26[tmp28_27] | 0x1));
/* 175 */       System.arraycopy(this.modifyTime.getBytes(), 0, data, pos, 4);
/* 176 */       pos += 4;
/*     */     }
/* 178 */     if ((this.bit1_accessTimePresent) && (this.accessTime != null)) {
/* 179 */       int tmp67_66 = 0; byte[] tmp67_65 = data;tmp67_65[tmp67_66] = ((byte)(tmp67_65[tmp67_66] | 0x2));
/* 180 */       System.arraycopy(this.accessTime.getBytes(), 0, data, pos, 4);
/* 181 */       pos += 4;
/*     */     }
/* 183 */     if ((this.bit2_createTimePresent) && (this.createTime != null)) {
/* 184 */       int tmp106_105 = 0; byte[] tmp106_104 = data;tmp106_104[tmp106_105] = ((byte)(tmp106_104[tmp106_105] | 0x4));
/* 185 */       System.arraycopy(this.createTime.getBytes(), 0, data, pos, 4);
/* 186 */       pos += 4;
/*     */     }
/* 188 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCentralDirectoryData()
/*     */   {
/* 198 */     byte[] centralData = new byte[getCentralDirectoryLength().getValue()];
/* 199 */     byte[] localData = getLocalFileDataData();
/*     */     
/*     */ 
/*     */ 
/* 203 */     System.arraycopy(localData, 0, centralData, 0, centralData.length);
/* 204 */     return centralData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromLocalFileData(byte[] data, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 218 */     reset();
/* 219 */     int len = offset + length;
/* 220 */     setFlags(data[(offset++)]);
/* 221 */     if (this.bit0_modifyTimePresent) {
/* 222 */       this.modifyTime = new ZipLong(data, offset);
/* 223 */       offset += 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 228 */     if ((this.bit1_accessTimePresent) && (offset + 4 <= len)) {
/* 229 */       this.accessTime = new ZipLong(data, offset);
/* 230 */       offset += 4;
/*     */     }
/* 232 */     if ((this.bit2_createTimePresent) && (offset + 4 <= len)) {
/* 233 */       this.createTime = new ZipLong(data, offset);
/* 234 */       offset += 4;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromCentralDirectoryData(byte[] buffer, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 245 */     reset();
/* 246 */     parseFromLocalFileData(buffer, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reset()
/*     */   {
/* 254 */     setFlags((byte)0);
/* 255 */     this.modifyTime = null;
/* 256 */     this.accessTime = null;
/* 257 */     this.createTime = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlags(byte flags)
/*     */   {
/* 275 */     this.flags = flags;
/* 276 */     this.bit0_modifyTimePresent = ((flags & 0x1) == 1);
/* 277 */     this.bit1_accessTimePresent = ((flags & 0x2) == 2);
/* 278 */     this.bit2_createTimePresent = ((flags & 0x4) == 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte getFlags()
/*     */   {
/* 295 */     return this.flags;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBit0_modifyTimePresent()
/*     */   {
/* 304 */     return this.bit0_modifyTimePresent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBit1_accessTimePresent()
/*     */   {
/* 313 */     return this.bit1_accessTimePresent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBit2_createTimePresent()
/*     */   {
/* 322 */     return this.bit2_createTimePresent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong getModifyTime()
/*     */   {
/* 331 */     return this.modifyTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong getAccessTime()
/*     */   {
/* 340 */     return this.accessTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong getCreateTime()
/*     */   {
/* 355 */     return this.createTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getModifyJavaTime()
/*     */   {
/* 366 */     return this.modifyTime != null ? new Date(this.modifyTime.getValue() * 1000L) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getAccessJavaTime()
/*     */   {
/* 378 */     return this.accessTime != null ? new Date(this.accessTime.getValue() * 1000L) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Date getCreateJavaTime()
/*     */   {
/* 396 */     return this.createTime != null ? new Date(this.createTime.getValue() * 1000L) : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModifyTime(ZipLong l)
/*     */   {
/* 412 */     this.bit0_modifyTimePresent = (l != null);
/* 413 */     this.flags = ((byte)(l != null ? this.flags | 0x1 : this.flags & 0xFFFFFFFE));
/*     */     
/* 415 */     this.modifyTime = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessTime(ZipLong l)
/*     */   {
/* 431 */     this.bit1_accessTimePresent = (l != null);
/* 432 */     this.flags = ((byte)(l != null ? this.flags | 0x2 : this.flags & 0xFFFFFFFD));
/*     */     
/* 434 */     this.accessTime = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreateTime(ZipLong l)
/*     */   {
/* 450 */     this.bit2_createTimePresent = (l != null);
/* 451 */     this.flags = ((byte)(l != null ? this.flags | 0x4 : this.flags & 0xFFFFFFFB));
/*     */     
/* 453 */     this.createTime = l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModifyJavaTime(Date d)
/*     */   {
/* 469 */     setModifyTime(dateToZipLong(d));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAccessJavaTime(Date d)
/*     */   {
/* 484 */     setAccessTime(dateToZipLong(d));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCreateJavaTime(Date d)
/*     */   {
/* 499 */     setCreateTime(dateToZipLong(d));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static ZipLong dateToZipLong(Date d)
/*     */   {
/* 512 */     if (d == null) { return null;
/*     */     }
/* 514 */     long TWO_TO_32 = 4294967296L;
/* 515 */     long l = d.getTime() / 1000L;
/* 516 */     if (l >= 4294967296L) {
/* 517 */       throw new IllegalArgumentException("Cannot set an X5455 timestamp larger than 2^32: " + l);
/*     */     }
/* 519 */     return new ZipLong(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 531 */     StringBuilder buf = new StringBuilder();
/* 532 */     buf.append("0x5455 Zip Extra Field: Flags=");
/* 533 */     buf.append(Integer.toBinaryString(ZipUtil.unsignedIntToSignedByte(this.flags))).append(" ");
/* 534 */     if ((this.bit0_modifyTimePresent) && (this.modifyTime != null)) {
/* 535 */       Date m = getModifyJavaTime();
/* 536 */       buf.append(" Modify:[").append(m).append("] ");
/*     */     }
/* 538 */     if ((this.bit1_accessTimePresent) && (this.accessTime != null)) {
/* 539 */       Date a = getAccessJavaTime();
/* 540 */       buf.append(" Access:[").append(a).append("] ");
/*     */     }
/* 542 */     if ((this.bit2_createTimePresent) && (this.createTime != null)) {
/* 543 */       Date c = getCreateJavaTime();
/* 544 */       buf.append(" Create:[").append(c).append("] ");
/*     */     }
/* 546 */     return buf.toString();
/*     */   }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/* 551 */     return super.clone();
/*     */   }
/*     */   
/*     */   public boolean equals(Object o)
/*     */   {
/* 556 */     if ((o instanceof X5455_ExtendedTimestamp)) {
/* 557 */       X5455_ExtendedTimestamp xf = (X5455_ExtendedTimestamp)o;
/*     */       
/*     */ 
/*     */ 
/* 561 */       return ((this.flags & 0x7) == (xf.flags & 0x7)) && ((this.modifyTime == xf.modifyTime) || ((this.modifyTime != null) && (this.modifyTime.equals(xf.modifyTime)))) && ((this.accessTime == xf.accessTime) || ((this.accessTime != null) && (this.accessTime.equals(xf.accessTime)))) && ((this.createTime == xf.createTime) || ((this.createTime != null) && (this.createTime.equals(xf.createTime))));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 566 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 572 */     int hc = -123 * (this.flags & 0x7);
/* 573 */     if (this.modifyTime != null) {
/* 574 */       hc ^= this.modifyTime.hashCode();
/*     */     }
/* 576 */     if (this.accessTime != null)
/*     */     {
/*     */ 
/* 579 */       hc ^= Integer.rotateLeft(this.accessTime.hashCode(), 11);
/*     */     }
/* 581 */     if (this.createTime != null) {
/* 582 */       hc ^= Integer.rotateLeft(this.createTime.hashCode(), 22);
/*     */     }
/* 584 */     return hc;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\X5455_ExtendedTimestamp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */