/*    */ package org.apache.commons.compress.archivers.zip;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.compress.parallel.InputStreamSupplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ZipArchiveEntryRequest
/*    */ {
/*    */   private final ZipArchiveEntry zipArchiveEntry;
/*    */   private final InputStreamSupplier payloadSupplier;
/*    */   private final int method;
/*    */   
/*    */   private ZipArchiveEntryRequest(ZipArchiveEntry zipArchiveEntry, InputStreamSupplier payloadSupplier)
/*    */   {
/* 42 */     this.zipArchiveEntry = zipArchiveEntry;
/* 43 */     this.payloadSupplier = payloadSupplier;
/* 44 */     this.method = zipArchiveEntry.getMethod();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ZipArchiveEntryRequest createZipArchiveEntryRequest(ZipArchiveEntry zipArchiveEntry, InputStreamSupplier payloadSupplier)
/*    */   {
/* 54 */     return new ZipArchiveEntryRequest(zipArchiveEntry, payloadSupplier);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public InputStream getPayloadStream()
/*    */   {
/* 62 */     return this.payloadSupplier.get();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getMethod()
/*    */   {
/* 70 */     return this.method;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   ZipArchiveEntry getZipArchiveEntry()
/*    */   {
/* 79 */     return this.zipArchiveEntry;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipArchiveEntryRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */