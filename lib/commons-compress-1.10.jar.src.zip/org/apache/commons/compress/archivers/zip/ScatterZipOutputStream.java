/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import org.apache.commons.compress.parallel.FileBasedScatterGatherBackingStore;
/*     */ import org.apache.commons.compress.parallel.ScatterGatherBackingStore;
/*     */ import org.apache.commons.compress.utils.BoundedInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScatterZipOutputStream
/*     */   implements Closeable
/*     */ {
/*  49 */   private final Queue<CompressedEntry> items = new ConcurrentLinkedQueue();
/*     */   private final ScatterGatherBackingStore backingStore;
/*     */   private final StreamCompressor streamCompressor;
/*     */   
/*     */   private static class CompressedEntry {
/*     */     final ZipArchiveEntryRequest zipArchiveEntryRequest;
/*     */     final long crc;
/*     */     final long compressedSize;
/*     */     final long size;
/*     */     
/*     */     public CompressedEntry(ZipArchiveEntryRequest zipArchiveEntryRequest, long crc, long compressedSize, long size) {
/*  60 */       this.zipArchiveEntryRequest = zipArchiveEntryRequest;
/*  61 */       this.crc = crc;
/*  62 */       this.compressedSize = compressedSize;
/*  63 */       this.size = size;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ZipArchiveEntry transferToArchiveEntry()
/*     */     {
/*  73 */       ZipArchiveEntry entry = this.zipArchiveEntryRequest.getZipArchiveEntry();
/*  74 */       entry.setCompressedSize(this.compressedSize);
/*  75 */       entry.setSize(this.size);
/*  76 */       entry.setCrc(this.crc);
/*  77 */       entry.setMethod(this.zipArchiveEntryRequest.getMethod());
/*  78 */       return entry;
/*     */     }
/*     */   }
/*     */   
/*     */   public ScatterZipOutputStream(ScatterGatherBackingStore backingStore, StreamCompressor streamCompressor)
/*     */   {
/*  84 */     this.backingStore = backingStore;
/*  85 */     this.streamCompressor = streamCompressor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addArchiveEntry(ZipArchiveEntryRequest zipArchiveEntryRequest)
/*     */     throws IOException
/*     */   {
/*  95 */     InputStream payloadStream = zipArchiveEntryRequest.getPayloadStream();
/*     */     try {
/*  97 */       this.streamCompressor.deflate(payloadStream, zipArchiveEntryRequest.getMethod());
/*     */     } finally {
/*  99 */       payloadStream.close();
/*     */     }
/* 101 */     this.items.add(new CompressedEntry(zipArchiveEntryRequest, this.streamCompressor.getCrc32(), this.streamCompressor.getBytesWrittenForLastEntry(), this.streamCompressor.getBytesRead()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(ZipArchiveOutputStream target)
/*     */     throws IOException
/*     */   {
/* 112 */     this.backingStore.closeForWriting();
/* 113 */     InputStream data = this.backingStore.getInputStream();
/* 114 */     for (CompressedEntry compressedEntry : this.items) {
/* 115 */       BoundedInputStream rawStream = new BoundedInputStream(data, compressedEntry.compressedSize);
/* 116 */       target.addRawArchiveEntry(compressedEntry.transferToArchiveEntry(), rawStream);
/* 117 */       rawStream.close();
/*     */     }
/* 119 */     data.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 128 */     this.backingStore.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ScatterZipOutputStream fileBased(File file)
/*     */     throws FileNotFoundException
/*     */   {
/* 139 */     return fileBased(file, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ScatterZipOutputStream fileBased(File file, int compressionLevel)
/*     */     throws FileNotFoundException
/*     */   {
/* 151 */     ScatterGatherBackingStore bs = new FileBasedScatterGatherBackingStore(file);
/* 152 */     StreamCompressor sc = StreamCompressor.create(compressionLevel, bs);
/* 153 */     return new ScatterZipOutputStream(bs, sc);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ScatterZipOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */