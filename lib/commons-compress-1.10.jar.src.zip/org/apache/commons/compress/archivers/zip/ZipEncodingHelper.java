/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.compress.utils.Charsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ZipEncodingHelper
/*     */ {
/*     */   private static final Map<String, SimpleEncodingHolder> simpleEncodings;
/*     */   
/*     */   private static class SimpleEncodingHolder
/*     */   {
/*     */     private final char[] highChars;
/*     */     private Simple8BitZipEncoding encoding;
/*     */     
/*     */     SimpleEncodingHolder(char[] highChars)
/*     */     {
/*  53 */       this.highChars = highChars;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized Simple8BitZipEncoding getEncoding()
/*     */     {
/*  61 */       if (this.encoding == null) {
/*  62 */         this.encoding = new Simple8BitZipEncoding(this.highChars);
/*     */       }
/*  64 */       return this.encoding;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static
/*     */   {
/*  71 */     Map<String, SimpleEncodingHolder> se = new HashMap();
/*     */     
/*     */ 
/*  74 */     char[] cp437_high_chars = { 'Ç', 'ü', 'é', 'â', 'ä', 'à', 'å', 'ç', 'ê', 'ë', 'è', 'ï', 'î', 'ì', 'Ä', 'Å', 'É', 'æ', 'Æ', 'ô', 'ö', 'ò', 'û', 'ù', 'ÿ', 'Ö', 'Ü', '¢', '£', '¥', '₧', 'ƒ', 'á', 'í', 'ó', 'ú', 'ñ', 'Ñ', 'ª', 'º', '¿', '⌐', '¬', '½', '¼', '¡', '«', '»', '░', '▒', '▓', '│', '┤', '╡', '╢', '╖', '╕', '╣', '║', '╗', '╝', '╜', '╛', '┐', '└', '┴', '┬', '├', '─', '┼', '╞', '╟', '╚', '╔', '╩', '╦', '╠', '═', '╬', '╧', '╨', '╤', '╥', '╙', '╘', '╒', '╓', '╫', '╪', '┘', '┌', '█', '▄', '▌', '▐', '▀', 'α', 'ß', 'Γ', 'π', 'Σ', 'σ', 'µ', 'τ', 'Φ', 'Θ', 'Ω', 'δ', '∞', 'φ', 'ε', '∩', '≡', '±', '≥', '≤', '⌠', '⌡', '÷', '≈', '°', '∙', '·', '√', 'ⁿ', '²', '■', ' ' };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */     SimpleEncodingHolder cp437 = new SimpleEncodingHolder(cp437_high_chars);
/*     */     
/* 100 */     se.put("CP437", cp437);
/* 101 */     se.put("Cp437", cp437);
/* 102 */     se.put("cp437", cp437);
/* 103 */     se.put("IBM437", cp437);
/* 104 */     se.put("ibm437", cp437);
/*     */     
/* 106 */     char[] cp850_high_chars = { 'Ç', 'ü', 'é', 'â', 'ä', 'à', 'å', 'ç', 'ê', 'ë', 'è', 'ï', 'î', 'ì', 'Ä', 'Å', 'É', 'æ', 'Æ', 'ô', 'ö', 'ò', 'û', 'ù', 'ÿ', 'Ö', 'Ü', 'ø', '£', 'Ø', '×', 'ƒ', 'á', 'í', 'ó', 'ú', 'ñ', 'Ñ', 'ª', 'º', '¿', '®', '¬', '½', '¼', '¡', '«', '»', '░', '▒', '▓', '│', '┤', 'Á', 'Â', 'À', '©', '╣', '║', '╗', '╝', '¢', '¥', '┐', '└', '┴', '┬', '├', '─', '┼', 'ã', 'Ã', '╚', '╔', '╩', '╦', '╠', '═', '╬', '¤', 'ð', 'Ð', 'Ê', 'Ë', 'È', 'ı', 'Í', 'Î', 'Ï', '┘', '┌', '█', '▄', '¦', 'Ì', '▀', 'Ó', 'ß', 'Ô', 'Ò', 'õ', 'Õ', 'µ', 'þ', 'Þ', 'Ú', 'Û', 'Ù', 'ý', 'Ý', '¯', '´', '­', '±', '‗', '¾', '¶', '§', '÷', '¸', '°', '¨', '·', '¹', '³', '²', '■', ' ' };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 130 */     SimpleEncodingHolder cp850 = new SimpleEncodingHolder(cp850_high_chars);
/*     */     
/* 132 */     se.put("CP850", cp850);
/* 133 */     se.put("Cp850", cp850);
/* 134 */     se.put("cp850", cp850);
/* 135 */     se.put("IBM850", cp850);
/* 136 */     se.put("ibm850", cp850);
/* 137 */     simpleEncodings = Collections.unmodifiableMap(se);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static ByteBuffer growBuffer(ByteBuffer b, int newCapacity)
/*     */   {
/* 153 */     b.limit(b.position());
/* 154 */     b.rewind();
/*     */     
/* 156 */     int c2 = b.capacity() * 2;
/* 157 */     ByteBuffer on = ByteBuffer.allocate(c2 < newCapacity ? newCapacity : c2);
/*     */     
/* 159 */     on.put(b);
/* 160 */     return on;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */   private static final byte[] HEX_DIGITS = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final String UTF8 = "UTF8";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void appendSurrogate(ByteBuffer bb, char c)
/*     */   {
/* 183 */     bb.put((byte)37);
/* 184 */     bb.put((byte)85);
/*     */     
/* 186 */     bb.put(HEX_DIGITS[(c >> '\f' & 0xF)]);
/* 187 */     bb.put(HEX_DIGITS[(c >> '\b' & 0xF)]);
/* 188 */     bb.put(HEX_DIGITS[(c >> '\004' & 0xF)]);
/* 189 */     bb.put(HEX_DIGITS[(c & 0xF)]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */   static final ZipEncoding UTF8_ZIP_ENCODING = new FallbackZipEncoding("UTF8");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipEncoding getZipEncoding(String name)
/*     */   {
/* 213 */     if (isUTF8(name)) {
/* 214 */       return UTF8_ZIP_ENCODING;
/*     */     }
/*     */     
/* 217 */     if (name == null) {
/* 218 */       return new FallbackZipEncoding();
/*     */     }
/*     */     
/* 221 */     SimpleEncodingHolder h = (SimpleEncodingHolder)simpleEncodings.get(name);
/*     */     
/* 223 */     if (h != null) {
/* 224 */       return h.getEncoding();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 229 */       Charset cs = Charset.forName(name);
/* 230 */       return new NioZipEncoding(cs);
/*     */     }
/*     */     catch (UnsupportedCharsetException e) {}
/* 233 */     return new FallbackZipEncoding(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean isUTF8(String charsetName)
/*     */   {
/* 244 */     if (charsetName == null)
/*     */     {
/* 246 */       charsetName = Charset.defaultCharset().name();
/*     */     }
/* 248 */     if (Charsets.UTF_8.name().equalsIgnoreCase(charsetName)) {
/* 249 */       return true;
/*     */     }
/* 251 */     for (String alias : Charsets.UTF_8.aliases()) {
/* 252 */       if (alias.equalsIgnoreCase(charsetName)) {
/* 253 */         return true;
/*     */       }
/*     */     }
/* 256 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipEncodingHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */