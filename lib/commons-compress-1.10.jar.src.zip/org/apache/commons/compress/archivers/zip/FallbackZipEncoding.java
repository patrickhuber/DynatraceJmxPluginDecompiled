/*    */ package org.apache.commons.compress.archivers.zip;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.ByteBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FallbackZipEncoding
/*    */   implements ZipEncoding
/*    */ {
/*    */   private final String charsetName;
/*    */   
/*    */   public FallbackZipEncoding()
/*    */   {
/* 51 */     this.charsetName = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FallbackZipEncoding(String charsetName)
/*    */   {
/* 61 */     this.charsetName = charsetName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean canEncode(String name)
/*    */   {
/* 69 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ByteBuffer encode(String name)
/*    */     throws IOException
/*    */   {
/* 77 */     if (this.charsetName == null) {
/* 78 */       return ByteBuffer.wrap(name.getBytes());
/*    */     }
/* 80 */     return ByteBuffer.wrap(name.getBytes(this.charsetName));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String decode(byte[] data)
/*    */     throws IOException
/*    */   {
/* 89 */     if (this.charsetName == null) {
/* 90 */       return new String(data);
/*    */     }
/* 92 */     return new String(data, this.charsetName);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\FallbackZipEncoding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */