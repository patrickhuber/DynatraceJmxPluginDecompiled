/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Deflater;
/*     */ import org.apache.commons.compress.parallel.ScatterGatherBackingStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StreamCompressor
/*     */   implements Closeable
/*     */ {
/*     */   private static final int DEFLATER_BLOCK_SIZE = 8192;
/*     */   private final Deflater def;
/*  50 */   private final CRC32 crc = new CRC32();
/*     */   
/*  52 */   private long writtenToOutputStreamForLastEntry = 0L;
/*  53 */   private long sourcePayloadLength = 0L;
/*  54 */   private long totalWrittenToOutputStream = 0L;
/*     */   
/*     */   private static final int bufferSize = 4096;
/*  57 */   private final byte[] outputBuffer = new byte['က'];
/*  58 */   private final byte[] readerBuf = new byte['က'];
/*     */   
/*     */   StreamCompressor(Deflater deflater) {
/*  61 */     this.def = deflater;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static StreamCompressor create(OutputStream os, Deflater deflater)
/*     */   {
/*  72 */     return new OutputStreamCompressor(deflater, os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static StreamCompressor create(OutputStream os)
/*     */   {
/*  82 */     return create(os, new Deflater(-1, true));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static StreamCompressor create(DataOutput os, Deflater deflater)
/*     */   {
/*  93 */     return new DataOutputCompressor(deflater, os);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StreamCompressor create(int compressionLevel, ScatterGatherBackingStore bs)
/*     */   {
/* 104 */     Deflater deflater = new Deflater(compressionLevel, true);
/* 105 */     return new ScatterGatherBackingStoreCompressor(deflater, bs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static StreamCompressor create(ScatterGatherBackingStore bs)
/*     */   {
/* 115 */     return create(-1, bs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCrc32()
/*     */   {
/* 125 */     return this.crc.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getBytesRead()
/*     */   {
/* 134 */     return this.sourcePayloadLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getBytesWrittenForLastEntry()
/*     */   {
/* 143 */     return this.writtenToOutputStreamForLastEntry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTotalBytesWritten()
/*     */   {
/* 152 */     return this.totalWrittenToOutputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deflate(InputStream source, int method)
/*     */     throws IOException
/*     */   {
/* 165 */     reset();
/*     */     
/*     */     int length;
/* 168 */     while ((length = source.read(this.readerBuf, 0, this.readerBuf.length)) >= 0) {
/* 169 */       write(this.readerBuf, 0, length, method);
/*     */     }
/* 171 */     if (method == 8) {
/* 172 */       flushDeflater();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long write(byte[] b, int offset, int length, int method)
/*     */     throws IOException
/*     */   {
/* 187 */     long current = this.writtenToOutputStreamForLastEntry;
/* 188 */     this.crc.update(b, offset, length);
/* 189 */     if (method == 8) {
/* 190 */       writeDeflated(b, offset, length);
/*     */     } else {
/* 192 */       writeCounted(b, offset, length);
/*     */     }
/* 194 */     this.sourcePayloadLength += length;
/* 195 */     return this.writtenToOutputStreamForLastEntry - current;
/*     */   }
/*     */   
/*     */   void reset()
/*     */   {
/* 200 */     this.crc.reset();
/* 201 */     this.def.reset();
/* 202 */     this.sourcePayloadLength = 0L;
/* 203 */     this.writtenToOutputStreamForLastEntry = 0L;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 207 */     this.def.end();
/*     */   }
/*     */   
/*     */   void flushDeflater() throws IOException {
/* 211 */     this.def.finish();
/* 212 */     while (!this.def.finished()) {
/* 213 */       deflate();
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeDeflated(byte[] b, int offset, int length) throws IOException
/*     */   {
/* 219 */     if ((length > 0) && (!this.def.finished())) {
/* 220 */       if (length <= 8192) {
/* 221 */         this.def.setInput(b, offset, length);
/* 222 */         deflateUntilInputIsNeeded();
/*     */       } else {
/* 224 */         int fullblocks = length / 8192;
/* 225 */         for (int i = 0; i < fullblocks; i++) {
/* 226 */           this.def.setInput(b, offset + i * 8192, 8192);
/*     */           
/* 228 */           deflateUntilInputIsNeeded();
/*     */         }
/* 230 */         int done = fullblocks * 8192;
/* 231 */         if (done < length) {
/* 232 */           this.def.setInput(b, offset + done, length - done);
/* 233 */           deflateUntilInputIsNeeded();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void deflateUntilInputIsNeeded() throws IOException {
/* 240 */     while (!this.def.needsInput()) {
/* 241 */       deflate();
/*     */     }
/*     */   }
/*     */   
/*     */   void deflate() throws IOException {
/* 246 */     int len = this.def.deflate(this.outputBuffer, 0, this.outputBuffer.length);
/* 247 */     if (len > 0) {
/* 248 */       writeCounted(this.outputBuffer, 0, len);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeCounted(byte[] data) throws IOException {
/* 253 */     writeCounted(data, 0, data.length);
/*     */   }
/*     */   
/*     */   public void writeCounted(byte[] data, int offset, int length) throws IOException {
/* 257 */     writeOut(data, offset, length);
/* 258 */     this.writtenToOutputStreamForLastEntry += length;
/* 259 */     this.totalWrittenToOutputStream += length;
/*     */   }
/*     */   
/*     */   protected abstract void writeOut(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException;
/*     */   
/*     */   private static final class ScatterGatherBackingStoreCompressor extends StreamCompressor {
/*     */     private final ScatterGatherBackingStore bs;
/*     */     
/*     */     public ScatterGatherBackingStoreCompressor(Deflater deflater, ScatterGatherBackingStore bs) {
/* 268 */       super();
/* 269 */       this.bs = bs;
/*     */     }
/*     */     
/*     */     protected final void writeOut(byte[] data, int offset, int length) throws IOException
/*     */     {
/* 274 */       this.bs.writeOut(data, offset, length);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class OutputStreamCompressor extends StreamCompressor {
/*     */     private final OutputStream os;
/*     */     
/*     */     public OutputStreamCompressor(Deflater deflater, OutputStream os) {
/* 282 */       super();
/* 283 */       this.os = os;
/*     */     }
/*     */     
/*     */     protected final void writeOut(byte[] data, int offset, int length) throws IOException
/*     */     {
/* 288 */       this.os.write(data, offset, length);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class DataOutputCompressor extends StreamCompressor {
/*     */     private final DataOutput raf;
/*     */     
/*     */     public DataOutputCompressor(Deflater deflater, DataOutput raf) {
/* 296 */       super();
/* 297 */       this.raf = raf;
/*     */     }
/*     */     
/*     */     protected final void writeOut(byte[] data, int offset, int length) throws IOException
/*     */     {
/* 302 */       this.raf.write(data, offset, length);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\StreamCompressor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */