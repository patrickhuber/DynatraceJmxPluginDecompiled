/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.zip.CRC32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ZipUtil
/*     */ {
/*  35 */   private static final byte[] DOS_TIME_MIN = ZipLong.getBytes(8448L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipLong toDosTime(Date time)
/*     */   {
/*  43 */     return new ZipLong(toDosTime(time.getTime()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] toDosTime(long t)
/*     */   {
/*  54 */     byte[] result = new byte[4];
/*  55 */     toDosTime(t, result, 0);
/*  56 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void toDosTime(long t, byte[] buf, int offset)
/*     */   {
/*  70 */     toDosTime(Calendar.getInstance(), t, buf, offset);
/*     */   }
/*     */   
/*     */   static void toDosTime(Calendar c, long t, byte[] buf, int offset) {
/*  74 */     c.setTimeInMillis(t);
/*     */     
/*  76 */     int year = c.get(1);
/*  77 */     if (year < 1980) {
/*  78 */       System.arraycopy(DOS_TIME_MIN, 0, buf, offset, DOS_TIME_MIN.length);
/*  79 */       return;
/*     */     }
/*  81 */     int month = c.get(2) + 1;
/*  82 */     long value = year - 1980 << 25 | month << 21 | c.get(5) << 16 | c.get(11) << 11 | c.get(12) << 5 | c.get(13) >> 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     ZipLong.putLong(value, buf, offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long adjustToLong(int i)
/*     */   {
/* 100 */     if (i < 0) {
/* 101 */       return 4294967296L + i;
/*     */     }
/* 103 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] reverse(byte[] array)
/*     */   {
/* 119 */     int z = array.length - 1;
/* 120 */     for (int i = 0; i < array.length / 2; i++) {
/* 121 */       byte x = array[i];
/* 122 */       array[i] = array[(z - i)];
/* 123 */       array[(z - i)] = x;
/*     */     }
/* 125 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static long bigToLong(BigInteger big)
/*     */   {
/* 136 */     if (big.bitLength() <= 63) {
/* 137 */       return big.longValue();
/*     */     }
/* 139 */     throw new NumberFormatException("The BigInteger cannot fit inside a 64 bit java long: [" + big + "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static BigInteger longToBig(long l)
/*     */   {
/* 155 */     if (l < -2147483648L)
/* 156 */       throw new IllegalArgumentException("Negative longs < -2^31 not permitted: [" + l + "]");
/* 157 */     if ((l < 0L) && (l >= -2147483648L))
/*     */     {
/*     */ 
/* 160 */       l = adjustToLong((int)l);
/*     */     }
/* 162 */     return BigInteger.valueOf(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int signedByteToUnsignedInt(byte b)
/*     */   {
/* 174 */     if (b >= 0) {
/* 175 */       return b;
/*     */     }
/* 177 */     return 256 + b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte unsignedIntToSignedByte(int i)
/*     */   {
/* 190 */     if ((i > 255) || (i < 0)) {
/* 191 */       throw new IllegalArgumentException("Can only convert non-negative integers between [0,255] to byte: [" + i + "]");
/*     */     }
/* 193 */     if (i < 128) {
/* 194 */       return (byte)i;
/*     */     }
/* 196 */     return (byte)(i - 256);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Date fromDosTime(ZipLong zipDosTime)
/*     */   {
/* 207 */     long dosTime = zipDosTime.getValue();
/* 208 */     return new Date(dosToJavaTime(dosTime));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long dosToJavaTime(long dosTime)
/*     */   {
/* 218 */     Calendar cal = Calendar.getInstance();
/*     */     
/* 220 */     cal.set(1, (int)(dosTime >> 25 & 0x7F) + 1980);
/* 221 */     cal.set(2, (int)(dosTime >> 21 & 0xF) - 1);
/* 222 */     cal.set(5, (int)(dosTime >> 16) & 0x1F);
/* 223 */     cal.set(11, (int)(dosTime >> 11) & 0x1F);
/* 224 */     cal.set(12, (int)(dosTime >> 5) & 0x3F);
/* 225 */     cal.set(13, (int)(dosTime << 1) & 0x3E);
/* 226 */     cal.set(14, 0);
/*     */     
/* 228 */     return cal.getTime().getTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void setNameAndCommentFromExtraFields(ZipArchiveEntry ze, byte[] originalNameBytes, byte[] commentBytes)
/*     */   {
/* 239 */     UnicodePathExtraField name = (UnicodePathExtraField)ze.getExtraField(UnicodePathExtraField.UPATH_ID);
/*     */     
/* 241 */     String originalName = ze.getName();
/* 242 */     String newName = getUnicodeStringIfOriginalMatches(name, originalNameBytes);
/*     */     
/* 244 */     if ((newName != null) && (!originalName.equals(newName))) {
/* 245 */       ze.setName(newName);
/*     */     }
/*     */     
/* 248 */     if ((commentBytes != null) && (commentBytes.length > 0)) {
/* 249 */       UnicodeCommentExtraField cmt = (UnicodeCommentExtraField)ze.getExtraField(UnicodeCommentExtraField.UCOM_ID);
/*     */       
/* 251 */       String newComment = getUnicodeStringIfOriginalMatches(cmt, commentBytes);
/*     */       
/* 253 */       if (newComment != null) {
/* 254 */         ze.setComment(newComment);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getUnicodeStringIfOriginalMatches(AbstractUnicodeExtraField f, byte[] orig)
/*     */   {
/* 269 */     if (f != null) {
/* 270 */       CRC32 crc32 = new CRC32();
/* 271 */       crc32.update(orig);
/* 272 */       long origCRC32 = crc32.getValue();
/*     */       
/* 274 */       if (origCRC32 == f.getNameCRC32()) {
/*     */         try {
/* 276 */           return ZipEncodingHelper.UTF8_ZIP_ENCODING.decode(f.getUnicodeName());
/*     */ 
/*     */ 
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */ 
/* 283 */           return null;
/*     */         }
/*     */       }
/*     */     }
/* 287 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static byte[] copy(byte[] from)
/*     */   {
/* 295 */     if (from != null) {
/* 296 */       byte[] to = new byte[from.length];
/* 297 */       System.arraycopy(from, 0, to, 0, to.length);
/* 298 */       return to;
/*     */     }
/* 300 */     return null;
/*     */   }
/*     */   
/* 303 */   static void copy(byte[] from, byte[] to, int offset) { if (from != null) {
/* 304 */       System.arraycopy(from, 0, to, offset, from.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean canHandleEntryData(ZipArchiveEntry entry)
/*     */   {
/* 313 */     return (supportsEncryptionOf(entry)) && (supportsMethodOf(entry));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean supportsEncryptionOf(ZipArchiveEntry entry)
/*     */   {
/* 323 */     return !entry.getGeneralPurposeBit().usesEncryption();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean supportsMethodOf(ZipArchiveEntry entry)
/*     */   {
/* 333 */     return (entry.getMethod() == 0) || (entry.getMethod() == ZipMethod.UNSHRINKING.getCode()) || (entry.getMethod() == ZipMethod.IMPLODING.getCode()) || (entry.getMethod() == 8);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void checkRequestedFeatures(ZipArchiveEntry ze)
/*     */     throws UnsupportedZipFeatureException
/*     */   {
/* 345 */     if (!supportsEncryptionOf(ze)) {
/* 346 */       throw new UnsupportedZipFeatureException(UnsupportedZipFeatureException.Feature.ENCRYPTION, ze);
/*     */     }
/*     */     
/*     */ 
/* 350 */     if (!supportsMethodOf(ze)) {
/* 351 */       ZipMethod m = ZipMethod.getMethodByCode(ze.getMethod());
/* 352 */       if (m == null) {
/* 353 */         throw new UnsupportedZipFeatureException(UnsupportedZipFeatureException.Feature.METHOD, ze);
/*     */       }
/*     */       
/*     */ 
/* 357 */       throw new UnsupportedZipFeatureException(m, ze);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */