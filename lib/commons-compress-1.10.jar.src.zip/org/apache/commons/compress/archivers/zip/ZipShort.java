/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ZipShort
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int BYTE_1_MASK = 65280;
/*     */   private static final int BYTE_1_SHIFT = 8;
/*     */   private final int value;
/*     */   
/*     */   public ZipShort(int value)
/*     */   {
/*  42 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort(byte[] bytes)
/*     */   {
/*  50 */     this(bytes, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort(byte[] bytes, int offset)
/*     */   {
/*  59 */     this.value = getValue(bytes, offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  67 */     byte[] result = new byte[2];
/*  68 */     result[0] = ((byte)(this.value & 0xFF));
/*  69 */     result[1] = ((byte)((this.value & 0xFF00) >> 8));
/*  70 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getValue()
/*     */   {
/*  78 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytes(int value)
/*     */   {
/*  87 */     byte[] result = new byte[2];
/*  88 */     putShort(value, result, 0);
/*  89 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putShort(int value, byte[] buf, int offset)
/*     */   {
/* 101 */     buf[offset] = ((byte)(value & 0xFF));
/* 102 */     buf[(offset + 1)] = ((byte)((value & 0xFF00) >> 8));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getValue(byte[] bytes, int offset)
/*     */   {
/* 112 */     int value = bytes[(offset + 1)] << 8 & 0xFF00;
/* 113 */     value += (bytes[offset] & 0xFF);
/* 114 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getValue(byte[] bytes)
/*     */   {
/* 123 */     return getValue(bytes, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 133 */     if ((o == null) || (!(o instanceof ZipShort))) {
/* 134 */       return false;
/*     */     }
/* 136 */     return this.value == ((ZipShort)o).getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 145 */     return this.value;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/* 151 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException cnfe) {
/* 154 */       throw new RuntimeException(cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 160 */     return "ZipShort value: " + this.value;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipShort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */