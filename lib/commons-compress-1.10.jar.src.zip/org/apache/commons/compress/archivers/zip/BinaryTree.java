/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BinaryTree
/*     */ {
/*     */   private static final int UNDEFINED = -1;
/*     */   private static final int NODE = -2;
/*     */   private final int[] tree;
/*     */   
/*     */   public BinaryTree(int depth)
/*     */   {
/*  48 */     this.tree = new int[(1 << depth + 1) - 1];
/*  49 */     Arrays.fill(this.tree, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLeaf(int node, int path, int depth, int value)
/*     */   {
/*  61 */     if (depth == 0)
/*     */     {
/*  63 */       if (this.tree[node] == -1) {
/*  64 */         this.tree[node] = value;
/*     */       } else {
/*  66 */         throw new IllegalArgumentException("Tree value at index " + node + " has already been assigned (" + this.tree[node] + ")");
/*     */       }
/*     */     }
/*     */     else {
/*  70 */       this.tree[node] = -2;
/*     */       
/*     */ 
/*  73 */       int nextChild = 2 * node + 1 + (path & 0x1);
/*  74 */       addLeaf(nextChild, path >>> 1, depth - 1, value);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(BitStream stream)
/*     */     throws IOException
/*     */   {
/*  85 */     int currentIndex = 0;
/*     */     for (;;)
/*     */     {
/*  88 */       int bit = stream.nextBit();
/*  89 */       if (bit == -1) {
/*  90 */         return -1;
/*     */       }
/*     */       
/*  93 */       int childIndex = 2 * currentIndex + 1 + bit;
/*  94 */       int value = this.tree[childIndex];
/*  95 */       if (value == -2)
/*     */       {
/*  97 */         currentIndex = childIndex;
/*  98 */       } else { if (value != -1) {
/*  99 */           return value;
/*     */         }
/* 101 */         throw new IOException("The child " + bit + " of node at index " + currentIndex + " is not defined");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static BinaryTree decode(InputStream in, int totalNumberOfValues)
/*     */     throws IOException
/*     */   {
/* 112 */     int size = in.read() + 1;
/* 113 */     if (size == 0) {
/* 114 */       throw new IOException("Cannot read the size of the encoded tree, unexpected end of stream");
/*     */     }
/*     */     
/* 117 */     byte[] encodedTree = new byte[size];
/* 118 */     new DataInputStream(in).readFully(encodedTree);
/*     */     
/*     */ 
/* 121 */     int maxLength = 0;
/*     */     
/* 123 */     int[] originalBitLengths = new int[totalNumberOfValues];
/* 124 */     int pos = 0;
/* 125 */     for (byte b : encodedTree)
/*     */     {
/* 127 */       int numberOfValues = ((b & 0xF0) >> 4) + 1;
/* 128 */       int bitLength = (b & 0xF) + 1;
/*     */       
/* 130 */       for (int j = 0; j < numberOfValues; j++) {
/* 131 */         originalBitLengths[(pos++)] = bitLength;
/*     */       }
/*     */       
/* 134 */       maxLength = Math.max(maxLength, bitLength);
/*     */     }
/*     */     
/*     */ 
/* 138 */     int[] permutation = new int[originalBitLengths.length];
/* 139 */     for (int k = 0; k < permutation.length; k++) {
/* 140 */       permutation[k] = k;
/*     */     }
/*     */     
/* 143 */     int c = 0;
/* 144 */     int[] sortedBitLengths = new int[originalBitLengths.length];
/* 145 */     for (int k = 0; k < originalBitLengths.length; k++)
/*     */     {
/* 147 */       for (int l = 0; l < originalBitLengths.length; l++)
/*     */       {
/* 149 */         if (originalBitLengths[l] == k)
/*     */         {
/* 151 */           sortedBitLengths[c] = k;
/*     */           
/*     */ 
/* 154 */           permutation[c] = l;
/*     */           
/* 156 */           c++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 162 */     int code = 0;
/* 163 */     int codeIncrement = 0;
/* 164 */     int lastBitLength = 0;
/*     */     
/* 166 */     int[] codes = new int[totalNumberOfValues];
/*     */     
/* 168 */     for (int i = totalNumberOfValues - 1; i >= 0; i--) {
/* 169 */       code += codeIncrement;
/* 170 */       if (sortedBitLengths[i] != lastBitLength) {
/* 171 */         lastBitLength = sortedBitLengths[i];
/* 172 */         codeIncrement = 1 << 16 - lastBitLength;
/*     */       }
/* 174 */       codes[permutation[i]] = code;
/*     */     }
/*     */     
/*     */ 
/* 178 */     BinaryTree tree = new BinaryTree(maxLength);
/*     */     
/* 180 */     for (int k = 0; k < codes.length; k++) {
/* 181 */       int bitLength = originalBitLengths[k];
/* 182 */       if (bitLength > 0) {
/* 183 */         tree.addLeaf(0, Integer.reverse(codes[k] << 16), bitLength, k);
/*     */       }
/*     */     }
/*     */     
/* 187 */     return tree;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\BinaryTree.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */