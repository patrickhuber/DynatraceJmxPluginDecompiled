/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsiExtraField
/*     */   implements ZipExtraField, UnixStat, Cloneable
/*     */ {
/*  54 */   private static final ZipShort HEADER_ID = new ZipShort(30062);
/*     */   
/*     */ 
/*     */   private static final int WORD = 4;
/*     */   
/*  59 */   private int mode = 0;
/*     */   
/*     */ 
/*     */ 
/*  63 */   private int uid = 0;
/*     */   
/*     */ 
/*     */ 
/*  67 */   private int gid = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   private String link = "";
/*     */   
/*     */ 
/*     */ 
/*  77 */   private boolean dirFlag = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  82 */   private CRC32 crc = new CRC32();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getHeaderId()
/*     */   {
/*  93 */     return HEADER_ID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getLocalFileDataLength()
/*     */   {
/* 102 */     return new ZipShort(14 + getLinkedFile().getBytes().length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipShort getCentralDirectoryLength()
/*     */   {
/* 116 */     return getLocalFileDataLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getLocalFileDataData()
/*     */   {
/* 126 */     byte[] data = new byte[getLocalFileDataLength().getValue() - 4];
/* 127 */     System.arraycopy(ZipShort.getBytes(getMode()), 0, data, 0, 2);
/*     */     
/* 129 */     byte[] linkArray = getLinkedFile().getBytes();
/*     */     
/* 131 */     System.arraycopy(ZipLong.getBytes(linkArray.length), 0, data, 2, 4);
/*     */     
/*     */ 
/* 134 */     System.arraycopy(ZipShort.getBytes(getUserId()), 0, data, 6, 2);
/*     */     
/* 136 */     System.arraycopy(ZipShort.getBytes(getGroupId()), 0, data, 8, 2);
/*     */     
/*     */ 
/* 139 */     System.arraycopy(linkArray, 0, data, 10, linkArray.length);
/*     */     
/*     */ 
/* 142 */     this.crc.reset();
/* 143 */     this.crc.update(data);
/* 144 */     long checksum = this.crc.getValue();
/*     */     
/* 146 */     byte[] result = new byte[data.length + 4];
/* 147 */     System.arraycopy(ZipLong.getBytes(checksum), 0, result, 0, 4);
/* 148 */     System.arraycopy(data, 0, result, 4, data.length);
/* 149 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCentralDirectoryData()
/*     */   {
/* 157 */     return getLocalFileDataData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUserId(int uid)
/*     */   {
/* 165 */     this.uid = uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUserId()
/*     */   {
/* 173 */     return this.uid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGroupId(int gid)
/*     */   {
/* 181 */     this.gid = gid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getGroupId()
/*     */   {
/* 189 */     return this.gid;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLinkedFile(String name)
/*     */   {
/* 199 */     this.link = name;
/* 200 */     this.mode = getMode(this.mode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLinkedFile()
/*     */   {
/* 210 */     return this.link;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLink()
/*     */   {
/* 218 */     return getLinkedFile().length() != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMode(int mode)
/*     */   {
/* 226 */     this.mode = getMode(mode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMode()
/*     */   {
/* 234 */     return this.mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDirectory(boolean dirFlag)
/*     */   {
/* 242 */     this.dirFlag = dirFlag;
/* 243 */     this.mode = getMode(this.mode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/* 251 */     return (this.dirFlag) && (!isLink());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromLocalFileData(byte[] data, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 264 */     long givenChecksum = ZipLong.getValue(data, offset);
/* 265 */     byte[] tmp = new byte[length - 4];
/* 266 */     System.arraycopy(data, offset + 4, tmp, 0, length - 4);
/* 267 */     this.crc.reset();
/* 268 */     this.crc.update(tmp);
/* 269 */     long realChecksum = this.crc.getValue();
/* 270 */     if (givenChecksum != realChecksum) {
/* 271 */       throw new ZipException("bad CRC checksum " + Long.toHexString(givenChecksum) + " instead of " + Long.toHexString(realChecksum));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 277 */     int newMode = ZipShort.getValue(tmp, 0);
/*     */     
/* 279 */     byte[] linkArray = new byte[(int)ZipLong.getValue(tmp, 2)];
/* 280 */     this.uid = ZipShort.getValue(tmp, 6);
/* 281 */     this.gid = ZipShort.getValue(tmp, 8);
/*     */     
/* 283 */     if (linkArray.length == 0) {
/* 284 */       this.link = "";
/*     */     } else {
/* 286 */       System.arraycopy(tmp, 10, linkArray, 0, linkArray.length);
/* 287 */       this.link = new String(linkArray);
/*     */     }
/*     */     
/* 290 */     setDirectory((newMode & 0x4000) != 0);
/* 291 */     setMode(newMode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseFromCentralDirectoryData(byte[] buffer, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 301 */     parseFromLocalFileData(buffer, offset, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getMode(int mode)
/*     */   {
/* 310 */     int type = 32768;
/* 311 */     if (isLink()) {
/* 312 */       type = 40960;
/* 313 */     } else if (isDirectory()) {
/* 314 */       type = 16384;
/*     */     }
/* 316 */     return type | mode & 0xFFF;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/* 322 */       AsiExtraField cloned = (AsiExtraField)super.clone();
/* 323 */       cloned.crc = new CRC32();
/* 324 */       return cloned;
/*     */     }
/*     */     catch (CloneNotSupportedException cnfe) {
/* 327 */       throw new RuntimeException(cnfe);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\AsiExtraField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */