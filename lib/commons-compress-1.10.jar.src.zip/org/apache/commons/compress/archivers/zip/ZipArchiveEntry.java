/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipException;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipArchiveEntry
/*     */   extends ZipEntry
/*     */   implements ArchiveEntry
/*     */ {
/*     */   public static final int PLATFORM_UNIX = 3;
/*     */   public static final int PLATFORM_FAT = 0;
/*     */   public static final int CRC_UNKNOWN = -1;
/*     */   private static final int SHORT_MASK = 65535;
/*     */   private static final int SHORT_SHIFT = 16;
/*  58 */   private static final byte[] EMPTY = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private int method = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private long size = -1L;
/*     */   
/*  80 */   private int internalAttributes = 0;
/*  81 */   private int platform = 0;
/*  82 */   private long externalAttributes = 0L;
/*     */   private ZipExtraField[] extraFields;
/*  84 */   private UnparseableExtraFieldData unparseableExtra = null;
/*  85 */   private String name = null;
/*  86 */   private byte[] rawName = null;
/*  87 */   private GeneralPurposeBit gpb = new GeneralPurposeBit();
/*  88 */   private static final ZipExtraField[] noExtraFields = new ZipExtraField[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipArchiveEntry(String name)
/*     */   {
/*  99 */     super(name);
/* 100 */     setName(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipArchiveEntry(ZipEntry entry)
/*     */     throws ZipException
/*     */   {
/* 113 */     super(entry);
/* 114 */     setName(entry.getName());
/* 115 */     byte[] extra = entry.getExtra();
/* 116 */     if (extra != null) {
/* 117 */       setExtraFields(ExtraFieldUtils.parse(extra, true, ExtraFieldUtils.UnparseableExtraField.READ));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 122 */       setExtra();
/*     */     }
/* 124 */     setMethod(entry.getMethod());
/* 125 */     this.size = entry.getSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipArchiveEntry(ZipArchiveEntry entry)
/*     */     throws ZipException
/*     */   {
/* 138 */     this(entry);
/* 139 */     setInternalAttributes(entry.getInternalAttributes());
/* 140 */     setExternalAttributes(entry.getExternalAttributes());
/* 141 */     setExtraFields(getAllExtraFieldsNoCopy());
/* 142 */     setPlatform(entry.getPlatform());
/* 143 */     GeneralPurposeBit other = entry.getGeneralPurposeBit();
/* 144 */     setGeneralPurposeBit(other == null ? null : (GeneralPurposeBit)other.clone());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ZipArchiveEntry()
/*     */   {
/* 151 */     this("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipArchiveEntry(File inputFile, String entryName)
/*     */   {
/* 166 */     this((inputFile.isDirectory()) && (!entryName.endsWith("/")) ? entryName + "/" : entryName);
/*     */     
/* 168 */     if (inputFile.isFile()) {
/* 169 */       setSize(inputFile.length());
/*     */     }
/* 171 */     setTime(inputFile.lastModified());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 181 */     ZipArchiveEntry e = (ZipArchiveEntry)super.clone();
/*     */     
/* 183 */     e.setInternalAttributes(getInternalAttributes());
/* 184 */     e.setExternalAttributes(getExternalAttributes());
/* 185 */     e.setExtraFields(getAllExtraFieldsNoCopy());
/* 186 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMethod()
/*     */   {
/* 199 */     return this.method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMethod(int method)
/*     */   {
/* 211 */     if (method < 0) {
/* 212 */       throw new IllegalArgumentException("ZIP compression method can not be negative: " + method);
/*     */     }
/*     */     
/* 215 */     this.method = method;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInternalAttributes()
/*     */   {
/* 228 */     return this.internalAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInternalAttributes(int value)
/*     */   {
/* 236 */     this.internalAttributes = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getExternalAttributes()
/*     */   {
/* 249 */     return this.externalAttributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExternalAttributes(long value)
/*     */   {
/* 257 */     this.externalAttributes = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnixMode(int mode)
/*     */   {
/* 267 */     setExternalAttributes(mode << 16 | ((mode & 0x80) == 0 ? 1 : 0) | (isDirectory() ? 16 : 0));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     this.platform = 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnixMode()
/*     */   {
/* 281 */     return this.platform != 3 ? 0 : (int)(getExternalAttributes() >> 16 & 0xFFFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnixSymlink()
/*     */   {
/* 294 */     return (getUnixMode() & 0xA000) == 40960;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPlatform()
/*     */   {
/* 305 */     return this.platform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setPlatform(int platform)
/*     */   {
/* 313 */     this.platform = platform;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExtraFields(ZipExtraField[] fields)
/*     */   {
/* 321 */     List<ZipExtraField> newFields = new ArrayList();
/* 322 */     for (ZipExtraField field : fields) {
/* 323 */       if ((field instanceof UnparseableExtraFieldData)) {
/* 324 */         this.unparseableExtra = ((UnparseableExtraFieldData)field);
/*     */       } else {
/* 326 */         newFields.add(field);
/*     */       }
/*     */     }
/* 329 */     this.extraFields = ((ZipExtraField[])newFields.toArray(new ZipExtraField[newFields.size()]));
/* 330 */     setExtra();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipExtraField[] getExtraFields()
/*     */   {
/* 344 */     return getParseableExtraFields();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipExtraField[] getExtraFields(boolean includeUnparseable)
/*     */   {
/* 357 */     return includeUnparseable ? getAllExtraFields() : getParseableExtraFields();
/*     */   }
/*     */   
/*     */ 
/*     */   private ZipExtraField[] getParseableExtraFieldsNoCopy()
/*     */   {
/* 363 */     if (this.extraFields == null) {
/* 364 */       return noExtraFields;
/*     */     }
/* 366 */     return this.extraFields;
/*     */   }
/*     */   
/*     */   private ZipExtraField[] getParseableExtraFields() {
/* 370 */     ZipExtraField[] parseableExtraFields = getParseableExtraFieldsNoCopy();
/* 371 */     return parseableExtraFields == this.extraFields ? copyOf(parseableExtraFields) : parseableExtraFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ZipExtraField[] getAllExtraFieldsNoCopy()
/*     */   {
/* 379 */     if (this.extraFields == null) {
/* 380 */       return getUnparseableOnly();
/*     */     }
/* 382 */     return this.unparseableExtra != null ? getMergedFields() : this.extraFields;
/*     */   }
/*     */   
/*     */   private ZipExtraField[] copyOf(ZipExtraField[] src) {
/* 386 */     return copyOf(src, src.length);
/*     */   }
/*     */   
/*     */   private ZipExtraField[] copyOf(ZipExtraField[] src, int length) {
/* 390 */     ZipExtraField[] cpy = new ZipExtraField[length];
/* 391 */     System.arraycopy(src, 0, cpy, 0, Math.min(src.length, length));
/* 392 */     return cpy;
/*     */   }
/*     */   
/*     */   private ZipExtraField[] getMergedFields() {
/* 396 */     ZipExtraField[] zipExtraFields = copyOf(this.extraFields, this.extraFields.length + 1);
/* 397 */     zipExtraFields[this.extraFields.length] = this.unparseableExtra;
/* 398 */     return zipExtraFields;
/*     */   }
/*     */   
/*     */   private ZipExtraField[] getUnparseableOnly() {
/* 402 */     return new ZipExtraField[] { this.unparseableExtra == null ? noExtraFields : this.unparseableExtra };
/*     */   }
/*     */   
/*     */   private ZipExtraField[] getAllExtraFields() {
/* 406 */     ZipExtraField[] allExtraFieldsNoCopy = getAllExtraFieldsNoCopy();
/* 407 */     return allExtraFieldsNoCopy == this.extraFields ? copyOf(allExtraFieldsNoCopy) : allExtraFieldsNoCopy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExtraField(ZipExtraField ze)
/*     */   {
/* 418 */     if ((ze instanceof UnparseableExtraFieldData)) {
/* 419 */       this.unparseableExtra = ((UnparseableExtraFieldData)ze);
/*     */     }
/* 421 */     else if (this.extraFields == null) {
/* 422 */       this.extraFields = new ZipExtraField[] { ze };
/*     */     } else {
/* 424 */       if (getExtraField(ze.getHeaderId()) != null) {
/* 425 */         removeExtraField(ze.getHeaderId());
/*     */       }
/* 427 */       ZipExtraField[] zipExtraFields = copyOf(this.extraFields, this.extraFields.length + 1);
/* 428 */       zipExtraFields[(zipExtraFields.length - 1)] = ze;
/* 429 */       this.extraFields = zipExtraFields;
/*     */     }
/*     */     
/* 432 */     setExtra();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addAsFirstExtraField(ZipExtraField ze)
/*     */   {
/* 443 */     if ((ze instanceof UnparseableExtraFieldData)) {
/* 444 */       this.unparseableExtra = ((UnparseableExtraFieldData)ze);
/*     */     } else {
/* 446 */       if (getExtraField(ze.getHeaderId()) != null) {
/* 447 */         removeExtraField(ze.getHeaderId());
/*     */       }
/* 449 */       ZipExtraField[] copy = this.extraFields;
/* 450 */       int newLen = this.extraFields != null ? this.extraFields.length + 1 : 1;
/* 451 */       this.extraFields = new ZipExtraField[newLen];
/* 452 */       this.extraFields[0] = ze;
/* 453 */       if (copy != null) {
/* 454 */         System.arraycopy(copy, 0, this.extraFields, 1, this.extraFields.length - 1);
/*     */       }
/*     */     }
/* 457 */     setExtra();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeExtraField(ZipShort type)
/*     */   {
/* 465 */     if (this.extraFields == null) {
/* 466 */       throw new NoSuchElementException();
/*     */     }
/*     */     
/* 469 */     List<ZipExtraField> newResult = new ArrayList();
/* 470 */     for (ZipExtraField extraField : this.extraFields) {
/* 471 */       if (!type.equals(extraField.getHeaderId())) {
/* 472 */         newResult.add(extraField);
/*     */       }
/*     */     }
/* 475 */     if (this.extraFields.length == newResult.size()) {
/* 476 */       throw new NoSuchElementException();
/*     */     }
/* 478 */     this.extraFields = ((ZipExtraField[])newResult.toArray(new ZipExtraField[newResult.size()]));
/* 479 */     setExtra();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeUnparseableExtraFieldData()
/*     */   {
/* 488 */     if (this.unparseableExtra == null) {
/* 489 */       throw new NoSuchElementException();
/*     */     }
/* 491 */     this.unparseableExtra = null;
/* 492 */     setExtra();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipExtraField getExtraField(ZipShort type)
/*     */   {
/* 502 */     if (this.extraFields != null) {
/* 503 */       for (ZipExtraField extraField : this.extraFields) {
/* 504 */         if (type.equals(extraField.getHeaderId())) {
/* 505 */           return extraField;
/*     */         }
/*     */       }
/*     */     }
/* 509 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UnparseableExtraFieldData getUnparseableExtraFieldData()
/*     */   {
/* 520 */     return this.unparseableExtra;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExtra(byte[] extra)
/*     */     throws RuntimeException
/*     */   {
/*     */     try
/*     */     {
/* 534 */       ZipExtraField[] local = ExtraFieldUtils.parse(extra, true, ExtraFieldUtils.UnparseableExtraField.READ);
/*     */       
/*     */ 
/* 537 */       mergeExtraFields(local, true);
/*     */     }
/*     */     catch (ZipException e) {
/* 540 */       throw new RuntimeException("Error parsing extra fields for entry: " + getName() + " - " + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setExtra()
/*     */   {
/* 552 */     super.setExtra(ExtraFieldUtils.mergeLocalFileDataData(getAllExtraFieldsNoCopy()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCentralDirectoryExtra(byte[] b)
/*     */   {
/*     */     try
/*     */     {
/* 561 */       ZipExtraField[] central = ExtraFieldUtils.parse(b, false, ExtraFieldUtils.UnparseableExtraField.READ);
/*     */       
/*     */ 
/* 564 */       mergeExtraFields(central, false);
/*     */     } catch (ZipException e) {
/* 566 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getLocalFileDataExtra()
/*     */   {
/* 575 */     byte[] extra = getExtra();
/* 576 */     return extra != null ? extra : EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getCentralDirectoryExtra()
/*     */   {
/* 584 */     return ExtraFieldUtils.mergeCentralDirectoryData(getAllExtraFieldsNoCopy());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 593 */     return this.name == null ? super.getName() : this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/* 602 */     return getName().endsWith("/");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setName(String name)
/*     */   {
/* 610 */     if ((name != null) && (getPlatform() == 0) && (!name.contains("/")))
/*     */     {
/* 612 */       name = name.replace('\\', '/');
/*     */     }
/* 614 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getSize()
/*     */   {
/* 628 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(long size)
/*     */   {
/* 639 */     if (size < 0L) {
/* 640 */       throw new IllegalArgumentException("invalid entry size");
/*     */     }
/* 642 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setName(String name, byte[] rawName)
/*     */   {
/* 655 */     setName(name);
/* 656 */     this.rawName = rawName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getRawName()
/*     */   {
/* 670 */     if (this.rawName != null) {
/* 671 */       byte[] b = new byte[this.rawName.length];
/* 672 */       System.arraycopy(this.rawName, 0, b, 0, this.rawName.length);
/* 673 */       return b;
/*     */     }
/* 675 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 689 */     return getName().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GeneralPurposeBit getGeneralPurposeBit()
/*     */   {
/* 698 */     return this.gpb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGeneralPurposeBit(GeneralPurposeBit b)
/*     */   {
/* 707 */     this.gpb = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void mergeExtraFields(ZipExtraField[] f, boolean local)
/*     */     throws ZipException
/*     */   {
/* 720 */     if (this.extraFields == null) {
/* 721 */       setExtraFields(f);
/*     */     } else {
/* 723 */       for (ZipExtraField element : f) { ZipExtraField existing;
/*     */         ZipExtraField existing;
/* 725 */         if ((element instanceof UnparseableExtraFieldData)) {
/* 726 */           existing = this.unparseableExtra;
/*     */         } else {
/* 728 */           existing = getExtraField(element.getHeaderId());
/*     */         }
/* 730 */         if (existing == null) {
/* 731 */           addExtraField(element);
/*     */         }
/* 733 */         else if (local) {
/* 734 */           byte[] b = element.getLocalFileDataData();
/* 735 */           existing.parseFromLocalFileData(b, 0, b.length);
/*     */         } else {
/* 737 */           byte[] b = element.getCentralDirectoryData();
/* 738 */           existing.parseFromCentralDirectoryData(b, 0, b.length);
/*     */         }
/*     */       }
/*     */       
/* 742 */       setExtra();
/*     */     }
/*     */   }
/*     */   
/*     */   public Date getLastModifiedDate() {
/* 747 */     return new Date(getTime());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 755 */     if (this == obj) {
/* 756 */       return true;
/*     */     }
/* 758 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 759 */       return false;
/*     */     }
/* 761 */     ZipArchiveEntry other = (ZipArchiveEntry)obj;
/* 762 */     String myName = getName();
/* 763 */     String otherName = other.getName();
/* 764 */     if (myName == null) {
/* 765 */       if (otherName != null) {
/* 766 */         return false;
/*     */       }
/* 768 */     } else if (!myName.equals(otherName)) {
/* 769 */       return false;
/*     */     }
/* 771 */     String myComment = getComment();
/* 772 */     String otherComment = other.getComment();
/* 773 */     if (myComment == null) {
/* 774 */       myComment = "";
/*     */     }
/* 776 */     if (otherComment == null) {
/* 777 */       otherComment = "";
/*     */     }
/* 779 */     return (getTime() == other.getTime()) && (myComment.equals(otherComment)) && (getInternalAttributes() == other.getInternalAttributes()) && (getPlatform() == other.getPlatform()) && (getExternalAttributes() == other.getExternalAttributes()) && (getMethod() == other.getMethod()) && (getSize() == other.getSize()) && (getCrc() == other.getCrc()) && (getCompressedSize() == other.getCompressedSize()) && (Arrays.equals(getCentralDirectoryExtra(), other.getCentralDirectoryExtra())) && (Arrays.equals(getLocalFileDataExtra(), other.getLocalFileDataExtra())) && (this.gpb.equals(other.gpb));
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */