/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteOrder;
/*     */ import org.apache.commons.compress.compressors.lzw.LZWInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UnshrinkingInputStream
/*     */   extends LZWInputStream
/*     */ {
/*     */   private static final int MAX_CODE_SIZE = 13;
/*     */   private static final int MAX_TABLE_SIZE = 8192;
/*     */   private final boolean[] isUsed;
/*     */   
/*     */   public UnshrinkingInputStream(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/*  38 */     super(inputStream, ByteOrder.LITTLE_ENDIAN);
/*  39 */     setClearCode(9);
/*  40 */     initializeTables(13);
/*  41 */     this.isUsed = new boolean[getPrefixesLength()];
/*  42 */     for (int i = 0; i < 256; i++) {
/*  43 */       this.isUsed[i] = true;
/*     */     }
/*  45 */     setTableSize(getClearCode() + 1);
/*     */   }
/*     */   
/*     */   protected int addEntry(int previousCode, byte character) throws IOException
/*     */   {
/*  50 */     int tableSize = getTableSize();
/*  51 */     while ((tableSize < 8192) && (this.isUsed[tableSize] != 0)) {
/*  52 */       tableSize++;
/*     */     }
/*  54 */     setTableSize(tableSize);
/*  55 */     int idx = addEntry(previousCode, character, 8192);
/*  56 */     if (idx >= 0) {
/*  57 */       this.isUsed[idx] = true;
/*     */     }
/*  59 */     return idx;
/*     */   }
/*     */   
/*     */   private void partialClear() {
/*  63 */     boolean[] isParent = new boolean[' '];
/*  64 */     for (int i = 0; i < this.isUsed.length; i++) {
/*  65 */       if ((this.isUsed[i] != 0) && (getPrefix(i) != -1)) {
/*  66 */         isParent[getPrefix(i)] = true;
/*     */       }
/*     */     }
/*  69 */     for (int i = getClearCode() + 1; i < isParent.length; i++) {
/*  70 */       if (isParent[i] == 0) {
/*  71 */         this.isUsed[i] = false;
/*  72 */         setPrefix(i, -1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int decompressNextSymbol()
/*     */     throws IOException
/*     */   {
/*  91 */     int code = readNextCode();
/*  92 */     if (code < 0)
/*  93 */       return -1;
/*  94 */     if (code == getClearCode()) {
/*  95 */       int subCode = readNextCode();
/*  96 */       if (subCode < 0)
/*  97 */         throw new IOException("Unexpected EOF;");
/*  98 */       if (subCode == 1) {
/*  99 */         if (getCodeSize() < 13) {
/* 100 */           incrementCodeSize();
/*     */         } else {
/* 102 */           throw new IOException("Attempt to increase code size beyond maximum");
/*     */         }
/* 104 */       } else if (subCode == 2) {
/* 105 */         partialClear();
/* 106 */         setTableSize(getClearCode() + 1);
/*     */       } else {
/* 108 */         throw new IOException("Invalid clear code subcode " + subCode);
/*     */       }
/* 110 */       return 0;
/*     */     }
/* 112 */     boolean addedUnfinishedEntry = false;
/* 113 */     int effectiveCode = code;
/* 114 */     if (this.isUsed[code] == 0) {
/* 115 */       effectiveCode = addRepeatOfPreviousCode();
/* 116 */       addedUnfinishedEntry = true;
/*     */     }
/* 118 */     return expandCodeToOutputStack(effectiveCode, addedUnfinishedEntry);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\UnshrinkingInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */