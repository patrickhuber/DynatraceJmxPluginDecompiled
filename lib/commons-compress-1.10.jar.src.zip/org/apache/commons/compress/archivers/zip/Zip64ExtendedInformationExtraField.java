/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.util.zip.ZipException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Zip64ExtendedInformationExtraField
/*     */   implements ZipExtraField
/*     */ {
/*  45 */   static final ZipShort HEADER_ID = new ZipShort(1);
/*     */   
/*     */ 
/*     */   private static final String LFH_MUST_HAVE_BOTH_SIZES_MSG = "Zip64 extended information must contain both size values in the local file header.";
/*     */   
/*  50 */   private static final byte[] EMPTY = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ZipEightByteInteger size;
/*     */   
/*     */ 
/*     */ 
/*     */   private ZipEightByteInteger compressedSize;
/*     */   
/*     */ 
/*     */ 
/*     */   private ZipEightByteInteger relativeHeaderOffset;
/*     */   
/*     */ 
/*     */ 
/*     */   private ZipLong diskStart;
/*     */   
/*     */ 
/*     */ 
/*     */   private byte[] rawCentralDirectoryData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Zip64ExtendedInformationExtraField() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Zip64ExtendedInformationExtraField(ZipEightByteInteger size, ZipEightByteInteger compressedSize)
/*     */   {
/*  83 */     this(size, compressedSize, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Zip64ExtendedInformationExtraField(ZipEightByteInteger size, ZipEightByteInteger compressedSize, ZipEightByteInteger relativeHeaderOffset, ZipLong diskStart)
/*     */   {
/* 100 */     this.size = size;
/* 101 */     this.compressedSize = compressedSize;
/* 102 */     this.relativeHeaderOffset = relativeHeaderOffset;
/* 103 */     this.diskStart = diskStart;
/*     */   }
/*     */   
/*     */   public ZipShort getHeaderId() {
/* 107 */     return HEADER_ID;
/*     */   }
/*     */   
/*     */   public ZipShort getLocalFileDataLength() {
/* 111 */     return new ZipShort(this.size != null ? 16 : 0);
/*     */   }
/*     */   
/*     */   public ZipShort getCentralDirectoryLength() {
/* 115 */     return new ZipShort((this.size != null ? 8 : 0) + (this.compressedSize != null ? 8 : 0) + (this.relativeHeaderOffset != null ? 8 : 0) + (this.diskStart != null ? 4 : 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getLocalFileDataData()
/*     */   {
/* 122 */     if ((this.size != null) || (this.compressedSize != null)) {
/* 123 */       if ((this.size == null) || (this.compressedSize == null)) {
/* 124 */         throw new IllegalArgumentException("Zip64 extended information must contain both size values in the local file header.");
/*     */       }
/* 126 */       byte[] data = new byte[16];
/* 127 */       addSizes(data);
/* 128 */       return data;
/*     */     }
/* 130 */     return EMPTY;
/*     */   }
/*     */   
/*     */   public byte[] getCentralDirectoryData() {
/* 134 */     byte[] data = new byte[getCentralDirectoryLength().getValue()];
/* 135 */     int off = addSizes(data);
/* 136 */     if (this.relativeHeaderOffset != null) {
/* 137 */       System.arraycopy(this.relativeHeaderOffset.getBytes(), 0, data, off, 8);
/* 138 */       off += 8;
/*     */     }
/* 140 */     if (this.diskStart != null) {
/* 141 */       System.arraycopy(this.diskStart.getBytes(), 0, data, off, 4);
/* 142 */       off += 4;
/*     */     }
/* 144 */     return data;
/*     */   }
/*     */   
/*     */   public void parseFromLocalFileData(byte[] buffer, int offset, int length) throws ZipException
/*     */   {
/* 149 */     if (length == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 154 */       return;
/*     */     }
/* 156 */     if (length < 16) {
/* 157 */       throw new ZipException("Zip64 extended information must contain both size values in the local file header.");
/*     */     }
/* 159 */     this.size = new ZipEightByteInteger(buffer, offset);
/* 160 */     offset += 8;
/* 161 */     this.compressedSize = new ZipEightByteInteger(buffer, offset);
/* 162 */     offset += 8;
/* 163 */     int remaining = length - 16;
/* 164 */     if (remaining >= 8) {
/* 165 */       this.relativeHeaderOffset = new ZipEightByteInteger(buffer, offset);
/* 166 */       offset += 8;
/* 167 */       remaining -= 8;
/*     */     }
/* 169 */     if (remaining >= 4) {
/* 170 */       this.diskStart = new ZipLong(buffer, offset);
/* 171 */       offset += 4;
/* 172 */       remaining -= 4;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void parseFromCentralDirectoryData(byte[] buffer, int offset, int length)
/*     */     throws ZipException
/*     */   {
/* 180 */     this.rawCentralDirectoryData = new byte[length];
/* 181 */     System.arraycopy(buffer, offset, this.rawCentralDirectoryData, 0, length);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */     if (length >= 28) {
/* 190 */       parseFromLocalFileData(buffer, offset, length);
/* 191 */     } else if (length == 24) {
/* 192 */       this.size = new ZipEightByteInteger(buffer, offset);
/* 193 */       offset += 8;
/* 194 */       this.compressedSize = new ZipEightByteInteger(buffer, offset);
/* 195 */       offset += 8;
/* 196 */       this.relativeHeaderOffset = new ZipEightByteInteger(buffer, offset);
/* 197 */     } else if (length % 8 == 4) {
/* 198 */       this.diskStart = new ZipLong(buffer, offset + length - 4);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reparseCentralDirectoryData(boolean hasUncompressedSize, boolean hasCompressedSize, boolean hasRelativeHeaderOffset, boolean hasDiskStart)
/*     */     throws ZipException
/*     */   {
/* 222 */     if (this.rawCentralDirectoryData != null) {
/* 223 */       int expectedLength = (hasUncompressedSize ? 8 : 0) + (hasCompressedSize ? 8 : 0) + (hasRelativeHeaderOffset ? 8 : 0) + (hasDiskStart ? 4 : 0);
/*     */       
/*     */ 
/*     */ 
/* 227 */       if (this.rawCentralDirectoryData.length < expectedLength) {
/* 228 */         throw new ZipException("central directory zip64 extended information extra field's length doesn't match central directory data.  Expected length " + expectedLength + " but is " + this.rawCentralDirectoryData.length);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */       int offset = 0;
/* 236 */       if (hasUncompressedSize) {
/* 237 */         this.size = new ZipEightByteInteger(this.rawCentralDirectoryData, offset);
/* 238 */         offset += 8;
/*     */       }
/* 240 */       if (hasCompressedSize) {
/* 241 */         this.compressedSize = new ZipEightByteInteger(this.rawCentralDirectoryData, offset);
/*     */         
/* 243 */         offset += 8;
/*     */       }
/* 245 */       if (hasRelativeHeaderOffset) {
/* 246 */         this.relativeHeaderOffset = new ZipEightByteInteger(this.rawCentralDirectoryData, offset);
/*     */         
/* 248 */         offset += 8;
/*     */       }
/* 250 */       if (hasDiskStart) {
/* 251 */         this.diskStart = new ZipLong(this.rawCentralDirectoryData, offset);
/* 252 */         offset += 4;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipEightByteInteger getSize()
/*     */   {
/* 262 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(ZipEightByteInteger size)
/*     */   {
/* 270 */     this.size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipEightByteInteger getCompressedSize()
/*     */   {
/* 278 */     return this.compressedSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompressedSize(ZipEightByteInteger compressedSize)
/*     */   {
/* 286 */     this.compressedSize = compressedSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipEightByteInteger getRelativeHeaderOffset()
/*     */   {
/* 294 */     return this.relativeHeaderOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRelativeHeaderOffset(ZipEightByteInteger rho)
/*     */   {
/* 302 */     this.relativeHeaderOffset = rho;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong getDiskStartNumber()
/*     */   {
/* 310 */     return this.diskStart;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDiskStartNumber(ZipLong ds)
/*     */   {
/* 318 */     this.diskStart = ds;
/*     */   }
/*     */   
/*     */   private int addSizes(byte[] data) {
/* 322 */     int off = 0;
/* 323 */     if (this.size != null) {
/* 324 */       System.arraycopy(this.size.getBytes(), 0, data, 0, 8);
/* 325 */       off += 8;
/*     */     }
/* 327 */     if (this.compressedSize != null) {
/* 328 */       System.arraycopy(this.compressedSize.getBytes(), 0, data, off, 8);
/* 329 */       off += 8;
/*     */     }
/* 331 */     return off;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\Zip64ExtendedInformationExtraField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */