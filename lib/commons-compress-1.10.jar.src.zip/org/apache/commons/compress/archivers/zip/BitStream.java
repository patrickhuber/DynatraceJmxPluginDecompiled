/*    */ package org.apache.commons.compress.archivers.zip;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.nio.ByteOrder;
/*    */ import org.apache.commons.compress.utils.BitInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BitStream
/*    */   extends BitInputStream
/*    */ {
/*    */   BitStream(InputStream in)
/*    */   {
/* 36 */     super(in, ByteOrder.LITTLE_ENDIAN);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   int nextBit()
/*    */     throws IOException
/*    */   {
/* 45 */     return (int)readBits(1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   long nextBits(int n)
/*    */     throws IOException
/*    */   {
/* 55 */     return readBits(n);
/*    */   }
/*    */   
/*    */   int nextByte() throws IOException {
/* 59 */     return (int)readBits(8);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\BitStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */