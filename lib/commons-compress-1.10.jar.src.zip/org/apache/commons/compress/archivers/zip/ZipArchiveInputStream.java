/*      */ package org.apache.commons.compress.archivers.zip;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PushbackInputStream;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.zip.CRC32;
/*      */ import java.util.zip.DataFormatException;
/*      */ import java.util.zip.Inflater;
/*      */ import java.util.zip.ZipException;
/*      */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*      */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*      */ import org.apache.commons.compress.utils.IOUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ZipArchiveInputStream
/*      */   extends ArchiveInputStream
/*      */ {
/*      */   private final ZipEncoding zipEncoding;
/*      */   final String encoding;
/*      */   private final boolean useUnicodeExtraFields;
/*      */   private final InputStream in;
/*   90 */   private final Inflater inf = new Inflater(true);
/*      */   
/*      */ 
/*   93 */   private final ByteBuffer buf = ByteBuffer.allocate(512);
/*      */   
/*      */ 
/*   96 */   private CurrentEntry current = null;
/*      */   
/*      */ 
/*   99 */   private boolean closed = false;
/*      */   
/*      */ 
/*  102 */   private boolean hitCentralDirectory = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  109 */   private ByteArrayInputStream lastStoredEntry = null;
/*      */   
/*      */ 
/*  112 */   private boolean allowStoredEntriesWithDataDescriptor = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int LFH_LEN = 30;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int CFH_LEN = 46;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final long TWO_EXP_32 = 4294967296L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  153 */   private final byte[] LFH_BUF = new byte[30];
/*  154 */   private final byte[] SKIP_BUF = new byte['Ѐ'];
/*  155 */   private final byte[] SHORT_BUF = new byte[2];
/*  156 */   private final byte[] WORD_BUF = new byte[4];
/*  157 */   private final byte[] TWO_DWORD_BUF = new byte[16];
/*      */   
/*  159 */   private int entriesRead = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveInputStream(InputStream inputStream)
/*      */   {
/*  166 */     this(inputStream, "UTF8");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveInputStream(InputStream inputStream, String encoding)
/*      */   {
/*  177 */     this(inputStream, encoding, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveInputStream(InputStream inputStream, String encoding, boolean useUnicodeExtraFields)
/*      */   {
/*  189 */     this(inputStream, encoding, useUnicodeExtraFields, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ZipArchiveInputStream(InputStream inputStream, String encoding, boolean useUnicodeExtraFields, boolean allowStoredEntriesWithDataDescriptor)
/*      */   {
/*  207 */     this.encoding = encoding;
/*  208 */     this.zipEncoding = ZipEncodingHelper.getZipEncoding(encoding);
/*  209 */     this.useUnicodeExtraFields = useUnicodeExtraFields;
/*  210 */     this.in = new PushbackInputStream(inputStream, this.buf.capacity());
/*  211 */     this.allowStoredEntriesWithDataDescriptor = allowStoredEntriesWithDataDescriptor;
/*      */     
/*      */ 
/*  214 */     this.buf.limit(0);
/*      */   }
/*      */   
/*      */   public ZipArchiveEntry getNextZipEntry() throws IOException {
/*  218 */     boolean firstEntry = true;
/*  219 */     if ((this.closed) || (this.hitCentralDirectory)) {
/*  220 */       return null;
/*      */     }
/*  222 */     if (this.current != null) {
/*  223 */       closeEntry();
/*  224 */       firstEntry = false;
/*      */     }
/*      */     try
/*      */     {
/*  228 */       if (firstEntry)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  233 */         readFirstLocalFileHeader(this.LFH_BUF);
/*      */       } else {
/*  235 */         readFully(this.LFH_BUF);
/*      */       }
/*      */     } catch (EOFException e) {
/*  238 */       return null;
/*      */     }
/*      */     
/*  241 */     ZipLong sig = new ZipLong(this.LFH_BUF);
/*  242 */     if ((sig.equals(ZipLong.CFH_SIG)) || (sig.equals(ZipLong.AED_SIG))) {
/*  243 */       this.hitCentralDirectory = true;
/*  244 */       skipRemainderOfArchive();
/*      */     }
/*  246 */     if (!sig.equals(ZipLong.LFH_SIG)) {
/*  247 */       return null;
/*      */     }
/*      */     
/*  250 */     int off = 4;
/*  251 */     this.current = new CurrentEntry(null);
/*      */     
/*  253 */     int versionMadeBy = ZipShort.getValue(this.LFH_BUF, off);
/*  254 */     off += 2;
/*  255 */     this.current.entry.setPlatform(versionMadeBy >> 8 & 0xF);
/*      */     
/*  257 */     GeneralPurposeBit gpFlag = GeneralPurposeBit.parse(this.LFH_BUF, off);
/*  258 */     boolean hasUTF8Flag = gpFlag.usesUTF8ForNames();
/*  259 */     ZipEncoding entryEncoding = hasUTF8Flag ? ZipEncodingHelper.UTF8_ZIP_ENCODING : this.zipEncoding;
/*  260 */     this.current.hasDataDescriptor = gpFlag.usesDataDescriptor();
/*  261 */     this.current.entry.setGeneralPurposeBit(gpFlag);
/*      */     
/*  263 */     off += 2;
/*      */     
/*  265 */     this.current.entry.setMethod(ZipShort.getValue(this.LFH_BUF, off));
/*  266 */     off += 2;
/*      */     
/*  268 */     long time = ZipUtil.dosToJavaTime(ZipLong.getValue(this.LFH_BUF, off));
/*  269 */     this.current.entry.setTime(time);
/*  270 */     off += 4;
/*      */     
/*  272 */     ZipLong size = null;ZipLong cSize = null;
/*  273 */     if (!this.current.hasDataDescriptor) {
/*  274 */       this.current.entry.setCrc(ZipLong.getValue(this.LFH_BUF, off));
/*  275 */       off += 4;
/*      */       
/*  277 */       cSize = new ZipLong(this.LFH_BUF, off);
/*  278 */       off += 4;
/*      */       
/*  280 */       size = new ZipLong(this.LFH_BUF, off);
/*  281 */       off += 4;
/*      */     } else {
/*  283 */       off += 12;
/*      */     }
/*      */     
/*  286 */     int fileNameLen = ZipShort.getValue(this.LFH_BUF, off);
/*      */     
/*  288 */     off += 2;
/*      */     
/*  290 */     int extraLen = ZipShort.getValue(this.LFH_BUF, off);
/*  291 */     off += 2;
/*      */     
/*  293 */     byte[] fileName = new byte[fileNameLen];
/*  294 */     readFully(fileName);
/*  295 */     this.current.entry.setName(entryEncoding.decode(fileName), fileName);
/*      */     
/*  297 */     byte[] extraData = new byte[extraLen];
/*  298 */     readFully(extraData);
/*  299 */     this.current.entry.setExtra(extraData);
/*      */     
/*  301 */     if ((!hasUTF8Flag) && (this.useUnicodeExtraFields)) {
/*  302 */       ZipUtil.setNameAndCommentFromExtraFields(this.current.entry, fileName, null);
/*      */     }
/*      */     
/*  305 */     processZip64Extra(size, cSize);
/*      */     
/*  307 */     if (this.current.entry.getCompressedSize() != -1L) {
/*  308 */       if (this.current.entry.getMethod() == ZipMethod.UNSHRINKING.getCode()) {
/*  309 */         this.current.in = new UnshrinkingInputStream(new BoundedInputStream(this.in, this.current.entry.getCompressedSize()));
/*  310 */       } else if (this.current.entry.getMethod() == ZipMethod.IMPLODING.getCode()) {
/*  311 */         this.current.in = new ExplodingInputStream(this.current.entry.getGeneralPurposeBit().getSlidingDictionarySize(), this.current.entry.getGeneralPurposeBit().getNumberOfShannonFanoTrees(), new BoundedInputStream(this.in, this.current.entry.getCompressedSize()));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  318 */     this.entriesRead += 1;
/*  319 */     return this.current.entry;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readFirstLocalFileHeader(byte[] lfh)
/*      */     throws IOException
/*      */   {
/*  328 */     readFully(lfh);
/*  329 */     ZipLong sig = new ZipLong(lfh);
/*  330 */     if (sig.equals(ZipLong.DD_SIG)) {
/*  331 */       throw new UnsupportedZipFeatureException(UnsupportedZipFeatureException.Feature.SPLITTING);
/*      */     }
/*      */     
/*  334 */     if (sig.equals(ZipLong.SINGLE_SEGMENT_SPLIT_MARKER))
/*      */     {
/*      */ 
/*  337 */       byte[] missedLfhBytes = new byte[4];
/*  338 */       readFully(missedLfhBytes);
/*  339 */       System.arraycopy(lfh, 4, lfh, 0, 26);
/*  340 */       System.arraycopy(missedLfhBytes, 0, lfh, 26, 4);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processZip64Extra(ZipLong size, ZipLong cSize)
/*      */   {
/*  350 */     Zip64ExtendedInformationExtraField z64 = (Zip64ExtendedInformationExtraField)this.current.entry.getExtraField(Zip64ExtendedInformationExtraField.HEADER_ID);
/*      */     
/*      */ 
/*  353 */     this.current.usesZip64 = (z64 != null);
/*  354 */     if (!this.current.hasDataDescriptor) {
/*  355 */       if ((z64 != null) && ((cSize.equals(ZipLong.ZIP64_MAGIC)) || (size.equals(ZipLong.ZIP64_MAGIC))))
/*      */       {
/*  357 */         this.current.entry.setCompressedSize(z64.getCompressedSize().getLongValue());
/*  358 */         this.current.entry.setSize(z64.getSize().getLongValue());
/*      */       } else {
/*  360 */         this.current.entry.setCompressedSize(cSize.getValue());
/*  361 */         this.current.entry.setSize(size.getValue());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public ArchiveEntry getNextEntry() throws IOException
/*      */   {
/*  368 */     return getNextZipEntry();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean canReadEntryData(ArchiveEntry ae)
/*      */   {
/*  380 */     if ((ae instanceof ZipArchiveEntry)) {
/*  381 */       ZipArchiveEntry ze = (ZipArchiveEntry)ae;
/*  382 */       return (ZipUtil.canHandleEntryData(ze)) && (supportsDataDescriptorFor(ze));
/*      */     }
/*      */     
/*      */ 
/*  386 */     return false;
/*      */   }
/*      */   
/*      */   public int read(byte[] buffer, int offset, int length) throws IOException
/*      */   {
/*  391 */     if (this.closed) {
/*  392 */       throw new IOException("The stream is closed");
/*      */     }
/*      */     
/*  395 */     if (this.current == null) {
/*  396 */       return -1;
/*      */     }
/*      */     
/*      */ 
/*  400 */     if ((offset > buffer.length) || (length < 0) || (offset < 0) || (buffer.length - offset < length)) {
/*  401 */       throw new ArrayIndexOutOfBoundsException();
/*      */     }
/*      */     
/*  404 */     ZipUtil.checkRequestedFeatures(this.current.entry);
/*  405 */     if (!supportsDataDescriptorFor(this.current.entry)) {
/*  406 */       throw new UnsupportedZipFeatureException(UnsupportedZipFeatureException.Feature.DATA_DESCRIPTOR, this.current.entry);
/*      */     }
/*      */     
/*      */     int read;
/*      */     
/*  411 */     if (this.current.entry.getMethod() == 0) {
/*  412 */       read = readStored(buffer, offset, length); } else { int read;
/*  413 */       if (this.current.entry.getMethod() == 8) {
/*  414 */         read = readDeflated(buffer, offset, length); } else { int read;
/*  415 */         if ((this.current.entry.getMethod() == ZipMethod.UNSHRINKING.getCode()) || (this.current.entry.getMethod() == ZipMethod.IMPLODING.getCode()))
/*      */         {
/*  417 */           read = this.current.in.read(buffer, offset, length);
/*      */         } else
/*  419 */           throw new UnsupportedZipFeatureException(ZipMethod.getMethodByCode(this.current.entry.getMethod()), this.current.entry);
/*      */       }
/*      */     }
/*      */     int read;
/*  423 */     if (read >= 0) {
/*  424 */       this.current.crc.update(buffer, offset, read);
/*      */     }
/*      */     
/*  427 */     return read;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int readStored(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  435 */     if (this.current.hasDataDescriptor) {
/*  436 */       if (this.lastStoredEntry == null) {
/*  437 */         readStoredEntry();
/*      */       }
/*  439 */       return this.lastStoredEntry.read(buffer, offset, length);
/*      */     }
/*      */     
/*  442 */     long csize = this.current.entry.getSize();
/*  443 */     if (this.current.bytesRead >= csize) {
/*  444 */       return -1;
/*      */     }
/*      */     
/*  447 */     if (this.buf.position() >= this.buf.limit()) {
/*  448 */       this.buf.position(0);
/*  449 */       int l = this.in.read(this.buf.array());
/*  450 */       if (l == -1) {
/*  451 */         return -1;
/*      */       }
/*  453 */       this.buf.limit(l);
/*      */       
/*  455 */       count(l);
/*  456 */       CurrentEntry.access$714(this.current, l);
/*      */     }
/*      */     
/*  459 */     int toRead = Math.min(this.buf.remaining(), length);
/*  460 */     if (csize - this.current.bytesRead < toRead)
/*      */     {
/*  462 */       toRead = (int)(csize - this.current.bytesRead);
/*      */     }
/*  464 */     this.buf.get(buffer, offset, toRead);
/*  465 */     CurrentEntry.access$614(this.current, toRead);
/*  466 */     return toRead;
/*      */   }
/*      */   
/*      */ 
/*      */   private int readDeflated(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  473 */     int read = readFromInflater(buffer, offset, length);
/*  474 */     if (read <= 0) {
/*  475 */       if (this.inf.finished())
/*  476 */         return -1;
/*  477 */       if (this.inf.needsDictionary()) {
/*  478 */         throw new ZipException("This archive needs a preset dictionary which is not supported by Commons Compress.");
/*      */       }
/*      */       
/*  481 */       if (read == -1) {
/*  482 */         throw new IOException("Truncated ZIP file");
/*      */       }
/*      */     }
/*  485 */     return read;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int readFromInflater(byte[] buffer, int offset, int length)
/*      */     throws IOException
/*      */   {
/*  493 */     int read = 0;
/*      */     do {
/*  495 */       if (this.inf.needsInput()) {
/*  496 */         int l = fill();
/*  497 */         if (l > 0) {
/*  498 */           CurrentEntry.access$714(this.current, this.buf.limit());
/*  499 */         } else { if (l != -1) break;
/*  500 */           return -1;
/*      */         }
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  506 */         read = this.inf.inflate(buffer, offset, length);
/*      */       } catch (DataFormatException e) {
/*  508 */         throw ((IOException)new ZipException(e.getMessage()).initCause(e));
/*      */       }
/*  510 */     } while ((read == 0) && (this.inf.needsInput()));
/*  511 */     return read;
/*      */   }
/*      */   
/*      */   public void close() throws IOException
/*      */   {
/*  516 */     if (!this.closed) {
/*  517 */       this.closed = true;
/*  518 */       this.in.close();
/*  519 */       this.inf.end();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long skip(long value)
/*      */     throws IOException
/*      */   {
/*  540 */     if (value >= 0L) {
/*  541 */       long skipped = 0L;
/*  542 */       while (skipped < value) {
/*  543 */         long rem = value - skipped;
/*  544 */         int x = read(this.SKIP_BUF, 0, (int)(this.SKIP_BUF.length > rem ? rem : this.SKIP_BUF.length));
/*  545 */         if (x == -1) {
/*  546 */           return skipped;
/*      */         }
/*  548 */         skipped += x;
/*      */       }
/*  550 */       return skipped;
/*      */     }
/*  552 */     throw new IllegalArgumentException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean matches(byte[] signature, int length)
/*      */   {
/*  565 */     if (length < ZipArchiveOutputStream.LFH_SIG.length) {
/*  566 */       return false;
/*      */     }
/*      */     
/*  569 */     return (checksig(signature, ZipArchiveOutputStream.LFH_SIG)) || (checksig(signature, ZipArchiveOutputStream.EOCD_SIG)) || (checksig(signature, ZipArchiveOutputStream.DD_SIG)) || (checksig(signature, ZipLong.SINGLE_SEGMENT_SPLIT_MARKER.getBytes()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static boolean checksig(byte[] signature, byte[] expected)
/*      */   {
/*  576 */     for (int i = 0; i < expected.length; i++) {
/*  577 */       if (signature[i] != expected[i]) {
/*  578 */         return false;
/*      */       }
/*      */     }
/*  581 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void closeEntry()
/*      */     throws IOException
/*      */   {
/*  603 */     if (this.closed) {
/*  604 */       throw new IOException("The stream is closed");
/*      */     }
/*  606 */     if (this.current == null) {
/*  607 */       return;
/*      */     }
/*      */     
/*      */ 
/*  611 */     if ((this.current.bytesReadFromStream <= this.current.entry.getCompressedSize()) && (!this.current.hasDataDescriptor))
/*      */     {
/*  613 */       drainCurrentEntryData();
/*      */     } else {
/*  615 */       skip(Long.MAX_VALUE);
/*      */       
/*  617 */       long inB = this.current.entry.getMethod() == 8 ? getBytesInflated() : this.current.bytesRead;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  622 */       int diff = (int)(this.current.bytesReadFromStream - inB);
/*      */       
/*      */ 
/*  625 */       if (diff > 0) {
/*  626 */         pushback(this.buf.array(), this.buf.limit() - diff, diff);
/*      */       }
/*      */     }
/*      */     
/*  630 */     if ((this.lastStoredEntry == null) && (this.current.hasDataDescriptor)) {
/*  631 */       readDataDescriptor();
/*      */     }
/*      */     
/*  634 */     this.inf.reset();
/*  635 */     this.buf.clear().flip();
/*  636 */     this.current = null;
/*  637 */     this.lastStoredEntry = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void drainCurrentEntryData()
/*      */     throws IOException
/*      */   {
/*  645 */     long remaining = this.current.entry.getCompressedSize() - this.current.bytesReadFromStream;
/*  646 */     while (remaining > 0L) {
/*  647 */       long n = this.in.read(this.buf.array(), 0, (int)Math.min(this.buf.capacity(), remaining));
/*  648 */       if (n < 0L) {
/*  649 */         throw new EOFException("Truncated ZIP entry: " + this.current.entry.getName());
/*      */       }
/*  651 */       count(n);
/*  652 */       remaining -= n;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private long getBytesInflated()
/*      */   {
/*  673 */     long inB = this.inf.getBytesRead();
/*  674 */     if (this.current.bytesReadFromStream >= 4294967296L) {
/*  675 */       while (inB + 4294967296L <= this.current.bytesReadFromStream) {
/*  676 */         inB += 4294967296L;
/*      */       }
/*      */     }
/*  679 */     return inB;
/*      */   }
/*      */   
/*      */   private int fill() throws IOException {
/*  683 */     if (this.closed) {
/*  684 */       throw new IOException("The stream is closed");
/*      */     }
/*  686 */     int length = this.in.read(this.buf.array());
/*  687 */     if (length > 0) {
/*  688 */       this.buf.limit(length);
/*  689 */       count(this.buf.limit());
/*  690 */       this.inf.setInput(this.buf.array(), 0, this.buf.limit());
/*      */     }
/*  692 */     return length;
/*      */   }
/*      */   
/*      */   private void readFully(byte[] b) throws IOException {
/*  696 */     int count = IOUtils.readFully(this.in, b);
/*  697 */     count(count);
/*  698 */     if (count < b.length) {
/*  699 */       throw new EOFException();
/*      */     }
/*      */   }
/*      */   
/*      */   private void readDataDescriptor() throws IOException {
/*  704 */     readFully(this.WORD_BUF);
/*  705 */     ZipLong val = new ZipLong(this.WORD_BUF);
/*  706 */     if (ZipLong.DD_SIG.equals(val))
/*      */     {
/*  708 */       readFully(this.WORD_BUF);
/*  709 */       val = new ZipLong(this.WORD_BUF);
/*      */     }
/*  711 */     this.current.entry.setCrc(val.getValue());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  724 */     readFully(this.TWO_DWORD_BUF);
/*  725 */     ZipLong potentialSig = new ZipLong(this.TWO_DWORD_BUF, 8);
/*  726 */     if ((potentialSig.equals(ZipLong.CFH_SIG)) || (potentialSig.equals(ZipLong.LFH_SIG))) {
/*  727 */       pushback(this.TWO_DWORD_BUF, 8, 8);
/*  728 */       this.current.entry.setCompressedSize(ZipLong.getValue(this.TWO_DWORD_BUF));
/*  729 */       this.current.entry.setSize(ZipLong.getValue(this.TWO_DWORD_BUF, 4));
/*      */     } else {
/*  731 */       this.current.entry.setCompressedSize(ZipEightByteInteger.getLongValue(this.TWO_DWORD_BUF));
/*  732 */       this.current.entry.setSize(ZipEightByteInteger.getLongValue(this.TWO_DWORD_BUF, 8));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean supportsDataDescriptorFor(ZipArchiveEntry entry)
/*      */   {
/*  744 */     return (!entry.getGeneralPurposeBit().usesDataDescriptor()) || ((this.allowStoredEntriesWithDataDescriptor) && (entry.getMethod() == 0)) || (entry.getMethod() == 8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readStoredEntry()
/*      */     throws IOException
/*      */   {
/*  768 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  769 */     int off = 0;
/*  770 */     boolean done = false;
/*      */     
/*      */ 
/*  773 */     int ddLen = this.current.usesZip64 ? 20 : 12;
/*      */     
/*  775 */     while (!done) {
/*  776 */       int r = this.in.read(this.buf.array(), off, 512 - off);
/*  777 */       if (r <= 0)
/*      */       {
/*      */ 
/*  780 */         throw new IOException("Truncated ZIP file");
/*      */       }
/*  782 */       if (r + off < 4)
/*      */       {
/*  784 */         off += r;
/*      */       }
/*      */       else
/*      */       {
/*  788 */         done = bufferContainsSignature(bos, off, r, ddLen);
/*  789 */         if (!done) {
/*  790 */           off = cacheBytesRead(bos, off, r, ddLen);
/*      */         }
/*      */       }
/*      */     }
/*  794 */     byte[] b = bos.toByteArray();
/*  795 */     this.lastStoredEntry = new ByteArrayInputStream(b);
/*      */   }
/*      */   
/*  798 */   private static final byte[] LFH = ZipLong.LFH_SIG.getBytes();
/*  799 */   private static final byte[] CFH = ZipLong.CFH_SIG.getBytes();
/*  800 */   private static final byte[] DD = ZipLong.DD_SIG.getBytes();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean bufferContainsSignature(ByteArrayOutputStream bos, int offset, int lastRead, int expectedDDLen)
/*      */     throws IOException
/*      */   {
/*  813 */     boolean done = false;
/*  814 */     int readTooMuch = 0;
/*  815 */     for (int i = 0; (!done) && (i < lastRead - 4); i++) {
/*  816 */       if ((this.buf.array()[i] == LFH[0]) && (this.buf.array()[(i + 1)] == LFH[1])) {
/*  817 */         if (((this.buf.array()[(i + 2)] == LFH[2]) && (this.buf.array()[(i + 3)] == LFH[3])) || ((this.buf.array()[i] == CFH[2]) && (this.buf.array()[(i + 3)] == CFH[3])))
/*      */         {
/*      */ 
/*  820 */           readTooMuch = offset + lastRead - i - expectedDDLen;
/*  821 */           done = true;
/*      */         }
/*  823 */         else if ((this.buf.array()[(i + 2)] == DD[2]) && (this.buf.array()[(i + 3)] == DD[3]))
/*      */         {
/*  825 */           readTooMuch = offset + lastRead - i;
/*  826 */           done = true;
/*      */         }
/*  828 */         if (done)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*  833 */           pushback(this.buf.array(), offset + lastRead - readTooMuch, readTooMuch);
/*  834 */           bos.write(this.buf.array(), 0, i);
/*  835 */           readDataDescriptor();
/*      */         }
/*      */       }
/*      */     }
/*  839 */     return done;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int cacheBytesRead(ByteArrayOutputStream bos, int offset, int lastRead, int expecteDDLen)
/*      */   {
/*  852 */     int cacheable = offset + lastRead - expecteDDLen - 3;
/*  853 */     if (cacheable > 0) {
/*  854 */       bos.write(this.buf.array(), 0, cacheable);
/*  855 */       System.arraycopy(this.buf.array(), cacheable, this.buf.array(), 0, expecteDDLen + 3);
/*  856 */       offset = expecteDDLen + 3;
/*      */     } else {
/*  858 */       offset += lastRead;
/*      */     }
/*  860 */     return offset;
/*      */   }
/*      */   
/*      */   private void pushback(byte[] buf, int offset, int length) throws IOException {
/*  864 */     ((PushbackInputStream)this.in).unread(buf, offset, length);
/*  865 */     pushedBackBytes(length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void skipRemainderOfArchive()
/*      */     throws IOException
/*      */   {
/*  893 */     realSkip(this.entriesRead * 46 - 30);
/*  894 */     findEocdRecord();
/*  895 */     realSkip(16L);
/*  896 */     readFully(this.SHORT_BUF);
/*      */     
/*  898 */     realSkip(ZipShort.getValue(this.SHORT_BUF));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void findEocdRecord()
/*      */     throws IOException
/*      */   {
/*  906 */     int currentByte = -1;
/*  907 */     boolean skipReadCall = false;
/*  908 */     while ((skipReadCall) || ((currentByte = readOneByte()) > -1)) {
/*  909 */       skipReadCall = false;
/*  910 */       if (isFirstByteOfEocdSig(currentByte))
/*      */       {
/*      */ 
/*  913 */         currentByte = readOneByte();
/*  914 */         if (currentByte != ZipArchiveOutputStream.EOCD_SIG[1]) {
/*  915 */           if (currentByte == -1) {
/*      */             break;
/*      */           }
/*  918 */           skipReadCall = isFirstByteOfEocdSig(currentByte);
/*      */         }
/*      */         else {
/*  921 */           currentByte = readOneByte();
/*  922 */           if (currentByte != ZipArchiveOutputStream.EOCD_SIG[2]) {
/*  923 */             if (currentByte == -1) {
/*      */               break;
/*      */             }
/*  926 */             skipReadCall = isFirstByteOfEocdSig(currentByte);
/*      */           }
/*      */           else {
/*  929 */             currentByte = readOneByte();
/*  930 */             if ((currentByte == -1) || (currentByte == ZipArchiveOutputStream.EOCD_SIG[3])) {
/*      */               break;
/*      */             }
/*      */             
/*  934 */             skipReadCall = isFirstByteOfEocdSig(currentByte);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void realSkip(long value)
/*      */     throws IOException
/*      */   {
/*  946 */     if (value >= 0L) {
/*  947 */       long skipped = 0L;
/*  948 */       while (skipped < value) {
/*  949 */         long rem = value - skipped;
/*  950 */         int x = this.in.read(this.SKIP_BUF, 0, (int)(this.SKIP_BUF.length > rem ? rem : this.SKIP_BUF.length));
/*  951 */         if (x == -1) {
/*  952 */           return;
/*      */         }
/*  954 */         count(x);
/*  955 */         skipped += x;
/*      */       }
/*  957 */       return;
/*      */     }
/*  959 */     throw new IllegalArgumentException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int readOneByte()
/*      */     throws IOException
/*      */   {
/*  969 */     int b = this.in.read();
/*  970 */     if (b != -1) {
/*  971 */       count(1);
/*      */     }
/*  973 */     return b;
/*      */   }
/*      */   
/*      */   private boolean isFirstByteOfEocdSig(int b) {
/*  977 */     return b == ZipArchiveOutputStream.EOCD_SIG[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final class CurrentEntry
/*      */   {
/*  989 */     private final ZipArchiveEntry entry = new ZipArchiveEntry();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private boolean hasDataDescriptor;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private boolean usesZip64;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private long bytesRead;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     private long bytesReadFromStream;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1019 */     private final CRC32 crc = new CRC32();
/*      */     
/*      */ 
/*      */ 
/*      */     private InputStream in;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class BoundedInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private final InputStream in;
/*      */     
/*      */ 
/*      */ 
/*      */     private final long max;
/*      */     
/*      */ 
/* 1039 */     private long pos = 0L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public BoundedInputStream(InputStream in, long size)
/*      */     {
/* 1049 */       this.max = size;
/* 1050 */       this.in = in;
/*      */     }
/*      */     
/*      */     public int read() throws IOException
/*      */     {
/* 1055 */       if ((this.max >= 0L) && (this.pos >= this.max)) {
/* 1056 */         return -1;
/*      */       }
/* 1058 */       int result = this.in.read();
/* 1059 */       this.pos += 1L;
/* 1060 */       ZipArchiveInputStream.this.count(1);
/* 1061 */       ZipArchiveInputStream.CurrentEntry.access$708(ZipArchiveInputStream.this.current);
/* 1062 */       return result;
/*      */     }
/*      */     
/*      */     public int read(byte[] b) throws IOException
/*      */     {
/* 1067 */       return read(b, 0, b.length);
/*      */     }
/*      */     
/*      */     public int read(byte[] b, int off, int len) throws IOException
/*      */     {
/* 1072 */       if ((this.max >= 0L) && (this.pos >= this.max)) {
/* 1073 */         return -1;
/*      */       }
/* 1075 */       long maxRead = this.max >= 0L ? Math.min(len, this.max - this.pos) : len;
/* 1076 */       int bytesRead = this.in.read(b, off, (int)maxRead);
/*      */       
/* 1078 */       if (bytesRead == -1) {
/* 1079 */         return -1;
/*      */       }
/*      */       
/* 1082 */       this.pos += bytesRead;
/* 1083 */       ZipArchiveInputStream.this.count(bytesRead);
/* 1084 */       ZipArchiveInputStream.CurrentEntry.access$714(ZipArchiveInputStream.this.current, bytesRead);
/* 1085 */       return bytesRead;
/*      */     }
/*      */     
/*      */     public long skip(long n) throws IOException
/*      */     {
/* 1090 */       long toSkip = this.max >= 0L ? Math.min(n, this.max - this.pos) : n;
/* 1091 */       long skippedBytes = this.in.skip(toSkip);
/* 1092 */       this.pos += skippedBytes;
/* 1093 */       return skippedBytes;
/*      */     }
/*      */     
/*      */     public int available() throws IOException
/*      */     {
/* 1098 */       if ((this.max >= 0L) && (this.pos >= this.max)) {
/* 1099 */         return 0;
/*      */       }
/* 1101 */       return this.in.available();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */