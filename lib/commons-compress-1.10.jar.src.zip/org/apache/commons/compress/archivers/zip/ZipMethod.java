/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum ZipMethod
/*     */ {
/*  39 */   STORED(0), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */   UNSHRINKING(1), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   EXPANDING_LEVEL_1(2), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */   EXPANDING_LEVEL_2(3), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   EXPANDING_LEVEL_3(4), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   EXPANDING_LEVEL_4(5), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   IMPLODING(6), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   TOKENIZATION(7), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */   DEFLATED(8), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   ENHANCED_DEFLATED(9), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */   PKWARE_IMPLODING(10), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */   BZIP2(12), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */   LZMA(14), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */   JPEG(96), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 147 */   WAVPACK(97), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */   PPMD(98), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */   AES_ENCRYPTED(99), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 167 */   UNKNOWN;
/*     */   
/*     */ 
/*     */   static final int UNKNOWN_CODE = -1;
/*     */   private final int code;
/*     */   private static final Map<Integer, ZipMethod> codeToEnum;
/*     */   
/*     */   static
/*     */   {
/* 176 */     Map<Integer, ZipMethod> cte = new HashMap();
/* 177 */     for (ZipMethod method : values()) {
/* 178 */       cte.put(Integer.valueOf(method.getCode()), method);
/*     */     }
/* 180 */     codeToEnum = Collections.unmodifiableMap(cte);
/*     */   }
/*     */   
/*     */   private ZipMethod() {
/* 184 */     this(-1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ZipMethod(int code)
/*     */   {
/* 191 */     this.code = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCode()
/*     */   {
/* 202 */     return this.code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ZipMethod getMethodByCode(int code)
/*     */   {
/* 214 */     return (ZipMethod)codeToEnum.get(Integer.valueOf(code));
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipMethod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */