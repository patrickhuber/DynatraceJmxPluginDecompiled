/*    */ package org.apache.commons.compress.archivers.zip;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnicodeCommentExtraField
/*    */   extends AbstractUnicodeExtraField
/*    */ {
/* 34 */   public static final ZipShort UCOM_ID = new ZipShort(25461);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnicodeCommentExtraField() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnicodeCommentExtraField(String text, byte[] bytes, int off, int len)
/*    */   {
/* 51 */     super(text, bytes, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public UnicodeCommentExtraField(String comment, byte[] bytes)
/*    */   {
/* 62 */     super(comment, bytes);
/*    */   }
/*    */   
/*    */   public ZipShort getHeaderId() {
/* 66 */     return UCOM_ID;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\UnicodeCommentExtraField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */