/*     */ package org.apache.commons.compress.archivers.zip;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ZipLong
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final int BYTE_1 = 1;
/*     */   private static final int BYTE_1_MASK = 65280;
/*     */   private static final int BYTE_1_SHIFT = 8;
/*     */   private static final int BYTE_2 = 2;
/*     */   private static final int BYTE_2_MASK = 16711680;
/*     */   private static final int BYTE_2_SHIFT = 16;
/*     */   private static final int BYTE_3 = 3;
/*     */   private static final long BYTE_3_MASK = 4278190080L;
/*     */   private static final int BYTE_3_SHIFT = 24;
/*     */   private final long value;
/*  50 */   public static final ZipLong CFH_SIG = new ZipLong(33639248L);
/*     */   
/*     */ 
/*  53 */   public static final ZipLong LFH_SIG = new ZipLong(67324752L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   public static final ZipLong DD_SIG = new ZipLong(134695760L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   static final ZipLong ZIP64_MAGIC = new ZipLong(4294967295L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   public static final ZipLong SINGLE_SEGMENT_SPLIT_MARKER = new ZipLong(808471376L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  87 */   public static final ZipLong AED_SIG = new ZipLong(134630224L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong(long value)
/*     */   {
/*  94 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong(byte[] bytes)
/*     */   {
/* 102 */     this(bytes, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ZipLong(byte[] bytes, int offset)
/*     */   {
/* 111 */     this.value = getValue(bytes, offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/* 119 */     return getBytes(this.value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getValue()
/*     */   {
/* 127 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] getBytes(long value)
/*     */   {
/* 136 */     byte[] result = new byte[4];
/* 137 */     putLong(value, result, 0);
/* 138 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putLong(long value, byte[] buf, int offset)
/*     */   {
/* 151 */     buf[(offset++)] = ((byte)(int)(value & 0xFF));
/* 152 */     buf[(offset++)] = ((byte)(int)((value & 0xFF00) >> 8));
/* 153 */     buf[(offset++)] = ((byte)(int)((value & 0xFF0000) >> 16));
/* 154 */     buf[offset] = ((byte)(int)((value & 0xFF000000) >> 24));
/*     */   }
/*     */   
/*     */   public void putLong(byte[] buf, int offset) {
/* 158 */     putLong(this.value, buf, offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getValue(byte[] bytes, int offset)
/*     */   {
/* 168 */     long value = bytes[(offset + 3)] << 24 & 0xFF000000;
/* 169 */     value += (bytes[(offset + 2)] << 16 & 0xFF0000);
/* 170 */     value += (bytes[(offset + 1)] << 8 & 0xFF00);
/* 171 */     value += (bytes[offset] & 0xFF);
/* 172 */     return value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getValue(byte[] bytes)
/*     */   {
/* 181 */     return getValue(bytes, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 191 */     if ((o == null) || (!(o instanceof ZipLong))) {
/* 192 */       return false;
/*     */     }
/* 194 */     return this.value == ((ZipLong)o).getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 203 */     return (int)this.value;
/*     */   }
/*     */   
/*     */   public Object clone()
/*     */   {
/*     */     try {
/* 209 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException cnfe) {
/* 212 */       throw new RuntimeException(cnfe);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 218 */     return "ZipLong value: " + this.value;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\zip\ZipLong.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */