/*     */ package org.apache.commons.compress.archivers.ar;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArArchiveEntry
/*     */   implements ArchiveEntry
/*     */ {
/*     */   public static final String HEADER = "!<arch>\n";
/*     */   public static final String TRAILER = "`\n";
/*     */   private final String name;
/*     */   private final int userId;
/*     */   private final int groupId;
/*     */   private final int mode;
/*     */   private static final int DEFAULT_MODE = 33188;
/*     */   private final long lastModified;
/*     */   private final long length;
/*     */   
/*     */   public ArArchiveEntry(String name, long length)
/*     */   {
/*  85 */     this(name, length, 0, 0, 33188, System.currentTimeMillis() / 1000L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArArchiveEntry(String name, long length, int userId, int groupId, int mode, long lastModified)
/*     */   {
/* 101 */     this.name = name;
/* 102 */     this.length = length;
/* 103 */     this.userId = userId;
/* 104 */     this.groupId = groupId;
/* 105 */     this.mode = mode;
/* 106 */     this.lastModified = lastModified;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArArchiveEntry(File inputFile, String entryName)
/*     */   {
/* 116 */     this(entryName, inputFile.isFile() ? inputFile.length() : 0L, 0, 0, 33188, inputFile.lastModified() / 1000L);
/*     */   }
/*     */   
/*     */   public long getSize()
/*     */   {
/* 121 */     return getLength();
/*     */   }
/*     */   
/*     */   public String getName() {
/* 125 */     return this.name;
/*     */   }
/*     */   
/*     */   public int getUserId() {
/* 129 */     return this.userId;
/*     */   }
/*     */   
/*     */   public int getGroupId() {
/* 133 */     return this.groupId;
/*     */   }
/*     */   
/*     */   public int getMode() {
/* 137 */     return this.mode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLastModified()
/*     */   {
/* 145 */     return this.lastModified;
/*     */   }
/*     */   
/*     */   public Date getLastModifiedDate() {
/* 149 */     return new Date(1000L * getLastModified());
/*     */   }
/*     */   
/*     */   public long getLength() {
/* 153 */     return this.length;
/*     */   }
/*     */   
/*     */   public boolean isDirectory() {
/* 157 */     return false;
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 162 */     int prime = 31;
/* 163 */     int result = 1;
/* 164 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 165 */     return result;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 170 */     if (this == obj) {
/* 171 */       return true;
/*     */     }
/* 173 */     if ((obj == null) || (getClass() != obj.getClass())) {
/* 174 */       return false;
/*     */     }
/* 176 */     ArArchiveEntry other = (ArArchiveEntry)obj;
/* 177 */     if (this.name == null) {
/* 178 */       if (other.name != null) {
/* 179 */         return false;
/*     */       }
/* 181 */     } else if (!this.name.equals(other.name)) {
/* 182 */       return false;
/*     */     }
/* 184 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\ar\ArArchiveEntry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */