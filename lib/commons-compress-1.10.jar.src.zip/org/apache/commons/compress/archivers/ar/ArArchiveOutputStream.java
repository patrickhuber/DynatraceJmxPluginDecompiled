/*     */ package org.apache.commons.compress.archivers.ar;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveOutputStream;
/*     */ import org.apache.commons.compress.utils.ArchiveUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArArchiveOutputStream
/*     */   extends ArchiveOutputStream
/*     */ {
/*     */   public static final int LONGFILE_ERROR = 0;
/*     */   public static final int LONGFILE_BSD = 1;
/*     */   private final OutputStream out;
/*  42 */   private long entryOffset = 0L;
/*     */   private ArArchiveEntry prevEntry;
/*  44 */   private boolean haveUnclosedEntry = false;
/*  45 */   private int longFileMode = 0;
/*     */   
/*     */ 
/*  48 */   private boolean finished = false;
/*     */   
/*     */   public ArArchiveOutputStream(OutputStream pOut) {
/*  51 */     this.out = pOut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLongFileMode(int longFileMode)
/*     */   {
/*  63 */     this.longFileMode = longFileMode;
/*     */   }
/*     */   
/*     */   private long writeArchiveHeader() throws IOException {
/*  67 */     byte[] header = ArchiveUtils.toAsciiBytes("!<arch>\n");
/*  68 */     this.out.write(header);
/*  69 */     return header.length;
/*     */   }
/*     */   
/*     */   public void closeArchiveEntry() throws IOException
/*     */   {
/*  74 */     if (this.finished) {
/*  75 */       throw new IOException("Stream has already been finished");
/*     */     }
/*  77 */     if ((this.prevEntry == null) || (!this.haveUnclosedEntry)) {
/*  78 */       throw new IOException("No current entry to close");
/*     */     }
/*  80 */     if (this.entryOffset % 2L != 0L) {
/*  81 */       this.out.write(10);
/*     */     }
/*  83 */     this.haveUnclosedEntry = false;
/*     */   }
/*     */   
/*     */   public void putArchiveEntry(ArchiveEntry pEntry) throws IOException
/*     */   {
/*  88 */     if (this.finished) {
/*  89 */       throw new IOException("Stream has already been finished");
/*     */     }
/*     */     
/*  92 */     ArArchiveEntry pArEntry = (ArArchiveEntry)pEntry;
/*  93 */     if (this.prevEntry == null) {
/*  94 */       writeArchiveHeader();
/*     */     } else {
/*  96 */       if (this.prevEntry.getLength() != this.entryOffset) {
/*  97 */         throw new IOException("length does not match entry (" + this.prevEntry.getLength() + " != " + this.entryOffset);
/*     */       }
/*     */       
/* 100 */       if (this.haveUnclosedEntry) {
/* 101 */         closeArchiveEntry();
/*     */       }
/*     */     }
/*     */     
/* 105 */     this.prevEntry = pArEntry;
/*     */     
/* 107 */     writeEntryHeader(pArEntry);
/*     */     
/* 109 */     this.entryOffset = 0L;
/* 110 */     this.haveUnclosedEntry = true;
/*     */   }
/*     */   
/*     */   private long fill(long pOffset, long pNewOffset, char pFill) throws IOException {
/* 114 */     long diff = pNewOffset - pOffset;
/*     */     
/* 116 */     if (diff > 0L) {
/* 117 */       for (int i = 0; i < diff; i++) {
/* 118 */         write(pFill);
/*     */       }
/*     */     }
/*     */     
/* 122 */     return pNewOffset;
/*     */   }
/*     */   
/*     */   private long write(String data) throws IOException {
/* 126 */     byte[] bytes = data.getBytes("ascii");
/* 127 */     write(bytes);
/* 128 */     return bytes.length;
/*     */   }
/*     */   
/*     */   private long writeEntryHeader(ArArchiveEntry pEntry) throws IOException
/*     */   {
/* 133 */     long offset = 0L;
/* 134 */     boolean mustAppendName = false;
/*     */     
/* 136 */     String n = pEntry.getName();
/* 137 */     if ((0 == this.longFileMode) && (n.length() > 16)) {
/* 138 */       throw new IOException("filename too long, > 16 chars: " + n);
/*     */     }
/* 140 */     if ((1 == this.longFileMode) && ((n.length() > 16) || (n.contains(" "))))
/*     */     {
/* 142 */       mustAppendName = true;
/* 143 */       offset += write("#1/" + String.valueOf(n.length()));
/*     */     }
/*     */     else {
/* 146 */       offset += write(n);
/*     */     }
/*     */     
/* 149 */     offset = fill(offset, 16L, ' ');
/* 150 */     String m = "" + pEntry.getLastModified();
/* 151 */     if (m.length() > 12) {
/* 152 */       throw new IOException("modified too long");
/*     */     }
/* 154 */     offset += write(m);
/*     */     
/* 156 */     offset = fill(offset, 28L, ' ');
/* 157 */     String u = "" + pEntry.getUserId();
/* 158 */     if (u.length() > 6) {
/* 159 */       throw new IOException("userid too long");
/*     */     }
/* 161 */     offset += write(u);
/*     */     
/* 163 */     offset = fill(offset, 34L, ' ');
/* 164 */     String g = "" + pEntry.getGroupId();
/* 165 */     if (g.length() > 6) {
/* 166 */       throw new IOException("groupid too long");
/*     */     }
/* 168 */     offset += write(g);
/*     */     
/* 170 */     offset = fill(offset, 40L, ' ');
/* 171 */     String fm = "" + Integer.toString(pEntry.getMode(), 8);
/* 172 */     if (fm.length() > 8) {
/* 173 */       throw new IOException("filemode too long");
/*     */     }
/* 175 */     offset += write(fm);
/*     */     
/* 177 */     offset = fill(offset, 48L, ' ');
/* 178 */     String s = String.valueOf(pEntry.getLength() + (mustAppendName ? n.length() : 0));
/*     */     
/*     */ 
/* 181 */     if (s.length() > 10) {
/* 182 */       throw new IOException("size too long");
/*     */     }
/* 184 */     offset += write(s);
/*     */     
/* 186 */     offset = fill(offset, 58L, ' ');
/*     */     
/* 188 */     offset += write("`\n");
/*     */     
/* 190 */     if (mustAppendName) {
/* 191 */       offset += write(n);
/*     */     }
/*     */     
/* 194 */     return offset;
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException
/*     */   {
/* 199 */     this.out.write(b, off, len);
/* 200 */     count(len);
/* 201 */     this.entryOffset += len;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 209 */     if (!this.finished) {
/* 210 */       finish();
/*     */     }
/* 212 */     this.out.close();
/* 213 */     this.prevEntry = null;
/*     */   }
/*     */   
/*     */   public ArchiveEntry createArchiveEntry(File inputFile, String entryName)
/*     */     throws IOException
/*     */   {
/* 219 */     if (this.finished) {
/* 220 */       throw new IOException("Stream has already been finished");
/*     */     }
/* 222 */     return new ArArchiveEntry(inputFile, entryName);
/*     */   }
/*     */   
/*     */   public void finish() throws IOException
/*     */   {
/* 227 */     if (this.haveUnclosedEntry)
/* 228 */       throw new IOException("This archive contains unclosed entries.");
/* 229 */     if (this.finished) {
/* 230 */       throw new IOException("This archive has already been finished");
/*     */     }
/* 232 */     this.finished = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\ar\ArArchiveOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */