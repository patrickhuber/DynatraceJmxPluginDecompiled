/*     */ package org.apache.commons.compress.archivers.ar;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*     */ import org.apache.commons.compress.utils.ArchiveUtils;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArArchiveInputStream
/*     */   extends ArchiveInputStream
/*     */ {
/*     */   private final InputStream input;
/*  39 */   private long offset = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean closed;
/*     */   
/*     */ 
/*  46 */   private ArArchiveEntry currentEntry = null;
/*     */   
/*     */ 
/*  49 */   private byte[] namebuffer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  55 */   private long entryOffset = -1L;
/*     */   
/*     */ 
/*  58 */   private final byte[] NAME_BUF = new byte[16];
/*  59 */   private final byte[] LAST_MODIFIED_BUF = new byte[12];
/*  60 */   private final byte[] ID_BUF = new byte[6];
/*  61 */   private final byte[] FILE_MODE_BUF = new byte[8];
/*  62 */   private final byte[] LENGTH_BUF = new byte[10];
/*     */   
/*     */ 
/*     */   static final String BSD_LONGNAME_PREFIX = "#1/";
/*     */   
/*     */ 
/*     */ 
/*     */   public ArArchiveInputStream(InputStream pInput)
/*     */   {
/*  71 */     this.input = pInput;
/*  72 */     this.closed = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArArchiveEntry getNextArEntry()
/*     */     throws IOException
/*     */   {
/*  83 */     if (this.currentEntry != null) {
/*  84 */       long entryEnd = this.entryOffset + this.currentEntry.getLength();
/*  85 */       IOUtils.skip(this, entryEnd - this.offset);
/*  86 */       this.currentEntry = null;
/*     */     }
/*     */     
/*  89 */     if (this.offset == 0L) {
/*  90 */       byte[] expected = ArchiveUtils.toAsciiBytes("!<arch>\n");
/*  91 */       byte[] realized = new byte[expected.length];
/*  92 */       int read = IOUtils.readFully(this, realized);
/*  93 */       if (read != expected.length) {
/*  94 */         throw new IOException("failed to read header. Occured at byte: " + getBytesRead());
/*     */       }
/*  96 */       for (int i = 0; i < expected.length; i++) {
/*  97 */         if (expected[i] != realized[i]) {
/*  98 */           throw new IOException("invalid header " + ArchiveUtils.toAsciiString(realized));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 103 */     if ((this.offset % 2L != 0L) && (read() < 0))
/*     */     {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     if (this.input.available() == 0) {
/* 109 */       return null;
/*     */     }
/*     */     
/* 112 */     IOUtils.readFully(this, this.NAME_BUF);
/* 113 */     IOUtils.readFully(this, this.LAST_MODIFIED_BUF);
/* 114 */     IOUtils.readFully(this, this.ID_BUF);
/* 115 */     int userId = asInt(this.ID_BUF, true);
/* 116 */     IOUtils.readFully(this, this.ID_BUF);
/* 117 */     IOUtils.readFully(this, this.FILE_MODE_BUF);
/* 118 */     IOUtils.readFully(this, this.LENGTH_BUF);
/*     */     
/*     */ 
/* 121 */     byte[] expected = ArchiveUtils.toAsciiBytes("`\n");
/* 122 */     byte[] realized = new byte[expected.length];
/* 123 */     int read = IOUtils.readFully(this, realized);
/* 124 */     if (read != expected.length) {
/* 125 */       throw new IOException("failed to read entry trailer. Occured at byte: " + getBytesRead());
/*     */     }
/* 127 */     for (int i = 0; i < expected.length; i++) {
/* 128 */       if (expected[i] != realized[i]) {
/* 129 */         throw new IOException("invalid entry trailer. not read the content? Occured at byte: " + getBytesRead());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 134 */     this.entryOffset = this.offset;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 139 */     String temp = ArchiveUtils.toAsciiString(this.NAME_BUF).trim();
/* 140 */     if (isGNUStringTable(temp)) {
/* 141 */       this.currentEntry = readGNUStringTable(this.LENGTH_BUF);
/* 142 */       return getNextArEntry();
/*     */     }
/*     */     
/* 145 */     long len = asLong(this.LENGTH_BUF);
/* 146 */     if (temp.endsWith("/")) {
/* 147 */       temp = temp.substring(0, temp.length() - 1);
/* 148 */     } else if (isGNULongName(temp)) {
/* 149 */       int off = Integer.parseInt(temp.substring(1));
/* 150 */       temp = getExtendedName(off);
/* 151 */     } else if (isBSDLongName(temp)) {
/* 152 */       temp = getBSDLongName(temp);
/*     */       
/*     */ 
/*     */ 
/* 156 */       int nameLen = temp.length();
/* 157 */       len -= nameLen;
/* 158 */       this.entryOffset += nameLen;
/*     */     }
/*     */     
/* 161 */     this.currentEntry = new ArArchiveEntry(temp, len, userId, asInt(this.ID_BUF, true), asInt(this.FILE_MODE_BUF, 8), asLong(this.LAST_MODIFIED_BUF));
/*     */     
/*     */ 
/*     */ 
/* 165 */     return this.currentEntry;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getExtendedName(int offset)
/*     */     throws IOException
/*     */   {
/* 176 */     if (this.namebuffer == null) {
/* 177 */       throw new IOException("Cannot process GNU long filename as no // record was found");
/*     */     }
/* 179 */     for (int i = offset; i < this.namebuffer.length; i++) {
/* 180 */       if (this.namebuffer[i] == 10) {
/* 181 */         if (this.namebuffer[(i - 1)] == 47) {
/* 182 */           i--;
/*     */         }
/* 184 */         return ArchiveUtils.toAsciiString(this.namebuffer, offset, i - offset);
/*     */       }
/*     */     }
/* 187 */     throw new IOException("Failed to read entry: " + offset);
/*     */   }
/*     */   
/* 190 */   private long asLong(byte[] input) { return Long.parseLong(ArchiveUtils.toAsciiString(input).trim()); }
/*     */   
/*     */   private int asInt(byte[] input)
/*     */   {
/* 194 */     return asInt(input, 10, false);
/*     */   }
/*     */   
/*     */   private int asInt(byte[] input, boolean treatBlankAsZero) {
/* 198 */     return asInt(input, 10, treatBlankAsZero);
/*     */   }
/*     */   
/*     */   private int asInt(byte[] input, int base) {
/* 202 */     return asInt(input, base, false);
/*     */   }
/*     */   
/*     */   private int asInt(byte[] input, int base, boolean treatBlankAsZero) {
/* 206 */     String string = ArchiveUtils.toAsciiString(input).trim();
/* 207 */     if ((string.length() == 0) && (treatBlankAsZero)) {
/* 208 */       return 0;
/*     */     }
/* 210 */     return Integer.parseInt(string, base);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ArchiveEntry getNextEntry()
/*     */     throws IOException
/*     */   {
/* 221 */     return getNextArEntry();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 231 */     if (!this.closed) {
/* 232 */       this.closed = true;
/* 233 */       this.input.close();
/*     */     }
/* 235 */     this.currentEntry = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 245 */     int toRead = len;
/* 246 */     if (this.currentEntry != null) {
/* 247 */       long entryEnd = this.entryOffset + this.currentEntry.getLength();
/* 248 */       if ((len > 0) && (entryEnd > this.offset)) {
/* 249 */         toRead = (int)Math.min(len, entryEnd - this.offset);
/*     */       } else {
/* 251 */         return -1;
/*     */       }
/*     */     }
/* 254 */     int ret = this.input.read(b, off, toRead);
/* 255 */     count(ret);
/* 256 */     this.offset += (ret > 0 ? ret : 0L);
/* 257 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 273 */     if (length < 8) {
/* 274 */       return false;
/*     */     }
/* 276 */     if (signature[0] != 33) {
/* 277 */       return false;
/*     */     }
/* 279 */     if (signature[1] != 60) {
/* 280 */       return false;
/*     */     }
/* 282 */     if (signature[2] != 97) {
/* 283 */       return false;
/*     */     }
/* 285 */     if (signature[3] != 114) {
/* 286 */       return false;
/*     */     }
/* 288 */     if (signature[4] != 99) {
/* 289 */       return false;
/*     */     }
/* 291 */     if (signature[5] != 104) {
/* 292 */       return false;
/*     */     }
/* 294 */     if (signature[6] != 62) {
/* 295 */       return false;
/*     */     }
/* 297 */     if (signature[7] != 10) {
/* 298 */       return false;
/*     */     }
/*     */     
/* 301 */     return true;
/*     */   }
/*     */   
/*     */ 
/* 305 */   private static final int BSD_LONGNAME_PREFIX_LEN = "#1/".length();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String BSD_LONGNAME_PATTERN = "^#1/\\d+";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String GNU_STRING_TABLE_NAME = "//";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String GNU_LONGNAME_PATTERN = "^/\\d+";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isBSDLongName(String name)
/*     */   {
/* 333 */     return (name != null) && (name.matches("^#1/\\d+"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getBSDLongName(String bsdLongName)
/*     */     throws IOException
/*     */   {
/* 345 */     int nameLen = Integer.parseInt(bsdLongName.substring(BSD_LONGNAME_PREFIX_LEN));
/*     */     
/* 347 */     byte[] name = new byte[nameLen];
/* 348 */     int read = IOUtils.readFully(this.input, name);
/* 349 */     count(read);
/* 350 */     if (read != nameLen) {
/* 351 */       throw new EOFException();
/*     */     }
/* 353 */     return ArchiveUtils.toAsciiString(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isGNUStringTable(String name)
/*     */   {
/* 376 */     return "//".equals(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ArArchiveEntry readGNUStringTable(byte[] length)
/*     */     throws IOException
/*     */   {
/* 385 */     int bufflen = asInt(length);
/* 386 */     this.namebuffer = new byte[bufflen];
/* 387 */     int read = IOUtils.readFully(this, this.namebuffer, 0, bufflen);
/* 388 */     if (read != bufflen) {
/* 389 */       throw new IOException("Failed to read complete // record: expected=" + bufflen + " read=" + read);
/*     */     }
/*     */     
/* 392 */     return new ArArchiveEntry("//", bufflen);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isGNULongName(String name)
/*     */   {
/* 404 */     return (name != null) && (name.matches("^/\\d+"));
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\archivers\ar\ArArchiveInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */