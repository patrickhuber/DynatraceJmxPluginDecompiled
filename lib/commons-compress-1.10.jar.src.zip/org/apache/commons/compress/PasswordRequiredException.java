/*    */ package org.apache.commons.compress;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PasswordRequiredException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1391070005491684483L;
/*    */   
/*    */   public PasswordRequiredException(String name)
/*    */   {
/* 38 */     super("Cannot read encrypted content from " + name + " without a password.");
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\PasswordRequiredException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */