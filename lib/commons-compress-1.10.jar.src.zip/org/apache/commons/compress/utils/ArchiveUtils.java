/*     */ package org.apache.commons.compress.utils;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArchiveUtils
/*     */ {
/*     */   public static String toString(ArchiveEntry entry)
/*     */   {
/*  47 */     StringBuilder sb = new StringBuilder();
/*  48 */     sb.append(entry.isDirectory() ? 'd' : '-');
/*  49 */     String size = Long.toString(entry.getSize());
/*  50 */     sb.append(' ');
/*     */     
/*  52 */     for (int i = 7; i > size.length(); i--) {
/*  53 */       sb.append(' ');
/*     */     }
/*  55 */     sb.append(size);
/*  56 */     sb.append(' ').append(entry.getName());
/*  57 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matchAsciiBuffer(String expected, byte[] buffer, int offset, int length)
/*     */   {
/*     */     byte[] buffer1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  73 */       buffer1 = expected.getBytes("US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/*  75 */       throw new RuntimeException(e);
/*     */     }
/*  77 */     return isEqual(buffer1, 0, buffer1.length, buffer, offset, length, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matchAsciiBuffer(String expected, byte[] buffer)
/*     */   {
/*  88 */     return matchAsciiBuffer(expected, buffer, 0, buffer.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] toAsciiBytes(String inputString)
/*     */   {
/*     */     try
/*     */     {
/* 100 */       return inputString.getBytes("US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 102 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toAsciiString(byte[] inputBytes)
/*     */   {
/*     */     try
/*     */     {
/* 114 */       return new String(inputBytes, "US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 116 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String toAsciiString(byte[] inputBytes, int offset, int length)
/*     */   {
/*     */     try
/*     */     {
/* 130 */       return new String(inputBytes, offset, length, "US-ASCII");
/*     */     } catch (UnsupportedEncodingException e) {
/* 132 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] buffer1, int offset1, int length1, byte[] buffer2, int offset2, int length2, boolean ignoreTrailingNulls)
/*     */   {
/* 152 */     int minLen = length1 < length2 ? length1 : length2;
/* 153 */     for (int i = 0; i < minLen; i++) {
/* 154 */       if (buffer1[(offset1 + i)] != buffer2[(offset2 + i)]) {
/* 155 */         return false;
/*     */       }
/*     */     }
/* 158 */     if (length1 == length2) {
/* 159 */       return true;
/*     */     }
/* 161 */     if (ignoreTrailingNulls) {
/* 162 */       if (length1 > length2) {
/* 163 */         for (int i = length2; i < length1; i++) {
/* 164 */           if (buffer1[(offset1 + i)] != 0) {
/* 165 */             return false;
/*     */           }
/*     */         }
/*     */       } else {
/* 169 */         for (int i = length1; i < length2; i++) {
/* 170 */           if (buffer2[(offset2 + i)] != 0) {
/* 171 */             return false;
/*     */           }
/*     */         }
/*     */       }
/* 175 */       return true;
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] buffer1, int offset1, int length1, byte[] buffer2, int offset2, int length2)
/*     */   {
/* 194 */     return isEqual(buffer1, offset1, length1, buffer2, offset2, length2, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] buffer1, byte[] buffer2)
/*     */   {
/* 205 */     return isEqual(buffer1, 0, buffer1.length, buffer2, 0, buffer2.length, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqual(byte[] buffer1, byte[] buffer2, boolean ignoreTrailingNulls)
/*     */   {
/* 217 */     return isEqual(buffer1, 0, buffer1.length, buffer2, 0, buffer2.length, ignoreTrailingNulls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isEqualWithNull(byte[] buffer1, int offset1, int length1, byte[] buffer2, int offset2, int length2)
/*     */   {
/* 234 */     return isEqual(buffer1, offset1, length1, buffer2, offset2, length2, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isArrayZero(byte[] a, int size)
/*     */   {
/* 247 */     for (int i = 0; i < size; i++) {
/* 248 */       if (a[i] != 0) {
/* 249 */         return false;
/*     */       }
/*     */     }
/* 252 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\utils\ArchiveUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */