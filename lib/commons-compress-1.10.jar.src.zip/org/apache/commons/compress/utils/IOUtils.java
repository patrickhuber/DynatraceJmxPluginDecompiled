/*     */ package org.apache.commons.compress.utils;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IOUtils
/*     */ {
/*     */   private static final int COPY_BUF_SIZE = 8024;
/*     */   private static final int SKIP_BUF_SIZE = 4096;
/*  38 */   private static final byte[] SKIP_BUF = new byte['က'];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long copy(InputStream input, OutputStream output)
/*     */     throws IOException
/*     */   {
/*  57 */     return copy(input, output, 8024);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long copy(InputStream input, OutputStream output, int buffersize)
/*     */     throws IOException
/*     */   {
/*  74 */     byte[] buffer = new byte[buffersize];
/*  75 */     int n = 0;
/*  76 */     long count = 0L;
/*  77 */     while (-1 != (n = input.read(buffer))) {
/*  78 */       output.write(buffer, 0, n);
/*  79 */       count += n;
/*     */     }
/*  81 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long skip(InputStream input, long numToSkip)
/*     */     throws IOException
/*     */   {
/* 101 */     long available = numToSkip;
/* 102 */     while (numToSkip > 0L) {
/* 103 */       long skipped = input.skip(numToSkip);
/* 104 */       if (skipped == 0L) {
/*     */         break;
/*     */       }
/* 107 */       numToSkip -= skipped;
/*     */     }
/*     */     
/* 110 */     while (numToSkip > 0L) {
/* 111 */       int read = readFully(input, SKIP_BUF, 0, (int)Math.min(numToSkip, 4096L));
/*     */       
/* 113 */       if (read < 1) {
/*     */         break;
/*     */       }
/* 116 */       numToSkip -= read;
/*     */     }
/* 118 */     return available - numToSkip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int readFully(InputStream input, byte[] b)
/*     */     throws IOException
/*     */   {
/* 134 */     return readFully(input, b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int readFully(InputStream input, byte[] b, int offset, int len)
/*     */     throws IOException
/*     */   {
/* 155 */     if ((len < 0) || (offset < 0) || (len + offset > b.length)) {
/* 156 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 158 */     int count = 0;int x = 0;
/* 159 */     while (count != len) {
/* 160 */       x = input.read(b, offset + count, len - count);
/* 161 */       if (x == -1) {
/*     */         break;
/*     */       }
/* 164 */       count += x;
/*     */     }
/* 166 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] toByteArray(InputStream input)
/*     */     throws IOException
/*     */   {
/* 188 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 189 */     copy(input, output);
/* 190 */     return output.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void closeQuietly(Closeable c)
/*     */   {
/* 199 */     if (c != null) {
/*     */       try {
/* 201 */         c.close();
/*     */       }
/*     */       catch (IOException ignored) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\utils\IOUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */