/*    */ package org.apache.commons.compress.utils;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.util.zip.CRC32;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CRC32VerifyingInputStream
/*    */   extends ChecksumVerifyingInputStream
/*    */ {
/*    */   public CRC32VerifyingInputStream(InputStream in, long size, int expectedCrc32)
/*    */   {
/* 37 */     this(in, size, expectedCrc32 & 0xFFFFFFFF);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CRC32VerifyingInputStream(InputStream in, long size, long expectedCrc32)
/*    */   {
/* 47 */     super(new CRC32(), in, size, expectedCrc32);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\utils\CRC32VerifyingInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */