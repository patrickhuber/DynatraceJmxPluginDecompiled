/*     */ package org.apache.commons.compress.utils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.Checksum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChecksumVerifyingInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final InputStream in;
/*     */   private long bytesRemaining;
/*     */   private final long expectedChecksum;
/*     */   private final Checksum checksum;
/*     */   
/*     */   public ChecksumVerifyingInputStream(Checksum checksum, InputStream in, long size, long expectedChecksum)
/*     */   {
/*  38 */     this.checksum = checksum;
/*  39 */     this.in = in;
/*  40 */     this.expectedChecksum = expectedChecksum;
/*  41 */     this.bytesRemaining = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  52 */     if (this.bytesRemaining <= 0L) {
/*  53 */       return -1;
/*     */     }
/*  55 */     int ret = this.in.read();
/*  56 */     if (ret >= 0) {
/*  57 */       this.checksum.update(ret);
/*  58 */       this.bytesRemaining -= 1L;
/*     */     }
/*  60 */     if ((this.bytesRemaining == 0L) && (this.expectedChecksum != this.checksum.getValue())) {
/*  61 */       throw new IOException("Checksum verification failed");
/*     */     }
/*  63 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/*  74 */     return read(b, 0, b.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  85 */     int ret = this.in.read(b, off, len);
/*  86 */     if (ret >= 0) {
/*  87 */       this.checksum.update(b, off, ret);
/*  88 */       this.bytesRemaining -= ret;
/*     */     }
/*  90 */     if ((this.bytesRemaining <= 0L) && (this.expectedChecksum != this.checksum.getValue())) {
/*  91 */       throw new IOException("Checksum verification failed");
/*     */     }
/*  93 */     return ret;
/*     */   }
/*     */   
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/*  99 */     if (read() >= 0) {
/* 100 */       return 1L;
/*     */     }
/* 102 */     return 0L;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 108 */     this.in.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\utils\ChecksumVerifyingInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */