/*    */ package org.apache.commons.compress.utils;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoundedInputStream
/*    */   extends InputStream
/*    */ {
/*    */   private final InputStream in;
/*    */   private long bytesRemaining;
/*    */   
/*    */   public BoundedInputStream(InputStream in, long size)
/*    */   {
/* 39 */     this.in = in;
/* 40 */     this.bytesRemaining = size;
/*    */   }
/*    */   
/*    */   public int read() throws IOException
/*    */   {
/* 45 */     if (this.bytesRemaining > 0L) {
/* 46 */       this.bytesRemaining -= 1L;
/* 47 */       return this.in.read();
/*    */     }
/* 49 */     return -1;
/*    */   }
/*    */   
/*    */   public int read(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 55 */     if (this.bytesRemaining == 0L) {
/* 56 */       return -1;
/*    */     }
/* 58 */     int bytesToRead = len;
/* 59 */     if (bytesToRead > this.bytesRemaining) {
/* 60 */       bytesToRead = (int)this.bytesRemaining;
/*    */     }
/* 62 */     int bytesRead = this.in.read(b, off, bytesToRead);
/* 63 */     if (bytesRead >= 0) {
/* 64 */       this.bytesRemaining -= bytesRead;
/*    */     }
/* 66 */     return bytesRead;
/*    */   }
/*    */   
/*    */   public void close() {}
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\utils\BoundedInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */