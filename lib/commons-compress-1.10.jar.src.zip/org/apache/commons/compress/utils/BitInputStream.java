/*     */ package org.apache.commons.compress.utils;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteOrder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BitInputStream
/*     */   implements Closeable
/*     */ {
/*     */   private static final int MAXIMUM_CACHE_SIZE = 63;
/*  33 */   private static final long[] MASKS = new long[64];
/*     */   private final InputStream in;
/*     */   
/*  36 */   static { for (int i = 1; i <= 63; i++) {
/*  37 */       MASKS[i] = ((MASKS[(i - 1)] << 1) + 1L);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private final ByteOrder byteOrder;
/*  43 */   private long bitsCached = 0L;
/*  44 */   private int bitsCachedSize = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BitInputStream(InputStream in, ByteOrder byteOrder)
/*     */   {
/*  53 */     this.in = in;
/*  54 */     this.byteOrder = byteOrder;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  58 */     this.in.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearBitCache()
/*     */   {
/*  66 */     this.bitsCached = 0L;
/*  67 */     this.bitsCachedSize = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long readBits(int count)
/*     */     throws IOException
/*     */   {
/*  81 */     if ((count < 0) || (count > 63)) {
/*  82 */       throw new IllegalArgumentException("count must not be negative or greater than 63");
/*     */     }
/*  84 */     while (this.bitsCachedSize < count) {
/*  85 */       long nextByte = this.in.read();
/*  86 */       if (nextByte < 0L) {
/*  87 */         return nextByte;
/*     */       }
/*  89 */       if (this.byteOrder == ByteOrder.LITTLE_ENDIAN) {
/*  90 */         this.bitsCached |= nextByte << this.bitsCachedSize;
/*     */       } else {
/*  92 */         this.bitsCached <<= 8;
/*  93 */         this.bitsCached |= nextByte;
/*     */       }
/*  95 */       this.bitsCachedSize += 8;
/*     */     }
/*     */     
/*     */     long bitsOut;
/*  99 */     if (this.byteOrder == ByteOrder.LITTLE_ENDIAN) {
/* 100 */       long bitsOut = this.bitsCached & MASKS[count];
/* 101 */       this.bitsCached >>>= count;
/*     */     } else {
/* 103 */       bitsOut = this.bitsCached >> this.bitsCachedSize - count & MASKS[count];
/*     */     }
/* 105 */     this.bitsCachedSize -= count;
/* 106 */     return bitsOut;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\utils\BitInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */