/*     */ package org.apache.commons.compress.compressors.xz;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.compress.compressors.FileNameUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XZUtils
/*     */ {
/*     */   private static final FileNameUtil fileNameUtil;
/*  40 */   private static final byte[] HEADER_MAGIC = { -3, 55, 122, 88, 90, 0 };
/*     */   private static volatile CachedAvailability cachedXZAvailability;
/*     */   
/*     */   static enum CachedAvailability
/*     */   {
/*  45 */     DONT_CACHE,  CACHED_AVAILABLE,  CACHED_UNAVAILABLE;
/*     */     
/*     */     private CachedAvailability() {}
/*     */   }
/*     */   
/*     */   static {
/*  51 */     Map<String, String> uncompressSuffix = new HashMap();
/*  52 */     uncompressSuffix.put(".txz", ".tar");
/*  53 */     uncompressSuffix.put(".xz", "");
/*  54 */     uncompressSuffix.put("-xz", "");
/*  55 */     fileNameUtil = new FileNameUtil(uncompressSuffix, ".xz");
/*  56 */     cachedXZAvailability = CachedAvailability.DONT_CACHE;
/*     */     try {
/*  58 */       Class.forName("org.osgi.framework.BundleEvent");
/*     */     } catch (Exception ex) {
/*  60 */       setCacheXZAvailablity(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/*  81 */     if (length < HEADER_MAGIC.length) {
/*  82 */       return false;
/*     */     }
/*     */     
/*  85 */     for (int i = 0; i < HEADER_MAGIC.length; i++) {
/*  86 */       if (signature[i] != HEADER_MAGIC[i]) {
/*  87 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  91 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isXZCompressionAvailable()
/*     */   {
/* 100 */     CachedAvailability cachedResult = cachedXZAvailability;
/* 101 */     if (cachedResult != CachedAvailability.DONT_CACHE) {
/* 102 */       return cachedResult == CachedAvailability.CACHED_AVAILABLE;
/*     */     }
/* 104 */     return internalIsXZCompressionAvailable();
/*     */   }
/*     */   
/*     */   private static boolean internalIsXZCompressionAvailable() {
/*     */     try {
/* 109 */       XZCompressorInputStream.matches(null, 0);
/* 110 */       return true;
/*     */     } catch (NoClassDefFoundError error) {}
/* 112 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isCompressedFilename(String filename)
/*     */   {
/* 124 */     return fileNameUtil.isCompressedFilename(filename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUncompressedFilename(String filename)
/*     */   {
/* 141 */     return fileNameUtil.getUncompressedFilename(filename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCompressedFilename(String filename)
/*     */   {
/* 156 */     return fileNameUtil.getCompressedFilename(filename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCacheXZAvailablity(boolean doCache)
/*     */   {
/* 167 */     if (!doCache) {
/* 168 */       cachedXZAvailability = CachedAvailability.DONT_CACHE;
/* 169 */     } else if (cachedXZAvailability == CachedAvailability.DONT_CACHE) {
/* 170 */       boolean hasXz = internalIsXZCompressionAvailable();
/* 171 */       cachedXZAvailability = hasXz ? CachedAvailability.CACHED_AVAILABLE : CachedAvailability.CACHED_UNAVAILABLE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static CachedAvailability getCachedXZAvailability()
/*     */   {
/* 178 */     return cachedXZAvailability;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\xz\XZUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */