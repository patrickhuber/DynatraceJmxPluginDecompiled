/*     */ package org.apache.commons.compress.compressors.gzip;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GzipCompressorInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   private static final int FHCRC = 2;
/*     */   private static final int FEXTRA = 4;
/*     */   private static final int FNAME = 8;
/*     */   private static final int FCOMMENT = 16;
/*     */   private static final int FRESERVED = 224;
/*     */   private final InputStream in;
/*     */   private final boolean decompressConcatenated;
/*  66 */   private final byte[] buf = new byte[' '];
/*     */   
/*     */ 
/*  69 */   private int bufUsed = 0;
/*     */   
/*     */ 
/*  72 */   private Inflater inf = new Inflater(true);
/*     */   
/*     */ 
/*  75 */   private final CRC32 crc = new CRC32();
/*     */   
/*     */ 
/*  78 */   private boolean endReached = false;
/*     */   
/*     */ 
/*  81 */   private final byte[] oneByte = new byte[1];
/*     */   
/*  83 */   private final GzipParameters parameters = new GzipParameters();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GzipCompressorInputStream(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 100 */     this(inputStream, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GzipCompressorInputStream(InputStream inputStream, boolean decompressConcatenated)
/*     */     throws IOException
/*     */   {
/* 128 */     if (inputStream.markSupported()) {
/* 129 */       this.in = inputStream;
/*     */     } else {
/* 131 */       this.in = new BufferedInputStream(inputStream);
/*     */     }
/*     */     
/* 134 */     this.decompressConcatenated = decompressConcatenated;
/* 135 */     init(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GzipParameters getMetaData()
/*     */   {
/* 145 */     return this.parameters;
/*     */   }
/*     */   
/*     */   private boolean init(boolean isFirstMember) throws IOException {
/* 149 */     assert ((isFirstMember) || (this.decompressConcatenated));
/*     */     
/*     */ 
/* 152 */     int magic0 = this.in.read();
/* 153 */     int magic1 = this.in.read();
/*     */     
/*     */ 
/*     */ 
/* 157 */     if ((magic0 == -1) && (!isFirstMember)) {
/* 158 */       return false;
/*     */     }
/*     */     
/* 161 */     if ((magic0 != 31) || (magic1 != 139)) {
/* 162 */       throw new IOException(isFirstMember ? "Input is not in the .gz format" : "Garbage after a valid .gz stream");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 168 */     DataInputStream inData = new DataInputStream(this.in);
/* 169 */     int method = inData.readUnsignedByte();
/* 170 */     if (method != 8) {
/* 171 */       throw new IOException("Unsupported compression method " + method + " in the .gz header");
/*     */     }
/*     */     
/*     */ 
/* 175 */     int flg = inData.readUnsignedByte();
/* 176 */     if ((flg & 0xE0) != 0) {
/* 177 */       throw new IOException("Reserved flags are set in the .gz header");
/*     */     }
/*     */     
/*     */ 
/* 181 */     this.parameters.setModificationTime(readLittleEndianInt(inData) * 1000L);
/* 182 */     switch (inData.readUnsignedByte()) {
/*     */     case 2: 
/* 184 */       this.parameters.setCompressionLevel(9);
/* 185 */       break;
/*     */     case 4: 
/* 187 */       this.parameters.setCompressionLevel(1);
/* 188 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 193 */     this.parameters.setOperatingSystem(inData.readUnsignedByte());
/*     */     
/*     */ 
/* 196 */     if ((flg & 0x4) != 0) {
/* 197 */       int xlen = inData.readUnsignedByte();
/* 198 */       xlen |= inData.readUnsignedByte() << 8;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 203 */       while (xlen-- > 0) {
/* 204 */         inData.readUnsignedByte();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 209 */     if ((flg & 0x8) != 0) {
/* 210 */       this.parameters.setFilename(new String(readToNull(inData), "ISO-8859-1"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 215 */     if ((flg & 0x10) != 0) {
/* 216 */       this.parameters.setComment(new String(readToNull(inData), "ISO-8859-1"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */     if ((flg & 0x2) != 0) {
/* 226 */       inData.readShort();
/*     */     }
/*     */     
/*     */ 
/* 230 */     this.inf.reset();
/* 231 */     this.crc.reset();
/*     */     
/* 233 */     return true;
/*     */   }
/*     */   
/*     */   private byte[] readToNull(DataInputStream inData) throws IOException {
/* 237 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 238 */     int b = 0;
/* 239 */     while ((b = inData.readUnsignedByte()) != 0) {
/* 240 */       bos.write(b);
/*     */     }
/* 242 */     return bos.toByteArray();
/*     */   }
/*     */   
/*     */   private long readLittleEndianInt(DataInputStream inData) throws IOException {
/* 246 */     return inData.readUnsignedByte() | inData.readUnsignedByte() << 8 | inData.readUnsignedByte() << 16 | inData.readUnsignedByte() << 24;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 254 */     return read(this.oneByte, 0, 1) == -1 ? -1 : this.oneByte[0] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 264 */     if (this.endReached) {
/* 265 */       return -1;
/*     */     }
/*     */     
/* 268 */     int size = 0;
/*     */     
/* 270 */     while (len > 0) {
/* 271 */       if (this.inf.needsInput())
/*     */       {
/*     */ 
/* 274 */         this.in.mark(this.buf.length);
/*     */         
/* 276 */         this.bufUsed = this.in.read(this.buf);
/* 277 */         if (this.bufUsed == -1) {
/* 278 */           throw new EOFException();
/*     */         }
/*     */         
/* 281 */         this.inf.setInput(this.buf, 0, this.bufUsed);
/*     */       }
/*     */       int ret;
/*     */       try
/*     */       {
/* 286 */         ret = this.inf.inflate(b, off, len);
/*     */       } catch (DataFormatException e) {
/* 288 */         throw new IOException("Gzip-compressed data is corrupt");
/*     */       }
/*     */       
/* 291 */       this.crc.update(b, off, ret);
/* 292 */       off += ret;
/* 293 */       len -= ret;
/* 294 */       size += ret;
/* 295 */       count(ret);
/*     */       
/* 297 */       if (this.inf.finished())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 303 */         this.in.reset();
/*     */         
/* 305 */         int skipAmount = this.bufUsed - this.inf.getRemaining();
/* 306 */         if (this.in.skip(skipAmount) != skipAmount) {
/* 307 */           throw new IOException();
/*     */         }
/*     */         
/* 310 */         this.bufUsed = 0;
/*     */         
/* 312 */         DataInputStream inData = new DataInputStream(this.in);
/*     */         
/*     */ 
/* 315 */         long crcStored = readLittleEndianInt(inData);
/*     */         
/* 317 */         if (crcStored != this.crc.getValue()) {
/* 318 */           throw new IOException("Gzip-compressed data is corrupt (CRC32 error)");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 323 */         long isize = readLittleEndianInt(inData);
/*     */         
/* 325 */         if (isize != (this.inf.getBytesWritten() & 0xFFFFFFFF)) {
/* 326 */           throw new IOException("Gzip-compressed data is corrupt(uncompressed size mismatch)");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 331 */         if ((!this.decompressConcatenated) || (!init(false))) {
/* 332 */           this.inf.end();
/* 333 */           this.inf = null;
/* 334 */           this.endReached = true;
/* 335 */           return size == 0 ? -1 : size;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 340 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 354 */     if (length < 2) {
/* 355 */       return false;
/*     */     }
/*     */     
/* 358 */     if (signature[0] != 31) {
/* 359 */       return false;
/*     */     }
/*     */     
/* 362 */     if (signature[1] != -117) {
/* 363 */       return false;
/*     */     }
/*     */     
/* 366 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 376 */     if (this.inf != null) {
/* 377 */       this.inf.end();
/* 378 */       this.inf = null;
/*     */     }
/*     */     
/* 381 */     if (this.in != System.in) {
/* 382 */       this.in.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\gzip\GzipCompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */