/*     */ package org.apache.commons.compress.compressors.gzip;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GzipParameters
/*     */ {
/*  31 */   private int compressionLevel = -1;
/*     */   private long modificationTime;
/*     */   private String filename;
/*     */   private String comment;
/*  35 */   private int operatingSystem = 255;
/*     */   
/*     */   public int getCompressionLevel() {
/*  38 */     return this.compressionLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompressionLevel(int compressionLevel)
/*     */   {
/*  51 */     if ((compressionLevel < -1) || (compressionLevel > 9)) {
/*  52 */       throw new IllegalArgumentException("Invalid gzip compression level: " + compressionLevel);
/*     */     }
/*  54 */     this.compressionLevel = compressionLevel;
/*     */   }
/*     */   
/*     */   public long getModificationTime() {
/*  58 */     return this.modificationTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModificationTime(long modificationTime)
/*     */   {
/*  67 */     this.modificationTime = modificationTime;
/*     */   }
/*     */   
/*     */   public String getFilename() {
/*  71 */     return this.filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilename(String filename)
/*     */   {
/*  80 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getComment() {
/*  84 */     return this.comment;
/*     */   }
/*     */   
/*     */   public void setComment(String comment) {
/*  88 */     this.comment = comment;
/*     */   }
/*     */   
/*     */   public int getOperatingSystem() {
/*  92 */     return this.operatingSystem;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOperatingSystem(int operatingSystem)
/*     */   {
/* 119 */     this.operatingSystem = operatingSystem;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\gzip\GzipParameters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */