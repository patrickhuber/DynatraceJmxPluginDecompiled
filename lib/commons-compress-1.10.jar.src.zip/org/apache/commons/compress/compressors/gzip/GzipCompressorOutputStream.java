/*     */ package org.apache.commons.compress.compressors.gzip;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Deflater;
/*     */ import org.apache.commons.compress.compressors.CompressorOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GzipCompressorOutputStream
/*     */   extends CompressorOutputStream
/*     */ {
/*     */   private static final int FNAME = 8;
/*     */   private static final int FCOMMENT = 16;
/*     */   private final OutputStream out;
/*     */   private final Deflater deflater;
/*  56 */   private final byte[] deflateBuffer = new byte['Ȁ'];
/*     */   
/*     */ 
/*     */   private boolean closed;
/*     */   
/*     */ 
/*  62 */   private final CRC32 crc = new CRC32();
/*     */   
/*     */ 
/*     */   public GzipCompressorOutputStream(OutputStream out)
/*     */     throws IOException
/*     */   {
/*  68 */     this(out, new GzipParameters());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public GzipCompressorOutputStream(OutputStream out, GzipParameters parameters)
/*     */     throws IOException
/*     */   {
/*  77 */     this.out = out;
/*  78 */     this.deflater = new Deflater(parameters.getCompressionLevel(), true);
/*     */     
/*  80 */     writeHeader(parameters);
/*     */   }
/*     */   
/*     */   private void writeHeader(GzipParameters parameters) throws IOException {
/*  84 */     String filename = parameters.getFilename();
/*  85 */     String comment = parameters.getComment();
/*     */     
/*  87 */     ByteBuffer buffer = ByteBuffer.allocate(10);
/*  88 */     buffer.order(ByteOrder.LITTLE_ENDIAN);
/*  89 */     buffer.putShort((short)35615);
/*  90 */     buffer.put((byte)8);
/*  91 */     buffer.put((byte)((filename != null ? 8 : 0) | (comment != null ? 16 : 0)));
/*  92 */     buffer.putInt((int)(parameters.getModificationTime() / 1000L));
/*     */     
/*     */ 
/*  95 */     int compressionLevel = parameters.getCompressionLevel();
/*  96 */     if (compressionLevel == 9) {
/*  97 */       buffer.put((byte)2);
/*  98 */     } else if (compressionLevel == 1) {
/*  99 */       buffer.put((byte)4);
/*     */     } else {
/* 101 */       buffer.put((byte)0);
/*     */     }
/*     */     
/* 104 */     buffer.put((byte)parameters.getOperatingSystem());
/*     */     
/* 106 */     this.out.write(buffer.array());
/*     */     
/* 108 */     if (filename != null) {
/* 109 */       this.out.write(filename.getBytes("ISO-8859-1"));
/* 110 */       this.out.write(0);
/*     */     }
/*     */     
/* 113 */     if (comment != null) {
/* 114 */       this.out.write(comment.getBytes("ISO-8859-1"));
/* 115 */       this.out.write(0);
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeTrailer() throws IOException {
/* 120 */     ByteBuffer buffer = ByteBuffer.allocate(8);
/* 121 */     buffer.order(ByteOrder.LITTLE_ENDIAN);
/* 122 */     buffer.putInt((int)this.crc.getValue());
/* 123 */     buffer.putInt(this.deflater.getTotalIn());
/*     */     
/* 125 */     this.out.write(buffer.array());
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException
/*     */   {
/* 130 */     write(new byte[] { (byte)(b & 0xFF) }, 0, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] buffer)
/*     */     throws IOException
/*     */   {
/* 140 */     write(buffer, 0, buffer.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 150 */     if (this.deflater.finished()) {
/* 151 */       throw new IOException("Cannot write more data, the end of the compressed data stream has been reached");
/*     */     }
/* 153 */     if (length > 0) {
/* 154 */       this.deflater.setInput(buffer, offset, length);
/*     */       
/* 156 */       while (!this.deflater.needsInput()) {
/* 157 */         deflate();
/*     */       }
/*     */       
/* 160 */       this.crc.update(buffer, offset, length);
/*     */     }
/*     */   }
/*     */   
/*     */   private void deflate() throws IOException {
/* 165 */     int length = this.deflater.deflate(this.deflateBuffer, 0, this.deflateBuffer.length);
/* 166 */     if (length > 0) {
/* 167 */       this.out.write(this.deflateBuffer, 0, length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finish()
/*     */     throws IOException
/*     */   {
/* 177 */     if (!this.deflater.finished()) {
/* 178 */       this.deflater.finish();
/*     */       
/* 180 */       while (!this.deflater.finished()) {
/* 181 */         deflate();
/*     */       }
/*     */       
/* 184 */       writeTrailer();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 195 */     this.out.flush();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 200 */     if (!this.closed) {
/* 201 */       finish();
/* 202 */       this.deflater.end();
/* 203 */       this.out.close();
/* 204 */       this.closed = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\gzip\GzipCompressorOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */