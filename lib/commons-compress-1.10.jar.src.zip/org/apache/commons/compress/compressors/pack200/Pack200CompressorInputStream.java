/*     */ package org.apache.commons.compress.compressors.pack200;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.jar.JarOutputStream;
/*     */ import java.util.jar.Pack200;
/*     */ import java.util.jar.Pack200.Unpacker;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pack200CompressorInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   private final InputStream originalInput;
/*     */   private final StreamBridge streamBridge;
/*     */   
/*     */   public Pack200CompressorInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/*  58 */     this(in, Pack200Strategy.IN_MEMORY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(InputStream in, Pack200Strategy mode)
/*     */     throws IOException
/*     */   {
/*  74 */     this(in, null, mode, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(InputStream in, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/*  90 */     this(in, Pack200Strategy.IN_MEMORY, props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(InputStream in, Pack200Strategy mode, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/* 108 */     this(in, null, mode, props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(File f)
/*     */     throws IOException
/*     */   {
/* 118 */     this(f, Pack200Strategy.IN_MEMORY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(File f, Pack200Strategy mode)
/*     */     throws IOException
/*     */   {
/* 130 */     this(null, f, mode, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(File f, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/* 143 */     this(f, Pack200Strategy.IN_MEMORY, props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorInputStream(File f, Pack200Strategy mode, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/* 157 */     this(null, f, mode, props);
/*     */   }
/*     */   
/*     */ 
/*     */   private Pack200CompressorInputStream(InputStream in, File f, Pack200Strategy mode, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/* 164 */     this.originalInput = in;
/* 165 */     this.streamBridge = mode.newStreamBridge();
/* 166 */     JarOutputStream jarOut = new JarOutputStream(this.streamBridge);
/* 167 */     Pack200.Unpacker u = Pack200.newUnpacker();
/* 168 */     if (props != null) {
/* 169 */       u.properties().putAll(props);
/*     */     }
/* 171 */     if (f == null) {
/* 172 */       u.unpack(new FilterInputStream(in) { public void close() {} }, jarOut);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/* 181 */       u.unpack(f, jarOut);
/*     */     }
/* 183 */     jarOut.close();
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 188 */     return this.streamBridge.getInput().read();
/*     */   }
/*     */   
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/* 193 */     return this.streamBridge.getInput().read(b);
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int count) throws IOException
/*     */   {
/* 198 */     return this.streamBridge.getInput().read(b, off, count);
/*     */   }
/*     */   
/*     */   public int available() throws IOException
/*     */   {
/* 203 */     return this.streamBridge.getInput().available();
/*     */   }
/*     */   
/*     */   public boolean markSupported()
/*     */   {
/*     */     try {
/* 209 */       return this.streamBridge.getInput().markSupported();
/*     */     } catch (IOException ex) {}
/* 211 */     return false;
/*     */   }
/*     */   
/*     */   public void mark(int limit)
/*     */   {
/*     */     try
/*     */     {
/* 218 */       this.streamBridge.getInput().mark(limit);
/*     */     } catch (IOException ex) {
/* 220 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */   
/*     */   public void reset() throws IOException
/*     */   {
/* 226 */     this.streamBridge.getInput().reset();
/*     */   }
/*     */   
/*     */   public long skip(long count) throws IOException
/*     */   {
/* 231 */     return this.streamBridge.getInput().skip(count);
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*     */     try {
/* 237 */       this.streamBridge.stop();
/*     */     } finally {
/* 239 */       if (this.originalInput != null) {
/* 240 */         this.originalInput.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 245 */   private static final byte[] CAFE_DOOD = { -54, -2, -48, 13 };
/*     */   
/*     */ 
/* 248 */   private static final int SIG_LENGTH = CAFE_DOOD.length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 262 */     if (length < SIG_LENGTH) {
/* 263 */       return false;
/*     */     }
/*     */     
/* 266 */     for (int i = 0; i < SIG_LENGTH; i++) {
/* 267 */       if (signature[i] != CAFE_DOOD[i]) {
/* 268 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 272 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\pack200\Pack200CompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */