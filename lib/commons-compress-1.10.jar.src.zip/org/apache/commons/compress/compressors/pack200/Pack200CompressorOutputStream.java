/*     */ package org.apache.commons.compress.compressors.pack200;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.Pack200;
/*     */ import java.util.jar.Pack200.Packer;
/*     */ import org.apache.commons.compress.compressors.CompressorOutputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pack200CompressorOutputStream
/*     */   extends CompressorOutputStream
/*     */ {
/*  38 */   private boolean finished = false;
/*     */   
/*     */ 
/*     */   private final OutputStream originalOutput;
/*     */   
/*     */   private final StreamBridge streamBridge;
/*     */   
/*     */   private final Map<String, String> properties;
/*     */   
/*     */ 
/*     */   public Pack200CompressorOutputStream(OutputStream out)
/*     */     throws IOException
/*     */   {
/*  51 */     this(out, Pack200Strategy.IN_MEMORY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorOutputStream(OutputStream out, Pack200Strategy mode)
/*     */     throws IOException
/*     */   {
/*  64 */     this(out, mode, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorOutputStream(OutputStream out, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/*  77 */     this(out, Pack200Strategy.IN_MEMORY, props);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pack200CompressorOutputStream(OutputStream out, Pack200Strategy mode, Map<String, String> props)
/*     */     throws IOException
/*     */   {
/*  92 */     this.originalOutput = out;
/*  93 */     this.streamBridge = mode.newStreamBridge();
/*  94 */     this.properties = props;
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException
/*     */   {
/*  99 */     this.streamBridge.write(b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b) throws IOException
/*     */   {
/* 104 */     this.streamBridge.write(b);
/*     */   }
/*     */   
/*     */   public void write(byte[] b, int from, int length) throws IOException
/*     */   {
/* 109 */     this.streamBridge.write(b, from, length);
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 114 */     finish();
/*     */     try {
/* 116 */       this.streamBridge.stop();
/*     */     } finally {
/* 118 */       this.originalOutput.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void finish() throws IOException {
/* 123 */     if (!this.finished) {
/* 124 */       this.finished = true;
/* 125 */       Pack200.Packer p = Pack200.newPacker();
/* 126 */       if (this.properties != null) {
/* 127 */         p.properties().putAll(this.properties);
/*     */       }
/* 129 */       JarInputStream ji = null;
/* 130 */       boolean success = false;
/*     */       try {
/* 132 */         p.pack(ji = new JarInputStream(this.streamBridge.getInput()), this.originalOutput);
/*     */         
/* 134 */         success = true;
/*     */       } finally {
/* 136 */         if (!success) {
/* 137 */           IOUtils.closeQuietly(ji);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\pack200\Pack200CompressorOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */