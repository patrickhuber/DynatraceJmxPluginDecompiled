/*    */ package org.apache.commons.compress.compressors.pack200;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TempFileCachingStreamBridge
/*    */   extends StreamBridge
/*    */ {
/*    */   private final File f;
/*    */   
/*    */   TempFileCachingStreamBridge()
/*    */     throws IOException
/*    */   {
/* 37 */     this.f = File.createTempFile("commons-compress", "packtemp");
/* 38 */     this.f.deleteOnExit();
/* 39 */     this.out = new FileOutputStream(this.f);
/*    */   }
/*    */   
/*    */   InputStream getInputView() throws IOException
/*    */   {
/* 44 */     this.out.close();
/* 45 */     new FileInputStream(this.f)
/*    */     {
/*    */       public void close() throws IOException {
/* 48 */         super.close();
/* 49 */         TempFileCachingStreamBridge.this.f.delete();
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\pack200\TempFileCachingStreamBridge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */