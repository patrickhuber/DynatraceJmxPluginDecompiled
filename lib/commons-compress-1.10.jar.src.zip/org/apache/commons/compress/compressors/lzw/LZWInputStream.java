/*     */ package org.apache.commons.compress.compressors.lzw;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteOrder;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ import org.apache.commons.compress.utils.BitInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LZWInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   protected static final int DEFAULT_CODE_SIZE = 9;
/*     */   protected static final int UNUSED_PREFIX = -1;
/*  40 */   private final byte[] oneByte = new byte[1];
/*     */   
/*     */   protected final BitInputStream in;
/*  43 */   private int clearCode = -1;
/*  44 */   private int codeSize = 9;
/*     */   private byte previousCodeFirstChar;
/*  46 */   private int previousCode = -1;
/*     */   private int tableSize;
/*     */   private int[] prefixes;
/*     */   private byte[] characters;
/*     */   private byte[] outputStack;
/*     */   private int outputStackLocation;
/*     */   
/*     */   protected LZWInputStream(InputStream inputStream, ByteOrder byteOrder) {
/*  54 */     this.in = new BitInputStream(inputStream, byteOrder);
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  59 */     this.in.close();
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/*  64 */     int ret = read(this.oneByte);
/*  65 */     if (ret < 0) {
/*  66 */       return ret;
/*     */     }
/*  68 */     return 0xFF & this.oneByte[0];
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/*  73 */     int bytesRead = readFromStack(b, off, len);
/*  74 */     while (len - bytesRead > 0) {
/*  75 */       int result = decompressNextSymbol();
/*  76 */       if (result < 0) {
/*  77 */         if (bytesRead > 0) {
/*  78 */           count(bytesRead);
/*  79 */           return bytesRead;
/*     */         }
/*  81 */         return result;
/*     */       }
/*  83 */       bytesRead += readFromStack(b, off + bytesRead, len - bytesRead);
/*     */     }
/*  85 */     count(bytesRead);
/*  86 */     return bytesRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract int decompressNextSymbol()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   protected abstract int addEntry(int paramInt, byte paramByte)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setClearCode(int codeSize)
/*     */   {
/* 104 */     this.clearCode = (1 << codeSize - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void initializeTables(int maxCodeSize)
/*     */   {
/* 111 */     int maxTableSize = 1 << maxCodeSize;
/* 112 */     this.prefixes = new int[maxTableSize];
/* 113 */     this.characters = new byte[maxTableSize];
/* 114 */     this.outputStack = new byte[maxTableSize];
/* 115 */     this.outputStackLocation = maxTableSize;
/* 116 */     int max = 256;
/* 117 */     for (int i = 0; i < 256; i++) {
/* 118 */       this.prefixes[i] = -1;
/* 119 */       this.characters[i] = ((byte)i);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected int readNextCode()
/*     */     throws IOException
/*     */   {
/* 127 */     if (this.codeSize > 31) {
/* 128 */       throw new IllegalArgumentException("code size must not be bigger than 31");
/*     */     }
/* 130 */     return (int)this.in.readBits(this.codeSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int addEntry(int previousCode, byte character, int maxTableSize)
/*     */   {
/* 138 */     if (this.tableSize < maxTableSize) {
/* 139 */       this.prefixes[this.tableSize] = previousCode;
/* 140 */       this.characters[this.tableSize] = character;
/* 141 */       return this.tableSize++;
/*     */     }
/* 143 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   protected int addRepeatOfPreviousCode()
/*     */     throws IOException
/*     */   {
/* 150 */     if (this.previousCode == -1)
/*     */     {
/* 152 */       throw new IOException("The first code can't be a reference to its preceding code");
/*     */     }
/* 154 */     return addEntry(this.previousCode, this.previousCodeFirstChar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int expandCodeToOutputStack(int code, boolean addedUnfinishedEntry)
/*     */     throws IOException
/*     */   {
/* 163 */     for (int entry = code; entry >= 0; entry = this.prefixes[entry]) {
/* 164 */       this.outputStack[(--this.outputStackLocation)] = this.characters[entry];
/*     */     }
/* 166 */     if ((this.previousCode != -1) && (!addedUnfinishedEntry)) {
/* 167 */       addEntry(this.previousCode, this.outputStack[this.outputStackLocation]);
/*     */     }
/* 169 */     this.previousCode = code;
/* 170 */     this.previousCodeFirstChar = this.outputStack[this.outputStackLocation];
/* 171 */     return this.outputStackLocation;
/*     */   }
/*     */   
/*     */   private int readFromStack(byte[] b, int off, int len) {
/* 175 */     int remainingInStack = this.outputStack.length - this.outputStackLocation;
/* 176 */     if (remainingInStack > 0) {
/* 177 */       int maxLength = Math.min(remainingInStack, len);
/* 178 */       System.arraycopy(this.outputStack, this.outputStackLocation, b, off, maxLength);
/* 179 */       this.outputStackLocation += maxLength;
/* 180 */       return maxLength;
/*     */     }
/* 182 */     return 0;
/*     */   }
/*     */   
/*     */   protected int getCodeSize() {
/* 186 */     return this.codeSize;
/*     */   }
/*     */   
/*     */   protected void resetCodeSize() {
/* 190 */     setCodeSize(9);
/*     */   }
/*     */   
/*     */   protected void setCodeSize(int cs) {
/* 194 */     this.codeSize = cs;
/*     */   }
/*     */   
/*     */   protected void incrementCodeSize() {
/* 198 */     this.codeSize += 1;
/*     */   }
/*     */   
/*     */   protected void resetPreviousCode() {
/* 202 */     this.previousCode = -1;
/*     */   }
/*     */   
/*     */   protected int getPrefix(int offset) {
/* 206 */     return this.prefixes[offset];
/*     */   }
/*     */   
/*     */   protected void setPrefix(int offset, int value) {
/* 210 */     this.prefixes[offset] = value;
/*     */   }
/*     */   
/*     */   protected int getPrefixesLength() {
/* 214 */     return this.prefixes.length;
/*     */   }
/*     */   
/*     */   protected int getClearCode() {
/* 218 */     return this.clearCode;
/*     */   }
/*     */   
/*     */   protected int getTableSize() {
/* 222 */     return this.tableSize;
/*     */   }
/*     */   
/*     */   protected void setTableSize(int newSize) {
/* 226 */     this.tableSize = newSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\lzw\LZWInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */