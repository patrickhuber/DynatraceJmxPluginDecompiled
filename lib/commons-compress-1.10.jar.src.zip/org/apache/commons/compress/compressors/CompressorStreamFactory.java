/*     */ package org.apache.commons.compress.compressors;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
/*     */ import org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.deflate.DeflateCompressorOutputStream;
/*     */ import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
/*     */ import org.apache.commons.compress.compressors.lzma.LZMACompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.lzma.LZMAUtils;
/*     */ import org.apache.commons.compress.compressors.pack200.Pack200CompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.pack200.Pack200CompressorOutputStream;
/*     */ import org.apache.commons.compress.compressors.snappy.FramedSnappyCompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.snappy.SnappyCompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
/*     */ import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream;
/*     */ import org.apache.commons.compress.compressors.xz.XZUtils;
/*     */ import org.apache.commons.compress.compressors.z.ZCompressorInputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompressorStreamFactory
/*     */ {
/*     */   public static final String BZIP2 = "bzip2";
/*     */   public static final String GZIP = "gz";
/*     */   public static final String PACK200 = "pack200";
/*     */   public static final String XZ = "xz";
/*     */   public static final String LZMA = "lzma";
/*     */   public static final String SNAPPY_FRAMED = "snappy-framed";
/*     */   public static final String SNAPPY_RAW = "snappy-raw";
/*     */   public static final String Z = "z";
/*     */   public static final String DEFLATE = "deflate";
/*     */   private final Boolean decompressUntilEOF;
/* 144 */   private volatile boolean decompressConcatenated = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public CompressorStreamFactory()
/*     */   {
/* 150 */     this.decompressUntilEOF = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompressorStreamFactory(boolean decompressUntilEOF)
/*     */   {
/* 164 */     this.decompressUntilEOF = Boolean.valueOf(decompressUntilEOF);
/*     */     
/* 166 */     this.decompressConcatenated = decompressUntilEOF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setDecompressConcatenated(boolean decompressConcatenated)
/*     */   {
/* 187 */     if (this.decompressUntilEOF != null) {
/* 188 */       throw new IllegalStateException("Cannot override the setting defined by the constructor");
/*     */     }
/* 190 */     this.decompressConcatenated = decompressConcatenated;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompressorInputStream createCompressorInputStream(InputStream in)
/*     */     throws CompressorException
/*     */   {
/* 206 */     if (in == null) {
/* 207 */       throw new IllegalArgumentException("Stream must not be null.");
/*     */     }
/*     */     
/* 210 */     if (!in.markSupported()) {
/* 211 */       throw new IllegalArgumentException("Mark is not supported.");
/*     */     }
/*     */     
/* 214 */     byte[] signature = new byte[12];
/* 215 */     in.mark(signature.length);
/*     */     try {
/* 217 */       int signatureLength = IOUtils.readFully(in, signature);
/* 218 */       in.reset();
/*     */       
/* 220 */       if (BZip2CompressorInputStream.matches(signature, signatureLength)) {
/* 221 */         return new BZip2CompressorInputStream(in, this.decompressConcatenated);
/*     */       }
/*     */       
/* 224 */       if (GzipCompressorInputStream.matches(signature, signatureLength)) {
/* 225 */         return new GzipCompressorInputStream(in, this.decompressConcatenated);
/*     */       }
/*     */       
/* 228 */       if (Pack200CompressorInputStream.matches(signature, signatureLength)) {
/* 229 */         return new Pack200CompressorInputStream(in);
/*     */       }
/*     */       
/* 232 */       if (FramedSnappyCompressorInputStream.matches(signature, signatureLength)) {
/* 233 */         return new FramedSnappyCompressorInputStream(in);
/*     */       }
/*     */       
/* 236 */       if (ZCompressorInputStream.matches(signature, signatureLength)) {
/* 237 */         return new ZCompressorInputStream(in);
/*     */       }
/*     */       
/* 240 */       if (DeflateCompressorInputStream.matches(signature, signatureLength)) {
/* 241 */         return new DeflateCompressorInputStream(in);
/*     */       }
/*     */       
/* 244 */       if ((XZUtils.matches(signature, signatureLength)) && (XZUtils.isXZCompressionAvailable()))
/*     */       {
/* 246 */         return new XZCompressorInputStream(in, this.decompressConcatenated);
/*     */       }
/*     */       
/* 249 */       if ((LZMAUtils.matches(signature, signatureLength)) && (LZMAUtils.isLZMACompressionAvailable()))
/*     */       {
/* 251 */         return new LZMACompressorInputStream(in);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 255 */       throw new CompressorException("Failed to detect Compressor from InputStream.", e);
/*     */     }
/*     */     
/* 258 */     throw new CompressorException("No Compressor found for the stream signature.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompressorInputStream createCompressorInputStream(String name, InputStream in)
/*     */     throws CompressorException
/*     */   {
/* 275 */     if ((name == null) || (in == null)) {
/* 276 */       throw new IllegalArgumentException("Compressor name and stream must not be null.");
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 282 */       if ("gz".equalsIgnoreCase(name)) {
/* 283 */         return new GzipCompressorInputStream(in, this.decompressConcatenated);
/*     */       }
/*     */       
/* 286 */       if ("bzip2".equalsIgnoreCase(name)) {
/* 287 */         return new BZip2CompressorInputStream(in, this.decompressConcatenated);
/*     */       }
/*     */       
/* 290 */       if ("xz".equalsIgnoreCase(name)) {
/* 291 */         return new XZCompressorInputStream(in, this.decompressConcatenated);
/*     */       }
/*     */       
/* 294 */       if ("lzma".equalsIgnoreCase(name)) {
/* 295 */         return new LZMACompressorInputStream(in);
/*     */       }
/*     */       
/* 298 */       if ("pack200".equalsIgnoreCase(name)) {
/* 299 */         return new Pack200CompressorInputStream(in);
/*     */       }
/*     */       
/* 302 */       if ("snappy-raw".equalsIgnoreCase(name)) {
/* 303 */         return new SnappyCompressorInputStream(in);
/*     */       }
/*     */       
/* 306 */       if ("snappy-framed".equalsIgnoreCase(name)) {
/* 307 */         return new FramedSnappyCompressorInputStream(in);
/*     */       }
/*     */       
/* 310 */       if ("z".equalsIgnoreCase(name)) {
/* 311 */         return new ZCompressorInputStream(in);
/*     */       }
/*     */       
/* 314 */       if ("deflate".equalsIgnoreCase(name)) {
/* 315 */         return new DeflateCompressorInputStream(in);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 319 */       throw new CompressorException("Could not create CompressorInputStream.", e);
/*     */     }
/*     */     
/* 322 */     throw new CompressorException("Compressor: " + name + " not found.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompressorOutputStream createCompressorOutputStream(String name, OutputStream out)
/*     */     throws CompressorException
/*     */   {
/* 339 */     if ((name == null) || (out == null)) {
/* 340 */       throw new IllegalArgumentException("Compressor name and stream must not be null.");
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 346 */       if ("gz".equalsIgnoreCase(name)) {
/* 347 */         return new GzipCompressorOutputStream(out);
/*     */       }
/*     */       
/* 350 */       if ("bzip2".equalsIgnoreCase(name)) {
/* 351 */         return new BZip2CompressorOutputStream(out);
/*     */       }
/*     */       
/* 354 */       if ("xz".equalsIgnoreCase(name)) {
/* 355 */         return new XZCompressorOutputStream(out);
/*     */       }
/*     */       
/* 358 */       if ("pack200".equalsIgnoreCase(name)) {
/* 359 */         return new Pack200CompressorOutputStream(out);
/*     */       }
/*     */       
/* 362 */       if ("deflate".equalsIgnoreCase(name)) {
/* 363 */         return new DeflateCompressorOutputStream(out);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 367 */       throw new CompressorException("Could not create CompressorOutputStream", e);
/*     */     }
/*     */     
/* 370 */     throw new CompressorException("Compressor: " + name + " not found.");
/*     */   }
/*     */   
/*     */   boolean getDecompressConcatenated()
/*     */   {
/* 375 */     return this.decompressConcatenated;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\CompressorStreamFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */