/*    */ package org.apache.commons.compress.compressors.deflate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeflateParameters
/*    */ {
/* 30 */   private boolean zlibHeader = true;
/* 31 */   private int compressionLevel = -1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean withZlibHeader()
/*    */   {
/* 38 */     return this.zlibHeader;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setWithZlibHeader(boolean zlibHeader)
/*    */   {
/* 50 */     this.zlibHeader = zlibHeader;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getCompressionLevel()
/*    */   {
/* 58 */     return this.compressionLevel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setCompressionLevel(int compressionLevel)
/*    */   {
/* 71 */     if ((compressionLevel < -1) || (compressionLevel > 9)) {
/* 72 */       throw new IllegalArgumentException("Invalid Deflate compression level: " + compressionLevel);
/*    */     }
/* 74 */     this.compressionLevel = compressionLevel;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\deflate\DeflateParameters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */