/*    */ package org.apache.commons.compress.compressors.deflate;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.zip.Deflater;
/*    */ import java.util.zip.DeflaterOutputStream;
/*    */ import org.apache.commons.compress.compressors.CompressorOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeflateCompressorOutputStream
/*    */   extends CompressorOutputStream
/*    */ {
/*    */   private final DeflaterOutputStream out;
/*    */   
/*    */   public DeflateCompressorOutputStream(OutputStream outputStream)
/*    */     throws IOException
/*    */   {
/* 41 */     this(outputStream, new DeflateParameters());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DeflateCompressorOutputStream(OutputStream outputStream, DeflateParameters parameters)
/*    */     throws IOException
/*    */   {
/* 52 */     this.out = new DeflaterOutputStream(outputStream, new Deflater(parameters.getCompressionLevel(), !parameters.withZlibHeader()));
/*    */   }
/*    */   
/*    */   public void write(int b) throws IOException
/*    */   {
/* 57 */     this.out.write(b);
/*    */   }
/*    */   
/*    */   public void write(byte[] buf, int off, int len) throws IOException
/*    */   {
/* 62 */     this.out.write(buf, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void flush()
/*    */     throws IOException
/*    */   {
/* 73 */     this.out.flush();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void finish()
/*    */     throws IOException
/*    */   {
/* 81 */     this.out.finish();
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 86 */     this.out.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\deflate\DeflateCompressorOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */