/*     */ package org.apache.commons.compress.compressors.deflate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.Inflater;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeflateCompressorInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   private static final int MAGIC_1 = 120;
/*     */   private static final int MAGIC_2a = 1;
/*     */   private static final int MAGIC_2b = 94;
/*     */   private static final int MAGIC_2c = 156;
/*     */   private static final int MAGIC_2d = 218;
/*     */   private final InputStream in;
/*     */   
/*     */   public DeflateCompressorInputStream(InputStream inputStream)
/*     */   {
/*  49 */     this(inputStream, new DeflateParameters());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DeflateCompressorInputStream(InputStream inputStream, DeflateParameters parameters)
/*     */   {
/*  61 */     this.in = new InflaterInputStream(inputStream, new Inflater(!parameters.withZlibHeader()));
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  67 */     int ret = this.in.read();
/*  68 */     count(ret == -1 ? 0 : 1);
/*  69 */     return ret;
/*     */   }
/*     */   
/*     */   public int read(byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/*  75 */     int ret = this.in.read(buf, off, len);
/*  76 */     count(ret);
/*  77 */     return ret;
/*     */   }
/*     */   
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/*  83 */     return this.in.skip(n);
/*     */   }
/*     */   
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/*  89 */     return this.in.available();
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  95 */     this.in.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 112 */     return (length > 3) && (signature[0] == 120) && ((signature[1] == 1) || (signature[1] == 94) || (signature[1] == -100) || (signature[1] == -38));
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\deflate\DeflateCompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */