package org.apache.commons.compress.compressors;

import java.io.OutputStream;

public abstract class CompressorOutputStream
  extends OutputStream
{}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\CompressorOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */