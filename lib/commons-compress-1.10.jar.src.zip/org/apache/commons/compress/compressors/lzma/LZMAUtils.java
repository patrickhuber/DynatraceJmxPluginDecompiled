/*     */ package org.apache.commons.compress.compressors.lzma;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.compress.compressors.FileNameUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LZMAUtils
/*     */ {
/*     */   private static final FileNameUtil fileNameUtil;
/*  37 */   private static final byte[] HEADER_MAGIC = { 93, 0, 0 };
/*     */   private static volatile CachedAvailability cachedLZMAAvailability;
/*     */   
/*     */   static enum CachedAvailability
/*     */   {
/*  42 */     DONT_CACHE,  CACHED_AVAILABLE,  CACHED_UNAVAILABLE;
/*     */     
/*     */     private CachedAvailability() {}
/*     */   }
/*     */   
/*     */   static {
/*  48 */     Map<String, String> uncompressSuffix = new HashMap();
/*  49 */     uncompressSuffix.put(".lzma", "");
/*  50 */     uncompressSuffix.put("-lzma", "");
/*  51 */     fileNameUtil = new FileNameUtil(uncompressSuffix, ".lzma");
/*  52 */     cachedLZMAAvailability = CachedAvailability.DONT_CACHE;
/*     */     try {
/*  54 */       Class.forName("org.osgi.framework.BundleEvent");
/*     */     } catch (Exception ex) {
/*  56 */       setCacheLZMAAvailablity(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/*  72 */     if (length < HEADER_MAGIC.length) {
/*  73 */       return false;
/*     */     }
/*     */     
/*  76 */     for (int i = 0; i < HEADER_MAGIC.length; i++) {
/*  77 */       if (signature[i] != HEADER_MAGIC[i]) {
/*  78 */         return false;
/*     */       }
/*     */     }
/*     */     
/*  82 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isLZMACompressionAvailable()
/*     */   {
/*  89 */     CachedAvailability cachedResult = cachedLZMAAvailability;
/*  90 */     if (cachedResult != CachedAvailability.DONT_CACHE) {
/*  91 */       return cachedResult == CachedAvailability.CACHED_AVAILABLE;
/*     */     }
/*  93 */     return internalIsLZMACompressionAvailable();
/*     */   }
/*     */   
/*     */   private static boolean internalIsLZMACompressionAvailable() {
/*     */     try {
/*  98 */       LZMACompressorInputStream.matches(null, 0);
/*  99 */       return true;
/*     */     } catch (NoClassDefFoundError error) {}
/* 101 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isCompressedFilename(String filename)
/*     */   {
/* 113 */     return fileNameUtil.isCompressedFilename(filename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getUncompressedFilename(String filename)
/*     */   {
/* 127 */     return fileNameUtil.getUncompressedFilename(filename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCompressedFilename(String filename)
/*     */   {
/* 138 */     return fileNameUtil.getCompressedFilename(filename);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setCacheLZMAAvailablity(boolean doCache)
/*     */   {
/* 148 */     if (!doCache) {
/* 149 */       cachedLZMAAvailability = CachedAvailability.DONT_CACHE;
/* 150 */     } else if (cachedLZMAAvailability == CachedAvailability.DONT_CACHE) {
/* 151 */       boolean hasLzma = internalIsLZMACompressionAvailable();
/* 152 */       cachedLZMAAvailability = hasLzma ? CachedAvailability.CACHED_AVAILABLE : CachedAvailability.CACHED_UNAVAILABLE;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static CachedAvailability getCachedLZMAAvailability()
/*     */   {
/* 159 */     return cachedLZMAAvailability;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\lzma\LZMAUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */