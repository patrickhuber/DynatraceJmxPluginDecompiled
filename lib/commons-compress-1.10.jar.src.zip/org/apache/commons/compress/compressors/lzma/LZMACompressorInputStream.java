/*     */ package org.apache.commons.compress.compressors.lzma;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ import org.tukaani.xz.LZMAInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LZMACompressorInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   private final InputStream in;
/*     */   
/*     */   public LZMACompressorInputStream(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/*  48 */     this.in = new LZMAInputStream(inputStream);
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  54 */     int ret = this.in.read();
/*  55 */     count(ret == -1 ? 0 : 1);
/*  56 */     return ret;
/*     */   }
/*     */   
/*     */   public int read(byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/*  62 */     int ret = this.in.read(buf, off, len);
/*  63 */     count(ret);
/*  64 */     return ret;
/*     */   }
/*     */   
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/*  70 */     return this.in.skip(n);
/*     */   }
/*     */   
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/*  76 */     return this.in.available();
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  82 */     this.in.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/*  98 */     if ((signature == null) || (length < 3)) {
/*  99 */       return false;
/*     */     }
/*     */     
/* 102 */     if (signature[0] != 93) {
/* 103 */       return false;
/*     */     }
/*     */     
/* 106 */     if (signature[1] != 0) {
/* 107 */       return false;
/*     */     }
/*     */     
/* 110 */     if (signature[2] != 0) {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\lzma\LZMACompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */