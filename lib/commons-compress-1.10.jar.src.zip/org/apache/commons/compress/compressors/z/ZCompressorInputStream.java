/*     */ package org.apache.commons.compress.compressors.z;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteOrder;
/*     */ import org.apache.commons.compress.compressors.lzw.LZWInputStream;
/*     */ import org.apache.commons.compress.utils.BitInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZCompressorInputStream
/*     */   extends LZWInputStream
/*     */ {
/*     */   private static final int MAGIC_1 = 31;
/*     */   private static final int MAGIC_2 = 157;
/*     */   private static final int BLOCK_MODE_MASK = 128;
/*     */   private static final int MAX_CODE_SIZE_MASK = 31;
/*     */   private final boolean blockMode;
/*     */   private final int maxCodeSize;
/*  39 */   private long totalCodesRead = 0L;
/*     */   
/*     */   public ZCompressorInputStream(InputStream inputStream) throws IOException {
/*  42 */     super(inputStream, ByteOrder.LITTLE_ENDIAN);
/*  43 */     int firstByte = (int)this.in.readBits(8);
/*  44 */     int secondByte = (int)this.in.readBits(8);
/*  45 */     int thirdByte = (int)this.in.readBits(8);
/*  46 */     if ((firstByte != 31) || (secondByte != 157) || (thirdByte < 0)) {
/*  47 */       throw new IOException("Input is not in .Z format");
/*     */     }
/*  49 */     this.blockMode = ((thirdByte & 0x80) != 0);
/*  50 */     this.maxCodeSize = (thirdByte & 0x1F);
/*  51 */     if (this.blockMode) {
/*  52 */       setClearCode(9);
/*     */     }
/*  54 */     initializeTables(this.maxCodeSize);
/*  55 */     clearEntries();
/*     */   }
/*     */   
/*     */   private void clearEntries() {
/*  59 */     setTableSize('Ā' + (this.blockMode ? 1 : 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int readNextCode()
/*     */     throws IOException
/*     */   {
/*  70 */     int code = super.readNextCode();
/*  71 */     if (code >= 0) {
/*  72 */       this.totalCodesRead += 1L;
/*     */     }
/*  74 */     return code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void reAlignReading()
/*     */     throws IOException
/*     */   {
/*  82 */     long codeReadsToThrowAway = 8L - this.totalCodesRead % 8L;
/*  83 */     if (codeReadsToThrowAway == 8L) {
/*  84 */       codeReadsToThrowAway = 0L;
/*     */     }
/*  86 */     for (long i = 0L; i < codeReadsToThrowAway; i += 1L) {
/*  87 */       readNextCode();
/*     */     }
/*  89 */     this.in.clearBitCache();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int addEntry(int previousCode, byte character)
/*     */     throws IOException
/*     */   {
/* 100 */     int maxTableSize = 1 << getCodeSize();
/* 101 */     int r = addEntry(previousCode, character, maxTableSize);
/* 102 */     if ((getTableSize() == maxTableSize) && (getCodeSize() < this.maxCodeSize)) {
/* 103 */       reAlignReading();
/* 104 */       incrementCodeSize();
/*     */     }
/* 106 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int decompressNextSymbol()
/*     */     throws IOException
/*     */   {
/* 129 */     int code = readNextCode();
/* 130 */     if (code < 0)
/* 131 */       return -1;
/* 132 */     if ((this.blockMode) && (code == getClearCode())) {
/* 133 */       clearEntries();
/* 134 */       reAlignReading();
/* 135 */       resetCodeSize();
/* 136 */       resetPreviousCode();
/* 137 */       return 0;
/*     */     }
/* 139 */     boolean addedUnfinishedEntry = false;
/* 140 */     if (code == getTableSize()) {
/* 141 */       addRepeatOfPreviousCode();
/* 142 */       addedUnfinishedEntry = true;
/* 143 */     } else if (code > getTableSize()) {
/* 144 */       throw new IOException(String.format("Invalid %d bit code 0x%x", new Object[] { Integer.valueOf(getCodeSize()), Integer.valueOf(code) }));
/*     */     }
/* 146 */     return expandCodeToOutputStack(code, addedUnfinishedEntry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 163 */     return (length > 3) && (signature[0] == 31) && (signature[1] == -99);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\z\ZCompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */