/*      */ package org.apache.commons.compress.compressors.bzip2;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import org.apache.commons.compress.compressors.CompressorOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BZip2CompressorOutputStream
/*      */   extends CompressorOutputStream
/*      */   implements BZip2Constants
/*      */ {
/*      */   public static final int MIN_BLOCKSIZE = 1;
/*      */   public static final int MAX_BLOCKSIZE = 9;
/*      */   private static final int GREATER_ICOST = 15;
/*      */   private static final int LESSER_ICOST = 0;
/*      */   private int last;
/*      */   private final int blockSize100k;
/*      */   private int bsBuff;
/*      */   private int bsLive;
/*      */   
/*      */   private static void hbMakeCodeLengths(byte[] len, int[] freq, Data dat, int alphaSize, int maxLen)
/*      */   {
/*  148 */     int[] heap = dat.heap;
/*  149 */     int[] weight = dat.weight;
/*  150 */     int[] parent = dat.parent;
/*      */     
/*  152 */     int i = alphaSize; for (;;) { i--; if (i < 0) break;
/*  153 */       weight[(i + 1)] = ((freq[i] == 0 ? 1 : freq[i]) << 8);
/*      */     }
/*      */     
/*  156 */     for (boolean tooLong = true; tooLong;) {
/*  157 */       tooLong = false;
/*      */       
/*  159 */       int nNodes = alphaSize;
/*  160 */       int nHeap = 0;
/*  161 */       heap[0] = 0;
/*  162 */       weight[0] = 0;
/*  163 */       parent[0] = -2;
/*      */       
/*  165 */       for (int i = 1; i <= alphaSize; i++) {
/*  166 */         parent[i] = -1;
/*  167 */         nHeap++;
/*  168 */         heap[nHeap] = i;
/*      */         
/*  170 */         int zz = nHeap;
/*  171 */         int tmp = heap[zz];
/*  172 */         while (weight[tmp] < weight[heap[(zz >> 1)]]) {
/*  173 */           heap[zz] = heap[(zz >> 1)];
/*  174 */           zz >>= 1;
/*      */         }
/*  176 */         heap[zz] = tmp;
/*      */       }
/*      */       
/*  179 */       while (nHeap > 1) {
/*  180 */         int n1 = heap[1];
/*  181 */         heap[1] = heap[nHeap];
/*  182 */         nHeap--;
/*      */         
/*  184 */         int yy = 0;
/*  185 */         int zz = 1;
/*  186 */         int tmp = heap[1];
/*      */         for (;;)
/*      */         {
/*  189 */           yy = zz << 1;
/*      */           
/*  191 */           if (yy > nHeap) {
/*      */             break;
/*      */           }
/*      */           
/*  195 */           if ((yy < nHeap) && (weight[heap[(yy + 1)]] < weight[heap[yy]]))
/*      */           {
/*  197 */             yy++;
/*      */           }
/*      */           
/*  200 */           if (weight[tmp] < weight[heap[yy]]) {
/*      */             break;
/*      */           }
/*      */           
/*  204 */           heap[zz] = heap[yy];
/*  205 */           zz = yy;
/*      */         }
/*      */         
/*  208 */         heap[zz] = tmp;
/*      */         
/*  210 */         int n2 = heap[1];
/*  211 */         heap[1] = heap[nHeap];
/*  212 */         nHeap--;
/*      */         
/*  214 */         yy = 0;
/*  215 */         zz = 1;
/*  216 */         tmp = heap[1];
/*      */         for (;;)
/*      */         {
/*  219 */           yy = zz << 1;
/*      */           
/*  221 */           if (yy > nHeap) {
/*      */             break;
/*      */           }
/*      */           
/*  225 */           if ((yy < nHeap) && (weight[heap[(yy + 1)]] < weight[heap[yy]]))
/*      */           {
/*  227 */             yy++;
/*      */           }
/*      */           
/*  230 */           if (weight[tmp] < weight[heap[yy]]) {
/*      */             break;
/*      */           }
/*      */           
/*  234 */           heap[zz] = heap[yy];
/*  235 */           zz = yy;
/*      */         }
/*      */         
/*  238 */         heap[zz] = tmp;
/*  239 */         nNodes++;
/*  240 */         parent[n1] = (parent[n2] = nNodes);
/*      */         
/*  242 */         int weight_n1 = weight[n1];
/*  243 */         int weight_n2 = weight[n2];
/*  244 */         weight[nNodes] = ((weight_n1 & 0xFF00) + (weight_n2 & 0xFF00) | 1 + ((weight_n1 & 0xFF) > (weight_n2 & 0xFF) ? weight_n1 & 0xFF : weight_n2 & 0xFF));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  251 */         parent[nNodes] = -1;
/*  252 */         nHeap++;
/*  253 */         heap[nHeap] = nNodes;
/*      */         
/*  255 */         tmp = 0;
/*  256 */         zz = nHeap;
/*  257 */         tmp = heap[zz];
/*  258 */         int weight_tmp = weight[tmp];
/*  259 */         while (weight_tmp < weight[heap[(zz >> 1)]]) {
/*  260 */           heap[zz] = heap[(zz >> 1)];
/*  261 */           zz >>= 1;
/*      */         }
/*  263 */         heap[zz] = tmp;
/*      */       }
/*      */       
/*      */ 
/*  267 */       for (int i = 1; i <= alphaSize; i++) {
/*  268 */         int j = 0;
/*  269 */         int k = i;
/*      */         int parent_k;
/*  271 */         while ((parent_k = parent[k]) >= 0) {
/*  272 */           k = parent_k;
/*  273 */           j++;
/*      */         }
/*      */         
/*  276 */         len[(i - 1)] = ((byte)j);
/*  277 */         if (j > maxLen) {
/*  278 */           tooLong = true;
/*      */         }
/*      */       }
/*      */       
/*  282 */       if (tooLong) {
/*  283 */         for (int i = 1; i < alphaSize; i++) {
/*  284 */           int j = weight[i] >> 8;
/*  285 */           j = 1 + (j >> 1);
/*  286 */           weight[i] = (j << 8);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  305 */   private final CRC crc = new CRC();
/*      */   
/*      */   private int nInUse;
/*      */   
/*      */   private int nMTF;
/*      */   
/*  311 */   private int currentChar = -1;
/*  312 */   private int runLength = 0;
/*      */   
/*      */ 
/*      */ 
/*      */   private int blockCRC;
/*      */   
/*      */ 
/*      */ 
/*      */   private int combinedCRC;
/*      */   
/*      */ 
/*      */ 
/*      */   private final int allowableBlockSize;
/*      */   
/*      */ 
/*      */   private Data data;
/*      */   
/*      */ 
/*      */   private BlockSort blockSorter;
/*      */   
/*      */ 
/*      */   private OutputStream out;
/*      */   
/*      */ 
/*      */ 
/*      */   public static int chooseBlockSize(long inputLength)
/*      */   {
/*  339 */     return inputLength > 0L ? (int)Math.min(inputLength / 132000L + 1L, 9L) : 9;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BZip2CompressorOutputStream(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  356 */     this(out, 9);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BZip2CompressorOutputStream(OutputStream out, int blockSize)
/*      */     throws IOException
/*      */   {
/*  378 */     if (blockSize < 1) {
/*  379 */       throw new IllegalArgumentException("blockSize(" + blockSize + ") < 1");
/*      */     }
/*  381 */     if (blockSize > 9) {
/*  382 */       throw new IllegalArgumentException("blockSize(" + blockSize + ") > 9");
/*      */     }
/*      */     
/*  385 */     this.blockSize100k = blockSize;
/*  386 */     this.out = out;
/*      */     
/*      */ 
/*  389 */     this.allowableBlockSize = (this.blockSize100k * 100000 - 20);
/*  390 */     init();
/*      */   }
/*      */   
/*      */   public void write(int b) throws IOException
/*      */   {
/*  395 */     if (this.out != null) {
/*  396 */       write0(b);
/*      */     } else {
/*  398 */       throw new IOException("closed");
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void writeRun()
/*      */     throws IOException
/*      */   {
/*  416 */     int lastShadow = this.last;
/*      */     
/*  418 */     if (lastShadow < this.allowableBlockSize) {
/*  419 */       int currentCharShadow = this.currentChar;
/*  420 */       Data dataShadow = this.data;
/*  421 */       dataShadow.inUse[currentCharShadow] = true;
/*  422 */       byte ch = (byte)currentCharShadow;
/*      */       
/*  424 */       int runLengthShadow = this.runLength;
/*  425 */       this.crc.updateCRC(currentCharShadow, runLengthShadow);
/*      */       
/*  427 */       switch (runLengthShadow) {
/*      */       case 1: 
/*  429 */         dataShadow.block[(lastShadow + 2)] = ch;
/*  430 */         this.last = (lastShadow + 1);
/*  431 */         break;
/*      */       
/*      */       case 2: 
/*  434 */         dataShadow.block[(lastShadow + 2)] = ch;
/*  435 */         dataShadow.block[(lastShadow + 3)] = ch;
/*  436 */         this.last = (lastShadow + 2);
/*  437 */         break;
/*      */       
/*      */       case 3: 
/*  440 */         byte[] block = dataShadow.block;
/*  441 */         block[(lastShadow + 2)] = ch;
/*  442 */         block[(lastShadow + 3)] = ch;
/*  443 */         block[(lastShadow + 4)] = ch;
/*  444 */         this.last = (lastShadow + 3);
/*      */         
/*  446 */         break;
/*      */       
/*      */       default: 
/*  449 */         runLengthShadow -= 4;
/*  450 */         dataShadow.inUse[runLengthShadow] = true;
/*  451 */         byte[] block = dataShadow.block;
/*  452 */         block[(lastShadow + 2)] = ch;
/*  453 */         block[(lastShadow + 3)] = ch;
/*  454 */         block[(lastShadow + 4)] = ch;
/*  455 */         block[(lastShadow + 5)] = ch;
/*  456 */         block[(lastShadow + 6)] = ((byte)runLengthShadow);
/*  457 */         this.last = (lastShadow + 5);
/*      */       }
/*      */       
/*      */     }
/*      */     else
/*      */     {
/*  463 */       endBlock();
/*  464 */       initBlock();
/*  465 */       writeRun();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void finalize()
/*      */     throws Throwable
/*      */   {
/*  474 */     finish();
/*  475 */     super.finalize();
/*      */   }
/*      */   
/*      */   public void finish() throws IOException
/*      */   {
/*  480 */     if (this.out != null) {
/*      */       try {
/*  482 */         if (this.runLength > 0) {
/*  483 */           writeRun();
/*      */         }
/*  485 */         this.currentChar = -1;
/*  486 */         endBlock();
/*  487 */         endCompression();
/*      */       } finally {
/*  489 */         this.out = null;
/*  490 */         this.data = null;
/*  491 */         this.blockSorter = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void close() throws IOException
/*      */   {
/*  498 */     if (this.out != null) {
/*  499 */       OutputStream outShadow = this.out;
/*  500 */       finish();
/*  501 */       outShadow.close();
/*      */     }
/*      */   }
/*      */   
/*      */   public void flush() throws IOException
/*      */   {
/*  507 */     OutputStream outShadow = this.out;
/*  508 */     if (outShadow != null) {
/*  509 */       outShadow.flush();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init()
/*      */     throws IOException
/*      */   {
/*  520 */     bsPutUByte(66);
/*  521 */     bsPutUByte(90);
/*      */     
/*  523 */     this.data = new Data(this.blockSize100k);
/*  524 */     this.blockSorter = new BlockSort(this.data);
/*      */     
/*      */ 
/*  527 */     bsPutUByte(104);
/*  528 */     bsPutUByte(48 + this.blockSize100k);
/*      */     
/*  530 */     this.combinedCRC = 0;
/*  531 */     initBlock();
/*      */   }
/*      */   
/*      */   private void initBlock()
/*      */   {
/*  536 */     this.crc.initialiseCRC();
/*  537 */     this.last = -1;
/*      */     
/*      */ 
/*  540 */     boolean[] inUse = this.data.inUse;
/*  541 */     int i = 256; for (;;) { i--; if (i < 0) break;
/*  542 */       inUse[i] = false;
/*      */     }
/*      */   }
/*      */   
/*      */   private void endBlock() throws IOException
/*      */   {
/*  548 */     this.blockCRC = this.crc.getFinalCRC();
/*  549 */     this.combinedCRC = (this.combinedCRC << 1 | this.combinedCRC >>> 31);
/*  550 */     this.combinedCRC ^= this.blockCRC;
/*      */     
/*      */ 
/*  553 */     if (this.last == -1) {
/*  554 */       return;
/*      */     }
/*      */     
/*      */ 
/*  558 */     blockSort();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  571 */     bsPutUByte(49);
/*  572 */     bsPutUByte(65);
/*  573 */     bsPutUByte(89);
/*  574 */     bsPutUByte(38);
/*  575 */     bsPutUByte(83);
/*  576 */     bsPutUByte(89);
/*      */     
/*      */ 
/*  579 */     bsPutInt(this.blockCRC);
/*      */     
/*      */ 
/*  582 */     bsW(1, 0);
/*      */     
/*      */ 
/*  585 */     moveToFrontCodeAndSend();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void endCompression()
/*      */     throws IOException
/*      */   {
/*  595 */     bsPutUByte(23);
/*  596 */     bsPutUByte(114);
/*  597 */     bsPutUByte(69);
/*  598 */     bsPutUByte(56);
/*  599 */     bsPutUByte(80);
/*  600 */     bsPutUByte(144);
/*      */     
/*  602 */     bsPutInt(this.combinedCRC);
/*  603 */     bsFinishedWithStream();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final int getBlockSize()
/*      */   {
/*  610 */     return this.blockSize100k;
/*      */   }
/*      */   
/*      */   public void write(byte[] buf, int offs, int len)
/*      */     throws IOException
/*      */   {
/*  616 */     if (offs < 0) {
/*  617 */       throw new IndexOutOfBoundsException("offs(" + offs + ") < 0.");
/*      */     }
/*  619 */     if (len < 0) {
/*  620 */       throw new IndexOutOfBoundsException("len(" + len + ") < 0.");
/*      */     }
/*  622 */     if (offs + len > buf.length) {
/*  623 */       throw new IndexOutOfBoundsException("offs(" + offs + ") + len(" + len + ") > buf.length(" + buf.length + ").");
/*      */     }
/*      */     
/*      */ 
/*  627 */     if (this.out == null) {
/*  628 */       throw new IOException("stream closed");
/*      */     }
/*      */     
/*  631 */     for (int hi = offs + len; offs < hi;) {
/*  632 */       write0(buf[(offs++)]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void write0(int b)
/*      */     throws IOException
/*      */   {
/*  641 */     if (this.currentChar != -1) {
/*  642 */       b &= 0xFF;
/*  643 */       if (this.currentChar == b) {
/*  644 */         if (++this.runLength > 254) {
/*  645 */           writeRun();
/*  646 */           this.currentChar = -1;
/*  647 */           this.runLength = 0;
/*      */         }
/*      */       }
/*      */       else {
/*  651 */         writeRun();
/*  652 */         this.runLength = 1;
/*  653 */         this.currentChar = b;
/*      */       }
/*      */     } else {
/*  656 */       this.currentChar = (b & 0xFF);
/*  657 */       this.runLength += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static void hbAssignCodes(int[] code, byte[] length, int minLen, int maxLen, int alphaSize)
/*      */   {
/*  664 */     int vec = 0;
/*  665 */     for (int n = minLen; n <= maxLen; n++) {
/*  666 */       for (int i = 0; i < alphaSize; i++) {
/*  667 */         if ((length[i] & 0xFF) == n) {
/*  668 */           code[i] = vec;
/*  669 */           vec++;
/*      */         }
/*      */       }
/*  672 */       vec <<= 1;
/*      */     }
/*      */   }
/*      */   
/*      */   private void bsFinishedWithStream() throws IOException {
/*  677 */     while (this.bsLive > 0) {
/*  678 */       int ch = this.bsBuff >> 24;
/*  679 */       this.out.write(ch);
/*  680 */       this.bsBuff <<= 8;
/*  681 */       this.bsLive -= 8;
/*      */     }
/*      */   }
/*      */   
/*      */   private void bsW(int n, int v) throws IOException {
/*  686 */     OutputStream outShadow = this.out;
/*  687 */     int bsLiveShadow = this.bsLive;
/*  688 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  690 */     while (bsLiveShadow >= 8) {
/*  691 */       outShadow.write(bsBuffShadow >> 24);
/*  692 */       bsBuffShadow <<= 8;
/*  693 */       bsLiveShadow -= 8;
/*      */     }
/*      */     
/*  696 */     this.bsBuff = (bsBuffShadow | v << 32 - bsLiveShadow - n);
/*  697 */     this.bsLive = (bsLiveShadow + n);
/*      */   }
/*      */   
/*      */   private void bsPutUByte(int c) throws IOException {
/*  701 */     bsW(8, c);
/*      */   }
/*      */   
/*      */   private void bsPutInt(int u) throws IOException {
/*  705 */     bsW(8, u >> 24 & 0xFF);
/*  706 */     bsW(8, u >> 16 & 0xFF);
/*  707 */     bsW(8, u >> 8 & 0xFF);
/*  708 */     bsW(8, u & 0xFF);
/*      */   }
/*      */   
/*      */   private void sendMTFValues() throws IOException {
/*  712 */     byte[][] len = this.data.sendMTFValues_len;
/*  713 */     int alphaSize = this.nInUse + 2;
/*      */     
/*  715 */     int t = 6; for (;;) { t--; if (t < 0) break;
/*  716 */       byte[] len_t = len[t];
/*  717 */       int v = alphaSize; for (;;) { v--; if (v < 0) break;
/*  718 */         len_t[v] = 15;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  724 */     int nGroups = this.nMTF < 2400 ? 5 : this.nMTF < 1200 ? 4 : this.nMTF < 600 ? 3 : this.nMTF < 200 ? 2 : 6;
/*      */     
/*      */ 
/*      */ 
/*  728 */     sendMTFValues0(nGroups, alphaSize);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  733 */     int nSelectors = sendMTFValues1(nGroups, alphaSize);
/*      */     
/*      */ 
/*  736 */     sendMTFValues2(nGroups, nSelectors);
/*      */     
/*      */ 
/*  739 */     sendMTFValues3(nGroups, alphaSize);
/*      */     
/*      */ 
/*  742 */     sendMTFValues4();
/*      */     
/*      */ 
/*  745 */     sendMTFValues5(nGroups, nSelectors);
/*      */     
/*      */ 
/*  748 */     sendMTFValues6(nGroups, alphaSize);
/*      */     
/*      */ 
/*  751 */     sendMTFValues7();
/*      */   }
/*      */   
/*      */   private void sendMTFValues0(int nGroups, int alphaSize) {
/*  755 */     byte[][] len = this.data.sendMTFValues_len;
/*  756 */     int[] mtfFreq = this.data.mtfFreq;
/*      */     
/*  758 */     int remF = this.nMTF;
/*  759 */     int gs = 0;
/*      */     
/*  761 */     for (int nPart = nGroups; nPart > 0; nPart--) {
/*  762 */       int tFreq = remF / nPart;
/*  763 */       int ge = gs - 1;
/*  764 */       int aFreq = 0;
/*      */       
/*  766 */       for (int a = alphaSize - 1; (aFreq < tFreq) && (ge < a);) {
/*  767 */         aFreq += mtfFreq[(++ge)];
/*      */       }
/*      */       
/*  770 */       if ((ge > gs) && (nPart != nGroups) && (nPart != 1) && ((nGroups - nPart & 0x1) != 0))
/*      */       {
/*  772 */         aFreq -= mtfFreq[(ge--)];
/*      */       }
/*      */       
/*  775 */       byte[] len_np = len[(nPart - 1)];
/*  776 */       int v = alphaSize; for (;;) { v--; if (v < 0) break;
/*  777 */         if ((v >= gs) && (v <= ge)) {
/*  778 */           len_np[v] = 0;
/*      */         } else {
/*  780 */           len_np[v] = 15;
/*      */         }
/*      */       }
/*      */       
/*  784 */       gs = ge + 1;
/*  785 */       remF -= aFreq;
/*      */     }
/*      */   }
/*      */   
/*      */   private int sendMTFValues1(int nGroups, int alphaSize) {
/*  790 */     Data dataShadow = this.data;
/*  791 */     int[][] rfreq = dataShadow.sendMTFValues_rfreq;
/*  792 */     int[] fave = dataShadow.sendMTFValues_fave;
/*  793 */     short[] cost = dataShadow.sendMTFValues_cost;
/*  794 */     char[] sfmap = dataShadow.sfmap;
/*  795 */     byte[] selector = dataShadow.selector;
/*  796 */     byte[][] len = dataShadow.sendMTFValues_len;
/*  797 */     byte[] len_0 = len[0];
/*  798 */     byte[] len_1 = len[1];
/*  799 */     byte[] len_2 = len[2];
/*  800 */     byte[] len_3 = len[3];
/*  801 */     byte[] len_4 = len[4];
/*  802 */     byte[] len_5 = len[5];
/*  803 */     int nMTFShadow = this.nMTF;
/*      */     
/*  805 */     int nSelectors = 0;
/*      */     
/*  807 */     for (int iter = 0; iter < 4; iter++) {
/*  808 */       int t = nGroups; for (;;) { t--; if (t < 0) break;
/*  809 */         fave[t] = 0;
/*  810 */         int[] rfreqt = rfreq[t];
/*  811 */         int i = alphaSize; for (;;) { i--; if (i < 0) break;
/*  812 */           rfreqt[i] = 0;
/*      */         }
/*      */       }
/*      */       
/*  816 */       nSelectors = 0;
/*      */       
/*  818 */       for (int gs = 0; gs < this.nMTF;)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  826 */         int ge = Math.min(gs + 50 - 1, nMTFShadow - 1);
/*      */         
/*  828 */         if (nGroups == 6)
/*      */         {
/*      */ 
/*  831 */           short cost0 = 0;
/*  832 */           short cost1 = 0;
/*  833 */           short cost2 = 0;
/*  834 */           short cost3 = 0;
/*  835 */           short cost4 = 0;
/*  836 */           short cost5 = 0;
/*      */           
/*  838 */           for (int i = gs; i <= ge; i++) {
/*  839 */             int icv = sfmap[i];
/*  840 */             cost0 = (short)(cost0 + (len_0[icv] & 0xFF));
/*  841 */             cost1 = (short)(cost1 + (len_1[icv] & 0xFF));
/*  842 */             cost2 = (short)(cost2 + (len_2[icv] & 0xFF));
/*  843 */             cost3 = (short)(cost3 + (len_3[icv] & 0xFF));
/*  844 */             cost4 = (short)(cost4 + (len_4[icv] & 0xFF));
/*  845 */             cost5 = (short)(cost5 + (len_5[icv] & 0xFF));
/*      */           }
/*      */           
/*  848 */           cost[0] = cost0;
/*  849 */           cost[1] = cost1;
/*  850 */           cost[2] = cost2;
/*  851 */           cost[3] = cost3;
/*  852 */           cost[4] = cost4;
/*  853 */           cost[5] = cost5;
/*      */         }
/*      */         else {
/*  856 */           int t = nGroups; for (;;) { t--; if (t < 0) break;
/*  857 */             cost[t] = 0;
/*      */           }
/*      */           
/*  860 */           for (int i = gs; i <= ge; i++) {
/*  861 */             int icv = sfmap[i];
/*  862 */             int t = nGroups; for (;;) { t--; if (t < 0) break;
/*  863 */               int tmp403_401 = t; short[] tmp403_399 = cost;tmp403_399[tmp403_401] = ((short)(tmp403_399[tmp403_401] + (len[t][icv] & 0xFF)));
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  872 */         int bt = -1;
/*  873 */         int t = nGroups;int bc = 999999999; for (;;) { t--; if (t < 0) break;
/*  874 */           int cost_t = cost[t];
/*  875 */           if (cost_t < bc) {
/*  876 */             bc = cost_t;
/*  877 */             bt = t;
/*      */           }
/*      */         }
/*      */         
/*  881 */         fave[bt] += 1;
/*  882 */         selector[nSelectors] = ((byte)bt);
/*  883 */         nSelectors++;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  888 */         int[] rfreq_bt = rfreq[bt];
/*  889 */         for (int i = gs; i <= ge; i++) {
/*  890 */           rfreq_bt[sfmap[i]] += 1;
/*      */         }
/*      */         
/*  893 */         gs = ge + 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  899 */       for (int t = 0; t < nGroups; t++) {
/*  900 */         hbMakeCodeLengths(len[t], rfreq[t], this.data, alphaSize, 20);
/*      */       }
/*      */     }
/*      */     
/*  904 */     return nSelectors;
/*      */   }
/*      */   
/*      */ 
/*      */   private void sendMTFValues2(int nGroups, int nSelectors)
/*      */   {
/*  910 */     Data dataShadow = this.data;
/*  911 */     byte[] pos = dataShadow.sendMTFValues2_pos;
/*      */     
/*  913 */     int i = nGroups; for (;;) { i--; if (i < 0) break;
/*  914 */       pos[i] = ((byte)i);
/*      */     }
/*      */     
/*  917 */     for (int i = 0; i < nSelectors; i++) {
/*  918 */       byte ll_i = dataShadow.selector[i];
/*  919 */       byte tmp = pos[0];
/*  920 */       int j = 0;
/*      */       
/*  922 */       while (ll_i != tmp) {
/*  923 */         j++;
/*  924 */         byte tmp2 = tmp;
/*  925 */         tmp = pos[j];
/*  926 */         pos[j] = tmp2;
/*      */       }
/*      */       
/*  929 */       pos[0] = tmp;
/*  930 */       dataShadow.selectorMtf[i] = ((byte)j);
/*      */     }
/*      */   }
/*      */   
/*      */   private void sendMTFValues3(int nGroups, int alphaSize) {
/*  935 */     int[][] code = this.data.sendMTFValues_code;
/*  936 */     byte[][] len = this.data.sendMTFValues_len;
/*      */     
/*  938 */     for (int t = 0; t < nGroups; t++) {
/*  939 */       int minLen = 32;
/*  940 */       int maxLen = 0;
/*  941 */       byte[] len_t = len[t];
/*  942 */       int i = alphaSize; for (;;) { i--; if (i < 0) break;
/*  943 */         int l = len_t[i] & 0xFF;
/*  944 */         if (l > maxLen) {
/*  945 */           maxLen = l;
/*      */         }
/*  947 */         if (l < minLen) {
/*  948 */           minLen = l;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  955 */       hbAssignCodes(code[t], len[t], minLen, maxLen, alphaSize);
/*      */     }
/*      */   }
/*      */   
/*      */   private void sendMTFValues4() throws IOException {
/*  960 */     boolean[] inUse = this.data.inUse;
/*  961 */     boolean[] inUse16 = this.data.sentMTFValues4_inUse16;
/*      */     
/*  963 */     int i = 16; for (;;) { i--; if (i < 0) break;
/*  964 */       inUse16[i] = false;
/*  965 */       int i16 = i * 16;
/*  966 */       int j = 16; for (;;) { j--; if (j < 0) break;
/*  967 */         if (inUse[(i16 + j)] != 0) {
/*  968 */           inUse16[i] = true;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  973 */     for (int i = 0; i < 16; i++) {
/*  974 */       bsW(1, inUse16[i] != 0 ? 1 : 0);
/*      */     }
/*      */     
/*  977 */     OutputStream outShadow = this.out;
/*  978 */     int bsLiveShadow = this.bsLive;
/*  979 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  981 */     for (int i = 0; i < 16; i++) {
/*  982 */       if (inUse16[i] != 0) {
/*  983 */         int i16 = i * 16;
/*  984 */         for (int j = 0; j < 16; j++)
/*      */         {
/*  986 */           while (bsLiveShadow >= 8) {
/*  987 */             outShadow.write(bsBuffShadow >> 24);
/*  988 */             bsBuffShadow <<= 8;
/*  989 */             bsLiveShadow -= 8;
/*      */           }
/*  991 */           if (inUse[(i16 + j)] != 0) {
/*  992 */             bsBuffShadow |= 1 << 32 - bsLiveShadow - 1;
/*      */           }
/*  994 */           bsLiveShadow++;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  999 */     this.bsBuff = bsBuffShadow;
/* 1000 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */   
/*      */   private void sendMTFValues5(int nGroups, int nSelectors) throws IOException
/*      */   {
/* 1005 */     bsW(3, nGroups);
/* 1006 */     bsW(15, nSelectors);
/*      */     
/* 1008 */     OutputStream outShadow = this.out;
/* 1009 */     byte[] selectorMtf = this.data.selectorMtf;
/*      */     
/* 1011 */     int bsLiveShadow = this.bsLive;
/* 1012 */     int bsBuffShadow = this.bsBuff;
/*      */     
/* 1014 */     for (int i = 0; i < nSelectors; i++) {
/* 1015 */       int j = 0; for (int hj = selectorMtf[i] & 0xFF; j < hj; j++)
/*      */       {
/* 1017 */         while (bsLiveShadow >= 8) {
/* 1018 */           outShadow.write(bsBuffShadow >> 24);
/* 1019 */           bsBuffShadow <<= 8;
/* 1020 */           bsLiveShadow -= 8;
/*      */         }
/* 1022 */         bsBuffShadow |= 1 << 32 - bsLiveShadow - 1;
/* 1023 */         bsLiveShadow++;
/*      */       }
/*      */       
/*      */ 
/* 1027 */       while (bsLiveShadow >= 8) {
/* 1028 */         outShadow.write(bsBuffShadow >> 24);
/* 1029 */         bsBuffShadow <<= 8;
/* 1030 */         bsLiveShadow -= 8;
/*      */       }
/*      */       
/* 1033 */       bsLiveShadow++;
/*      */     }
/*      */     
/* 1036 */     this.bsBuff = bsBuffShadow;
/* 1037 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */   
/*      */   private void sendMTFValues6(int nGroups, int alphaSize) throws IOException
/*      */   {
/* 1042 */     byte[][] len = this.data.sendMTFValues_len;
/* 1043 */     OutputStream outShadow = this.out;
/*      */     
/* 1045 */     int bsLiveShadow = this.bsLive;
/* 1046 */     int bsBuffShadow = this.bsBuff;
/*      */     
/* 1048 */     for (int t = 0; t < nGroups; t++) {
/* 1049 */       byte[] len_t = len[t];
/* 1050 */       int curr = len_t[0] & 0xFF;
/*      */       
/*      */ 
/* 1053 */       while (bsLiveShadow >= 8) {
/* 1054 */         outShadow.write(bsBuffShadow >> 24);
/* 1055 */         bsBuffShadow <<= 8;
/* 1056 */         bsLiveShadow -= 8;
/*      */       }
/* 1058 */       bsBuffShadow |= curr << 32 - bsLiveShadow - 5;
/* 1059 */       bsLiveShadow += 5;
/*      */       
/* 1061 */       for (int i = 0; i < alphaSize; i++) {
/* 1062 */         int lti = len_t[i] & 0xFF;
/* 1063 */         while (curr < lti)
/*      */         {
/* 1065 */           while (bsLiveShadow >= 8) {
/* 1066 */             outShadow.write(bsBuffShadow >> 24);
/* 1067 */             bsBuffShadow <<= 8;
/* 1068 */             bsLiveShadow -= 8;
/*      */           }
/* 1070 */           bsBuffShadow |= 2 << 32 - bsLiveShadow - 2;
/* 1071 */           bsLiveShadow += 2;
/*      */           
/* 1073 */           curr++;
/*      */         }
/*      */         
/* 1076 */         while (curr > lti)
/*      */         {
/* 1078 */           while (bsLiveShadow >= 8) {
/* 1079 */             outShadow.write(bsBuffShadow >> 24);
/* 1080 */             bsBuffShadow <<= 8;
/* 1081 */             bsLiveShadow -= 8;
/*      */           }
/* 1083 */           bsBuffShadow |= 3 << 32 - bsLiveShadow - 2;
/* 1084 */           bsLiveShadow += 2;
/*      */           
/* 1086 */           curr--;
/*      */         }
/*      */         
/*      */ 
/* 1090 */         while (bsLiveShadow >= 8) {
/* 1091 */           outShadow.write(bsBuffShadow >> 24);
/* 1092 */           bsBuffShadow <<= 8;
/* 1093 */           bsLiveShadow -= 8;
/*      */         }
/*      */         
/* 1096 */         bsLiveShadow++;
/*      */       }
/*      */     }
/*      */     
/* 1100 */     this.bsBuff = bsBuffShadow;
/* 1101 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */   
/*      */   private void sendMTFValues7() throws IOException {
/* 1105 */     Data dataShadow = this.data;
/* 1106 */     byte[][] len = dataShadow.sendMTFValues_len;
/* 1107 */     int[][] code = dataShadow.sendMTFValues_code;
/* 1108 */     OutputStream outShadow = this.out;
/* 1109 */     byte[] selector = dataShadow.selector;
/* 1110 */     char[] sfmap = dataShadow.sfmap;
/* 1111 */     int nMTFShadow = this.nMTF;
/*      */     
/* 1113 */     int selCtr = 0;
/*      */     
/* 1115 */     int bsLiveShadow = this.bsLive;
/* 1116 */     int bsBuffShadow = this.bsBuff;
/*      */     
/* 1118 */     for (int gs = 0; gs < nMTFShadow;) {
/* 1119 */       int ge = Math.min(gs + 50 - 1, nMTFShadow - 1);
/* 1120 */       int selector_selCtr = selector[selCtr] & 0xFF;
/* 1121 */       int[] code_selCtr = code[selector_selCtr];
/* 1122 */       byte[] len_selCtr = len[selector_selCtr];
/*      */       
/* 1124 */       while (gs <= ge) {
/* 1125 */         int sfmap_i = sfmap[gs];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1131 */         while (bsLiveShadow >= 8) {
/* 1132 */           outShadow.write(bsBuffShadow >> 24);
/* 1133 */           bsBuffShadow <<= 8;
/* 1134 */           bsLiveShadow -= 8;
/*      */         }
/* 1136 */         int n = len_selCtr[sfmap_i] & 0xFF;
/* 1137 */         bsBuffShadow |= code_selCtr[sfmap_i] << 32 - bsLiveShadow - n;
/* 1138 */         bsLiveShadow += n;
/*      */         
/* 1140 */         gs++;
/*      */       }
/*      */       
/* 1143 */       gs = ge + 1;
/* 1144 */       selCtr++;
/*      */     }
/*      */     
/* 1147 */     this.bsBuff = bsBuffShadow;
/* 1148 */     this.bsLive = bsLiveShadow;
/*      */   }
/*      */   
/*      */   private void moveToFrontCodeAndSend() throws IOException {
/* 1152 */     bsW(24, this.data.origPtr);
/* 1153 */     generateMTFValues();
/* 1154 */     sendMTFValues();
/*      */   }
/*      */   
/*      */   private void blockSort() {
/* 1158 */     this.blockSorter.blockSort(this.data, this.last);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void generateMTFValues()
/*      */   {
/* 1169 */     int lastShadow = this.last;
/* 1170 */     Data dataShadow = this.data;
/* 1171 */     boolean[] inUse = dataShadow.inUse;
/* 1172 */     byte[] block = dataShadow.block;
/* 1173 */     int[] fmap = dataShadow.fmap;
/* 1174 */     char[] sfmap = dataShadow.sfmap;
/* 1175 */     int[] mtfFreq = dataShadow.mtfFreq;
/* 1176 */     byte[] unseqToSeq = dataShadow.unseqToSeq;
/* 1177 */     byte[] yy = dataShadow.generateMTFValues_yy;
/*      */     
/*      */ 
/* 1180 */     int nInUseShadow = 0;
/* 1181 */     for (int i = 0; i < 256; i++) {
/* 1182 */       if (inUse[i] != 0) {
/* 1183 */         unseqToSeq[i] = ((byte)nInUseShadow);
/* 1184 */         nInUseShadow++;
/*      */       }
/*      */     }
/* 1187 */     this.nInUse = nInUseShadow;
/*      */     
/* 1189 */     int eob = nInUseShadow + 1;
/*      */     
/* 1191 */     for (int i = eob; i >= 0; i--) {
/* 1192 */       mtfFreq[i] = 0;
/*      */     }
/*      */     
/* 1195 */     int i = nInUseShadow; for (;;) { i--; if (i < 0) break;
/* 1196 */       yy[i] = ((byte)i);
/*      */     }
/*      */     
/* 1199 */     int wr = 0;
/* 1200 */     int zPend = 0;
/*      */     
/* 1202 */     for (int i = 0; i <= lastShadow; i++) {
/* 1203 */       byte ll_i = unseqToSeq[(block[fmap[i]] & 0xFF)];
/* 1204 */       byte tmp = yy[0];
/* 1205 */       int j = 0;
/*      */       
/* 1207 */       while (ll_i != tmp) {
/* 1208 */         j++;
/* 1209 */         byte tmp2 = tmp;
/* 1210 */         tmp = yy[j];
/* 1211 */         yy[j] = tmp2;
/*      */       }
/* 1213 */       yy[0] = tmp;
/*      */       
/* 1215 */       if (j == 0) {
/* 1216 */         zPend++;
/*      */       } else {
/* 1218 */         if (zPend > 0) {
/* 1219 */           zPend--;
/*      */           for (;;) {
/* 1221 */             if ((zPend & 0x1) == 0) {
/* 1222 */               sfmap[wr] = '\000';
/* 1223 */               wr++;
/* 1224 */               mtfFreq[0] += 1;
/*      */             } else {
/* 1226 */               sfmap[wr] = '\001';
/* 1227 */               wr++;
/* 1228 */               mtfFreq[1] += 1;
/*      */             }
/*      */             
/* 1231 */             if (zPend < 2) break;
/* 1232 */             zPend = zPend - 2 >> 1;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1237 */           zPend = 0;
/*      */         }
/* 1239 */         sfmap[wr] = ((char)(j + 1));
/* 1240 */         wr++;
/* 1241 */         mtfFreq[(j + 1)] += 1;
/*      */       }
/*      */     }
/*      */     
/* 1245 */     if (zPend > 0) {
/* 1246 */       zPend--;
/*      */       for (;;) {
/* 1248 */         if ((zPend & 0x1) == 0) {
/* 1249 */           sfmap[wr] = '\000';
/* 1250 */           wr++;
/* 1251 */           mtfFreq[0] += 1;
/*      */         } else {
/* 1253 */           sfmap[wr] = '\001';
/* 1254 */           wr++;
/* 1255 */           mtfFreq[1] += 1;
/*      */         }
/*      */         
/* 1258 */         if (zPend < 2) break;
/* 1259 */         zPend = zPend - 2 >> 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1266 */     sfmap[wr] = ((char)eob);
/* 1267 */     mtfFreq[eob] += 1;
/* 1268 */     this.nMTF = (wr + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class Data
/*      */   {
/* 1275 */     final boolean[] inUse = new boolean['Ā'];
/* 1276 */     final byte[] unseqToSeq = new byte['Ā'];
/* 1277 */     final int[] mtfFreq = new int['Ă'];
/* 1278 */     final byte[] selector = new byte['䙒'];
/* 1279 */     final byte[] selectorMtf = new byte['䙒'];
/*      */     
/* 1281 */     final byte[] generateMTFValues_yy = new byte['Ā'];
/* 1282 */     final byte[][] sendMTFValues_len = new byte[6]['Ă'];
/*      */     
/* 1284 */     final int[][] sendMTFValues_rfreq = new int[6]['Ă'];
/*      */     
/* 1286 */     final int[] sendMTFValues_fave = new int[6];
/* 1287 */     final short[] sendMTFValues_cost = new short[6];
/* 1288 */     final int[][] sendMTFValues_code = new int[6]['Ă'];
/*      */     
/* 1290 */     final byte[] sendMTFValues2_pos = new byte[6];
/* 1291 */     final boolean[] sentMTFValues4_inUse16 = new boolean[16];
/*      */     
/* 1293 */     final int[] heap = new int['Ą'];
/* 1294 */     final int[] weight = new int['Ȅ'];
/* 1295 */     final int[] parent = new int['Ȅ'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     final byte[] block;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     final int[] fmap;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     final char[] sfmap;
/*      */     
/*      */ 
/*      */ 
/*      */     int origPtr;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     Data(int blockSize100k)
/*      */     {
/* 1321 */       int n = blockSize100k * 100000;
/* 1322 */       this.block = new byte[n + 1 + 20];
/* 1323 */       this.fmap = new int[n];
/* 1324 */       this.sfmap = new char[2 * n];
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\bzip2\BZip2CompressorOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */