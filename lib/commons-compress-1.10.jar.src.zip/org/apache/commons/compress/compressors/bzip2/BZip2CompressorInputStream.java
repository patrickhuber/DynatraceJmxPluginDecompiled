/*      */ package org.apache.commons.compress.compressors.bzip2;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BZip2CompressorInputStream
/*      */   extends CompressorInputStream
/*      */   implements BZip2Constants
/*      */ {
/*      */   private int last;
/*      */   private int origPtr;
/*      */   private int blockSize100k;
/*      */   private boolean blockRandomised;
/*      */   private int bsBuff;
/*      */   private int bsLive;
/*   60 */   private final CRC crc = new CRC();
/*      */   
/*      */   private int nInUse;
/*      */   
/*      */   private InputStream in;
/*      */   
/*      */   private final boolean decompressConcatenated;
/*      */   
/*      */   private static final int EOF = 0;
/*      */   private static final int START_BLOCK_STATE = 1;
/*      */   private static final int RAND_PART_A_STATE = 2;
/*      */   private static final int RAND_PART_B_STATE = 3;
/*      */   private static final int RAND_PART_C_STATE = 4;
/*      */   private static final int NO_RAND_PART_A_STATE = 5;
/*      */   private static final int NO_RAND_PART_B_STATE = 6;
/*      */   private static final int NO_RAND_PART_C_STATE = 7;
/*   76 */   private int currentState = 1;
/*      */   
/*      */   private int storedBlockCRC;
/*      */   
/*      */   private int storedCombinedCRC;
/*      */   
/*      */   private int computedBlockCRC;
/*      */   
/*      */   private int computedCombinedCRC;
/*      */   
/*      */   private int su_count;
/*      */   
/*      */   private int su_ch2;
/*      */   
/*      */   private int su_chPrev;
/*      */   
/*      */   private int su_i2;
/*      */   
/*      */   private int su_j2;
/*      */   
/*      */   private int su_rNToGo;
/*      */   
/*      */   private int su_rTPos;
/*      */   
/*      */   private int su_tPos;
/*      */   
/*      */   private char su_z;
/*      */   
/*      */   private Data data;
/*      */   
/*      */ 
/*      */   public BZip2CompressorInputStream(InputStream in)
/*      */     throws IOException
/*      */   {
/*  110 */     this(in, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public BZip2CompressorInputStream(InputStream in, boolean decompressConcatenated)
/*      */     throws IOException
/*      */   {
/*  130 */     this.in = in;
/*  131 */     this.decompressConcatenated = decompressConcatenated;
/*      */     
/*  133 */     init(true);
/*  134 */     initBlock();
/*      */   }
/*      */   
/*      */   public int read() throws IOException
/*      */   {
/*  139 */     if (this.in != null) {
/*  140 */       int r = read0();
/*  141 */       count(r < 0 ? -1 : 1);
/*  142 */       return r;
/*      */     }
/*  144 */     throw new IOException("stream closed");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int read(byte[] dest, int offs, int len)
/*      */     throws IOException
/*      */   {
/*  156 */     if (offs < 0) {
/*  157 */       throw new IndexOutOfBoundsException("offs(" + offs + ") < 0.");
/*      */     }
/*  159 */     if (len < 0) {
/*  160 */       throw new IndexOutOfBoundsException("len(" + len + ") < 0.");
/*      */     }
/*  162 */     if (offs + len > dest.length) {
/*  163 */       throw new IndexOutOfBoundsException("offs(" + offs + ") + len(" + len + ") > dest.length(" + dest.length + ").");
/*      */     }
/*      */     
/*  166 */     if (this.in == null) {
/*  167 */       throw new IOException("stream closed");
/*      */     }
/*  169 */     if (len == 0) {
/*  170 */       return 0;
/*      */     }
/*      */     
/*  173 */     int hi = offs + len;
/*  174 */     int destOffs = offs;
/*      */     int b;
/*  176 */     while ((destOffs < hi) && ((b = read0()) >= 0)) {
/*  177 */       dest[(destOffs++)] = ((byte)b);
/*  178 */       count(1);
/*      */     }
/*      */     
/*  181 */     int c = destOffs == offs ? -1 : destOffs - offs;
/*  182 */     return c;
/*      */   }
/*      */   
/*      */   private void makeMaps() {
/*  186 */     boolean[] inUse = this.data.inUse;
/*  187 */     byte[] seqToUnseq = this.data.seqToUnseq;
/*      */     
/*  189 */     int nInUseShadow = 0;
/*      */     
/*  191 */     for (int i = 0; i < 256; i++) {
/*  192 */       if (inUse[i] != 0) {
/*  193 */         seqToUnseq[(nInUseShadow++)] = ((byte)i);
/*      */       }
/*      */     }
/*      */     
/*  197 */     this.nInUse = nInUseShadow;
/*      */   }
/*      */   
/*      */   private int read0() throws IOException {
/*  201 */     switch (this.currentState) {
/*      */     case 0: 
/*  203 */       return -1;
/*      */     
/*      */     case 1: 
/*  206 */       return setupBlock();
/*      */     
/*      */     case 2: 
/*  209 */       throw new IllegalStateException();
/*      */     
/*      */     case 3: 
/*  212 */       return setupRandPartB();
/*      */     
/*      */     case 4: 
/*  215 */       return setupRandPartC();
/*      */     
/*      */     case 5: 
/*  218 */       throw new IllegalStateException();
/*      */     
/*      */     case 6: 
/*  221 */       return setupNoRandPartB();
/*      */     
/*      */     case 7: 
/*  224 */       return setupNoRandPartC();
/*      */     }
/*      */     
/*  227 */     throw new IllegalStateException();
/*      */   }
/*      */   
/*      */   private boolean init(boolean isFirstStream) throws IOException
/*      */   {
/*  232 */     if (null == this.in) {
/*  233 */       throw new IOException("No InputStream");
/*      */     }
/*      */     
/*  236 */     int magic0 = this.in.read();
/*  237 */     if ((magic0 == -1) && (!isFirstStream)) {
/*  238 */       return false;
/*      */     }
/*  240 */     int magic1 = this.in.read();
/*  241 */     int magic2 = this.in.read();
/*      */     
/*  243 */     if ((magic0 != 66) || (magic1 != 90) || (magic2 != 104)) {
/*  244 */       throw new IOException(isFirstStream ? "Stream is not in the BZip2 format" : "Garbage after a valid BZip2 stream");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  249 */     int blockSize = this.in.read();
/*  250 */     if ((blockSize < 49) || (blockSize > 57)) {
/*  251 */       throw new IOException("BZip2 block size is invalid");
/*      */     }
/*      */     
/*  254 */     this.blockSize100k = (blockSize - 48);
/*      */     
/*  256 */     this.bsLive = 0;
/*  257 */     this.computedCombinedCRC = 0;
/*      */     
/*  259 */     return true;
/*      */   }
/*      */   
/*      */   private void initBlock() throws IOException
/*      */   {
/*      */     char magic0;
/*      */     char magic1;
/*      */     char magic2;
/*      */     char magic3;
/*      */     char magic4;
/*      */     char magic5;
/*      */     do
/*      */     {
/*  272 */       magic0 = bsGetUByte();
/*  273 */       magic1 = bsGetUByte();
/*  274 */       magic2 = bsGetUByte();
/*  275 */       magic3 = bsGetUByte();
/*  276 */       magic4 = bsGetUByte();
/*  277 */       magic5 = bsGetUByte();
/*      */       
/*      */ 
/*  280 */       if ((magic0 != '\027') || (magic1 != 'r') || (magic2 != 'E') || (magic3 != '8') || (magic4 != 'P') || (magic5 != ''))
/*      */       {
/*      */         break;
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*  288 */     while (!complete());
/*  289 */     return;
/*      */     
/*      */ 
/*      */ 
/*  293 */     if ((magic0 != '1') || (magic1 != 'A') || (magic2 != 'Y') || (magic3 != '&') || (magic4 != 'S') || (magic5 != 'Y'))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  300 */       this.currentState = 0;
/*  301 */       throw new IOException("bad block header");
/*      */     }
/*  303 */     this.storedBlockCRC = bsGetInt();
/*  304 */     this.blockRandomised = (bsR(1) == 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  310 */     if (this.data == null) {
/*  311 */       this.data = new Data(this.blockSize100k);
/*      */     }
/*      */     
/*      */ 
/*  315 */     getAndMoveToFrontDecode();
/*      */     
/*  317 */     this.crc.initialiseCRC();
/*  318 */     this.currentState = 1;
/*      */   }
/*      */   
/*      */   private void endBlock() throws IOException
/*      */   {
/*  323 */     this.computedBlockCRC = this.crc.getFinalCRC();
/*      */     
/*      */ 
/*  326 */     if (this.storedBlockCRC != this.computedBlockCRC)
/*      */     {
/*      */ 
/*  329 */       this.computedCombinedCRC = (this.storedCombinedCRC << 1 | this.storedCombinedCRC >>> 31);
/*      */       
/*  331 */       this.computedCombinedCRC ^= this.storedBlockCRC;
/*      */       
/*  333 */       throw new IOException("BZip2 CRC error");
/*      */     }
/*      */     
/*  336 */     this.computedCombinedCRC = (this.computedCombinedCRC << 1 | this.computedCombinedCRC >>> 31);
/*      */     
/*  338 */     this.computedCombinedCRC ^= this.computedBlockCRC;
/*      */   }
/*      */   
/*      */   private boolean complete() throws IOException {
/*  342 */     this.storedCombinedCRC = bsGetInt();
/*  343 */     this.currentState = 0;
/*  344 */     this.data = null;
/*      */     
/*  346 */     if (this.storedCombinedCRC != this.computedCombinedCRC) {
/*  347 */       throw new IOException("BZip2 CRC error");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  352 */     return (!this.decompressConcatenated) || (!init(false));
/*      */   }
/*      */   
/*      */   public void close() throws IOException
/*      */   {
/*  357 */     InputStream inShadow = this.in;
/*  358 */     if (inShadow != null) {
/*      */       try {
/*  360 */         if (inShadow != System.in) {
/*  361 */           inShadow.close();
/*      */         }
/*      */       } finally {
/*  364 */         this.data = null;
/*  365 */         this.in = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private int bsR(int n) throws IOException {
/*  371 */     int bsLiveShadow = this.bsLive;
/*  372 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  374 */     if (bsLiveShadow < n) {
/*  375 */       InputStream inShadow = this.in;
/*      */       do {
/*  377 */         int thech = inShadow.read();
/*      */         
/*  379 */         if (thech < 0) {
/*  380 */           throw new IOException("unexpected end of stream");
/*      */         }
/*      */         
/*  383 */         bsBuffShadow = bsBuffShadow << 8 | thech;
/*  384 */         bsLiveShadow += 8;
/*  385 */       } while (bsLiveShadow < n);
/*      */       
/*  387 */       this.bsBuff = bsBuffShadow;
/*      */     }
/*      */     
/*  390 */     this.bsLive = (bsLiveShadow - n);
/*  391 */     return bsBuffShadow >> bsLiveShadow - n & (1 << n) - 1;
/*      */   }
/*      */   
/*      */   private boolean bsGetBit() throws IOException {
/*  395 */     int bsLiveShadow = this.bsLive;
/*  396 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  398 */     if (bsLiveShadow < 1) {
/*  399 */       int thech = this.in.read();
/*      */       
/*  401 */       if (thech < 0) {
/*  402 */         throw new IOException("unexpected end of stream");
/*      */       }
/*      */       
/*  405 */       bsBuffShadow = bsBuffShadow << 8 | thech;
/*  406 */       bsLiveShadow += 8;
/*  407 */       this.bsBuff = bsBuffShadow;
/*      */     }
/*      */     
/*  410 */     this.bsLive = (bsLiveShadow - 1);
/*  411 */     return (bsBuffShadow >> bsLiveShadow - 1 & 0x1) != 0;
/*      */   }
/*      */   
/*      */   private char bsGetUByte() throws IOException {
/*  415 */     return (char)bsR(8);
/*      */   }
/*      */   
/*      */   private int bsGetInt() throws IOException {
/*  419 */     return ((bsR(8) << 8 | bsR(8)) << 8 | bsR(8)) << 8 | bsR(8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static void hbCreateDecodeTables(int[] limit, int[] base, int[] perm, char[] length, int minLen, int maxLen, int alphaSize)
/*      */   {
/*  428 */     int i = minLen; for (int pp = 0; i <= maxLen; i++) {
/*  429 */       for (int j = 0; j < alphaSize; j++) {
/*  430 */         if (length[j] == i) {
/*  431 */           perm[(pp++)] = j;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  436 */     int i = 23; for (;;) { i--; if (i <= 0) break;
/*  437 */       base[i] = 0;
/*  438 */       limit[i] = 0;
/*      */     }
/*      */     
/*  441 */     for (int i = 0; i < alphaSize; i++) {
/*  442 */       base[(length[i] + '\001')] += 1;
/*      */     }
/*      */     
/*  445 */     int i = 1; for (int b = base[0]; i < 23; i++) {
/*  446 */       b += base[i];
/*  447 */       base[i] = b;
/*      */     }
/*      */     
/*  450 */     int i = minLen;int vec = 0; for (int b = base[i]; i <= maxLen; i++) {
/*  451 */       int nb = base[(i + 1)];
/*  452 */       vec += nb - b;
/*  453 */       b = nb;
/*  454 */       limit[i] = (vec - 1);
/*  455 */       vec <<= 1;
/*      */     }
/*      */     
/*  458 */     for (int i = minLen + 1; i <= maxLen; i++) {
/*  459 */       base[i] = ((limit[(i - 1)] + 1 << 1) - base[i]);
/*      */     }
/*      */   }
/*      */   
/*      */   private void recvDecodingTables() throws IOException {
/*  464 */     Data dataShadow = this.data;
/*  465 */     boolean[] inUse = dataShadow.inUse;
/*  466 */     byte[] pos = dataShadow.recvDecodingTables_pos;
/*  467 */     byte[] selector = dataShadow.selector;
/*  468 */     byte[] selectorMtf = dataShadow.selectorMtf;
/*      */     
/*  470 */     int inUse16 = 0;
/*      */     
/*      */ 
/*  473 */     for (int i = 0; i < 16; i++) {
/*  474 */       if (bsGetBit()) {
/*  475 */         inUse16 |= 1 << i;
/*      */       }
/*      */     }
/*      */     
/*  479 */     int i = 256; for (;;) { i--; if (i < 0) break;
/*  480 */       inUse[i] = false;
/*      */     }
/*      */     
/*  483 */     for (int i = 0; i < 16; i++) {
/*  484 */       if ((inUse16 & 1 << i) != 0) {
/*  485 */         int i16 = i << 4;
/*  486 */         for (int j = 0; j < 16; j++) {
/*  487 */           if (bsGetBit()) {
/*  488 */             inUse[(i16 + j)] = true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  494 */     makeMaps();
/*  495 */     int alphaSize = this.nInUse + 2;
/*      */     
/*      */ 
/*  498 */     int nGroups = bsR(3);
/*  499 */     int nSelectors = bsR(15);
/*      */     
/*  501 */     for (int i = 0; i < nSelectors; i++) {
/*  502 */       int j = 0;
/*  503 */       while (bsGetBit()) {
/*  504 */         j++;
/*      */       }
/*  506 */       selectorMtf[i] = ((byte)j);
/*      */     }
/*      */     
/*      */ 
/*  510 */     int v = nGroups; for (;;) { v--; if (v < 0) break;
/*  511 */       pos[v] = ((byte)v);
/*      */     }
/*      */     
/*  514 */     for (int i = 0; i < nSelectors; i++) {
/*  515 */       int v = selectorMtf[i] & 0xFF;
/*  516 */       byte tmp = pos[v];
/*  517 */       while (v > 0)
/*      */       {
/*  519 */         pos[v] = pos[(v - 1)];
/*  520 */         v--;
/*      */       }
/*  522 */       pos[0] = tmp;
/*  523 */       selector[i] = tmp;
/*      */     }
/*      */     
/*  526 */     char[][] len = dataShadow.temp_charArray2d;
/*      */     
/*      */ 
/*  529 */     for (int t = 0; t < nGroups; t++) {
/*  530 */       int curr = bsR(5);
/*  531 */       char[] len_t = len[t];
/*  532 */       for (int i = 0; i < alphaSize; i++) {
/*  533 */         while (bsGetBit()) {
/*  534 */           curr += (bsGetBit() ? -1 : 1);
/*      */         }
/*  536 */         len_t[i] = ((char)curr);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  541 */     createHuffmanDecodingTables(alphaSize, nGroups);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createHuffmanDecodingTables(int alphaSize, int nGroups)
/*      */   {
/*  549 */     Data dataShadow = this.data;
/*  550 */     char[][] len = dataShadow.temp_charArray2d;
/*  551 */     int[] minLens = dataShadow.minLens;
/*  552 */     int[][] limit = dataShadow.limit;
/*  553 */     int[][] base = dataShadow.base;
/*  554 */     int[][] perm = dataShadow.perm;
/*      */     
/*  556 */     for (int t = 0; t < nGroups; t++) {
/*  557 */       int minLen = 32;
/*  558 */       int maxLen = 0;
/*  559 */       char[] len_t = len[t];
/*  560 */       int i = alphaSize; for (;;) { i--; if (i < 0) break;
/*  561 */         char lent = len_t[i];
/*  562 */         if (lent > maxLen) {
/*  563 */           maxLen = lent;
/*      */         }
/*  565 */         if (lent < minLen) {
/*  566 */           minLen = lent;
/*      */         }
/*      */       }
/*  569 */       hbCreateDecodeTables(limit[t], base[t], perm[t], len[t], minLen, maxLen, alphaSize);
/*      */       
/*  571 */       minLens[t] = minLen;
/*      */     }
/*      */   }
/*      */   
/*      */   private void getAndMoveToFrontDecode() throws IOException {
/*  576 */     this.origPtr = bsR(24);
/*  577 */     recvDecodingTables();
/*      */     
/*  579 */     InputStream inShadow = this.in;
/*  580 */     Data dataShadow = this.data;
/*  581 */     byte[] ll8 = dataShadow.ll8;
/*  582 */     int[] unzftab = dataShadow.unzftab;
/*  583 */     byte[] selector = dataShadow.selector;
/*  584 */     byte[] seqToUnseq = dataShadow.seqToUnseq;
/*  585 */     char[] yy = dataShadow.getAndMoveToFrontDecode_yy;
/*  586 */     int[] minLens = dataShadow.minLens;
/*  587 */     int[][] limit = dataShadow.limit;
/*  588 */     int[][] base = dataShadow.base;
/*  589 */     int[][] perm = dataShadow.perm;
/*  590 */     int limitLast = this.blockSize100k * 100000;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  597 */     int i = 256; for (;;) { i--; if (i < 0) break;
/*  598 */       yy[i] = ((char)i);
/*  599 */       unzftab[i] = 0;
/*      */     }
/*      */     
/*  602 */     int groupNo = 0;
/*  603 */     int groupPos = 49;
/*  604 */     int eob = this.nInUse + 1;
/*  605 */     int nextSym = getAndMoveToFrontDecode0(0);
/*  606 */     int bsBuffShadow = this.bsBuff;
/*  607 */     int bsLiveShadow = this.bsLive;
/*  608 */     int lastShadow = -1;
/*  609 */     int zt = selector[groupNo] & 0xFF;
/*  610 */     int[] base_zt = base[zt];
/*  611 */     int[] limit_zt = limit[zt];
/*  612 */     int[] perm_zt = perm[zt];
/*  613 */     int minLens_zt = minLens[zt];
/*      */     
/*  615 */     while (nextSym != eob) {
/*  616 */       if ((nextSym == 0) || (nextSym == 1)) {
/*  617 */         int s = -1;
/*      */         
/*  619 */         for (int n = 1;; n <<= 1) {
/*  620 */           if (nextSym == 0) {
/*  621 */             s += n;
/*  622 */           } else { if (nextSym != 1) break;
/*  623 */             s += (n << 1);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  628 */           if (groupPos == 0) {
/*  629 */             groupPos = 49;
/*  630 */             zt = selector[(++groupNo)] & 0xFF;
/*  631 */             base_zt = base[zt];
/*  632 */             limit_zt = limit[zt];
/*  633 */             perm_zt = perm[zt];
/*  634 */             minLens_zt = minLens[zt];
/*      */           } else {
/*  636 */             groupPos--;
/*      */           }
/*      */           
/*  639 */           int zn = minLens_zt;
/*      */           
/*      */ 
/*      */ 
/*  643 */           while (bsLiveShadow < zn) {
/*  644 */             int thech = inShadow.read();
/*  645 */             if (thech >= 0) {
/*  646 */               bsBuffShadow = bsBuffShadow << 8 | thech;
/*  647 */               bsLiveShadow += 8;
/*      */             }
/*      */             else {
/*  650 */               throw new IOException("unexpected end of stream");
/*      */             }
/*      */           }
/*  653 */           int zvec = bsBuffShadow >> bsLiveShadow - zn & (1 << zn) - 1;
/*      */           
/*  655 */           bsLiveShadow -= zn;
/*      */           
/*  657 */           while (zvec > limit_zt[zn]) {
/*  658 */             zn++;
/*  659 */             while (bsLiveShadow < 1) {
/*  660 */               int thech = inShadow.read();
/*  661 */               if (thech >= 0) {
/*  662 */                 bsBuffShadow = bsBuffShadow << 8 | thech;
/*  663 */                 bsLiveShadow += 8;
/*      */               }
/*      */               else {
/*  666 */                 throw new IOException("unexpected end of stream");
/*      */               }
/*      */             }
/*      */             
/*  670 */             bsLiveShadow--;
/*  671 */             zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */           }
/*      */           
/*  674 */           nextSym = perm_zt[(zvec - base_zt[zn])];
/*      */         }
/*      */         
/*  677 */         byte ch = seqToUnseq[yy[0]];
/*  678 */         unzftab[(ch & 0xFF)] += s + 1;
/*      */         
/*  680 */         while (s-- >= 0) {
/*  681 */           ll8[(++lastShadow)] = ch;
/*      */         }
/*      */         
/*  684 */         if (lastShadow >= limitLast) {
/*  685 */           throw new IOException("block overrun");
/*      */         }
/*      */       } else {
/*  688 */         lastShadow++; if (lastShadow >= limitLast) {
/*  689 */           throw new IOException("block overrun");
/*      */         }
/*      */         
/*  692 */         char tmp = yy[(nextSym - 1)];
/*  693 */         unzftab[(seqToUnseq[tmp] & 0xFF)] += 1;
/*  694 */         ll8[lastShadow] = seqToUnseq[tmp];
/*      */         
/*      */ 
/*      */ 
/*      */         int j;
/*      */         
/*      */ 
/*  701 */         if (nextSym <= 16) {
/*  702 */           for (j = nextSym - 1; j > 0;) {
/*  703 */             yy[j] = yy[(--j)];
/*      */           }
/*      */         } else {
/*  706 */           System.arraycopy(yy, 0, yy, 1, nextSym - 1);
/*      */         }
/*      */         
/*  709 */         yy[0] = tmp;
/*      */         
/*  711 */         if (groupPos == 0) {
/*  712 */           groupPos = 49;
/*  713 */           zt = selector[(++groupNo)] & 0xFF;
/*  714 */           base_zt = base[zt];
/*  715 */           limit_zt = limit[zt];
/*  716 */           perm_zt = perm[zt];
/*  717 */           minLens_zt = minLens[zt];
/*      */         } else {
/*  719 */           groupPos--;
/*      */         }
/*      */         
/*  722 */         int zn = minLens_zt;
/*      */         
/*      */ 
/*      */ 
/*  726 */         while (bsLiveShadow < zn) {
/*  727 */           int thech = inShadow.read();
/*  728 */           if (thech >= 0) {
/*  729 */             bsBuffShadow = bsBuffShadow << 8 | thech;
/*  730 */             bsLiveShadow += 8;
/*      */           }
/*      */           else {
/*  733 */             throw new IOException("unexpected end of stream");
/*      */           }
/*      */         }
/*  736 */         int zvec = bsBuffShadow >> bsLiveShadow - zn & (1 << zn) - 1;
/*      */         
/*  738 */         bsLiveShadow -= zn;
/*      */         
/*  740 */         while (zvec > limit_zt[zn]) {
/*  741 */           zn++;
/*  742 */           while (bsLiveShadow < 1) {
/*  743 */             int thech = inShadow.read();
/*  744 */             if (thech >= 0) {
/*  745 */               bsBuffShadow = bsBuffShadow << 8 | thech;
/*  746 */               bsLiveShadow += 8;
/*      */             }
/*      */             else {
/*  749 */               throw new IOException("unexpected end of stream");
/*      */             }
/*      */           }
/*  752 */           bsLiveShadow--;
/*  753 */           zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */         }
/*  755 */         nextSym = perm_zt[(zvec - base_zt[zn])];
/*      */       }
/*      */     }
/*      */     
/*  759 */     this.last = lastShadow;
/*  760 */     this.bsLive = bsLiveShadow;
/*  761 */     this.bsBuff = bsBuffShadow;
/*      */   }
/*      */   
/*      */   private int getAndMoveToFrontDecode0(int groupNo) throws IOException {
/*  765 */     InputStream inShadow = this.in;
/*  766 */     Data dataShadow = this.data;
/*  767 */     int zt = dataShadow.selector[groupNo] & 0xFF;
/*  768 */     int[] limit_zt = dataShadow.limit[zt];
/*  769 */     int zn = dataShadow.minLens[zt];
/*  770 */     int zvec = bsR(zn);
/*  771 */     int bsLiveShadow = this.bsLive;
/*  772 */     int bsBuffShadow = this.bsBuff;
/*      */     
/*  774 */     while (zvec > limit_zt[zn]) {
/*  775 */       zn++;
/*  776 */       while (bsLiveShadow < 1) {
/*  777 */         int thech = inShadow.read();
/*      */         
/*  779 */         if (thech >= 0) {
/*  780 */           bsBuffShadow = bsBuffShadow << 8 | thech;
/*  781 */           bsLiveShadow += 8;
/*      */         }
/*      */         else {
/*  784 */           throw new IOException("unexpected end of stream");
/*      */         }
/*      */       }
/*  787 */       bsLiveShadow--;
/*  788 */       zvec = zvec << 1 | bsBuffShadow >> bsLiveShadow & 0x1;
/*      */     }
/*      */     
/*  791 */     this.bsLive = bsLiveShadow;
/*  792 */     this.bsBuff = bsBuffShadow;
/*      */     
/*  794 */     return dataShadow.perm[zt][(zvec - dataShadow.base[zt][zn])];
/*      */   }
/*      */   
/*      */   private int setupBlock() throws IOException {
/*  798 */     if ((this.currentState == 0) || (this.data == null)) {
/*  799 */       return -1;
/*      */     }
/*      */     
/*  802 */     int[] cftab = this.data.cftab;
/*  803 */     int[] tt = this.data.initTT(this.last + 1);
/*  804 */     byte[] ll8 = this.data.ll8;
/*  805 */     cftab[0] = 0;
/*  806 */     System.arraycopy(this.data.unzftab, 0, cftab, 1, 256);
/*      */     
/*  808 */     int i = 1; for (int c = cftab[0]; i <= 256; i++) {
/*  809 */       c += cftab[i];
/*  810 */       cftab[i] = c;
/*      */     }
/*      */     
/*  813 */     int i = 0; for (int lastShadow = this.last; i <= lastShadow; i++) {
/*  814 */       byte tmp129_128 = (ll8[i] & 0xFF); int[] tmp129_120 = cftab; int tmp131_130 = tmp129_120[tmp129_128];tmp129_120[tmp129_128] = (tmp131_130 + 1);tt[tmp131_130] = i;
/*      */     }
/*      */     
/*  817 */     if ((this.origPtr < 0) || (this.origPtr >= tt.length)) {
/*  818 */       throw new IOException("stream corrupted");
/*      */     }
/*      */     
/*  821 */     this.su_tPos = tt[this.origPtr];
/*  822 */     this.su_count = 0;
/*  823 */     this.su_i2 = 0;
/*  824 */     this.su_ch2 = 256;
/*      */     
/*  826 */     if (this.blockRandomised) {
/*  827 */       this.su_rNToGo = 0;
/*  828 */       this.su_rTPos = 0;
/*  829 */       return setupRandPartA();
/*      */     }
/*  831 */     return setupNoRandPartA();
/*      */   }
/*      */   
/*      */   private int setupRandPartA() throws IOException {
/*  835 */     if (this.su_i2 <= this.last) {
/*  836 */       this.su_chPrev = this.su_ch2;
/*  837 */       int su_ch2Shadow = this.data.ll8[this.su_tPos] & 0xFF;
/*  838 */       this.su_tPos = this.data.tt[this.su_tPos];
/*  839 */       if (this.su_rNToGo == 0) {
/*  840 */         this.su_rNToGo = (Rand.rNums(this.su_rTPos) - 1);
/*  841 */         if (++this.su_rTPos == 512) {
/*  842 */           this.su_rTPos = 0;
/*      */         }
/*      */       } else {
/*  845 */         this.su_rNToGo -= 1;
/*      */       }
/*  847 */       this.su_ch2 = (su_ch2Shadow ^= (this.su_rNToGo == 1 ? 1 : 0));
/*  848 */       this.su_i2 += 1;
/*  849 */       this.currentState = 3;
/*  850 */       this.crc.updateCRC(su_ch2Shadow);
/*  851 */       return su_ch2Shadow;
/*      */     }
/*  853 */     endBlock();
/*  854 */     initBlock();
/*  855 */     return setupBlock();
/*      */   }
/*      */   
/*      */   private int setupNoRandPartA() throws IOException
/*      */   {
/*  860 */     if (this.su_i2 <= this.last) {
/*  861 */       this.su_chPrev = this.su_ch2;
/*  862 */       int su_ch2Shadow = this.data.ll8[this.su_tPos] & 0xFF;
/*  863 */       this.su_ch2 = su_ch2Shadow;
/*  864 */       this.su_tPos = this.data.tt[this.su_tPos];
/*  865 */       this.su_i2 += 1;
/*  866 */       this.currentState = 6;
/*  867 */       this.crc.updateCRC(su_ch2Shadow);
/*  868 */       return su_ch2Shadow;
/*      */     }
/*  870 */     this.currentState = 5;
/*  871 */     endBlock();
/*  872 */     initBlock();
/*  873 */     return setupBlock();
/*      */   }
/*      */   
/*      */   private int setupRandPartB() throws IOException
/*      */   {
/*  878 */     if (this.su_ch2 != this.su_chPrev) {
/*  879 */       this.currentState = 2;
/*  880 */       this.su_count = 1;
/*  881 */       return setupRandPartA(); }
/*  882 */     if (++this.su_count >= 4) {
/*  883 */       this.su_z = ((char)(this.data.ll8[this.su_tPos] & 0xFF));
/*  884 */       this.su_tPos = this.data.tt[this.su_tPos];
/*  885 */       if (this.su_rNToGo == 0) {
/*  886 */         this.su_rNToGo = (Rand.rNums(this.su_rTPos) - 1);
/*  887 */         if (++this.su_rTPos == 512) {
/*  888 */           this.su_rTPos = 0;
/*      */         }
/*      */       } else {
/*  891 */         this.su_rNToGo -= 1;
/*      */       }
/*  893 */       this.su_j2 = 0;
/*  894 */       this.currentState = 4;
/*  895 */       if (this.su_rNToGo == 1) {
/*  896 */         this.su_z = ((char)(this.su_z ^ 0x1));
/*      */       }
/*  898 */       return setupRandPartC();
/*      */     }
/*  900 */     this.currentState = 2;
/*  901 */     return setupRandPartA();
/*      */   }
/*      */   
/*      */   private int setupRandPartC() throws IOException
/*      */   {
/*  906 */     if (this.su_j2 < this.su_z) {
/*  907 */       this.crc.updateCRC(this.su_ch2);
/*  908 */       this.su_j2 += 1;
/*  909 */       return this.su_ch2;
/*      */     }
/*  911 */     this.currentState = 2;
/*  912 */     this.su_i2 += 1;
/*  913 */     this.su_count = 0;
/*  914 */     return setupRandPartA();
/*      */   }
/*      */   
/*      */   private int setupNoRandPartB() throws IOException
/*      */   {
/*  919 */     if (this.su_ch2 != this.su_chPrev) {
/*  920 */       this.su_count = 1;
/*  921 */       return setupNoRandPartA(); }
/*  922 */     if (++this.su_count >= 4) {
/*  923 */       this.su_z = ((char)(this.data.ll8[this.su_tPos] & 0xFF));
/*  924 */       this.su_tPos = this.data.tt[this.su_tPos];
/*  925 */       this.su_j2 = 0;
/*  926 */       return setupNoRandPartC();
/*      */     }
/*  928 */     return setupNoRandPartA();
/*      */   }
/*      */   
/*      */   private int setupNoRandPartC() throws IOException
/*      */   {
/*  933 */     if (this.su_j2 < this.su_z) {
/*  934 */       int su_ch2Shadow = this.su_ch2;
/*  935 */       this.crc.updateCRC(su_ch2Shadow);
/*  936 */       this.su_j2 += 1;
/*  937 */       this.currentState = 7;
/*  938 */       return su_ch2Shadow;
/*      */     }
/*  940 */     this.su_i2 += 1;
/*  941 */     this.su_count = 0;
/*  942 */     return setupNoRandPartA();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class Data
/*      */   {
/*  949 */     final boolean[] inUse = new boolean['Ā'];
/*      */     
/*  951 */     final byte[] seqToUnseq = new byte['Ā'];
/*  952 */     final byte[] selector = new byte['䙒'];
/*  953 */     final byte[] selectorMtf = new byte['䙒'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  959 */     final int[] unzftab = new int['Ā'];
/*      */     
/*  961 */     final int[][] limit = new int[6]['Ă'];
/*  962 */     final int[][] base = new int[6]['Ă'];
/*  963 */     final int[][] perm = new int[6]['Ă'];
/*  964 */     final int[] minLens = new int[6];
/*      */     
/*  966 */     final int[] cftab = new int['ā'];
/*  967 */     final char[] getAndMoveToFrontDecode_yy = new char['Ā'];
/*  968 */     final char[][] temp_charArray2d = new char[6]['Ă'];
/*      */     
/*  970 */     final byte[] recvDecodingTables_pos = new byte[6];
/*      */     
/*      */ 
/*      */     int[] tt;
/*      */     
/*      */ 
/*      */     byte[] ll8;
/*      */     
/*      */ 
/*      */ 
/*      */     Data(int blockSize100k)
/*      */     {
/*  982 */       this.ll8 = new byte[blockSize100k * 100000];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int[] initTT(int length)
/*      */     {
/*  993 */       int[] ttShadow = this.tt;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  999 */       if ((ttShadow == null) || (ttShadow.length < length)) {
/* 1000 */         this.tt = (ttShadow = new int[length]);
/*      */       }
/*      */       
/* 1003 */       return ttShadow;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean matches(byte[] signature, int length)
/*      */   {
/* 1021 */     if (length < 3) {
/* 1022 */       return false;
/*      */     }
/*      */     
/* 1025 */     if (signature[0] != 66) {
/* 1026 */       return false;
/*      */     }
/*      */     
/* 1029 */     if (signature[1] != 90) {
/* 1030 */       return false;
/*      */     }
/*      */     
/* 1033 */     if (signature[2] != 104) {
/* 1034 */       return false;
/*      */     }
/*      */     
/* 1037 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\bzip2\BZip2CompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */