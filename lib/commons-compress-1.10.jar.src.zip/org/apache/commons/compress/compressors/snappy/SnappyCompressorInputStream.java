/*     */ package org.apache.commons.compress.compressors.snappy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SnappyCompressorInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   private static final int TAG_MASK = 3;
/*     */   public static final int DEFAULT_BLOCK_SIZE = 32768;
/*     */   private final byte[] decompressBuf;
/*     */   private int writeIndex;
/*     */   private int readIndex;
/*     */   private final int blockSize;
/*     */   private final InputStream in;
/*     */   private final int size;
/*     */   private int uncompressedBytesRemaining;
/*  71 */   private final byte[] oneByte = new byte[1];
/*     */   
/*  73 */   private boolean endReached = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SnappyCompressorInputStream(InputStream is)
/*     */     throws IOException
/*     */   {
/*  84 */     this(is, 32768);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SnappyCompressorInputStream(InputStream is, int blockSize)
/*     */     throws IOException
/*     */   {
/*  99 */     this.in = is;
/* 100 */     this.blockSize = blockSize;
/* 101 */     this.decompressBuf = new byte[blockSize * 3];
/* 102 */     this.writeIndex = (this.readIndex = 0);
/* 103 */     this.uncompressedBytesRemaining = (this.size = (int)readSize());
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 109 */     return read(this.oneByte, 0, 1) == -1 ? -1 : this.oneByte[0] & 0xFF;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 115 */     this.in.close();
/*     */   }
/*     */   
/*     */ 
/*     */   public int available()
/*     */   {
/* 121 */     return this.writeIndex - this.readIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 129 */     if (this.endReached) {
/* 130 */       return -1;
/*     */     }
/* 132 */     int avail = available();
/* 133 */     if (len > avail) {
/* 134 */       fill(len - avail);
/*     */     }
/*     */     
/* 137 */     int readable = Math.min(len, available());
/* 138 */     System.arraycopy(this.decompressBuf, this.readIndex, b, off, readable);
/* 139 */     this.readIndex += readable;
/* 140 */     if (this.readIndex > this.blockSize) {
/* 141 */       slideBuffer();
/*     */     }
/* 143 */     return readable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fill(int len)
/*     */     throws IOException
/*     */   {
/* 153 */     if (this.uncompressedBytesRemaining == 0) {
/* 154 */       this.endReached = true;
/*     */     }
/* 156 */     int readNow = Math.min(len, this.uncompressedBytesRemaining);
/*     */     
/* 158 */     while (readNow > 0) {
/* 159 */       int b = readOneByte();
/* 160 */       int length = 0;
/* 161 */       long offset = 0L;
/*     */       
/* 163 */       switch (b & 0x3)
/*     */       {
/*     */ 
/*     */       case 0: 
/* 167 */         length = readLiteralLength(b);
/*     */         
/* 169 */         if (expandLiteral(length)) {
/*     */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       case 1: 
/* 185 */         length = 4 + (b >> 2 & 0x7);
/* 186 */         offset = (b & 0xE0) << 3;
/* 187 */         offset |= readOneByte();
/*     */         
/* 189 */         if (expandCopy(offset, length)) {
/*     */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       case 2: 
/* 204 */         length = (b >> 2) + 1;
/*     */         
/* 206 */         offset = readOneByte();
/* 207 */         offset |= readOneByte() << 8;
/*     */         
/* 209 */         if (expandCopy(offset, length)) {
/*     */           return;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       case 3: 
/* 223 */         length = (b >> 2) + 1;
/*     */         
/* 225 */         offset = readOneByte();
/* 226 */         offset |= readOneByte() << 8;
/* 227 */         offset |= readOneByte() << 16;
/* 228 */         offset |= readOneByte() << 24;
/*     */         
/* 230 */         if (expandCopy(offset, length)) {
/*     */           return;
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/* 236 */       readNow -= length;
/* 237 */       this.uncompressedBytesRemaining -= length;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void slideBuffer()
/*     */   {
/* 248 */     System.arraycopy(this.decompressBuf, this.blockSize, this.decompressBuf, 0, this.blockSize * 2);
/*     */     
/* 250 */     this.writeIndex -= this.blockSize;
/* 251 */     this.readIndex -= this.blockSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readLiteralLength(int b)
/*     */     throws IOException
/*     */   {
/*     */     int length;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 267 */     switch (b >> 2) {
/*     */     case 60: 
/* 269 */       length = readOneByte();
/* 270 */       break;
/*     */     case 61: 
/* 272 */       length = readOneByte();
/* 273 */       length |= readOneByte() << 8;
/* 274 */       break;
/*     */     case 62: 
/* 276 */       length = readOneByte();
/* 277 */       length |= readOneByte() << 8;
/* 278 */       length |= readOneByte() << 16;
/* 279 */       break;
/*     */     case 63: 
/* 281 */       length = readOneByte();
/* 282 */       length |= readOneByte() << 8;
/* 283 */       length |= readOneByte() << 16;
/* 284 */       length = (int)(length | readOneByte() << 24);
/* 285 */       break;
/*     */     default: 
/* 287 */       length = b >> 2;
/*     */     }
/*     */     
/*     */     
/* 291 */     return length + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean expandLiteral(int length)
/*     */     throws IOException
/*     */   {
/* 307 */     int bytesRead = IOUtils.readFully(this.in, this.decompressBuf, this.writeIndex, length);
/* 308 */     count(bytesRead);
/* 309 */     if (length != bytesRead) {
/* 310 */       throw new IOException("Premature end of stream");
/*     */     }
/*     */     
/* 313 */     this.writeIndex += length;
/* 314 */     return this.writeIndex >= 2 * this.blockSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean expandCopy(long off, int length)
/*     */     throws IOException
/*     */   {
/* 337 */     if (off > this.blockSize) {
/* 338 */       throw new IOException("Offset is larger than block size");
/*     */     }
/* 340 */     int offset = (int)off;
/*     */     
/* 342 */     if (offset == 1) {
/* 343 */       byte lastChar = this.decompressBuf[(this.writeIndex - 1)];
/* 344 */       for (int i = 0; i < length; i++) {
/* 345 */         this.decompressBuf[(this.writeIndex++)] = lastChar;
/*     */       }
/* 347 */     } else if (length < offset) {
/* 348 */       System.arraycopy(this.decompressBuf, this.writeIndex - offset, this.decompressBuf, this.writeIndex, length);
/*     */       
/* 350 */       this.writeIndex += length;
/*     */     } else {
/* 352 */       int fullRotations = length / offset;
/* 353 */       int pad = length - offset * fullRotations;
/*     */       
/* 355 */       while (fullRotations-- != 0) {
/* 356 */         System.arraycopy(this.decompressBuf, this.writeIndex - offset, this.decompressBuf, this.writeIndex, offset);
/*     */         
/* 358 */         this.writeIndex += offset;
/*     */       }
/*     */       
/* 361 */       if (pad > 0) {
/* 362 */         System.arraycopy(this.decompressBuf, this.writeIndex - offset, this.decompressBuf, this.writeIndex, pad);
/*     */         
/*     */ 
/* 365 */         this.writeIndex += pad;
/*     */       }
/*     */     }
/* 368 */     return this.writeIndex >= 2 * this.blockSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readOneByte()
/*     */     throws IOException
/*     */   {
/* 382 */     int b = this.in.read();
/* 383 */     if (b == -1) {
/* 384 */       throw new IOException("Premature end of stream");
/*     */     }
/* 386 */     count(1);
/* 387 */     return b & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private long readSize()
/*     */     throws IOException
/*     */   {
/* 404 */     int index = 0;
/* 405 */     long sz = 0L;
/* 406 */     int b = 0;
/*     */     do
/*     */     {
/* 409 */       b = readOneByte();
/* 410 */       sz |= (b & 0x7F) << index++ * 7;
/* 411 */     } while (0 != (b & 0x80));
/* 412 */     return sz;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSize()
/*     */   {
/* 421 */     return this.size;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\snappy\SnappyCompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */