/*     */ package org.apache.commons.compress.compressors.snappy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.compress.compressors.CompressorInputStream;
/*     */ import org.apache.commons.compress.utils.BoundedInputStream;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FramedSnappyCompressorInputStream
/*     */   extends CompressorInputStream
/*     */ {
/*     */   static final long MASK_OFFSET = 2726488792L;
/*     */   private static final int STREAM_IDENTIFIER_TYPE = 255;
/*     */   private static final int COMPRESSED_CHUNK_TYPE = 0;
/*     */   private static final int UNCOMPRESSED_CHUNK_TYPE = 1;
/*     */   private static final int PADDING_CHUNK_TYPE = 254;
/*     */   private static final int MIN_UNSKIPPABLE_TYPE = 2;
/*     */   private static final int MAX_UNSKIPPABLE_TYPE = 127;
/*     */   private static final int MAX_SKIPPABLE_TYPE = 253;
/*  52 */   private static final byte[] SZ_SIGNATURE = { -1, 6, 0, 0, 115, 78, 97, 80, 112, 89 };
/*     */   
/*     */ 
/*     */ 
/*     */   private final PushbackInputStream in;
/*     */   
/*     */ 
/*     */ 
/*     */   private SnappyCompressorInputStream currentCompressedChunk;
/*     */   
/*     */ 
/*     */ 
/*  64 */   private final byte[] oneByte = new byte[1];
/*     */   
/*     */   private boolean endReached;
/*     */   private boolean inUncompressedChunk;
/*     */   private int uncompressedBytesRemaining;
/*  69 */   private long expectedChecksum = -1L;
/*  70 */   private final PureJavaCrc32C checksum = new PureJavaCrc32C();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FramedSnappyCompressorInputStream(InputStream in)
/*     */     throws IOException
/*     */   {
/*  78 */     this.in = new PushbackInputStream(in, 1);
/*  79 */     readStreamIdentifier();
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  85 */     return read(this.oneByte, 0, 1) == -1 ? -1 : this.oneByte[0] & 0xFF;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  91 */     if (this.currentCompressedChunk != null) {
/*  92 */       this.currentCompressedChunk.close();
/*  93 */       this.currentCompressedChunk = null;
/*     */     }
/*  95 */     this.in.close();
/*     */   }
/*     */   
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 101 */     int read = readOnce(b, off, len);
/* 102 */     if (read == -1) {
/* 103 */       readNextBlock();
/* 104 */       if (this.endReached) {
/* 105 */         return -1;
/*     */       }
/* 107 */       read = readOnce(b, off, len);
/*     */     }
/* 109 */     return read;
/*     */   }
/*     */   
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 115 */     if (this.inUncompressedChunk) {
/* 116 */       return Math.min(this.uncompressedBytesRemaining, this.in.available());
/*     */     }
/* 118 */     if (this.currentCompressedChunk != null) {
/* 119 */       return this.currentCompressedChunk.available();
/*     */     }
/* 121 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readOnce(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 132 */     int read = -1;
/* 133 */     if (this.inUncompressedChunk) {
/* 134 */       int amount = Math.min(this.uncompressedBytesRemaining, len);
/* 135 */       if (amount == 0) {
/* 136 */         return -1;
/*     */       }
/* 138 */       read = this.in.read(b, off, amount);
/* 139 */       if (read != -1) {
/* 140 */         this.uncompressedBytesRemaining -= read;
/* 141 */         count(read);
/*     */       }
/* 143 */     } else if (this.currentCompressedChunk != null) {
/* 144 */       long before = this.currentCompressedChunk.getBytesRead();
/* 145 */       read = this.currentCompressedChunk.read(b, off, len);
/* 146 */       if (read == -1) {
/* 147 */         this.currentCompressedChunk.close();
/* 148 */         this.currentCompressedChunk = null;
/*     */       } else {
/* 150 */         count(this.currentCompressedChunk.getBytesRead() - before);
/*     */       }
/*     */     }
/* 153 */     if (read > 0) {
/* 154 */       this.checksum.update(b, off, read);
/*     */     }
/* 156 */     return read;
/*     */   }
/*     */   
/*     */   private void readNextBlock() throws IOException {
/* 160 */     verifyLastChecksumAndReset();
/* 161 */     this.inUncompressedChunk = false;
/* 162 */     int type = readOneByte();
/* 163 */     if (type == -1) {
/* 164 */       this.endReached = true;
/* 165 */     } else if (type == 255) {
/* 166 */       this.in.unread(type);
/* 167 */       pushedBackBytes(1L);
/* 168 */       readStreamIdentifier();
/* 169 */       readNextBlock();
/* 170 */     } else if ((type == 254) || ((type > 127) && (type <= 253)))
/*     */     {
/* 172 */       skipBlock();
/* 173 */       readNextBlock();
/* 174 */     } else { if ((type >= 2) && (type <= 127)) {
/* 175 */         throw new IOException("unskippable chunk with type " + type + " (hex " + Integer.toHexString(type) + ")" + " detected.");
/*     */       }
/*     */       
/* 178 */       if (type == 1) {
/* 179 */         this.inUncompressedChunk = true;
/* 180 */         this.uncompressedBytesRemaining = (readSize() - 4);
/* 181 */         this.expectedChecksum = unmask(readCrc());
/* 182 */       } else if (type == 0) {
/* 183 */         long size = readSize() - 4;
/* 184 */         this.expectedChecksum = unmask(readCrc());
/* 185 */         this.currentCompressedChunk = new SnappyCompressorInputStream(new BoundedInputStream(this.in, size));
/*     */         
/*     */ 
/* 188 */         count(this.currentCompressedChunk.getBytesRead());
/*     */       }
/*     */       else {
/* 191 */         throw new IOException("unknown chunk type " + type + " detected.");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private long readCrc() throws IOException {
/* 197 */     byte[] b = new byte[4];
/* 198 */     int read = IOUtils.readFully(this.in, b);
/* 199 */     count(read);
/* 200 */     if (read != 4) {
/* 201 */       throw new IOException("premature end of stream");
/*     */     }
/* 203 */     long crc = 0L;
/* 204 */     for (int i = 0; i < 4; i++) {
/* 205 */       crc |= (b[i] & 0xFF) << 8 * i;
/*     */     }
/* 207 */     return crc;
/*     */   }
/*     */   
/*     */ 
/*     */   static long unmask(long x)
/*     */   {
/* 213 */     x -= 2726488792L;
/* 214 */     x &= 0xFFFFFFFF;
/* 215 */     return (x >> 17 | x << 15) & 0xFFFFFFFF;
/*     */   }
/*     */   
/*     */   private int readSize() throws IOException {
/* 219 */     int b = 0;
/* 220 */     int sz = 0;
/* 221 */     for (int i = 0; i < 3; i++) {
/* 222 */       b = readOneByte();
/* 223 */       if (b == -1) {
/* 224 */         throw new IOException("premature end of stream");
/*     */       }
/* 226 */       sz |= b << i * 8;
/*     */     }
/* 228 */     return sz;
/*     */   }
/*     */   
/*     */   private void skipBlock() throws IOException {
/* 232 */     int size = readSize();
/* 233 */     long read = IOUtils.skip(this.in, size);
/* 234 */     count(read);
/* 235 */     if (read != size) {
/* 236 */       throw new IOException("premature end of stream");
/*     */     }
/*     */   }
/*     */   
/*     */   private void readStreamIdentifier() throws IOException {
/* 241 */     byte[] b = new byte[10];
/* 242 */     int read = IOUtils.readFully(this.in, b);
/* 243 */     count(read);
/* 244 */     if ((10 != read) || (!matches(b, 10))) {
/* 245 */       throw new IOException("Not a framed Snappy stream");
/*     */     }
/*     */   }
/*     */   
/*     */   private int readOneByte() throws IOException {
/* 250 */     int b = this.in.read();
/* 251 */     if (b != -1) {
/* 252 */       count(1);
/* 253 */       return b & 0xFF;
/*     */     }
/* 255 */     return -1;
/*     */   }
/*     */   
/*     */   private void verifyLastChecksumAndReset() throws IOException {
/* 259 */     if ((this.expectedChecksum >= 0L) && (this.expectedChecksum != this.checksum.getValue())) {
/* 260 */       throw new IOException("Checksum verification failed");
/*     */     }
/* 262 */     this.expectedChecksum = -1L;
/* 263 */     this.checksum.reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean matches(byte[] signature, int length)
/*     */   {
/* 277 */     if (length < SZ_SIGNATURE.length) {
/* 278 */       return false;
/*     */     }
/*     */     
/* 281 */     byte[] shortenedSig = signature;
/* 282 */     if (signature.length > SZ_SIGNATURE.length) {
/* 283 */       shortenedSig = new byte[SZ_SIGNATURE.length];
/* 284 */       System.arraycopy(signature, 0, shortenedSig, 0, SZ_SIGNATURE.length);
/*     */     }
/*     */     
/* 287 */     return Arrays.equals(shortenedSig, SZ_SIGNATURE);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\compressors\snappy\FramedSnappyCompressorInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */