/*    */ package org.apache.commons.compress.parallel;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileBasedScatterGatherBackingStore
/*    */   implements ScatterGatherBackingStore
/*    */ {
/*    */   private final File target;
/*    */   private final FileOutputStream os;
/*    */   private boolean closed;
/*    */   
/*    */   public FileBasedScatterGatherBackingStore(File target)
/*    */     throws FileNotFoundException
/*    */   {
/* 38 */     this.target = target;
/* 39 */     this.os = new FileOutputStream(target);
/*    */   }
/*    */   
/*    */   public InputStream getInputStream() throws IOException {
/* 43 */     return new FileInputStream(this.target);
/*    */   }
/*    */   
/*    */   public void closeForWriting() throws IOException
/*    */   {
/* 48 */     if (!this.closed) {
/* 49 */       this.os.close();
/* 50 */       this.closed = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public void writeOut(byte[] data, int offset, int length) throws IOException {
/* 55 */     this.os.write(data, offset, length);
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 59 */     closeForWriting();
/* 60 */     this.target.delete();
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\parallel\FileBasedScatterGatherBackingStore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */