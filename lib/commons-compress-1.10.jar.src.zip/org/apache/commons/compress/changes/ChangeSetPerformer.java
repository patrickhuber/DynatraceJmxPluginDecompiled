/*     */ package org.apache.commons.compress.changes;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.ArchiveInputStream;
/*     */ import org.apache.commons.compress.archivers.ArchiveOutputStream;
/*     */ import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.zip.ZipFile;
/*     */ import org.apache.commons.compress.utils.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChangeSetPerformer
/*     */ {
/*     */   private final Set<Change> changes;
/*     */   
/*     */   public ChangeSetPerformer(ChangeSet changeSet)
/*     */   {
/*  52 */     this.changes = changeSet.getChanges();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChangeSetResults perform(ArchiveInputStream in, ArchiveOutputStream out)
/*     */     throws IOException
/*     */   {
/*  72 */     return perform(new ArchiveInputStreamIterator(in), out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChangeSetResults perform(ZipFile in, ArchiveOutputStream out)
/*     */     throws IOException
/*     */   {
/*  93 */     return perform(new ZipFileIterator(in), out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ChangeSetResults perform(ArchiveEntryIterator entryIterator, ArchiveOutputStream out)
/*     */     throws IOException
/*     */   {
/* 114 */     ChangeSetResults results = new ChangeSetResults();
/*     */     
/* 116 */     Set<Change> workingSet = new LinkedHashSet(this.changes);
/*     */     
/* 118 */     for (Iterator<Change> it = workingSet.iterator(); it.hasNext();) {
/* 119 */       Change change = (Change)it.next();
/*     */       
/* 121 */       if ((change.type() == 2) && (change.isReplaceMode())) {
/* 122 */         copyStream(change.getInput(), out, change.getEntry());
/* 123 */         it.remove();
/* 124 */         results.addedFromChangeSet(change.getEntry().getName());
/*     */       }
/*     */     }
/*     */     
/* 128 */     while (entryIterator.hasNext()) {
/* 129 */       ArchiveEntry entry = entryIterator.next();
/* 130 */       boolean copy = true;
/*     */       
/* 132 */       for (Iterator<Change> it = workingSet.iterator(); it.hasNext();) {
/* 133 */         Change change = (Change)it.next();
/*     */         
/* 135 */         int type = change.type();
/* 136 */         String name = entry.getName();
/* 137 */         if ((type == 1) && (name != null)) {
/* 138 */           if (name.equals(change.targetFile())) {
/* 139 */             copy = false;
/* 140 */             it.remove();
/* 141 */             results.deleted(name);
/* 142 */             break;
/*     */           }
/* 144 */         } else if ((type == 4) && (name != null))
/*     */         {
/* 146 */           if (name.startsWith(change.targetFile() + "/")) {
/* 147 */             copy = false;
/* 148 */             results.deleted(name);
/* 149 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 154 */       if ((copy) && (!isDeletedLater(workingSet, entry)) && (!results.hasBeenAdded(entry.getName())))
/*     */       {
/*     */ 
/* 157 */         copyStream(entryIterator.getInputStream(), out, entry);
/* 158 */         results.addedFromStream(entry.getName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 163 */     for (Iterator<Change> it = workingSet.iterator(); it.hasNext();) {
/* 164 */       Change change = (Change)it.next();
/*     */       
/* 166 */       if ((change.type() == 2) && (!change.isReplaceMode()) && (!results.hasBeenAdded(change.getEntry().getName())))
/*     */       {
/*     */ 
/* 169 */         copyStream(change.getInput(), out, change.getEntry());
/* 170 */         it.remove();
/* 171 */         results.addedFromChangeSet(change.getEntry().getName());
/*     */       }
/*     */     }
/* 174 */     out.finish();
/* 175 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isDeletedLater(Set<Change> workingSet, ArchiveEntry entry)
/*     */   {
/* 188 */     String source = entry.getName();
/*     */     
/* 190 */     if (!workingSet.isEmpty()) {
/* 191 */       for (Change change : workingSet) {
/* 192 */         int type = change.type();
/* 193 */         String target = change.targetFile();
/* 194 */         if ((type == 1) && (source.equals(target))) {
/* 195 */           return true;
/*     */         }
/*     */         
/* 198 */         if ((type == 4) && (source.startsWith(target + "/"))) {
/* 199 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 203 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void copyStream(InputStream in, ArchiveOutputStream out, ArchiveEntry entry)
/*     */     throws IOException
/*     */   {
/* 220 */     out.putArchiveEntry(entry);
/* 221 */     IOUtils.copy(in, out);
/* 222 */     out.closeArchiveEntry();
/*     */   }
/*     */   
/*     */ 
/*     */   static abstract interface ArchiveEntryIterator
/*     */   {
/*     */     public abstract boolean hasNext()
/*     */       throws IOException;
/*     */     
/*     */     public abstract ArchiveEntry next();
/*     */     
/*     */     public abstract InputStream getInputStream()
/*     */       throws IOException;
/*     */   }
/*     */   
/*     */   private static class ArchiveInputStreamIterator
/*     */     implements ChangeSetPerformer.ArchiveEntryIterator
/*     */   {
/*     */     private final ArchiveInputStream in;
/*     */     private ArchiveEntry next;
/*     */     
/*     */     ArchiveInputStreamIterator(ArchiveInputStream in)
/*     */     {
/* 245 */       this.in = in;
/*     */     }
/*     */     
/* 248 */     public boolean hasNext() throws IOException { return (this.next = this.in.getNextEntry()) != null; }
/*     */     
/*     */     public ArchiveEntry next() {
/* 251 */       return this.next;
/*     */     }
/*     */     
/* 254 */     public InputStream getInputStream() { return this.in; }
/*     */   }
/*     */   
/*     */   private static class ZipFileIterator implements ChangeSetPerformer.ArchiveEntryIterator
/*     */   {
/*     */     private final ZipFile in;
/*     */     private final Enumeration<ZipArchiveEntry> nestedEnum;
/*     */     private ZipArchiveEntry current;
/*     */     
/*     */     ZipFileIterator(ZipFile in) {
/* 264 */       this.in = in;
/* 265 */       this.nestedEnum = in.getEntriesInPhysicalOrder();
/*     */     }
/*     */     
/* 268 */     public boolean hasNext() { return this.nestedEnum.hasMoreElements(); }
/*     */     
/*     */     public ArchiveEntry next() {
/* 271 */       return this.current = (ZipArchiveEntry)this.nestedEnum.nextElement();
/*     */     }
/*     */     
/* 274 */     public InputStream getInputStream() throws IOException { return this.in.getInputStream(this.current); }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-compress-1.10.jar!\org\apache\commons\compress\changes\ChangeSetPerformer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */