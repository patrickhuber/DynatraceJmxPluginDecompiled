/*    */ package org.apache.commons.lang3.concurrent;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AtomicSafeInitializer<T>
/*    */   implements ConcurrentInitializer<T>
/*    */ {
/* 59 */   private final AtomicReference<AtomicSafeInitializer<T>> factory = new AtomicReference();
/*    */   
/*    */ 
/*    */ 
/* 63 */   private final AtomicReference<T> reference = new AtomicReference();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final T get()
/*    */     throws ConcurrentException
/*    */   {
/*    */     T result;
/*    */     
/*    */ 
/*    */ 
/* 75 */     while ((result = this.reference.get()) == null) {
/* 76 */       if (this.factory.compareAndSet(null, this)) {
/* 77 */         this.reference.set(initialize());
/*    */       }
/*    */     }
/*    */     
/* 81 */     return result;
/*    */   }
/*    */   
/*    */   protected abstract T initialize()
/*    */     throws ConcurrentException;
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-lang3-3.1.jar!\org\apache\commons\lang3\concurrent\AtomicSafeInitializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */