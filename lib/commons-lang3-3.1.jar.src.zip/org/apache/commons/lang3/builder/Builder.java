package org.apache.commons.lang3.builder;

public abstract interface Builder<T>
{
  public abstract T build();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-lang3-3.1.jar!\org\apache\commons\lang3\builder\Builder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */