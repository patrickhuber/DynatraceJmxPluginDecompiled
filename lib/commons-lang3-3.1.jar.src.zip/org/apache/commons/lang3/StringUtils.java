/*      */ package org.apache.commons.lang3;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   public static final String EMPTY = "";
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */   private static final int PAD_LIMIT = 8192;
/*  148 */   private static final Pattern WHITESPACE_BLOCK = Pattern.compile("\\s+");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isEmpty(CharSequence cs)
/*      */   {
/*  184 */     return (cs == null) || (cs.length() == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNotEmpty(CharSequence cs)
/*      */   {
/*  203 */     return !isEmpty(cs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isBlank(CharSequence cs)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  224 */     if ((cs == null) || ((strLen = cs.length()) == 0))
/*  225 */       return true;
/*      */     int strLen;
/*  227 */     for (int i = 0; i < strLen; i++) {
/*  228 */       if (!Character.isWhitespace(cs.charAt(i))) {
/*  229 */         return false;
/*      */       }
/*      */     }
/*  232 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNotBlank(CharSequence cs)
/*      */   {
/*  253 */     return !isBlank(cs);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String trim(String str)
/*      */   {
/*  282 */     return str == null ? null : str.trim();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String trimToNull(String str)
/*      */   {
/*  308 */     String ts = trim(str);
/*  309 */     return isEmpty(ts) ? null : ts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String trimToEmpty(String str)
/*      */   {
/*  334 */     return str == null ? "" : str.trim();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String strip(String str)
/*      */   {
/*  362 */     return strip(str, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripToNull(String str)
/*      */   {
/*  389 */     if (str == null) {
/*  390 */       return null;
/*      */     }
/*  392 */     str = strip(str, null);
/*  393 */     return str.length() == 0 ? null : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripToEmpty(String str)
/*      */   {
/*  419 */     return str == null ? "" : strip(str, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String strip(String str, String stripChars)
/*      */   {
/*  449 */     if (isEmpty(str)) {
/*  450 */       return str;
/*      */     }
/*  452 */     str = stripStart(str, stripChars);
/*  453 */     return stripEnd(str, stripChars);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripStart(String str, String stripChars)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  482 */     if ((str == null) || ((strLen = str.length()) == 0))
/*  483 */       return str;
/*      */     int strLen;
/*  485 */     int start = 0;
/*  486 */     if (stripChars == null) {
/*  487 */       while ((start != strLen) && (Character.isWhitespace(str.charAt(start))))
/*  488 */         start++;
/*      */     }
/*  490 */     if (stripChars.length() == 0) {
/*  491 */       return str;
/*      */     }
/*  493 */     while ((start != strLen) && (stripChars.indexOf(str.charAt(start)) != -1)) {
/*  494 */       start++;
/*      */     }
/*      */     
/*  497 */     return str.substring(start);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripEnd(String str, String stripChars)
/*      */   {
/*      */     int end;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  527 */     if ((str == null) || ((end = str.length()) == 0)) {
/*  528 */       return str;
/*      */     }
/*      */     int end;
/*  531 */     if (stripChars == null) {
/*  532 */       while ((end != 0) && (Character.isWhitespace(str.charAt(end - 1))))
/*  533 */         end--;
/*      */     }
/*  535 */     if (stripChars.length() == 0) {
/*  536 */       return str;
/*      */     }
/*  538 */     while ((end != 0) && (stripChars.indexOf(str.charAt(end - 1)) != -1)) {
/*  539 */       end--;
/*      */     }
/*      */     
/*  542 */     return str.substring(0, end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] stripAll(String... strs)
/*      */   {
/*  567 */     return stripAll(strs, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] stripAll(String[] strs, String stripChars)
/*      */   {
/*      */     int strsLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  597 */     if ((strs == null) || ((strsLen = strs.length) == 0))
/*  598 */       return strs;
/*      */     int strsLen;
/*  600 */     String[] newArr = new String[strsLen];
/*  601 */     for (int i = 0; i < strsLen; i++) {
/*  602 */       newArr[i] = strip(strs[i], stripChars);
/*      */     }
/*  604 */     return newArr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripAccents(String input)
/*      */   {
/*  629 */     if (input == null) {
/*  630 */       return null;
/*      */     }
/*      */     try {
/*  633 */       String result = null;
/*  634 */       if (InitStripAccents.java6NormalizeMethod != null) {
/*  635 */         result = removeAccentsJava6(input);
/*  636 */       } else if (InitStripAccents.sunDecomposeMethod != null) {
/*  637 */         result = removeAccentsSUN(input);
/*      */       } else {
/*  639 */         throw new UnsupportedOperationException("The stripAccents(CharSequence) method requires at least Java6, but got: " + InitStripAccents.java6Exception + "; or a Sun JVM: " + InitStripAccents.sunException);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  645 */       return result;
/*      */     } catch (IllegalArgumentException iae) {
/*  647 */       throw new RuntimeException("IllegalArgumentException occurred", iae);
/*      */     } catch (IllegalAccessException iae) {
/*  649 */       throw new RuntimeException("IllegalAccessException occurred", iae);
/*      */     } catch (InvocationTargetException ite) {
/*  651 */       throw new RuntimeException("InvocationTargetException occurred", ite);
/*      */     } catch (SecurityException se) {
/*  653 */       throw new RuntimeException("SecurityException occurred", se);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String removeAccentsJava6(CharSequence text)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*  673 */     if ((InitStripAccents.java6NormalizeMethod == null) || (InitStripAccents.java6NormalizerFormNFD == null)) {
/*  674 */       throw new IllegalStateException("java.text.Normalizer is not available", InitStripAccents.java6Exception);
/*      */     }
/*      */     
/*  677 */     String result = (String)InitStripAccents.java6NormalizeMethod.invoke(null, new Object[] { text, InitStripAccents.java6NormalizerFormNFD });
/*  678 */     result = InitStripAccents.java6Pattern.matcher(result).replaceAll("");
/*  679 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String removeAccentsSUN(CharSequence text)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*  697 */     if (InitStripAccents.sunDecomposeMethod == null) {
/*  698 */       throw new IllegalStateException("sun.text.Normalizer is not available", InitStripAccents.sunException);
/*      */     }
/*      */     
/*  701 */     String result = (String)InitStripAccents.sunDecomposeMethod.invoke(null, new Object[] { text, Boolean.FALSE, Integer.valueOf(0) });
/*  702 */     result = InitStripAccents.sunPattern.matcher(result).replaceAll("");
/*  703 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   private static class InitStripAccents
/*      */   {
/*      */     private static final Throwable sunException;
/*      */     private static final Method sunDecomposeMethod;
/*  711 */     private static final Pattern sunPattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
/*      */     
/*      */     private static final Throwable java6Exception;
/*      */     private static final Method java6NormalizeMethod;
/*      */     private static final Object java6NormalizerFormNFD;
/*  716 */     private static final Pattern java6Pattern = sunPattern;
/*      */     
/*      */     static
/*      */     {
/*  720 */       Object _java6NormalizerFormNFD = null;
/*  721 */       Method _java6NormalizeMethod = null;
/*  722 */       Method _sunDecomposeMethod = null;
/*  723 */       Throwable _java6Exception = null;
/*  724 */       Throwable _sunException = null;
/*      */       
/*      */       try
/*      */       {
/*  728 */         Class<?> normalizerFormClass = Thread.currentThread().getContextClassLoader().loadClass("java.text.Normalizer$Form");
/*      */         
/*  730 */         _java6NormalizerFormNFD = normalizerFormClass.getField("NFD").get(null);
/*  731 */         Class<?> normalizerClass = Thread.currentThread().getContextClassLoader().loadClass("java.text.Normalizer");
/*      */         
/*  733 */         _java6NormalizeMethod = normalizerClass.getMethod("normalize", new Class[] { CharSequence.class, normalizerFormClass });
/*      */       }
/*      */       catch (Exception e1)
/*      */       {
/*  737 */         _java6Exception = e1;
/*      */         try
/*      */         {
/*  740 */           Class<?> normalizerClass = Thread.currentThread().getContextClassLoader().loadClass("sun.text.Normalizer");
/*      */           
/*  742 */           _sunDecomposeMethod = normalizerClass.getMethod("decompose", new Class[] { String.class, Boolean.TYPE, Integer.TYPE });
/*      */         }
/*      */         catch (Exception e2) {
/*  745 */           _sunException = e2;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  750 */       java6Exception = _java6Exception;
/*  751 */       java6NormalizerFormNFD = _java6NormalizerFormNFD;
/*  752 */       java6NormalizeMethod = _java6NormalizeMethod;
/*  753 */       sunException = _sunException;
/*  754 */       sunDecomposeMethod = _sunDecomposeMethod;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equals(CharSequence cs1, CharSequence cs2)
/*      */   {
/*  782 */     return cs1 == null ? false : cs2 == null ? true : cs1.equals(cs2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean equalsIgnoreCase(CharSequence str1, CharSequence str2)
/*      */   {
/*  807 */     if ((str1 == null) || (str2 == null)) {
/*  808 */       return str1 == str2;
/*      */     }
/*  810 */     return CharSequenceUtils.regionMatches(str1, true, 0, str2, 0, Math.max(str1.length(), str2.length()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(CharSequence seq, int searchChar)
/*      */   {
/*  837 */     if (isEmpty(seq)) {
/*  838 */       return -1;
/*      */     }
/*  840 */     return CharSequenceUtils.indexOf(seq, searchChar, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(CharSequence seq, int searchChar, int startPos)
/*      */   {
/*  870 */     if (isEmpty(seq)) {
/*  871 */       return -1;
/*      */     }
/*  873 */     return CharSequenceUtils.indexOf(seq, searchChar, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(CharSequence seq, CharSequence searchSeq)
/*      */   {
/*  901 */     if ((seq == null) || (searchSeq == null)) {
/*  902 */       return -1;
/*      */     }
/*  904 */     return CharSequenceUtils.indexOf(seq, searchSeq, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOf(CharSequence seq, CharSequence searchSeq, int startPos)
/*      */   {
/*  941 */     if ((seq == null) || (searchSeq == null)) {
/*  942 */       return -1;
/*      */     }
/*  944 */     return CharSequenceUtils.indexOf(seq, searchSeq, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal)
/*      */   {
/*  982 */     return ordinalIndexOf(str, searchStr, ordinal, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal, boolean lastIndex)
/*      */   {
/* 1000 */     if ((str == null) || (searchStr == null) || (ordinal <= 0)) {
/* 1001 */       return -1;
/*      */     }
/* 1003 */     if (searchStr.length() == 0) {
/* 1004 */       return lastIndex ? str.length() : 0;
/*      */     }
/* 1006 */     int found = 0;
/* 1007 */     int index = lastIndex ? str.length() : -1;
/*      */     do {
/* 1009 */       if (lastIndex) {
/* 1010 */         index = CharSequenceUtils.lastIndexOf(str, searchStr, index - 1);
/*      */       } else {
/* 1012 */         index = CharSequenceUtils.indexOf(str, searchStr, index + 1);
/*      */       }
/* 1014 */       if (index < 0) {
/* 1015 */         return index;
/*      */       }
/* 1017 */       found++;
/* 1018 */     } while (found < ordinal);
/* 1019 */     return index;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr)
/*      */   {
/* 1048 */     return indexOfIgnoreCase(str, searchStr, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos)
/*      */   {
/* 1084 */     if ((str == null) || (searchStr == null)) {
/* 1085 */       return -1;
/*      */     }
/* 1087 */     if (startPos < 0) {
/* 1088 */       startPos = 0;
/*      */     }
/* 1090 */     int endLimit = str.length() - searchStr.length() + 1;
/* 1091 */     if (startPos > endLimit) {
/* 1092 */       return -1;
/*      */     }
/* 1094 */     if (searchStr.length() == 0) {
/* 1095 */       return startPos;
/*      */     }
/* 1097 */     for (int i = startPos; i < endLimit; i++) {
/* 1098 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, searchStr.length())) {
/* 1099 */         return i;
/*      */       }
/*      */     }
/* 1102 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(CharSequence seq, int searchChar)
/*      */   {
/* 1128 */     if (isEmpty(seq)) {
/* 1129 */       return -1;
/*      */     }
/* 1131 */     return CharSequenceUtils.lastIndexOf(seq, searchChar, seq.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(CharSequence seq, int searchChar, int startPos)
/*      */   {
/* 1163 */     if (isEmpty(seq)) {
/* 1164 */       return -1;
/*      */     }
/* 1166 */     return CharSequenceUtils.lastIndexOf(seq, searchChar, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(CharSequence seq, CharSequence searchSeq)
/*      */   {
/* 1193 */     if ((seq == null) || (searchSeq == null)) {
/* 1194 */       return -1;
/*      */     }
/* 1196 */     return CharSequenceUtils.lastIndexOf(seq, searchSeq, seq.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastOrdinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal)
/*      */   {
/* 1234 */     return ordinalIndexOf(str, searchStr, ordinal, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOf(CharSequence seq, CharSequence searchSeq, int startPos)
/*      */   {
/* 1267 */     if ((seq == null) || (searchSeq == null)) {
/* 1268 */       return -1;
/*      */     }
/* 1270 */     return CharSequenceUtils.lastIndexOf(seq, searchSeq, startPos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr)
/*      */   {
/* 1297 */     if ((str == null) || (searchStr == null)) {
/* 1298 */       return -1;
/*      */     }
/* 1300 */     return lastIndexOfIgnoreCase(str, searchStr, str.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos)
/*      */   {
/* 1333 */     if ((str == null) || (searchStr == null)) {
/* 1334 */       return -1;
/*      */     }
/* 1336 */     if (startPos > str.length() - searchStr.length()) {
/* 1337 */       startPos = str.length() - searchStr.length();
/*      */     }
/* 1339 */     if (startPos < 0) {
/* 1340 */       return -1;
/*      */     }
/* 1342 */     if (searchStr.length() == 0) {
/* 1343 */       return startPos;
/*      */     }
/*      */     
/* 1346 */     for (int i = startPos; i >= 0; i--) {
/* 1347 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, searchStr.length())) {
/* 1348 */         return i;
/*      */       }
/*      */     }
/* 1351 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(CharSequence seq, int searchChar)
/*      */   {
/* 1377 */     if (isEmpty(seq)) {
/* 1378 */       return false;
/*      */     }
/* 1380 */     return CharSequenceUtils.indexOf(seq, searchChar, 0) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean contains(CharSequence seq, CharSequence searchSeq)
/*      */   {
/* 1406 */     if ((seq == null) || (searchSeq == null)) {
/* 1407 */       return false;
/*      */     }
/* 1409 */     return CharSequenceUtils.indexOf(seq, searchSeq, 0) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsIgnoreCase(CharSequence str, CharSequence searchStr)
/*      */   {
/* 1437 */     if ((str == null) || (searchStr == null)) {
/* 1438 */       return false;
/*      */     }
/* 1440 */     int len = searchStr.length();
/* 1441 */     int max = str.length() - len;
/* 1442 */     for (int i = 0; i <= max; i++) {
/* 1443 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, len)) {
/* 1444 */         return true;
/*      */       }
/*      */     }
/* 1447 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsWhitespace(CharSequence seq)
/*      */   {
/* 1460 */     if (isEmpty(seq)) {
/* 1461 */       return false;
/*      */     }
/* 1463 */     int strLen = seq.length();
/* 1464 */     for (int i = 0; i < strLen; i++) {
/* 1465 */       if (Character.isWhitespace(seq.charAt(i))) {
/* 1466 */         return true;
/*      */       }
/*      */     }
/* 1469 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAny(CharSequence cs, char... searchChars)
/*      */   {
/* 1498 */     if ((isEmpty(cs)) || (ArrayUtils.isEmpty(searchChars))) {
/* 1499 */       return -1;
/*      */     }
/* 1501 */     int csLen = cs.length();
/* 1502 */     int csLast = csLen - 1;
/* 1503 */     int searchLen = searchChars.length;
/* 1504 */     int searchLast = searchLen - 1;
/* 1505 */     for (int i = 0; i < csLen; i++) {
/* 1506 */       char ch = cs.charAt(i);
/* 1507 */       for (int j = 0; j < searchLen; j++) {
/* 1508 */         if (searchChars[j] == ch) {
/* 1509 */           if ((i < csLast) && (j < searchLast) && (Character.isHighSurrogate(ch)))
/*      */           {
/* 1511 */             if (searchChars[(j + 1)] == cs.charAt(i + 1)) {
/* 1512 */               return i;
/*      */             }
/*      */           } else {
/* 1515 */             return i;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1520 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAny(CharSequence cs, String searchChars)
/*      */   {
/* 1547 */     if ((isEmpty(cs)) || (isEmpty(searchChars))) {
/* 1548 */       return -1;
/*      */     }
/* 1550 */     return indexOfAny(cs, searchChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsAny(CharSequence cs, char... searchChars)
/*      */   {
/* 1580 */     if ((isEmpty(cs)) || (ArrayUtils.isEmpty(searchChars))) {
/* 1581 */       return false;
/*      */     }
/* 1583 */     int csLength = cs.length();
/* 1584 */     int searchLength = searchChars.length;
/* 1585 */     int csLast = csLength - 1;
/* 1586 */     int searchLast = searchLength - 1;
/* 1587 */     for (int i = 0; i < csLength; i++) {
/* 1588 */       char ch = cs.charAt(i);
/* 1589 */       for (int j = 0; j < searchLength; j++) {
/* 1590 */         if (searchChars[j] == ch) {
/* 1591 */           if (Character.isHighSurrogate(ch)) {
/* 1592 */             if (j == searchLast)
/*      */             {
/* 1594 */               return true;
/*      */             }
/* 1596 */             if ((i < csLast) && (searchChars[(j + 1)] == cs.charAt(i + 1))) {
/* 1597 */               return true;
/*      */             }
/*      */           }
/*      */           else {
/* 1601 */             return true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1606 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsAny(CharSequence cs, CharSequence searchChars)
/*      */   {
/* 1638 */     if (searchChars == null) {
/* 1639 */       return false;
/*      */     }
/* 1641 */     return containsAny(cs, CharSequenceUtils.toCharArray(searchChars));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAnyBut(CharSequence cs, char... searchChars)
/*      */   {
/* 1671 */     if ((isEmpty(cs)) || (ArrayUtils.isEmpty(searchChars))) {
/* 1672 */       return -1;
/*      */     }
/* 1674 */     int csLen = cs.length();
/* 1675 */     int csLast = csLen - 1;
/* 1676 */     int searchLen = searchChars.length;
/* 1677 */     int searchLast = searchLen - 1;
/*      */     label127:
/* 1679 */     for (int i = 0; i < csLen; i++) {
/* 1680 */       char ch = cs.charAt(i);
/* 1681 */       for (int j = 0; j < searchLen; j++) {
/* 1682 */         if ((searchChars[j] == ch) && (
/* 1683 */           (i >= csLast) || (j >= searchLast) || (!Character.isHighSurrogate(ch)) || 
/* 1684 */           (searchChars[(j + 1)] == cs.charAt(i + 1)))) {
/*      */           break label127;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1692 */       return i;
/*      */     }
/* 1694 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAnyBut(CharSequence seq, CharSequence searchChars)
/*      */   {
/* 1721 */     if ((isEmpty(seq)) || (isEmpty(searchChars))) {
/* 1722 */       return -1;
/*      */     }
/* 1724 */     int strLen = seq.length();
/* 1725 */     for (int i = 0; i < strLen; i++) {
/* 1726 */       char ch = seq.charAt(i);
/* 1727 */       boolean chFound = CharSequenceUtils.indexOf(searchChars, ch, 0) >= 0;
/* 1728 */       if ((i + 1 < strLen) && (Character.isHighSurrogate(ch))) {
/* 1729 */         char ch2 = seq.charAt(i + 1);
/* 1730 */         if ((chFound) && (CharSequenceUtils.indexOf(searchChars, ch2, 0) < 0)) {
/* 1731 */           return i;
/*      */         }
/*      */       }
/* 1734 */       else if (!chFound) {
/* 1735 */         return i;
/*      */       }
/*      */     }
/*      */     
/* 1739 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsOnly(CharSequence cs, char... valid)
/*      */   {
/* 1768 */     if ((valid == null) || (cs == null)) {
/* 1769 */       return false;
/*      */     }
/* 1771 */     if (cs.length() == 0) {
/* 1772 */       return true;
/*      */     }
/* 1774 */     if (valid.length == 0) {
/* 1775 */       return false;
/*      */     }
/* 1777 */     return indexOfAnyBut(cs, valid) == -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsOnly(CharSequence cs, String validChars)
/*      */   {
/* 1804 */     if ((cs == null) || (validChars == null)) {
/* 1805 */       return false;
/*      */     }
/* 1807 */     return containsOnly(cs, validChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsNone(CharSequence cs, char... searchChars)
/*      */   {
/* 1836 */     if ((cs == null) || (searchChars == null)) {
/* 1837 */       return true;
/*      */     }
/* 1839 */     int csLen = cs.length();
/* 1840 */     int csLast = csLen - 1;
/* 1841 */     int searchLen = searchChars.length;
/* 1842 */     int searchLast = searchLen - 1;
/* 1843 */     for (int i = 0; i < csLen; i++) {
/* 1844 */       char ch = cs.charAt(i);
/* 1845 */       for (int j = 0; j < searchLen; j++) {
/* 1846 */         if (searchChars[j] == ch) {
/* 1847 */           if (Character.isHighSurrogate(ch)) {
/* 1848 */             if (j == searchLast)
/*      */             {
/* 1850 */               return false;
/*      */             }
/* 1852 */             if ((i < csLast) && (searchChars[(j + 1)] == cs.charAt(i + 1))) {
/* 1853 */               return false;
/*      */             }
/*      */           }
/*      */           else {
/* 1857 */             return false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1862 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean containsNone(CharSequence cs, String invalidChars)
/*      */   {
/* 1889 */     if ((cs == null) || (invalidChars == null)) {
/* 1890 */       return true;
/*      */     }
/* 1892 */     return containsNone(cs, invalidChars.toCharArray());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfAny(CharSequence str, CharSequence... searchStrs)
/*      */   {
/* 1925 */     if ((str == null) || (searchStrs == null)) {
/* 1926 */       return -1;
/*      */     }
/* 1928 */     int sz = searchStrs.length;
/*      */     
/*      */ 
/* 1931 */     int ret = Integer.MAX_VALUE;
/*      */     
/* 1933 */     int tmp = 0;
/* 1934 */     for (int i = 0; i < sz; i++) {
/* 1935 */       CharSequence search = searchStrs[i];
/* 1936 */       if (search != null)
/*      */       {
/*      */ 
/* 1939 */         tmp = CharSequenceUtils.indexOf(str, search, 0);
/* 1940 */         if (tmp != -1)
/*      */         {
/*      */ 
/*      */ 
/* 1944 */           if (tmp < ret)
/* 1945 */             ret = tmp;
/*      */         }
/*      */       }
/*      */     }
/* 1949 */     return ret == Integer.MAX_VALUE ? -1 : ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int lastIndexOfAny(CharSequence str, CharSequence... searchStrs)
/*      */   {
/* 1979 */     if ((str == null) || (searchStrs == null)) {
/* 1980 */       return -1;
/*      */     }
/* 1982 */     int sz = searchStrs.length;
/* 1983 */     int ret = -1;
/* 1984 */     int tmp = 0;
/* 1985 */     for (int i = 0; i < sz; i++) {
/* 1986 */       CharSequence search = searchStrs[i];
/* 1987 */       if (search != null)
/*      */       {
/*      */ 
/* 1990 */         tmp = CharSequenceUtils.lastIndexOf(str, search, str.length());
/* 1991 */         if (tmp > ret)
/* 1992 */           ret = tmp;
/*      */       }
/*      */     }
/* 1995 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substring(String str, int start)
/*      */   {
/* 2025 */     if (str == null) {
/* 2026 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 2030 */     if (start < 0) {
/* 2031 */       start = str.length() + start;
/*      */     }
/*      */     
/* 2034 */     if (start < 0) {
/* 2035 */       start = 0;
/*      */     }
/* 2037 */     if (start > str.length()) {
/* 2038 */       return "";
/*      */     }
/*      */     
/* 2041 */     return str.substring(start);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substring(String str, int start, int end)
/*      */   {
/* 2080 */     if (str == null) {
/* 2081 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 2085 */     if (end < 0) {
/* 2086 */       end = str.length() + end;
/*      */     }
/* 2088 */     if (start < 0) {
/* 2089 */       start = str.length() + start;
/*      */     }
/*      */     
/*      */ 
/* 2093 */     if (end > str.length()) {
/* 2094 */       end = str.length();
/*      */     }
/*      */     
/*      */ 
/* 2098 */     if (start > end) {
/* 2099 */       return "";
/*      */     }
/*      */     
/* 2102 */     if (start < 0) {
/* 2103 */       start = 0;
/*      */     }
/* 2105 */     if (end < 0) {
/* 2106 */       end = 0;
/*      */     }
/*      */     
/* 2109 */     return str.substring(start, end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String left(String str, int len)
/*      */   {
/* 2135 */     if (str == null) {
/* 2136 */       return null;
/*      */     }
/* 2138 */     if (len < 0) {
/* 2139 */       return "";
/*      */     }
/* 2141 */     if (str.length() <= len) {
/* 2142 */       return str;
/*      */     }
/* 2144 */     return str.substring(0, len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String right(String str, int len)
/*      */   {
/* 2168 */     if (str == null) {
/* 2169 */       return null;
/*      */     }
/* 2171 */     if (len < 0) {
/* 2172 */       return "";
/*      */     }
/* 2174 */     if (str.length() <= len) {
/* 2175 */       return str;
/*      */     }
/* 2177 */     return str.substring(str.length() - len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String mid(String str, int pos, int len)
/*      */   {
/* 2206 */     if (str == null) {
/* 2207 */       return null;
/*      */     }
/* 2209 */     if ((len < 0) || (pos > str.length())) {
/* 2210 */       return "";
/*      */     }
/* 2212 */     if (pos < 0) {
/* 2213 */       pos = 0;
/*      */     }
/* 2215 */     if (str.length() <= pos + len) {
/* 2216 */       return str.substring(pos);
/*      */     }
/* 2218 */     return str.substring(pos, pos + len);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBefore(String str, String separator)
/*      */   {
/* 2251 */     if ((isEmpty(str)) || (separator == null)) {
/* 2252 */       return str;
/*      */     }
/* 2254 */     if (separator.length() == 0) {
/* 2255 */       return "";
/*      */     }
/* 2257 */     int pos = str.indexOf(separator);
/* 2258 */     if (pos == -1) {
/* 2259 */       return str;
/*      */     }
/* 2261 */     return str.substring(0, pos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringAfter(String str, String separator)
/*      */   {
/* 2293 */     if (isEmpty(str)) {
/* 2294 */       return str;
/*      */     }
/* 2296 */     if (separator == null) {
/* 2297 */       return "";
/*      */     }
/* 2299 */     int pos = str.indexOf(separator);
/* 2300 */     if (pos == -1) {
/* 2301 */       return "";
/*      */     }
/* 2303 */     return str.substring(pos + separator.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBeforeLast(String str, String separator)
/*      */   {
/* 2334 */     if ((isEmpty(str)) || (isEmpty(separator))) {
/* 2335 */       return str;
/*      */     }
/* 2337 */     int pos = str.lastIndexOf(separator);
/* 2338 */     if (pos == -1) {
/* 2339 */       return str;
/*      */     }
/* 2341 */     return str.substring(0, pos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringAfterLast(String str, String separator)
/*      */   {
/* 2374 */     if (isEmpty(str)) {
/* 2375 */       return str;
/*      */     }
/* 2377 */     if (isEmpty(separator)) {
/* 2378 */       return "";
/*      */     }
/* 2380 */     int pos = str.lastIndexOf(separator);
/* 2381 */     if ((pos == -1) || (pos == str.length() - separator.length())) {
/* 2382 */       return "";
/*      */     }
/* 2384 */     return str.substring(pos + separator.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBetween(String str, String tag)
/*      */   {
/* 2411 */     return substringBetween(str, tag, tag);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String substringBetween(String str, String open, String close)
/*      */   {
/* 2442 */     if ((str == null) || (open == null) || (close == null)) {
/* 2443 */       return null;
/*      */     }
/* 2445 */     int start = str.indexOf(open);
/* 2446 */     if (start != -1) {
/* 2447 */       int end = str.indexOf(close, start + open.length());
/* 2448 */       if (end != -1) {
/* 2449 */         return str.substring(start + open.length(), end);
/*      */       }
/*      */     }
/* 2452 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] substringsBetween(String str, String open, String close)
/*      */   {
/* 2478 */     if ((str == null) || (isEmpty(open)) || (isEmpty(close))) {
/* 2479 */       return null;
/*      */     }
/* 2481 */     int strLen = str.length();
/* 2482 */     if (strLen == 0) {
/* 2483 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2485 */     int closeLen = close.length();
/* 2486 */     int openLen = open.length();
/* 2487 */     List<String> list = new ArrayList();
/* 2488 */     int pos = 0;
/* 2489 */     while (pos < strLen - closeLen) {
/* 2490 */       int start = str.indexOf(open, pos);
/* 2491 */       if (start < 0) {
/*      */         break;
/*      */       }
/* 2494 */       start += openLen;
/* 2495 */       int end = str.indexOf(close, start);
/* 2496 */       if (end < 0) {
/*      */         break;
/*      */       }
/* 2499 */       list.add(str.substring(start, end));
/* 2500 */       pos = end + closeLen;
/*      */     }
/* 2502 */     if (list.isEmpty()) {
/* 2503 */       return null;
/*      */     }
/* 2505 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str)
/*      */   {
/* 2536 */     return split(str, null, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str, char separatorChar)
/*      */   {
/* 2564 */     return splitWorker(str, separatorChar, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str, String separatorChars)
/*      */   {
/* 2593 */     return splitWorker(str, separatorChars, -1, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] split(String str, String separatorChars, int max)
/*      */   {
/* 2627 */     return splitWorker(str, separatorChars, max, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparator(String str, String separator)
/*      */   {
/* 2654 */     return splitByWholeSeparatorWorker(str, separator, -1, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparator(String str, String separator, int max)
/*      */   {
/* 2685 */     return splitByWholeSeparatorWorker(str, separator, max, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator)
/*      */   {
/* 2714 */     return splitByWholeSeparatorWorker(str, separator, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator, int max)
/*      */   {
/* 2747 */     return splitByWholeSeparatorWorker(str, separator, max, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitByWholeSeparatorWorker(String str, String separator, int max, boolean preserveAllTokens)
/*      */   {
/* 2766 */     if (str == null) {
/* 2767 */       return null;
/*      */     }
/*      */     
/* 2770 */     int len = str.length();
/*      */     
/* 2772 */     if (len == 0) {
/* 2773 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*      */     
/* 2776 */     if ((separator == null) || ("".equals(separator)))
/*      */     {
/* 2778 */       return splitWorker(str, null, max, preserveAllTokens);
/*      */     }
/*      */     
/* 2781 */     int separatorLength = separator.length();
/*      */     
/* 2783 */     ArrayList<String> substrings = new ArrayList();
/* 2784 */     int numberOfSubstrings = 0;
/* 2785 */     int beg = 0;
/* 2786 */     int end = 0;
/* 2787 */     while (end < len) {
/* 2788 */       end = str.indexOf(separator, beg);
/*      */       
/* 2790 */       if (end > -1) {
/* 2791 */         if (end > beg) {
/* 2792 */           numberOfSubstrings++;
/*      */           
/* 2794 */           if (numberOfSubstrings == max) {
/* 2795 */             end = len;
/* 2796 */             substrings.add(str.substring(beg));
/*      */           }
/*      */           else
/*      */           {
/* 2800 */             substrings.add(str.substring(beg, end));
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 2805 */             beg = end + separatorLength;
/*      */           }
/*      */         }
/*      */         else {
/* 2809 */           if (preserveAllTokens) {
/* 2810 */             numberOfSubstrings++;
/* 2811 */             if (numberOfSubstrings == max) {
/* 2812 */               end = len;
/* 2813 */               substrings.add(str.substring(beg));
/*      */             } else {
/* 2815 */               substrings.add("");
/*      */             }
/*      */           }
/* 2818 */           beg = end + separatorLength;
/*      */         }
/*      */       }
/*      */       else {
/* 2822 */         substrings.add(str.substring(beg));
/* 2823 */         end = len;
/*      */       }
/*      */     }
/*      */     
/* 2827 */     return (String[])substrings.toArray(new String[substrings.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str)
/*      */   {
/* 2856 */     return splitWorker(str, null, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str, char separatorChar)
/*      */   {
/* 2892 */     return splitWorker(str, separatorChar, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitWorker(String str, char separatorChar, boolean preserveAllTokens)
/*      */   {
/* 2910 */     if (str == null) {
/* 2911 */       return null;
/*      */     }
/* 2913 */     int len = str.length();
/* 2914 */     if (len == 0) {
/* 2915 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2917 */     List<String> list = new ArrayList();
/* 2918 */     int i = 0;int start = 0;
/* 2919 */     boolean match = false;
/* 2920 */     boolean lastMatch = false;
/* 2921 */     while (i < len)
/* 2922 */       if (str.charAt(i) == separatorChar) {
/* 2923 */         if ((match) || (preserveAllTokens)) {
/* 2924 */           list.add(str.substring(start, i));
/* 2925 */           match = false;
/* 2926 */           lastMatch = true;
/*      */         }
/* 2928 */         i++;start = i;
/*      */       }
/*      */       else {
/* 2931 */         lastMatch = false;
/* 2932 */         match = true;
/* 2933 */         i++;
/*      */       }
/* 2935 */     if ((match) || ((preserveAllTokens) && (lastMatch))) {
/* 2936 */       list.add(str.substring(start, i));
/*      */     }
/* 2938 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars)
/*      */   {
/* 2975 */     return splitWorker(str, separatorChars, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitPreserveAllTokens(String str, String separatorChars, int max)
/*      */   {
/* 3015 */     return splitWorker(str, separatorChars, max, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitWorker(String str, String separatorChars, int max, boolean preserveAllTokens)
/*      */   {
/* 3037 */     if (str == null) {
/* 3038 */       return null;
/*      */     }
/* 3040 */     int len = str.length();
/* 3041 */     if (len == 0) {
/* 3042 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3044 */     List<String> list = new ArrayList();
/* 3045 */     int sizePlus1 = 1;
/* 3046 */     int i = 0;int start = 0;
/* 3047 */     boolean match = false;
/* 3048 */     boolean lastMatch = false;
/* 3049 */     if (separatorChars == null)
/*      */     {
/* 3051 */       while (i < len)
/* 3052 */         if (Character.isWhitespace(str.charAt(i))) {
/* 3053 */           if ((match) || (preserveAllTokens)) {
/* 3054 */             lastMatch = true;
/* 3055 */             if (sizePlus1++ == max) {
/* 3056 */               i = len;
/* 3057 */               lastMatch = false;
/*      */             }
/* 3059 */             list.add(str.substring(start, i));
/* 3060 */             match = false;
/*      */           }
/* 3062 */           i++;start = i;
/*      */         }
/*      */         else {
/* 3065 */           lastMatch = false;
/* 3066 */           match = true;
/* 3067 */           i++;
/*      */         } }
/* 3069 */     if (separatorChars.length() == 1)
/*      */     {
/* 3071 */       char sep = separatorChars.charAt(0);
/* 3072 */       while (i < len) {
/* 3073 */         if (str.charAt(i) == sep) {
/* 3074 */           if ((match) || (preserveAllTokens)) {
/* 3075 */             lastMatch = true;
/* 3076 */             if (sizePlus1++ == max) {
/* 3077 */               i = len;
/* 3078 */               lastMatch = false;
/*      */             }
/* 3080 */             list.add(str.substring(start, i));
/* 3081 */             match = false;
/*      */           }
/* 3083 */           i++;start = i;
/*      */         }
/*      */         else {
/* 3086 */           lastMatch = false;
/* 3087 */           match = true;
/* 3088 */           i++;
/*      */         }
/*      */       }
/*      */     } else {
/* 3092 */       while (i < len)
/* 3093 */         if (separatorChars.indexOf(str.charAt(i)) >= 0) {
/* 3094 */           if ((match) || (preserveAllTokens)) {
/* 3095 */             lastMatch = true;
/* 3096 */             if (sizePlus1++ == max) {
/* 3097 */               i = len;
/* 3098 */               lastMatch = false;
/*      */             }
/* 3100 */             list.add(str.substring(start, i));
/* 3101 */             match = false;
/*      */           }
/* 3103 */           i++;start = i;
/*      */         }
/*      */         else {
/* 3106 */           lastMatch = false;
/* 3107 */           match = true;
/* 3108 */           i++;
/*      */         }
/*      */     }
/* 3111 */     if ((match) || ((preserveAllTokens) && (lastMatch))) {
/* 3112 */       list.add(str.substring(start, i));
/*      */     }
/* 3114 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByCharacterType(String str)
/*      */   {
/* 3137 */     return splitByCharacterType(str, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String[] splitByCharacterTypeCamelCase(String str)
/*      */   {
/* 3165 */     return splitByCharacterType(str, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String[] splitByCharacterType(String str, boolean camelCase)
/*      */   {
/* 3183 */     if (str == null) {
/* 3184 */       return null;
/*      */     }
/* 3186 */     if (str.length() == 0) {
/* 3187 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3189 */     char[] c = str.toCharArray();
/* 3190 */     List<String> list = new ArrayList();
/* 3191 */     int tokenStart = 0;
/* 3192 */     int currentType = Character.getType(c[tokenStart]);
/* 3193 */     for (int pos = tokenStart + 1; pos < c.length; pos++) {
/* 3194 */       int type = Character.getType(c[pos]);
/* 3195 */       if (type != currentType)
/*      */       {
/*      */ 
/* 3198 */         if ((camelCase) && (type == 2) && (currentType == 1)) {
/* 3199 */           int newTokenStart = pos - 1;
/* 3200 */           if (newTokenStart != tokenStart) {
/* 3201 */             list.add(new String(c, tokenStart, newTokenStart - tokenStart));
/* 3202 */             tokenStart = newTokenStart;
/*      */           }
/*      */         } else {
/* 3205 */           list.add(new String(c, tokenStart, pos - tokenStart));
/* 3206 */           tokenStart = pos;
/*      */         }
/* 3208 */         currentType = type;
/*      */       } }
/* 3210 */     list.add(new String(c, tokenStart, c.length - tokenStart));
/* 3211 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T> String join(T... elements)
/*      */   {
/* 3239 */     return join(elements, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, char separator)
/*      */   {
/* 3265 */     if (array == null) {
/* 3266 */       return null;
/*      */     }
/*      */     
/* 3269 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, char separator, int startIndex, int endIndex)
/*      */   {
/* 3299 */     if (array == null) {
/* 3300 */       return null;
/*      */     }
/* 3302 */     int noOfItems = endIndex - startIndex;
/* 3303 */     if (noOfItems <= 0) {
/* 3304 */       return "";
/*      */     }
/*      */     
/* 3307 */     StringBuilder buf = new StringBuilder(noOfItems * 16);
/*      */     
/* 3309 */     for (int i = startIndex; i < endIndex; i++) {
/* 3310 */       if (i > startIndex) {
/* 3311 */         buf.append(separator);
/*      */       }
/* 3313 */       if (array[i] != null) {
/* 3314 */         buf.append(array[i]);
/*      */       }
/*      */     }
/* 3317 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, String separator)
/*      */   {
/* 3344 */     if (array == null) {
/* 3345 */       return null;
/*      */     }
/* 3347 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Object[] array, String separator, int startIndex, int endIndex)
/*      */   {
/* 3378 */     if (array == null) {
/* 3379 */       return null;
/*      */     }
/* 3381 */     if (separator == null) {
/* 3382 */       separator = "";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3387 */     int noOfItems = endIndex - startIndex;
/* 3388 */     if (noOfItems <= 0) {
/* 3389 */       return "";
/*      */     }
/*      */     
/* 3392 */     StringBuilder buf = new StringBuilder(noOfItems * 16);
/*      */     
/* 3394 */     for (int i = startIndex; i < endIndex; i++) {
/* 3395 */       if (i > startIndex) {
/* 3396 */         buf.append(separator);
/*      */       }
/* 3398 */       if (array[i] != null) {
/* 3399 */         buf.append(array[i]);
/*      */       }
/*      */     }
/* 3402 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Iterator<?> iterator, char separator)
/*      */   {
/* 3422 */     if (iterator == null) {
/* 3423 */       return null;
/*      */     }
/* 3425 */     if (!iterator.hasNext()) {
/* 3426 */       return "";
/*      */     }
/* 3428 */     Object first = iterator.next();
/* 3429 */     if (!iterator.hasNext()) {
/* 3430 */       return ObjectUtils.toString(first);
/*      */     }
/*      */     
/*      */ 
/* 3434 */     StringBuilder buf = new StringBuilder(256);
/* 3435 */     if (first != null) {
/* 3436 */       buf.append(first);
/*      */     }
/*      */     
/* 3439 */     while (iterator.hasNext()) {
/* 3440 */       buf.append(separator);
/* 3441 */       Object obj = iterator.next();
/* 3442 */       if (obj != null) {
/* 3443 */         buf.append(obj);
/*      */       }
/*      */     }
/*      */     
/* 3447 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Iterator<?> iterator, String separator)
/*      */   {
/* 3466 */     if (iterator == null) {
/* 3467 */       return null;
/*      */     }
/* 3469 */     if (!iterator.hasNext()) {
/* 3470 */       return "";
/*      */     }
/* 3472 */     Object first = iterator.next();
/* 3473 */     if (!iterator.hasNext()) {
/* 3474 */       return ObjectUtils.toString(first);
/*      */     }
/*      */     
/*      */ 
/* 3478 */     StringBuilder buf = new StringBuilder(256);
/* 3479 */     if (first != null) {
/* 3480 */       buf.append(first);
/*      */     }
/*      */     
/* 3483 */     while (iterator.hasNext()) {
/* 3484 */       if (separator != null) {
/* 3485 */         buf.append(separator);
/*      */       }
/* 3487 */       Object obj = iterator.next();
/* 3488 */       if (obj != null) {
/* 3489 */         buf.append(obj);
/*      */       }
/*      */     }
/* 3492 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Iterable<?> iterable, char separator)
/*      */   {
/* 3510 */     if (iterable == null) {
/* 3511 */       return null;
/*      */     }
/* 3513 */     return join(iterable.iterator(), separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String join(Iterable<?> iterable, String separator)
/*      */   {
/* 3531 */     if (iterable == null) {
/* 3532 */       return null;
/*      */     }
/* 3534 */     return join(iterable.iterator(), separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String deleteWhitespace(String str)
/*      */   {
/* 3554 */     if (isEmpty(str)) {
/* 3555 */       return str;
/*      */     }
/* 3557 */     int sz = str.length();
/* 3558 */     char[] chs = new char[sz];
/* 3559 */     int count = 0;
/* 3560 */     for (int i = 0; i < sz; i++) {
/* 3561 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 3562 */         chs[(count++)] = str.charAt(i);
/*      */       }
/*      */     }
/* 3565 */     if (count == sz) {
/* 3566 */       return str;
/*      */     }
/* 3568 */     return new String(chs, 0, count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeStart(String str, String remove)
/*      */   {
/* 3598 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3599 */       return str;
/*      */     }
/* 3601 */     if (str.startsWith(remove)) {
/* 3602 */       return str.substring(remove.length());
/*      */     }
/* 3604 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeStartIgnoreCase(String str, String remove)
/*      */   {
/* 3633 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3634 */       return str;
/*      */     }
/* 3636 */     if (startsWithIgnoreCase(str, remove)) {
/* 3637 */       return str.substring(remove.length());
/*      */     }
/* 3639 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeEnd(String str, String remove)
/*      */   {
/* 3667 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3668 */       return str;
/*      */     }
/* 3670 */     if (str.endsWith(remove)) {
/* 3671 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 3673 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String removeEndIgnoreCase(String str, String remove)
/*      */   {
/* 3703 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3704 */       return str;
/*      */     }
/* 3706 */     if (endsWithIgnoreCase(str, remove)) {
/* 3707 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 3709 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String remove(String str, String remove)
/*      */   {
/* 3736 */     if ((isEmpty(str)) || (isEmpty(remove))) {
/* 3737 */       return str;
/*      */     }
/* 3739 */     return replace(str, remove, "", -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String remove(String str, char remove)
/*      */   {
/* 3762 */     if ((isEmpty(str)) || (str.indexOf(remove) == -1)) {
/* 3763 */       return str;
/*      */     }
/* 3765 */     char[] chars = str.toCharArray();
/* 3766 */     int pos = 0;
/* 3767 */     for (int i = 0; i < chars.length; i++) {
/* 3768 */       if (chars[i] != remove) {
/* 3769 */         chars[(pos++)] = chars[i];
/*      */       }
/*      */     }
/* 3772 */     return new String(chars, 0, pos);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceOnce(String text, String searchString, String replacement)
/*      */   {
/* 3801 */     return replace(text, searchString, replacement, 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replace(String text, String searchString, String replacement)
/*      */   {
/* 3828 */     return replace(text, searchString, replacement, -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replace(String text, String searchString, String replacement, int max)
/*      */   {
/* 3860 */     if ((isEmpty(text)) || (isEmpty(searchString)) || (replacement == null) || (max == 0)) {
/* 3861 */       return text;
/*      */     }
/* 3863 */     int start = 0;
/* 3864 */     int end = text.indexOf(searchString, start);
/* 3865 */     if (end == -1) {
/* 3866 */       return text;
/*      */     }
/* 3868 */     int replLength = searchString.length();
/* 3869 */     int increase = replacement.length() - replLength;
/* 3870 */     increase = increase < 0 ? 0 : increase;
/* 3871 */     increase *= (max > 64 ? 64 : max < 0 ? 16 : max);
/* 3872 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/* 3873 */     while (end != -1) {
/* 3874 */       buf.append(text.substring(start, end)).append(replacement);
/* 3875 */       start = end + replLength;
/* 3876 */       max--; if (max == 0) {
/*      */         break;
/*      */       }
/* 3879 */       end = text.indexOf(searchString, start);
/*      */     }
/* 3881 */     buf.append(text.substring(start));
/* 3882 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceEach(String text, String[] searchList, String[] replacementList)
/*      */   {
/* 3925 */     return replaceEach(text, searchList, replacementList, false, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceEachRepeatedly(String text, String[] searchList, String[] replacementList)
/*      */   {
/* 3975 */     int timeToLive = searchList == null ? 0 : searchList.length;
/* 3976 */     return replaceEach(text, searchList, replacementList, true, timeToLive);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static String replaceEach(String text, String[] searchList, String[] replacementList, boolean repeat, int timeToLive)
/*      */   {
/* 4033 */     if ((text == null) || (text.length() == 0) || (searchList == null) || (searchList.length == 0) || (replacementList == null) || (replacementList.length == 0))
/*      */     {
/* 4035 */       return text;
/*      */     }
/*      */     
/*      */ 
/* 4039 */     if (timeToLive < 0) {
/* 4040 */       throw new IllegalStateException("Aborting to protect against StackOverflowError - output of one loop is the input of another");
/*      */     }
/*      */     
/*      */ 
/* 4044 */     int searchLength = searchList.length;
/* 4045 */     int replacementLength = replacementList.length;
/*      */     
/*      */ 
/* 4048 */     if (searchLength != replacementLength) {
/* 4049 */       throw new IllegalArgumentException("Search and Replace array lengths don't match: " + searchLength + " vs " + replacementLength);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4056 */     boolean[] noMoreMatchesForReplIndex = new boolean[searchLength];
/*      */     
/*      */ 
/* 4059 */     int textIndex = -1;
/* 4060 */     int replaceIndex = -1;
/* 4061 */     int tempIndex = -1;
/*      */     
/*      */ 
/*      */ 
/* 4065 */     for (int i = 0; i < searchLength; i++) {
/* 4066 */       if ((noMoreMatchesForReplIndex[i] == 0) && (searchList[i] != null) && (searchList[i].length() != 0) && (replacementList[i] != null))
/*      */       {
/*      */ 
/*      */ 
/* 4070 */         tempIndex = text.indexOf(searchList[i]);
/*      */         
/*      */ 
/* 4073 */         if (tempIndex == -1) {
/* 4074 */           noMoreMatchesForReplIndex[i] = true;
/*      */         }
/* 4076 */         else if ((textIndex == -1) || (tempIndex < textIndex)) {
/* 4077 */           textIndex = tempIndex;
/* 4078 */           replaceIndex = i;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 4085 */     if (textIndex == -1) {
/* 4086 */       return text;
/*      */     }
/*      */     
/* 4089 */     int start = 0;
/*      */     
/*      */ 
/* 4092 */     int increase = 0;
/*      */     
/*      */ 
/* 4095 */     for (int i = 0; i < searchList.length; i++) {
/* 4096 */       if ((searchList[i] != null) && (replacementList[i] != null))
/*      */       {
/*      */ 
/* 4099 */         int greater = replacementList[i].length() - searchList[i].length();
/* 4100 */         if (greater > 0) {
/* 4101 */           increase += 3 * greater;
/*      */         }
/*      */       }
/*      */     }
/* 4105 */     increase = Math.min(increase, text.length() / 5);
/*      */     
/* 4107 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/*      */     
/* 4109 */     while (textIndex != -1)
/*      */     {
/* 4111 */       for (int i = start; i < textIndex; i++) {
/* 4112 */         buf.append(text.charAt(i));
/*      */       }
/* 4114 */       buf.append(replacementList[replaceIndex]);
/*      */       
/* 4116 */       start = textIndex + searchList[replaceIndex].length();
/*      */       
/* 4118 */       textIndex = -1;
/* 4119 */       replaceIndex = -1;
/* 4120 */       tempIndex = -1;
/*      */       
/*      */ 
/* 4123 */       for (int i = 0; i < searchLength; i++) {
/* 4124 */         if ((noMoreMatchesForReplIndex[i] == 0) && (searchList[i] != null) && (searchList[i].length() != 0) && (replacementList[i] != null))
/*      */         {
/*      */ 
/*      */ 
/* 4128 */           tempIndex = text.indexOf(searchList[i], start);
/*      */           
/*      */ 
/* 4131 */           if (tempIndex == -1) {
/* 4132 */             noMoreMatchesForReplIndex[i] = true;
/*      */           }
/* 4134 */           else if ((textIndex == -1) || (tempIndex < textIndex)) {
/* 4135 */             textIndex = tempIndex;
/* 4136 */             replaceIndex = i;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 4143 */     int textLength = text.length();
/* 4144 */     for (int i = start; i < textLength; i++) {
/* 4145 */       buf.append(text.charAt(i));
/*      */     }
/* 4147 */     String result = buf.toString();
/* 4148 */     if (!repeat) {
/* 4149 */       return result;
/*      */     }
/*      */     
/* 4152 */     return replaceEach(result, searchList, replacementList, repeat, timeToLive - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceChars(String str, char searchChar, char replaceChar)
/*      */   {
/* 4178 */     if (str == null) {
/* 4179 */       return null;
/*      */     }
/* 4181 */     return str.replace(searchChar, replaceChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String replaceChars(String str, String searchChars, String replaceChars)
/*      */   {
/* 4221 */     if ((isEmpty(str)) || (isEmpty(searchChars))) {
/* 4222 */       return str;
/*      */     }
/* 4224 */     if (replaceChars == null) {
/* 4225 */       replaceChars = "";
/*      */     }
/* 4227 */     boolean modified = false;
/* 4228 */     int replaceCharsLength = replaceChars.length();
/* 4229 */     int strLength = str.length();
/* 4230 */     StringBuilder buf = new StringBuilder(strLength);
/* 4231 */     for (int i = 0; i < strLength; i++) {
/* 4232 */       char ch = str.charAt(i);
/* 4233 */       int index = searchChars.indexOf(ch);
/* 4234 */       if (index >= 0) {
/* 4235 */         modified = true;
/* 4236 */         if (index < replaceCharsLength) {
/* 4237 */           buf.append(replaceChars.charAt(index));
/*      */         }
/*      */       } else {
/* 4240 */         buf.append(ch);
/*      */       }
/*      */     }
/* 4243 */     if (modified) {
/* 4244 */       return buf.toString();
/*      */     }
/* 4246 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String overlay(String str, String overlay, int start, int end)
/*      */   {
/* 4281 */     if (str == null) {
/* 4282 */       return null;
/*      */     }
/* 4284 */     if (overlay == null) {
/* 4285 */       overlay = "";
/*      */     }
/* 4287 */     int len = str.length();
/* 4288 */     if (start < 0) {
/* 4289 */       start = 0;
/*      */     }
/* 4291 */     if (start > len) {
/* 4292 */       start = len;
/*      */     }
/* 4294 */     if (end < 0) {
/* 4295 */       end = 0;
/*      */     }
/* 4297 */     if (end > len) {
/* 4298 */       end = len;
/*      */     }
/* 4300 */     if (start > end) {
/* 4301 */       int temp = start;
/* 4302 */       start = end;
/* 4303 */       end = temp;
/*      */     }
/* 4305 */     return len + start - end + overlay.length() + 1 + str.substring(0, start) + overlay + str.substring(end);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String chomp(String str)
/*      */   {
/* 4340 */     if (isEmpty(str)) {
/* 4341 */       return str;
/*      */     }
/*      */     
/* 4344 */     if (str.length() == 1) {
/* 4345 */       char ch = str.charAt(0);
/* 4346 */       if ((ch == '\r') || (ch == '\n')) {
/* 4347 */         return "";
/*      */       }
/* 4349 */       return str;
/*      */     }
/*      */     
/* 4352 */     int lastIdx = str.length() - 1;
/* 4353 */     char last = str.charAt(lastIdx);
/*      */     
/* 4355 */     if (last == '\n') {
/* 4356 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 4357 */         lastIdx--;
/*      */       }
/* 4359 */     } else if (last != '\r') {
/* 4360 */       lastIdx++;
/*      */     }
/* 4362 */     return str.substring(0, lastIdx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public static String chomp(String str, String separator)
/*      */   {
/* 4394 */     return removeEnd(str, separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String chop(String str)
/*      */   {
/* 4423 */     if (str == null) {
/* 4424 */       return null;
/*      */     }
/* 4426 */     int strLen = str.length();
/* 4427 */     if (strLen < 2) {
/* 4428 */       return "";
/*      */     }
/* 4430 */     int lastIdx = strLen - 1;
/* 4431 */     String ret = str.substring(0, lastIdx);
/* 4432 */     char last = str.charAt(lastIdx);
/* 4433 */     if ((last == '\n') && (ret.charAt(lastIdx - 1) == '\r')) {
/* 4434 */       return ret.substring(0, lastIdx - 1);
/*      */     }
/* 4436 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String repeat(String str, int repeat)
/*      */   {
/* 4465 */     if (str == null) {
/* 4466 */       return null;
/*      */     }
/* 4468 */     if (repeat <= 0) {
/* 4469 */       return "";
/*      */     }
/* 4471 */     int inputLength = str.length();
/* 4472 */     if ((repeat == 1) || (inputLength == 0)) {
/* 4473 */       return str;
/*      */     }
/* 4475 */     if ((inputLength == 1) && (repeat <= 8192)) {
/* 4476 */       return repeat(str.charAt(0), repeat);
/*      */     }
/*      */     
/* 4479 */     int outputLength = inputLength * repeat;
/* 4480 */     switch (inputLength) {
/*      */     case 1: 
/* 4482 */       return repeat(str.charAt(0), repeat);
/*      */     case 2: 
/* 4484 */       char ch0 = str.charAt(0);
/* 4485 */       char ch1 = str.charAt(1);
/* 4486 */       char[] output2 = new char[outputLength];
/* 4487 */       for (int i = repeat * 2 - 2; i >= 0; i--) {
/* 4488 */         output2[i] = ch0;
/* 4489 */         output2[(i + 1)] = ch1;i--;
/*      */       }
/*      */       
/* 4491 */       return new String(output2);
/*      */     }
/* 4493 */     StringBuilder buf = new StringBuilder(outputLength);
/* 4494 */     for (int i = 0; i < repeat; i++) {
/* 4495 */       buf.append(str);
/*      */     }
/* 4497 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String repeat(String str, String separator, int repeat)
/*      */   {
/* 4522 */     if ((str == null) || (separator == null)) {
/* 4523 */       return repeat(str, repeat);
/*      */     }
/*      */     
/* 4526 */     String result = repeat(str + separator, repeat);
/* 4527 */     return removeEnd(result, separator);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String repeat(char ch, int repeat)
/*      */   {
/* 4554 */     char[] buf = new char[repeat];
/* 4555 */     for (int i = repeat - 1; i >= 0; i--) {
/* 4556 */       buf[i] = ch;
/*      */     }
/* 4558 */     return new String(buf);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String rightPad(String str, int size)
/*      */   {
/* 4581 */     return rightPad(str, size, ' ');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String rightPad(String str, int size, char padChar)
/*      */   {
/* 4606 */     if (str == null) {
/* 4607 */       return null;
/*      */     }
/* 4609 */     int pads = size - str.length();
/* 4610 */     if (pads <= 0) {
/* 4611 */       return str;
/*      */     }
/* 4613 */     if (pads > 8192) {
/* 4614 */       return rightPad(str, size, String.valueOf(padChar));
/*      */     }
/* 4616 */     return str.concat(repeat(padChar, pads));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String rightPad(String str, int size, String padStr)
/*      */   {
/* 4643 */     if (str == null) {
/* 4644 */       return null;
/*      */     }
/* 4646 */     if (isEmpty(padStr)) {
/* 4647 */       padStr = " ";
/*      */     }
/* 4649 */     int padLen = padStr.length();
/* 4650 */     int strLen = str.length();
/* 4651 */     int pads = size - strLen;
/* 4652 */     if (pads <= 0) {
/* 4653 */       return str;
/*      */     }
/* 4655 */     if ((padLen == 1) && (pads <= 8192)) {
/* 4656 */       return rightPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 4659 */     if (pads == padLen)
/* 4660 */       return str.concat(padStr);
/* 4661 */     if (pads < padLen) {
/* 4662 */       return str.concat(padStr.substring(0, pads));
/*      */     }
/* 4664 */     char[] padding = new char[pads];
/* 4665 */     char[] padChars = padStr.toCharArray();
/* 4666 */     for (int i = 0; i < pads; i++) {
/* 4667 */       padding[i] = padChars[(i % padLen)];
/*      */     }
/* 4669 */     return str.concat(new String(padding));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String leftPad(String str, int size)
/*      */   {
/* 4693 */     return leftPad(str, size, ' ');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String leftPad(String str, int size, char padChar)
/*      */   {
/* 4718 */     if (str == null) {
/* 4719 */       return null;
/*      */     }
/* 4721 */     int pads = size - str.length();
/* 4722 */     if (pads <= 0) {
/* 4723 */       return str;
/*      */     }
/* 4725 */     if (pads > 8192) {
/* 4726 */       return leftPad(str, size, String.valueOf(padChar));
/*      */     }
/* 4728 */     return repeat(padChar, pads).concat(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String leftPad(String str, int size, String padStr)
/*      */   {
/* 4755 */     if (str == null) {
/* 4756 */       return null;
/*      */     }
/* 4758 */     if (isEmpty(padStr)) {
/* 4759 */       padStr = " ";
/*      */     }
/* 4761 */     int padLen = padStr.length();
/* 4762 */     int strLen = str.length();
/* 4763 */     int pads = size - strLen;
/* 4764 */     if (pads <= 0) {
/* 4765 */       return str;
/*      */     }
/* 4767 */     if ((padLen == 1) && (pads <= 8192)) {
/* 4768 */       return leftPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 4771 */     if (pads == padLen)
/* 4772 */       return padStr.concat(str);
/* 4773 */     if (pads < padLen) {
/* 4774 */       return padStr.substring(0, pads).concat(str);
/*      */     }
/* 4776 */     char[] padding = new char[pads];
/* 4777 */     char[] padChars = padStr.toCharArray();
/* 4778 */     for (int i = 0; i < pads; i++) {
/* 4779 */       padding[i] = padChars[(i % padLen)];
/*      */     }
/* 4781 */     return new String(padding).concat(str);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int length(CharSequence cs)
/*      */   {
/* 4797 */     return cs == null ? 0 : cs.length();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String center(String str, int size)
/*      */   {
/* 4826 */     return center(str, size, ' ');
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String center(String str, int size, char padChar)
/*      */   {
/* 4854 */     if ((str == null) || (size <= 0)) {
/* 4855 */       return str;
/*      */     }
/* 4857 */     int strLen = str.length();
/* 4858 */     int pads = size - strLen;
/* 4859 */     if (pads <= 0) {
/* 4860 */       return str;
/*      */     }
/* 4862 */     str = leftPad(str, strLen + pads / 2, padChar);
/* 4863 */     str = rightPad(str, size, padChar);
/* 4864 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String center(String str, int size, String padStr)
/*      */   {
/* 4894 */     if ((str == null) || (size <= 0)) {
/* 4895 */       return str;
/*      */     }
/* 4897 */     if (isEmpty(padStr)) {
/* 4898 */       padStr = " ";
/*      */     }
/* 4900 */     int strLen = str.length();
/* 4901 */     int pads = size - strLen;
/* 4902 */     if (pads <= 0) {
/* 4903 */       return str;
/*      */     }
/* 4905 */     str = leftPad(str, strLen + pads / 2, padStr);
/* 4906 */     str = rightPad(str, size, padStr);
/* 4907 */     return str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String upperCase(String str)
/*      */   {
/* 4932 */     if (str == null) {
/* 4933 */       return null;
/*      */     }
/* 4935 */     return str.toUpperCase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String upperCase(String str, Locale locale)
/*      */   {
/* 4955 */     if (str == null) {
/* 4956 */       return null;
/*      */     }
/* 4958 */     return str.toUpperCase(locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String lowerCase(String str)
/*      */   {
/* 4981 */     if (str == null) {
/* 4982 */       return null;
/*      */     }
/* 4984 */     return str.toLowerCase();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String lowerCase(String str, Locale locale)
/*      */   {
/* 5004 */     if (str == null) {
/* 5005 */       return null;
/*      */     }
/* 5007 */     return str.toLowerCase(locale);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String capitalize(String str)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5032 */     if ((str == null) || ((strLen = str.length()) == 0))
/* 5033 */       return str;
/*      */     int strLen;
/* 5035 */     return strLen + Character.toTitleCase(str.charAt(0)) + str.substring(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String uncapitalize(String str)
/*      */   {
/*      */     int strLen;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5063 */     if ((str == null) || ((strLen = str.length()) == 0))
/* 5064 */       return str;
/*      */     int strLen;
/* 5066 */     return strLen + Character.toLowerCase(str.charAt(0)) + str.substring(1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String swapCase(String str)
/*      */   {
/* 5100 */     if (isEmpty(str)) {
/* 5101 */       return str;
/*      */     }
/*      */     
/* 5104 */     char[] buffer = str.toCharArray();
/*      */     
/* 5106 */     for (int i = 0; i < buffer.length; i++) {
/* 5107 */       char ch = buffer[i];
/* 5108 */       if (Character.isUpperCase(ch)) {
/* 5109 */         buffer[i] = Character.toLowerCase(ch);
/* 5110 */       } else if (Character.isTitleCase(ch)) {
/* 5111 */         buffer[i] = Character.toLowerCase(ch);
/* 5112 */       } else if (Character.isLowerCase(ch)) {
/* 5113 */         buffer[i] = Character.toUpperCase(ch);
/*      */       }
/*      */     }
/* 5116 */     return new String(buffer);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int countMatches(CharSequence str, CharSequence sub)
/*      */   {
/* 5142 */     if ((isEmpty(str)) || (isEmpty(sub))) {
/* 5143 */       return 0;
/*      */     }
/* 5145 */     int count = 0;
/* 5146 */     int idx = 0;
/* 5147 */     while ((idx = CharSequenceUtils.indexOf(str, sub, idx)) != -1) {
/* 5148 */       count++;
/* 5149 */       idx += sub.length();
/*      */     }
/* 5151 */     return count;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlpha(CharSequence cs)
/*      */   {
/* 5177 */     if ((cs == null) || (cs.length() == 0)) {
/* 5178 */       return false;
/*      */     }
/* 5180 */     int sz = cs.length();
/* 5181 */     for (int i = 0; i < sz; i++) {
/* 5182 */       if (!Character.isLetter(cs.charAt(i))) {
/* 5183 */         return false;
/*      */       }
/*      */     }
/* 5186 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlphaSpace(CharSequence cs)
/*      */   {
/* 5212 */     if (cs == null) {
/* 5213 */       return false;
/*      */     }
/* 5215 */     int sz = cs.length();
/* 5216 */     for (int i = 0; i < sz; i++) {
/* 5217 */       if ((!Character.isLetter(cs.charAt(i))) && (cs.charAt(i) != ' ')) {
/* 5218 */         return false;
/*      */       }
/*      */     }
/* 5221 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlphanumeric(CharSequence cs)
/*      */   {
/* 5247 */     if ((cs == null) || (cs.length() == 0)) {
/* 5248 */       return false;
/*      */     }
/* 5250 */     int sz = cs.length();
/* 5251 */     for (int i = 0; i < sz; i++) {
/* 5252 */       if (!Character.isLetterOrDigit(cs.charAt(i))) {
/* 5253 */         return false;
/*      */       }
/*      */     }
/* 5256 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAlphanumericSpace(CharSequence cs)
/*      */   {
/* 5282 */     if (cs == null) {
/* 5283 */       return false;
/*      */     }
/* 5285 */     int sz = cs.length();
/* 5286 */     for (int i = 0; i < sz; i++) {
/* 5287 */       if ((!Character.isLetterOrDigit(cs.charAt(i))) && (cs.charAt(i) != ' ')) {
/* 5288 */         return false;
/*      */       }
/*      */     }
/* 5291 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAsciiPrintable(CharSequence cs)
/*      */   {
/* 5321 */     if (cs == null) {
/* 5322 */       return false;
/*      */     }
/* 5324 */     int sz = cs.length();
/* 5325 */     for (int i = 0; i < sz; i++) {
/* 5326 */       if (!CharUtils.isAsciiPrintable(cs.charAt(i))) {
/* 5327 */         return false;
/*      */       }
/*      */     }
/* 5330 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNumeric(CharSequence cs)
/*      */   {
/* 5357 */     if ((cs == null) || (cs.length() == 0)) {
/* 5358 */       return false;
/*      */     }
/* 5360 */     int sz = cs.length();
/* 5361 */     for (int i = 0; i < sz; i++) {
/* 5362 */       if (!Character.isDigit(cs.charAt(i))) {
/* 5363 */         return false;
/*      */       }
/*      */     }
/* 5366 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isNumericSpace(CharSequence cs)
/*      */   {
/* 5394 */     if (cs == null) {
/* 5395 */       return false;
/*      */     }
/* 5397 */     int sz = cs.length();
/* 5398 */     for (int i = 0; i < sz; i++) {
/* 5399 */       if ((!Character.isDigit(cs.charAt(i))) && (cs.charAt(i) != ' ')) {
/* 5400 */         return false;
/*      */       }
/*      */     }
/* 5403 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isWhitespace(CharSequence cs)
/*      */   {
/* 5427 */     if (cs == null) {
/* 5428 */       return false;
/*      */     }
/* 5430 */     int sz = cs.length();
/* 5431 */     for (int i = 0; i < sz; i++) {
/* 5432 */       if (!Character.isWhitespace(cs.charAt(i))) {
/* 5433 */         return false;
/*      */       }
/*      */     }
/* 5436 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAllLowerCase(CharSequence cs)
/*      */   {
/* 5459 */     if ((cs == null) || (isEmpty(cs))) {
/* 5460 */       return false;
/*      */     }
/* 5462 */     int sz = cs.length();
/* 5463 */     for (int i = 0; i < sz; i++) {
/* 5464 */       if (!Character.isLowerCase(cs.charAt(i))) {
/* 5465 */         return false;
/*      */       }
/*      */     }
/* 5468 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isAllUpperCase(CharSequence cs)
/*      */   {
/* 5491 */     if ((cs == null) || (isEmpty(cs))) {
/* 5492 */       return false;
/*      */     }
/* 5494 */     int sz = cs.length();
/* 5495 */     for (int i = 0; i < sz; i++) {
/* 5496 */       if (!Character.isUpperCase(cs.charAt(i))) {
/* 5497 */         return false;
/*      */       }
/*      */     }
/* 5500 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String defaultString(String str)
/*      */   {
/* 5522 */     return str == null ? "" : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String defaultString(String str, String defaultStr)
/*      */   {
/* 5543 */     return str == null ? defaultStr : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T extends CharSequence> T defaultIfBlank(T str, T defaultStr)
/*      */   {
/* 5565 */     return isBlank(str) ? defaultStr : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static <T extends CharSequence> T defaultIfEmpty(T str, T defaultStr)
/*      */   {
/* 5587 */     return isEmpty(str) ? defaultStr : str;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String reverse(String str)
/*      */   {
/* 5607 */     if (str == null) {
/* 5608 */       return null;
/*      */     }
/* 5610 */     return new StringBuilder(str).reverse().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String reverseDelimited(String str, char separatorChar)
/*      */   {
/* 5633 */     if (str == null) {
/* 5634 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 5638 */     String[] strs = split(str, separatorChar);
/* 5639 */     ArrayUtils.reverse(strs);
/* 5640 */     return join(strs, separatorChar);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String abbreviate(String str, int maxWidth)
/*      */   {
/* 5678 */     return abbreviate(str, 0, maxWidth);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String abbreviate(String str, int offset, int maxWidth)
/*      */   {
/* 5717 */     if (str == null) {
/* 5718 */       return null;
/*      */     }
/* 5720 */     if (maxWidth < 4) {
/* 5721 */       throw new IllegalArgumentException("Minimum abbreviation width is 4");
/*      */     }
/* 5723 */     if (str.length() <= maxWidth) {
/* 5724 */       return str;
/*      */     }
/* 5726 */     if (offset > str.length()) {
/* 5727 */       offset = str.length();
/*      */     }
/* 5729 */     if (str.length() - offset < maxWidth - 3) {
/* 5730 */       offset = str.length() - (maxWidth - 3);
/*      */     }
/* 5732 */     String abrevMarker = "...";
/* 5733 */     if (offset <= 4) {
/* 5734 */       return str.substring(0, maxWidth - 3) + "...";
/*      */     }
/* 5736 */     if (maxWidth < 7) {
/* 5737 */       throw new IllegalArgumentException("Minimum abbreviation width with offset is 7");
/*      */     }
/* 5739 */     if (offset + maxWidth - 3 < str.length()) {
/* 5740 */       return "..." + abbreviate(str.substring(offset), maxWidth - 3);
/*      */     }
/* 5742 */     return "..." + str.substring(str.length() - (maxWidth - 3));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String abbreviateMiddle(String str, String middle, int length)
/*      */   {
/* 5775 */     if ((isEmpty(str)) || (isEmpty(middle))) {
/* 5776 */       return str;
/*      */     }
/*      */     
/* 5779 */     if ((length >= str.length()) || (length < middle.length() + 2)) {
/* 5780 */       return str;
/*      */     }
/*      */     
/* 5783 */     int targetSting = length - middle.length();
/* 5784 */     int startOffset = targetSting / 2 + targetSting % 2;
/* 5785 */     int endOffset = str.length() - targetSting / 2;
/*      */     
/* 5787 */     StringBuilder builder = new StringBuilder(length);
/* 5788 */     builder.append(str.substring(0, startOffset));
/* 5789 */     builder.append(middle);
/* 5790 */     builder.append(str.substring(endOffset));
/*      */     
/* 5792 */     return builder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String difference(String str1, String str2)
/*      */   {
/* 5823 */     if (str1 == null) {
/* 5824 */       return str2;
/*      */     }
/* 5826 */     if (str2 == null) {
/* 5827 */       return str1;
/*      */     }
/* 5829 */     int at = indexOfDifference(str1, str2);
/* 5830 */     if (at == -1) {
/* 5831 */       return "";
/*      */     }
/* 5833 */     return str2.substring(at);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfDifference(CharSequence cs1, CharSequence cs2)
/*      */   {
/* 5862 */     if (cs1 == cs2) {
/* 5863 */       return -1;
/*      */     }
/* 5865 */     if ((cs1 == null) || (cs2 == null)) {
/* 5866 */       return 0;
/*      */     }
/*      */     
/* 5869 */     for (int i = 0; (i < cs1.length()) && (i < cs2.length()); i++) {
/* 5870 */       if (cs1.charAt(i) != cs2.charAt(i)) {
/*      */         break;
/*      */       }
/*      */     }
/* 5874 */     if ((i < cs2.length()) || (i < cs1.length())) {
/* 5875 */       return i;
/*      */     }
/* 5877 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int indexOfDifference(CharSequence... css)
/*      */   {
/* 5913 */     if ((css == null) || (css.length <= 1)) {
/* 5914 */       return -1;
/*      */     }
/* 5916 */     boolean anyStringNull = false;
/* 5917 */     boolean allStringsNull = true;
/* 5918 */     int arrayLen = css.length;
/* 5919 */     int shortestStrLen = Integer.MAX_VALUE;
/* 5920 */     int longestStrLen = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5925 */     for (int i = 0; i < arrayLen; i++) {
/* 5926 */       if (css[i] == null) {
/* 5927 */         anyStringNull = true;
/* 5928 */         shortestStrLen = 0;
/*      */       } else {
/* 5930 */         allStringsNull = false;
/* 5931 */         shortestStrLen = Math.min(css[i].length(), shortestStrLen);
/* 5932 */         longestStrLen = Math.max(css[i].length(), longestStrLen);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5937 */     if ((allStringsNull) || ((longestStrLen == 0) && (!anyStringNull))) {
/* 5938 */       return -1;
/*      */     }
/*      */     
/*      */ 
/* 5942 */     if (shortestStrLen == 0) {
/* 5943 */       return 0;
/*      */     }
/*      */     
/*      */ 
/* 5947 */     int firstDiff = -1;
/* 5948 */     for (int stringPos = 0; stringPos < shortestStrLen; stringPos++) {
/* 5949 */       char comparisonChar = css[0].charAt(stringPos);
/* 5950 */       for (int arrayPos = 1; arrayPos < arrayLen; arrayPos++) {
/* 5951 */         if (css[arrayPos].charAt(stringPos) != comparisonChar) {
/* 5952 */           firstDiff = stringPos;
/* 5953 */           break;
/*      */         }
/*      */       }
/* 5956 */       if (firstDiff != -1) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     
/* 5961 */     if ((firstDiff == -1) && (shortestStrLen != longestStrLen))
/*      */     {
/*      */ 
/*      */ 
/* 5965 */       return shortestStrLen;
/*      */     }
/* 5967 */     return firstDiff;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getCommonPrefix(String... strs)
/*      */   {
/* 6004 */     if ((strs == null) || (strs.length == 0)) {
/* 6005 */       return "";
/*      */     }
/* 6007 */     int smallestIndexOfDiff = indexOfDifference(strs);
/* 6008 */     if (smallestIndexOfDiff == -1)
/*      */     {
/* 6010 */       if (strs[0] == null) {
/* 6011 */         return "";
/*      */       }
/* 6013 */       return strs[0]; }
/* 6014 */     if (smallestIndexOfDiff == 0)
/*      */     {
/* 6016 */       return "";
/*      */     }
/*      */     
/* 6019 */     return strs[0].substring(0, smallestIndexOfDiff);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getLevenshteinDistance(CharSequence s, CharSequence t)
/*      */   {
/* 6062 */     if ((s == null) || (t == null)) {
/* 6063 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6083 */     int n = s.length();
/* 6084 */     int m = t.length();
/*      */     
/* 6086 */     if (n == 0)
/* 6087 */       return m;
/* 6088 */     if (m == 0) {
/* 6089 */       return n;
/*      */     }
/*      */     
/* 6092 */     if (n > m)
/*      */     {
/* 6094 */       CharSequence tmp = s;
/* 6095 */       s = t;
/* 6096 */       t = tmp;
/* 6097 */       n = m;
/* 6098 */       m = t.length();
/*      */     }
/*      */     
/* 6101 */     int[] p = new int[n + 1];
/* 6102 */     int[] d = new int[n + 1];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6113 */     for (int i = 0; i <= n; i++) {
/* 6114 */       p[i] = i;
/*      */     }
/*      */     
/* 6117 */     for (int j = 1; j <= m; j++) {
/* 6118 */       char t_j = t.charAt(j - 1);
/* 6119 */       d[0] = j;
/*      */       
/* 6121 */       for (i = 1; i <= n; i++) {
/* 6122 */         int cost = s.charAt(i - 1) == t_j ? 0 : 1;
/*      */         
/* 6124 */         d[i] = Math.min(Math.min(d[(i - 1)] + 1, p[i] + 1), p[(i - 1)] + cost);
/*      */       }
/*      */       
/*      */ 
/* 6128 */       int[] _d = p;
/* 6129 */       p = d;
/* 6130 */       d = _d;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 6135 */     return p[n];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getLevenshteinDistance(CharSequence s, CharSequence t, int threshold)
/*      */   {
/* 6171 */     if ((s == null) || (t == null)) {
/* 6172 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/* 6174 */     if (threshold < 0) {
/* 6175 */       throw new IllegalArgumentException("Threshold must not be negative");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6222 */     int n = s.length();
/* 6223 */     int m = t.length();
/*      */     
/*      */ 
/* 6226 */     if (n == 0)
/* 6227 */       return m <= threshold ? m : -1;
/* 6228 */     if (m == 0) {
/* 6229 */       return n <= threshold ? n : -1;
/*      */     }
/*      */     
/* 6232 */     if (n > m)
/*      */     {
/* 6234 */       CharSequence tmp = s;
/* 6235 */       s = t;
/* 6236 */       t = tmp;
/* 6237 */       n = m;
/* 6238 */       m = t.length();
/*      */     }
/*      */     
/* 6241 */     int[] p = new int[n + 1];
/* 6242 */     int[] d = new int[n + 1];
/*      */     
/*      */ 
/*      */ 
/* 6246 */     int boundary = Math.min(n, threshold) + 1;
/* 6247 */     for (int i = 0; i < boundary; i++) {
/* 6248 */       p[i] = i;
/*      */     }
/*      */     
/*      */ 
/* 6252 */     Arrays.fill(p, boundary, p.length, Integer.MAX_VALUE);
/* 6253 */     Arrays.fill(d, Integer.MAX_VALUE);
/*      */     
/*      */ 
/* 6256 */     for (int j = 1; j <= m; j++) {
/* 6257 */       char t_j = t.charAt(j - 1);
/* 6258 */       d[0] = j;
/*      */       
/*      */ 
/* 6261 */       int min = Math.max(1, j - threshold);
/* 6262 */       int max = Math.min(n, j + threshold);
/*      */       
/*      */ 
/* 6265 */       if (min > max) {
/* 6266 */         return -1;
/*      */       }
/*      */       
/*      */ 
/* 6270 */       if (min > 1) {
/* 6271 */         d[(min - 1)] = Integer.MAX_VALUE;
/*      */       }
/*      */       
/*      */ 
/* 6275 */       for (int i = min; i <= max; i++) {
/* 6276 */         if (s.charAt(i - 1) == t_j)
/*      */         {
/* 6278 */           d[i] = p[(i - 1)];
/*      */         }
/*      */         else {
/* 6281 */           d[i] = (1 + Math.min(Math.min(d[(i - 1)], p[i]), p[(i - 1)]));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 6286 */       int[] _d = p;
/* 6287 */       p = d;
/* 6288 */       d = _d;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 6293 */     if (p[n] <= threshold) {
/* 6294 */       return p[n];
/*      */     }
/* 6296 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWith(CharSequence str, CharSequence prefix)
/*      */   {
/* 6326 */     return startsWith(str, prefix, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(CharSequence str, CharSequence prefix)
/*      */   {
/* 6352 */     return startsWith(str, prefix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean startsWith(CharSequence str, CharSequence prefix, boolean ignoreCase)
/*      */   {
/* 6367 */     if ((str == null) || (prefix == null)) {
/* 6368 */       return (str == null) && (prefix == null);
/*      */     }
/* 6370 */     if (prefix.length() > str.length()) {
/* 6371 */       return false;
/*      */     }
/* 6373 */     return CharSequenceUtils.regionMatches(str, ignoreCase, 0, prefix, 0, prefix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean startsWithAny(CharSequence string, CharSequence... searchStrings)
/*      */   {
/* 6396 */     if ((isEmpty(string)) || (ArrayUtils.isEmpty(searchStrings))) {
/* 6397 */       return false;
/*      */     }
/* 6399 */     for (CharSequence searchString : searchStrings) {
/* 6400 */       if (startsWith(string, searchString)) {
/* 6401 */         return true;
/*      */       }
/*      */     }
/* 6404 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWith(CharSequence str, CharSequence suffix)
/*      */   {
/* 6434 */     return endsWith(str, suffix, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWithIgnoreCase(CharSequence str, CharSequence suffix)
/*      */   {
/* 6461 */     return endsWith(str, suffix, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static boolean endsWith(CharSequence str, CharSequence suffix, boolean ignoreCase)
/*      */   {
/* 6476 */     if ((str == null) || (suffix == null)) {
/* 6477 */       return (str == null) && (suffix == null);
/*      */     }
/* 6479 */     if (suffix.length() > str.length()) {
/* 6480 */       return false;
/*      */     }
/* 6482 */     int strOffset = str.length() - suffix.length();
/* 6483 */     return CharSequenceUtils.regionMatches(str, ignoreCase, strOffset, suffix, 0, suffix.length());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String normalizeSpace(String str)
/*      */   {
/* 6528 */     if (str == null) {
/* 6529 */       return null;
/*      */     }
/* 6531 */     return WHITESPACE_BLOCK.matcher(trim(str)).replaceAll(" ");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean endsWithAny(CharSequence string, CharSequence... searchStrings)
/*      */   {
/* 6553 */     if ((isEmpty(string)) || (ArrayUtils.isEmpty(searchStrings))) {
/* 6554 */       return false;
/*      */     }
/* 6556 */     for (CharSequence searchString : searchStrings) {
/* 6557 */       if (endsWith(string, searchString)) {
/* 6558 */         return true;
/*      */       }
/*      */     }
/* 6561 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String toString(byte[] bytes, String charsetName)
/*      */     throws UnsupportedEncodingException
/*      */   {
/* 6579 */     return charsetName == null ? new String(bytes) : new String(bytes, charsetName);
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-lang3-3.1.jar!\org\apache\commons\lang3\StringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */