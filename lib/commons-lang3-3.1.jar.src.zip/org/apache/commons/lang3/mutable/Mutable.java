package org.apache.commons.lang3.mutable;

public abstract interface Mutable<T>
{
  public abstract T getValue();
  
  public abstract void setValue(T paramT);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\commons-lang3-3.1.jar!\org\apache\commons\lang3\mutable\Mutable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */