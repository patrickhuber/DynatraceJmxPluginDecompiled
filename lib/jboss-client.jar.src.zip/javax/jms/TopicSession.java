package javax.jms;

public abstract interface TopicSession
  extends Session
{
  public abstract Topic createTopic(String paramString)
    throws JMSException;
  
  public abstract TopicSubscriber createSubscriber(Topic paramTopic)
    throws JMSException;
  
  public abstract TopicSubscriber createSubscriber(Topic paramTopic, String paramString, boolean paramBoolean)
    throws JMSException;
  
  public abstract TopicSubscriber createDurableSubscriber(Topic paramTopic, String paramString)
    throws JMSException;
  
  public abstract TopicSubscriber createDurableSubscriber(Topic paramTopic, String paramString1, String paramString2, boolean paramBoolean)
    throws JMSException;
  
  public abstract TopicPublisher createPublisher(Topic paramTopic)
    throws JMSException;
  
  public abstract TemporaryTopic createTemporaryTopic()
    throws JMSException;
  
  public abstract void unsubscribe(String paramString)
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\TopicSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */