/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageFormatException
/*    */   extends JMSException
/*    */ {
/*    */   private static final long serialVersionUID = -3642297253594750138L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MessageFormatException(String reason, String errorCode)
/*    */   {
/* 31 */     super(reason, errorCode);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MessageFormatException(String reason)
/*    */   {
/* 41 */     super(reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\MessageFormatException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */