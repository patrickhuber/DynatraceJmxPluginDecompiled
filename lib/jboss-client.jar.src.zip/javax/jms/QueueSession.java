package javax.jms;

public abstract interface QueueSession
  extends Session
{
  public abstract Queue createQueue(String paramString)
    throws JMSException;
  
  public abstract QueueReceiver createReceiver(Queue paramQueue)
    throws JMSException;
  
  public abstract QueueReceiver createReceiver(Queue paramQueue, String paramString)
    throws JMSException;
  
  public abstract QueueSender createSender(Queue paramQueue)
    throws JMSException;
  
  public abstract QueueBrowser createBrowser(Queue paramQueue)
    throws JMSException;
  
  public abstract QueueBrowser createBrowser(Queue paramQueue, String paramString)
    throws JMSException;
  
  public abstract TemporaryQueue createTemporaryQueue()
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\QueueSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */