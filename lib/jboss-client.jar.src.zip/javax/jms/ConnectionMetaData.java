package javax.jms;

import java.util.Enumeration;

public abstract interface ConnectionMetaData
{
  public abstract String getJMSVersion()
    throws JMSException;
  
  public abstract int getJMSMajorVersion()
    throws JMSException;
  
  public abstract int getJMSMinorVersion()
    throws JMSException;
  
  public abstract String getJMSProviderName()
    throws JMSException;
  
  public abstract String getProviderVersion()
    throws JMSException;
  
  public abstract int getProviderMajorVersion()
    throws JMSException;
  
  public abstract int getProviderMinorVersion()
    throws JMSException;
  
  public abstract Enumeration getJMSXPropertyNames()
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\ConnectionMetaData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */