package javax.jms;

public abstract interface QueueSender
  extends MessageProducer
{
  public abstract Queue getQueue()
    throws JMSException;
  
  public abstract void send(Message paramMessage)
    throws JMSException;
  
  public abstract void send(Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
  
  public abstract void send(Queue paramQueue, Message paramMessage)
    throws JMSException;
  
  public abstract void send(Queue paramQueue, Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\QueueSender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */