package javax.jms;

public abstract interface QueueConnectionFactory
  extends ConnectionFactory
{
  public abstract QueueConnection createQueueConnection()
    throws JMSException;
  
  public abstract QueueConnection createQueueConnection(String paramString1, String paramString2)
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\QueueConnectionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */