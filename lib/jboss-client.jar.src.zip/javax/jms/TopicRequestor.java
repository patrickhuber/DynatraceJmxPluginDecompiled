/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TopicRequestor
/*    */ {
/* 15 */   private TopicSession topicSession = null;
/*    */   
/* 17 */   private TopicPublisher requestPublisher = null;
/*    */   
/* 19 */   private TemporaryTopic responseTopic = null;
/*    */   
/* 21 */   private TopicSubscriber responseSubscriber = null;
/*    */   
/*    */   public TopicRequestor(TopicSession session, Topic topic) throws JMSException
/*    */   {
/* 25 */     this.topicSession = session;
/* 26 */     this.requestPublisher = this.topicSession.createPublisher(topic);
/* 27 */     this.responseTopic = this.topicSession.createTemporaryTopic();
/* 28 */     this.responseSubscriber = this.topicSession.createSubscriber(this.responseTopic);
/*    */   }
/*    */   
/*    */   public Message request(Message message) throws JMSException
/*    */   {
/* 33 */     message.setJMSReplyTo(this.responseTopic);
/* 34 */     this.requestPublisher.publish(message);
/* 35 */     return this.responseSubscriber.receive();
/*    */   }
/*    */   
/*    */   public void close() throws JMSException
/*    */   {
/*    */     try
/*    */     {
/* 42 */       this.responseSubscriber.close();
/*    */     }
/*    */     catch (JMSException ignored) {}
/*    */     
/*    */ 
/*    */     try
/*    */     {
/* 49 */       this.responseTopic.delete();
/*    */     }
/*    */     catch (JMSException ignored) {}
/*    */     
/*    */ 
/* 54 */     this.topicSession.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\TopicRequestor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */