package javax.jms;

public abstract interface MessageConsumer
{
  public abstract String getMessageSelector()
    throws JMSException;
  
  public abstract MessageListener getMessageListener()
    throws JMSException;
  
  public abstract void setMessageListener(MessageListener paramMessageListener)
    throws JMSException;
  
  public abstract Message receive()
    throws JMSException;
  
  public abstract Message receive(long paramLong)
    throws JMSException;
  
  public abstract Message receiveNoWait()
    throws JMSException;
  
  public abstract void close()
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\MessageConsumer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */