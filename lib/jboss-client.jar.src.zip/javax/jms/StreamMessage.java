package javax.jms;

public abstract interface StreamMessage
  extends Message
{
  public abstract boolean readBoolean()
    throws JMSException;
  
  public abstract byte readByte()
    throws JMSException;
  
  public abstract short readShort()
    throws JMSException;
  
  public abstract char readChar()
    throws JMSException;
  
  public abstract int readInt()
    throws JMSException;
  
  public abstract long readLong()
    throws JMSException;
  
  public abstract float readFloat()
    throws JMSException;
  
  public abstract double readDouble()
    throws JMSException;
  
  public abstract String readString()
    throws JMSException;
  
  public abstract int readBytes(byte[] paramArrayOfByte)
    throws JMSException;
  
  public abstract Object readObject()
    throws JMSException;
  
  public abstract void writeBoolean(boolean paramBoolean)
    throws JMSException;
  
  public abstract void writeByte(byte paramByte)
    throws JMSException;
  
  public abstract void writeShort(short paramShort)
    throws JMSException;
  
  public abstract void writeChar(char paramChar)
    throws JMSException;
  
  public abstract void writeInt(int paramInt)
    throws JMSException;
  
  public abstract void writeLong(long paramLong)
    throws JMSException;
  
  public abstract void writeFloat(float paramFloat)
    throws JMSException;
  
  public abstract void writeDouble(double paramDouble)
    throws JMSException;
  
  public abstract void writeString(String paramString)
    throws JMSException;
  
  public abstract void writeBytes(byte[] paramArrayOfByte)
    throws JMSException;
  
  public abstract void writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws JMSException;
  
  public abstract void writeObject(Object paramObject)
    throws JMSException;
  
  public abstract void reset()
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\StreamMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */