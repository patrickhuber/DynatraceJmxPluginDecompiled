/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class QueueRequestor
/*    */ {
/* 12 */   private QueueSession queueSession = null;
/*    */   
/* 14 */   private QueueSender requestSender = null;
/*    */   
/* 16 */   private QueueReceiver replyReceiver = null;
/*    */   
/* 18 */   private TemporaryQueue replyQueue = null;
/*    */   
/*    */   public QueueRequestor(QueueSession session, Queue queue) throws JMSException
/*    */   {
/* 22 */     this.queueSession = session;
/*    */     
/* 24 */     this.requestSender = this.queueSession.createSender(queue);
/* 25 */     this.replyQueue = this.queueSession.createTemporaryQueue();
/* 26 */     this.replyReceiver = this.queueSession.createReceiver(this.replyQueue);
/*    */   }
/*    */   
/*    */   public Message request(Message message) throws JMSException
/*    */   {
/* 31 */     message.setJMSReplyTo(this.replyQueue);
/* 32 */     message.setJMSDeliveryMode(1);
/* 33 */     this.requestSender.send(message);
/* 34 */     return this.replyReceiver.receive();
/*    */   }
/*    */   
/*    */   public void close() throws JMSException
/*    */   {
/*    */     try
/*    */     {
/* 41 */       this.replyReceiver.close();
/*    */     }
/*    */     catch (JMSException ignored) {}
/*    */     
/*    */ 
/*    */     try
/*    */     {
/* 48 */       this.replyQueue.delete();
/*    */     }
/*    */     catch (JMSException ignored) {}
/*    */     
/*    */ 
/* 53 */     this.queueSession.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\QueueRequestor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */