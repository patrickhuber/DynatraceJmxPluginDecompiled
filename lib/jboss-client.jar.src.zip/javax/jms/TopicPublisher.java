package javax.jms;

public abstract interface TopicPublisher
  extends MessageProducer
{
  public abstract Topic getTopic()
    throws JMSException;
  
  public abstract void publish(Message paramMessage)
    throws JMSException;
  
  public abstract void publish(Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
  
  public abstract void publish(Topic paramTopic, Message paramMessage)
    throws JMSException;
  
  public abstract void publish(Topic paramTopic, Message paramMessage, int paramInt1, int paramInt2, long paramLong)
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\TopicPublisher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */