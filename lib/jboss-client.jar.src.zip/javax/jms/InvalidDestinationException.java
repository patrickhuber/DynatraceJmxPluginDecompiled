/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidDestinationException
/*    */   extends JMSException
/*    */ {
/*    */   private static final long serialVersionUID = -8588063794606036755L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidDestinationException(String reason, String errorCode)
/*    */   {
/* 23 */     super(reason, errorCode);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public InvalidDestinationException(String reason)
/*    */   {
/* 33 */     super(reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\InvalidDestinationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */