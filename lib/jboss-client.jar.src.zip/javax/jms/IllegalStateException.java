/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalStateException
/*    */   extends JMSException
/*    */ {
/*    */   private static final long serialVersionUID = -6850763061112244487L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IllegalStateException(String reason, String errorCode)
/*    */   {
/* 27 */     super(reason, errorCode);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IllegalStateException(String reason)
/*    */   {
/* 37 */     super(reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\IllegalStateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */