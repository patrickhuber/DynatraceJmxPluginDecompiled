/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMSException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 8951994251593378324L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String errorCode;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Exception linkedException;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JMSException(String reason, String errorCode)
/*    */   {
/* 39 */     super(reason);
/* 40 */     this.errorCode = errorCode;
/* 41 */     this.linkedException = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JMSException(String reason)
/*    */   {
/* 51 */     super(reason);
/* 52 */     this.errorCode = null;
/* 53 */     this.linkedException = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getErrorCode()
/*    */   {
/* 62 */     return this.errorCode;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Exception getLinkedException()
/*    */   {
/* 72 */     return this.linkedException;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public synchronized void setLinkedException(Exception ex)
/*    */   {
/* 82 */     this.linkedException = ex;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\JMSException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */