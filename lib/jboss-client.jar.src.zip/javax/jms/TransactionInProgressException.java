/*    */ package javax.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransactionInProgressException
/*    */   extends JMSException
/*    */ {
/*    */   private static final long serialVersionUID = -5611340150426335231L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TransactionInProgressException(String reason, String errorCode)
/*    */   {
/* 25 */     super(reason, errorCode);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TransactionInProgressException(String reason)
/*    */   {
/* 35 */     super(reason);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\TransactionInProgressException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */