package javax.jms;

public abstract interface TextMessage
  extends Message
{
  public abstract void setText(String paramString)
    throws JMSException;
  
  public abstract String getText()
    throws JMSException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\jms\TextMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */