package javax.transaction;

import javax.transaction.xa.XAResource;

public abstract interface Transaction
{
  public abstract void commit()
    throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, SystemException;
  
  public abstract void rollback()
    throws IllegalStateException, SystemException;
  
  public abstract void setRollbackOnly()
    throws IllegalStateException, SystemException;
  
  public abstract int getStatus()
    throws SystemException;
  
  public abstract boolean enlistResource(XAResource paramXAResource)
    throws RollbackException, IllegalStateException, SystemException;
  
  public abstract boolean delistResource(XAResource paramXAResource, int paramInt)
    throws IllegalStateException, SystemException;
  
  public abstract void registerSynchronization(Synchronization paramSynchronization)
    throws RollbackException, IllegalStateException, SystemException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\transaction\Transaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */