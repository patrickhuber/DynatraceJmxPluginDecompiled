package javax.transaction;

public abstract interface UserTransaction
{
  public abstract void begin()
    throws NotSupportedException, SystemException;
  
  public abstract void commit()
    throws RollbackException, HeuristicMixedException, HeuristicRollbackException, SecurityException, IllegalStateException, SystemException;
  
  public abstract void rollback()
    throws IllegalStateException, SecurityException, SystemException;
  
  public abstract void setRollbackOnly()
    throws IllegalStateException, SystemException;
  
  public abstract int getStatus()
    throws SystemException;
  
  public abstract void setTransactionTimeout(int paramInt)
    throws SystemException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\transaction\UserTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */