package javax.transaction;

public abstract interface TransactionSynchronizationRegistry
{
  public abstract Object getTransactionKey();
  
  public abstract int getTransactionStatus();
  
  public abstract boolean getRollbackOnly()
    throws IllegalStateException;
  
  public abstract void setRollbackOnly()
    throws IllegalStateException;
  
  public abstract void registerInterposedSynchronization(Synchronization paramSynchronization)
    throws IllegalStateException;
  
  public abstract Object getResource(Object paramObject)
    throws IllegalStateException;
  
  public abstract void putResource(Object paramObject1, Object paramObject2)
    throws IllegalStateException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\transaction\TransactionSynchronizationRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */