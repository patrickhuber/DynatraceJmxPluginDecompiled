/*    */ package javax.transaction.xa;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XAException
/*    */   extends Exception
/*    */ {
/* 13 */   public int errorCode = 0;
/*    */   
/*    */   public static final int XAER_ASYNC = -2;
/*    */   
/*    */   public static final int XAER_RMERR = -3;
/*    */   
/*    */   public static final int XAER_NOTA = -4;
/*    */   public static final int XAER_INVAL = -5;
/*    */   public static final int XAER_PROTO = -6;
/*    */   public static final int XAER_RMFAIL = -7;
/*    */   
/*    */   public XAException() {}
/*    */   
/*    */   public XAException(String msg)
/*    */   {
/* 28 */     super(msg);
/*    */   }
/*    */   
/*    */   public static final int XAER_DUPID = -8;
/*    */   public static final int XAER_OUTSIDE = -9;
/*    */   public static final int XA_RDONLY = 3;
/*    */   public static final int XA_RETRY = 4;
/*    */   public static final int XA_HEURMIX = 5;
/*    */   public static final int XA_HEURRB = 6;
/*    */   
/* 38 */   public XAException(int errorCode) { this.errorCode = errorCode; }
/*    */   
/*    */   public static final int XA_HEURCOM = 7;
/*    */   public static final int XA_HEURHAZ = 8;
/*    */   public static final int XA_NOMIGRATE = 9;
/*    */   public static final int XA_RBBASE = 100;
/*    */   public static final int XA_RBROLLBACK = 100;
/*    */   public static final int XA_RBCOMMFAIL = 101;
/*    */   public static final int XA_RBDEADLOCK = 102;
/*    */   public static final int XA_RBINTEGRITY = 103;
/*    */   public static final int XA_RBOTHER = 104;
/*    */   public static final int XA_RBPROTO = 105;
/*    */   public static final int XA_RBTIMEOUT = 106;
/*    */   public static final int XA_RBTRANSIENT = 107;
/*    */   public static final int XA_RBEND = 107;
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\transaction\xa\XAException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */