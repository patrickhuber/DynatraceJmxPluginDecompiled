package javax.transaction.xa;

public abstract interface Xid
{
  public static final int MAXGTRIDSIZE = 64;
  public static final int MAXBQUALSIZE = 64;
  
  public abstract int getFormatId();
  
  public abstract byte[] getGlobalTransactionId();
  
  public abstract byte[] getBranchQualifier();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\transaction\xa\Xid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */