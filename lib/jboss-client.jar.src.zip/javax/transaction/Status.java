package javax.transaction;

public abstract interface Status
{
  public static final int STATUS_ACTIVE = 0;
  public static final int STATUS_MARKED_ROLLBACK = 1;
  public static final int STATUS_PREPARED = 2;
  public static final int STATUS_COMMITTED = 3;
  public static final int STATUS_ROLLEDBACK = 4;
  public static final int STATUS_UNKNOWN = 5;
  public static final int STATUS_NO_TRANSACTION = 6;
  public static final int STATUS_PREPARING = 7;
  public static final int STATUS_COMMITTING = 8;
  public static final int STATUS_ROLLING_BACK = 9;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\transaction\Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */