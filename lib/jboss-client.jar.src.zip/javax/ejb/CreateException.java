/*    */ package javax.ejb;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 6295951740865457514L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CreateException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CreateException(String message)
/*    */   {
/* 30 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\CreateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */