/*    */ package javax.ejb;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FinderException
/*    */   extends Exception
/*    */ {
/*    */   public FinderException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FinderException(String message)
/*    */   {
/* 25 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\FinderException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */