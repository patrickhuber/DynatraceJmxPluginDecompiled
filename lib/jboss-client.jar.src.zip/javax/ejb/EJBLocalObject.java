package javax.ejb;

public abstract interface EJBLocalObject
{
  public abstract EJBLocalHome getEJBLocalHome()
    throws EJBException;
  
  public abstract Object getPrimaryKey()
    throws EJBException;
  
  public abstract void remove()
    throws RemoveException, EJBException;
  
  public abstract boolean isIdentical(EJBLocalObject paramEJBLocalObject)
    throws EJBException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EJBLocalObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */