/*    */ package javax.ejb;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimerConfig
/*    */ {
/*    */   private Serializable info;
/* 25 */   private boolean persistent = true;
/*    */   
/*    */ 
/*    */ 
/*    */   public TimerConfig() {}
/*    */   
/*    */ 
/*    */   public TimerConfig(Serializable info, boolean persistent)
/*    */   {
/* 34 */     this.info = info;
/* 35 */     this.persistent = persistent;
/*    */   }
/*    */   
/*    */   public Serializable getInfo()
/*    */   {
/* 40 */     return this.info;
/*    */   }
/*    */   
/*    */   public boolean isPersistent()
/*    */   {
/* 45 */     return this.persistent;
/*    */   }
/*    */   
/*    */   public void setInfo(Serializable i)
/*    */   {
/* 50 */     this.info = i;
/*    */   }
/*    */   
/*    */   public void setPersistent(boolean p)
/*    */   {
/* 55 */     this.persistent = p;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\TimerConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */