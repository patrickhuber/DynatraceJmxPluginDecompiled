package javax.ejb;

import java.io.Serializable;
import java.util.Date;

public abstract interface Timer
{
  public abstract void cancel()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  public abstract long getTimeRemaining()
    throws IllegalStateException, NoMoreTimeoutsException, NoSuchObjectLocalException, EJBException;
  
  public abstract Date getNextTimeout()
    throws IllegalStateException, NoMoreTimeoutsException, NoSuchObjectLocalException, EJBException;
  
  public abstract Serializable getInfo()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  public abstract TimerHandle getHandle()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  public abstract ScheduleExpression getSchedule()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  public abstract boolean isCalendarTimer()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
  
  public abstract boolean isPersistent()
    throws IllegalStateException, NoSuchObjectLocalException, EJBException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\Timer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */