/*    */ package javax.ejb;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EJBTransactionRolledbackException
/*    */   extends EJBException
/*    */ {
/*    */   public EJBTransactionRolledbackException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EJBTransactionRolledbackException(String message)
/*    */   {
/* 26 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EJBTransactionRolledbackException(String message, Exception ex)
/*    */   {
/* 37 */     super(message, ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EJBTransactionRolledbackException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */