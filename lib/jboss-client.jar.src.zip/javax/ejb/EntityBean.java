package javax.ejb;

import java.rmi.RemoteException;

public abstract interface EntityBean
  extends EnterpriseBean
{
  public abstract void setEntityContext(EntityContext paramEntityContext)
    throws EJBException, RemoteException;
  
  public abstract void unsetEntityContext()
    throws EJBException, RemoteException;
  
  public abstract void ejbRemove()
    throws RemoveException, EJBException, RemoteException;
  
  public abstract void ejbActivate()
    throws EJBException, RemoteException;
  
  public abstract void ejbPassivate()
    throws EJBException, RemoteException;
  
  public abstract void ejbLoad()
    throws EJBException, RemoteException;
  
  public abstract void ejbStore()
    throws EJBException, RemoteException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EntityBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */