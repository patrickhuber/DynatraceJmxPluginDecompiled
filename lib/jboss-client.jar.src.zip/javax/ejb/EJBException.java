/*    */ package javax.ejb;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EJBException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 796770993296843510L;
/*    */   
/*    */ 
/*    */ 
/*    */   private Exception causeException;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EJBException()
/*    */   {
/* 21 */     this.causeException = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EJBException(String message)
/*    */   {
/* 31 */     super(message);
/* 32 */     this.causeException = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EJBException(Exception ex)
/*    */   {
/* 42 */     super(ex);
/* 43 */     this.causeException = ex;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EJBException(String message, Exception ex)
/*    */   {
/* 55 */     super(message, ex);
/* 56 */     this.causeException = ex;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Exception getCausedByException()
/*    */   {
/* 66 */     return this.causeException;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EJBException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */