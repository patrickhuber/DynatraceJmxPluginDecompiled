/*    */ package javax.ejb;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalLoopbackException
/*    */   extends ConcurrentAccessException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IllegalLoopbackException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public IllegalLoopbackException(String message)
/*    */   {
/* 24 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\IllegalLoopbackException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */