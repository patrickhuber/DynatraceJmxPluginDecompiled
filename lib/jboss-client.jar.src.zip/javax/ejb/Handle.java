package javax.ejb;

import java.io.Serializable;
import java.rmi.RemoteException;

public abstract interface Handle
  extends Serializable
{
  public abstract EJBObject getEJBObject()
    throws RemoteException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\Handle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */