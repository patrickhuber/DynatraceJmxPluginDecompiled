package javax.ejb;

import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface EJBObject
  extends Remote
{
  public abstract EJBHome getEJBHome()
    throws RemoteException;
  
  public abstract Object getPrimaryKey()
    throws RemoteException;
  
  public abstract void remove()
    throws RemoteException, RemoveException;
  
  public abstract Handle getHandle()
    throws RemoteException;
  
  public abstract boolean isIdentical(EJBObject paramEJBObject)
    throws RemoteException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EJBObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */