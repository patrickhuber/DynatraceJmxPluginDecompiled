/*     */ package javax.ejb;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScheduleExpression
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  44 */   private String dayOfMonth = "*";
/*     */   
/*  46 */   private String dayOfWeek = "*";
/*     */   
/*     */   private Date end;
/*     */   
/*  50 */   private String hour = "0";
/*     */   
/*  52 */   private String minute = "0";
/*     */   
/*  54 */   private String month = "*";
/*     */   
/*  56 */   private String second = "0";
/*     */   
/*     */   private Date start;
/*     */   
/*  60 */   private String timezone = "";
/*     */   
/*  62 */   private String year = "*";
/*     */   
/*     */   public ScheduleExpression dayOfMonth(int d)
/*     */   {
/*  66 */     this.dayOfMonth = Integer.toString(d);
/*  67 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression dayOfMonth(String d)
/*     */   {
/*  72 */     this.dayOfMonth = d;
/*  73 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression dayOfWeek(int d)
/*     */   {
/*  78 */     this.dayOfWeek = Integer.toString(d);
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression dayOfWeek(String d)
/*     */   {
/*  84 */     this.dayOfWeek = d;
/*  85 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression end(Date e)
/*     */   {
/*  90 */     this.end = e;
/*  91 */     return this;
/*     */   }
/*     */   
/*     */   public String getDayOfMonth()
/*     */   {
/*  96 */     return this.dayOfMonth;
/*     */   }
/*     */   
/*     */   public String getDayOfWeek()
/*     */   {
/* 101 */     return this.dayOfWeek;
/*     */   }
/*     */   
/*     */   public Date getEnd()
/*     */   {
/* 106 */     return this.end;
/*     */   }
/*     */   
/*     */   public String getHour()
/*     */   {
/* 111 */     return this.hour;
/*     */   }
/*     */   
/*     */   public String getMinute()
/*     */   {
/* 116 */     return this.minute;
/*     */   }
/*     */   
/*     */   public String getMonth()
/*     */   {
/* 121 */     return this.month;
/*     */   }
/*     */   
/*     */   public String getSecond()
/*     */   {
/* 126 */     return this.second;
/*     */   }
/*     */   
/*     */   public Date getStart()
/*     */   {
/* 131 */     return this.start;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTimezone()
/*     */   {
/* 140 */     if ((this.timezone != null) && (this.timezone.isEmpty()))
/*     */     {
/* 142 */       return null;
/*     */     }
/* 144 */     return this.timezone;
/*     */   }
/*     */   
/*     */   public String getYear()
/*     */   {
/* 149 */     return this.year;
/*     */   }
/*     */   
/*     */   public ScheduleExpression hour(int h)
/*     */   {
/* 154 */     this.hour = Integer.toString(h);
/* 155 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression hour(String h)
/*     */   {
/* 160 */     this.hour = h;
/* 161 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression minute(int m)
/*     */   {
/* 166 */     this.minute = Integer.toString(m);
/* 167 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression minute(String m)
/*     */   {
/* 172 */     this.minute = m;
/* 173 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression month(int m)
/*     */   {
/* 178 */     this.month = Integer.toString(m);
/* 179 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression month(String m)
/*     */   {
/* 184 */     this.month = m;
/* 185 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression second(int s)
/*     */   {
/* 190 */     this.second = Integer.toString(s);
/* 191 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression second(String s)
/*     */   {
/* 196 */     this.second = s;
/* 197 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression start(Date s)
/*     */   {
/* 202 */     this.start = s;
/* 203 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression timezone(String s)
/*     */   {
/* 208 */     this.timezone = s;
/* 209 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression year(int y)
/*     */   {
/* 214 */     this.year = Integer.toString(y);
/* 215 */     return this;
/*     */   }
/*     */   
/*     */   public ScheduleExpression year(String y)
/*     */   {
/* 220 */     this.year = y;
/* 221 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 227 */     StringBuilder sb = new StringBuilder("ScheduleExpression[");
/*     */     
/* 229 */     sb.append("second=");
/* 230 */     sb.append(this.second);
/* 231 */     sb.append(" minute=");
/* 232 */     sb.append(this.minute);
/* 233 */     sb.append(" hour=");
/* 234 */     sb.append(this.hour);
/* 235 */     sb.append(" dayOfWeek=");
/* 236 */     sb.append(this.dayOfWeek);
/* 237 */     sb.append(" dayOfMonth=");
/* 238 */     sb.append(this.dayOfMonth);
/* 239 */     sb.append(" month=");
/* 240 */     sb.append(this.month);
/* 241 */     sb.append(" year=");
/* 242 */     sb.append(this.year);
/* 243 */     sb.append(" start=");
/* 244 */     sb.append(this.start);
/* 245 */     sb.append(" end=");
/* 246 */     sb.append(this.end);
/* 247 */     sb.append(" timezone=");
/* 248 */     sb.append(this.timezone);
/*     */     
/* 250 */     sb.append("]");
/*     */     
/* 252 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\ScheduleExpression.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */