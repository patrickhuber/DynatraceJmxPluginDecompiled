package javax.ejb;

import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface EJBHome
  extends Remote
{
  public abstract void remove(Handle paramHandle)
    throws RemoteException, RemoveException;
  
  public abstract void remove(Object paramObject)
    throws RemoteException, RemoveException;
  
  public abstract EJBMetaData getEJBMetaData()
    throws RemoteException;
  
  public abstract HomeHandle getHomeHandle()
    throws RemoteException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EJBHome.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */