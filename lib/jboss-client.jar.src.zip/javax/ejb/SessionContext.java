package javax.ejb;

import javax.xml.rpc.handler.MessageContext;

public abstract interface SessionContext
  extends EJBContext
{
  public abstract EJBLocalObject getEJBLocalObject()
    throws IllegalStateException;
  
  public abstract EJBObject getEJBObject()
    throws IllegalStateException;
  
  public abstract MessageContext getMessageContext()
    throws IllegalStateException;
  
  public abstract <T> T getBusinessObject(Class<T> paramClass)
    throws IllegalStateException;
  
  public abstract Class getInvokedBusinessInterface()
    throws IllegalStateException;
  
  public abstract boolean wasCancelCalled()
    throws IllegalStateException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\SessionContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */