package javax.ejb;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Schedule
{
  String dayOfMonth() default "*";
  
  String dayOfWeek() default "*";
  
  String hour() default "0";
  
  String info() default "";
  
  String minute() default "0";
  
  String month() default "*";
  
  boolean persistent() default true;
  
  String second() default "0";
  
  String timezone() default "";
  
  String year() default "*";
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\Schedule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */