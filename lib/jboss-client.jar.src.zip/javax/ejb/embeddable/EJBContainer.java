/*     */ package javax.ejb.embeddable;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.ejb.EJBException;
/*     */ import javax.ejb.spi.EJBContainerProvider;
/*     */ import javax.naming.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class EJBContainer
/*     */ {
/*     */   public static final String APP_NAME = "javax.ejb.embeddable.appName";
/*     */   public static final String MODULES = "javax.ejb.embeddable.modules";
/*     */   public static final String PROVIDER = "javax.ejb.embeddable.provider";
/*  34 */   private static final Pattern nonCommentPattern = Pattern.compile("^([^#]+)");
/*     */   
/*  36 */   private static List<EJBContainerProvider> factories = new ArrayList();
/*     */   
/*     */   static
/*     */   {
/*  40 */     findAllFactories();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EJBContainer createEJBContainer()
/*     */     throws EJBException
/*     */   {
/*  58 */     return createEJBContainer(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EJBContainer createEJBContainer(Map<?, ?> properties)
/*     */     throws EJBException
/*     */   {
/*  74 */     for (EJBContainerProvider factory : factories)
/*     */     {
/*  76 */       EJBContainer container = factory.createEJBContainer(properties);
/*  77 */       if (container != null)
/*  78 */         return container;
/*     */     }
/*  80 */     throw new EJBException("Unable to instantiate container with factories " + factories);
/*     */   }
/*     */   
/*     */   private static List<String> factoryNamesFromReader(BufferedReader reader) throws IOException
/*     */   {
/*  85 */     List<String> names = new ArrayList();
/*     */     String line;
/*  87 */     while ((line = reader.readLine()) != null)
/*     */     {
/*  89 */       line = line.trim();
/*  90 */       Matcher m = nonCommentPattern.matcher(line);
/*  91 */       if (m.find())
/*     */       {
/*  93 */         names.add(m.group().trim());
/*     */       }
/*     */     }
/*  96 */     return names;
/*     */   }
/*     */   
/*     */   private static void findAllFactories()
/*     */   {
/*     */     try
/*     */     {
/* 103 */       loader = Thread.currentThread().getContextClassLoader();
/* 104 */       Enumeration<URL> resources = loader.getResources("META-INF/services/" + EJBContainerProvider.class.getName());
/* 105 */       Set<String> names = new HashSet();
/* 106 */       while (resources.hasMoreElements())
/*     */       {
/* 108 */         URL url = (URL)resources.nextElement();
/* 109 */         InputStream is = url.openStream();
/*     */         try
/*     */         {
/* 112 */           names.addAll(factoryNamesFromReader(new BufferedReader(new InputStreamReader(is))));
/*     */         }
/*     */         finally
/*     */         {
/* 116 */           is.close();
/*     */         }
/*     */       }
/* 119 */       for (String s : names)
/*     */       {
/* 121 */         Object factoryClass = loader.loadClass(s);
/* 122 */         factories.add(EJBContainerProvider.class.cast(((Class)factoryClass).newInstance()));
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/*     */       ClassLoader loader;
/* 127 */       throw new EJBException(e);
/*     */     }
/*     */     catch (InstantiationException e)
/*     */     {
/* 131 */       throw new EJBException(e);
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 135 */       throw new EJBException(e);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/* 139 */       throw new EJBException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void close();
/*     */   
/*     */   public abstract Context getContext();
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\embeddable\EJBContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */