package javax.ejb;

import java.rmi.RemoteException;

public abstract interface SessionSynchronization
{
  public abstract void afterBegin()
    throws EJBException, RemoteException;
  
  public abstract void beforeCompletion()
    throws EJBException, RemoteException;
  
  public abstract void afterCompletion(boolean paramBoolean)
    throws EJBException, RemoteException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\SessionSynchronization.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */