package javax.ejb;

import java.security.Identity;
import java.security.Principal;
import java.util.Map;
import java.util.Properties;
import javax.transaction.UserTransaction;

public abstract interface EJBContext
{
  public abstract EJBHome getEJBHome();
  
  public abstract EJBLocalHome getEJBLocalHome();
  
  public abstract Properties getEnvironment();
  
  public abstract Identity getCallerIdentity();
  
  public abstract Principal getCallerPrincipal();
  
  public abstract Map<String, Object> getContextData();
  
  public abstract boolean isCallerInRole(Identity paramIdentity);
  
  public abstract boolean isCallerInRole(String paramString);
  
  public abstract UserTransaction getUserTransaction()
    throws IllegalStateException;
  
  public abstract void setRollbackOnly()
    throws IllegalStateException;
  
  public abstract boolean getRollbackOnly()
    throws IllegalStateException;
  
  public abstract TimerService getTimerService()
    throws IllegalStateException;
  
  public abstract Object lookup(String paramString)
    throws IllegalArgumentException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\EJBContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */