/*    */ package javax.ejb;
/*    */ 
/*    */ import java.util.concurrent.ExecutionException;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.TimeoutException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AsyncResult<V>
/*    */   implements Future<V>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private V result;
/*    */   
/*    */   public AsyncResult(V result)
/*    */   {
/* 28 */     this.result = result;
/*    */   }
/*    */   
/*    */   public boolean cancel(boolean mayInterruptIfRunning)
/*    */   {
/* 33 */     return false;
/*    */   }
/*    */   
/*    */   public V get() throws InterruptedException, ExecutionException
/*    */   {
/* 38 */     return (V)this.result;
/*    */   }
/*    */   
/*    */   public V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException
/*    */   {
/* 43 */     return (V)this.result;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 48 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isDone()
/*    */   {
/* 53 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\AsyncResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */