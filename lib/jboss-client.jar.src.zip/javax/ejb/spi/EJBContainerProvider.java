package javax.ejb.spi;

import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.embeddable.EJBContainer;

public abstract interface EJBContainerProvider
{
  public abstract EJBContainer createEJBContainer(Map<?, ?> paramMap)
    throws EJBException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\spi\EJBContainerProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */