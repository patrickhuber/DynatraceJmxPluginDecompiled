package javax.ejb.spi;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.ejb.EJBHome;
import javax.ejb.EJBObject;

public abstract interface HandleDelegate
{
  public abstract void writeEJBObject(EJBObject paramEJBObject, ObjectOutputStream paramObjectOutputStream)
    throws IOException;
  
  public abstract EJBObject readEJBObject(ObjectInputStream paramObjectInputStream)
    throws IOException, ClassNotFoundException;
  
  public abstract void writeEJBHome(EJBHome paramEJBHome, ObjectOutputStream paramObjectOutputStream)
    throws IOException;
  
  public abstract EJBHome readEJBHome(ObjectInputStream paramObjectInputStream)
    throws IOException, ClassNotFoundException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\javax\ejb\spi\HandleDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */