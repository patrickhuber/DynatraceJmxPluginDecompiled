/*    */ package org.hornetq.api.jms;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JMSFactoryType
/*    */ {
/* 26 */   CF,  QUEUE_CF,  TOPIC_CF,  XA_CF,  QUEUE_XA_CF,  TOPIC_XA_CF;
/*    */   
/*    */   private JMSFactoryType() {}
/*    */   
/* 30 */   public int intValue() { int val = 0;
/* 31 */     switch (this)
/*    */     {
/*    */     case CF: 
/* 34 */       val = 0;
/* 35 */       break;
/*    */     case QUEUE_CF: 
/* 37 */       val = 1;
/* 38 */       break;
/*    */     case TOPIC_CF: 
/* 40 */       val = 2;
/* 41 */       break;
/*    */     case XA_CF: 
/* 43 */       val = 3;
/* 44 */       break;
/*    */     case QUEUE_XA_CF: 
/* 46 */       val = 4;
/* 47 */       break;
/*    */     case TOPIC_XA_CF: 
/* 49 */       val = 5;
/*    */     }
/*    */     
/* 52 */     return val;
/*    */   }
/*    */   
/*    */   public static JMSFactoryType valueOf(int val)
/*    */   {
/*    */     JMSFactoryType type;
/* 58 */     switch (val)
/*    */     {
/*    */     case 0: 
/* 61 */       type = CF;
/* 62 */       break;
/*    */     case 1: 
/* 64 */       type = QUEUE_CF;
/* 65 */       break;
/*    */     case 2: 
/* 67 */       type = TOPIC_CF;
/* 68 */       break;
/*    */     case 3: 
/* 70 */       type = XA_CF;
/* 71 */       break;
/*    */     case 4: 
/* 73 */       type = QUEUE_XA_CF;
/* 74 */       break;
/*    */     case 5: 
/* 76 */       type = TOPIC_XA_CF;
/* 77 */       break;
/*    */     default: 
/* 79 */       type = XA_CF;
/*    */     }
/*    */     
/* 82 */     return type;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\JMSFactoryType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */