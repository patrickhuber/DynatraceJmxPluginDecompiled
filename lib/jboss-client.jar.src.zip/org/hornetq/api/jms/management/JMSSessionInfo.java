/*    */ package org.hornetq.api.jms.management;
/*    */ 
/*    */ import org.hornetq.utils.json.JSONArray;
/*    */ import org.hornetq.utils.json.JSONException;
/*    */ import org.hornetq.utils.json.JSONObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JMSSessionInfo
/*    */ {
/*    */   private final String sessionID;
/*    */   private final long creationTime;
/*    */   
/*    */   public JMSSessionInfo(String sessionID, long creationTime)
/*    */   {
/* 35 */     this.sessionID = sessionID;
/* 36 */     this.creationTime = creationTime;
/*    */   }
/*    */   
/*    */   public static JMSSessionInfo[] from(String jsonString) throws JSONException
/*    */   {
/* 41 */     JSONArray array = new JSONArray(jsonString);
/* 42 */     JMSSessionInfo[] infos = new JMSSessionInfo[array.length()];
/* 43 */     for (int i = 0; i < array.length(); i++)
/*    */     {
/* 45 */       JSONObject obj = array.getJSONObject(i);
/*    */       
/* 47 */       JMSSessionInfo info = new JMSSessionInfo(obj.getString("sessionID"), obj.getLong("creationTime"));
/*    */       
/* 49 */       infos[i] = info;
/*    */     }
/* 51 */     return infos;
/*    */   }
/*    */   
/*    */   public String getSessionID()
/*    */   {
/* 56 */     return this.sessionID;
/*    */   }
/*    */   
/*    */   public long getCreationTime()
/*    */   {
/* 61 */     return this.creationTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\JMSSessionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */