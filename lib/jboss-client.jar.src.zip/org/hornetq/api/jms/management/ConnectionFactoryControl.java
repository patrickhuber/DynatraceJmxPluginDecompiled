package org.hornetq.api.jms.management;

import org.hornetq.api.core.DiscoveryGroupConfiguration;
import org.hornetq.api.core.TransportConfiguration;
import org.hornetq.api.core.management.Operation;
import org.hornetq.api.core.management.Parameter;

public abstract interface ConnectionFactoryControl
{
  public abstract String getName();
  
  public abstract String[] getJNDIBindings();
  
  public abstract boolean isHA();
  
  public abstract int getFactoryType();
  
  public abstract String getClientID();
  
  public abstract void setClientID(String paramString);
  
  public abstract boolean isCompressLargeMessages();
  
  public abstract void setCompressLargeMessages(boolean paramBoolean);
  
  public abstract long getClientFailureCheckPeriod();
  
  public abstract void setClientFailureCheckPeriod(long paramLong);
  
  public abstract long getCallTimeout();
  
  public abstract void setCallTimeout(long paramLong);
  
  public abstract long getCallFailoverTimeout();
  
  public abstract void setCallFailoverTimeout(long paramLong);
  
  public abstract int getDupsOKBatchSize();
  
  public abstract void setDupsOKBatchSize(int paramInt);
  
  public abstract int getConsumerMaxRate();
  
  public abstract void setConsumerMaxRate(int paramInt);
  
  public abstract int getConsumerWindowSize();
  
  public abstract void setConsumerWindowSize(int paramInt);
  
  public abstract int getProducerMaxRate();
  
  public abstract void setProducerMaxRate(int paramInt);
  
  public abstract int getConfirmationWindowSize();
  
  public abstract void setConfirmationWindowSize(int paramInt);
  
  public abstract boolean isBlockOnAcknowledge();
  
  public abstract void setBlockOnAcknowledge(boolean paramBoolean);
  
  public abstract boolean isBlockOnDurableSend();
  
  public abstract void setBlockOnDurableSend(boolean paramBoolean);
  
  public abstract boolean isBlockOnNonDurableSend();
  
  public abstract void setBlockOnNonDurableSend(boolean paramBoolean);
  
  public abstract boolean isPreAcknowledge();
  
  public abstract void setPreAcknowledge(boolean paramBoolean);
  
  public abstract long getConnectionTTL();
  
  public abstract void setConnectionTTL(long paramLong);
  
  public abstract int getTransactionBatchSize();
  
  public abstract void setTransactionBatchSize(int paramInt);
  
  public abstract int getMinLargeMessageSize();
  
  public abstract void setMinLargeMessageSize(int paramInt);
  
  public abstract boolean isAutoGroup();
  
  public abstract void setAutoGroup(boolean paramBoolean);
  
  public abstract long getRetryInterval();
  
  public abstract void setRetryInterval(long paramLong);
  
  public abstract double getRetryIntervalMultiplier();
  
  public abstract void setRetryIntervalMultiplier(double paramDouble);
  
  public abstract int getReconnectAttempts();
  
  public abstract void setReconnectAttempts(int paramInt);
  
  public abstract boolean isFailoverOnInitialConnection();
  
  public abstract void setFailoverOnInitialConnection(boolean paramBoolean);
  
  public abstract int getProducerWindowSize();
  
  public abstract void setProducerWindowSize(int paramInt);
  
  public abstract boolean isCacheLargeMessagesClient();
  
  public abstract void setCacheLargeMessagesClient(boolean paramBoolean);
  
  public abstract long getMaxRetryInterval();
  
  public abstract void setMaxRetryInterval(long paramLong);
  
  public abstract int getScheduledThreadPoolMaxSize();
  
  public abstract void setScheduledThreadPoolMaxSize(int paramInt);
  
  public abstract int getThreadPoolMaxSize();
  
  public abstract void setThreadPoolMaxSize(int paramInt);
  
  public abstract String getGroupID();
  
  public abstract void setGroupID(String paramString);
  
  public abstract int getInitialMessagePacketSize();
  
  public abstract boolean isUseGlobalPools();
  
  public abstract void setUseGlobalPools(boolean paramBoolean);
  
  public abstract String getConnectionLoadBalancingPolicyClassName();
  
  public abstract void setConnectionLoadBalancingPolicyClassName(String paramString);
  
  public abstract TransportConfiguration[] getStaticConnectors();
  
  public abstract DiscoveryGroupConfiguration getDiscoveryGroupConfiguration();
  
  @Operation(desc="Adds the factory to another JNDI binding")
  public abstract void addJNDI(@Parameter(name="jndiBinding", desc="the name of the binding for JNDI") String paramString)
    throws Exception;
  
  @Operation(desc="Remove an existing JNDI binding")
  public abstract void removeJNDI(@Parameter(name="jndiBinding", desc="the name of the binding for JNDI") String paramString)
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\ConnectionFactoryControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */