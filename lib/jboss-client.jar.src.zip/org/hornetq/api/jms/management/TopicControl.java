package org.hornetq.api.jms.management;

import java.util.Map;
import org.hornetq.api.core.management.Operation;
import org.hornetq.api.core.management.Parameter;

public abstract interface TopicControl
  extends DestinationControl
{
  public abstract int getSubscriptionCount();
  
  public abstract int getDurableSubscriptionCount();
  
  public abstract int getNonDurableSubscriptionCount();
  
  public abstract int getDurableMessageCount();
  
  public abstract int getNonDurableMessageCount();
  
  @Operation(desc="Returns the list of JNDI bindings associated")
  public abstract String[] getJNDIBindings();
  
  @Operation(desc="Adds the queue to another JNDI binding")
  public abstract void addJNDI(@Parameter(name="jndiBinding", desc="the name of the binding for JNDI") String paramString)
    throws Exception;
  
  @Operation(desc="List all subscriptions")
  public abstract Object[] listAllSubscriptions()
    throws Exception;
  
  @Operation(desc="List all subscriptions")
  public abstract String listAllSubscriptionsAsJSON()
    throws Exception;
  
  @Operation(desc="List only the durable subscriptions")
  public abstract Object[] listDurableSubscriptions()
    throws Exception;
  
  @Operation(desc="List only the durable subscriptions")
  public abstract String listDurableSubscriptionsAsJSON()
    throws Exception;
  
  @Operation(desc="List only the non durable subscriptions")
  public abstract Object[] listNonDurableSubscriptions()
    throws Exception;
  
  @Operation(desc="List only the non durable subscriptions")
  public abstract String listNonDurableSubscriptionsAsJSON()
    throws Exception;
  
  @Operation(desc="List all the message for the given subscription")
  public abstract Map<String, Object>[] listMessagesForSubscription(@Parameter(name="queueName", desc="the name of the queue representing a subscription") String paramString)
    throws Exception;
  
  @Operation(desc="List all the message for the given subscription")
  public abstract String listMessagesForSubscriptionAsJSON(@Parameter(name="queueName", desc="the name of the queue representing a subscription") String paramString)
    throws Exception;
  
  @Operation(desc="Count the number of messages matching the filter for the given subscription")
  public abstract int countMessagesForSubscription(@Parameter(name="clientID", desc="the client ID") String paramString1, @Parameter(name="subscriptionName", desc="the name of the durable subscription") String paramString2, @Parameter(name="filter", desc="a JMS filter (can be empty)") String paramString3)
    throws Exception;
  
  @Operation(desc="Drop a durable subscription", impact=1)
  public abstract void dropDurableSubscription(@Parameter(name="clientID", desc="the client ID") String paramString1, @Parameter(name="subscriptionName", desc="the name of the durable subscription") String paramString2)
    throws Exception;
  
  @Operation(desc="Drop all subscriptions from this topic", impact=1)
  public abstract void dropAllSubscriptions()
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\TopicControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */