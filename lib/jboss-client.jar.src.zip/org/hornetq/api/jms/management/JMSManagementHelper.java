/*     */ package org.hornetq.api.jms.management;
/*     */ 
/*     */ import javax.jms.JMSException;
/*     */ import org.hornetq.api.core.management.ManagementHelper;
/*     */ import org.hornetq.jms.client.HornetQMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSManagementHelper
/*     */ {
/*     */   private static org.hornetq.api.core.Message getCoreMessage(javax.jms.Message jmsMessage)
/*     */   {
/*  32 */     if (!(jmsMessage instanceof HornetQMessage))
/*     */     {
/*  34 */       throw new IllegalArgumentException("Cannot send a non HornetQ message as a management message " + jmsMessage.getClass().getName());
/*     */     }
/*     */     
/*     */ 
/*  38 */     return ((HornetQMessage)jmsMessage).getCoreMessage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putAttribute(javax.jms.Message message, String resourceName, String attribute)
/*     */     throws JMSException
/*     */   {
/*  52 */     ManagementHelper.putAttribute(getCoreMessage(message), resourceName, attribute);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putOperationInvocation(javax.jms.Message message, String resourceName, String operationName)
/*     */     throws JMSException
/*     */   {
/*     */     try
/*     */     {
/*  70 */       ManagementHelper.putOperationInvocation(getCoreMessage(message), resourceName, operationName);
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*  76 */       throw convertFromException(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private static JMSException convertFromException(Exception e)
/*     */   {
/*  82 */     JMSException jmse = new JMSException(e.getMessage());
/*     */     
/*  84 */     jmse.initCause(e);
/*     */     
/*  86 */     return jmse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putOperationInvocation(javax.jms.Message message, String resourceName, String operationName, Object... parameters)
/*     */     throws JMSException
/*     */   {
/*     */     try
/*     */     {
/* 106 */       ManagementHelper.putOperationInvocation(getCoreMessage(message), resourceName, operationName, parameters);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/* 113 */       throw convertFromException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isOperationResult(javax.jms.Message message)
/*     */     throws JMSException
/*     */   {
/* 122 */     return ManagementHelper.isOperationResult(getCoreMessage(message));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean isAttributesResult(javax.jms.Message message)
/*     */     throws JMSException
/*     */   {
/* 130 */     return ManagementHelper.isAttributesResult(getCoreMessage(message));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean hasOperationSucceeded(javax.jms.Message message)
/*     */     throws JMSException
/*     */   {
/* 138 */     return ManagementHelper.hasOperationSucceeded(getCoreMessage(message));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object[] getResults(javax.jms.Message message)
/*     */     throws Exception
/*     */   {
/* 149 */     return ManagementHelper.getResults(getCoreMessage(message));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getResult(javax.jms.Message message)
/*     */     throws Exception
/*     */   {
/* 160 */     return ManagementHelper.getResult(getCoreMessage(message));
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\JMSManagementHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */