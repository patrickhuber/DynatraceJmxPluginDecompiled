package org.hornetq.api.jms.management;

import org.hornetq.api.core.management.Operation;
import org.hornetq.api.core.management.Parameter;

public abstract interface JMSServerControl
{
  public abstract boolean isStarted();
  
  public abstract String getVersion();
  
  public abstract String[] getTopicNames();
  
  public abstract String[] getQueueNames();
  
  public abstract String[] getConnectionFactoryNames();
  
  @Operation(desc="Create a JMS Queue", impact=1)
  public abstract boolean createQueue(@Parameter(name="name", desc="Name of the queue to create") String paramString)
    throws Exception;
  
  @Operation(desc="Create a JMS Queue", impact=1)
  public abstract boolean createQueue(@Parameter(name="name", desc="Name of the queue to create") String paramString1, @Parameter(name="jndiBindings", desc="comma-separated list of JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String paramString2)
    throws Exception;
  
  @Operation(desc="Create a JMS Queue", impact=1)
  public abstract boolean createQueue(@Parameter(name="name", desc="Name of the queue to create") String paramString1, @Parameter(name="jndiBindings", desc="comma-separated list of JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String paramString2, @Parameter(name="selector", desc="the jms selector") String paramString3)
    throws Exception;
  
  @Operation(desc="Create a JMS Queue", impact=1)
  public abstract boolean createQueue(@Parameter(name="name", desc="Name of the queue to create") String paramString1, @Parameter(name="jndiBindings", desc="comma-separated list of JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String paramString2, @Parameter(name="selector", desc="the jms selector") String paramString3, @Parameter(name="durable", desc="durability of the queue") boolean paramBoolean)
    throws Exception;
  
  @Operation(desc="Destroy a JMS Queue", impact=1)
  public abstract boolean destroyQueue(@Parameter(name="name", desc="Name of the queue to destroy") String paramString)
    throws Exception;
  
  @Operation(desc="Create a JMS Topic", impact=1)
  public abstract boolean createTopic(@Parameter(name="name", desc="Name of the topic to create") String paramString)
    throws Exception;
  
  @Operation(desc="Create a JMS Topic", impact=1)
  public abstract boolean createTopic(@Parameter(name="name", desc="Name of the topic to create") String paramString1, @Parameter(name="jndiBindings", desc="comma-separated list of JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String paramString2)
    throws Exception;
  
  @Operation(desc="Destroy a JMS Topic", impact=1)
  public abstract boolean destroyTopic(@Parameter(name="name", desc="Name of the topic to destroy") String paramString)
    throws Exception;
  
  public abstract void createConnectionFactory(String paramString, boolean paramBoolean1, boolean paramBoolean2, @Parameter(name="cfType", desc="RegularCF=0, QueueCF=1, TopicCF=2, XACF=3, QueueXACF=4, TopicXACF=5") int paramInt, String[] paramArrayOfString, Object[] paramArrayOfObject)
    throws Exception;
  
  @Operation(desc="Create a JMS ConnectionFactory", impact=1)
  public abstract void createConnectionFactory(@Parameter(name="name") String paramString1, @Parameter(name="ha") boolean paramBoolean1, @Parameter(name="useDiscovery", desc="should we use discovery or a connector configuration") boolean paramBoolean2, @Parameter(name="cfType", desc="RegularCF=0, QueueCF=1, TopicCF=2, XACF=3, QueueXACF=4, TopicXACF=5") int paramInt, @Parameter(name="connectorNames", desc="comma-separated list of connectorNames or the discovery group name") String paramString2, @Parameter(name="jndiBindings", desc="comma-separated list of JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String paramString3)
    throws Exception;
  
  @Operation(desc="Create a JMS ConnectionFactory", impact=1)
  public abstract void createConnectionFactory(@Parameter(name="name") String paramString1, @Parameter(name="ha") boolean paramBoolean1, @Parameter(name="useDiscovery", desc="should we use discovery or a connector configuration") boolean paramBoolean2, @Parameter(name="cfType", desc="RegularCF=0, QueueCF=1, TopicCF=2, XACF=3, QueueXACF=4, TopicXACF=5") int paramInt1, @Parameter(name="connectorNames", desc="An array of connector or the binding address") String[] paramArrayOfString1, @Parameter(name="jndiBindings", desc="array JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String[] paramArrayOfString2, @Parameter(name="clientID", desc="The clientID configured for the connectionFactory") String paramString2, @Parameter(name="clientFailureCheckPeriod", desc="clientFailureCheckPeriod") long paramLong1, @Parameter(name="connectionTTL", desc="connectionTTL") long paramLong2, @Parameter(name="callTimeout", desc="callTimeout") long paramLong3, @Parameter(name="callFailoverTimeout", desc="callFailoverTimeout") long paramLong4, @Parameter(name="minLargeMessageSize", desc="minLargeMessageSize") int paramInt2, @Parameter(name="compressLargeMessages", desc="compressLargeMessages") boolean paramBoolean3, @Parameter(name="consumerWindowSize", desc="consumerWindowSize") int paramInt3, @Parameter(name="consumerMaxRate", desc="consumerMaxRate") int paramInt4, @Parameter(name="confirmationWindowSize", desc="confirmationWindowSize") int paramInt5, @Parameter(name="producerWindowSize", desc="producerWindowSize") int paramInt6, @Parameter(name="producerMaxRate", desc="producerMaxRate") int paramInt7, @Parameter(name="blockOnAcknowledge", desc="blockOnAcknowledge") boolean paramBoolean4, @Parameter(name="blockOnDurableSend", desc="blockOnDurableSend") boolean paramBoolean5, @Parameter(name="blockOnNonDurableSend", desc="blockOnNonDurableSend") boolean paramBoolean6, @Parameter(name="autoGroup", desc="autoGroup") boolean paramBoolean7, @Parameter(name="preAcknowledge", desc="preAcknowledge") boolean paramBoolean8, @Parameter(name="loadBalancingPolicyClassName", desc="loadBalancingPolicyClassName (null or blank mean use the default value)") String paramString3, @Parameter(name="transactionBatchSize", desc="transactionBatchSize") int paramInt8, @Parameter(name="dupsOKBatchSize", desc="dupsOKBatchSize") int paramInt9, @Parameter(name="useGlobalPools", desc="useGlobalPools") boolean paramBoolean9, @Parameter(name="scheduledThreadPoolMaxSize", desc="scheduledThreadPoolMaxSize") int paramInt10, @Parameter(name="threadPoolMaxSize", desc="threadPoolMaxSize") int paramInt11, @Parameter(name="retryInterval", desc="retryInterval") long paramLong5, @Parameter(name="retryIntervalMultiplier", desc="retryIntervalMultiplier") double paramDouble, @Parameter(name="maxRetryInterval", desc="maxRetryInterval") long paramLong6, @Parameter(name="reconnectAttempts", desc="reconnectAttempts") int paramInt12, @Parameter(name="failoverOnInitialConnection", desc="failoverOnInitialConnection") boolean paramBoolean10, @Parameter(name="groupId", desc="groupId") String paramString4)
    throws Exception;
  
  @Operation(desc="Create a JMS ConnectionFactory", impact=1)
  public abstract void createConnectionFactory(@Parameter(name="name") String paramString1, @Parameter(name="ha") boolean paramBoolean1, @Parameter(name="useDiscovery", desc="should we use discovery or a connector configuration") boolean paramBoolean2, @Parameter(name="cfType", desc="RegularCF=0, QueueCF=1, TopicCF=2, XACF=3, QueueXACF=4, TopicXACF=5") int paramInt1, @Parameter(name="connectorNames", desc="comma-separated list of connectorNames or the discovery group name") String paramString2, @Parameter(name="jndiBindings", desc="comma-separated list of JNDI bindings (use '&comma;' if u need to use commas in your jndi name)") String paramString3, @Parameter(name="clientID", desc="The clientID configured for the connectionFactory") String paramString4, @Parameter(name="clientFailureCheckPeriod", desc="clientFailureCheckPeriod") long paramLong1, @Parameter(name="connectionTTL", desc="connectionTTL") long paramLong2, @Parameter(name="callTimeout", desc="callTimeout") long paramLong3, @Parameter(name="callFailoverTimeout", desc="callFailoverTimeout") long paramLong4, @Parameter(name="minLargeMessageSize", desc="minLargeMessageSize") int paramInt2, @Parameter(name="compressLargeMessages", desc="compressLargeMessages") boolean paramBoolean3, @Parameter(name="consumerWindowSize", desc="consumerWindowSize") int paramInt3, @Parameter(name="consumerMaxRate", desc="consumerMaxRate") int paramInt4, @Parameter(name="confirmationWindowSize", desc="confirmationWindowSize") int paramInt5, @Parameter(name="producerWindowSize", desc="producerWindowSize") int paramInt6, @Parameter(name="producerMaxRate", desc="producerMaxRate") int paramInt7, @Parameter(name="blockOnAcknowledge", desc="blockOnAcknowledge") boolean paramBoolean4, @Parameter(name="blockOnDurableSend", desc="blockOnDurableSend") boolean paramBoolean5, @Parameter(name="blockOnNonDurableSend", desc="blockOnNonDurableSend") boolean paramBoolean6, @Parameter(name="autoGroup", desc="autoGroup") boolean paramBoolean7, @Parameter(name="preAcknowledge", desc="preAcknowledge") boolean paramBoolean8, @Parameter(name="loadBalancingPolicyClassName", desc="loadBalancingPolicyClassName (null or blank mean use the default value)") String paramString5, @Parameter(name="transactionBatchSize", desc="transactionBatchSize") int paramInt8, @Parameter(name="dupsOKBatchSize", desc="dupsOKBatchSize") int paramInt9, @Parameter(name="useGlobalPools", desc="useGlobalPools") boolean paramBoolean9, @Parameter(name="scheduledThreadPoolMaxSize", desc="scheduledThreadPoolMaxSize") int paramInt10, @Parameter(name="threadPoolMaxSize", desc="threadPoolMaxSize") int paramInt11, @Parameter(name="retryInterval", desc="retryInterval") long paramLong5, @Parameter(name="retryIntervalMultiplier", desc="retryIntervalMultiplier") double paramDouble, @Parameter(name="maxRetryInterval", desc="maxRetryInterval") long paramLong6, @Parameter(name="reconnectAttempts", desc="reconnectAttempts") int paramInt12, @Parameter(name="failoverOnInitialConnection", desc="failoverOnInitialConnection") boolean paramBoolean10, @Parameter(name="groupId", desc="groupId") String paramString6)
    throws Exception;
  
  @Operation(desc="Destroy a JMS ConnectionFactory", impact=1)
  public abstract void destroyConnectionFactory(@Parameter(name="name", desc="Name of the ConnectionFactory to destroy") String paramString)
    throws Exception;
  
  @Operation(desc="List the client addresses", impact=0)
  public abstract String[] listRemoteAddresses()
    throws Exception;
  
  @Operation(desc="List the client addresses which match the given IP Address", impact=0)
  public abstract String[] listRemoteAddresses(@Parameter(desc="an IP address", name="ipAddress") String paramString)
    throws Exception;
  
  @Operation(desc="Closes all the connections for the given IP Address", impact=0)
  public abstract boolean closeConnectionsForAddress(@Parameter(desc="an IP address", name="ipAddress") String paramString)
    throws Exception;
  
  @Operation(desc="Closes all the consumer connections for the given HornetQ address", impact=0)
  public abstract boolean closeConsumerConnectionsForAddress(@Parameter(desc="a HornetQ address", name="address") String paramString)
    throws Exception;
  
  @Operation(desc="Closes all the connections for session using a particular user name", impact=0)
  public abstract boolean closeConnectionsForUser(@Parameter(desc="a user name", name="userName") String paramString)
    throws Exception;
  
  @Operation(desc="List all the connection IDs", impact=0)
  public abstract String[] listConnectionIDs()
    throws Exception;
  
  @Operation(desc="List all JMS connections")
  public abstract String listConnectionsAsJSON()
    throws Exception;
  
  @Operation(desc="List the sessions for the given connectionID", impact=0)
  public abstract String[] listSessions(@Parameter(desc="a connection ID", name="connectionID") String paramString)
    throws Exception;
  
  @Operation(desc="List all JMS consumers associated to a JMS Connection")
  public abstract String listConsumersAsJSON(@Parameter(desc="a connection ID", name="connectionID") String paramString)
    throws Exception;
  
  @Operation(desc="List all JMS consumers associated to a JMS Connection")
  public abstract String listAllConsumersAsJSON()
    throws Exception;
  
  @Operation(desc="Lists all addresses to which the designated session has sent messages", impact=0)
  public abstract String[] listTargetDestinations(@Parameter(desc="a session ID", name="sessionID") String paramString)
    throws Exception;
  
  @Operation(desc="Returns the last sent message's ID from the given session to an address", impact=0)
  public abstract String getLastSentMessageID(@Parameter(desc="session name", name="sessionID") String paramString1, @Parameter(desc="address", name="address") String paramString2)
    throws Exception;
  
  @Operation(desc="Gets the sessions creation time", impact=0)
  public abstract String getSessionCreationTime(@Parameter(desc="session name", name="sessionID") String paramString)
    throws Exception;
  
  @Operation(desc="List the sessions for the given connectionID", impact=0)
  public abstract String listSessionsAsJSON(@Parameter(desc="a connection ID", name="connectionID") String paramString)
    throws Exception;
  
  @Operation(desc="List all the prepared transaction, sorted by date, oldest first, with details, in JSON format", impact=0)
  public abstract String listPreparedTransactionDetailsAsJSON()
    throws Exception;
  
  @Operation(desc="List all the prepared transaction, sorted by date, oldest first, with details, in HTML format", impact=0)
  public abstract String listPreparedTransactionDetailsAsHTML()
    throws Exception;
  
  @Operation(desc="Will close any connection with the given connectionID", impact=0)
  public abstract String closeConnectionWithClientID(@Parameter(desc="the clientID used to connect", name="clientID") String paramString)
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\JMSServerControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */