/*     */ package org.hornetq.api.jms.management;
/*     */ 
/*     */ import org.hornetq.utils.json.JSONArray;
/*     */ import org.hornetq.utils.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSConsumerInfo
/*     */ {
/*     */   private final String consumerID;
/*     */   private final String connectionID;
/*     */   private final String destinationName;
/*     */   private final String destinationType;
/*     */   private final boolean browseOnly;
/*     */   private final long creationTime;
/*     */   private final boolean durable;
/*     */   private final String filter;
/*     */   
/*     */   public static JMSConsumerInfo[] from(String jsonString)
/*     */     throws Exception
/*     */   {
/*  51 */     JSONArray array = new JSONArray(jsonString);
/*  52 */     JMSConsumerInfo[] infos = new JMSConsumerInfo[array.length()];
/*  53 */     for (int i = 0; i < array.length(); i++)
/*     */     {
/*  55 */       JSONObject sub = array.getJSONObject(i);
/*  56 */       JMSConsumerInfo info = new JMSConsumerInfo(sub.getString("consumerID"), sub.getString("connectionID"), sub.getString("destinationName"), sub.getString("destinationType"), sub.getBoolean("browseOnly"), sub.getLong("creationTime"), sub.getBoolean("durable"), sub.optString("filter", null));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */       infos[i] = info;
/*     */     }
/*     */     
/*  67 */     return infos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JMSConsumerInfo(String consumerID, String connectionID, String destinationName, String destinationType, boolean browseOnly, long creationTime, boolean durable, String filter)
/*     */   {
/*  81 */     this.consumerID = consumerID;
/*  82 */     this.connectionID = connectionID;
/*  83 */     this.destinationName = destinationName;
/*  84 */     this.destinationType = destinationType;
/*  85 */     this.browseOnly = browseOnly;
/*  86 */     this.creationTime = creationTime;
/*  87 */     this.durable = durable;
/*  88 */     this.filter = filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConsumerID()
/*     */   {
/*  95 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public String getConnectionID()
/*     */   {
/* 100 */     return this.connectionID;
/*     */   }
/*     */   
/*     */   public String getDestinationName()
/*     */   {
/* 105 */     return this.destinationName;
/*     */   }
/*     */   
/*     */   public String getDestinationType()
/*     */   {
/* 110 */     return this.destinationType;
/*     */   }
/*     */   
/*     */   public boolean isBrowseOnly()
/*     */   {
/* 115 */     return this.browseOnly;
/*     */   }
/*     */   
/*     */   public long getCreationTime()
/*     */   {
/* 120 */     return this.creationTime;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDurable()
/*     */   {
/* 128 */     return this.durable;
/*     */   }
/*     */   
/*     */   public String getFilter()
/*     */   {
/* 133 */     return this.filter;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\JMSConsumerInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */