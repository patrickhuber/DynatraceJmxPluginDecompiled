/*     */ package org.hornetq.api.jms.management;
/*     */ 
/*     */ import org.hornetq.utils.json.JSONArray;
/*     */ import org.hornetq.utils.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriptionInfo
/*     */ {
/*     */   private final String queueName;
/*     */   private final String clientID;
/*     */   private final String name;
/*     */   private final boolean durable;
/*     */   private final String selector;
/*     */   private final int messageCount;
/*     */   private final int deliveringCount;
/*     */   
/*     */   public static SubscriptionInfo[] from(String jsonString)
/*     */     throws Exception
/*     */   {
/*  49 */     JSONArray array = new JSONArray(jsonString);
/*  50 */     SubscriptionInfo[] infos = new SubscriptionInfo[array.length()];
/*  51 */     for (int i = 0; i < array.length(); i++)
/*     */     {
/*  53 */       JSONObject sub = array.getJSONObject(i);
/*  54 */       SubscriptionInfo info = new SubscriptionInfo(sub.getString("queueName"), sub.optString("clientID", null), sub.optString("name", null), sub.getBoolean("durable"), sub.optString("selector", null), sub.getInt("messageCount"), sub.getInt("deliveringCount"));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  61 */       infos[i] = info;
/*     */     }
/*     */     
/*  64 */     return infos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SubscriptionInfo(String queueName, String clientID, String name, boolean durable, String selector, int messageCount, int deliveringCount)
/*     */   {
/*  77 */     this.queueName = queueName;
/*  78 */     this.clientID = clientID;
/*  79 */     this.name = name;
/*  80 */     this.durable = durable;
/*  81 */     this.selector = selector;
/*  82 */     this.messageCount = messageCount;
/*  83 */     this.deliveringCount = deliveringCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getQueueName()
/*     */   {
/*  93 */     return this.queueName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getClientID()
/*     */   {
/* 101 */     return this.clientID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 109 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDurable()
/*     */   {
/* 117 */     return this.durable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSelector()
/*     */   {
/* 125 */     return this.selector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMessageCount()
/*     */   {
/* 133 */     return this.messageCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDeliveringCount()
/*     */   {
/* 141 */     return this.deliveringCount;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\SubscriptionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */