package org.hornetq.api.jms.management;

import org.hornetq.api.core.management.Operation;
import org.hornetq.api.core.management.Parameter;

public abstract interface DestinationControl
{
  public abstract String getName();
  
  public abstract String getAddress();
  
  public abstract boolean isTemporary();
  
  public abstract long getMessageCount()
    throws Exception;
  
  public abstract int getDeliveringCount();
  
  public abstract long getMessagesAdded();
  
  @Operation(desc="Remove messages matching the given filter from the destination", impact=1)
  public abstract int removeMessages(@Parameter(name="filter", desc="A JMS message filter (can be empty)") String paramString)
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\management\DestinationControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */