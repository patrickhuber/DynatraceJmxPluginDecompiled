package org.hornetq.api.jms;

public class HornetQJMSConstants
{
  public static final String JMS_HORNETQ_INPUT_STREAM = "JMS_HQ_InputStream";
  public static final String JMS_HORNETQ_OUTPUT_STREAM = "JMS_HQ_OutputStream";
  public static final String JMS_HORNETQ_SAVE_STREAM = "JMS_HQ_SaveStream";
  public static final String JBOSS_MESSAGING_BRIDGE_MESSAGE_ID_LIST = "HQ_BRIDGE_MSG_ID_LIST";
  public static final int PRE_ACKNOWLEDGE = 100;
  public static final int INDIVIDUAL_ACKNOWLEDGE = 101;
  public static final String JMS_HORNETQ_ENABLE_BYTE_ARRAY_JMS_CORRELATION_ID_PROPERTY_NAME = "hq.jms.support-bytes-id";
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\HornetQJMSConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */