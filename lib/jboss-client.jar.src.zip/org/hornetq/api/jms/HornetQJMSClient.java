/*     */ package org.hornetq.api.jms;
/*     */ 
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.Topic;
/*     */ import org.hornetq.api.core.DiscoveryGroupConfiguration;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.jms.client.HornetQConnectionFactory;
/*     */ import org.hornetq.jms.client.HornetQDestination;
/*     */ import org.hornetq.jms.client.HornetQJMSConnectionFactory;
/*     */ import org.hornetq.jms.client.HornetQQueueConnectionFactory;
/*     */ import org.hornetq.jms.client.HornetQTopicConnectionFactory;
/*     */ import org.hornetq.jms.client.HornetQXAConnectionFactory;
/*     */ import org.hornetq.jms.client.HornetQXAQueueConnectionFactory;
/*     */ import org.hornetq.jms.client.HornetQXATopicConnectionFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HornetQJMSClient
/*     */ {
/*     */   public static HornetQConnectionFactory createConnectionFactoryWithHA(DiscoveryGroupConfiguration groupConfiguration, JMSFactoryType jmsFactoryType)
/*     */   {
/*  54 */     HornetQConnectionFactory factory = null;
/*  55 */     if (jmsFactoryType.equals(JMSFactoryType.CF))
/*     */     {
/*  57 */       factory = new HornetQJMSConnectionFactory(true, groupConfiguration);
/*     */     }
/*  59 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_CF))
/*     */     {
/*  61 */       factory = new HornetQQueueConnectionFactory(true, groupConfiguration);
/*     */     }
/*  63 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_CF))
/*     */     {
/*  65 */       factory = new HornetQTopicConnectionFactory(true, groupConfiguration);
/*     */     }
/*  67 */     else if (jmsFactoryType.equals(JMSFactoryType.XA_CF))
/*     */     {
/*  69 */       factory = new HornetQXAConnectionFactory(true, groupConfiguration);
/*     */     }
/*  71 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_XA_CF))
/*     */     {
/*  73 */       factory = new HornetQXAQueueConnectionFactory(true, groupConfiguration);
/*     */     }
/*  75 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_XA_CF))
/*     */     {
/*  77 */       factory = new HornetQXATopicConnectionFactory(true, groupConfiguration);
/*     */     }
/*     */     
/*  80 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HornetQConnectionFactory createConnectionFactoryWithoutHA(DiscoveryGroupConfiguration groupConfiguration, JMSFactoryType jmsFactoryType)
/*     */   {
/*  94 */     HornetQConnectionFactory factory = null;
/*  95 */     if (jmsFactoryType.equals(JMSFactoryType.CF))
/*     */     {
/*  97 */       factory = new HornetQJMSConnectionFactory(false, groupConfiguration);
/*     */     }
/*  99 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_CF))
/*     */     {
/* 101 */       factory = new HornetQQueueConnectionFactory(false, groupConfiguration);
/*     */     }
/* 103 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_CF))
/*     */     {
/* 105 */       factory = new HornetQTopicConnectionFactory(false, groupConfiguration);
/*     */     }
/* 107 */     else if (jmsFactoryType.equals(JMSFactoryType.XA_CF))
/*     */     {
/* 109 */       factory = new HornetQXAConnectionFactory(false, groupConfiguration);
/*     */     }
/* 111 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_XA_CF))
/*     */     {
/* 113 */       factory = new HornetQXAQueueConnectionFactory(false, groupConfiguration);
/*     */     }
/* 115 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_XA_CF))
/*     */     {
/* 117 */       factory = new HornetQXATopicConnectionFactory(false, groupConfiguration);
/*     */     }
/*     */     
/* 120 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HornetQConnectionFactory createConnectionFactoryWithHA(JMSFactoryType jmsFactoryType, TransportConfiguration... initialServers)
/*     */   {
/* 139 */     HornetQConnectionFactory factory = null;
/* 140 */     if (jmsFactoryType.equals(JMSFactoryType.CF))
/*     */     {
/* 142 */       factory = new HornetQJMSConnectionFactory(true, initialServers);
/*     */     }
/* 144 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_CF))
/*     */     {
/* 146 */       factory = new HornetQQueueConnectionFactory(true, initialServers);
/*     */     }
/* 148 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_CF))
/*     */     {
/* 150 */       factory = new HornetQTopicConnectionFactory(true, initialServers);
/*     */     }
/* 152 */     else if (jmsFactoryType.equals(JMSFactoryType.XA_CF))
/*     */     {
/* 154 */       factory = new HornetQXAConnectionFactory(true, initialServers);
/*     */     }
/* 156 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_XA_CF))
/*     */     {
/* 158 */       factory = new HornetQXAQueueConnectionFactory(true, initialServers);
/*     */     }
/* 160 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_XA_CF))
/*     */     {
/* 162 */       factory = new HornetQXATopicConnectionFactory(true, initialServers);
/*     */     }
/*     */     
/* 165 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HornetQConnectionFactory createConnectionFactoryWithoutHA(JMSFactoryType jmsFactoryType, TransportConfiguration... transportConfigurations)
/*     */   {
/* 179 */     HornetQConnectionFactory factory = null;
/* 180 */     if (jmsFactoryType.equals(JMSFactoryType.CF))
/*     */     {
/* 182 */       factory = new HornetQJMSConnectionFactory(false, transportConfigurations);
/*     */     }
/* 184 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_CF))
/*     */     {
/* 186 */       factory = new HornetQQueueConnectionFactory(false, transportConfigurations);
/*     */     }
/* 188 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_CF))
/*     */     {
/* 190 */       factory = new HornetQTopicConnectionFactory(false, transportConfigurations);
/*     */     }
/* 192 */     else if (jmsFactoryType.equals(JMSFactoryType.XA_CF))
/*     */     {
/* 194 */       factory = new HornetQXAConnectionFactory(false, transportConfigurations);
/*     */     }
/* 196 */     else if (jmsFactoryType.equals(JMSFactoryType.QUEUE_XA_CF))
/*     */     {
/* 198 */       factory = new HornetQXAQueueConnectionFactory(false, transportConfigurations);
/*     */     }
/* 200 */     else if (jmsFactoryType.equals(JMSFactoryType.TOPIC_XA_CF))
/*     */     {
/* 202 */       factory = new HornetQXATopicConnectionFactory(false, transportConfigurations);
/*     */     }
/*     */     
/* 205 */     return factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Topic createTopic(String name)
/*     */   {
/* 216 */     return HornetQDestination.createTopic(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Queue createQueue(String name)
/*     */   {
/* 227 */     return HornetQDestination.createQueue(name);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\jms\HornetQJMSClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */