/*     */ package org.hornetq.api.config;
/*     */ 
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HornetQDefaultConfiguration
/*     */ {
/*     */   public static long getDefaultClientFailureCheckPeriod()
/*     */   {
/*  26 */     return DEFAULT_CLIENT_FAILURE_CHECK_PERIOD;
/*     */   }
/*     */   
/*     */   public static long getDefaultConnectionTtl()
/*     */   {
/*  31 */     return DEFAULT_CONNECTION_TTL;
/*     */   }
/*     */   
/*     */   public static double getDefaultRetryIntervalMultiplier()
/*     */   {
/*  36 */     return DEFAULT_RETRY_INTERVAL_MULTIPLIER;
/*     */   }
/*     */   
/*     */   public static long getDefaultMaxRetryInterval()
/*     */   {
/*  41 */     return DEFAULT_MAX_RETRY_INTERVAL;
/*     */   }
/*     */   
/*     */   public static String getDefaultJmxDomain()
/*     */   {
/*  46 */     return DEFAULT_JMX_DOMAIN;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultPersistDeliveryCountBeforeDelivery()
/*     */   {
/*  51 */     return DEFAULT_PERSIST_DELIVERY_COUNT_BEFORE_DELIVERY;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultBackup()
/*     */   {
/*  56 */     return DEFAULT_BACKUP;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultAllowAutoFailback()
/*     */   {
/*  61 */     return DEFAULT_ALLOW_AUTO_FAILBACK;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultSharedStore()
/*     */   {
/*  66 */     return DEFAULT_SHARED_STORE;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultFileDeploymentEnabled()
/*     */   {
/*  71 */     return DEFAULT_FILE_DEPLOYMENT_ENABLED;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultPersistenceEnabled()
/*     */   {
/*  76 */     return DEFAULT_PERSISTENCE_ENABLED;
/*     */   }
/*     */   
/*     */   public static long getDefaultFileDeployerScanPeriod()
/*     */   {
/*  81 */     return DEFAULT_FILE_DEPLOYER_SCAN_PERIOD;
/*     */   }
/*     */   
/*     */   public static int getDefaultScheduledThreadPoolMaxSize()
/*     */   {
/*  86 */     return DEFAULT_SCHEDULED_THREAD_POOL_MAX_SIZE;
/*     */   }
/*     */   
/*     */   public static int getDefaultThreadPoolMaxSize()
/*     */   {
/*  91 */     return DEFAULT_THREAD_POOL_MAX_SIZE;
/*     */   }
/*     */   
/*     */   public static long getDefaultSecurityInvalidationInterval()
/*     */   {
/*  96 */     return DEFAULT_SECURITY_INVALIDATION_INTERVAL;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultSecurityEnabled()
/*     */   {
/* 101 */     return DEFAULT_SECURITY_ENABLED;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultJmxManagementEnabled()
/*     */   {
/* 106 */     return DEFAULT_JMX_MANAGEMENT_ENABLED;
/*     */   }
/*     */   
/*     */   public static long getDefaultConnectionTtlOverride()
/*     */   {
/* 111 */     return DEFAULT_CONNECTION_TTL_OVERRIDE;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultAsyncConnectionExecutionEnabled()
/*     */   {
/* 116 */     return DEFAULT_ASYNC_CONNECTION_EXECUTION_ENABLED;
/*     */   }
/*     */   
/*     */   public static String getDefaultBindingsDirectory()
/*     */   {
/* 121 */     return DEFAULT_BINDINGS_DIRECTORY;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultCreateBindingsDir()
/*     */   {
/* 126 */     return DEFAULT_CREATE_BINDINGS_DIR;
/*     */   }
/*     */   
/*     */   public static String getDefaultJournalDir()
/*     */   {
/* 131 */     return DEFAULT_JOURNAL_DIR;
/*     */   }
/*     */   
/*     */   public static String getDefaultPagingDir()
/*     */   {
/* 136 */     return DEFAULT_PAGING_DIR;
/*     */   }
/*     */   
/*     */   public static String getDefaultLargeMessagesDir()
/*     */   {
/* 141 */     return DEFAULT_LARGE_MESSAGES_DIR;
/*     */   }
/*     */   
/*     */   public static int getDefaultMaxConcurrentPageIo()
/*     */   {
/* 146 */     return DEFAULT_MAX_CONCURRENT_PAGE_IO;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultCreateJournalDir()
/*     */   {
/* 151 */     return DEFAULT_CREATE_JOURNAL_DIR;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultJournalSyncTransactional()
/*     */   {
/* 156 */     return DEFAULT_JOURNAL_SYNC_TRANSACTIONAL;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultJournalSyncNonTransactional()
/*     */   {
/* 161 */     return DEFAULT_JOURNAL_SYNC_NON_TRANSACTIONAL;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalFileSize()
/*     */   {
/* 166 */     return DEFAULT_JOURNAL_FILE_SIZE;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalCompactMinFiles()
/*     */   {
/* 171 */     return DEFAULT_JOURNAL_COMPACT_MIN_FILES;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalCompactPercentage()
/*     */   {
/* 176 */     return DEFAULT_JOURNAL_COMPACT_PERCENTAGE;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalMinFiles()
/*     */   {
/* 181 */     return DEFAULT_JOURNAL_MIN_FILES;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalMaxIoAio()
/*     */   {
/* 186 */     return DEFAULT_JOURNAL_MAX_IO_AIO;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalBufferTimeoutAio()
/*     */   {
/* 191 */     return DEFAULT_JOURNAL_BUFFER_TIMEOUT_AIO;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalBufferSizeAio()
/*     */   {
/* 196 */     return DEFAULT_JOURNAL_BUFFER_SIZE_AIO;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalMaxIoNio()
/*     */   {
/* 201 */     return DEFAULT_JOURNAL_MAX_IO_NIO;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalBufferTimeoutNio()
/*     */   {
/* 206 */     return DEFAULT_JOURNAL_BUFFER_TIMEOUT_NIO;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalBufferSizeNio()
/*     */   {
/* 211 */     return DEFAULT_JOURNAL_BUFFER_SIZE_NIO;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultJournalLogWriteRate()
/*     */   {
/* 216 */     return DEFAULT_JOURNAL_LOG_WRITE_RATE;
/*     */   }
/*     */   
/*     */   public static int getDefaultJournalPerfBlastPages()
/*     */   {
/* 221 */     return DEFAULT_JOURNAL_PERF_BLAST_PAGES;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultRunSyncSpeedTest()
/*     */   {
/* 226 */     return DEFAULT_RUN_SYNC_SPEED_TEST;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultWildcardRoutingEnabled()
/*     */   {
/* 231 */     return DEFAULT_WILDCARD_ROUTING_ENABLED;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultMessageCounterEnabled()
/*     */   {
/* 236 */     return DEFAULT_MESSAGE_COUNTER_ENABLED;
/*     */   }
/*     */   
/*     */   public static long getDefaultMessageCounterSamplePeriod()
/*     */   {
/* 241 */     return DEFAULT_MESSAGE_COUNTER_SAMPLE_PERIOD;
/*     */   }
/*     */   
/*     */   public static int getDefaultMessageCounterMaxDayHistory()
/*     */   {
/* 246 */     return DEFAULT_MESSAGE_COUNTER_MAX_DAY_HISTORY;
/*     */   }
/*     */   
/*     */   public static long getDefaultTransactionTimeout()
/*     */   {
/* 251 */     return DEFAULT_TRANSACTION_TIMEOUT;
/*     */   }
/*     */   
/*     */   public static long getDefaultTransactionTimeoutScanPeriod()
/*     */   {
/* 256 */     return DEFAULT_TRANSACTION_TIMEOUT_SCAN_PERIOD;
/*     */   }
/*     */   
/*     */   public static SimpleString getDefaultManagementAddress()
/*     */   {
/* 261 */     return DEFAULT_MANAGEMENT_ADDRESS;
/*     */   }
/*     */   
/*     */   public static SimpleString getDefaultManagementNotificationAddress()
/*     */   {
/* 266 */     return DEFAULT_MANAGEMENT_NOTIFICATION_ADDRESS;
/*     */   }
/*     */   
/*     */   public static String getDefaultClusterUser()
/*     */   {
/* 271 */     return DEFAULT_CLUSTER_USER;
/*     */   }
/*     */   
/*     */   public static String getDefaultClusterPassword()
/*     */   {
/* 276 */     return DEFAULT_CLUSTER_PASSWORD;
/*     */   }
/*     */   
/*     */   public static long getDefaultBroadcastPeriod()
/*     */   {
/* 281 */     return DEFAULT_BROADCAST_PERIOD;
/*     */   }
/*     */   
/*     */   public static long getDefaultBroadcastRefreshTimeout()
/*     */   {
/* 286 */     return DEFAULT_BROADCAST_REFRESH_TIMEOUT;
/*     */   }
/*     */   
/*     */   public static long getDefaultMessageExpiryScanPeriod()
/*     */   {
/* 291 */     return DEFAULT_MESSAGE_EXPIRY_SCAN_PERIOD;
/*     */   }
/*     */   
/*     */   public static int getDefaultMessageExpiryThreadPriority()
/*     */   {
/* 296 */     return DEFAULT_MESSAGE_EXPIRY_THREAD_PRIORITY;
/*     */   }
/*     */   
/*     */   public static int getDefaultIdCacheSize()
/*     */   {
/* 301 */     return DEFAULT_ID_CACHE_SIZE;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultPersistIdCache()
/*     */   {
/* 306 */     return DEFAULT_PERSIST_ID_CACHE;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultClusterDuplicateDetection()
/*     */   {
/* 311 */     return DEFAULT_CLUSTER_DUPLICATE_DETECTION;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultClusterForwardWhenNoConsumers()
/*     */   {
/* 316 */     return DEFAULT_CLUSTER_FORWARD_WHEN_NO_CONSUMERS;
/*     */   }
/*     */   
/*     */   public static int getDefaultClusterMaxHops()
/*     */   {
/* 321 */     return DEFAULT_CLUSTER_MAX_HOPS;
/*     */   }
/*     */   
/*     */   public static long getDefaultClusterRetryInterval()
/*     */   {
/* 326 */     return DEFAULT_CLUSTER_RETRY_INTERVAL;
/*     */   }
/*     */   
/*     */   public static int getDefaultClusterReconnectAttempts()
/*     */   {
/* 331 */     return DEFAULT_CLUSTER_RECONNECT_ATTEMPTS;
/*     */   }
/*     */   
/*     */   public static long getDefaultClusterFailureCheckPeriod()
/*     */   {
/* 336 */     return DEFAULT_CLUSTER_FAILURE_CHECK_PERIOD;
/*     */   }
/*     */   
/*     */   public static long getDefaultClusterConnectionTtl()
/*     */   {
/* 341 */     return DEFAULT_CLUSTER_CONNECTION_TTL;
/*     */   }
/*     */   
/*     */   public static double getDefaultClusterRetryIntervalMultiplier()
/*     */   {
/* 346 */     return DEFAULT_CLUSTER_RETRY_INTERVAL_MULTIPLIER;
/*     */   }
/*     */   
/*     */   public static long getDefaultClusterMaxRetryInterval()
/*     */   {
/* 351 */     return DEFAULT_CLUSTER_MAX_RETRY_INTERVAL;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultDivertExclusive()
/*     */   {
/* 356 */     return DEFAULT_DIVERT_EXCLUSIVE;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultBridgeDuplicateDetection()
/*     */   {
/* 361 */     return DEFAULT_BRIDGE_DUPLICATE_DETECTION;
/*     */   }
/*     */   
/*     */   public static int getDefaultBridgeReconnectAttempts()
/*     */   {
/* 366 */     return DEFAULT_BRIDGE_RECONNECT_ATTEMPTS;
/*     */   }
/*     */   
/*     */   public static long getDefaultServerDumpInterval()
/*     */   {
/* 371 */     return DEFAULT_SERVER_DUMP_INTERVAL;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultFailoverOnServerShutdown()
/*     */   {
/* 376 */     return DEFAULT_FAILOVER_ON_SERVER_SHUTDOWN;
/*     */   }
/*     */   
/*     */   public static int getDefaultMemoryWarningThreshold()
/*     */   {
/* 381 */     return DEFAULT_MEMORY_WARNING_THRESHOLD;
/*     */   }
/*     */   
/*     */   public static long getDefaultMemoryMeasureInterval()
/*     */   {
/* 386 */     return DEFAULT_MEMORY_MEASURE_INTERVAL;
/*     */   }
/*     */   
/*     */   public static long getDefaultFailbackDelay()
/*     */   {
/* 391 */     return DEFAULT_FAILBACK_DELAY;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultCheckForLiveServer()
/*     */   {
/* 396 */     return DEFAULT_CHECK_FOR_LIVE_SERVER;
/*     */   }
/*     */   
/*     */   public static boolean isDefaultMaskPassword()
/*     */   {
/* 401 */     return DEFAULT_MASK_PASSWORD;
/*     */   }
/*     */   
/*     */   public static long getDefaultClusterNotificationInterval()
/*     */   {
/* 406 */     return DEFAULT_CLUSTER_NOTIFICATION_INTERVAL;
/*     */   }
/*     */   
/*     */   public static int getDefaultClusterNotificationAttempts()
/*     */   {
/* 411 */     return DEFAULT_CLUSTER_NOTIFICATION_ATTEMPTS;
/*     */   }
/*     */   
/*     */   public static String getPropMaskPassword()
/*     */   {
/* 416 */     return PROP_MASK_PASSWORD;
/*     */   }
/*     */   
/*     */   public static String getPropPasswordCodec()
/*     */   {
/* 421 */     return PROP_PASSWORD_CODEC;
/*     */   }
/*     */   
/*     */   public static int getDefaultBridgeConnectSameNode()
/*     */   {
/* 426 */     return DEFAULT_BRIDGE_CONNECT_SAME_NODE;
/*     */   }
/*     */   
/*     */   public static int getDefaultMaxSavedReplicatedJournalsSize()
/*     */   {
/* 431 */     return DEFAULT_MAX_SAVED_REPLICATED_JOURNALS_SIZE;
/*     */   }
/*     */   
/*     */   public static long getDefaultGroupTimeout()
/*     */   {
/* 436 */     return DEFAULT_GROUP_TIMEOUT;
/*     */   }
/*     */   
/*     */ 
/* 440 */   private static long DEFAULT_CLIENT_FAILURE_CHECK_PERIOD = 30000L;
/*     */   
/*     */ 
/*     */ 
/* 444 */   private static long DEFAULT_CONNECTION_TTL = 60000L;
/*     */   
/* 446 */   private static double DEFAULT_RETRY_INTERVAL_MULTIPLIER = 1.0D;
/*     */   
/* 448 */   private static long DEFAULT_MAX_RETRY_INTERVAL = 2000L;
/*     */   
/* 450 */   private static String DEFAULT_JMX_DOMAIN = "org.hornetq";
/*     */   
/*     */ 
/*     */ 
/* 454 */   private static boolean DEFAULT_PERSIST_DELIVERY_COUNT_BEFORE_DELIVERY = false;
/*     */   
/*     */ 
/*     */ 
/* 458 */   private static boolean DEFAULT_BACKUP = false;
/*     */   
/*     */ 
/*     */ 
/* 462 */   private static boolean DEFAULT_ALLOW_AUTO_FAILBACK = true;
/*     */   
/*     */ 
/*     */ 
/* 466 */   private static boolean DEFAULT_SHARED_STORE = true;
/* 467 */   private static boolean DEFAULT_FILE_DEPLOYMENT_ENABLED = false;
/*     */   
/*     */ 
/*     */ 
/* 471 */   private static boolean DEFAULT_PERSISTENCE_ENABLED = true;
/* 472 */   private static long DEFAULT_FILE_DEPLOYER_SCAN_PERIOD = 5000L;
/* 473 */   private static int DEFAULT_SCHEDULED_THREAD_POOL_MAX_SIZE = 5;
/* 474 */   private static int DEFAULT_THREAD_POOL_MAX_SIZE = 30;
/* 475 */   private static long DEFAULT_SECURITY_INVALIDATION_INTERVAL = 10000L;
/* 476 */   private static boolean DEFAULT_SECURITY_ENABLED = true;
/* 477 */   private static boolean DEFAULT_JMX_MANAGEMENT_ENABLED = true;
/* 478 */   private static long DEFAULT_CONNECTION_TTL_OVERRIDE = -1L;
/* 479 */   private static boolean DEFAULT_ASYNC_CONNECTION_EXECUTION_ENABLED = true;
/* 480 */   private static String DEFAULT_BINDINGS_DIRECTORY = "data/bindings";
/* 481 */   private static boolean DEFAULT_CREATE_BINDINGS_DIR = true;
/* 482 */   private static String DEFAULT_JOURNAL_DIR = "data/journal";
/* 483 */   private static String DEFAULT_PAGING_DIR = "data/paging";
/* 484 */   private static String DEFAULT_LARGE_MESSAGES_DIR = "data/largemessages";
/* 485 */   private static int DEFAULT_MAX_CONCURRENT_PAGE_IO = 5;
/* 486 */   private static boolean DEFAULT_CREATE_JOURNAL_DIR = true;
/* 487 */   private static boolean DEFAULT_JOURNAL_SYNC_TRANSACTIONAL = true;
/* 488 */   private static boolean DEFAULT_JOURNAL_SYNC_NON_TRANSACTIONAL = true;
/* 489 */   private static int DEFAULT_JOURNAL_FILE_SIZE = 10485760;
/* 490 */   private static int DEFAULT_JOURNAL_COMPACT_MIN_FILES = 10;
/* 491 */   private static int DEFAULT_JOURNAL_COMPACT_PERCENTAGE = 30;
/* 492 */   private static int DEFAULT_JOURNAL_MIN_FILES = 2;
/* 493 */   private static int DEFAULT_JOURNAL_MAX_IO_AIO = 500;
/* 494 */   private static int DEFAULT_JOURNAL_BUFFER_TIMEOUT_AIO = 500000;
/* 495 */   private static int DEFAULT_JOURNAL_BUFFER_SIZE_AIO = 501760;
/* 496 */   private static int DEFAULT_JOURNAL_MAX_IO_NIO = 1;
/* 497 */   private static int DEFAULT_JOURNAL_BUFFER_TIMEOUT_NIO = 3333333;
/* 498 */   private static int DEFAULT_JOURNAL_BUFFER_SIZE_NIO = 501760;
/* 499 */   private static boolean DEFAULT_JOURNAL_LOG_WRITE_RATE = false;
/* 500 */   private static int DEFAULT_JOURNAL_PERF_BLAST_PAGES = -1;
/* 501 */   private static boolean DEFAULT_RUN_SYNC_SPEED_TEST = false;
/* 502 */   private static boolean DEFAULT_WILDCARD_ROUTING_ENABLED = true;
/* 503 */   private static boolean DEFAULT_MESSAGE_COUNTER_ENABLED = false;
/* 504 */   private static long DEFAULT_MESSAGE_COUNTER_SAMPLE_PERIOD = 10000L;
/* 505 */   private static int DEFAULT_MESSAGE_COUNTER_MAX_DAY_HISTORY = 10;
/* 506 */   private static long DEFAULT_TRANSACTION_TIMEOUT = 300000L;
/* 507 */   private static long DEFAULT_TRANSACTION_TIMEOUT_SCAN_PERIOD = 1000L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 512 */   private static SimpleString DEFAULT_MANAGEMENT_ADDRESS = new SimpleString("jms.queue.hornetq.management");
/* 513 */   private static SimpleString DEFAULT_MANAGEMENT_NOTIFICATION_ADDRESS = new SimpleString("hornetq.notifications");
/* 514 */   private static String DEFAULT_CLUSTER_USER = "HORNETQ.CLUSTER.ADMIN.USER";
/* 515 */   private static String DEFAULT_CLUSTER_PASSWORD = "CHANGE ME!!";
/* 516 */   private static int DEFAULT_MAX_SAVED_REPLICATED_JOURNALS_SIZE = 2;
/* 517 */   private static long DEFAULT_BROADCAST_PERIOD = 2000L;
/* 518 */   private static long DEFAULT_BROADCAST_REFRESH_TIMEOUT = 10000L;
/* 519 */   private static long DEFAULT_MESSAGE_EXPIRY_SCAN_PERIOD = 30000L;
/* 520 */   private static int DEFAULT_MESSAGE_EXPIRY_THREAD_PRIORITY = 3;
/* 521 */   private static int DEFAULT_ID_CACHE_SIZE = 20000;
/* 522 */   private static boolean DEFAULT_PERSIST_ID_CACHE = true;
/* 523 */   private static boolean DEFAULT_CLUSTER_DUPLICATE_DETECTION = true;
/* 524 */   private static boolean DEFAULT_CLUSTER_FORWARD_WHEN_NO_CONSUMERS = false;
/* 525 */   private static int DEFAULT_CLUSTER_MAX_HOPS = 1;
/* 526 */   private static long DEFAULT_CLUSTER_RETRY_INTERVAL = 500L;
/* 527 */   private static int DEFAULT_CLUSTER_RECONNECT_ATTEMPTS = -1;
/* 528 */   private static long DEFAULT_CLUSTER_FAILURE_CHECK_PERIOD = getDefaultClientFailureCheckPeriod();
/* 529 */   private static long DEFAULT_CLUSTER_CONNECTION_TTL = getDefaultConnectionTtl();
/* 530 */   private static double DEFAULT_CLUSTER_RETRY_INTERVAL_MULTIPLIER = getDefaultRetryIntervalMultiplier();
/* 531 */   private static long DEFAULT_CLUSTER_MAX_RETRY_INTERVAL = getDefaultMaxRetryInterval();
/* 532 */   private static boolean DEFAULT_DIVERT_EXCLUSIVE = false;
/* 533 */   private static boolean DEFAULT_BRIDGE_DUPLICATE_DETECTION = true;
/* 534 */   private static int DEFAULT_BRIDGE_RECONNECT_ATTEMPTS = -1;
/* 535 */   private static int DEFAULT_BRIDGE_CONNECT_SAME_NODE = 10;
/* 536 */   private static long DEFAULT_SERVER_DUMP_INTERVAL = -1L;
/* 537 */   private static boolean DEFAULT_FAILOVER_ON_SERVER_SHUTDOWN = false;
/* 538 */   private static int DEFAULT_MEMORY_WARNING_THRESHOLD = 25;
/* 539 */   private static long DEFAULT_MEMORY_MEASURE_INTERVAL = -1L;
/* 540 */   private static long DEFAULT_FAILBACK_DELAY = 5000L;
/* 541 */   private static boolean DEFAULT_CHECK_FOR_LIVE_SERVER = false;
/* 542 */   private static boolean DEFAULT_MASK_PASSWORD = false;
/* 543 */   private static long DEFAULT_CLUSTER_NOTIFICATION_INTERVAL = 1000L;
/* 544 */   private static int DEFAULT_CLUSTER_NOTIFICATION_ATTEMPTS = 2;
/* 545 */   private static long DEFAULT_GROUP_TIMEOUT = -1L;
/*     */   
/*     */ 
/* 548 */   private static String PROP_MASK_PASSWORD = "hornetq.usemaskedpassword";
/* 549 */   private static String PROP_PASSWORD_CODEC = "hornetq.passwordcodec";
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\config\HornetQDefaultConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */