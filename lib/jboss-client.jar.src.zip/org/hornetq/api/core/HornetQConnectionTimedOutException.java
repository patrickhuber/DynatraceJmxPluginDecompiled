/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQConnectionTimedOutException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 3244233758084830372L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQConnectionTimedOutException()
/*    */   {
/* 36 */     super(HornetQExceptionType.CONNECTION_TIMEDOUT);
/*    */   }
/*    */   
/*    */   public HornetQConnectionTimedOutException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.CONNECTION_TIMEDOUT, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQConnectionTimedOutException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */