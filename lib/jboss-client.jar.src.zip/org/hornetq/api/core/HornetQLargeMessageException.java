/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQLargeMessageException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 1087867463974768491L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQLargeMessageException()
/*    */   {
/* 36 */     super(HornetQExceptionType.LARGE_MESSAGE_ERROR_BODY);
/*    */   }
/*    */   
/*    */   public HornetQLargeMessageException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.LARGE_MESSAGE_ERROR_BODY, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQLargeMessageException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */