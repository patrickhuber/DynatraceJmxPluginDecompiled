/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQUnBlockedException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -4507889261891160608L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQUnBlockedException()
/*    */   {
/* 36 */     super(HornetQExceptionType.UNBLOCKED);
/*    */   }
/*    */   
/*    */   public HornetQUnBlockedException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.UNBLOCKED, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQUnBlockedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */