/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQPropertyConversionException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -3010008708334904332L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQPropertyConversionException(String message)
/*    */   {
/* 29 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQPropertyConversionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */