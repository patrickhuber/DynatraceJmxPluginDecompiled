/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.core.remoting.impl.netty.TransportConstants;
/*     */ import org.hornetq.utils.UUIDGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransportConfiguration
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -3994528421527392679L;
/*     */   private String name;
/*     */   private String factoryClassName;
/*     */   private Map<String, Object> params;
/*     */   private static final byte TYPE_BOOLEAN = 0;
/*     */   private static final byte TYPE_INT = 1;
/*     */   private static final byte TYPE_LONG = 2;
/*     */   private static final byte TYPE_STRING = 3;
/*     */   
/*     */   public static String[] splitHosts(String commaSeparatedHosts)
/*     */   {
/*  67 */     if (commaSeparatedHosts == null)
/*     */     {
/*  69 */       return new String[0];
/*     */     }
/*  71 */     String[] hosts = commaSeparatedHosts.split(",");
/*     */     
/*  73 */     for (int i = 0; i < hosts.length; i++)
/*     */     {
/*  75 */       hosts[i] = hosts[i].trim();
/*     */     }
/*  77 */     return hosts;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransportConfiguration() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransportConfiguration(String className, Map<String, Object> params, String name)
/*     */   {
/*  97 */     this.factoryClassName = className;
/*     */     
/*  99 */     this.params = params;
/*     */     
/* 101 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransportConfiguration(String className, Map<String, Object> params)
/*     */   {
/* 113 */     this(className, params, UUIDGenerator.getInstance().generateStringUUID());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransportConfiguration(String className)
/*     */   {
/* 123 */     this(className, new HashMap(), UUIDGenerator.getInstance().generateStringUUID());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 133 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFactoryClassName()
/*     */   {
/* 143 */     return this.factoryClassName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> getParams()
/*     */   {
/* 153 */     return this.params;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 159 */     return this.factoryClassName.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 165 */     if (!(other instanceof TransportConfiguration))
/*     */     {
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     TransportConfiguration kother = (TransportConfiguration)other;
/*     */     
/* 172 */     if (this.factoryClassName.equals(kother.factoryClassName))
/*     */     {
/* 174 */       if ((this.params == null) || (this.params.isEmpty()))
/*     */       {
/* 176 */         return (kother.params == null) || (kother.params.isEmpty());
/*     */       }
/*     */       
/*     */ 
/* 180 */       if ((kother.params == null) || (kother.params.isEmpty()))
/*     */       {
/* 182 */         return false;
/*     */       }
/* 184 */       if (this.params.size() == kother.params.size())
/*     */       {
/* 186 */         for (Map.Entry<String, Object> entry : this.params.entrySet())
/*     */         {
/* 188 */           Object thisVal = entry.getValue();
/*     */           
/* 190 */           Object otherVal = kother.params.get(entry.getKey());
/*     */           
/* 192 */           if ((otherVal == null) || (!otherVal.equals(thisVal)))
/*     */           {
/* 194 */             return false;
/*     */           }
/*     */         }
/* 197 */         return true;
/*     */       }
/*     */       
/*     */ 
/* 201 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 207 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEquivalent(TransportConfiguration otherConfig)
/*     */   {
/* 221 */     if (getFactoryClassName().equals(otherConfig.getFactoryClassName()))
/*     */     {
/* 223 */       return true;
/*     */     }
/* 225 */     if ((getFactoryClassName().contains("Netty")) && (otherConfig.getFactoryClassName().contains("Netty")))
/*     */     {
/* 227 */       return true;
/*     */     }
/* 229 */     if ((getFactoryClassName().contains("InVM")) && (otherConfig.getFactoryClassName().contains("InVM")))
/*     */     {
/* 231 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 235 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 242 */     StringBuilder str = new StringBuilder(TransportConfiguration.class.getSimpleName());
/* 243 */     str.append("(name=" + this.name + ", ");
/* 244 */     str.append("factory=" + replaceWildcardChars(this.factoryClassName));
/* 245 */     str.append(") ");
/* 246 */     boolean first; if (this.params != null)
/*     */     {
/* 248 */       if (!this.params.isEmpty())
/*     */       {
/* 250 */         str.append("?");
/*     */       }
/*     */       
/* 253 */       first = true;
/* 254 */       for (Map.Entry<String, Object> entry : this.params.entrySet())
/*     */       {
/* 256 */         if (!first)
/*     */         {
/* 258 */           str.append("&");
/*     */         }
/*     */         
/* 261 */         String key = (String)entry.getKey();
/*     */         
/*     */         String val;
/*     */         String val;
/* 265 */         if ((key.equals("key-store-password")) || (key.equals(TransportConstants.DEFAULT_TRUSTSTORE_PASSWORD)))
/*     */         {
/* 267 */           val = "****";
/*     */         }
/*     */         else
/*     */         {
/* 271 */           val = entry.getValue() == null ? "null" : entry.getValue().toString();
/*     */         }
/*     */         
/* 274 */         str.append(replaceWildcardChars(key)).append('=').append(replaceWildcardChars(val));
/*     */         
/* 276 */         first = false;
/*     */       }
/*     */     }
/* 279 */     return str.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encode(HornetQBuffer buffer)
/*     */   {
/* 291 */     buffer.writeString(this.name);
/* 292 */     buffer.writeString(this.factoryClassName);
/*     */     
/* 294 */     buffer.writeInt(this.params == null ? 0 : this.params.size());
/*     */     
/* 296 */     if (this.params != null)
/*     */     {
/* 298 */       for (Map.Entry<String, Object> entry : this.params.entrySet())
/*     */       {
/* 300 */         buffer.writeString((String)entry.getKey());
/*     */         
/* 302 */         Object val = entry.getValue();
/*     */         
/* 304 */         if ((val instanceof Boolean))
/*     */         {
/* 306 */           buffer.writeByte((byte)0);
/* 307 */           buffer.writeBoolean(((Boolean)val).booleanValue());
/*     */         }
/* 309 */         else if ((val instanceof Integer))
/*     */         {
/* 311 */           buffer.writeByte((byte)1);
/* 312 */           buffer.writeInt(((Integer)val).intValue());
/*     */         }
/* 314 */         else if ((val instanceof Long))
/*     */         {
/* 316 */           buffer.writeByte((byte)2);
/* 317 */           buffer.writeLong(((Long)val).longValue());
/*     */         }
/* 319 */         else if ((val instanceof String))
/*     */         {
/* 321 */           buffer.writeByte((byte)3);
/* 322 */           buffer.writeString((String)val);
/*     */         }
/*     */         else
/*     */         {
/* 326 */           throw HornetQClientMessageBundle.BUNDLE.invalidEncodeType(val);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decode(HornetQBuffer buffer)
/*     */   {
/* 341 */     this.name = buffer.readString();
/* 342 */     this.factoryClassName = buffer.readString();
/*     */     
/* 344 */     int num = buffer.readInt();
/*     */     
/* 346 */     if (this.params == null)
/*     */     {
/* 348 */       if (num > 0)
/*     */       {
/* 350 */         this.params = new HashMap();
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 355 */       this.params.clear();
/*     */     }
/*     */     
/* 358 */     for (int i = 0; i < num; i++)
/*     */     {
/* 360 */       String key = buffer.readString();
/*     */       
/* 362 */       byte type = buffer.readByte();
/*     */       
/*     */       Object val;
/*     */       
/* 366 */       switch (type)
/*     */       {
/*     */ 
/*     */       case 0: 
/* 370 */         val = Boolean.valueOf(buffer.readBoolean());
/*     */         
/* 372 */         break;
/*     */       
/*     */ 
/*     */       case 1: 
/* 376 */         val = Integer.valueOf(buffer.readInt());
/*     */         
/* 378 */         break;
/*     */       
/*     */ 
/*     */       case 2: 
/* 382 */         val = Long.valueOf(buffer.readLong());
/*     */         
/* 384 */         break;
/*     */       
/*     */ 
/*     */       case 3: 
/* 388 */         val = buffer.readString();
/*     */         
/* 390 */         break;
/*     */       
/*     */ 
/*     */       default: 
/* 394 */         throw HornetQClientMessageBundle.BUNDLE.invalidType(Byte.valueOf(type));
/*     */       }
/*     */       
/*     */       
/* 398 */       this.params.put(key, val);
/*     */     }
/*     */   }
/*     */   
/*     */   private static String replaceWildcardChars(String str)
/*     */   {
/* 404 */     return str.replace('.', '-');
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\TransportConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */