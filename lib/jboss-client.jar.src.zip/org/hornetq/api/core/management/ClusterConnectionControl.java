package org.hornetq.api.core.management;

import java.util.Map;

public abstract interface ClusterConnectionControl
  extends HornetQComponentControl
{
  public abstract String getName();
  
  public abstract String getAddress();
  
  public abstract String getNodeID();
  
  public abstract boolean isDuplicateDetection();
  
  public abstract boolean isForwardWhenNoConsumers();
  
  public abstract String getTopology();
  
  public abstract int getMaxHops();
  
  public abstract Object[] getStaticConnectors();
  
  public abstract String getStaticConnectorsAsJSON()
    throws Exception;
  
  public abstract String getDiscoveryGroupName();
  
  public abstract long getRetryInterval();
  
  public abstract Map<String, String> getNodes()
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\ClusterConnectionControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */