/*     */ package org.hornetq.api.core.management;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.hornetq.utils.json.JSONArray;
/*     */ import org.hornetq.utils.json.JSONException;
/*     */ import org.hornetq.utils.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DayCounterInfo
/*     */ {
/*     */   private final String date;
/*     */   private final int[] counters;
/*     */   
/*     */   public static String toJSON(DayCounterInfo[] infos)
/*     */     throws JSONException
/*     */   {
/*  39 */     JSONObject json = new JSONObject();
/*  40 */     JSONArray counters = new JSONArray();
/*  41 */     for (DayCounterInfo info : infos)
/*     */     {
/*  43 */       JSONObject counter = new JSONObject();
/*  44 */       counter.put("date", info.getDate());
/*  45 */       counter.put("counters", Arrays.asList(new int[][] { info.getCounters() }));
/*  46 */       counters.put(counter);
/*     */     }
/*  48 */     json.put("dayCounters", counters);
/*  49 */     return json.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static DayCounterInfo[] fromJSON(String jsonString)
/*     */     throws JSONException
/*     */   {
/*  58 */     JSONObject json = new JSONObject(jsonString);
/*  59 */     JSONArray dayCounters = json.getJSONArray("dayCounters");
/*  60 */     DayCounterInfo[] infos = new DayCounterInfo[dayCounters.length()];
/*  61 */     for (int i = 0; i < dayCounters.length(); i++)
/*     */     {
/*     */ 
/*  64 */       JSONObject counter = (JSONObject)dayCounters.get(i);
/*  65 */       JSONArray hour = (JSONArray)counter.getJSONArray("counters").get(0);
/*  66 */       int[] hourCounters = new int[24];
/*  67 */       for (int j = 0; j < 24; j++)
/*     */       {
/*  69 */         hourCounters[j] = hour.getInt(j);
/*     */       }
/*  71 */       DayCounterInfo info = new DayCounterInfo(counter.getString("date"), hourCounters);
/*  72 */       infos[i] = info;
/*     */     }
/*  74 */     return infos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DayCounterInfo(String date, int[] counters)
/*     */   {
/*  81 */     this.date = date;
/*  82 */     this.counters = counters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDate()
/*     */   {
/*  92 */     return this.date;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getCounters()
/*     */   {
/* 101 */     return this.counters;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\DayCounterInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */