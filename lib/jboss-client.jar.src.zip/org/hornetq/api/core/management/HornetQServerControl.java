package org.hornetq.api.core.management;

public abstract interface HornetQServerControl
{
  public abstract String getVersion();
  
  public abstract int getConnectionCount();
  
  public abstract boolean isStarted();
  
  @Deprecated
  public abstract String[] getInterceptorClassNames();
  
  public abstract String[] getIncomingInterceptorClassNames();
  
  public abstract String[] getOutgoingInterceptorClassNames();
  
  public abstract boolean isClustered();
  
  public abstract int getScheduledThreadPoolMaxSize();
  
  public abstract int getThreadPoolMaxSize();
  
  public abstract long getSecurityInvalidationInterval();
  
  public abstract boolean isSecurityEnabled();
  
  public abstract String getBindingsDirectory();
  
  public abstract String getJournalDirectory();
  
  public abstract String getJournalType();
  
  public abstract boolean isJournalSyncTransactional();
  
  public abstract boolean isJournalSyncNonTransactional();
  
  public abstract int getJournalFileSize();
  
  public abstract int getJournalMinFiles();
  
  public abstract int getJournalMaxIO();
  
  public abstract int getJournalBufferSize();
  
  public abstract int getJournalBufferTimeout();
  
  public abstract void setFailoverOnServerShutdown(boolean paramBoolean)
    throws Exception;
  
  public abstract boolean isFailoverOnServerShutdown();
  
  public abstract int getJournalCompactMinFiles();
  
  public abstract int getJournalCompactPercentage();
  
  public abstract boolean isPersistenceEnabled();
  
  public abstract boolean isCreateBindingsDir();
  
  public abstract boolean isCreateJournalDir();
  
  public abstract boolean isMessageCounterEnabled();
  
  public abstract int getMessageCounterMaxDayCount();
  
  public abstract void setMessageCounterMaxDayCount(int paramInt)
    throws Exception;
  
  public abstract long getMessageCounterSamplePeriod();
  
  public abstract void setMessageCounterSamplePeriod(long paramLong)
    throws Exception;
  
  public abstract boolean isBackup();
  
  public abstract boolean isSharedStore();
  
  public abstract String getPagingDirectory();
  
  public abstract boolean isPersistDeliveryCountBeforeDelivery();
  
  public abstract long getConnectionTTLOverride();
  
  public abstract String getManagementAddress();
  
  public abstract String getManagementNotificationAddress();
  
  public abstract int getIDCacheSize();
  
  public abstract boolean isPersistIDCache();
  
  public abstract String getLargeMessagesDirectory();
  
  public abstract boolean isWildcardRoutingEnabled();
  
  public abstract long getTransactionTimeout();
  
  public abstract long getTransactionTimeoutScanPeriod();
  
  public abstract long getMessageExpiryScanPeriod();
  
  public abstract long getMessageExpiryThreadPriority();
  
  public abstract boolean isAsyncConnectionExecutionEnabled();
  
  public abstract Object[] getConnectors()
    throws Exception;
  
  public abstract String getConnectorsAsJSON()
    throws Exception;
  
  public abstract String[] getAddressNames();
  
  public abstract String[] getQueueNames();
  
  @Operation(desc="Create a queue with the specified address", impact=1)
  public abstract void createQueue(@Parameter(name="address", desc="Address of the queue") String paramString1, @Parameter(name="name", desc="Name of the queue") String paramString2)
    throws Exception;
  
  @Operation(desc="Create a queue", impact=1)
  public abstract void createQueue(@Parameter(name="address", desc="Address of the queue") String paramString1, @Parameter(name="name", desc="Name of the queue") String paramString2, @Parameter(name="filter", desc="Filter of the queue") String paramString3, @Parameter(name="durable", desc="Is the queue durable?") boolean paramBoolean)
    throws Exception;
  
  @Operation(desc="Create a queue with the specified address, name and durability", impact=1)
  public abstract void createQueue(@Parameter(name="address", desc="Address of the queue") String paramString1, @Parameter(name="name", desc="Name of the queue") String paramString2, @Parameter(name="durable", desc="Is the queue durable?") boolean paramBoolean)
    throws Exception;
  
  @Operation(desc="Deploy a queue", impact=1)
  public abstract void deployQueue(@Parameter(name="address", desc="Address of the queue") String paramString1, @Parameter(name="name", desc="Name of the queue") String paramString2, @Parameter(name="filter", desc="Filter of the queue") String paramString3)
    throws Exception;
  
  @Operation(desc="Deploy a queue", impact=1)
  public abstract void deployQueue(@Parameter(name="address", desc="Address of the queue") String paramString1, @Parameter(name="name", desc="Name of the queue") String paramString2, @Parameter(name="filter", desc="Filter of the queue") String paramString3, @Parameter(name="durable", desc="Is the queue durable?") boolean paramBoolean)
    throws Exception;
  
  @Operation(desc="Destroy a queue", impact=1)
  public abstract void destroyQueue(@Parameter(name="name", desc="Name of the queue to destroy") String paramString)
    throws Exception;
  
  @Operation(desc="Enable message counters", impact=1)
  public abstract void enableMessageCounters()
    throws Exception;
  
  @Operation(desc="Disable message counters", impact=1)
  public abstract void disableMessageCounters()
    throws Exception;
  
  @Operation(desc="Reset all message counters", impact=1)
  public abstract void resetAllMessageCounters()
    throws Exception;
  
  @Operation(desc="Reset all message counters history", impact=1)
  public abstract void resetAllMessageCounterHistories()
    throws Exception;
  
  @Operation(desc="List all the prepared transaction, sorted by date, oldest first")
  public abstract String[] listPreparedTransactions()
    throws Exception;
  
  @Operation(desc="List all the prepared transaction, sorted by date, oldest first, with details, in JSON format")
  public abstract String listPreparedTransactionDetailsAsJSON()
    throws Exception;
  
  @Operation(desc="List all the prepared transaction, sorted by date, oldest first, with details, in HTML format")
  public abstract String listPreparedTransactionDetailsAsHTML()
    throws Exception;
  
  public abstract String[] listHeuristicCommittedTransactions()
    throws Exception;
  
  public abstract String[] listHeuristicRolledBackTransactions()
    throws Exception;
  
  @Operation(desc="Commit a prepared transaction")
  public abstract boolean commitPreparedTransaction(@Parameter(desc="the Base64 representation of a transaction", name="transactionAsBase64") String paramString)
    throws Exception;
  
  @Operation(desc="Rollback a prepared transaction")
  public abstract boolean rollbackPreparedTransaction(@Parameter(desc="the Base64 representation of a transaction", name="transactionAsBase64") String paramString)
    throws Exception;
  
  @Operation(desc="List the client addresses", impact=0)
  public abstract String[] listRemoteAddresses()
    throws Exception;
  
  @Operation(desc="List the client addresses which match the given IP Address", impact=0)
  public abstract String[] listRemoteAddresses(@Parameter(desc="an IP address", name="ipAddress") String paramString)
    throws Exception;
  
  @Operation(desc="Closes all the connections for the given IP Address", impact=0)
  public abstract boolean closeConnectionsForAddress(@Parameter(desc="an IP address", name="ipAddress") String paramString)
    throws Exception;
  
  @Operation(desc="Closes all the consumer connections for the given HornetQ address", impact=0)
  public abstract boolean closeConsumerConnectionsForAddress(@Parameter(desc="a HornetQ address", name="address") String paramString)
    throws Exception;
  
  @Operation(desc="Closes all the connections for sessions with the given user name", impact=0)
  public abstract boolean closeConnectionsForUser(@Parameter(desc="a user name", name="userName") String paramString)
    throws Exception;
  
  @Operation(desc="List all the connection IDs", impact=0)
  public abstract String[] listConnectionIDs()
    throws Exception;
  
  public abstract String listProducersInfoAsJSON()
    throws Exception;
  
  @Operation(desc="List the sessions for the given connectionID", impact=0)
  public abstract String[] listSessions(@Parameter(desc="a connection ID", name="connectionID") String paramString)
    throws Exception;
  
  public abstract void sendQueueInfoToQueue(String paramString1, String paramString2)
    throws Exception;
  
  @Operation(desc="Add security settings for addresses matching the addressMatch", impact=1)
  public abstract void addSecuritySettings(@Parameter(desc="an address match", name="addressMatch") String paramString1, @Parameter(desc="a comma-separated list of roles allowed to send messages", name="send") String paramString2, @Parameter(desc="a comma-separated list of roles allowed to consume messages", name="consume") String paramString3, @Parameter(desc="a comma-separated list of roles allowed to create durable queues", name="createDurableQueueRoles") String paramString4, @Parameter(desc="a comma-separated list of roles allowed to delete durable queues", name="deleteDurableQueueRoles") String paramString5, @Parameter(desc="a comma-separated list of roles allowed to create non durable queues", name="createNonDurableQueueRoles") String paramString6, @Parameter(desc="a comma-separated list of roles allowed to delete non durable queues", name="deleteNonDurableQueueRoles") String paramString7, @Parameter(desc="a comma-separated list of roles allowed to send management messages messages", name="manage") String paramString8)
    throws Exception;
  
  @Operation(desc="Remove security settings for an address", impact=1)
  public abstract void removeSecuritySettings(@Parameter(desc="an address match", name="addressMatch") String paramString)
    throws Exception;
  
  @Operation(desc="get roles for a specific address match", impact=0)
  public abstract Object[] getRoles(@Parameter(desc="an address match", name="addressMatch") String paramString)
    throws Exception;
  
  @Operation(desc="get roles (as a JSON string) for a specific address match", impact=0)
  public abstract String getRolesAsJSON(@Parameter(desc="an address match", name="addressMatch") String paramString)
    throws Exception;
  
  @Operation(desc="Add address settings for addresses matching the addressMatch", impact=1)
  public abstract void addAddressSettings(@Parameter(desc="an address match", name="addressMatch") String paramString1, @Parameter(desc="the dead letter address setting", name="DLA") String paramString2, @Parameter(desc="the expiry address setting", name="expiryAddress") String paramString3, @Parameter(desc="the expiry delay setting", name="expiryDelay") long paramLong1, @Parameter(desc="are any queues created for this address a last value queue", name="lastValueQueue") boolean paramBoolean1, @Parameter(desc="the delivery attempts", name="deliveryAttempts") int paramInt1, @Parameter(desc="the max size in bytes", name="maxSizeBytes") long paramLong2, @Parameter(desc="the page size in bytes", name="pageSizeBytes") int paramInt2, @Parameter(desc="the max number of pages in the soft memory cache", name="pageMaxCacheSize") int paramInt3, @Parameter(desc="the redelivery delay", name="redeliveryDelay") long paramLong3, @Parameter(desc="the redelivery delay multiplier", name="redeliveryMultiplier") double paramDouble, @Parameter(desc="the maximum redelivery delay", name="maxRedeliveryDelay") long paramLong4, @Parameter(desc="the redistribution delay", name="redistributionDelay") long paramLong5, @Parameter(desc="do we send to the DLA when there is no where to route the message", name="sendToDLAOnNoRoute") boolean paramBoolean2, @Parameter(desc="the policy to use when the address is full", name="addressFullMessagePolicy") String paramString4, @Parameter(desc="when a consumer falls below this threshold in terms of messages consumed per second it will be considered 'slow'", name="slowConsumerThreshold") long paramLong6, @Parameter(desc="how often (in seconds) to check for slow consumers", name="slowConsumerCheckPeriod") long paramLong7, @Parameter(desc="the policy to use when a slow consumer is detected", name="slowConsumerPolicy") String paramString5)
    throws Exception;
  
  public abstract void removeAddressSettings(String paramString)
    throws Exception;
  
  @Operation(desc="returns the address settings as a JSON string for an address match", impact=0)
  public abstract String getAddressSettingsAsJSON(@Parameter(desc="an address match", name="addressMatch") String paramString)
    throws Exception;
  
  public abstract String[] getDivertNames();
  
  @Operation(desc="Create a Divert", impact=1)
  public abstract void createDivert(@Parameter(name="name", desc="Name of the divert") String paramString1, @Parameter(name="routingName", desc="Routing name of the divert") String paramString2, @Parameter(name="address", desc="Address to divert from") String paramString3, @Parameter(name="forwardingAddress", desc="Adress to divert to") String paramString4, @Parameter(name="exclusive", desc="Is the divert exclusive?") boolean paramBoolean, @Parameter(name="filterString", desc="Filter of the divert") String paramString5, @Parameter(name="transformerClassName", desc="Class name of the divert's transformer") String paramString6)
    throws Exception;
  
  @Operation(desc="Destroy a Divert", impact=1)
  public abstract void destroyDivert(@Parameter(name="name", desc="Name of the divert") String paramString)
    throws Exception;
  
  public abstract String[] getBridgeNames();
  
  @Operation(desc="Create a Bridge", impact=1)
  public abstract void createBridge(@Parameter(name="name", desc="Name of the bridge") String paramString1, @Parameter(name="queueName", desc="Name of the source queue") String paramString2, @Parameter(name="forwardingAddress", desc="Forwarding address") String paramString3, @Parameter(name="filterString", desc="Filter of the brdige") String paramString4, @Parameter(name="transformerClassName", desc="Class name of the bridge transformer") String paramString5, @Parameter(name="retryInterval", desc="Connection retry interval") long paramLong1, @Parameter(name="retryIntervalMultiplier", desc="Connection retry interval multiplier") double paramDouble, @Parameter(name="reconnectAttempts", desc="Number of reconnection attempts") int paramInt1, @Parameter(name="useDuplicateDetection", desc="Use duplicate detection") boolean paramBoolean1, @Parameter(name="confirmationWindowSize", desc="Confirmation window size") int paramInt2, @Parameter(name="clientFailureCheckPeriod", desc="Period to check client failure") long paramLong2, @Parameter(name="staticConnectorNames", desc="comma separated list of connector names or name of discovery group if 'useDiscoveryGroup' is set to true") String paramString6, @Parameter(name="useDiscoveryGroup", desc="use discovery  group") boolean paramBoolean2, @Parameter(name="ha", desc="Is it using HA") boolean paramBoolean3, @Parameter(name="user", desc="User name") String paramString7, @Parameter(name="password", desc="User password") String paramString8)
    throws Exception;
  
  @Operation(desc="Destroy a bridge", impact=1)
  public abstract void destroyBridge(@Parameter(name="name", desc="Name of the bridge") String paramString)
    throws Exception;
  
  @Operation(desc="force the server to stop and notify clients to failover", impact=3)
  public abstract void forceFailover()
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\HornetQServerControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */