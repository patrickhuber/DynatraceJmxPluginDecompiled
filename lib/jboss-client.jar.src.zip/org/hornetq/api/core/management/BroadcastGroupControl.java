package org.hornetq.api.core.management;

public abstract interface BroadcastGroupControl
  extends HornetQComponentControl
{
  public abstract String getName();
  
  public abstract int getLocalBindPort()
    throws Exception;
  
  public abstract String getGroupAddress()
    throws Exception;
  
  public abstract int getGroupPort()
    throws Exception;
  
  public abstract long getBroadcastPeriod();
  
  public abstract Object[] getConnectorPairs();
  
  public abstract String getConnectorPairsAsJSON()
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\BroadcastGroupControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */