/*     */ package org.hornetq.api.core.management;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.Message;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.utils.json.JSONArray;
/*     */ import org.hornetq.utils.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ManagementHelper
/*     */ {
/*  37 */   public static final SimpleString HDR_RESOURCE_NAME = new SimpleString("_HQ_ResourceName");
/*     */   
/*  39 */   public static final SimpleString HDR_ATTRIBUTE = new SimpleString("_HQ_Attribute");
/*     */   
/*  41 */   public static final SimpleString HDR_OPERATION_NAME = new SimpleString("_HQ_OperationName");
/*     */   
/*  43 */   public static final SimpleString HDR_OPERATION_SUCCEEDED = new SimpleString("_HQ_OperationSucceeded");
/*     */   
/*  45 */   public static final SimpleString HDR_NOTIFICATION_TYPE = new SimpleString("_HQ_NotifType");
/*     */   
/*  47 */   public static final SimpleString HDR_NOTIFICATION_TIMESTAMP = new SimpleString("_HQ_NotifTimestamp");
/*     */   
/*  49 */   public static final SimpleString HDR_ROUTING_NAME = new SimpleString("_HQ_RoutingName");
/*     */   
/*  51 */   public static final SimpleString HDR_CLUSTER_NAME = new SimpleString("_HQ_ClusterName");
/*     */   
/*  53 */   public static final SimpleString HDR_ADDRESS = new SimpleString("_HQ_Address");
/*     */   
/*  55 */   public static final SimpleString HDR_BINDING_ID = new SimpleString("_HQ_Binding_ID");
/*     */   
/*  57 */   public static final SimpleString HDR_BINDING_TYPE = new SimpleString("_HQ_Binding_Type");
/*     */   
/*  59 */   public static final SimpleString HDR_FILTERSTRING = new SimpleString("_HQ_FilterString");
/*     */   
/*  61 */   public static final SimpleString HDR_DISTANCE = new SimpleString("_HQ_Distance");
/*     */   
/*  63 */   public static final SimpleString HDR_CONSUMER_COUNT = new SimpleString("_HQ_ConsumerCount");
/*     */   
/*  65 */   public static final SimpleString HDR_USER = new SimpleString("_HQ_User");
/*     */   
/*  67 */   public static final SimpleString HDR_CHECK_TYPE = new SimpleString("_HQ_CheckType");
/*     */   
/*  69 */   public static final SimpleString HDR_SESSION_NAME = new SimpleString("_HQ_SessionName");
/*     */   
/*  71 */   public static final SimpleString HDR_REMOTE_ADDRESS = new SimpleString("_HQ_RemoteAddress");
/*     */   
/*  73 */   public static final SimpleString HDR_PROPOSAL_GROUP_ID = new SimpleString("_JBM_ProposalGroupId");
/*     */   
/*  75 */   public static final SimpleString HDR_PROPOSAL_VALUE = new SimpleString("_JBM_ProposalValue");
/*     */   
/*  77 */   public static final SimpleString HDR_PROPOSAL_ALT_VALUE = new SimpleString("_JBM_ProposalAltValue");
/*     */   
/*  79 */   public static final SimpleString HDR_CONSUMER_NAME = new SimpleString("_HQ_ConsumerName");
/*     */   
/*  81 */   public static final SimpleString HDR_CONNECTION_NAME = new SimpleString("_HQ_ConnectionName");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putAttribute(Message message, String resourceName, String attribute)
/*     */   {
/*  97 */     message.putStringProperty(HDR_RESOURCE_NAME, new SimpleString(resourceName));
/*  98 */     message.putStringProperty(HDR_ATTRIBUTE, new SimpleString(attribute));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putOperationInvocation(Message message, String resourceName, String operationName)
/*     */     throws Exception
/*     */   {
/* 113 */     putOperationInvocation(message, resourceName, operationName, (Object[])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void putOperationInvocation(Message message, String resourceName, String operationName, Object... parameters)
/*     */     throws Exception
/*     */   {
/* 131 */     message.putStringProperty(HDR_RESOURCE_NAME, new SimpleString(resourceName));
/* 132 */     message.putStringProperty(HDR_OPERATION_NAME, new SimpleString(operationName));
/*     */     
/*     */     String paramString;
/*     */     
/*     */     String paramString;
/*     */     
/* 138 */     if (parameters != null)
/*     */     {
/* 140 */       JSONArray jsonArray = toJSONArray(parameters);
/*     */       
/* 142 */       paramString = jsonArray.toString();
/*     */     }
/*     */     else
/*     */     {
/* 146 */       paramString = null;
/*     */     }
/*     */     
/* 149 */     message.getBodyBuffer().writeNullableSimpleString(SimpleString.toSimpleString(paramString));
/*     */   }
/*     */   
/*     */   private static JSONArray toJSONArray(Object[] array) throws Exception
/*     */   {
/* 154 */     JSONArray jsonArray = new JSONArray();
/*     */     
/* 156 */     for (Object parameter : array)
/*     */     {
/* 158 */       if ((parameter instanceof Map))
/*     */       {
/* 160 */         Map<String, Object> map = (Map)parameter;
/*     */         
/* 162 */         JSONObject jsonObject = new JSONObject();
/*     */         
/* 164 */         for (Map.Entry<String, Object> entry : map.entrySet())
/*     */         {
/* 166 */           String key = (String)entry.getKey();
/*     */           
/* 168 */           Object val = entry.getValue();
/*     */           
/* 170 */           if (val != null)
/*     */           {
/* 172 */             if (val.getClass().isArray())
/*     */             {
/* 174 */               val = toJSONArray((Object[])val);
/*     */             }
/*     */             else
/*     */             {
/* 178 */               checkType(val);
/*     */             }
/*     */           }
/*     */           
/* 182 */           jsonObject.put(key, val);
/*     */         }
/*     */         
/* 185 */         jsonArray.put(jsonObject);
/*     */ 
/*     */ 
/*     */       }
/* 189 */       else if (parameter != null)
/*     */       {
/* 191 */         Class<?> clz = parameter.getClass();
/*     */         
/* 193 */         if (clz.isArray())
/*     */         {
/* 195 */           Object[] innerArray = (Object[])parameter;
/*     */           
/* 197 */           jsonArray.put(toJSONArray(innerArray));
/*     */         }
/*     */         else
/*     */         {
/* 201 */           checkType(parameter);
/*     */           
/* 203 */           jsonArray.put(parameter);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 208 */         jsonArray.put((Object)null);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 213 */     return jsonArray;
/*     */   }
/*     */   
/*     */   private static Object[] fromJSONArray(JSONArray jsonArray) throws Exception
/*     */   {
/* 218 */     Object[] array = new Object[jsonArray.length()];
/*     */     
/* 220 */     for (int i = 0; i < jsonArray.length(); i++)
/*     */     {
/* 222 */       Object val = jsonArray.get(i);
/*     */       
/* 224 */       if ((val instanceof JSONArray))
/*     */       {
/* 226 */         Object[] inner = fromJSONArray((JSONArray)val);
/*     */         
/* 228 */         array[i] = inner;
/*     */       }
/* 230 */       else if ((val instanceof JSONObject))
/*     */       {
/* 232 */         JSONObject jsonObject = (JSONObject)val;
/*     */         
/* 234 */         Map<String, Object> map = new HashMap();
/*     */         
/* 236 */         Iterator<String> iter = jsonObject.keys();
/*     */         
/* 238 */         while (iter.hasNext())
/*     */         {
/* 240 */           String key = (String)iter.next();
/*     */           
/* 242 */           Object innerVal = jsonObject.get(key);
/*     */           
/* 244 */           if ((innerVal instanceof JSONArray))
/*     */           {
/* 246 */             innerVal = fromJSONArray((JSONArray)innerVal);
/*     */           }
/* 248 */           else if ((innerVal instanceof JSONObject))
/*     */           {
/* 250 */             Map<String, Object> innerMap = new HashMap();
/* 251 */             JSONObject o = (JSONObject)innerVal;
/* 252 */             Iterator it = o.keys();
/* 253 */             while (it.hasNext())
/*     */             {
/* 255 */               String k = (String)it.next();
/* 256 */               innerMap.put(k, o.get(k));
/*     */             }
/* 258 */             innerVal = innerMap;
/*     */           }
/* 260 */           else if ((innerVal instanceof Integer))
/*     */           {
/* 262 */             innerVal = Long.valueOf(((Integer)innerVal).longValue());
/*     */           }
/*     */           
/* 265 */           map.put(key, innerVal);
/*     */         }
/*     */         
/* 268 */         array[i] = map;
/*     */ 
/*     */ 
/*     */       }
/* 272 */       else if (val == JSONObject.NULL)
/*     */       {
/* 274 */         array[i] = null;
/*     */       }
/*     */       else
/*     */       {
/* 278 */         array[i] = val;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 283 */     return array;
/*     */   }
/*     */   
/*     */   private static void checkType(Object param)
/*     */   {
/* 288 */     if ((!(param instanceof Integer)) && (!(param instanceof Long)) && (!(param instanceof Double)) && (!(param instanceof String)) && (!(param instanceof Boolean)) && (!(param instanceof Map)) && (!(param instanceof Byte)) && (!(param instanceof Short)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 296 */       throw HornetQClientMessageBundle.BUNDLE.invalidManagementParam(param.getClass().getName());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Object[] retrieveOperationParameters(Message message)
/*     */     throws Exception
/*     */   {
/* 305 */     SimpleString sstring = message.getBodyBuffer().readNullableSimpleString();
/* 306 */     String jsonString = sstring == null ? null : sstring.toString();
/*     */     
/* 308 */     if (jsonString != null)
/*     */     {
/* 310 */       JSONArray jsonArray = new JSONArray(jsonString);
/*     */       
/* 312 */       return fromJSONArray(jsonArray);
/*     */     }
/*     */     
/*     */ 
/* 316 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isOperationResult(Message message)
/*     */   {
/* 325 */     return message.containsProperty(HDR_OPERATION_SUCCEEDED);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isAttributesResult(Message message)
/*     */   {
/* 333 */     return !isOperationResult(message);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void storeResult(Message message, Object result)
/*     */     throws Exception
/*     */   {
/*     */     String resultString;
/*     */     
/*     */     String resultString;
/* 343 */     if (result != null)
/*     */     {
/*     */ 
/*     */ 
/* 347 */       JSONArray jsonArray = toJSONArray(new Object[] { result });
/*     */       
/* 349 */       resultString = jsonArray.toString();
/*     */     }
/*     */     else
/*     */     {
/* 353 */       resultString = null;
/*     */     }
/*     */     
/* 356 */     message.getBodyBuffer().writeNullableSimpleString(SimpleString.toSimpleString(resultString));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object[] getResults(Message message)
/*     */     throws Exception
/*     */   {
/* 367 */     SimpleString sstring = message.getBodyBuffer().readNullableSimpleString();
/* 368 */     String jsonString = sstring == null ? null : sstring.toString();
/* 369 */     if (jsonString != null)
/*     */     {
/* 371 */       JSONArray jsonArray = new JSONArray(jsonString);
/*     */       
/* 373 */       Object[] res = fromJSONArray(jsonArray);
/*     */       
/* 375 */       return res;
/*     */     }
/*     */     
/*     */ 
/* 379 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object getResult(Message message)
/*     */     throws Exception
/*     */   {
/* 391 */     Object[] res = getResults(message);
/*     */     
/* 393 */     if (res != null)
/*     */     {
/* 395 */       return res[0];
/*     */     }
/*     */     
/*     */ 
/* 399 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean hasOperationSucceeded(Message message)
/*     */   {
/* 408 */     if (!isOperationResult(message))
/*     */     {
/* 410 */       return false;
/*     */     }
/* 412 */     if (message.containsProperty(HDR_OPERATION_SUCCEEDED))
/*     */     {
/* 414 */       return message.getBooleanProperty(HDR_OPERATION_SUCCEEDED).booleanValue();
/*     */     }
/* 416 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Map<String, Object> fromCommaSeparatedKeyValues(String str)
/*     */     throws Exception
/*     */   {
/* 424 */     if ((str == null) || (str.trim().length() == 0))
/*     */     {
/* 426 */       return Collections.emptyMap();
/*     */     }
/*     */     
/*     */ 
/* 430 */     JSONArray array = new JSONArray("[{" + str + "}]");
/* 431 */     Map<String, Object> params = (Map)fromJSONArray(array)[0];
/* 432 */     return params;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static Object[] fromCommaSeparatedArrayOfCommaSeparatedKeyValues(String str)
/*     */     throws Exception
/*     */   {
/* 440 */     if ((str == null) || (str.trim().length() == 0))
/*     */     {
/* 442 */       return new Object[0];
/*     */     }
/*     */     
/* 445 */     String s = str;
/*     */     
/*     */ 
/* 448 */     if (!s.trim().startsWith("{"))
/*     */     {
/* 450 */       s = "{" + s + "}";
/*     */     }
/* 452 */     JSONArray array = new JSONArray("[" + s + "]");
/* 453 */     return fromJSONArray(array);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\ManagementHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */