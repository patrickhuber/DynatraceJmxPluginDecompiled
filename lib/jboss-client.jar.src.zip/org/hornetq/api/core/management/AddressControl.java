package org.hornetq.api.core.management;

public abstract interface AddressControl
{
  public abstract String getAddress();
  
  public abstract Object[] getRoles()
    throws Exception;
  
  public abstract String getRolesAsJSON()
    throws Exception;
  
  public abstract String[] getQueueNames()
    throws Exception;
  
  public abstract int getNumberOfPages()
    throws Exception;
  
  public abstract boolean isPaging()
    throws Exception;
  
  public abstract long getNumberOfBytesPerPage()
    throws Exception;
  
  public abstract String[] getBindingNames()
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\AddressControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */