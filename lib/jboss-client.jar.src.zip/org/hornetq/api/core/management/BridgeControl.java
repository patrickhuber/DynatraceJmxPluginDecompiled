package org.hornetq.api.core.management;

public abstract interface BridgeControl
  extends HornetQComponentControl
{
  public abstract String getName();
  
  public abstract String getQueueName();
  
  public abstract String getForwardingAddress();
  
  public abstract String getFilterString();
  
  public abstract String getTransformerClassName();
  
  public abstract String[] getStaticConnectors()
    throws Exception;
  
  public abstract String getDiscoveryGroupName();
  
  public abstract long getRetryInterval();
  
  public abstract double getRetryIntervalMultiplier();
  
  public abstract int getReconnectAttempts();
  
  public abstract boolean isUseDuplicateDetection();
  
  public abstract boolean isHA();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\BridgeControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */