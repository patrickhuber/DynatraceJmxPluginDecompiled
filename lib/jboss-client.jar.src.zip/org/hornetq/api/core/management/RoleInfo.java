/*     */ package org.hornetq.api.core.management;
/*     */ 
/*     */ import org.hornetq.utils.json.JSONArray;
/*     */ import org.hornetq.utils.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RoleInfo
/*     */ {
/*     */   private final String name;
/*     */   private final boolean send;
/*     */   private final boolean consume;
/*     */   private final boolean createDurableQueue;
/*     */   private final boolean deleteDurableQueue;
/*     */   private final boolean createNonDurableQueue;
/*     */   private final boolean deleteNonDurableQueue;
/*     */   private final boolean manage;
/*     */   
/*     */   public static RoleInfo[] from(String jsonString)
/*     */     throws Exception
/*     */   {
/*  49 */     JSONArray array = new JSONArray(jsonString);
/*  50 */     RoleInfo[] roles = new RoleInfo[array.length()];
/*  51 */     for (int i = 0; i < array.length(); i++)
/*     */     {
/*  53 */       JSONObject r = array.getJSONObject(i);
/*  54 */       RoleInfo role = new RoleInfo(r.getString("name"), r.getBoolean("send"), r.getBoolean("consume"), r.getBoolean("createDurableQueue"), r.getBoolean("deleteDurableQueue"), r.getBoolean("createNonDurableQueue"), r.getBoolean("deleteNonDurableQueue"), r.getBoolean("manage"));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */       roles[i] = role;
/*     */     }
/*  64 */     return roles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RoleInfo(String name, boolean send, boolean consume, boolean createDurableQueue, boolean deleteDurableQueue, boolean createNonDurableQueue, boolean deleteNonDurableQueue, boolean manage)
/*     */   {
/*  76 */     this.name = name;
/*  77 */     this.send = send;
/*  78 */     this.consume = consume;
/*  79 */     this.createDurableQueue = createDurableQueue;
/*  80 */     this.deleteDurableQueue = deleteDurableQueue;
/*  81 */     this.createNonDurableQueue = createNonDurableQueue;
/*  82 */     this.deleteNonDurableQueue = deleteNonDurableQueue;
/*  83 */     this.manage = manage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  91 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSend()
/*     */   {
/*  99 */     return this.send;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConsume()
/*     */   {
/* 107 */     return this.consume;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCreateDurableQueue()
/*     */   {
/* 115 */     return this.createDurableQueue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDeleteDurableQueue()
/*     */   {
/* 123 */     return this.deleteDurableQueue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCreateNonDurableQueue()
/*     */   {
/* 131 */     return this.createNonDurableQueue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDeleteNonDurableQueue()
/*     */   {
/* 139 */     return this.deleteNonDurableQueue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isManage()
/*     */   {
/* 147 */     return this.manage;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\RoleInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */