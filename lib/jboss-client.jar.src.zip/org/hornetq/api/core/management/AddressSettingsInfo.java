/*     */ package org.hornetq.api.core.management;
/*     */ 
/*     */ import org.hornetq.utils.json.JSONObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AddressSettingsInfo
/*     */ {
/*     */   private final String addressFullMessagePolicy;
/*     */   private final long maxSizeBytes;
/*     */   private final int pageSizeBytes;
/*     */   private int pageCacheMaxSize;
/*     */   private final int maxDeliveryAttempts;
/*     */   private final double redeliveryMultiplier;
/*     */   private final long maxRedeliveryDelay;
/*     */   private final long redeliveryDelay;
/*     */   private final String deadLetterAddress;
/*     */   private final String expiryAddress;
/*     */   private final boolean lastValueQueue;
/*     */   private final long redistributionDelay;
/*     */   private final boolean sendToDLAOnNoRoute;
/*     */   private final long slowConsumerThreshold;
/*     */   private final long slowConsumerCheckPeriod;
/*     */   private final String slowConsumerPolicy;
/*     */   
/*     */   public static AddressSettingsInfo from(String jsonString)
/*     */     throws Exception
/*     */   {
/*  62 */     JSONObject object = new JSONObject(jsonString);
/*  63 */     return new AddressSettingsInfo(object.getString("addressFullMessagePolicy"), object.getLong("maxSizeBytes"), object.getInt("pageSizeBytes"), object.getInt("pageCacheMaxSize"), object.getInt("maxDeliveryAttempts"), object.getLong("redeliveryDelay"), object.getDouble("redeliveryMultiplier"), object.getLong("maxRedeliveryDelay"), object.getString("DLA"), object.getString("expiryAddress"), object.getBoolean("lastValueQueue"), object.getLong("redistributionDelay"), object.getBoolean("sendToDLAOnNoRoute"), object.getLong("slowConsumerThreshold"), object.getLong("slowConsumerCheckPeriod"), object.getString("slowConsumerPolicy"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AddressSettingsInfo(String addressFullMessagePolicy, long maxSizeBytes, int pageSizeBytes, int pageCacheMaxSize, int maxDeliveryAttempts, long redeliveryDelay, double redeliveryMultiplier, long maxRedeliveryDelay, String deadLetterAddress, String expiryAddress, boolean lastValueQueue, long redistributionDelay, boolean sendToDLAOnNoRoute, long slowConsumerThreshold, long slowConsumerCheckPeriod, String slowConsumerPolicy)
/*     */   {
/* 100 */     this.addressFullMessagePolicy = addressFullMessagePolicy;
/* 101 */     this.maxSizeBytes = maxSizeBytes;
/* 102 */     this.pageSizeBytes = pageSizeBytes;
/* 103 */     this.pageCacheMaxSize = pageCacheMaxSize;
/* 104 */     this.maxDeliveryAttempts = maxDeliveryAttempts;
/* 105 */     this.redeliveryDelay = redeliveryDelay;
/* 106 */     this.redeliveryMultiplier = redeliveryMultiplier;
/* 107 */     this.maxRedeliveryDelay = maxRedeliveryDelay;
/* 108 */     this.deadLetterAddress = deadLetterAddress;
/* 109 */     this.expiryAddress = expiryAddress;
/* 110 */     this.lastValueQueue = lastValueQueue;
/* 111 */     this.redistributionDelay = redistributionDelay;
/* 112 */     this.sendToDLAOnNoRoute = sendToDLAOnNoRoute;
/* 113 */     this.slowConsumerThreshold = slowConsumerThreshold;
/* 114 */     this.slowConsumerCheckPeriod = slowConsumerCheckPeriod;
/* 115 */     this.slowConsumerPolicy = slowConsumerPolicy;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPageCacheMaxSize()
/*     */   {
/* 122 */     return this.pageCacheMaxSize;
/*     */   }
/*     */   
/*     */   public void setPageCacheMaxSize(int pageCacheMaxSize)
/*     */   {
/* 127 */     this.pageCacheMaxSize = pageCacheMaxSize;
/*     */   }
/*     */   
/*     */   public String getAddressFullMessagePolicy()
/*     */   {
/* 132 */     return this.addressFullMessagePolicy;
/*     */   }
/*     */   
/*     */   public long getMaxSizeBytes()
/*     */   {
/* 137 */     return this.maxSizeBytes;
/*     */   }
/*     */   
/*     */   public int getPageSizeBytes()
/*     */   {
/* 142 */     return this.pageSizeBytes;
/*     */   }
/*     */   
/*     */   public int getMaxDeliveryAttempts()
/*     */   {
/* 147 */     return this.maxDeliveryAttempts;
/*     */   }
/*     */   
/*     */   public long getRedeliveryDelay()
/*     */   {
/* 152 */     return this.redeliveryDelay;
/*     */   }
/*     */   
/*     */   public String getDeadLetterAddress()
/*     */   {
/* 157 */     return this.deadLetterAddress;
/*     */   }
/*     */   
/*     */   public String getExpiryAddress()
/*     */   {
/* 162 */     return this.expiryAddress;
/*     */   }
/*     */   
/*     */   public boolean isLastValueQueue()
/*     */   {
/* 167 */     return this.lastValueQueue;
/*     */   }
/*     */   
/*     */   public long getRedistributionDelay()
/*     */   {
/* 172 */     return this.redistributionDelay;
/*     */   }
/*     */   
/*     */   public boolean isSendToDLAOnNoRoute()
/*     */   {
/* 177 */     return this.sendToDLAOnNoRoute;
/*     */   }
/*     */   
/*     */   public double getRedeliveryMultiplier()
/*     */   {
/* 182 */     return this.redeliveryMultiplier;
/*     */   }
/*     */   
/*     */   public long getMaxRedeliveryDelay()
/*     */   {
/* 187 */     return this.maxRedeliveryDelay;
/*     */   }
/*     */   
/*     */   public long getSlowConsumerThreshold()
/*     */   {
/* 192 */     return this.slowConsumerThreshold;
/*     */   }
/*     */   
/*     */   public long getSlowConsumerCheckPeriod()
/*     */   {
/* 197 */     return this.slowConsumerCheckPeriod;
/*     */   }
/*     */   
/*     */   public String getSlowConsumerPolicy()
/*     */   {
/* 202 */     return this.slowConsumerPolicy;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\AddressSettingsInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */