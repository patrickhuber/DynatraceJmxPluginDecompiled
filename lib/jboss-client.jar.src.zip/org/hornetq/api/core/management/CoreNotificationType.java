/*    */ package org.hornetq.api.core.management;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CoreNotificationType
/*    */   implements NotificationType
/*    */ {
/* 22 */   BINDING_ADDED(0), 
/* 23 */   BINDING_REMOVED(1), 
/* 24 */   CONSUMER_CREATED(2), 
/* 25 */   CONSUMER_CLOSED(3), 
/* 26 */   SECURITY_AUTHENTICATION_VIOLATION(6), 
/* 27 */   SECURITY_PERMISSION_VIOLATION(7), 
/* 28 */   DISCOVERY_GROUP_STARTED(8), 
/* 29 */   DISCOVERY_GROUP_STOPPED(9), 
/* 30 */   BROADCAST_GROUP_STARTED(10), 
/* 31 */   BROADCAST_GROUP_STOPPED(11), 
/* 32 */   BRIDGE_STARTED(12), 
/* 33 */   BRIDGE_STOPPED(13), 
/* 34 */   CLUSTER_CONNECTION_STARTED(14), 
/* 35 */   CLUSTER_CONNECTION_STOPPED(15), 
/* 36 */   ACCEPTOR_STARTED(16), 
/* 37 */   ACCEPTOR_STOPPED(17), 
/* 38 */   PROPOSAL(18), 
/* 39 */   PROPOSAL_RESPONSE(19), 
/* 40 */   UNPROPOSAL(20), 
/* 41 */   CONSUMER_SLOW(21);
/*    */   
/*    */   private final int value;
/*    */   
/*    */   private CoreNotificationType(int value)
/*    */   {
/* 47 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getType()
/*    */   {
/* 52 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\CoreNotificationType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */