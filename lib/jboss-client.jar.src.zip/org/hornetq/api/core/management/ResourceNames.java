package org.hornetq.api.core.management;

public final class ResourceNames
{
  public static final String CORE_SERVER = "core.server";
  public static final String CORE_QUEUE = "core.queue.";
  public static final String CORE_ADDRESS = "core.address.";
  public static final String CORE_BRIDGE = "core.bridge.";
  public static final String CORE_ACCEPTOR = "core.acceptor.";
  public static final String CORE_DIVERT = "core.divert.";
  public static final String CORE_CLUSTER_CONNECTION = "core.clusterconnection.";
  public static final String CORE_BROADCAST_GROUP = "core.broadcastgroup.";
  public static final String CORE_DISCOVERY_GROUP = "core.discovery.";
  public static final String JMS_SERVER = "jms.server";
  public static final String JMS_QUEUE = "jms.queue.";
  public static final String JMS_TOPIC = "jms.topic.";
  public static final String JMS_CONNECTION_FACTORY = "jms.connectionfactory.";
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\ResourceNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */