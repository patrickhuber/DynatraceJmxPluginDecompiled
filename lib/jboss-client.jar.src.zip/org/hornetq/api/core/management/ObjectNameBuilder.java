/*     */ package org.hornetq.api.core.management;
/*     */ 
/*     */ import javax.management.ObjectName;
/*     */ import org.hornetq.api.config.HornetQDefaultConfiguration;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObjectNameBuilder
/*     */ {
/*  33 */   public static final ObjectNameBuilder DEFAULT = new ObjectNameBuilder(HornetQDefaultConfiguration.getDefaultJmxDomain());
/*     */   
/*     */ 
/*     */   static final String JMS_MODULE = "JMS";
/*     */   
/*     */ 
/*     */   static final String CORE_MODULE = "Core";
/*     */   
/*     */ 
/*     */   private final String domain;
/*     */   
/*     */ 
/*     */   public static ObjectNameBuilder create(String domain)
/*     */   {
/*  47 */     if (domain == null)
/*     */     {
/*  49 */       return new ObjectNameBuilder(HornetQDefaultConfiguration.getDefaultJmxDomain());
/*     */     }
/*     */     
/*     */ 
/*  53 */     return new ObjectNameBuilder(domain);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ObjectNameBuilder(String domain)
/*     */   {
/*  61 */     this.domain = domain;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getHornetQServerObjectName()
/*     */     throws Exception
/*     */   {
/*  71 */     return ObjectName.getInstance(this.domain + ":module=Core,type=Server");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getAddressObjectName(SimpleString address)
/*     */     throws Exception
/*     */   {
/*  81 */     return createObjectName("Core", "Address", address.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getQueueObjectName(SimpleString address, SimpleString name)
/*     */     throws Exception
/*     */   {
/*  91 */     return ObjectName.getInstance(String.format("%s:module=%s,type=%s,address=%s,name=%s", new Object[] { this.domain, "Core", "Queue", ObjectName.quote(address.toString()), ObjectName.quote(name.toString()) }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getDivertObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 106 */     return createObjectName("Core", "Divert", name.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getAcceptorObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 116 */     return createObjectName("Core", "Acceptor", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getBroadcastGroupObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 126 */     return createObjectName("Core", "BroadcastGroup", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getBridgeObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 136 */     return createObjectName("Core", "Bridge", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getClusterConnectionObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 146 */     return createObjectName("Core", "ClusterConnection", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getDiscoveryGroupObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 156 */     return createObjectName("Core", "DiscoveryGroup", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getJMSServerObjectName()
/*     */     throws Exception
/*     */   {
/* 165 */     return ObjectName.getInstance(this.domain + ":module=JMS,type=Server");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getJMSQueueObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 174 */     return createObjectName("JMS", "Queue", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getJMSTopicObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 184 */     return createObjectName("JMS", "Topic", name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ObjectName getConnectionFactoryObjectName(String name)
/*     */     throws Exception
/*     */   {
/* 193 */     return createObjectName("JMS", "ConnectionFactory", name);
/*     */   }
/*     */   
/*     */   private ObjectName createObjectName(String module, String type, String name) throws Exception
/*     */   {
/* 198 */     return ObjectName.getInstance(String.format("%s:module=%s,type=%s,name=%s", new Object[] { this.domain, module, type, ObjectName.quote(name) }));
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\ObjectNameBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */