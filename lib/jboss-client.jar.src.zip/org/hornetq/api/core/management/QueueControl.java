package org.hornetq.api.core.management;

import java.util.Map;

public abstract interface QueueControl
{
  public abstract String getName();
  
  public abstract String getAddress();
  
  public abstract long getID();
  
  public abstract boolean isTemporary();
  
  public abstract boolean isDurable();
  
  public abstract String getFilter();
  
  public abstract long getMessageCount();
  
  public abstract long getScheduledCount();
  
  public abstract int getConsumerCount();
  
  public abstract int getDeliveringCount();
  
  public abstract long getMessagesAdded();
  
  public abstract String getExpiryAddress();
  
  public abstract void setExpiryAddress(@Parameter(name="expiryAddress", desc="Expiry address of the queue") String paramString)
    throws Exception;
  
  public abstract String getDeadLetterAddress();
  
  public abstract void setDeadLetterAddress(@Parameter(name="deadLetterAddress", desc="Dead-letter address of the queue") String paramString)
    throws Exception;
  
  @Operation(desc="List the messages scheduled for delivery", impact=0)
  public abstract Map<String, Object>[] listScheduledMessages()
    throws Exception;
  
  @Operation(desc="List the messages scheduled for delivery and returns them using JSON", impact=0)
  public abstract String listScheduledMessagesAsJSON()
    throws Exception;
  
  @Operation(desc="List all messages being delivered per consumer")
  public abstract Map<String, Map<String, Object>[]> listDeliveringMessages()
    throws Exception;
  
  @Operation(desc="list all messages being delivered per consumer using JSON form")
  public abstract String listDeliveringMessagesAsJSON()
    throws Exception;
  
  @Operation(desc="List all the messages in the queue matching the given filter", impact=0)
  public abstract Map<String, Object>[] listMessages(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString)
    throws Exception;
  
  @Operation(desc="List all the messages in the queue matching the given filter and returns them using JSON", impact=0)
  public abstract String listMessagesAsJSON(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString)
    throws Exception;
  
  @Operation(desc="Returns the number of the messages in the queue matching the given filter", impact=0)
  public abstract long countMessages(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString)
    throws Exception;
  
  @Operation(desc="Remove the message corresponding to the given messageID", impact=1)
  public abstract boolean removeMessage(@Parameter(name="messageID", desc="A message ID") long paramLong)
    throws Exception;
  
  @Operation(desc="Remove the messages corresponding to the given filter (and returns the number of removed messages)", impact=1)
  public abstract int removeMessages(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString)
    throws Exception;
  
  @Operation(desc="Expire the messages corresponding to the given filter (and returns the number of expired messages)", impact=1)
  public abstract int expireMessages(@Parameter(name="filter", desc="A message filter") String paramString)
    throws Exception;
  
  @Operation(desc="Remove the message corresponding to the given messageID", impact=1)
  public abstract boolean expireMessage(@Parameter(name="messageID", desc="A message ID") long paramLong)
    throws Exception;
  
  @Operation(desc="Move the message corresponding to the given messageID to another queue. rejectDuplicate=false on this case", impact=1)
  public abstract boolean moveMessage(@Parameter(name="messageID", desc="A message ID") long paramLong, @Parameter(name="otherQueueName", desc="The name of the queue to move the message to") String paramString)
    throws Exception;
  
  @Operation(desc="Move the message corresponding to the given messageID to another queue", impact=1)
  public abstract boolean moveMessage(@Parameter(name="messageID", desc="A message ID") long paramLong, @Parameter(name="otherQueueName", desc="The name of the queue to move the message to") String paramString, @Parameter(name="rejectDuplicates", desc="Reject messages identified as duplicate by the duplicate message") boolean paramBoolean)
    throws Exception;
  
  @Operation(desc="Move the messages corresponding to the given filter (and returns the number of moved messages). RejectDuplicates=false on this case.", impact=1)
  public abstract int moveMessages(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString1, @Parameter(name="otherQueueName", desc="The name of the queue to move the messages to") String paramString2)
    throws Exception;
  
  @Operation(desc="Move the messages corresponding to the given filter (and returns the number of moved messages)", impact=1)
  public abstract int moveMessages(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString1, @Parameter(name="otherQueueName", desc="The name of the queue to move the messages to") String paramString2, @Parameter(name="rejectDuplicates", desc="Reject messages identified as duplicate by the duplicate message") boolean paramBoolean)
    throws Exception;
  
  @Operation(desc="Send the message corresponding to the given messageID to this queue's Dead Letter Address", impact=1)
  public abstract boolean sendMessageToDeadLetterAddress(@Parameter(name="messageID", desc="A message ID") long paramLong)
    throws Exception;
  
  @Operation(desc="Send the messages corresponding to the given filter to this queue's Dead Letter Address", impact=1)
  public abstract int sendMessagesToDeadLetterAddress(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString)
    throws Exception;
  
  @Operation(desc="Change the priority of the message corresponding to the given messageID", impact=1)
  public abstract boolean changeMessagePriority(@Parameter(name="messageID", desc="A message ID") long paramLong, @Parameter(name="newPriority", desc="the new priority (between 0 and 9)") int paramInt)
    throws Exception;
  
  @Operation(desc="Change the priority of the messages corresponding to the given filter", impact=1)
  public abstract int changeMessagesPriority(@Parameter(name="filter", desc="A message filter (can be empty)") String paramString, @Parameter(name="newPriority", desc="the new priority (between 0 and 9)") int paramInt)
    throws Exception;
  
  @Operation(desc="List the message counters", impact=0)
  public abstract String listMessageCounter()
    throws Exception;
  
  @Operation(desc="Reset the message counters", impact=0)
  public abstract void resetMessageCounter()
    throws Exception;
  
  @Operation(desc="List the message counters as HTML", impact=0)
  public abstract String listMessageCounterAsHTML()
    throws Exception;
  
  @Operation(desc="List the message counters history", impact=0)
  public abstract String listMessageCounterHistory()
    throws Exception;
  
  @Operation(desc="List the message counters history HTML", impact=0)
  public abstract String listMessageCounterHistoryAsHTML()
    throws Exception;
  
  @Operation(desc="Pauses the Queue", impact=1)
  public abstract void pause()
    throws Exception;
  
  @Operation(desc="Resumes delivery of queued messages and gets the queue out of paused state.", impact=1)
  public abstract void resume()
    throws Exception;
  
  @Operation(desc="List all the existent consumers on the Queue")
  public abstract String listConsumersAsJSON()
    throws Exception;
  
  @Operation(desc="Inspects if the queue is paused", impact=0)
  public abstract boolean isPaused()
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\management\QueueControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */