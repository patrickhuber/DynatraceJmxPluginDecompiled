/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum HornetQExceptionType
/*     */ {
/*  16 */   INTERNAL_ERROR(0), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  24 */   UNSUPPORTED_PACKET(1), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  32 */   NOT_CONNECTED(2), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   CONNECTION_TIMEDOUT(3), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */   DISCONNECTED(4), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   UNBLOCKED(5), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */   IO_ERROR(6), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   QUEUE_DOES_NOT_EXIST(100), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   QUEUE_EXISTS(101), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   OBJECT_CLOSED(102), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   INVALID_FILTER_EXPRESSION(103), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 104 */   ILLEGAL_STATE(104), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */   SECURITY_EXCEPTION(105), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   ADDRESS_EXISTS(107), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */   INCOMPATIBLE_CLIENT_SERVER_VERSIONS(108), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   LARGE_MESSAGE_ERROR_BODY(110), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */   TRANSACTION_ROLLED_BACK(111), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */   SESSION_CREATION_REJECTED(112), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */   DUPLICATE_ID_REJECTED(113), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */   DUPLICATE_METADATA(114), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */   TRANSACTION_OUTCOME_UNKNOWN(115), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */   ALREADY_REPLICATING(116), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */   INTERCEPTOR_REJECTED_PACKET(117), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */   GENERIC_EXCEPTION(999), 
/* 201 */   NATIVE_ERROR_INTERNAL(200), 
/* 202 */   NATIVE_ERROR_INVALID_BUFFER(201), 
/* 203 */   NATIVE_ERROR_NOT_ALIGNED(202), 
/* 204 */   NATIVE_ERROR_CANT_INITIALIZE_AIO(203), 
/* 205 */   NATIVE_ERROR_CANT_RELEASE_AIO(204), 
/* 206 */   NATIVE_ERROR_CANT_OPEN_CLOSE_FILE(205), 
/* 207 */   NATIVE_ERROR_CANT_ALLOCATE_QUEUE(206), 
/* 208 */   NATIVE_ERROR_PREALLOCATE_FILE(208), 
/* 209 */   NATIVE_ERROR_ALLOCATE_MEMORY(209), 
/* 210 */   ADDRESS_FULL(210), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */   LARGE_MESSAGE_INTERRUPTED(211), 
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */   CLUSTER_SECURITY_EXCEPTION(212);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final Map<Integer, HornetQExceptionType> TYPE_MAP;
/*     */   
/*     */ 
/*     */   private final int code;
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 240 */     HashMap<Integer, HornetQExceptionType> map = new HashMap();
/* 241 */     for (HornetQExceptionType type : EnumSet.allOf(HornetQExceptionType.class))
/*     */     {
/* 243 */       map.put(Integer.valueOf(type.getCode()), type);
/*     */     }
/* 245 */     TYPE_MAP = Collections.unmodifiableMap(map);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private HornetQExceptionType(int code)
/*     */   {
/* 252 */     this.code = code;
/*     */   }
/*     */   
/*     */   public int getCode()
/*     */   {
/* 257 */     return this.code;
/*     */   }
/*     */   
/*     */   public HornetQException createException(String msg)
/*     */   {
/* 262 */     return new HornetQException(msg + ", code:" + this);
/*     */   }
/*     */   
/*     */   public static HornetQException createException(int code, String msg)
/*     */   {
/* 267 */     return getType(code).createException(msg);
/*     */   }
/*     */   
/*     */   public static HornetQExceptionType getType(int code)
/*     */   {
/* 272 */     HornetQExceptionType type = (HornetQExceptionType)TYPE_MAP.get(Integer.valueOf(code));
/* 273 */     if (type != null)
/* 274 */       return type;
/* 275 */     return GENERIC_EXCEPTION;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQExceptionType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */