/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HornetQException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -4802014152804997417L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private final HornetQExceptionType type;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQException()
/*    */   {
/* 29 */     this.type = HornetQExceptionType.GENERIC_EXCEPTION;
/*    */   }
/*    */   
/*    */   public HornetQException(String msg)
/*    */   {
/* 34 */     super(msg);
/* 35 */     this.type = HornetQExceptionType.GENERIC_EXCEPTION;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQException(int code, String msg)
/*    */   {
/* 43 */     super(msg);
/*    */     
/* 45 */     this.type = HornetQExceptionType.getType(code);
/*    */   }
/*    */   
/*    */   public HornetQException(HornetQExceptionType type, String msg)
/*    */   {
/* 50 */     super(msg);
/*    */     
/* 52 */     this.type = type;
/*    */   }
/*    */   
/*    */   public HornetQException(HornetQExceptionType type)
/*    */   {
/* 57 */     this.type = type;
/*    */   }
/*    */   
/*    */   public HornetQException(HornetQExceptionType type, String message, Throwable t)
/*    */   {
/* 62 */     super(message, t);
/* 63 */     this.type = type;
/*    */   }
/*    */   
/*    */   public HornetQExceptionType getType()
/*    */   {
/* 68 */     return this.type;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 74 */     return "HornetQException[errorType=" + this.type + " message=" + getMessage() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */