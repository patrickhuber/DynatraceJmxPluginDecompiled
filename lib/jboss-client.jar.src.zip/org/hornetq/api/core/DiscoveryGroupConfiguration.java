/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import org.hornetq.utils.UUIDGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DiscoveryGroupConfiguration
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8657206421727863400L;
/*     */   private String name;
/*     */   private long refreshTimeout;
/*     */   private long discoveryInitialWaitTimeout;
/*     */   private transient String localBindAddress;
/*     */   private transient int localBindPort;
/*     */   private String groupAddress;
/*     */   private int groupPort;
/*     */   private transient BroadcastEndpointFactoryConfiguration endpointFactoryConfiguration;
/*     */   
/*     */   public DiscoveryGroupConfiguration(String name, long refreshTimeout, long discoveryInitialWaitTimeout, BroadcastEndpointFactoryConfiguration endpointFactoryConfiguration)
/*     */   {
/*  76 */     this.name = name;
/*  77 */     this.refreshTimeout = refreshTimeout;
/*  78 */     this.discoveryInitialWaitTimeout = discoveryInitialWaitTimeout;
/*  79 */     this.endpointFactoryConfiguration = endpointFactoryConfiguration;
/*  80 */     if ((endpointFactoryConfiguration instanceof DiscoveryGroupConfigurationCompatibilityHelper))
/*     */     {
/*  82 */       DiscoveryGroupConfigurationCompatibilityHelper dgcch = (DiscoveryGroupConfigurationCompatibilityHelper)endpointFactoryConfiguration;
/*  83 */       this.localBindAddress = dgcch.getLocalBindAddress();
/*  84 */       this.localBindPort = dgcch.getLocalBindPort();
/*  85 */       this.groupAddress = dgcch.getGroupAddress();
/*  86 */       this.groupPort = dgcch.getGroupPort();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public DiscoveryGroupConfiguration(long refreshTimeout, long discoveryInitialWaitTimeout, BroadcastEndpointFactoryConfiguration endpointFactoryConfiguration)
/*     */   {
/*  94 */     this(UUIDGenerator.getInstance().generateStringUUID(), refreshTimeout, discoveryInitialWaitTimeout, endpointFactoryConfiguration);
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  99 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getRefreshTimeout()
/*     */   {
/* 104 */     return this.refreshTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 112 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRefreshTimeout(long refreshTimeout)
/*     */   {
/* 120 */     this.refreshTimeout = refreshTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getDiscoveryInitialWaitTimeout()
/*     */   {
/* 128 */     return this.discoveryInitialWaitTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDiscoveryInitialWaitTimeout(long discoveryInitialWaitTimeout)
/*     */   {
/* 136 */     this.discoveryInitialWaitTimeout = discoveryInitialWaitTimeout;
/*     */   }
/*     */   
/*     */   public BroadcastEndpointFactoryConfiguration getBroadcastEndpointFactoryConfiguration()
/*     */   {
/* 141 */     return this.endpointFactoryConfiguration;
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException
/*     */   {
/* 146 */     out.defaultWriteObject();
/* 147 */     if (this.groupPort < 0)
/*     */     {
/* 149 */       out.writeObject(this.endpointFactoryConfiguration);
/*     */     }
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws ClassNotFoundException, IOException
/*     */   {
/* 155 */     in.defaultReadObject();
/* 156 */     if (this.groupPort < 0)
/*     */     {
/* 158 */       this.endpointFactoryConfiguration = ((BroadcastEndpointFactoryConfiguration)in.readObject());
/*     */     }
/*     */     else
/*     */     {
/* 162 */       this.endpointFactoryConfiguration = new UDPBroadcastGroupConfiguration(this.groupAddress, this.groupPort, this.localBindAddress, this.localBindPort);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 169 */     if (this == o) return true;
/* 170 */     if ((o == null) || (getClass() != o.getClass())) { return false;
/*     */     }
/* 172 */     DiscoveryGroupConfiguration that = (DiscoveryGroupConfiguration)o;
/*     */     
/* 174 */     if (this.discoveryInitialWaitTimeout != that.discoveryInitialWaitTimeout) return false;
/* 175 */     if (this.refreshTimeout != that.refreshTimeout) return false;
/* 176 */     if (this.name != null ? !this.name.equals(that.name) : that.name != null) { return false;
/*     */     }
/* 178 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 184 */     int result = this.name != null ? this.name.hashCode() : 0;
/* 185 */     result = 31 * result + (int)(this.refreshTimeout ^ this.refreshTimeout >>> 32);
/* 186 */     result = 31 * result + (int)(this.discoveryInitialWaitTimeout ^ this.discoveryInitialWaitTimeout >>> 32);
/* 187 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 193 */     return "DiscoveryGroupConfiguration{name='" + this.name + '\'' + ", refreshTimeout=" + this.refreshTimeout + ", discoveryInitialWaitTimeout=" + this.discoveryInitialWaitTimeout + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\DiscoveryGroupConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */