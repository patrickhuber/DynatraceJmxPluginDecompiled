/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.MulticastSocket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UDPBroadcastGroupConfiguration
/*     */   implements BroadcastEndpointFactoryConfiguration, DiscoveryGroupConfigurationCompatibilityHelper
/*     */ {
/*     */   private static final long serialVersionUID = 1052413739064253955L;
/*     */   private final transient String localBindAddress;
/*     */   private final transient int localBindPort;
/*     */   private final String groupAddress;
/*     */   private final int groupPort;
/*     */   
/*     */   public UDPBroadcastGroupConfiguration(String groupAddress, int groupPort, String localBindAddress, int localBindPort)
/*     */   {
/*  54 */     this.groupAddress = groupAddress;
/*  55 */     this.groupPort = groupPort;
/*  56 */     this.localBindAddress = localBindAddress;
/*  57 */     this.localBindPort = localBindPort;
/*     */   }
/*     */   
/*     */   public BroadcastEndpointFactory createBroadcastEndpointFactory()
/*     */   {
/*  62 */     new BroadcastEndpointFactory()
/*     */     {
/*     */       public BroadcastEndpoint createBroadcastEndpoint()
/*     */         throws Exception
/*     */       {
/*  67 */         return new UDPBroadcastGroupConfiguration.UDPBroadcastEndpoint(UDPBroadcastGroupConfiguration.this.groupAddress != null ? InetAddress.getByName(UDPBroadcastGroupConfiguration.this.groupAddress) : null, UDPBroadcastGroupConfiguration.this.groupPort, UDPBroadcastGroupConfiguration.this.localBindAddress != null ? InetAddress.getByName(UDPBroadcastGroupConfiguration.this.localBindAddress) : null, UDPBroadcastGroupConfiguration.this.localBindPort);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getGroupAddress()
/*     */   {
/*  77 */     return this.groupAddress;
/*     */   }
/*     */   
/*     */   public int getGroupPort()
/*     */   {
/*  82 */     return this.groupPort;
/*     */   }
/*     */   
/*     */   public int getLocalBindPort()
/*     */   {
/*  87 */     return this.localBindPort;
/*     */   }
/*     */   
/*     */   public String getLocalBindAddress()
/*     */   {
/*  92 */     return this.localBindAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class UDPBroadcastEndpoint
/*     */     implements BroadcastEndpoint
/*     */   {
/*     */     private static final int SOCKET_TIMEOUT = 500;
/*     */     
/*     */ 
/*     */     private final InetAddress localAddress;
/*     */     
/*     */ 
/*     */     private final int localBindPort;
/*     */     
/*     */ 
/*     */     private final InetAddress groupAddress;
/*     */     
/*     */ 
/*     */     private final int groupPort;
/*     */     
/*     */ 
/*     */     private DatagramSocket broadcastingSocket;
/*     */     
/*     */ 
/*     */     private MulticastSocket receivingSocket;
/*     */     
/*     */     private volatile boolean open;
/*     */     
/*     */ 
/*     */     public UDPBroadcastEndpoint(InetAddress groupAddress, int groupPort, InetAddress localBindAddress, int localBindPort)
/*     */       throws UnknownHostException
/*     */     {
/* 126 */       this.groupAddress = groupAddress;
/* 127 */       this.groupPort = groupPort;
/* 128 */       this.localAddress = localBindAddress;
/* 129 */       this.localBindPort = localBindPort;
/*     */     }
/*     */     
/*     */     public void broadcast(byte[] data)
/*     */       throws Exception
/*     */     {
/* 135 */       DatagramPacket packet = new DatagramPacket(data, data.length, this.groupAddress, this.groupPort);
/* 136 */       this.broadcastingSocket.send(packet);
/*     */     }
/*     */     
/*     */     public byte[] receiveBroadcast() throws Exception
/*     */     {
/* 141 */       byte[] data = new byte[65535];
/* 142 */       DatagramPacket packet = new DatagramPacket(data, data.length);
/*     */       for (;;) {
/* 144 */         if (this.open)
/*     */         {
/*     */           try
/*     */           {
/* 148 */             this.receivingSocket.receive(packet);
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           catch (InterruptedIOException e) {}catch (IOException e)
/*     */           {
/*     */ 
/*     */ 
/* 157 */             if (this.open)
/*     */             {
/* 159 */               HornetQClientLogger.LOGGER.warn(this + " getting exception when receiving broadcasting.", e);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 164 */       return data;
/*     */     }
/*     */     
/*     */ 
/*     */     public byte[] receiveBroadcast(long time, TimeUnit unit)
/*     */       throws Exception
/*     */     {
/* 171 */       return receiveBroadcast();
/*     */     }
/*     */     
/*     */     public void openBroadcaster() throws Exception
/*     */     {
/* 176 */       if (this.localBindPort != -1)
/*     */       {
/* 178 */         this.broadcastingSocket = new DatagramSocket(this.localBindPort, this.localAddress);
/*     */       }
/*     */       else
/*     */       {
/* 182 */         if (this.localAddress != null)
/*     */         {
/* 184 */           HornetQClientLogger.LOGGER.broadcastGroupBindError();
/*     */         }
/* 186 */         this.broadcastingSocket = new DatagramSocket();
/*     */       }
/*     */       
/* 189 */       this.open = true;
/*     */     }
/*     */     
/*     */     public void openClient()
/*     */       throws Exception
/*     */     {
/* 195 */       if ((checkForLinux()) || (checkForSolaris()) || (checkForHp()))
/*     */       {
/*     */         try
/*     */         {
/* 199 */           this.receivingSocket = new MulticastSocket(new InetSocketAddress(this.groupAddress, this.groupPort));
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 203 */           HornetQClientLogger.LOGGER.ioDiscoveryError(this.groupAddress.getHostAddress(), (this.groupAddress instanceof Inet4Address) ? "IPv4" : "IPv6");
/*     */           
/* 205 */           this.receivingSocket = new MulticastSocket(this.groupPort);
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 210 */         this.receivingSocket = new MulticastSocket(this.groupPort);
/*     */       }
/*     */       
/* 213 */       if (this.localAddress != null)
/*     */       {
/* 215 */         this.receivingSocket.setInterface(this.localAddress);
/*     */       }
/*     */       
/* 218 */       this.receivingSocket.joinGroup(this.groupAddress);
/*     */       
/* 220 */       this.receivingSocket.setSoTimeout(500);
/*     */       
/* 222 */       this.open = true;
/*     */     }
/*     */     
/*     */     public void close(boolean isBroadcast)
/*     */       throws Exception
/*     */     {
/* 228 */       this.open = false;
/*     */       
/* 230 */       if (this.broadcastingSocket != null)
/*     */       {
/* 232 */         this.broadcastingSocket.close();
/*     */       }
/*     */       
/* 235 */       if (this.receivingSocket != null)
/*     */       {
/* 237 */         this.receivingSocket.close();
/*     */       }
/*     */     }
/*     */     
/*     */     private static boolean checkForLinux()
/*     */     {
/* 243 */       return checkForPresence("os.name", "linux");
/*     */     }
/*     */     
/*     */     private static boolean checkForHp()
/*     */     {
/* 248 */       return checkForPresence("os.name", "hp");
/*     */     }
/*     */     
/*     */     private static boolean checkForSolaris()
/*     */     {
/* 253 */       return checkForPresence("os.name", "sun");
/*     */     }
/*     */     
/*     */     private static boolean checkForPresence(String key, String value)
/*     */     {
/*     */       try
/*     */       {
/* 260 */         String tmp = System.getProperty(key);
/* 261 */         return (tmp != null) && (tmp.trim().toLowerCase().startsWith(value));
/*     */       }
/*     */       catch (Throwable t) {}
/*     */       
/* 265 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 274 */     int prime = 31;
/* 275 */     int result = 1;
/* 276 */     result = 31 * result + (this.groupAddress == null ? 0 : this.groupAddress.hashCode());
/* 277 */     result = 31 * result + this.groupPort;
/* 278 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 284 */     if (this == obj)
/* 285 */       return true;
/* 286 */     if (obj == null)
/* 287 */       return false;
/* 288 */     if (getClass() != obj.getClass())
/* 289 */       return false;
/* 290 */     UDPBroadcastGroupConfiguration other = (UDPBroadcastGroupConfiguration)obj;
/* 291 */     if (this.groupAddress == null)
/*     */     {
/* 293 */       if (other.groupAddress != null) {
/* 294 */         return false;
/*     */       }
/* 296 */     } else if (!this.groupAddress.equals(other.groupAddress))
/* 297 */       return false;
/* 298 */     if (this.groupPort != other.groupPort)
/* 299 */       return false;
/* 300 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\UDPBroadcastGroupConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */