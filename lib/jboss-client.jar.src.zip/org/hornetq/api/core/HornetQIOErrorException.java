/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQIOErrorException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 797277117077787396L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQIOErrorException()
/*    */   {
/* 36 */     super(HornetQExceptionType.IO_ERROR);
/*    */   }
/*    */   
/*    */   public HornetQIOErrorException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.IO_ERROR, msg);
/*    */   }
/*    */   
/*    */   public HornetQIOErrorException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(HornetQExceptionType.IO_ERROR, msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQIOErrorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */