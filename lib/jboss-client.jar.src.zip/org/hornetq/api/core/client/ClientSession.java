package org.hornetq.api.core.client;

import java.util.List;
import javax.transaction.xa.XAResource;
import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.SimpleString;

public abstract interface ClientSession
  extends XAResource
{
  public abstract void start()
    throws HornetQException;
  
  public abstract void stop()
    throws HornetQException;
  
  public abstract void close()
    throws HornetQException;
  
  public abstract boolean isClosed();
  
  public abstract void addFailureListener(SessionFailureListener paramSessionFailureListener);
  
  public abstract boolean removeFailureListener(SessionFailureListener paramSessionFailureListener);
  
  public abstract void addFailoverListener(FailoverEventListener paramFailoverEventListener);
  
  public abstract boolean removeFailoverListener(FailoverEventListener paramFailoverEventListener);
  
  public abstract int getVersion();
  
  public abstract void createQueue(SimpleString paramSimpleString1, SimpleString paramSimpleString2, boolean paramBoolean)
    throws HornetQException;
  
  public abstract void createQueue(String paramString1, String paramString2, boolean paramBoolean)
    throws HornetQException;
  
  public abstract void createQueue(String paramString1, String paramString2)
    throws HornetQException;
  
  public abstract void createQueue(SimpleString paramSimpleString1, SimpleString paramSimpleString2)
    throws HornetQException;
  
  public abstract void createQueue(SimpleString paramSimpleString1, SimpleString paramSimpleString2, SimpleString paramSimpleString3, boolean paramBoolean)
    throws HornetQException;
  
  public abstract void createQueue(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws HornetQException;
  
  public abstract void createTemporaryQueue(SimpleString paramSimpleString1, SimpleString paramSimpleString2)
    throws HornetQException;
  
  public abstract void createTemporaryQueue(String paramString1, String paramString2)
    throws HornetQException;
  
  public abstract void createTemporaryQueue(SimpleString paramSimpleString1, SimpleString paramSimpleString2, SimpleString paramSimpleString3)
    throws HornetQException;
  
  public abstract void createTemporaryQueue(String paramString1, String paramString2, String paramString3)
    throws HornetQException;
  
  public abstract void deleteQueue(SimpleString paramSimpleString)
    throws HornetQException;
  
  public abstract void deleteQueue(String paramString)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(SimpleString paramSimpleString)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(String paramString)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(SimpleString paramSimpleString1, SimpleString paramSimpleString2)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(String paramString1, String paramString2)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(SimpleString paramSimpleString, boolean paramBoolean)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(String paramString, boolean paramBoolean)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(String paramString1, String paramString2, boolean paramBoolean)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(SimpleString paramSimpleString1, SimpleString paramSimpleString2, boolean paramBoolean)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(SimpleString paramSimpleString1, SimpleString paramSimpleString2, int paramInt1, int paramInt2, boolean paramBoolean)
    throws HornetQException;
  
  public abstract ClientConsumer createConsumer(String paramString1, String paramString2, int paramInt1, int paramInt2, boolean paramBoolean)
    throws HornetQException;
  
  public abstract ClientProducer createProducer()
    throws HornetQException;
  
  public abstract ClientProducer createProducer(SimpleString paramSimpleString)
    throws HornetQException;
  
  public abstract ClientProducer createProducer(String paramString)
    throws HornetQException;
  
  public abstract ClientProducer createProducer(SimpleString paramSimpleString, int paramInt)
    throws HornetQException;
  
  public abstract ClientMessage createMessage(boolean paramBoolean);
  
  public abstract ClientMessage createMessage(byte paramByte, boolean paramBoolean);
  
  public abstract ClientMessage createMessage(byte paramByte1, boolean paramBoolean, long paramLong1, long paramLong2, byte paramByte2);
  
  public abstract QueueQuery queueQuery(SimpleString paramSimpleString)
    throws HornetQException;
  
  public abstract BindingQuery bindingQuery(SimpleString paramSimpleString)
    throws HornetQException;
  
  public abstract XAResource getXAResource();
  
  public abstract boolean isXA();
  
  public abstract void commit()
    throws HornetQException;
  
  public abstract void rollback()
    throws HornetQException;
  
  public abstract void rollback(boolean paramBoolean)
    throws HornetQException;
  
  public abstract boolean isRollbackOnly();
  
  public abstract boolean isAutoCommitSends();
  
  public abstract boolean isAutoCommitAcks();
  
  public abstract boolean isBlockOnAcknowledge();
  
  public abstract void setSendAcknowledgementHandler(SendAcknowledgementHandler paramSendAcknowledgementHandler);
  
  public abstract void addMetaData(String paramString1, String paramString2)
    throws HornetQException;
  
  public abstract void addUniqueMetaData(String paramString1, String paramString2)
    throws HornetQException;
  
  public static abstract interface QueueQuery
  {
    public abstract boolean isExists();
    
    public abstract boolean isDurable();
    
    public abstract int getConsumerCount();
    
    public abstract long getMessageCount();
    
    public abstract SimpleString getFilterString();
    
    public abstract SimpleString getAddress();
  }
  
  public static abstract interface BindingQuery
  {
    public abstract boolean isExists();
    
    public abstract List<SimpleString> getQueueNames();
  }
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ClientSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */