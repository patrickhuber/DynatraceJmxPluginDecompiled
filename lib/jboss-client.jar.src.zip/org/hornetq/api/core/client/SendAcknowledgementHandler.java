package org.hornetq.api.core.client;

import org.hornetq.api.core.Message;

public abstract interface SendAcknowledgementHandler
{
  public abstract void sendAcknowledged(Message paramMessage);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\SendAcknowledgementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */