package org.hornetq.api.core.client;

import org.hornetq.api.core.HornetQException;
import org.hornetq.core.protocol.core.CoreRemotingConnection;

public abstract interface ClientSessionFactory
{
  public abstract ClientSession createXASession()
    throws HornetQException;
  
  public abstract ClientSession createTransactedSession()
    throws HornetQException;
  
  public abstract ClientSession createSession()
    throws HornetQException;
  
  public abstract ClientSession createSession(boolean paramBoolean1, boolean paramBoolean2)
    throws HornetQException;
  
  public abstract ClientSession createSession(boolean paramBoolean1, boolean paramBoolean2, int paramInt)
    throws HornetQException;
  
  public abstract ClientSession createSession(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
    throws HornetQException;
  
  public abstract ClientSession createSession(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
    throws HornetQException;
  
  public abstract ClientSession createSession(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, int paramInt)
    throws HornetQException;
  
  public abstract void close();
  
  public abstract boolean isClosed();
  
  public abstract void addFailoverListener(FailoverEventListener paramFailoverEventListener);
  
  public abstract boolean removeFailoverListener(FailoverEventListener paramFailoverEventListener);
  
  public abstract void cleanup();
  
  public abstract ServerLocator getServerLocator();
  
  public abstract CoreRemotingConnection getConnection();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ClientSessionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */