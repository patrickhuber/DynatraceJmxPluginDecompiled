package org.hornetq.api.core.client;

import java.io.Serializable;
import org.hornetq.api.core.TransportConfiguration;
import org.hornetq.spi.core.protocol.RemotingConnection;

public abstract interface TopologyMember
  extends Serializable
{
  public abstract String getBackupGroupName();
  
  public abstract TransportConfiguration getLive();
  
  public abstract TransportConfiguration getBackup();
  
  public abstract String getNodeId();
  
  public abstract long getUniqueEventID();
  
  public abstract boolean isMember(RemotingConnection paramRemotingConnection);
  
  public abstract boolean isMember(TransportConfiguration paramTransportConfiguration);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\TopologyMember.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */