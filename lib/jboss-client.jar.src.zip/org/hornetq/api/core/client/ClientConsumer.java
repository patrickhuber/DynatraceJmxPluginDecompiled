package org.hornetq.api.core.client;

import org.hornetq.api.core.HornetQException;

public abstract interface ClientConsumer
{
  public abstract ClientMessage receive()
    throws HornetQException;
  
  public abstract ClientMessage receive(long paramLong)
    throws HornetQException;
  
  public abstract ClientMessage receiveImmediate()
    throws HornetQException;
  
  public abstract MessageHandler getMessageHandler()
    throws HornetQException;
  
  public abstract void setMessageHandler(MessageHandler paramMessageHandler)
    throws HornetQException;
  
  public abstract void close()
    throws HornetQException;
  
  public abstract boolean isClosed();
  
  public abstract Exception getLastException();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ClientConsumer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */