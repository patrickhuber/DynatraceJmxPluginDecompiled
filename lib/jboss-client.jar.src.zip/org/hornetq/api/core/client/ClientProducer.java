package org.hornetq.api.core.client;

import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.Message;
import org.hornetq.api.core.SimpleString;

public abstract interface ClientProducer
{
  public abstract SimpleString getAddress();
  
  public abstract void send(Message paramMessage)
    throws HornetQException;
  
  public abstract void send(SimpleString paramSimpleString, Message paramMessage)
    throws HornetQException;
  
  public abstract void send(String paramString, Message paramMessage)
    throws HornetQException;
  
  public abstract void close()
    throws HornetQException;
  
  public abstract boolean isClosed();
  
  public abstract boolean isBlockOnDurableSend();
  
  public abstract boolean isBlockOnNonDurableSend();
  
  public abstract int getMaxRate();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ClientProducer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */