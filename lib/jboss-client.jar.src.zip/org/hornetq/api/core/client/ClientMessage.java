package org.hornetq.api.core.client;

import java.io.InputStream;
import java.io.OutputStream;
import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.Message;

public abstract interface ClientMessage
  extends Message
{
  public abstract int getDeliveryCount();
  
  public abstract void setDeliveryCount(int paramInt);
  
  public abstract void acknowledge()
    throws HornetQException;
  
  public abstract void individualAcknowledge()
    throws HornetQException;
  
  public abstract void checkCompletion()
    throws HornetQException;
  
  public abstract int getBodySize();
  
  public abstract void setOutputStream(OutputStream paramOutputStream)
    throws HornetQException;
  
  public abstract void saveToOutputStream(OutputStream paramOutputStream)
    throws HornetQException;
  
  public abstract boolean waitOutputStreamCompletion(long paramLong)
    throws HornetQException;
  
  public abstract void setBodyInputStream(InputStream paramInputStream);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ClientMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */