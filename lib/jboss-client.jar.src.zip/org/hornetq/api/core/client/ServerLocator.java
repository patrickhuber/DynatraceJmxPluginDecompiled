package org.hornetq.api.core.client;

import org.hornetq.api.core.DiscoveryGroupConfiguration;
import org.hornetq.api.core.Interceptor;
import org.hornetq.api.core.TransportConfiguration;
import org.hornetq.core.client.impl.Topology;

public abstract interface ServerLocator
{
  public abstract boolean isClosed();
  
  public abstract void disableFinalizeCheck();
  
  public abstract ClientSessionFactory createSessionFactory()
    throws Exception;
  
  public abstract ClientSessionFactory createSessionFactory(String paramString)
    throws Exception;
  
  public abstract ClientSessionFactory createSessionFactory(TransportConfiguration paramTransportConfiguration)
    throws Exception;
  
  public abstract ClientSessionFactory createSessionFactory(TransportConfiguration paramTransportConfiguration, int paramInt, boolean paramBoolean)
    throws Exception;
  
  public abstract long getClientFailureCheckPeriod();
  
  public abstract void setClientFailureCheckPeriod(long paramLong);
  
  public abstract boolean isCacheLargeMessagesClient();
  
  public abstract void setCacheLargeMessagesClient(boolean paramBoolean);
  
  public abstract long getConnectionTTL();
  
  public abstract void setConnectionTTL(long paramLong);
  
  public abstract long getCallTimeout();
  
  public abstract void setCallTimeout(long paramLong);
  
  public abstract long getCallFailoverTimeout();
  
  public abstract void setCallFailoverTimeout(long paramLong);
  
  public abstract int getMinLargeMessageSize();
  
  public abstract void setMinLargeMessageSize(int paramInt);
  
  public abstract int getConsumerWindowSize();
  
  public abstract void setConsumerWindowSize(int paramInt);
  
  public abstract int getConsumerMaxRate();
  
  public abstract void setConsumerMaxRate(int paramInt);
  
  public abstract int getConfirmationWindowSize();
  
  public abstract void setConfirmationWindowSize(int paramInt);
  
  public abstract int getProducerWindowSize();
  
  public abstract void setProducerWindowSize(int paramInt);
  
  public abstract int getProducerMaxRate();
  
  public abstract void setProducerMaxRate(int paramInt);
  
  public abstract boolean isBlockOnAcknowledge();
  
  public abstract void setBlockOnAcknowledge(boolean paramBoolean);
  
  public abstract boolean isBlockOnDurableSend();
  
  public abstract void setBlockOnDurableSend(boolean paramBoolean);
  
  public abstract boolean isBlockOnNonDurableSend();
  
  public abstract void setBlockOnNonDurableSend(boolean paramBoolean);
  
  public abstract boolean isAutoGroup();
  
  public abstract void setAutoGroup(boolean paramBoolean);
  
  public abstract String getGroupID();
  
  public abstract void setGroupID(String paramString);
  
  public abstract boolean isPreAcknowledge();
  
  public abstract void setPreAcknowledge(boolean paramBoolean);
  
  public abstract int getAckBatchSize();
  
  public abstract void setAckBatchSize(int paramInt);
  
  public abstract TransportConfiguration[] getStaticTransportConfigurations();
  
  public abstract DiscoveryGroupConfiguration getDiscoveryGroupConfiguration();
  
  public abstract boolean isUseGlobalPools();
  
  public abstract void setUseGlobalPools(boolean paramBoolean);
  
  public abstract int getScheduledThreadPoolMaxSize();
  
  public abstract void setScheduledThreadPoolMaxSize(int paramInt);
  
  public abstract int getThreadPoolMaxSize();
  
  public abstract void setThreadPoolMaxSize(int paramInt);
  
  public abstract long getRetryInterval();
  
  public abstract void setRetryInterval(long paramLong);
  
  public abstract double getRetryIntervalMultiplier();
  
  public abstract void setRetryIntervalMultiplier(double paramDouble);
  
  public abstract long getMaxRetryInterval();
  
  public abstract void setMaxRetryInterval(long paramLong);
  
  public abstract int getReconnectAttempts();
  
  public abstract void setReconnectAttempts(int paramInt);
  
  public abstract void setInitialConnectAttempts(int paramInt);
  
  public abstract int getInitialConnectAttempts();
  
  public abstract boolean isFailoverOnInitialConnection();
  
  public abstract void setFailoverOnInitialConnection(boolean paramBoolean);
  
  public abstract String getConnectionLoadBalancingPolicyClassName();
  
  public abstract void setConnectionLoadBalancingPolicyClassName(String paramString);
  
  public abstract int getInitialMessagePacketSize();
  
  public abstract void setInitialMessagePacketSize(int paramInt);
  
  @Deprecated
  public abstract void addInterceptor(Interceptor paramInterceptor);
  
  public abstract void addIncomingInterceptor(Interceptor paramInterceptor);
  
  public abstract void addOutgoingInterceptor(Interceptor paramInterceptor);
  
  @Deprecated
  public abstract boolean removeInterceptor(Interceptor paramInterceptor);
  
  public abstract boolean removeIncomingInterceptor(Interceptor paramInterceptor);
  
  public abstract boolean removeOutgoingInterceptor(Interceptor paramInterceptor);
  
  public abstract void close();
  
  public abstract Topology getTopology();
  
  public abstract boolean isHA();
  
  public abstract boolean isCompressLargeMessage();
  
  public abstract void setCompressLargeMessage(boolean paramBoolean);
  
  public abstract void addClusterTopologyListener(ClusterTopologyListener paramClusterTopologyListener);
  
  public abstract void removeClusterTopologyListener(ClusterTopologyListener paramClusterTopologyListener);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ServerLocator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */