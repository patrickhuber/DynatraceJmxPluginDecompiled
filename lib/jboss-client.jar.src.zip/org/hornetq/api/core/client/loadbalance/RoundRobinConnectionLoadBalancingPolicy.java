/*    */ package org.hornetq.api.core.client.loadbalance;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RoundRobinConnectionLoadBalancingPolicy
/*    */   implements ConnectionLoadBalancingPolicy, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 7511196010141439559L;
/* 37 */   private final org.hornetq.utils.Random random = new org.hornetq.utils.Random();
/*    */   
/* 39 */   private boolean first = true;
/*    */   
/*    */   private int pos;
/*    */   
/*    */   public int select(int max)
/*    */   {
/* 45 */     if (this.first)
/*    */     {
/*    */ 
/* 48 */       this.pos = this.random.getRandom().nextInt(max);
/*    */       
/* 50 */       this.first = false;
/*    */     }
/*    */     else
/*    */     {
/* 54 */       this.pos += 1;
/*    */       
/* 56 */       if (this.pos >= max)
/*    */       {
/* 58 */         this.pos = 0;
/*    */       }
/*    */     }
/*    */     
/* 62 */     return this.pos;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\loadbalance\RoundRobinConnectionLoadBalancingPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */