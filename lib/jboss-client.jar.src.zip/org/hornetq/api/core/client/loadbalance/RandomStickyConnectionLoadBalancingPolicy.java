/*    */ package org.hornetq.api.core.client.loadbalance;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RandomStickyConnectionLoadBalancingPolicy
/*    */   implements ConnectionLoadBalancingPolicy
/*    */ {
/* 26 */   private final org.hornetq.utils.Random random = new org.hornetq.utils.Random();
/*    */   
/* 28 */   private int pos = -1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int select(int max)
/*    */   {
/* 35 */     if (this.pos == -1)
/*    */     {
/* 37 */       this.pos = this.random.getRandom().nextInt(max);
/*    */     }
/*    */     
/* 40 */     return this.pos;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\loadbalance\RandomStickyConnectionLoadBalancingPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */