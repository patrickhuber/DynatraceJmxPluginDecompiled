/*     */ package org.hornetq.api.core.client;
/*     */ 
/*     */ import java.util.UUID;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.impl.ClientMessageImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClientRequestor
/*     */ {
/*     */   private final ClientSession queueSession;
/*     */   private final ClientProducer requestProducer;
/*     */   private final ClientConsumer replyConsumer;
/*     */   private final SimpleString replyQueue;
/*     */   
/*     */   public ClientRequestor(ClientSession session, SimpleString requestAddress)
/*     */     throws Exception
/*     */   {
/*  53 */     this.queueSession = session;
/*     */     
/*  55 */     this.requestProducer = this.queueSession.createProducer(requestAddress);
/*  56 */     this.replyQueue = new SimpleString(requestAddress + "." + UUID.randomUUID().toString());
/*  57 */     this.queueSession.createTemporaryQueue(this.replyQueue, this.replyQueue);
/*  58 */     this.replyConsumer = this.queueSession.createConsumer(this.replyQueue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ClientRequestor(ClientSession session, String requestAddress)
/*     */     throws Exception
/*     */   {
/*  66 */     this(session, SimpleString.toSimpleString(requestAddress));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientMessage request(ClientMessage request)
/*     */     throws Exception
/*     */   {
/*  79 */     return request(request, 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientMessage request(ClientMessage request, long timeout)
/*     */     throws Exception
/*     */   {
/*  93 */     request.putStringProperty(ClientMessageImpl.REPLYTO_HEADER_NAME, this.replyQueue);
/*  94 */     this.requestProducer.send(request);
/*  95 */     return this.replyConsumer.receive(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws Exception
/*     */   {
/* 105 */     this.replyConsumer.close();
/* 106 */     this.requestProducer.close();
/* 107 */     this.queueSession.deleteQueue(this.replyQueue);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\client\ClientRequestor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */