package org.hornetq.api.core;

public abstract interface DiscoveryGroupConfigurationCompatibilityHelper
{
  public abstract String getLocalBindAddress();
  
  public abstract int getLocalBindPort();
  
  public abstract String getGroupAddress();
  
  public abstract int getGroupPort();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\DiscoveryGroupConfigurationCompatibilityHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */