package org.hornetq.api.core;

import java.util.concurrent.TimeUnit;

public abstract interface BroadcastEndpoint
{
  public abstract void openClient()
    throws Exception;
  
  public abstract void openBroadcaster()
    throws Exception;
  
  public abstract void close(boolean paramBoolean)
    throws Exception;
  
  public abstract void broadcast(byte[] paramArrayOfByte)
    throws Exception;
  
  public abstract byte[] receiveBroadcast()
    throws Exception;
  
  public abstract byte[] receiveBroadcast(long paramLong, TimeUnit paramTimeUnit)
    throws Exception;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\BroadcastEndpoint.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */