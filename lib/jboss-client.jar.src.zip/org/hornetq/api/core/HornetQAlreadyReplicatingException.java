/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQAlreadyReplicatingException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -7352538521961996152L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQAlreadyReplicatingException()
/*    */   {
/* 36 */     super(HornetQExceptionType.ALREADY_REPLICATING);
/*    */   }
/*    */   
/*    */   public HornetQAlreadyReplicatingException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.ALREADY_REPLICATING, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQAlreadyReplicatingException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */