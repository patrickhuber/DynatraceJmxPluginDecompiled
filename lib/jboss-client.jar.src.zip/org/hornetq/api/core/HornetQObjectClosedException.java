/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQObjectClosedException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 809024052184914812L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQObjectClosedException()
/*    */   {
/* 37 */     super(HornetQExceptionType.OBJECT_CLOSED);
/*    */   }
/*    */   
/*    */   public HornetQObjectClosedException(String msg)
/*    */   {
/* 42 */     super(HornetQExceptionType.OBJECT_CLOSED, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQObjectClosedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */