/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQInternalErrorException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -5987814047521530695L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQInternalErrorException()
/*    */   {
/* 36 */     super(HornetQExceptionType.INTERNAL_ERROR);
/*    */   }
/*    */   
/*    */   public HornetQInternalErrorException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.INTERNAL_ERROR, msg);
/*    */   }
/*    */   
/*    */   public HornetQInternalErrorException(String message, Exception e)
/*    */   {
/* 46 */     super(HornetQExceptionType.INTERNAL_ERROR, message, e);
/*    */   }
/*    */   
/*    */   public HornetQInternalErrorException(String message, Throwable t)
/*    */   {
/* 51 */     super(HornetQExceptionType.INTERNAL_ERROR, message, t);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQInternalErrorException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */