/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BroadcastGroupConfiguration
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2335634694112319124L;
/*     */   private String name;
/*     */   private long broadcastPeriod;
/*     */   private final BroadcastEndpointFactoryConfiguration endpointFactoryConfiguration;
/*     */   private List<String> connectorInfos;
/*     */   
/*     */   public BroadcastGroupConfiguration(String name, long broadcastPeriod, List<String> connectorInfos, BroadcastEndpointFactoryConfiguration endpointFactoryConfiguration)
/*     */   {
/*  45 */     this.name = name;
/*  46 */     this.broadcastPeriod = broadcastPeriod;
/*  47 */     this.connectorInfos = connectorInfos;
/*  48 */     this.endpointFactoryConfiguration = endpointFactoryConfiguration;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  53 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getBroadcastPeriod()
/*     */   {
/*  58 */     return this.broadcastPeriod;
/*     */   }
/*     */   
/*     */   public List<String> getConnectorInfos()
/*     */   {
/*  63 */     return this.connectorInfos;
/*     */   }
/*     */   
/*     */   public void setName(String name)
/*     */   {
/*  68 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setBroadcastPeriod(long broadcastPeriod)
/*     */   {
/*  73 */     this.broadcastPeriod = broadcastPeriod;
/*     */   }
/*     */   
/*     */   public void setConnectorInfos(List<String> connectorInfos)
/*     */   {
/*  78 */     this.connectorInfos = connectorInfos;
/*     */   }
/*     */   
/*     */   public BroadcastEndpointFactoryConfiguration getEndpointFactoryConfiguration()
/*     */   {
/*  83 */     return this.endpointFactoryConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  89 */     int prime = 31;
/*  90 */     int result = 1;
/*  91 */     result = 31 * result + (int)(this.broadcastPeriod ^ this.broadcastPeriod >>> 32);
/*  92 */     result = 31 * result + (this.connectorInfos == null ? 0 : this.connectorInfos.hashCode());
/*  93 */     result = 31 * result + (this.endpointFactoryConfiguration == null ? 0 : this.endpointFactoryConfiguration.hashCode());
/*  94 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/*  95 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 101 */     if (this == obj)
/* 102 */       return true;
/* 103 */     if (obj == null)
/* 104 */       return false;
/* 105 */     if (getClass() != obj.getClass())
/* 106 */       return false;
/* 107 */     BroadcastGroupConfiguration other = (BroadcastGroupConfiguration)obj;
/* 108 */     if (this.broadcastPeriod != other.broadcastPeriod)
/* 109 */       return false;
/* 110 */     if (this.connectorInfos == null)
/*     */     {
/* 112 */       if (other.connectorInfos != null) {
/* 113 */         return false;
/*     */       }
/* 115 */     } else if (!this.connectorInfos.equals(other.connectorInfos))
/* 116 */       return false;
/* 117 */     if (this.endpointFactoryConfiguration == null)
/*     */     {
/* 119 */       if (other.endpointFactoryConfiguration != null) {
/* 120 */         return false;
/*     */       }
/* 122 */     } else if (!this.endpointFactoryConfiguration.equals(other.endpointFactoryConfiguration))
/* 123 */       return false;
/* 124 */     if (this.name == null)
/*     */     {
/* 126 */       if (other.name != null) {
/* 127 */         return false;
/*     */       }
/* 129 */     } else if (!this.name.equals(other.name))
/* 130 */       return false;
/* 131 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\BroadcastGroupConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */