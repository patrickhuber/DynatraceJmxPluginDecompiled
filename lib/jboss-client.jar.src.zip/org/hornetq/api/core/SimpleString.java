/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleString
/*     */   implements CharSequence, Serializable, Comparable<SimpleString>
/*     */ {
/*     */   private static final long serialVersionUID = 4204223851422244307L;
/*     */   private final byte[] data;
/*     */   private transient int hash;
/*     */   private transient String str;
/*     */   
/*     */   public static SimpleString toSimpleString(String string)
/*     */   {
/*  55 */     if (string == null)
/*     */     {
/*  57 */       return null;
/*     */     }
/*  59 */     return new SimpleString(string);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString(String string)
/*     */   {
/*  72 */     int len = string.length();
/*     */     
/*  74 */     this.data = new byte[len << 1];
/*     */     
/*  76 */     int j = 0;
/*     */     
/*  78 */     for (int i = 0; i < len; i++)
/*     */     {
/*  80 */       char c = string.charAt(i);
/*     */       
/*  82 */       byte low = (byte)(c & 0xFF);
/*     */       
/*  84 */       this.data[(j++)] = low;
/*     */       
/*  86 */       byte high = (byte)(c >> '\b' & 0xFF);
/*     */       
/*  88 */       this.data[(j++)] = high;
/*     */     }
/*     */     
/*  91 */     this.str = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString(byte[] data)
/*     */   {
/* 101 */     this.data = data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/* 109 */     return this.data.length >> 1;
/*     */   }
/*     */   
/*     */   public char charAt(int pos)
/*     */   {
/* 114 */     if ((pos < 0) || (pos >= this.data.length >> 1))
/*     */     {
/* 116 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 118 */     pos <<= 1;
/*     */     
/* 120 */     return (char)(this.data[pos] & 0xFF | this.data[(pos + 1)] << 8 & 0xFF00);
/*     */   }
/*     */   
/*     */   public CharSequence subSequence(int start, int end)
/*     */   {
/* 125 */     int len = this.data.length >> 1;
/*     */     
/* 127 */     if ((end < start) || (start < 0) || (end > len))
/*     */     {
/* 129 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*     */ 
/* 133 */     int newlen = end - start << 1;
/* 134 */     byte[] bytes = new byte[newlen];
/*     */     
/* 136 */     System.arraycopy(this.data, start << 1, bytes, 0, newlen);
/*     */     
/* 138 */     return new SimpleString(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(SimpleString o)
/*     */   {
/* 146 */     return toString().compareTo(o.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 159 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean startsWith(SimpleString other)
/*     */   {
/* 170 */     byte[] otherdata = other.data;
/*     */     
/* 172 */     if (otherdata.length > this.data.length)
/*     */     {
/* 174 */       return false;
/*     */     }
/*     */     
/* 177 */     for (int i = 0; i < otherdata.length; i++)
/*     */     {
/* 179 */       if (this.data[i] != otherdata[i])
/*     */       {
/* 181 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 185 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 191 */     if (this.str == null)
/*     */     {
/* 193 */       int len = this.data.length >> 1;
/*     */       
/* 195 */       char[] chars = new char[len];
/*     */       
/* 197 */       int j = 0;
/*     */       
/* 199 */       for (int i = 0; i < len; i++)
/*     */       {
/* 201 */         int low = this.data[(j++)] & 0xFF;
/*     */         
/* 203 */         int high = this.data[(j++)] << 8 & 0xFF00;
/*     */         
/* 205 */         chars[i] = ((char)(low | high));
/*     */       }
/*     */       
/* 208 */       this.str = new String(chars);
/*     */     }
/*     */     
/* 211 */     return this.str;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 217 */     if (this == other)
/*     */     {
/* 219 */       return true;
/*     */     }
/*     */     
/* 222 */     if ((other instanceof SimpleString))
/*     */     {
/* 224 */       SimpleString s = (SimpleString)other;
/*     */       
/* 226 */       if (this.data.length != s.data.length)
/*     */       {
/* 228 */         return false;
/*     */       }
/*     */       
/* 231 */       for (int i = 0; i < this.data.length; i++)
/*     */       {
/* 233 */         if (this.data[i] != s.data[i])
/*     */         {
/* 235 */           return false;
/*     */         }
/*     */       }
/*     */       
/* 239 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 243 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 250 */     if (this.hash == 0)
/*     */     {
/* 252 */       int tmphash = 0;
/* 253 */       for (byte element : this.data)
/*     */       {
/* 255 */         tmphash = (tmphash << 5) - tmphash + element;
/*     */       }
/* 257 */       this.hash = tmphash;
/*     */     }
/*     */     
/* 260 */     return this.hash;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString[] split(char delim)
/*     */   {
/* 271 */     List<SimpleString> all = null;
/*     */     
/* 273 */     byte low = (byte)(delim & 0xFF);
/* 274 */     byte high = (byte)(delim >> '\b' & 0xFF);
/*     */     
/* 276 */     int lasPos = 0;
/* 277 */     for (int i = 0; i < this.data.length; i += 2)
/*     */     {
/* 279 */       if ((this.data[i] == low) && (this.data[(i + 1)] == high))
/*     */       {
/* 281 */         byte[] bytes = new byte[i - lasPos];
/* 282 */         System.arraycopy(this.data, lasPos, bytes, 0, bytes.length);
/* 283 */         lasPos = i + 2;
/*     */         
/*     */ 
/* 286 */         if (all == null)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 292 */           all = new ArrayList(2);
/*     */         }
/* 294 */         all.add(new SimpleString(bytes));
/*     */       }
/*     */     }
/*     */     
/* 298 */     if (all == null)
/*     */     {
/* 300 */       return new SimpleString[] { this };
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 305 */     byte[] bytes = new byte[this.data.length - lasPos];
/* 306 */     System.arraycopy(this.data, lasPos, bytes, 0, bytes.length);
/* 307 */     all.add(new SimpleString(bytes));
/*     */     
/*     */ 
/* 310 */     SimpleString[] parts = new SimpleString[all.size()];
/* 311 */     return (SimpleString[])all.toArray(parts);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(char c)
/*     */   {
/* 323 */     byte low = (byte)(c & 0xFF);
/* 324 */     byte high = (byte)(c >> '\b' & 0xFF);
/*     */     
/* 326 */     for (int i = 0; i < this.data.length; i += 2)
/*     */     {
/* 328 */       if ((this.data[i] == low) && (this.data[(i + 1)] == high))
/*     */       {
/* 330 */         return true;
/*     */       }
/*     */     }
/* 333 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString concat(String toAdd)
/*     */   {
/* 344 */     return concat(new SimpleString(toAdd));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString concat(SimpleString toAdd)
/*     */   {
/* 355 */     byte[] bytes = new byte[this.data.length + toAdd.getData().length];
/* 356 */     System.arraycopy(this.data, 0, bytes, 0, this.data.length);
/* 357 */     System.arraycopy(toAdd.getData(), 0, bytes, this.data.length, toAdd.getData().length);
/* 358 */     return new SimpleString(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString concat(char c)
/*     */   {
/* 369 */     byte[] bytes = new byte[this.data.length + 2];
/* 370 */     System.arraycopy(this.data, 0, bytes, 0, this.data.length);
/* 371 */     bytes[this.data.length] = ((byte)(c & 0xFF));
/* 372 */     bytes[(this.data.length + 1)] = ((byte)(c >> '\b' & 0xFF));
/* 373 */     return new SimpleString(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int sizeof()
/*     */   {
/* 383 */     return 4 + this.data.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int sizeofString(SimpleString str)
/*     */   {
/* 394 */     return str.sizeof();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int sizeofNullableString(SimpleString str)
/*     */   {
/* 405 */     if (str == null)
/*     */     {
/* 407 */       return 1;
/*     */     }
/*     */     
/*     */ 
/* 411 */     return 1 + str.sizeof();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getChars(int srcBegin, int srcEnd, char[] dst, int dstPos)
/*     */   {
/* 426 */     if (srcBegin < 0)
/*     */     {
/* 428 */       throw new StringIndexOutOfBoundsException(srcBegin);
/*     */     }
/* 430 */     if (srcEnd > length())
/*     */     {
/* 432 */       throw new StringIndexOutOfBoundsException(srcEnd);
/*     */     }
/* 434 */     if (srcBegin > srcEnd)
/*     */     {
/* 436 */       throw new StringIndexOutOfBoundsException(srcEnd - srcBegin);
/*     */     }
/*     */     
/* 439 */     int j = srcBegin * 2;
/* 440 */     int d = dstPos;
/*     */     
/* 442 */     for (int i = srcBegin; i < srcEnd; i++)
/*     */     {
/* 444 */       int low = this.data[(j++)] & 0xFF;
/*     */       
/* 446 */       int high = this.data[(j++)] << 8 & 0xFF00;
/*     */       
/* 448 */       dst[(d++)] = ((char)(low | high));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\SimpleString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */