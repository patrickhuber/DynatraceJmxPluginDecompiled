/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Pair<A, B>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -2496357457812368127L;
/*     */   private A a;
/*     */   private B b;
/*     */   
/*     */   public Pair(A a, B b)
/*     */   {
/*  30 */     this.a = a;
/*     */     
/*  32 */     this.b = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   private int hash = -1;
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  44 */     if (this.hash == -1)
/*     */     {
/*  46 */       if ((this.a == null) && (this.b == null))
/*     */       {
/*  48 */         return super.hashCode();
/*     */       }
/*     */       
/*     */ 
/*  52 */       this.hash = ((this.a == null ? 0 : this.a.hashCode()) + 37 * (this.b == null ? 0 : this.b.hashCode()));
/*     */     }
/*     */     
/*     */ 
/*  56 */     return this.hash;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/*  62 */     if (other == this)
/*     */     {
/*  64 */       return true;
/*     */     }
/*     */     
/*  67 */     if (!(other instanceof Pair))
/*     */     {
/*  69 */       return false;
/*     */     }
/*     */     
/*  72 */     Pair<A, B> pother = (Pair)other;
/*     */     
/*  74 */     return (pother.a == null ? this.a == null : pother.a.equals(this.a)) && (pother.b == null ? this.b == null : pother.b.equals(this.b));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  81 */     return "Pair[a=" + this.a + ", b=" + this.b + "]";
/*     */   }
/*     */   
/*     */   public void setA(A a)
/*     */   {
/*  86 */     this.hash = -1;
/*  87 */     this.a = a;
/*     */   }
/*     */   
/*     */   public A getA()
/*     */   {
/*  92 */     return (A)this.a;
/*     */   }
/*     */   
/*     */   public void setB(B b)
/*     */   {
/*  97 */     this.hash = -1;
/*  98 */     this.b = b;
/*     */   }
/*     */   
/*     */   public B getB()
/*     */   {
/* 103 */     return (B)this.b;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\Pair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */