/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQAddressExistsException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 3032730450033992367L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQAddressExistsException()
/*    */   {
/* 36 */     super(HornetQExceptionType.ADDRESS_EXISTS);
/*    */   }
/*    */   
/*    */   public HornetQAddressExistsException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.ADDRESS_EXISTS, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQAddressExistsException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */