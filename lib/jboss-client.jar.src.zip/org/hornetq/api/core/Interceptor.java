package org.hornetq.api.core;

import org.hornetq.core.protocol.core.Packet;
import org.hornetq.spi.core.protocol.RemotingConnection;

public abstract interface Interceptor
{
  public abstract boolean intercept(Packet paramPacket, RemotingConnection paramRemotingConnection)
    throws HornetQException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\Interceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */