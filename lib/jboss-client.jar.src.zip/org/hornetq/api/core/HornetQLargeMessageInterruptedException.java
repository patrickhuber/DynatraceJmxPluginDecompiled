/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HornetQLargeMessageInterruptedException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 0L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQLargeMessageInterruptedException(String message)
/*    */   {
/* 30 */     super(HornetQExceptionType.LARGE_MESSAGE_INTERRUPTED, message);
/*    */   }
/*    */   
/*    */   public HornetQLargeMessageInterruptedException()
/*    */   {
/* 35 */     super(HornetQExceptionType.LARGE_MESSAGE_INTERRUPTED);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQLargeMessageInterruptedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */