/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQDisconnectedException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 7414966383933311627L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQDisconnectedException()
/*    */   {
/* 36 */     super(HornetQExceptionType.DISCONNECTED);
/*    */   }
/*    */   
/*    */   public HornetQDisconnectedException(String message)
/*    */   {
/* 41 */     super(HornetQExceptionType.DISCONNECTED, message);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQDisconnectedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */