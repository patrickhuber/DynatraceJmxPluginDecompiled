/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.hornetq.utils.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface Message
/*    */ {
/* 59 */   public static final SimpleString HDR_ACTUAL_EXPIRY_TIME = new SimpleString("_HQ_ACTUAL_EXPIRY");
/*    */   
/* 61 */   public static final SimpleString HDR_ORIGINAL_ADDRESS = new SimpleString("_HQ_ORIG_ADDRESS");
/*    */   
/* 63 */   public static final SimpleString HDR_ORIGINAL_QUEUE = new SimpleString("_HQ_ORIG_QUEUE");
/*    */   
/* 65 */   public static final SimpleString HDR_ORIG_MESSAGE_ID = new SimpleString("_HQ_ORIG_MESSAGE_ID");
/*    */   
/* 67 */   public static final SimpleString HDR_GROUP_ID = new SimpleString("_HQ_GROUP_ID");
/*    */   
/* 69 */   public static final SimpleString HDR_LARGE_COMPRESSED = new SimpleString("_HQ_LARGE_COMPRESSED");
/*    */   
/* 71 */   public static final SimpleString HDR_LARGE_BODY_SIZE = new SimpleString("_HQ_LARGE_SIZE");
/*    */   
/* 73 */   public static final SimpleString HDR_SCHEDULED_DELIVERY_TIME = new SimpleString("_HQ_SCHED_DELIVERY");
/*    */   
/* 75 */   public static final SimpleString HDR_DUPLICATE_DETECTION_ID = new SimpleString("_HQ_DUPL_ID");
/*    */   
/* 77 */   public static final SimpleString HDR_LAST_VALUE_NAME = new SimpleString("_HQ_LVQ_NAME");
/*    */   public static final byte DEFAULT_TYPE = 0;
/*    */   public static final byte OBJECT_TYPE = 2;
/*    */   public static final byte TEXT_TYPE = 3;
/*    */   public static final byte BYTES_TYPE = 4;
/*    */   public static final byte MAP_TYPE = 5;
/*    */   public static final byte STREAM_TYPE = 6;
/*    */   
/*    */   public abstract long getMessageID();
/*    */   
/*    */   public abstract UUID getUserID();
/*    */   
/*    */   public abstract void setUserID(UUID paramUUID);
/*    */   
/*    */   public abstract SimpleString getAddress();
/*    */   
/*    */   public abstract void setAddress(SimpleString paramSimpleString);
/*    */   
/*    */   public abstract byte getType();
/*    */   
/*    */   public abstract boolean isDurable();
/*    */   
/*    */   public abstract void setDurable(boolean paramBoolean);
/*    */   
/*    */   public abstract long getExpiration();
/*    */   
/*    */   public abstract boolean isExpired();
/*    */   
/*    */   public abstract void setExpiration(long paramLong);
/*    */   
/*    */   public abstract long getTimestamp();
/*    */   
/*    */   public abstract void setTimestamp(long paramLong);
/*    */   
/*    */   public abstract byte getPriority();
/*    */   
/*    */   public abstract void setPriority(byte paramByte);
/*    */   
/*    */   public abstract int getEncodeSize();
/*    */   
/*    */   public abstract boolean isLargeMessage();
/*    */   
/*    */   public abstract HornetQBuffer getBodyBuffer();
/*    */   
/*    */   public abstract HornetQBuffer getBodyBufferCopy();
/*    */   
/*    */   public abstract void putBooleanProperty(SimpleString paramSimpleString, boolean paramBoolean);
/*    */   
/*    */   public abstract void putBooleanProperty(String paramString, boolean paramBoolean);
/*    */   
/*    */   public abstract void putByteProperty(SimpleString paramSimpleString, byte paramByte);
/*    */   
/*    */   public abstract void putByteProperty(String paramString, byte paramByte);
/*    */   
/*    */   public abstract void putBytesProperty(SimpleString paramSimpleString, byte[] paramArrayOfByte);
/*    */   
/*    */   public abstract void putBytesProperty(String paramString, byte[] paramArrayOfByte);
/*    */   
/*    */   public abstract void putShortProperty(SimpleString paramSimpleString, short paramShort);
/*    */   
/*    */   public abstract void putShortProperty(String paramString, short paramShort);
/*    */   
/*    */   public abstract void putIntProperty(SimpleString paramSimpleString, int paramInt);
/*    */   
/*    */   public abstract void putIntProperty(String paramString, int paramInt);
/*    */   
/*    */   public abstract void putLongProperty(SimpleString paramSimpleString, long paramLong);
/*    */   
/*    */   public abstract void putLongProperty(String paramString, long paramLong);
/*    */   
/*    */   public abstract void putFloatProperty(SimpleString paramSimpleString, float paramFloat);
/*    */   
/*    */   public abstract void putFloatProperty(String paramString, float paramFloat);
/*    */   
/*    */   public abstract void putDoubleProperty(SimpleString paramSimpleString, double paramDouble);
/*    */   
/*    */   public abstract void putDoubleProperty(String paramString, double paramDouble);
/*    */   
/*    */   public abstract void putStringProperty(SimpleString paramSimpleString1, SimpleString paramSimpleString2);
/*    */   
/*    */   public abstract void putStringProperty(String paramString1, String paramString2);
/*    */   
/*    */   public abstract void putObjectProperty(SimpleString paramSimpleString, Object paramObject)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract void putObjectProperty(String paramString, Object paramObject)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Object removeProperty(SimpleString paramSimpleString);
/*    */   
/*    */   public abstract Object removeProperty(String paramString);
/*    */   
/*    */   public abstract boolean containsProperty(SimpleString paramSimpleString);
/*    */   
/*    */   public abstract boolean containsProperty(String paramString);
/*    */   
/*    */   public abstract Boolean getBooleanProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Boolean getBooleanProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Byte getByteProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Byte getByteProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Double getDoubleProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Double getDoubleProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Integer getIntProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Integer getIntProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Long getLongProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Long getLongProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Object getObjectProperty(SimpleString paramSimpleString);
/*    */   
/*    */   public abstract Object getObjectProperty(String paramString);
/*    */   
/*    */   public abstract Short getShortProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Short getShortProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Float getFloatProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Float getFloatProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract String getStringProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract String getStringProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract SimpleString getSimpleStringProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract SimpleString getSimpleStringProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract byte[] getBytesProperty(SimpleString paramSimpleString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract byte[] getBytesProperty(String paramString)
/*    */     throws HornetQPropertyConversionException;
/*    */   
/*    */   public abstract Set<SimpleString> getPropertyNames();
/*    */   
/*    */   public abstract Map<String, Object> toMap();
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */