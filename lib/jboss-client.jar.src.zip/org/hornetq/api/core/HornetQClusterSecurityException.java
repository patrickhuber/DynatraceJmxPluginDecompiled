/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQClusterSecurityException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -5890578849781297933L;
/*    */   
/*    */ 
/*    */ 
/*    */   public HornetQClusterSecurityException()
/*    */   {
/* 15 */     super(HornetQExceptionType.CLUSTER_SECURITY_EXCEPTION);
/*    */   }
/*    */   
/*    */   public HornetQClusterSecurityException(String msg)
/*    */   {
/* 20 */     super(HornetQExceptionType.CLUSTER_SECURITY_EXCEPTION, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQClusterSecurityException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */