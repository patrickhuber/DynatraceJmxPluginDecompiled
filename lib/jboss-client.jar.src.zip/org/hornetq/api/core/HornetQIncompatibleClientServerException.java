/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQIncompatibleClientServerException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -1662999230291452298L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQIncompatibleClientServerException()
/*    */   {
/* 38 */     super(HornetQExceptionType.INCOMPATIBLE_CLIENT_SERVER_VERSIONS);
/*    */   }
/*    */   
/*    */   public HornetQIncompatibleClientServerException(String msg)
/*    */   {
/* 43 */     super(HornetQExceptionType.INCOMPATIBLE_CLIENT_SERVER_VERSIONS, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQIncompatibleClientServerException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */