/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQSecurityException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = 3291210307590756881L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQSecurityException()
/*    */   {
/* 36 */     super(HornetQExceptionType.SECURITY_EXCEPTION);
/*    */   }
/*    */   
/*    */   public HornetQSecurityException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.SECURITY_EXCEPTION, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQSecurityException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */