/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ import java.nio.ByteBuffer;
/*    */ import org.hornetq.core.buffers.impl.ChannelBufferWrapper;
/*    */ import org.jboss.netty.buffer.ChannelBuffer;
/*    */ import org.jboss.netty.buffer.ChannelBuffers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQBuffers
/*    */ {
/*    */   public static HornetQBuffer dynamicBuffer(int size)
/*    */   {
/* 36 */     return new ChannelBufferWrapper(ChannelBuffers.dynamicBuffer(size));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static HornetQBuffer dynamicBuffer(byte[] bytes)
/*    */   {
/* 47 */     ChannelBuffer buff = ChannelBuffers.dynamicBuffer(bytes.length);
/*    */     
/* 49 */     buff.writeBytes(bytes);
/*    */     
/* 51 */     return new ChannelBufferWrapper(buff);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static HornetQBuffer wrappedBuffer(ByteBuffer underlying)
/*    */   {
/* 64 */     HornetQBuffer buff = new ChannelBufferWrapper(ChannelBuffers.wrappedBuffer(underlying));
/*    */     
/* 66 */     buff.clear();
/*    */     
/* 68 */     return buff;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static HornetQBuffer wrappedBuffer(byte[] underlying)
/*    */   {
/* 79 */     return new ChannelBufferWrapper(ChannelBuffers.wrappedBuffer(underlying));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static HornetQBuffer fixedBuffer(int size)
/*    */   {
/* 90 */     return new ChannelBufferWrapper(ChannelBuffers.buffer(size));
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQBuffers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */