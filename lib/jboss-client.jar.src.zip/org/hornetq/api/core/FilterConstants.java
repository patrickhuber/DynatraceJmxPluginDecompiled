/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FilterConstants
/*    */ {
/* 26 */   public static final SimpleString HORNETQ_USERID = new SimpleString("HQUserID");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 31 */   public static final SimpleString HORNETQ_EXPIRATION = new SimpleString("HQExpiration");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 36 */   public static final SimpleString HORNETQ_DURABLE = new SimpleString("HQDurable");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 41 */   public static final SimpleString NON_DURABLE = new SimpleString("NON_DURABLE");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 46 */   public static final SimpleString DURABLE = new SimpleString("DURABLE");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 51 */   public static final SimpleString HORNETQ_TIMESTAMP = new SimpleString("HQTimestamp");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 56 */   public static final SimpleString HORNETQ_PRIORITY = new SimpleString("HQPriority");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 61 */   public static final SimpleString HORNETQ_SIZE = new SimpleString("HQSize");
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 66 */   public static final SimpleString HORNETQ_PREFIX = new SimpleString("HQ");
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\FilterConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */