package org.hornetq.api.core;

import java.nio.ByteBuffer;
import org.jboss.netty.buffer.ChannelBuffer;

public abstract interface HornetQBuffer
{
  public abstract ChannelBuffer channelBuffer();
  
  public abstract int capacity();
  
  public abstract int readerIndex();
  
  public abstract void readerIndex(int paramInt);
  
  public abstract int writerIndex();
  
  public abstract void writerIndex(int paramInt);
  
  public abstract void setIndex(int paramInt1, int paramInt2);
  
  public abstract int readableBytes();
  
  public abstract int writableBytes();
  
  public abstract boolean readable();
  
  public abstract boolean writable();
  
  public abstract void clear();
  
  public abstract void markReaderIndex();
  
  public abstract void resetReaderIndex();
  
  public abstract void markWriterIndex();
  
  public abstract void resetWriterIndex();
  
  public abstract void discardReadBytes();
  
  public abstract byte getByte(int paramInt);
  
  public abstract short getUnsignedByte(int paramInt);
  
  public abstract short getShort(int paramInt);
  
  public abstract int getUnsignedShort(int paramInt);
  
  public abstract int getInt(int paramInt);
  
  public abstract long getUnsignedInt(int paramInt);
  
  public abstract long getLong(int paramInt);
  
  public abstract void getBytes(int paramInt, HornetQBuffer paramHornetQBuffer);
  
  public abstract void getBytes(int paramInt1, HornetQBuffer paramHornetQBuffer, int paramInt2);
  
  public abstract void getBytes(int paramInt1, HornetQBuffer paramHornetQBuffer, int paramInt2, int paramInt3);
  
  public abstract void getBytes(int paramInt, byte[] paramArrayOfByte);
  
  public abstract void getBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public abstract void getBytes(int paramInt, ByteBuffer paramByteBuffer);
  
  public abstract char getChar(int paramInt);
  
  public abstract float getFloat(int paramInt);
  
  public abstract double getDouble(int paramInt);
  
  public abstract void setByte(int paramInt, byte paramByte);
  
  public abstract void setShort(int paramInt, short paramShort);
  
  public abstract void setInt(int paramInt1, int paramInt2);
  
  public abstract void setLong(int paramInt, long paramLong);
  
  public abstract void setBytes(int paramInt, HornetQBuffer paramHornetQBuffer);
  
  public abstract void setBytes(int paramInt1, HornetQBuffer paramHornetQBuffer, int paramInt2);
  
  public abstract void setBytes(int paramInt1, HornetQBuffer paramHornetQBuffer, int paramInt2, int paramInt3);
  
  public abstract void setBytes(int paramInt, byte[] paramArrayOfByte);
  
  public abstract void setBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public abstract void setBytes(int paramInt, ByteBuffer paramByteBuffer);
  
  public abstract void setChar(int paramInt, char paramChar);
  
  public abstract void setFloat(int paramInt, float paramFloat);
  
  public abstract void setDouble(int paramInt, double paramDouble);
  
  public abstract byte readByte();
  
  public abstract short readUnsignedByte();
  
  public abstract short readShort();
  
  public abstract int readUnsignedShort();
  
  public abstract int readInt();
  
  public abstract long readUnsignedInt();
  
  public abstract long readLong();
  
  public abstract char readChar();
  
  public abstract float readFloat();
  
  public abstract double readDouble();
  
  public abstract boolean readBoolean();
  
  public abstract SimpleString readNullableSimpleString();
  
  public abstract String readNullableString();
  
  public abstract SimpleString readSimpleString();
  
  public abstract String readString();
  
  public abstract String readUTF();
  
  public abstract HornetQBuffer readBytes(int paramInt);
  
  public abstract HornetQBuffer readSlice(int paramInt);
  
  public abstract void readBytes(HornetQBuffer paramHornetQBuffer);
  
  public abstract void readBytes(HornetQBuffer paramHornetQBuffer, int paramInt);
  
  public abstract void readBytes(HornetQBuffer paramHornetQBuffer, int paramInt1, int paramInt2);
  
  public abstract void readBytes(byte[] paramArrayOfByte);
  
  public abstract void readBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract void readBytes(ByteBuffer paramByteBuffer);
  
  public abstract void skipBytes(int paramInt);
  
  public abstract void writeByte(byte paramByte);
  
  public abstract void writeShort(short paramShort);
  
  public abstract void writeInt(int paramInt);
  
  public abstract void writeLong(long paramLong);
  
  public abstract void writeChar(char paramChar);
  
  public abstract void writeFloat(float paramFloat);
  
  public abstract void writeDouble(double paramDouble);
  
  public abstract void writeBoolean(boolean paramBoolean);
  
  public abstract void writeNullableSimpleString(SimpleString paramSimpleString);
  
  public abstract void writeNullableString(String paramString);
  
  public abstract void writeSimpleString(SimpleString paramSimpleString);
  
  public abstract void writeString(String paramString);
  
  public abstract void writeUTF(String paramString);
  
  public abstract void writeBytes(HornetQBuffer paramHornetQBuffer, int paramInt);
  
  public abstract void writeBytes(HornetQBuffer paramHornetQBuffer, int paramInt1, int paramInt2);
  
  public abstract void writeBytes(byte[] paramArrayOfByte);
  
  public abstract void writeBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract void writeBytes(ByteBuffer paramByteBuffer);
  
  public abstract HornetQBuffer copy();
  
  public abstract HornetQBuffer copy(int paramInt1, int paramInt2);
  
  public abstract HornetQBuffer slice();
  
  public abstract HornetQBuffer slice(int paramInt1, int paramInt2);
  
  public abstract HornetQBuffer duplicate();
  
  public abstract ByteBuffer toByteBuffer();
  
  public abstract ByteBuffer toByteBuffer(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */