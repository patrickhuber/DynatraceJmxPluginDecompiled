/*     */ package org.hornetq.api.core;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.LinkedBlockingDeque;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.jgroups.JChannel;
/*     */ import org.jgroups.Message;
/*     */ import org.jgroups.ReceiverAdapter;
/*     */ import org.jgroups.conf.PlainConfigurator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JGroupsBroadcastGroupConfiguration
/*     */   implements BroadcastEndpointFactoryConfiguration, DiscoveryGroupConfigurationCompatibilityHelper
/*     */ {
/*     */   private static final long serialVersionUID = 8952238567248461285L;
/*     */   private final BroadcastEndpointFactory factory;
/*     */   
/*     */   public JGroupsBroadcastGroupConfiguration(final String jgroupsFile, final String channelName)
/*     */   {
/*  58 */     this.factory = new BroadcastEndpointFactory()
/*     */     {
/*     */       private static final long serialVersionUID = 1047956472941098435L;
/*     */       
/*     */       public BroadcastEndpoint createBroadcastEndpoint()
/*     */         throws Exception
/*     */       {
/*  65 */         JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint endpoint = new JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint(null);
/*  66 */         endpoint.initChannel(jgroupsFile, channelName);
/*  67 */         return endpoint;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public JGroupsBroadcastGroupConfiguration(final JChannel channel, final String channelName)
/*     */   {
/*  74 */     this.factory = new BroadcastEndpointFactory()
/*     */     {
/*     */       private static final long serialVersionUID = 5110372849181145377L;
/*     */       
/*     */       public BroadcastEndpoint createBroadcastEndpoint()
/*     */         throws Exception
/*     */       {
/*  81 */         JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint endpoint = new JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint(null);
/*  82 */         endpoint.initChannel(channel, channelName);
/*  83 */         return endpoint;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public BroadcastEndpointFactory createBroadcastEndpointFactory()
/*     */   {
/*  91 */     return this.factory;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getLocalBindAddress()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLocalBindPort()
/*     */   {
/* 106 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getGroupAddress()
/*     */   {
/* 112 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getGroupPort()
/*     */   {
/* 118 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static final class JGroupsBroadcastEndpoint
/*     */     implements BroadcastEndpoint
/*     */   {
/*     */     private boolean clientOpened;
/*     */     
/*     */     private boolean broadcastOpened;
/*     */     
/*     */     private JChannelWrapper<?> channel;
/*     */     
/*     */     private JGroupsReceiver receiver;
/*     */     
/*     */ 
/*     */     public void broadcast(byte[] data)
/*     */       throws Exception
/*     */     {
/* 138 */       if (this.broadcastOpened)
/*     */       {
/* 140 */         Message msg = new Message();
/*     */         
/* 142 */         msg.setBuffer(data);
/*     */         
/* 144 */         this.channel.send(msg);
/*     */       }
/*     */     }
/*     */     
/*     */     public byte[] receiveBroadcast() throws Exception
/*     */     {
/* 150 */       if (this.clientOpened)
/*     */       {
/* 152 */         return this.receiver.receiveBroadcast();
/*     */       }
/*     */       
/*     */ 
/* 156 */       return null;
/*     */     }
/*     */     
/*     */     public byte[] receiveBroadcast(long time, TimeUnit unit)
/*     */       throws Exception
/*     */     {
/* 162 */       if (this.clientOpened)
/*     */       {
/* 164 */         return this.receiver.receiveBroadcast(time, unit);
/*     */       }
/*     */       
/*     */ 
/* 168 */       return null;
/*     */     }
/*     */     
/*     */     public synchronized void openClient()
/*     */       throws Exception
/*     */     {
/* 174 */       if (this.clientOpened)
/*     */       {
/* 176 */         return;
/*     */       }
/* 178 */       internalOpen();
/* 179 */       this.receiver = new JGroupsReceiver(null);
/* 180 */       this.channel.setReceiver(this.receiver);
/* 181 */       this.clientOpened = true;
/*     */     }
/*     */     
/*     */     public synchronized void openBroadcaster() throws Exception
/*     */     {
/* 186 */       if (this.broadcastOpened) return;
/* 187 */       internalOpen();
/* 188 */       this.broadcastOpened = true;
/*     */     }
/*     */     
/*     */     private void initChannel(String jgroupsConfig, String channelName) throws Exception
/*     */     {
/* 193 */       PlainConfigurator configurator = new PlainConfigurator(jgroupsConfig);
/*     */       try
/*     */       {
/* 196 */         this.channel = JChannelManager.getJChannel(channelName, configurator);
/* 197 */         return;
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 201 */         this.channel = null;
/*     */         
/*     */ 
/* 204 */         URL configURL = Thread.currentThread().getContextClassLoader().getResource(jgroupsConfig);
/*     */         
/* 206 */         if (configURL == null)
/*     */         {
/* 208 */           throw new RuntimeException("couldn't find JGroups configuration " + jgroupsConfig);
/*     */         }
/* 210 */         this.channel = JChannelManager.getJChannel(channelName, configURL);
/*     */       }
/*     */     }
/*     */     
/*     */     private void initChannel(JChannel channel1, String channelName) throws Exception {
/* 215 */       this.channel = JChannelManager.getJChannel(channelName, channel1);
/*     */     }
/*     */     
/*     */     protected void internalOpen() throws Exception
/*     */     {
/* 220 */       this.channel.connect();
/*     */     }
/*     */     
/*     */     public synchronized void close(boolean isBroadcast) throws Exception
/*     */     {
/* 225 */       if (isBroadcast)
/*     */       {
/* 227 */         this.broadcastOpened = false;
/*     */       }
/*     */       else
/*     */       {
/* 231 */         this.channel.removeReceiver(this.receiver);
/* 232 */         this.clientOpened = false;
/*     */       }
/* 234 */       this.channel.close();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static final class JGroupsReceiver
/*     */       extends ReceiverAdapter
/*     */     {
/* 243 */       private final BlockingQueue<byte[]> dequeue = new LinkedBlockingDeque();
/*     */       
/*     */ 
/*     */       public void receive(Message msg)
/*     */       {
/* 248 */         this.dequeue.add(msg.getBuffer());
/*     */       }
/*     */       
/*     */       public byte[] receiveBroadcast() throws Exception
/*     */       {
/* 253 */         return (byte[])this.dequeue.take();
/*     */       }
/*     */       
/*     */       public byte[] receiveBroadcast(long time, TimeUnit unit) throws Exception
/*     */       {
/* 258 */         return (byte[])this.dequeue.poll(time, unit);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private static class JChannelWrapper<T>
/*     */     {
/* 271 */       int refCount = 1;
/*     */       JChannel channel;
/*     */       String channelName;
/* 274 */       List<JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JGroupsReceiver> receivers = new ArrayList();
/*     */       
/*     */       public JChannelWrapper(String channelName, T t) throws Exception
/*     */       {
/* 278 */         this.refCount = 1;
/* 279 */         this.channelName = channelName;
/* 280 */         if ((t instanceof URL))
/*     */         {
/* 282 */           this.channel = new JChannel((URL)t);
/*     */         }
/* 284 */         else if ((t instanceof JChannel))
/*     */         {
/* 286 */           this.channel = ((JChannel)t);
/*     */         }
/* 288 */         else if ((t instanceof PlainConfigurator))
/*     */         {
/* 290 */           this.channel = new JChannel((PlainConfigurator)t);
/*     */         }
/*     */         else
/*     */         {
/* 294 */           throw new IllegalArgumentException("Unsupported type " + t);
/*     */         }
/*     */       }
/*     */       
/*     */       public synchronized void close()
/*     */       {
/* 300 */         this.refCount -= 1;
/* 301 */         if (this.refCount == 0)
/*     */         {
/* 303 */           JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelManager.closeChannel(this.channelName, this.channel);
/*     */         }
/*     */       }
/*     */       
/*     */       public void removeReceiver(JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JGroupsReceiver receiver)
/*     */       {
/* 309 */         synchronized (this.receivers)
/*     */         {
/* 311 */           this.receivers.remove(receiver);
/*     */         }
/*     */       }
/*     */       
/*     */       public synchronized void connect() throws Exception
/*     */       {
/* 317 */         if (this.channel.isConnected()) return;
/* 318 */         this.channel.setReceiver(new ReceiverAdapter()
/*     */         {
/*     */ 
/*     */           public void receive(Message msg)
/*     */           {
/*     */ 
/* 324 */             synchronized (JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper.this.receivers)
/*     */             {
/* 326 */               for (JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JGroupsReceiver r : JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper.this.receivers)
/*     */               {
/* 328 */                 r.receive(msg);
/*     */               }
/*     */             }
/*     */           }
/* 332 */         });
/* 333 */         this.channel.connect(this.channelName);
/*     */       }
/*     */       
/*     */       public void setReceiver(JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JGroupsReceiver jGroupsReceiver)
/*     */       {
/* 338 */         synchronized (this.receivers)
/*     */         {
/* 340 */           this.receivers.add(jGroupsReceiver);
/*     */         }
/*     */       }
/*     */       
/*     */       public void send(Message msg) throws Exception
/*     */       {
/* 346 */         this.channel.send(msg);
/*     */       }
/*     */       
/*     */       public JChannelWrapper<T> addRef()
/*     */       {
/* 351 */         this.refCount += 1;
/* 352 */         return this;
/*     */       }
/*     */       
/*     */ 
/*     */       public String toString()
/*     */       {
/* 358 */         return "JChannelWrapper of [" + this.channel + "] " + this.refCount + " " + this.channelName;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private static class JChannelManager
/*     */     {
/*     */       private static Map<String, JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper<?>> channels;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       public static synchronized <T> JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper<?> getJChannel(String channelName, T t)
/*     */         throws Exception
/*     */       {
/* 375 */         if (channels == null)
/*     */         {
/* 377 */           channels = new HashMap();
/*     */         }
/* 379 */         JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper<?> wrapper = (JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper)channels.get(channelName);
/* 380 */         if (wrapper == null)
/*     */         {
/* 382 */           wrapper = new JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper(channelName, t);
/* 383 */           channels.put(channelName, wrapper);
/* 384 */           return wrapper;
/*     */         }
/* 386 */         return wrapper.addRef();
/*     */       }
/*     */       
/*     */       public static synchronized void closeChannel(String channelName, JChannel channel)
/*     */       {
/* 391 */         channel.setReceiver(null);
/* 392 */         channel.disconnect();
/* 393 */         channel.close();
/* 394 */         JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper<?> wrapper = (JGroupsBroadcastGroupConfiguration.JGroupsBroadcastEndpoint.JChannelWrapper)channels.remove(channelName);
/* 395 */         if (wrapper == null)
/*     */         {
/* 397 */           throw new IllegalStateException("Did not find channel " + channelName);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\JGroupsBroadcastGroupConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */