/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQNonExistentQueueException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -8199298881947523607L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQNonExistentQueueException()
/*    */   {
/* 36 */     super(HornetQExceptionType.QUEUE_DOES_NOT_EXIST);
/*    */   }
/*    */   
/*    */   public HornetQNonExistentQueueException(String msg)
/*    */   {
/* 41 */     super(HornetQExceptionType.QUEUE_DOES_NOT_EXIST, msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQNonExistentQueueException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */