/*    */ package org.hornetq.api.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HornetQIllegalStateException
/*    */   extends HornetQException
/*    */ {
/*    */   private static final long serialVersionUID = -4480125401057788511L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public HornetQIllegalStateException()
/*    */   {
/* 37 */     super(HornetQExceptionType.ILLEGAL_STATE);
/*    */   }
/*    */   
/*    */   public HornetQIllegalStateException(String message)
/*    */   {
/* 42 */     super(HornetQExceptionType.ILLEGAL_STATE, message);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\api\core\HornetQIllegalStateException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */