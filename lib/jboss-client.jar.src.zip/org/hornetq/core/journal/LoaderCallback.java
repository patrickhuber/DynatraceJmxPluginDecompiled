package org.hornetq.core.journal;

public abstract interface LoaderCallback
  extends TransactionFailureCallback
{
  public abstract void addPreparedTransaction(PreparedTransactionInfo paramPreparedTransactionInfo);
  
  public abstract void addRecord(RecordInfo paramRecordInfo);
  
  public abstract void deleteRecord(long paramLong);
  
  public abstract void updateRecord(RecordInfo paramRecordInfo);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\LoaderCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */