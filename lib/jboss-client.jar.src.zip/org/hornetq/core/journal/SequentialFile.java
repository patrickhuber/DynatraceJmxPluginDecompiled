package org.hornetq.core.journal;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import org.hornetq.api.core.HornetQBuffer;
import org.hornetq.api.core.HornetQException;
import org.hornetq.core.journal.impl.TimedBuffer;

public abstract interface SequentialFile
{
  public abstract void open()
    throws Exception;
  
  public abstract boolean isOpen();
  
  public abstract boolean exists();
  
  public abstract void open(int paramInt, boolean paramBoolean)
    throws Exception;
  
  public abstract boolean fits(int paramInt);
  
  public abstract int getAlignment()
    throws Exception;
  
  public abstract int calculateBlockStart(int paramInt)
    throws Exception;
  
  public abstract String getFileName();
  
  public abstract void fill(int paramInt1, int paramInt2, byte paramByte)
    throws Exception;
  
  public abstract void delete()
    throws IOException, InterruptedException, HornetQException;
  
  public abstract void write(HornetQBuffer paramHornetQBuffer, boolean paramBoolean, IOAsyncTask paramIOAsyncTask)
    throws Exception;
  
  public abstract void write(HornetQBuffer paramHornetQBuffer, boolean paramBoolean)
    throws Exception;
  
  public abstract void write(EncodingSupport paramEncodingSupport, boolean paramBoolean, IOAsyncTask paramIOAsyncTask)
    throws Exception;
  
  public abstract void write(EncodingSupport paramEncodingSupport, boolean paramBoolean)
    throws Exception;
  
  public abstract void writeDirect(ByteBuffer paramByteBuffer, boolean paramBoolean, IOAsyncTask paramIOAsyncTask);
  
  public abstract void writeDirect(ByteBuffer paramByteBuffer, boolean paramBoolean)
    throws Exception;
  
  public abstract void writeInternal(ByteBuffer paramByteBuffer)
    throws Exception;
  
  public abstract int read(ByteBuffer paramByteBuffer, IOAsyncTask paramIOAsyncTask)
    throws Exception;
  
  public abstract int read(ByteBuffer paramByteBuffer)
    throws Exception;
  
  public abstract void position(long paramLong)
    throws IOException;
  
  public abstract long position();
  
  public abstract void close()
    throws Exception;
  
  public abstract void waitForClose()
    throws Exception;
  
  public abstract void sync()
    throws IOException;
  
  public abstract long size()
    throws Exception;
  
  public abstract void renameTo(String paramString)
    throws Exception;
  
  public abstract SequentialFile cloneFile();
  
  public abstract void copyTo(SequentialFile paramSequentialFile)
    throws Exception;
  
  public abstract void setTimedBuffer(TimedBuffer paramTimedBuffer);
  
  public abstract File getJavaFile();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\SequentialFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */