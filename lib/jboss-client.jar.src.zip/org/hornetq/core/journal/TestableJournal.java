package org.hornetq.core.journal;

import org.hornetq.core.journal.impl.JournalFile;

public abstract interface TestableJournal
  extends Journal
{
  public abstract int getDataFilesCount();
  
  public abstract int getFreeFilesCount();
  
  public abstract int getOpenedFilesCount();
  
  public abstract int getIDMapSize();
  
  public abstract String debug()
    throws Exception;
  
  public abstract void debugWait()
    throws Exception;
  
  public abstract int getFileSize();
  
  public abstract int getMinFiles();
  
  public abstract String getFilePrefix();
  
  public abstract String getFileExtension();
  
  public abstract int getMaxAIO();
  
  public abstract void forceMoveNextFile()
    throws Exception;
  
  public abstract void setAutoReclaim(boolean paramBoolean);
  
  public abstract boolean isAutoReclaim();
  
  public abstract void testCompact();
  
  public abstract JournalFile getCurrentFile();
  
  public abstract boolean checkReclaimStatus()
    throws Exception;
  
  public abstract JournalFile[] getDataFiles();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\TestableJournal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */