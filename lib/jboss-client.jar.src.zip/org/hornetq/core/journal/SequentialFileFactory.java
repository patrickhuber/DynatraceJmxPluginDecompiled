package org.hornetq.core.journal;

import java.nio.ByteBuffer;
import java.util.List;

public abstract interface SequentialFileFactory
{
  public abstract SequentialFile createSequentialFile(String paramString, int paramInt);
  
  public abstract List<String> listFiles(String paramString)
    throws Exception;
  
  public abstract boolean isSupportsCallbacks();
  
  public abstract void onIOError(Exception paramException, String paramString, SequentialFile paramSequentialFile);
  
  public abstract ByteBuffer allocateDirectBuffer(int paramInt);
  
  public abstract void releaseDirectBuffer(ByteBuffer paramByteBuffer);
  
  public abstract ByteBuffer newBuffer(int paramInt);
  
  public abstract void releaseBuffer(ByteBuffer paramByteBuffer);
  
  public abstract void activateBuffer(SequentialFile paramSequentialFile);
  
  public abstract void deactivateBuffer();
  
  public abstract ByteBuffer wrapBuffer(byte[] paramArrayOfByte);
  
  public abstract int getAlignment();
  
  public abstract int calculateBlockSize(int paramInt);
  
  public abstract String getDirectory();
  
  public abstract void clearBuffer(ByteBuffer paramByteBuffer);
  
  public abstract void start();
  
  public abstract void stop();
  
  public abstract void createDirs()
    throws Exception;
  
  public abstract void flush();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\SequentialFileFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */