/*    */ package org.hornetq.core.journal;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.hornetq.core.journal.impl.JournalFile;
/*    */ import org.hornetq.core.server.HornetQComponent;
/*    */ 
/*    */ public abstract interface Journal
/*    */   extends HornetQComponent
/*    */ {
/*    */   public abstract void appendAddRecord(long paramLong, byte paramByte, byte[] paramArrayOfByte, boolean paramBoolean)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendAddRecord(long paramLong, byte paramByte, EncodingSupport paramEncodingSupport, boolean paramBoolean)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendAddRecord(long paramLong, byte paramByte, EncodingSupport paramEncodingSupport, boolean paramBoolean, IOCompletion paramIOCompletion)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendUpdateRecord(long paramLong, byte paramByte, byte[] paramArrayOfByte, boolean paramBoolean) throws Exception;
/*    */   
/*    */   public abstract void appendUpdateRecord(long paramLong, byte paramByte, EncodingSupport paramEncodingSupport, boolean paramBoolean) throws Exception;
/*    */   
/*    */   public abstract void appendUpdateRecord(long paramLong, byte paramByte, EncodingSupport paramEncodingSupport, boolean paramBoolean, IOCompletion paramIOCompletion) throws Exception;
/*    */   
/*    */   public abstract void appendDeleteRecord(long paramLong, boolean paramBoolean) throws Exception;
/*    */   
/*    */   public abstract void appendDeleteRecord(long paramLong, boolean paramBoolean, IOCompletion paramIOCompletion) throws Exception;
/*    */   
/*    */   public abstract void appendAddRecordTransactional(long paramLong1, long paramLong2, byte paramByte, byte[] paramArrayOfByte) throws Exception;
/*    */   
/*    */   public abstract void appendAddRecordTransactional(long paramLong1, long paramLong2, byte paramByte, EncodingSupport paramEncodingSupport) throws Exception;
/*    */   
/*    */   public static enum JournalState
/*    */   {
/* 36 */     STOPPED, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 41 */     STARTED, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 46 */     SYNCING, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 51 */     SYNCING_UP_TO_DATE, 
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 56 */     LOADED;
/*    */     
/*    */     private JournalState() {}
/*    */   }
/*    */   
/*    */   public abstract void appendUpdateRecordTransactional(long paramLong1, long paramLong2, byte paramByte, byte[] paramArrayOfByte)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendUpdateRecordTransactional(long paramLong1, long paramLong2, byte paramByte, EncodingSupport paramEncodingSupport)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendDeleteRecordTransactional(long paramLong1, long paramLong2, byte[] paramArrayOfByte)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendDeleteRecordTransactional(long paramLong1, long paramLong2, EncodingSupport paramEncodingSupport)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendDeleteRecordTransactional(long paramLong1, long paramLong2)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendCommitRecord(long paramLong, boolean paramBoolean)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendCommitRecord(long paramLong, boolean paramBoolean, IOCompletion paramIOCompletion)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendCommitRecord(long paramLong, boolean paramBoolean1, IOCompletion paramIOCompletion, boolean paramBoolean2)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendPrepareRecord(long paramLong, EncodingSupport paramEncodingSupport, boolean paramBoolean)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendPrepareRecord(long paramLong, EncodingSupport paramEncodingSupport, boolean paramBoolean, IOCompletion paramIOCompletion)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendPrepareRecord(long paramLong, byte[] paramArrayOfByte, boolean paramBoolean)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendRollbackRecord(long paramLong, boolean paramBoolean)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void appendRollbackRecord(long paramLong, boolean paramBoolean, IOCompletion paramIOCompletion)
/*    */     throws Exception;
/*    */   
/*    */   public abstract JournalLoadInformation load(LoaderCallback paramLoaderCallback)
/*    */     throws Exception;
/*    */   
/*    */   public abstract JournalLoadInformation loadInternalOnly()
/*    */     throws Exception;
/*    */   
/*    */   public abstract JournalLoadInformation loadSyncOnly(JournalState paramJournalState)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void lineUpContext(IOCompletion paramIOCompletion);
/*    */   
/*    */   public abstract JournalLoadInformation load(List<RecordInfo> paramList, List<PreparedTransactionInfo> paramList1, TransactionFailureCallback paramTransactionFailureCallback)
/*    */     throws Exception;
/*    */   
/*    */   public abstract int getAlignment()
/*    */     throws Exception;
/*    */   
/*    */   public abstract int getNumberOfRecords();
/*    */   
/*    */   public abstract int getUserVersion();
/*    */   
/*    */   public abstract void perfBlast(int paramInt);
/*    */   
/*    */   public abstract void runDirectJournalBlast()
/*    */     throws Exception;
/*    */   
/*    */   public abstract Map<Long, JournalFile> createFilesForBackupSync(long[] paramArrayOfLong)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void synchronizationLock();
/*    */   
/*    */   public abstract void synchronizationUnlock();
/*    */   
/*    */   public abstract void forceMoveNextFile()
/*    */     throws Exception;
/*    */   
/*    */   public abstract JournalFile[] getDataFiles();
/*    */   
/*    */   public abstract SequentialFileFactory getFileFactory();
/*    */   
/*    */   public abstract int getFileSize();
/*    */   
/*    */   public abstract void scheduleCompactAndBlock(int paramInt)
/*    */     throws Exception;
/*    */   
/*    */   public abstract void replicationSyncPreserveOldFiles();
/*    */   
/*    */   public abstract void replicationSyncFinished();
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\Journal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */