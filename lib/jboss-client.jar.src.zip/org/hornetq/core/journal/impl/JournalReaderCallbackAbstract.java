package org.hornetq.core.journal.impl;

import org.hornetq.core.journal.RecordInfo;

public class JournalReaderCallbackAbstract
  implements JournalReaderCallback
{
  public void markAsDataFile(JournalFile file) {}
  
  public void onReadAddRecord(RecordInfo info)
    throws Exception
  {}
  
  public void onReadAddRecordTX(long transactionID, RecordInfo recordInfo)
    throws Exception
  {}
  
  public void onReadCommitRecord(long transactionID, int numberOfRecords)
    throws Exception
  {}
  
  public void onReadDeleteRecord(long recordID)
    throws Exception
  {}
  
  public void onReadDeleteRecordTX(long transactionID, RecordInfo recordInfo)
    throws Exception
  {}
  
  public void onReadPrepareRecord(long transactionID, byte[] extraData, int numberOfRecords)
    throws Exception
  {}
  
  public void onReadRollbackRecord(long transactionID)
    throws Exception
  {}
  
  public void onReadUpdateRecord(RecordInfo recordInfo)
    throws Exception
  {}
  
  public void onReadUpdateRecordTX(long transactionID, RecordInfo recordInfo)
    throws Exception
  {}
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalReaderCallbackAbstract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */