/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.hornetq.core.journal.RecordInfo;
/*     */ import org.hornetq.utils.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportJournal
/*     */ {
/*     */   public static void main(String[] arg)
/*     */   {
/*  63 */     if (arg.length != 5)
/*     */     {
/*  65 */       System.err.println("Use: java -cp hornetq-core.jar:netty.jar org.hornetq.core.journal.impl.ImportJournal <JournalDirectory> <JournalPrefix> <FileExtension> <FileSize> <FileOutput>");
/*  66 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  71 */       importJournal(arg[0], arg[1], arg[2], 2, Integer.parseInt(arg[3]), arg[4]);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  75 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void importJournal(String directory, String journalPrefix, String journalSuffix, int minFiles, int fileSize, String fileInput)
/*     */     throws Exception
/*     */   {
/*  87 */     FileInputStream fileInputStream = new FileInputStream(new File(fileInput));
/*  88 */     importJournal(directory, journalPrefix, journalSuffix, minFiles, fileSize, fileInputStream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void importJournal(String directory, String journalPrefix, String journalSuffix, int minFiles, int fileSize, InputStream stream)
/*     */     throws Exception
/*     */   {
/*  99 */     Reader reader = new InputStreamReader(stream);
/* 100 */     importJournal(directory, journalPrefix, journalSuffix, minFiles, fileSize, reader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void importJournal(String directory, String journalPrefix, String journalSuffix, int minFiles, int fileSize, Reader reader)
/*     */     throws Exception
/*     */   {
/* 111 */     File journalDir = new File(directory);
/*     */     
/* 113 */     if (!journalDir.exists())
/*     */     {
/* 115 */       if (!journalDir.mkdirs()) {
/* 116 */         System.err.println("Could not create directory " + directory);
/*     */       }
/*     */     }
/* 119 */     NIOSequentialFileFactory nio = new NIOSequentialFileFactory(directory, null);
/*     */     
/* 121 */     JournalImpl journal = new JournalImpl(fileSize, minFiles, 0, 0, nio, journalPrefix, journalSuffix, 1);
/*     */     
/* 123 */     if (journal.orderFiles().size() != 0)
/*     */     {
/* 125 */       throw new IllegalStateException("Import needs to create a brand new journal");
/*     */     }
/*     */     
/* 128 */     journal.start();
/*     */     
/*     */ 
/* 131 */     journal.loadInternalOnly();
/*     */     
/* 133 */     BufferedReader buffReader = new BufferedReader(reader);
/*     */     
/*     */ 
/*     */ 
/* 137 */     HashMap<Long, AtomicInteger> txCounters = new HashMap();
/*     */     
/* 139 */     long lineNumber = 0L;
/*     */     
/* 141 */     Map<Long, JournalRecord> journalRecords = journal.getRecords();
/*     */     String line;
/* 143 */     while ((line = buffReader.readLine()) != null)
/*     */     {
/* 145 */       lineNumber += 1L;
/* 146 */       String[] splitLine = line.split(",");
/* 147 */       if (splitLine[0].equals("#File"))
/*     */       {
/* 149 */         txCounters.clear();
/*     */       }
/*     */       else
/*     */       {
/* 153 */         Properties lineProperties = parseLine(splitLine);
/*     */         
/* 155 */         String operation = null;
/*     */         try
/*     */         {
/* 158 */           operation = lineProperties.getProperty("operation");
/*     */           
/* 160 */           if (operation.equals("AddRecord"))
/*     */           {
/* 162 */             RecordInfo info = parseRecord(lineProperties);
/* 163 */             journal.appendAddRecord(info.id, info.userRecordType, info.data, false);
/*     */           }
/* 165 */           else if (operation.equals("AddRecordTX"))
/*     */           {
/* 167 */             long txID = parseLong("txID", lineProperties);
/* 168 */             AtomicInteger counter = getCounter(Long.valueOf(txID), txCounters);
/* 169 */             counter.incrementAndGet();
/* 170 */             RecordInfo info = parseRecord(lineProperties);
/* 171 */             journal.appendAddRecordTransactional(txID, info.id, info.userRecordType, info.data);
/*     */           }
/* 173 */           else if (operation.equals("AddRecordTX"))
/*     */           {
/* 175 */             long txID = parseLong("txID", lineProperties);
/* 176 */             AtomicInteger counter = getCounter(Long.valueOf(txID), txCounters);
/* 177 */             counter.incrementAndGet();
/* 178 */             RecordInfo info = parseRecord(lineProperties);
/* 179 */             journal.appendAddRecordTransactional(txID, info.id, info.userRecordType, info.data);
/*     */           }
/* 181 */           else if (operation.equals("UpdateTX"))
/*     */           {
/* 183 */             long txID = parseLong("txID", lineProperties);
/* 184 */             AtomicInteger counter = getCounter(Long.valueOf(txID), txCounters);
/* 185 */             counter.incrementAndGet();
/* 186 */             RecordInfo info = parseRecord(lineProperties);
/* 187 */             journal.appendUpdateRecordTransactional(txID, info.id, info.userRecordType, info.data);
/*     */           }
/* 189 */           else if (operation.equals("Update"))
/*     */           {
/* 191 */             RecordInfo info = parseRecord(lineProperties);
/* 192 */             journal.appendUpdateRecord(info.id, info.userRecordType, info.data, false);
/*     */           }
/* 194 */           else if (operation.equals("DeleteRecord"))
/*     */           {
/* 196 */             long id = parseLong("id", lineProperties);
/*     */             
/*     */ 
/* 199 */             if (journalRecords.get(Long.valueOf(id)) != null)
/*     */             {
/* 201 */               journal.appendDeleteRecord(id, false);
/*     */             }
/*     */           }
/* 204 */           else if (operation.equals("DeleteRecordTX"))
/*     */           {
/* 206 */             long txID = parseLong("txID", lineProperties);
/* 207 */             long id = parseLong("id", lineProperties);
/* 208 */             AtomicInteger counter = getCounter(Long.valueOf(txID), txCounters);
/* 209 */             counter.incrementAndGet();
/*     */             
/*     */ 
/* 212 */             if (journalRecords.get(Long.valueOf(id)) != null)
/*     */             {
/* 214 */               journal.appendDeleteRecordTransactional(txID, id);
/*     */             }
/*     */           }
/* 217 */           else if (operation.equals("Prepare"))
/*     */           {
/* 219 */             long txID = parseLong("txID", lineProperties);
/* 220 */             int numberOfRecords = parseInt("numberOfRecords", lineProperties);
/* 221 */             AtomicInteger counter = getCounter(Long.valueOf(txID), txCounters);
/* 222 */             byte[] data = parseEncoding("extraData", lineProperties);
/*     */             
/* 224 */             if (counter.get() == numberOfRecords)
/*     */             {
/* 226 */               journal.appendPrepareRecord(txID, data, false);
/*     */             }
/*     */             else
/*     */             {
/* 230 */               System.err.println("Transaction " + txID + " at line " + lineNumber + " is incomplete. The prepare record expected " + numberOfRecords + " while the import only had " + counter);
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/* 239 */           else if (operation.equals("Commit"))
/*     */           {
/* 241 */             long txID = parseLong("txID", lineProperties);
/* 242 */             int numberOfRecords = parseInt("numberOfRecords", lineProperties);
/* 243 */             AtomicInteger counter = getCounter(Long.valueOf(txID), txCounters);
/* 244 */             if (counter.get() == numberOfRecords)
/*     */             {
/* 246 */               journal.appendCommitRecord(txID, false);
/*     */             }
/*     */             else
/*     */             {
/* 250 */               System.err.println("Transaction " + txID + " at line " + lineNumber + " is incomplete. The commit record expected " + numberOfRecords + " while the import only had " + counter);
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/* 259 */           else if (operation.equals("Rollback"))
/*     */           {
/* 261 */             long txID = parseLong("txID", lineProperties);
/* 262 */             journal.appendRollbackRecord(txID, false);
/*     */           }
/*     */           else
/*     */           {
/* 266 */             System.err.println("Invalid opeartion " + operation + " at line " + lineNumber);
/*     */           }
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 271 */           System.err.println("Error at line " + lineNumber + ", operation=" + operation + " msg = " + ex.getMessage());
/*     */         }
/*     */       }
/*     */     }
/* 275 */     journal.stop();
/*     */   }
/*     */   
/*     */ 
/*     */   protected static AtomicInteger getCounter(Long txID, Map<Long, AtomicInteger> txCounters)
/*     */   {
/* 281 */     AtomicInteger counter = (AtomicInteger)txCounters.get(txID);
/* 282 */     if (counter == null)
/*     */     {
/* 284 */       counter = new AtomicInteger(0);
/* 285 */       txCounters.put(txID, counter);
/*     */     }
/*     */     
/* 288 */     return counter;
/*     */   }
/*     */   
/*     */   protected static RecordInfo parseRecord(Properties properties) throws Exception
/*     */   {
/* 293 */     long id = parseLong("id", properties);
/* 294 */     byte userRecordType = parseByte("userRecordType", properties);
/* 295 */     boolean isUpdate = parseBoolean("isUpdate", properties);
/* 296 */     byte[] data = parseEncoding("data", properties);
/* 297 */     return new RecordInfo(id, userRecordType, data, isUpdate, (short)0);
/*     */   }
/*     */   
/*     */   private static byte[] parseEncoding(String name, Properties properties) throws Exception
/*     */   {
/* 302 */     String value = parseString(name, properties);
/*     */     
/* 304 */     return decode(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int parseInt(String name, Properties properties)
/*     */     throws Exception
/*     */   {
/* 313 */     String value = parseString(name, properties);
/*     */     
/* 315 */     return Integer.parseInt(value);
/*     */   }
/*     */   
/*     */   private static long parseLong(String name, Properties properties) throws Exception
/*     */   {
/* 320 */     String value = parseString(name, properties);
/*     */     
/* 322 */     return Long.parseLong(value);
/*     */   }
/*     */   
/*     */   private static boolean parseBoolean(String name, Properties properties) throws Exception
/*     */   {
/* 327 */     String value = parseString(name, properties);
/*     */     
/* 329 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */   
/*     */   private static byte parseByte(String name, Properties properties) throws Exception
/*     */   {
/* 334 */     String value = parseString(name, properties);
/*     */     
/* 336 */     return Byte.parseByte(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String parseString(String name, Properties properties)
/*     */     throws Exception
/*     */   {
/* 347 */     String value = properties.getProperty(name);
/*     */     
/* 349 */     if (value == null)
/*     */     {
/* 351 */       throw new Exception("property " + name + " not found");
/*     */     }
/* 353 */     return value;
/*     */   }
/*     */   
/*     */   protected static Properties parseLine(String[] splitLine)
/*     */   {
/* 358 */     Properties properties = new Properties();
/*     */     
/* 360 */     for (String el : splitLine)
/*     */     {
/* 362 */       String[] tuple = el.split("@");
/* 363 */       if (tuple.length == 2)
/*     */       {
/* 365 */         properties.put(tuple[0], tuple[1]);
/*     */       }
/*     */       else
/*     */       {
/* 369 */         properties.put(tuple[0], tuple[0]);
/*     */       }
/*     */     }
/*     */     
/* 373 */     return properties;
/*     */   }
/*     */   
/*     */   private static byte[] decode(String data)
/*     */   {
/* 378 */     return Base64.decode(data, 24);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\ImportJournal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */