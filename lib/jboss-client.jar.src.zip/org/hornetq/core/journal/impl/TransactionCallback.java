/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.hornetq.core.journal.IOAsyncTask;
/*     */ import org.hornetq.utils.ReusableLatch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TransactionCallback
/*     */   implements IOAsyncTask
/*     */ {
/*  30 */   private final ReusableLatch countLatch = new ReusableLatch();
/*     */   
/*  32 */   private volatile String errorMessage = null;
/*     */   
/*  34 */   private volatile int errorCode = 0;
/*     */   
/*  36 */   private final AtomicInteger up = new AtomicInteger();
/*     */   
/*  38 */   private volatile int done = 0;
/*     */   
/*     */   private volatile IOAsyncTask delegateCompletion;
/*     */   
/*     */   public void countUp()
/*     */   {
/*  44 */     this.up.incrementAndGet();
/*  45 */     this.countLatch.countUp();
/*     */   }
/*     */   
/*     */   public void done()
/*     */   {
/*  50 */     this.countLatch.countDown();
/*  51 */     if ((++this.done == this.up.get()) && (this.delegateCompletion != null))
/*     */     {
/*  53 */       IOAsyncTask delegateToCall = this.delegateCompletion;
/*     */       
/*     */ 
/*  56 */       this.delegateCompletion = null;
/*  57 */       delegateToCall.done();
/*     */     }
/*     */   }
/*     */   
/*     */   public void waitCompletion() throws InterruptedException
/*     */   {
/*  63 */     this.countLatch.await();
/*     */     
/*  65 */     if (this.errorMessage != null)
/*     */     {
/*  67 */       throw new IllegalStateException("Error on Transaction: " + this.errorCode + " - " + this.errorMessage);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onError(int errorCode, String errorMessage)
/*     */   {
/*  73 */     this.errorMessage = errorMessage;
/*     */     
/*  75 */     this.errorCode = errorCode;
/*     */     
/*  77 */     this.countLatch.countDown();
/*     */     
/*  79 */     if (this.delegateCompletion != null)
/*     */     {
/*  81 */       this.delegateCompletion.onError(errorCode, errorMessage);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IOAsyncTask getDelegateCompletion()
/*     */   {
/*  90 */     return this.delegateCompletion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDelegateCompletion(IOAsyncTask delegateCompletion)
/*     */   {
/*  98 */     this.delegateCompletion = delegateCompletion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getErrorMessage()
/*     */   {
/* 106 */     return this.errorMessage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/* 114 */     return this.errorCode;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\TransactionCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */