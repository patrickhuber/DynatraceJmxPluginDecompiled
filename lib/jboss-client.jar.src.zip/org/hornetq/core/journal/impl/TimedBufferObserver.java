package org.hornetq.core.journal.impl;

import java.nio.ByteBuffer;
import java.util.List;
import org.hornetq.core.journal.IOAsyncTask;

public abstract interface TimedBufferObserver
{
  public abstract void flushBuffer(ByteBuffer paramByteBuffer, boolean paramBoolean, List<IOAsyncTask> paramList);
  
  public abstract int getRemainingBytes();
  
  public abstract ByteBuffer newBuffer(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\TimedBufferObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */