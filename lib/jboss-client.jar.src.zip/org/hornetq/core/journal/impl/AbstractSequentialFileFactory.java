/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.core.journal.IOCriticalErrorListener;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ import org.hornetq.utils.HornetQThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractSequentialFileFactory
/*     */   implements SequentialFileFactory
/*     */ {
/*     */   protected static final int EXECUTOR_TIMEOUT = 60;
/*     */   protected final String journalDir;
/*     */   protected final TimedBuffer timedBuffer;
/*     */   protected final int bufferSize;
/*     */   protected final long bufferTimeout;
/*     */   private final IOCriticalErrorListener critialErrorListener;
/*     */   protected ExecutorService writeExecutor;
/*     */   
/*     */   AbstractSequentialFileFactory(String journalDir, boolean buffered, int bufferSize, int bufferTimeout, boolean logRates, IOCriticalErrorListener criticalErrorListener)
/*     */   {
/*  73 */     this.journalDir = journalDir;
/*     */     
/*  75 */     if (buffered)
/*     */     {
/*  77 */       this.timedBuffer = new TimedBuffer(bufferSize, bufferTimeout, logRates);
/*     */     }
/*     */     else
/*     */     {
/*  81 */       this.timedBuffer = null;
/*     */     }
/*  83 */     this.bufferSize = bufferSize;
/*  84 */     this.bufferTimeout = bufferTimeout;
/*  85 */     this.critialErrorListener = criticalErrorListener;
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/*  90 */     if (this.timedBuffer != null)
/*     */     {
/*  92 */       this.timedBuffer.stop();
/*     */     }
/*     */     
/*  95 */     if ((isSupportsCallbacks()) && (this.writeExecutor != null))
/*     */     {
/*  97 */       this.writeExecutor.shutdown();
/*     */       
/*     */       try
/*     */       {
/* 101 */         if (!this.writeExecutor.awaitTermination(60L, TimeUnit.SECONDS))
/*     */         {
/* 103 */           HornetQJournalLogger.LOGGER.timeoutOnWriterShutdown(new Exception("trace"));
/*     */         }
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 108 */         throw new HornetQInterruptedException(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDirectory()
/*     */   {
/* 115 */     return this.journalDir;
/*     */   }
/*     */   
/*     */   public void start()
/*     */   {
/* 120 */     if (this.timedBuffer != null)
/*     */     {
/* 122 */       this.timedBuffer.start();
/*     */     }
/*     */     
/* 125 */     if (isSupportsCallbacks())
/*     */     {
/* 127 */       this.writeExecutor = Executors.newSingleThreadExecutor(new HornetQThreadFactory("HornetQ-Asynchronous-Persistent-Writes" + System.identityHashCode(this), true, getThisClassLoader()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onIOError(Exception exception, String message, SequentialFile file)
/*     */   {
/* 137 */     if (this.critialErrorListener != null)
/*     */     {
/* 139 */       this.critialErrorListener.onIOException(exception, message, file);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void activateBuffer(SequentialFile file)
/*     */   {
/* 146 */     if (this.timedBuffer != null)
/*     */     {
/* 148 */       file.setTimedBuffer(this.timedBuffer);
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush()
/*     */   {
/* 154 */     if (this.timedBuffer != null)
/*     */     {
/* 156 */       this.timedBuffer.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   public void deactivateBuffer()
/*     */   {
/* 162 */     if (this.timedBuffer != null)
/*     */     {
/*     */ 
/* 165 */       this.timedBuffer.flush();
/* 166 */       this.timedBuffer.setObserver(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void releaseBuffer(ByteBuffer buffer) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void createDirs()
/*     */     throws Exception
/*     */   {
/* 179 */     File file = new File(this.journalDir);
/* 180 */     boolean ok = file.mkdirs();
/* 181 */     if (!ok)
/*     */     {
/* 183 */       throw new IOException("Failed to create directory " + this.journalDir);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<String> listFiles(final String extension) throws Exception
/*     */   {
/* 189 */     File dir = new File(this.journalDir);
/*     */     
/* 191 */     FilenameFilter fnf = new FilenameFilter()
/*     */     {
/*     */       public boolean accept(File file, String name)
/*     */       {
/* 195 */         return name.endsWith("." + extension);
/*     */       }
/*     */       
/* 198 */     };
/* 199 */     String[] fileNames = dir.list(fnf);
/*     */     
/* 201 */     if (fileNames == null)
/*     */     {
/* 203 */       throw new IOException("Failed to list: " + this.journalDir);
/*     */     }
/*     */     
/* 206 */     return Arrays.asList(fileNames);
/*     */   }
/*     */   
/*     */   private static ClassLoader getThisClassLoader()
/*     */   {
/* 211 */     (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public ClassLoader run()
/*     */       {
/* 215 */         return AbstractSequentialFileFactory.class.getClassLoader();
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\AbstractSequentialFileFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */