/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQIOErrorException;
/*     */ import org.hornetq.core.journal.EncodingSupport;
/*     */ import org.hornetq.core.journal.IOAsyncTask;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.journal.HornetQJournalBundle;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSequentialFile
/*     */   implements SequentialFile
/*     */ {
/*     */   private File file;
/*     */   private final String directory;
/*     */   protected final SequentialFileFactory factory;
/*  50 */   protected long fileSize = 0L;
/*     */   
/*  52 */   protected final AtomicLong position = new AtomicLong(0L);
/*     */   
/*     */ 
/*     */ 
/*     */   protected TimedBuffer timedBuffer;
/*     */   
/*     */ 
/*     */ 
/*  60 */   protected final TimedBufferObserver timedBufferObserver = new LocalBufferObserver();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final Executor writerExecutor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractSequentialFile(String directory, File file, SequentialFileFactory factory, Executor writerExecutor)
/*     */   {
/*  77 */     this.file = file;
/*  78 */     this.directory = directory;
/*  79 */     this.factory = factory;
/*  80 */     this.writerExecutor = writerExecutor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean exists()
/*     */   {
/*  87 */     return this.file.exists();
/*     */   }
/*     */   
/*     */   public final String getFileName()
/*     */   {
/*  92 */     return this.file.getName();
/*     */   }
/*     */   
/*     */   public final void delete() throws IOException, InterruptedException, HornetQException
/*     */   {
/*  97 */     if (isOpen())
/*     */     {
/*  99 */       close();
/*     */     }
/*     */     
/* 102 */     if ((this.file.exists()) && (!this.file.delete()))
/*     */     {
/* 104 */       HornetQJournalLogger.LOGGER.errorDeletingFile(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void copyTo(SequentialFile newFileName) throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 112 */       HornetQJournalLogger.LOGGER.debug("Copying " + this + " as " + newFileName);
/* 113 */       if (!newFileName.isOpen())
/*     */       {
/* 115 */         newFileName.open();
/*     */       }
/*     */       
/* 118 */       if (!isOpen())
/*     */       {
/* 120 */         open();
/*     */       }
/*     */       
/*     */ 
/* 124 */       ByteBuffer buffer = ByteBuffer.allocate(10240);
/*     */       
/*     */       for (;;)
/*     */       {
/* 128 */         buffer.rewind();
/* 129 */         int size = read(buffer);
/* 130 */         newFileName.writeDirect(buffer, false);
/* 131 */         if (size < 10240) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 136 */       newFileName.close();
/* 137 */       close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 141 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 142 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void position(long pos)
/*     */     throws IOException
/*     */   {
/* 152 */     this.position.set(pos);
/*     */   }
/*     */   
/*     */   public long position()
/*     */   {
/* 157 */     return this.position.get();
/*     */   }
/*     */   
/*     */   public final void renameTo(String newFileName)
/*     */     throws IOException, InterruptedException, HornetQException
/*     */   {
/*     */     try
/*     */     {
/* 165 */       close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 169 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 170 */       throw e;
/*     */     }
/*     */     
/* 173 */     File newFile = new File(this.directory + "/" + newFileName);
/*     */     
/* 175 */     if (!this.file.equals(newFile))
/*     */     {
/* 177 */       if (!this.file.renameTo(newFile))
/*     */       {
/* 179 */         throw HornetQJournalBundle.BUNDLE.ioRenameFileError(this.file.getName(), newFileName);
/*     */       }
/* 181 */       this.file = newFile;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */     throws IOException, InterruptedException, HornetQException
/*     */   {
/* 191 */     final CountDownLatch donelatch = new CountDownLatch(1);
/*     */     
/* 193 */     if (this.writerExecutor != null)
/*     */     {
/* 195 */       this.writerExecutor.execute(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 199 */           donelatch.countDown();
/*     */         }
/*     */       });
/*     */       
/* 203 */       while (!donelatch.await(60L, TimeUnit.SECONDS))
/*     */       {
/* 205 */         HornetQJournalLogger.LOGGER.couldNotCompleteTask(new Exception("trace"), this.file.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public final boolean fits(int size)
/*     */   {
/* 212 */     if (this.timedBuffer == null)
/*     */     {
/* 214 */       return this.position.get() + size <= this.fileSize;
/*     */     }
/*     */     
/*     */ 
/* 218 */     return this.timedBuffer.checkSize(size);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setTimedBuffer(TimedBuffer buffer)
/*     */   {
/* 224 */     if (this.timedBuffer != null)
/*     */     {
/* 226 */       this.timedBuffer.setObserver(null);
/*     */     }
/*     */     
/* 229 */     this.timedBuffer = buffer;
/*     */     
/* 231 */     if (buffer != null)
/*     */     {
/* 233 */       buffer.setObserver(this.timedBufferObserver);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(HornetQBuffer bytes, boolean sync, IOAsyncTask callback)
/*     */     throws IOException
/*     */   {
/* 240 */     if (this.timedBuffer != null)
/*     */     {
/* 242 */       bytes.setIndex(0, bytes.capacity());
/* 243 */       this.timedBuffer.addBytes(bytes, sync, callback);
/*     */     }
/*     */     else
/*     */     {
/* 247 */       ByteBuffer buffer = this.factory.newBuffer(bytes.capacity());
/* 248 */       buffer.put(bytes.toByteBuffer().array());
/* 249 */       buffer.rewind();
/* 250 */       writeDirect(buffer, sync, callback);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(HornetQBuffer bytes, boolean sync)
/*     */     throws IOException, InterruptedException, HornetQException
/*     */   {
/* 257 */     if (sync)
/*     */     {
/* 259 */       SimpleWaitIOCallback completion = new SimpleWaitIOCallback();
/*     */       
/* 261 */       write(bytes, true, completion);
/*     */       
/* 263 */       completion.waitCompletion();
/*     */     }
/*     */     else
/*     */     {
/* 267 */       write(bytes, false, DummyCallback.getInstance());
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(EncodingSupport bytes, boolean sync, IOAsyncTask callback)
/*     */   {
/* 273 */     if (this.timedBuffer != null)
/*     */     {
/* 275 */       this.timedBuffer.addBytes(bytes, sync, callback);
/*     */     }
/*     */     else
/*     */     {
/* 279 */       ByteBuffer buffer = this.factory.newBuffer(bytes.getEncodeSize());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 285 */       HornetQBuffer outBuffer = HornetQBuffers.wrappedBuffer(buffer);
/* 286 */       bytes.encode(outBuffer);
/* 287 */       buffer.rewind();
/* 288 */       writeDirect(buffer, sync, callback);
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(EncodingSupport bytes, boolean sync) throws InterruptedException, HornetQException
/*     */   {
/* 294 */     if (sync)
/*     */     {
/* 296 */       SimpleWaitIOCallback completion = new SimpleWaitIOCallback();
/*     */       
/* 298 */       write(bytes, true, completion);
/*     */       
/* 300 */       completion.waitCompletion();
/*     */     }
/*     */     else
/*     */     {
/* 304 */       write(bytes, false, DummyCallback.getInstance());
/*     */     }
/*     */   }
/*     */   
/*     */   protected File getFile()
/*     */   {
/* 310 */     return this.file;
/*     */   }
/*     */   
/*     */   private static final class DelegateCallback implements IOAsyncTask
/*     */   {
/*     */     final List<IOAsyncTask> delegates;
/*     */     
/*     */     private DelegateCallback(List<IOAsyncTask> delegates)
/*     */     {
/* 319 */       this.delegates = delegates;
/*     */     }
/*     */     
/*     */     public void done()
/*     */     {
/* 324 */       for (IOAsyncTask callback : this.delegates)
/*     */       {
/*     */         try
/*     */         {
/* 328 */           callback.done();
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 332 */           HornetQJournalLogger.LOGGER.errorCompletingCallback(e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void onError(int errorCode, String errorMessage)
/*     */     {
/* 339 */       for (IOAsyncTask callback : this.delegates)
/*     */       {
/*     */         try
/*     */         {
/* 343 */           callback.onError(errorCode, errorMessage);
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 347 */           HornetQJournalLogger.LOGGER.errorCallingErrorCallback(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected ByteBuffer newBuffer(int size, int limit)
/*     */   {
/* 355 */     size = this.factory.calculateBlockSize(size);
/* 356 */     limit = this.factory.calculateBlockSize(limit);
/*     */     
/* 358 */     ByteBuffer buffer = this.factory.newBuffer(size);
/* 359 */     buffer.limit(limit);
/* 360 */     return buffer;
/*     */   }
/*     */   
/*     */   protected class LocalBufferObserver implements TimedBufferObserver {
/*     */     protected LocalBufferObserver() {}
/*     */     
/*     */     public void flushBuffer(ByteBuffer buffer, boolean requestedSync, List<IOAsyncTask> callbacks) {
/* 367 */       buffer.flip();
/*     */       
/* 369 */       if (buffer.limit() == 0)
/*     */       {
/* 371 */         AbstractSequentialFile.this.factory.releaseBuffer(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 375 */         AbstractSequentialFile.this.writeDirect(buffer, requestedSync, new AbstractSequentialFile.DelegateCallback(callbacks, null));
/*     */       }
/*     */     }
/*     */     
/*     */     public ByteBuffer newBuffer(int size, int limit)
/*     */     {
/* 381 */       return AbstractSequentialFile.this.newBuffer(size, limit);
/*     */     }
/*     */     
/*     */     public int getRemainingBytes()
/*     */     {
/* 386 */       if (AbstractSequentialFile.this.fileSize - AbstractSequentialFile.this.position.get() > 2147483647L)
/*     */       {
/* 388 */         return Integer.MAX_VALUE;
/*     */       }
/*     */       
/*     */ 
/* 392 */       return (int)(AbstractSequentialFile.this.fileSize - AbstractSequentialFile.this.position.get());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String toString()
/*     */     {
/* 399 */       return "TimedBufferObserver on file (" + AbstractSequentialFile.this.getFile().getName() + ")";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File getJavaFile()
/*     */   {
/* 407 */     return getFile().getAbsoluteFile();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\AbstractSequentialFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */