/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.Pair;
/*     */ import org.hornetq.core.journal.RecordInfo;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.core.journal.impl.dataformat.ByteArrayEncoding;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecord;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecordTX;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalCompleteRecordTX;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalCompleteRecordTX.TX_RECORD_TYPE;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalDeleteRecordTX;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalInternalRecord;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalRollbackRecordTX;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JournalCompactor
/*     */   extends AbstractJournalUpdateTask
/*     */   implements JournalRecordProvider
/*     */ {
/*     */   private static final short COMPACT_SPLIT_LINE = 2;
/*  55 */   private final Map<Long, PendingTransaction> pendingTransactions = new ConcurrentHashMap();
/*     */   
/*  57 */   private final Map<Long, JournalRecord> newRecords = new HashMap();
/*     */   
/*  59 */   private final Map<Long, JournalTransaction> newTransactions = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  64 */   private final LinkedList<CompactCommand> pendingCommands = new LinkedList();
/*     */   
/*     */   int currentCount;
/*     */   
/*     */   public static SequentialFile readControlFile(SequentialFileFactory fileFactory, List<String> dataFiles, List<String> newFiles, List<Pair<String, String>> renameFile)
/*     */     throws Exception
/*     */   {
/*  71 */     SequentialFile controlFile = fileFactory.createSequentialFile("journal-rename-control.ctr", 1);
/*     */     
/*  73 */     if (controlFile.exists())
/*     */     {
/*  75 */       JournalFile file = new JournalFileImpl(controlFile, 0L, 2);
/*     */       
/*  77 */       ArrayList<RecordInfo> records = new ArrayList();
/*     */       
/*  79 */       JournalImpl.readJournalFile(fileFactory, file, new JournalReaderCallbackAbstract()
/*     */       {
/*     */         public void onReadAddRecord(RecordInfo info)
/*     */           throws Exception
/*     */         {
/*  84 */           this.val$records.add(info);
/*     */         }
/*     */       });
/*     */       
/*  88 */       if (records.size() == 0)
/*     */       {
/*  90 */         return null;
/*     */       }
/*     */       
/*     */ 
/*  94 */       HornetQBuffer input = HornetQBuffers.wrappedBuffer(((RecordInfo)records.get(0)).data);
/*     */       
/*  96 */       int numberDataFiles = input.readInt();
/*     */       
/*  98 */       for (int i = 0; i < numberDataFiles; i++)
/*     */       {
/* 100 */         dataFiles.add(input.readUTF());
/*     */       }
/*     */       
/* 103 */       int numberNewFiles = input.readInt();
/*     */       
/* 105 */       for (int i = 0; i < numberNewFiles; i++)
/*     */       {
/* 107 */         newFiles.add(input.readUTF());
/*     */       }
/*     */       
/* 110 */       int numberRenames = input.readInt();
/* 111 */       for (int i = 0; i < numberRenames; i++)
/*     */       {
/* 113 */         String from = input.readUTF();
/* 114 */         String to = input.readUTF();
/* 115 */         renameFile.add(new Pair(from, to));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 120 */       return controlFile;
/*     */     }
/*     */     
/*     */ 
/* 124 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public List<JournalFile> getNewDataFiles()
/*     */   {
/* 130 */     return this.newDataFiles;
/*     */   }
/*     */   
/*     */   public Map<Long, JournalRecord> getNewRecords()
/*     */   {
/* 135 */     return this.newRecords;
/*     */   }
/*     */   
/*     */   public Map<Long, JournalTransaction> getNewTransactions()
/*     */   {
/* 140 */     return this.newTransactions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalCompactor(SequentialFileFactory fileFactory, JournalImpl journal, JournalFilesRepository filesRepository, Set<Long> recordsSnapshot, long firstFileID)
/*     */   {
/* 149 */     super(fileFactory, journal, filesRepository, recordsSnapshot, firstFileID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addPendingTransaction(long transactionID, long[] ids)
/*     */   {
/* 155 */     this.pendingTransactions.put(Long.valueOf(transactionID), new PendingTransaction(ids));
/*     */   }
/*     */   
/*     */   public void addCommandCommit(JournalTransaction liveTransaction, JournalFile currentFile)
/*     */   {
/* 160 */     this.pendingCommands.add(new CommitCompactCommand(liveTransaction, currentFile));
/*     */     
/* 162 */     long[] ids = liveTransaction.getPositiveArray();
/*     */     
/* 164 */     PendingTransaction oldTransaction = (PendingTransaction)this.pendingTransactions.get(Long.valueOf(liveTransaction.getId()));
/* 165 */     long[] ids2 = null;
/*     */     
/* 167 */     if (oldTransaction != null)
/*     */     {
/* 169 */       ids2 = oldTransaction.pendingIDs;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 174 */     if (ids != null)
/*     */     {
/* 176 */       for (long id : ids)
/*     */       {
/* 178 */         addToRecordsSnaptshot(id);
/*     */       }
/*     */     }
/*     */     
/* 182 */     if (ids2 != null)
/*     */     {
/* 184 */       for (long id : ids2)
/*     */       {
/* 186 */         addToRecordsSnaptshot(id);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addCommandRollback(JournalTransaction liveTransaction, JournalFile currentFile)
/*     */   {
/* 193 */     this.pendingCommands.add(new RollbackCompactCommand(liveTransaction, currentFile));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCommandDelete(long id, JournalFile usedFile)
/*     */   {
/* 202 */     this.pendingCommands.add(new DeleteCompactCommand(id, usedFile));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCommandUpdate(long id, JournalFile usedFile, int size)
/*     */   {
/* 211 */     this.pendingCommands.add(new UpdateCompactCommand(id, usedFile, size));
/*     */   }
/*     */   
/*     */   private void checkSize(int size) throws Exception
/*     */   {
/* 216 */     checkSize(size, -1);
/*     */   }
/*     */   
/*     */   private void checkSize(int size, int compactCount) throws Exception
/*     */   {
/* 221 */     if (getWritingChannel() == null)
/*     */     {
/* 223 */       if (!checkCompact(compactCount))
/*     */       {
/*     */ 
/* 226 */         openFile();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 231 */       if (compactCount >= 0)
/*     */       {
/* 233 */         if (checkCompact(compactCount))
/*     */         {
/*     */ 
/*     */ 
/* 237 */           return;
/*     */         }
/*     */       }
/*     */       
/* 241 */       if (getWritingChannel().writerIndex() + size > getWritingChannel().capacity())
/*     */       {
/* 243 */         openFile();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 251 */   boolean willNeedToSplit = false;
/*     */   
/* 253 */   boolean splitted = false;
/*     */   
/*     */   private boolean checkCompact(int compactCount) throws Exception
/*     */   {
/* 257 */     if ((compactCount >= 2) && (!this.splitted))
/*     */     {
/* 259 */       this.willNeedToSplit = true;
/*     */     }
/*     */     
/* 262 */     if ((this.willNeedToSplit) && (compactCount < 2))
/*     */     {
/* 264 */       this.willNeedToSplit = false;
/* 265 */       this.splitted = false;
/* 266 */       openFile();
/* 267 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 271 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replayPendingCommands()
/*     */   {
/* 280 */     for (CompactCommand command : this.pendingCommands)
/*     */     {
/*     */       try
/*     */       {
/* 284 */         command.execute();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 288 */         HornetQJournalLogger.LOGGER.errorReplayingCommands(e);
/*     */       }
/*     */     }
/*     */     
/* 292 */     this.pendingCommands.clear();
/*     */   }
/*     */   
/*     */ 
/*     */   public void onReadAddRecord(RecordInfo info)
/*     */     throws Exception
/*     */   {
/* 299 */     if (lookupRecord(info.id))
/*     */     {
/* 301 */       JournalInternalRecord addRecord = new JournalAddRecord(true, info.id, info.getUserRecordType(), new ByteArrayEncoding(info.data));
/*     */       
/*     */ 
/*     */ 
/* 305 */       addRecord.setCompactCount((short)(info.compactCount + 1));
/*     */       
/* 307 */       checkSize(addRecord.getEncodeSize(), info.compactCount);
/*     */       
/* 309 */       writeEncoder(addRecord);
/*     */       
/* 311 */       this.newRecords.put(Long.valueOf(info.id), new JournalRecord(this.currentFile, addRecord.getEncodeSize()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onReadAddRecordTX(long transactionID, RecordInfo info) throws Exception
/*     */   {
/* 317 */     if ((this.pendingTransactions.get(Long.valueOf(transactionID)) != null) || (lookupRecord(info.id)))
/*     */     {
/* 319 */       JournalTransaction newTransaction = getNewJournalTransaction(transactionID);
/*     */       
/* 321 */       JournalInternalRecord record = new JournalAddRecordTX(true, transactionID, info.id, info.getUserRecordType(), new ByteArrayEncoding(info.data));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 327 */       record.setCompactCount((short)(info.compactCount + 1));
/*     */       
/* 329 */       checkSize(record.getEncodeSize(), info.compactCount);
/*     */       
/* 331 */       newTransaction.addPositive(this.currentFile, info.id, record.getEncodeSize());
/*     */       
/* 333 */       writeEncoder(record);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onReadCommitRecord(long transactionID, int numberOfRecords)
/*     */     throws Exception
/*     */   {
/* 340 */     if (this.pendingTransactions.get(Long.valueOf(transactionID)) != null)
/*     */     {
/*     */ 
/* 343 */       HornetQJournalLogger.LOGGER.inconsistencyDuringCompacting(Long.valueOf(transactionID));
/*     */     }
/*     */     else
/*     */     {
/* 347 */       JournalTransaction newTransaction = (JournalTransaction)this.newTransactions.remove(Long.valueOf(transactionID));
/* 348 */       if (newTransaction != null)
/*     */       {
/* 350 */         JournalInternalRecord commitRecord = new JournalCompleteRecordTX(JournalCompleteRecordTX.TX_RECORD_TYPE.COMMIT, transactionID, null);
/*     */         
/*     */ 
/* 353 */         checkSize(commitRecord.getEncodeSize());
/*     */         
/* 355 */         writeEncoder(commitRecord, newTransaction.getCounter(this.currentFile));
/*     */         
/* 357 */         newTransaction.commit(this.currentFile);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onReadDeleteRecord(long recordID) throws Exception
/*     */   {
/* 364 */     if (this.newRecords.get(Long.valueOf(recordID)) != null)
/*     */     {
/*     */ 
/* 367 */       HornetQJournalLogger.LOGGER.inconsistencyDuringCompactingDelete(Long.valueOf(recordID));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onReadDeleteRecordTX(long transactionID, RecordInfo info)
/*     */     throws Exception
/*     */   {
/* 374 */     if (this.pendingTransactions.get(Long.valueOf(transactionID)) != null)
/*     */     {
/* 376 */       JournalTransaction newTransaction = getNewJournalTransaction(transactionID);
/*     */       
/* 378 */       JournalInternalRecord record = new JournalDeleteRecordTX(transactionID, info.id, new ByteArrayEncoding(info.data));
/*     */       
/*     */ 
/*     */ 
/* 382 */       checkSize(record.getEncodeSize());
/*     */       
/* 384 */       writeEncoder(record);
/*     */       
/* 386 */       newTransaction.addNegative(this.currentFile, info.id);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void markAsDataFile(JournalFile file) {}
/*     */   
/*     */ 
/*     */   public void onReadPrepareRecord(long transactionID, byte[] extraData, int numberOfRecords)
/*     */     throws Exception
/*     */   {
/* 398 */     if (this.pendingTransactions.get(Long.valueOf(transactionID)) != null)
/*     */     {
/*     */ 
/* 401 */       JournalTransaction newTransaction = getNewJournalTransaction(transactionID);
/*     */       
/* 403 */       JournalInternalRecord prepareRecord = new JournalCompleteRecordTX(JournalCompleteRecordTX.TX_RECORD_TYPE.PREPARE, transactionID, new ByteArrayEncoding(extraData));
/*     */       
/*     */ 
/* 406 */       checkSize(prepareRecord.getEncodeSize());
/*     */       
/* 408 */       writeEncoder(prepareRecord, newTransaction.getCounter(this.currentFile));
/*     */       
/* 410 */       newTransaction.prepare(this.currentFile);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onReadRollbackRecord(long transactionID)
/*     */     throws Exception
/*     */   {
/* 417 */     if (this.pendingTransactions.get(Long.valueOf(transactionID)) != null)
/*     */     {
/*     */ 
/* 420 */       throw new IllegalStateException("Inconsistency during compacting: RollbackRecord ID = " + transactionID + " for an already rolled back transaction during compacting");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 425 */     JournalTransaction newTransaction = (JournalTransaction)this.newTransactions.remove(Long.valueOf(transactionID));
/* 426 */     if (newTransaction != null)
/*     */     {
/*     */ 
/* 429 */       JournalInternalRecord rollbackRecord = new JournalRollbackRecordTX(transactionID);
/*     */       
/* 431 */       checkSize(rollbackRecord.getEncodeSize());
/*     */       
/* 433 */       writeEncoder(rollbackRecord);
/*     */       
/* 435 */       newTransaction.rollback(this.currentFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void onReadUpdateRecord(RecordInfo info)
/*     */     throws Exception
/*     */   {
/* 443 */     if (lookupRecord(info.id))
/*     */     {
/* 445 */       JournalInternalRecord updateRecord = new JournalAddRecord(false, info.id, info.userRecordType, new ByteArrayEncoding(info.data));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 450 */       updateRecord.setCompactCount((short)(info.compactCount + 1));
/*     */       
/* 452 */       checkSize(updateRecord.getEncodeSize(), info.compactCount);
/*     */       
/* 454 */       JournalRecord newRecord = (JournalRecord)this.newRecords.get(Long.valueOf(info.id));
/*     */       
/* 456 */       if (newRecord == null)
/*     */       {
/* 458 */         HornetQJournalLogger.LOGGER.compactingWithNoAddRecord(Long.valueOf(info.id));
/*     */       }
/*     */       else
/*     */       {
/* 462 */         newRecord.addUpdateFile(this.currentFile, updateRecord.getEncodeSize());
/*     */       }
/*     */       
/* 465 */       writeEncoder(updateRecord);
/*     */     }
/*     */   }
/*     */   
/*     */   public void onReadUpdateRecordTX(long transactionID, RecordInfo info) throws Exception
/*     */   {
/* 471 */     if ((this.pendingTransactions.get(Long.valueOf(transactionID)) != null) || (lookupRecord(info.id)))
/*     */     {
/* 473 */       JournalTransaction newTransaction = getNewJournalTransaction(transactionID);
/*     */       
/* 475 */       JournalInternalRecord updateRecordTX = new JournalAddRecordTX(false, transactionID, info.id, info.userRecordType, new ByteArrayEncoding(info.data));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 481 */       updateRecordTX.setCompactCount((short)(info.compactCount + 1));
/*     */       
/* 483 */       checkSize(updateRecordTX.getEncodeSize(), info.compactCount);
/*     */       
/* 485 */       writeEncoder(updateRecordTX);
/*     */       
/* 487 */       newTransaction.addPositive(this.currentFile, info.id, updateRecordTX.getEncodeSize());
/*     */     }
/*     */     else
/*     */     {
/* 491 */       onReadUpdateRecord(info);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JournalTransaction getNewJournalTransaction(long transactionID)
/*     */   {
/* 501 */     JournalTransaction newTransaction = (JournalTransaction)this.newTransactions.get(Long.valueOf(transactionID));
/* 502 */     if (newTransaction == null)
/*     */     {
/* 504 */       newTransaction = new JournalTransaction(transactionID, this);
/* 505 */       this.newTransactions.put(Long.valueOf(transactionID), newTransaction);
/*     */     }
/* 507 */     return newTransaction;
/*     */   }
/*     */   
/*     */   private static abstract class CompactCommand
/*     */   {
/*     */     abstract void execute() throws Exception;
/*     */   }
/*     */   
/*     */   private class DeleteCompactCommand extends JournalCompactor.CompactCommand
/*     */   {
/*     */     long id;
/*     */     JournalFile usedFile;
/*     */     
/*     */     public DeleteCompactCommand(long id, JournalFile usedFile)
/*     */     {
/* 522 */       super();
/* 523 */       this.id = id;
/* 524 */       this.usedFile = usedFile;
/*     */     }
/*     */     
/*     */     void execute()
/*     */       throws Exception
/*     */     {
/* 530 */       JournalRecord deleteRecord = (JournalRecord)JournalCompactor.this.journal.getRecords().remove(Long.valueOf(this.id));
/* 531 */       if (deleteRecord == null)
/*     */       {
/* 533 */         HornetQJournalLogger.LOGGER.noRecordDuringCompactReplay(Long.valueOf(this.id));
/*     */       }
/*     */       else
/*     */       {
/* 537 */         deleteRecord.delete(this.usedFile);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class PendingTransaction
/*     */   {
/*     */     long[] pendingIDs;
/*     */     
/*     */     PendingTransaction(long[] ids)
/*     */     {
/* 548 */       this.pendingIDs = ids;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class UpdateCompactCommand
/*     */     extends JournalCompactor.CompactCommand
/*     */   {
/*     */     private final long id;
/*     */     private final JournalFile usedFile;
/*     */     private final int size;
/*     */     
/*     */     public UpdateCompactCommand(long id, JournalFile usedFile, int size)
/*     */     {
/* 562 */       super();
/* 563 */       this.id = id;
/* 564 */       this.usedFile = usedFile;
/* 565 */       this.size = size;
/*     */     }
/*     */     
/*     */     void execute()
/*     */       throws Exception
/*     */     {
/* 571 */       JournalRecord updateRecord = (JournalRecord)JournalCompactor.this.journal.getRecords().get(Long.valueOf(this.id));
/* 572 */       updateRecord.addUpdateFile(this.usedFile, this.size);
/*     */     }
/*     */   }
/*     */   
/*     */   private class CommitCompactCommand
/*     */     extends JournalCompactor.CompactCommand
/*     */   {
/*     */     private final JournalTransaction liveTransaction;
/*     */     private final JournalFile commitFile;
/*     */     
/*     */     public CommitCompactCommand(JournalTransaction liveTransaction, JournalFile commitFile)
/*     */     {
/* 584 */       super();
/* 585 */       this.liveTransaction = liveTransaction;
/* 586 */       this.commitFile = commitFile;
/*     */     }
/*     */     
/*     */     void execute()
/*     */       throws Exception
/*     */     {
/* 592 */       JournalTransaction newTransaction = (JournalTransaction)JournalCompactor.this.newTransactions.get(Long.valueOf(this.liveTransaction.getId()));
/* 593 */       if (newTransaction != null)
/*     */       {
/* 595 */         this.liveTransaction.merge(newTransaction);
/* 596 */         this.liveTransaction.commit(this.commitFile);
/*     */       }
/* 598 */       JournalCompactor.this.newTransactions.remove(Long.valueOf(this.liveTransaction.getId()));
/*     */     }
/*     */   }
/*     */   
/*     */   private class RollbackCompactCommand
/*     */     extends JournalCompactor.CompactCommand
/*     */   {
/*     */     private final JournalTransaction liveTransaction;
/*     */     private final JournalFile rollbackFile;
/*     */     
/*     */     public RollbackCompactCommand(JournalTransaction liveTransaction, JournalFile rollbackFile)
/*     */     {
/* 610 */       super();
/* 611 */       this.liveTransaction = liveTransaction;
/* 612 */       this.rollbackFile = rollbackFile;
/*     */     }
/*     */     
/*     */     void execute()
/*     */       throws Exception
/*     */     {
/* 618 */       JournalTransaction newTransaction = (JournalTransaction)JournalCompactor.this.newTransactions.get(Long.valueOf(this.liveTransaction.getId()));
/* 619 */       if (newTransaction != null)
/*     */       {
/* 621 */         this.liveTransaction.merge(newTransaction);
/* 622 */         this.liveTransaction.rollback(this.rollbackFile);
/*     */       }
/* 624 */       JournalCompactor.this.newTransactions.remove(Long.valueOf(this.liveTransaction.getId()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public JournalCompactor getCompactor()
/*     */   {
/* 631 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<Long, JournalRecord> getRecords()
/*     */   {
/* 637 */     return this.newRecords;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalCompactor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */