/*    */ package org.hornetq.core.journal.impl;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.hornetq.core.journal.IOCriticalErrorListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompactJournal
/*    */ {
/*    */   public static void main(String[] arg)
/*    */   {
/* 31 */     if (arg.length != 4)
/*    */     {
/* 33 */       System.err.println("Use: java -cp hornetq-core.jar org.hornetq.core.journal.impl.CompactJournal <JournalDirectory> <JournalPrefix> <FileExtension> <FileSize>");
/* 34 */       return;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 39 */       compactJournal(arg[0], arg[1], arg[2], 2, Integer.parseInt(arg[3]), null);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 43 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   static void compactJournal(String directory, String journalPrefix, String journalSuffix, int minFiles, int fileSize, IOCriticalErrorListener listener)
/*    */     throws Exception
/*    */   {
/* 55 */     NIOSequentialFileFactory nio = new NIOSequentialFileFactory(directory, listener);
/*    */     
/* 57 */     JournalImpl journal = new JournalImpl(fileSize, minFiles, 0, 0, nio, journalPrefix, journalSuffix, 1);
/*    */     
/* 59 */     journal.start();
/*    */     
/* 61 */     journal.loadInternalOnly();
/*    */     
/* 63 */     journal.compact();
/*    */     
/* 65 */     journal.stop();
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\CompactJournal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */