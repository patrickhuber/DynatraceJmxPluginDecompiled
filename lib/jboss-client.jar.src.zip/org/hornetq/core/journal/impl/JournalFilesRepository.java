/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.BlockingDeque;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.LinkedBlockingDeque;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JournalFilesRepository
/*     */ {
/*  39 */   private static final boolean trace = HornetQJournalLogger.LOGGER.isTraceEnabled();
/*     */   
/*     */ 
/*     */   private static final boolean CHECK_CONSISTENCE = false;
/*     */   
/*     */ 
/*     */   private final SequentialFileFactory fileFactory;
/*     */   
/*     */ 
/*     */   private final JournalImpl journal;
/*     */   
/*     */ 
/*     */   private static void trace(String message)
/*     */   {
/*  53 */     HornetQJournalLogger.LOGGER.trace(message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private final BlockingDeque<JournalFile> dataFiles = new LinkedBlockingDeque();
/*     */   
/*  62 */   private final ConcurrentLinkedQueue<JournalFile> freeFiles = new ConcurrentLinkedQueue();
/*     */   
/*  64 */   private final BlockingQueue<JournalFile> openedFiles = new LinkedBlockingQueue();
/*     */   
/*  66 */   private final AtomicLong nextFileID = new AtomicLong(0L);
/*     */   
/*     */   private final int maxAIO;
/*     */   
/*     */   private final int minFiles;
/*     */   
/*     */   private final int fileSize;
/*     */   
/*     */   private final String filePrefix;
/*     */   
/*     */   private final String fileExtension;
/*     */   
/*     */   private final int userVersion;
/*     */   
/*     */   private Executor openFilesExecutor;
/*     */   
/*  82 */   private final Runnable pushOpenRunnable = new Runnable()
/*     */   {
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/*  88 */         JournalFilesRepository.this.pushOpenedFile();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  92 */         HornetQJournalLogger.LOGGER.errorPushingFile(e);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalFilesRepository(SequentialFileFactory fileFactory, JournalImpl journal, String filePrefix, String fileExtension, int userVersion, int maxAIO, int fileSize, int minFiles)
/*     */   {
/* 106 */     if (filePrefix == null)
/*     */     {
/* 108 */       throw new IllegalArgumentException("filePrefix cannot be null");
/*     */     }
/* 110 */     if (fileExtension == null)
/*     */     {
/* 112 */       throw new IllegalArgumentException("fileExtension cannot be null");
/*     */     }
/* 114 */     if (maxAIO <= 0)
/*     */     {
/* 116 */       throw new IllegalArgumentException("maxAIO must be a positive number");
/*     */     }
/* 118 */     this.fileFactory = fileFactory;
/* 119 */     this.maxAIO = maxAIO;
/* 120 */     this.filePrefix = filePrefix;
/* 121 */     this.fileExtension = fileExtension;
/* 122 */     this.minFiles = minFiles;
/* 123 */     this.fileSize = fileSize;
/* 124 */     this.userVersion = userVersion;
/* 125 */     this.journal = journal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setExecutor(Executor fileExecutor)
/*     */   {
/* 132 */     this.openFilesExecutor = fileExecutor;
/*     */   }
/*     */   
/*     */   public void clear() throws Exception
/*     */   {
/* 137 */     this.dataFiles.clear();
/*     */     
/* 139 */     this.freeFiles.clear();
/*     */     
/* 141 */     for (JournalFile file : this.openedFiles)
/*     */     {
/*     */       try
/*     */       {
/* 145 */         file.getFile().close();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 149 */         HornetQJournalLogger.LOGGER.errorClosingFile(e);
/*     */       }
/*     */     }
/* 152 */     this.openedFiles.clear();
/*     */   }
/*     */   
/*     */   public int getMaxAIO()
/*     */   {
/* 157 */     return this.maxAIO;
/*     */   }
/*     */   
/*     */   public String getFileExtension()
/*     */   {
/* 162 */     return this.fileExtension;
/*     */   }
/*     */   
/*     */   public String getFilePrefix()
/*     */   {
/* 167 */     return this.filePrefix;
/*     */   }
/*     */   
/*     */ 
/*     */   public void calculateNextfileID(List<JournalFile> files)
/*     */   {
/* 173 */     for (JournalFile file : files)
/*     */     {
/* 175 */       long fileIdFromFile = file.getFileID();
/* 176 */       long fileIdFromName = getFileNameID(file.getFile().getFileName());
/*     */       
/*     */ 
/*     */ 
/* 180 */       setNextFileID(Math.max(fileIdFromName, fileIdFromFile));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNextFileID(long targetUpdate)
/*     */   {
/*     */     for (;;)
/*     */     {
/* 197 */       long current = this.nextFileID.get();
/* 198 */       if (current >= targetUpdate) {
/* 199 */         return;
/*     */       }
/* 201 */       if (this.nextFileID.compareAndSet(current, targetUpdate)) {
/* 202 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void ensureMinFiles() throws Exception
/*     */   {
/* 209 */     int filesToCreate = this.minFiles - (this.dataFiles.size() + this.freeFiles.size());
/*     */     
/* 211 */     if (filesToCreate > 0)
/*     */     {
/* 213 */       for (int i = 0; i < filesToCreate; i++)
/*     */       {
/*     */ 
/* 216 */         this.freeFiles.add(createFile(false, false, true, false, -1L));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void openFile(JournalFile file, boolean multiAIO)
/*     */     throws Exception
/*     */   {
/* 224 */     if (multiAIO)
/*     */     {
/* 226 */       file.getFile().open();
/*     */     }
/*     */     else
/*     */     {
/* 230 */       file.getFile().open(1, false);
/*     */     }
/*     */     
/* 233 */     file.getFile().position(file.getFile().calculateBlockStart(16));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JournalFile[] getDataFilesArray()
/*     */   {
/* 240 */     return (JournalFile[])this.dataFiles.toArray(new JournalFile[this.dataFiles.size()]);
/*     */   }
/*     */   
/*     */   public JournalFile pollLastDataFile()
/*     */   {
/* 245 */     return (JournalFile)this.dataFiles.pollLast();
/*     */   }
/*     */   
/*     */   public void removeDataFile(JournalFile file)
/*     */   {
/* 250 */     if (!this.dataFiles.remove(file))
/*     */     {
/* 252 */       HornetQJournalLogger.LOGGER.couldNotRemoveFile(file);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getDataFilesCount()
/*     */   {
/* 258 */     return this.dataFiles.size();
/*     */   }
/*     */   
/*     */   public Collection<JournalFile> getDataFiles()
/*     */   {
/* 263 */     return this.dataFiles;
/*     */   }
/*     */   
/*     */   public void clearDataFiles()
/*     */   {
/* 268 */     this.dataFiles.clear();
/*     */   }
/*     */   
/*     */   public void addDataFileOnTop(JournalFile file)
/*     */   {
/* 273 */     this.dataFiles.addFirst(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String debugFiles()
/*     */   {
/* 283 */     StringBuilder buffer = new StringBuilder();
/*     */     
/* 285 */     buffer.append("**********\nCurrent File = " + this.journal.getCurrentFile() + "\n");
/* 286 */     buffer.append("**********\nDataFiles:\n");
/* 287 */     for (JournalFile file : this.dataFiles)
/*     */     {
/* 289 */       buffer.append(file.toString() + "\n");
/*     */     }
/* 291 */     buffer.append("*********\nFreeFiles:\n");
/* 292 */     for (JournalFile file : this.freeFiles)
/*     */     {
/* 294 */       buffer.append(file.toString() + "\n");
/*     */     }
/* 296 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   public synchronized void checkDataFiles()
/*     */   {
/* 301 */     long seq = -1L;
/* 302 */     for (JournalFile file : this.dataFiles)
/*     */     {
/* 304 */       if (file.getFileID() <= seq)
/*     */       {
/* 306 */         HornetQJournalLogger.LOGGER.checkFiles();
/* 307 */         HornetQJournalLogger.LOGGER.info(debugFiles());
/* 308 */         HornetQJournalLogger.LOGGER.seqOutOfOrder();
/* 309 */         System.exit(-1);
/*     */       }
/*     */       
/* 312 */       if ((this.journal.getCurrentFile() != null) && (this.journal.getCurrentFile().getFileID() <= file.getFileID()))
/*     */       {
/* 314 */         HornetQJournalLogger.LOGGER.checkFiles();
/* 315 */         HornetQJournalLogger.LOGGER.info(debugFiles());
/* 316 */         HornetQJournalLogger.LOGGER.currentFile(Long.valueOf(file.getFileID()), Long.valueOf(this.journal.getCurrentFile().getFileID()), Long.valueOf(file.getFileID()), Boolean.valueOf(this.journal.getCurrentFile() == file));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 322 */       if (this.journal.getCurrentFile() == file)
/*     */       {
/* 324 */         throw new RuntimeException("Check failure! Current file listed as data file!");
/*     */       }
/*     */       
/* 327 */       seq = file.getFileID();
/*     */     }
/*     */     
/* 330 */     long lastFreeId = -1L;
/* 331 */     for (JournalFile file : this.freeFiles)
/*     */     {
/* 333 */       if (file.getFileID() <= lastFreeId)
/*     */       {
/* 335 */         HornetQJournalLogger.LOGGER.checkFiles();
/* 336 */         HornetQJournalLogger.LOGGER.info(debugFiles());
/* 337 */         HornetQJournalLogger.LOGGER.fileIdOutOfOrder();
/*     */         
/* 339 */         throw new RuntimeException("Check failure!");
/*     */       }
/*     */       
/* 342 */       lastFreeId = file.getFileID();
/*     */       
/* 344 */       if (file.getFileID() < seq)
/*     */       {
/* 346 */         HornetQJournalLogger.LOGGER.checkFiles();
/* 347 */         HornetQJournalLogger.LOGGER.info(debugFiles());
/* 348 */         HornetQJournalLogger.LOGGER.fileTooSmall();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addDataFileOnBottom(JournalFile file)
/*     */   {
/* 357 */     this.dataFiles.add(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFreeFilesCount()
/*     */   {
/* 369 */     return this.freeFiles.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addFreeFile(JournalFile file, boolean renameTmp)
/*     */     throws Exception
/*     */   {
/* 378 */     addFreeFile(file, renameTmp, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void addFreeFile(JournalFile file, boolean renameTmp, boolean checkDelete)
/*     */     throws Exception
/*     */   {
/* 389 */     long calculatedSize = 0L;
/*     */     try
/*     */     {
/* 392 */       calculatedSize = file.getFile().size();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 396 */       e.printStackTrace();
/* 397 */       System.out.println("Can't get file size on " + file);
/* 398 */       System.exit(-1);
/*     */     }
/* 400 */     if (calculatedSize != this.fileSize)
/*     */     {
/* 402 */       HornetQJournalLogger.LOGGER.deletingFile(file);
/* 403 */       file.getFile().delete();
/*     */ 
/*     */ 
/*     */     }
/* 407 */     else if ((!checkDelete) || (this.freeFiles.size() + this.dataFiles.size() + 1 + this.openedFiles.size() < this.minFiles))
/*     */     {
/*     */ 
/*     */ 
/* 411 */       if (trace)
/*     */       {
/* 413 */         trace("Adding free file " + file);
/*     */       }
/*     */       
/* 416 */       JournalFile jf = reinitializeFile(file);
/*     */       
/* 418 */       if (renameTmp)
/*     */       {
/* 420 */         jf.getFile().renameTo(JournalImpl.renameExtensionFile(jf.getFile().getFileName(), ".tmp"));
/*     */       }
/*     */       
/* 423 */       this.freeFiles.add(jf);
/*     */     }
/*     */     else
/*     */     {
/* 427 */       if (trace)
/*     */       {
/* 429 */         HornetQJournalLogger.LOGGER.trace("DataFiles.size() = " + this.dataFiles.size());
/* 430 */         HornetQJournalLogger.LOGGER.trace("openedFiles.size() = " + this.openedFiles.size());
/* 431 */         HornetQJournalLogger.LOGGER.trace("minfiles = " + this.minFiles);
/* 432 */         HornetQJournalLogger.LOGGER.trace("Free Files = " + this.freeFiles.size());
/* 433 */         HornetQJournalLogger.LOGGER.trace("File " + file + " being deleted as freeFiles.size() + dataFiles.size() + 1 + openedFiles.size() (" + (this.freeFiles.size() + this.dataFiles.size() + 1 + this.openedFiles.size()) + ") < minFiles (" + this.minFiles + ")");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 438 */       file.getFile().delete();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Collection<JournalFile> getFreeFiles()
/*     */   {
/* 449 */     return this.freeFiles;
/*     */   }
/*     */   
/*     */   public JournalFile getFreeFile()
/*     */   {
/* 454 */     return (JournalFile)this.freeFiles.remove();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getOpenedFilesCount()
/*     */   {
/* 461 */     return this.openedFiles.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalFile openFile()
/*     */     throws InterruptedException
/*     */   {
/* 471 */     if (trace)
/*     */     {
/* 473 */       trace("enqueueOpenFile with openedFiles.size=" + this.openedFiles.size());
/*     */     }
/*     */     
/* 476 */     if (this.openFilesExecutor == null)
/*     */     {
/* 478 */       this.pushOpenRunnable.run();
/*     */     }
/*     */     else
/*     */     {
/* 482 */       this.openFilesExecutor.execute(this.pushOpenRunnable);
/*     */     }
/*     */     
/* 485 */     JournalFile nextFile = null;
/*     */     
/* 487 */     while (nextFile == null)
/*     */     {
/* 489 */       nextFile = (JournalFile)this.openedFiles.poll(5L, TimeUnit.SECONDS);
/* 490 */       if (nextFile == null)
/*     */       {
/* 492 */         HornetQJournalLogger.LOGGER.errorOpeningFile(new Exception("trace"));
/*     */       }
/*     */     }
/*     */     
/* 496 */     if (trace)
/*     */     {
/* 498 */       trace("Returning file " + nextFile);
/*     */     }
/*     */     
/* 501 */     return nextFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void pushOpenedFile()
/*     */     throws Exception
/*     */   {
/* 509 */     JournalFile nextOpenedFile = takeFile(true, true, true, false);
/*     */     
/* 511 */     if (trace)
/*     */     {
/* 513 */       trace("pushing openFile " + nextOpenedFile);
/*     */     }
/*     */     
/* 516 */     if (!this.openedFiles.offer(nextOpenedFile))
/*     */     {
/* 518 */       HornetQJournalLogger.LOGGER.failedToAddFile(nextOpenedFile);
/*     */     }
/*     */   }
/*     */   
/*     */   public void closeFile(JournalFile file) throws Exception
/*     */   {
/* 524 */     this.fileFactory.deactivateBuffer();
/* 525 */     file.getFile().close();
/* 526 */     this.dataFiles.add(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalFile takeFile(boolean keepOpened, boolean multiAIO, boolean initFile, boolean tmpCompactExtension)
/*     */     throws Exception
/*     */   {
/* 541 */     JournalFile nextFile = null;
/*     */     
/* 543 */     nextFile = (JournalFile)this.freeFiles.poll();
/*     */     
/* 545 */     if (nextFile == null)
/*     */     {
/* 547 */       nextFile = createFile(keepOpened, multiAIO, initFile, tmpCompactExtension, -1L);
/*     */     }
/*     */     else
/*     */     {
/* 551 */       if (tmpCompactExtension)
/*     */       {
/* 553 */         SequentialFile sequentialFile = nextFile.getFile();
/* 554 */         sequentialFile.renameTo(sequentialFile.getFileName() + ".cmp");
/*     */       }
/*     */       
/* 557 */       if (keepOpened)
/*     */       {
/* 559 */         openFile(nextFile, multiAIO);
/*     */       }
/*     */     }
/* 562 */     return nextFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalFile createRemoteBackupSyncFile(long fileID)
/*     */     throws Exception
/*     */   {
/* 575 */     return createFile(false, false, true, false, fileID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JournalFile createFile(boolean keepOpened, boolean multiAIO, boolean init, boolean tmpCompact, long fileIdPreSet)
/*     */     throws Exception
/*     */   {
/* 591 */     long fileID = fileIdPreSet != -1L ? fileIdPreSet : generateFileID();
/*     */     
/* 593 */     String fileName = createFileName(tmpCompact, fileID);
/*     */     
/* 595 */     if (trace)
/*     */     {
/* 597 */       trace("Creating file " + fileName);
/*     */     }
/*     */     
/* 600 */     String tmpFileName = fileName + ".tmp";
/*     */     
/* 602 */     SequentialFile sequentialFile = this.fileFactory.createSequentialFile(tmpFileName, this.maxAIO);
/*     */     
/* 604 */     sequentialFile.open(1, false);
/*     */     
/* 606 */     if (init)
/*     */     {
/* 608 */       sequentialFile.fill(0, this.fileSize, (byte)74);
/*     */       
/* 610 */       JournalImpl.initFileHeader(this.fileFactory, sequentialFile, this.userVersion, fileID);
/*     */     }
/*     */     
/* 613 */     long position = sequentialFile.position();
/*     */     
/* 615 */     sequentialFile.close();
/*     */     
/* 617 */     if (trace)
/*     */     {
/* 619 */       trace("Renaming file " + tmpFileName + " as " + fileName);
/*     */     }
/*     */     
/* 622 */     sequentialFile.renameTo(fileName);
/*     */     
/* 624 */     if (keepOpened)
/*     */     {
/* 626 */       if (multiAIO)
/*     */       {
/* 628 */         sequentialFile.open();
/*     */       }
/*     */       else
/*     */       {
/* 632 */         sequentialFile.open(1, false);
/*     */       }
/* 634 */       sequentialFile.position(position);
/*     */     }
/*     */     
/* 637 */     return new JournalFileImpl(sequentialFile, fileID, 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String createFileName(boolean tmpCompact, long fileID)
/*     */   {
/*     */     String fileName;
/*     */     
/*     */     String fileName;
/*     */     
/* 648 */     if (tmpCompact)
/*     */     {
/* 650 */       fileName = this.filePrefix + "-" + fileID + "." + this.fileExtension + ".cmp";
/*     */     }
/*     */     else
/*     */     {
/* 654 */       fileName = this.filePrefix + "-" + fileID + "." + this.fileExtension;
/*     */     }
/* 656 */     return fileName;
/*     */   }
/*     */   
/*     */   private long generateFileID()
/*     */   {
/* 661 */     return this.nextFileID.incrementAndGet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private long getFileNameID(String fileName)
/*     */   {
/*     */     try
/*     */     {
/* 671 */       return Long.parseLong(fileName.substring(this.filePrefix.length() + 1, fileName.indexOf('.')));
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 675 */       HornetQJournalLogger.LOGGER.errorRetrievingID(e, fileName); }
/* 676 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */   private JournalFile reinitializeFile(JournalFile file)
/*     */     throws Exception
/*     */   {
/* 683 */     long newFileID = generateFileID();
/*     */     
/* 685 */     SequentialFile sf = file.getFile();
/*     */     
/* 687 */     sf.open(1, false);
/*     */     
/* 689 */     int position = JournalImpl.initFileHeader(this.fileFactory, sf, this.userVersion, newFileID);
/*     */     
/* 691 */     JournalFile jf = new JournalFileImpl(sf, newFileID, 2);
/*     */     
/* 693 */     sf.position(position);
/*     */     
/* 695 */     sf.close();
/*     */     
/* 697 */     return jf;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 703 */     return "JournalFilesRepository(dataFiles=" + this.dataFiles + ", freeFiles=" + this.freeFiles + ", openedFiles=" + this.openedFiles + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalFilesRepository.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */