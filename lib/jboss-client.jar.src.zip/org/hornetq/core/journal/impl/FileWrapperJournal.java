/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQUnsupportedPacketException;
/*     */ import org.hornetq.core.journal.EncodingSupport;
/*     */ import org.hornetq.core.journal.IOCompletion;
/*     */ import org.hornetq.core.journal.Journal;
/*     */ import org.hornetq.core.journal.Journal.JournalState;
/*     */ import org.hornetq.core.journal.JournalLoadInformation;
/*     */ import org.hornetq.core.journal.LoaderCallback;
/*     */ import org.hornetq.core.journal.PreparedTransactionInfo;
/*     */ import org.hornetq.core.journal.RecordInfo;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.core.journal.TransactionFailureCallback;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecord;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecordTX;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalCompleteRecordTX;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalCompleteRecordTX.TX_RECORD_TYPE;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalDeleteRecord;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalDeleteRecordTX;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalInternalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FileWrapperJournal
/*     */   extends JournalBase
/*     */ {
/*  37 */   private final ReentrantLock lockAppend = new ReentrantLock();
/*     */   
/*  39 */   private final ConcurrentMap<Long, AtomicInteger> transactions = new ConcurrentHashMap();
/*     */   
/*     */   private final JournalImpl journal;
/*     */   
/*     */   protected volatile JournalFile currentFile;
/*     */   
/*     */ 
/*     */   public FileWrapperJournal(Journal journal)
/*     */     throws Exception
/*     */   {
/*  49 */     super(journal.getFileFactory().isSupportsCallbacks(), journal.getFileSize());
/*  50 */     this.journal = ((JournalImpl)journal);
/*  51 */     this.currentFile = this.journal.setUpCurrentFile(16);
/*     */   }
/*     */   
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/*  57 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */     throws Exception
/*     */   {
/*  63 */     if (this.currentFile.getFile().isOpen()) {
/*  64 */       this.currentFile.getFile().close();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isStarted()
/*     */   {
/*  70 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void appendAddRecord(long id, byte recordType, EncodingSupport record, boolean sync, IOCompletion callback)
/*     */     throws Exception
/*     */   {
/*  81 */     JournalInternalRecord addRecord = new JournalAddRecord(true, id, recordType, record);
/*     */     
/*  83 */     writeRecord(addRecord, sync, callback);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeRecord(JournalInternalRecord encoder, boolean sync, IOCompletion callback)
/*     */     throws Exception
/*     */   {
/*  93 */     this.lockAppend.lock();
/*     */     try
/*     */     {
/*  96 */       if (callback != null)
/*     */       {
/*  98 */         callback.storeLineUp();
/*     */       }
/* 100 */       this.currentFile = this.journal.switchFileIfNecessary(encoder.getEncodeSize());
/* 101 */       encoder.setFileID(this.currentFile.getRecordID());
/*     */       
/* 103 */       if (callback != null)
/*     */       {
/* 105 */         this.currentFile.getFile().write(encoder, sync, callback);
/*     */       }
/*     */       else
/*     */       {
/* 109 */         this.currentFile.getFile().write(encoder, sync);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 114 */       this.lockAppend.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendDeleteRecord(long id, boolean sync, IOCompletion callback)
/*     */     throws Exception
/*     */   {
/* 121 */     JournalInternalRecord deleteRecord = new JournalDeleteRecord(id);
/* 122 */     writeRecord(deleteRecord, sync, callback);
/*     */   }
/*     */   
/*     */   public void appendDeleteRecordTransactional(long txID, long id, EncodingSupport record)
/*     */     throws Exception
/*     */   {
/* 128 */     count(txID);
/* 129 */     JournalInternalRecord deleteRecordTX = new JournalDeleteRecordTX(txID, id, record);
/* 130 */     writeRecord(deleteRecordTX, false, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void appendAddRecordTransactional(long txID, long id, byte recordType, EncodingSupport record)
/*     */     throws Exception
/*     */   {
/* 137 */     count(txID);
/* 138 */     JournalInternalRecord addRecord = new JournalAddRecordTX(true, txID, id, recordType, record);
/* 139 */     writeRecord(addRecord, false, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void appendUpdateRecord(long id, byte recordType, EncodingSupport record, boolean sync, IOCompletion callback)
/*     */     throws Exception
/*     */   {
/* 147 */     JournalInternalRecord updateRecord = new JournalAddRecord(false, id, recordType, record);
/* 148 */     writeRecord(updateRecord, sync, callback);
/*     */   }
/*     */   
/*     */ 
/*     */   public void appendUpdateRecordTransactional(long txID, long id, byte recordType, EncodingSupport record)
/*     */     throws Exception
/*     */   {
/* 155 */     count(txID);
/* 156 */     JournalInternalRecord updateRecordTX = new JournalAddRecordTX(false, txID, id, recordType, record);
/* 157 */     writeRecord(updateRecordTX, false, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void appendCommitRecord(long txID, boolean sync, IOCompletion callback, boolean lineUpContext)
/*     */     throws Exception
/*     */   {
/* 164 */     JournalInternalRecord commitRecord = new JournalCompleteRecordTX(JournalCompleteRecordTX.TX_RECORD_TYPE.COMMIT, txID, null);
/* 165 */     AtomicInteger value = (AtomicInteger)this.transactions.remove(Long.valueOf(txID));
/* 166 */     if (value != null)
/*     */     {
/* 168 */       commitRecord.setNumberOfRecords(value.get());
/*     */     }
/*     */     
/* 171 */     writeRecord(commitRecord, true, callback);
/*     */   }
/*     */   
/*     */ 
/*     */   public void appendPrepareRecord(long txID, EncodingSupport transactionData, boolean sync, IOCompletion callback)
/*     */     throws Exception
/*     */   {
/* 178 */     JournalInternalRecord prepareRecord = new JournalCompleteRecordTX(JournalCompleteRecordTX.TX_RECORD_TYPE.PREPARE, txID, transactionData);
/* 179 */     AtomicInteger value = (AtomicInteger)this.transactions.get(Long.valueOf(txID));
/* 180 */     if (value != null)
/*     */     {
/* 182 */       prepareRecord.setNumberOfRecords(value.get());
/*     */     }
/* 184 */     writeRecord(prepareRecord, sync, callback);
/*     */   }
/*     */   
/*     */   private int count(long txID) throws HornetQException
/*     */   {
/* 189 */     AtomicInteger defaultValue = new AtomicInteger(1);
/* 190 */     AtomicInteger count = (AtomicInteger)this.transactions.putIfAbsent(Long.valueOf(txID), defaultValue);
/* 191 */     if (count != null)
/*     */     {
/* 193 */       return count.incrementAndGet();
/*     */     }
/* 195 */     return defaultValue.get();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 201 */     return FileWrapperJournal.class.getName() + "(currentFile=[" + this.currentFile + "], hash=" + super.toString() + ")";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void appendRollbackRecord(long txID, boolean sync, IOCompletion callback)
/*     */     throws Exception
/*     */   {
/* 209 */     throw new HornetQUnsupportedPacketException();
/*     */   }
/*     */   
/*     */   public JournalLoadInformation load(LoaderCallback reloadManager)
/*     */     throws Exception
/*     */   {
/* 215 */     throw new HornetQUnsupportedPacketException();
/*     */   }
/*     */   
/*     */   public JournalLoadInformation loadInternalOnly()
/*     */     throws Exception
/*     */   {
/* 221 */     throw new HornetQUnsupportedPacketException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void lineUpContext(IOCompletion callback)
/*     */   {
/* 227 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JournalLoadInformation load(List<RecordInfo> committedRecords, List<PreparedTransactionInfo> preparedTransactions, TransactionFailureCallback transactionFailure)
/*     */     throws Exception
/*     */   {
/* 235 */     throw new HornetQUnsupportedPacketException();
/*     */   }
/*     */   
/*     */   public int getAlignment()
/*     */     throws Exception
/*     */   {
/* 241 */     throw new HornetQUnsupportedPacketException();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getNumberOfRecords()
/*     */   {
/* 247 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getUserVersion()
/*     */   {
/* 253 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void perfBlast(int pages)
/*     */   {
/* 259 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void runDirectJournalBlast()
/*     */     throws Exception
/*     */   {
/* 265 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public JournalLoadInformation loadSyncOnly(Journal.JournalState state)
/*     */     throws Exception
/*     */   {
/* 271 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public Map<Long, JournalFile> createFilesForBackupSync(long[] fileIds)
/*     */     throws Exception
/*     */   {
/* 277 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void synchronizationLock()
/*     */   {
/* 283 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void synchronizationUnlock()
/*     */   {
/* 289 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void forceMoveNextFile()
/*     */   {
/* 295 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public JournalFile[] getDataFiles()
/*     */   {
/* 301 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void scheduleReclaim() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public SequentialFileFactory getFileFactory()
/*     */   {
/* 313 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public void scheduleCompactAndBlock(int timeout)
/*     */     throws Exception
/*     */   {
/* 319 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void replicationSyncPreserveOldFiles()
/*     */   {
/* 325 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void replicationSyncFinished()
/*     */   {
/* 331 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\FileWrapperJournal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */