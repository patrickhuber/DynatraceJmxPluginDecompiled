/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JournalFileImpl
/*     */   implements JournalFile
/*     */ {
/*     */   private final SequentialFile file;
/*     */   private final long fileID;
/*     */   private final int recordID;
/*     */   private long offset;
/*  41 */   private final AtomicInteger posCount = new AtomicInteger(0);
/*     */   
/*  43 */   private final AtomicInteger liveBytes = new AtomicInteger(0);
/*     */   
/*     */   private boolean canReclaim;
/*     */   
/*  47 */   private final AtomicInteger totalNegativeToOthers = new AtomicInteger(0);
/*     */   
/*     */   private final int version;
/*     */   
/*  51 */   private final Map<JournalFile, AtomicInteger> negCounts = new ConcurrentHashMap();
/*     */   
/*     */   public JournalFileImpl(SequentialFile file, long fileID, int version)
/*     */   {
/*  55 */     this.file = file;
/*     */     
/*  57 */     this.fileID = fileID;
/*     */     
/*  59 */     this.version = version;
/*     */     
/*  61 */     this.recordID = ((int)(fileID & 0x7FFFFFFF));
/*     */   }
/*     */   
/*     */   public int getPosCount()
/*     */   {
/*  66 */     return this.posCount.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isCanReclaim()
/*     */   {
/*  72 */     return this.canReclaim;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCanReclaim(boolean canReclaim)
/*     */   {
/*  78 */     this.canReclaim = canReclaim;
/*     */   }
/*     */   
/*     */   public void incNegCount(JournalFile file)
/*     */   {
/*  83 */     if (file != this)
/*     */     {
/*  85 */       this.totalNegativeToOthers.incrementAndGet();
/*     */     }
/*  87 */     getOrCreateNegCount(file).incrementAndGet();
/*     */   }
/*     */   
/*     */   public int getNegCount(JournalFile file)
/*     */   {
/*  92 */     AtomicInteger count = (AtomicInteger)this.negCounts.get(file);
/*     */     
/*  94 */     if (count == null)
/*     */     {
/*  96 */       return 0;
/*     */     }
/*     */     
/*     */ 
/* 100 */     return count.intValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getJournalVersion()
/*     */   {
/* 106 */     return this.version;
/*     */   }
/*     */   
/*     */   public void incPosCount()
/*     */   {
/* 111 */     this.posCount.incrementAndGet();
/*     */   }
/*     */   
/*     */   public void decPosCount()
/*     */   {
/* 116 */     this.posCount.decrementAndGet();
/*     */   }
/*     */   
/*     */   public long getOffset()
/*     */   {
/* 121 */     return this.offset;
/*     */   }
/*     */   
/*     */   public long getFileID()
/*     */   {
/* 126 */     return this.fileID;
/*     */   }
/*     */   
/*     */   public int getRecordID()
/*     */   {
/* 131 */     return this.recordID;
/*     */   }
/*     */   
/*     */   public void setOffset(long offset)
/*     */   {
/* 136 */     this.offset = offset;
/*     */   }
/*     */   
/*     */   public SequentialFile getFile()
/*     */   {
/* 141 */     return this.file;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*     */     try
/*     */     {
/* 149 */       return "JournalFileImpl: (" + this.file.getFileName() + " id = " + this.fileID + ", recordID = " + this.recordID + ")";
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 153 */       e.printStackTrace();
/* 154 */       return "Error:" + e.toString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String debug()
/*     */   {
/* 161 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 163 */     for (Map.Entry<JournalFile, AtomicInteger> entry : this.negCounts.entrySet())
/*     */     {
/* 165 */       builder.append(" file = " + entry.getKey() + " negcount value = " + entry.getValue() + "\n");
/*     */     }
/*     */     
/* 168 */     return builder.toString();
/*     */   }
/*     */   
/*     */   private synchronized AtomicInteger getOrCreateNegCount(JournalFile file)
/*     */   {
/* 173 */     AtomicInteger count = (AtomicInteger)this.negCounts.get(file);
/*     */     
/* 175 */     if (count == null)
/*     */     {
/* 177 */       count = new AtomicInteger();
/* 178 */       this.negCounts.put(file, count);
/*     */     }
/*     */     
/* 181 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addSize(int bytes)
/*     */   {
/* 187 */     this.liveBytes.addAndGet(bytes);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decSize(int bytes)
/*     */   {
/* 193 */     this.liveBytes.addAndGet(-bytes);
/*     */   }
/*     */   
/*     */ 
/*     */   public int getLiveSize()
/*     */   {
/* 199 */     return this.liveBytes.get();
/*     */   }
/*     */   
/*     */   public int getTotalNegativeToOthers()
/*     */   {
/* 204 */     return this.totalNegativeToOthers.get();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalFileImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */