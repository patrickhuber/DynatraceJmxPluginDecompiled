/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.core.asyncio.BufferCallback;
/*     */ import org.hornetq.core.asyncio.impl.AsynchronousFileImpl;
/*     */ import org.hornetq.core.journal.IOCriticalErrorListener;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ import org.hornetq.utils.HornetQThreadFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AIOSequentialFileFactory
/*     */   extends AbstractSequentialFileFactory
/*     */ {
/*  39 */   private static final boolean trace = HornetQJournalLogger.LOGGER.isTraceEnabled();
/*     */   
/*  41 */   private final ReuseBuffersController buffersControl = new ReuseBuffersController(null);
/*     */   
/*     */ 
/*     */   private ExecutorService pollerExecutor;
/*     */   
/*     */ 
/*     */ 
/*     */   private static void trace(String message)
/*     */   {
/*  50 */     HornetQJournalLogger.LOGGER.trace(message);
/*     */   }
/*     */   
/*     */   public AIOSequentialFileFactory(String journalDir)
/*     */   {
/*  55 */     this(journalDir, 501760, 500000, false, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AIOSequentialFileFactory(String journalDir, IOCriticalErrorListener listener)
/*     */   {
/*  64 */     this(journalDir, 501760, 500000, false, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AIOSequentialFileFactory(String journalDir, int bufferSize, int bufferTimeout, boolean logRates)
/*     */   {
/*  76 */     this(journalDir, bufferSize, bufferTimeout, logRates, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AIOSequentialFileFactory(String journalDir, int bufferSize, int bufferTimeout, boolean logRates, IOCriticalErrorListener listener)
/*     */   {
/*  85 */     super(journalDir, true, bufferSize, bufferTimeout, logRates, listener);
/*     */   }
/*     */   
/*     */   public SequentialFile createSequentialFile(String fileName, int maxIO)
/*     */   {
/*  90 */     return new AIOSequentialFile(this, this.bufferSize, this.bufferTimeout, this.journalDir, fileName, maxIO, this.buffersControl.callback, this.writeExecutor, this.pollerExecutor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSupportsCallbacks()
/*     */   {
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isSupported()
/*     */   {
/* 108 */     return AsynchronousFileImpl.isLoaded();
/*     */   }
/*     */   
/*     */ 
/*     */   public ByteBuffer allocateDirectBuffer(int size)
/*     */   {
/* 114 */     int blocks = size / 512;
/* 115 */     if (size % 512 != 0)
/*     */     {
/* 117 */       blocks++;
/*     */     }
/*     */     
/*     */ 
/* 121 */     ByteBuffer buffer = AsynchronousFileImpl.newBuffer(blocks * 512);
/*     */     
/* 123 */     buffer.limit(size);
/*     */     
/* 125 */     return buffer;
/*     */   }
/*     */   
/*     */   public void releaseDirectBuffer(ByteBuffer buffer)
/*     */   {
/* 130 */     AsynchronousFileImpl.destroyBuffer(buffer);
/*     */   }
/*     */   
/*     */   public ByteBuffer newBuffer(int size)
/*     */   {
/* 135 */     if (size % 512 != 0)
/*     */     {
/* 137 */       size = (size / 512 + 1) * 512;
/*     */     }
/*     */     
/* 140 */     return this.buffersControl.newBuffer(size);
/*     */   }
/*     */   
/*     */   public void clearBuffer(ByteBuffer directByteBuffer)
/*     */   {
/* 145 */     AsynchronousFileImpl.clearBuffer(directByteBuffer);
/*     */   }
/*     */   
/*     */   public int getAlignment()
/*     */   {
/* 150 */     return 512;
/*     */   }
/*     */   
/*     */ 
/*     */   public ByteBuffer wrapBuffer(byte[] bytes)
/*     */   {
/* 156 */     ByteBuffer newbuffer = newBuffer(bytes.length);
/* 157 */     newbuffer.put(bytes);
/* 158 */     return newbuffer;
/*     */   }
/*     */   
/*     */   public int calculateBlockSize(int position)
/*     */   {
/* 163 */     int alignment = getAlignment();
/*     */     
/* 165 */     int pos = (position / alignment + (position % alignment != 0 ? 1 : 0)) * alignment;
/*     */     
/* 167 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void releaseBuffer(ByteBuffer buffer)
/*     */   {
/* 176 */     AsynchronousFileImpl.destroyBuffer(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */   public void start()
/*     */   {
/* 182 */     super.start();
/*     */     
/* 184 */     this.pollerExecutor = Executors.newCachedThreadPool(new HornetQThreadFactory("HornetQ-AIO-poller-pool" + System.identityHashCode(this), true, getThisClassLoader()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 193 */     this.buffersControl.stop();
/*     */     
/* 195 */     if (this.pollerExecutor != null)
/*     */     {
/* 197 */       this.pollerExecutor.shutdown();
/*     */       
/*     */       try
/*     */       {
/* 201 */         if (!this.pollerExecutor.awaitTermination(60L, TimeUnit.SECONDS))
/*     */         {
/* 203 */           HornetQJournalLogger.LOGGER.timeoutOnPollerShutdown(new Exception("trace"));
/*     */         }
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 208 */         throw new HornetQInterruptedException(e);
/*     */       }
/*     */     }
/*     */     
/* 212 */     super.stop();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 218 */   protected void finalize() { stop(); }
/*     */   
/*     */   private class ReuseBuffersController {
/*     */     private volatile long bufferReuseLastTime;
/*     */     private final ConcurrentLinkedQueue<ByteBuffer> reuseBuffersQueue;
/*     */     private boolean stopped;
/*     */     final BufferCallback callback;
/*     */     
/* 226 */     private ReuseBuffersController() { this.bufferReuseLastTime = System.currentTimeMillis();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */       this.reuseBuffersQueue = new ConcurrentLinkedQueue();
/*     */       
/* 235 */       this.stopped = false;
/*     */       
/* 237 */       this.callback = new LocalBufferCallback(null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public ByteBuffer newBuffer(int size)
/*     */     {
/* 244 */       if ((AIOSequentialFileFactory.this.bufferSize > 0) && (System.currentTimeMillis() - this.bufferReuseLastTime > 10000L))
/*     */       {
/* 246 */         if (AIOSequentialFileFactory.trace)
/*     */         {
/* 248 */           AIOSequentialFileFactory.trace("Clearing reuse buffers queue with " + this.reuseBuffersQueue.size() + " elements");
/*     */         }
/*     */         
/*     */ 
/* 252 */         this.bufferReuseLastTime = System.currentTimeMillis();
/*     */         
/* 254 */         clearPoll();
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 259 */       if (size > AIOSequentialFileFactory.this.bufferSize)
/*     */       {
/* 261 */         return AsynchronousFileImpl.newBuffer(size);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 267 */       int alignedSize = AIOSequentialFileFactory.this.calculateBlockSize(size);
/*     */       
/*     */ 
/* 270 */       ByteBuffer buffer = (ByteBuffer)this.reuseBuffersQueue.poll();
/*     */       
/* 272 */       if (buffer == null)
/*     */       {
/*     */ 
/* 275 */         buffer = AsynchronousFileImpl.newBuffer(AIOSequentialFileFactory.this.bufferSize);
/*     */         
/* 277 */         buffer.limit(alignedSize);
/*     */       }
/*     */       else
/*     */       {
/* 281 */         AIOSequentialFileFactory.this.clearBuffer(buffer);
/*     */         
/*     */ 
/* 284 */         buffer.limit(alignedSize);
/*     */       }
/*     */       
/* 287 */       buffer.rewind();
/*     */       
/* 289 */       return buffer;
/*     */     }
/*     */     
/*     */ 
/*     */     public synchronized void stop()
/*     */     {
/* 295 */       this.stopped = true;
/* 296 */       clearPoll();
/*     */     }
/*     */     
/*     */ 
/*     */     public synchronized void clearPoll()
/*     */     {
/*     */       ByteBuffer reusedBuffer;
/* 303 */       while ((reusedBuffer = (ByteBuffer)this.reuseBuffersQueue.poll()) != null)
/*     */       {
/* 305 */         AIOSequentialFileFactory.this.releaseBuffer(reusedBuffer);
/*     */       }
/*     */     }
/*     */     
/*     */     private class LocalBufferCallback implements BufferCallback {
/*     */       private LocalBufferCallback() {}
/*     */       
/*     */       public void bufferDone(ByteBuffer buffer) {
/* 313 */         synchronized (AIOSequentialFileFactory.ReuseBuffersController.this)
/*     */         {
/*     */ 
/* 316 */           if (AIOSequentialFileFactory.ReuseBuffersController.this.stopped)
/*     */           {
/* 318 */             AIOSequentialFileFactory.this.releaseBuffer(buffer);
/*     */           }
/*     */           else
/*     */           {
/* 322 */             AIOSequentialFileFactory.ReuseBuffersController.this.bufferReuseLastTime = System.currentTimeMillis();
/*     */             
/*     */ 
/*     */ 
/* 326 */             if (buffer.capacity() == AIOSequentialFileFactory.this.bufferSize)
/*     */             {
/* 328 */               AIOSequentialFileFactory.ReuseBuffersController.this.reuseBuffersQueue.offer(buffer);
/*     */             }
/*     */             else
/*     */             {
/* 332 */               AIOSequentialFileFactory.this.releaseBuffer(buffer);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static ClassLoader getThisClassLoader()
/*     */   {
/* 342 */     (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public ClassLoader run()
/*     */       {
/* 346 */         return AIOSequentialFileFactory.class.getClassLoader();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 355 */     return AIOSequentialFileFactory.class.getSimpleName() + "(buffersControl.stopped=" + this.buffersControl.stopped + "):" + super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\AIOSequentialFileFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */