/*    */ package org.hornetq.core.journal.impl.dataformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.journal.EncodingSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayEncoding
/*    */   implements EncodingSupport
/*    */ {
/*    */   final byte[] data;
/*    */   
/*    */   public ByteArrayEncoding(byte[] data)
/*    */   {
/* 33 */     this.data = data;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void decode(HornetQBuffer buffer)
/*    */   {
/* 40 */     throw new IllegalStateException("operation not supported");
/*    */   }
/*    */   
/*    */   public void encode(HornetQBuffer buffer)
/*    */   {
/* 45 */     buffer.writeBytes(this.data);
/*    */   }
/*    */   
/*    */   public int getEncodeSize()
/*    */   {
/* 50 */     return this.data.length;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\ByteArrayEncoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */