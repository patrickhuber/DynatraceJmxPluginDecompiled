/*    */ package org.hornetq.core.journal.impl.dataformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.journal.EncodingSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JournalDeleteRecordTX
/*    */   extends JournalInternalRecord
/*    */ {
/*    */   private final long txID;
/*    */   private final long id;
/*    */   private final EncodingSupport record;
/*    */   
/*    */   public JournalDeleteRecordTX(long txID, long id, EncodingSupport record)
/*    */   {
/* 43 */     this.id = id;
/*    */     
/* 45 */     this.txID = txID;
/*    */     
/* 47 */     this.record = record;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encode(HornetQBuffer buffer)
/*    */   {
/* 53 */     buffer.writeByte((byte)15);
/*    */     
/* 55 */     buffer.writeInt(this.fileID);
/*    */     
/* 57 */     buffer.writeByte(this.compactCount);
/*    */     
/* 59 */     buffer.writeLong(this.txID);
/*    */     
/* 61 */     buffer.writeLong(this.id);
/*    */     
/* 63 */     buffer.writeInt(this.record != null ? this.record.getEncodeSize() : 0);
/*    */     
/* 65 */     if (this.record != null)
/*    */     {
/* 67 */       this.record.encode(buffer);
/*    */     }
/*    */     
/* 70 */     buffer.writeInt(getEncodeSize());
/*    */   }
/*    */   
/*    */ 
/*    */   public int getEncodeSize()
/*    */   {
/* 76 */     return 29 + (this.record != null ? this.record.getEncodeSize() : 0) + 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\JournalDeleteRecordTX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */