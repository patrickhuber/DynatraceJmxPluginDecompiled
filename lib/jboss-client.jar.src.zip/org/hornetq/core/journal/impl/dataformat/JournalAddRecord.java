/*    */ package org.hornetq.core.journal.impl.dataformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.journal.EncodingSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JournalAddRecord
/*    */   extends JournalInternalRecord
/*    */ {
/*    */   private final long id;
/*    */   private final EncodingSupport record;
/*    */   private final byte recordType;
/*    */   private final boolean add;
/*    */   
/*    */   public JournalAddRecord(boolean add, long id, byte recordType, EncodingSupport record)
/*    */   {
/* 45 */     this.id = id;
/*    */     
/* 47 */     this.record = record;
/*    */     
/* 49 */     this.recordType = recordType;
/*    */     
/* 51 */     this.add = add;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encode(HornetQBuffer buffer)
/*    */   {
/* 57 */     if (this.add)
/*    */     {
/* 59 */       buffer.writeByte((byte)11);
/*    */     }
/*    */     else
/*    */     {
/* 63 */       buffer.writeByte((byte)12);
/*    */     }
/*    */     
/* 66 */     buffer.writeInt(this.fileID);
/*    */     
/* 68 */     buffer.writeByte(this.compactCount);
/*    */     
/* 70 */     buffer.writeLong(this.id);
/*    */     
/* 72 */     buffer.writeInt(this.record.getEncodeSize());
/*    */     
/* 74 */     buffer.writeByte(this.recordType);
/*    */     
/* 76 */     this.record.encode(buffer);
/*    */     
/* 78 */     buffer.writeInt(getEncodeSize());
/*    */   }
/*    */   
/*    */ 
/*    */   public int getEncodeSize()
/*    */   {
/* 84 */     return 22 + this.record.getEncodeSize() + 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\JournalAddRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */