/*    */ package org.hornetq.core.journal.impl.dataformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.journal.EncodingSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JournalAddRecordTX
/*    */   extends JournalInternalRecord
/*    */ {
/*    */   private final long txID;
/*    */   private final long id;
/*    */   private final EncodingSupport record;
/*    */   private final byte recordType;
/*    */   private final boolean add;
/*    */   
/*    */   public JournalAddRecordTX(boolean add, long txID, long id, byte recordType, EncodingSupport record)
/*    */   {
/* 52 */     this.txID = txID;
/*    */     
/* 54 */     this.id = id;
/*    */     
/* 56 */     this.record = record;
/*    */     
/* 58 */     this.recordType = recordType;
/*    */     
/* 60 */     this.add = add;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encode(HornetQBuffer buffer)
/*    */   {
/* 66 */     if (this.add)
/*    */     {
/* 68 */       buffer.writeByte((byte)13);
/*    */     }
/*    */     else
/*    */     {
/* 72 */       buffer.writeByte((byte)14);
/*    */     }
/*    */     
/* 75 */     buffer.writeInt(this.fileID);
/*    */     
/* 77 */     buffer.writeByte(this.compactCount);
/*    */     
/* 79 */     buffer.writeLong(this.txID);
/*    */     
/* 81 */     buffer.writeLong(this.id);
/*    */     
/* 83 */     buffer.writeInt(this.record.getEncodeSize());
/*    */     
/* 85 */     buffer.writeByte(this.recordType);
/*    */     
/* 87 */     this.record.encode(buffer);
/*    */     
/* 89 */     buffer.writeInt(getEncodeSize());
/*    */   }
/*    */   
/*    */ 
/*    */   public int getEncodeSize()
/*    */   {
/* 95 */     return 30 + this.record.getEncodeSize() + 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\JournalAddRecordTX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */