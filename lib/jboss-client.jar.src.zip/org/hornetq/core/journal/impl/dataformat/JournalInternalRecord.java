/*    */ package org.hornetq.core.journal.impl.dataformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.journal.EncodingSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JournalInternalRecord
/*    */   implements EncodingSupport
/*    */ {
/*    */   protected int fileID;
/*    */   protected byte compactCount;
/*    */   
/*    */   public int getFileID()
/*    */   {
/* 35 */     return this.fileID;
/*    */   }
/*    */   
/*    */   public void setFileID(int fileID)
/*    */   {
/* 40 */     this.fileID = fileID;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void decode(HornetQBuffer buffer) {}
/*    */   
/*    */ 
/*    */   public void setNumberOfRecords(int records) {}
/*    */   
/*    */ 
/*    */   public int getNumberOfRecords()
/*    */   {
/* 53 */     return 0;
/*    */   }
/*    */   
/*    */   public short getCompactCount()
/*    */   {
/* 58 */     return (short)this.compactCount;
/*    */   }
/*    */   
/*    */   public void setCompactCount(short compactCount)
/*    */   {
/* 63 */     if (compactCount > 127)
/*    */     {
/* 65 */       this.compactCount = Byte.MAX_VALUE;
/*    */     }
/*    */     else
/*    */     {
/* 69 */       this.compactCount = ((byte)compactCount);
/*    */     }
/*    */   }
/*    */   
/*    */   public abstract int getEncodeSize();
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\JournalInternalRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */