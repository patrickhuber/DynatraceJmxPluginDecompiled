/*    */ package org.hornetq.core.journal.impl.dataformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JournalDeleteRecord
/*    */   extends JournalInternalRecord
/*    */ {
/*    */   private final long id;
/*    */   
/*    */   public JournalDeleteRecord(long id)
/*    */   {
/* 36 */     this.id = id;
/*    */   }
/*    */   
/*    */   public void encode(HornetQBuffer buffer)
/*    */   {
/* 41 */     buffer.writeByte((byte)16);
/*    */     
/* 43 */     buffer.writeInt(this.fileID);
/*    */     
/* 45 */     buffer.writeByte(this.compactCount);
/*    */     
/* 47 */     buffer.writeLong(this.id);
/*    */     
/* 49 */     buffer.writeInt(getEncodeSize());
/*    */   }
/*    */   
/*    */ 
/*    */   public int getEncodeSize()
/*    */   {
/* 55 */     return 18;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\JournalDeleteRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */