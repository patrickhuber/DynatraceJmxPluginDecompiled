/*     */ package org.hornetq.core.journal.impl.dataformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.journal.EncodingSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JournalCompleteRecordTX
/*     */   extends JournalInternalRecord
/*     */ {
/*     */   private final TX_RECORD_TYPE txRecordType;
/*     */   private final long txID;
/*     */   private final EncodingSupport transactionData;
/*     */   private int numberOfRecords;
/*     */   
/*     */   public static enum TX_RECORD_TYPE
/*     */   {
/*  40 */     COMMIT,  PREPARE;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private TX_RECORD_TYPE() {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalCompleteRecordTX(TX_RECORD_TYPE isCommit, long txID, EncodingSupport transactionData)
/*     */   {
/*  53 */     this.txRecordType = isCommit;
/*     */     
/*  55 */     this.txID = txID;
/*     */     
/*  57 */     this.transactionData = transactionData;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encode(HornetQBuffer buffer)
/*     */   {
/*  63 */     if (this.txRecordType == TX_RECORD_TYPE.COMMIT)
/*     */     {
/*  65 */       buffer.writeByte((byte)18);
/*     */     }
/*     */     else
/*     */     {
/*  69 */       buffer.writeByte((byte)17);
/*     */     }
/*     */     
/*  72 */     buffer.writeInt(this.fileID);
/*     */     
/*  74 */     buffer.writeByte(this.compactCount);
/*     */     
/*  76 */     buffer.writeLong(this.txID);
/*     */     
/*  78 */     buffer.writeInt(this.numberOfRecords);
/*     */     
/*  80 */     if (this.transactionData != null)
/*     */     {
/*  82 */       buffer.writeInt(this.transactionData.getEncodeSize());
/*     */     }
/*     */     
/*  85 */     if (this.transactionData != null)
/*     */     {
/*  87 */       this.transactionData.encode(buffer);
/*     */     }
/*     */     
/*  90 */     buffer.writeInt(getEncodeSize());
/*     */   }
/*     */   
/*     */ 
/*     */   public void setNumberOfRecords(int records)
/*     */   {
/*  96 */     this.numberOfRecords = records;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getNumberOfRecords()
/*     */   {
/* 102 */     return this.numberOfRecords;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getEncodeSize()
/*     */   {
/* 108 */     if (this.txRecordType == TX_RECORD_TYPE.COMMIT)
/*     */     {
/* 110 */       return 22;
/*     */     }
/*     */     
/*     */ 
/* 114 */     return 25 + (this.transactionData != null ? this.transactionData.getEncodeSize() : 0) + 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\dataformat\JournalCompleteRecordTX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */