/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.Pair;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.core.journal.impl.dataformat.ByteArrayEncoding;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecord;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalInternalRecord;
/*     */ import org.hornetq.utils.ConcurrentHashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJournalUpdateTask
/*     */   implements JournalReaderCallback
/*     */ {
/*     */   protected static final String FILE_COMPACT_CONTROL = "journal-rename-control.ctr";
/*     */   protected final JournalImpl journal;
/*     */   protected final SequentialFileFactory fileFactory;
/*     */   protected JournalFile currentFile;
/*     */   protected SequentialFile sequentialFile;
/*     */   protected final JournalFilesRepository filesRepository;
/*     */   protected long nextOrderingID;
/*     */   private HornetQBuffer writingChannel;
/*  61 */   private final Set<Long> recordsSnapshot = new ConcurrentHashSet();
/*     */   
/*  63 */   protected final List<JournalFile> newDataFiles = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractJournalUpdateTask(SequentialFileFactory fileFactory, JournalImpl journal, JournalFilesRepository filesRepository, Set<Long> recordsSnapshot, long nextOrderingID)
/*     */   {
/*  76 */     this.journal = journal;
/*  77 */     this.filesRepository = filesRepository;
/*  78 */     this.fileFactory = fileFactory;
/*  79 */     this.nextOrderingID = nextOrderingID;
/*  80 */     this.recordsSnapshot.addAll(recordsSnapshot);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static SequentialFile writeControlFile(SequentialFileFactory fileFactory, List<JournalFile> files, List<JournalFile> newFiles, List<Pair<String, String>> renames)
/*     */     throws Exception
/*     */   {
/*  91 */     SequentialFile controlFile = fileFactory.createSequentialFile("journal-rename-control.ctr", 1);
/*     */     
/*     */     try
/*     */     {
/*  95 */       controlFile.open(1, false);
/*     */       
/*  97 */       JournalImpl.initFileHeader(fileFactory, controlFile, 0, 0L);
/*     */       
/*  99 */       HornetQBuffer filesToRename = HornetQBuffers.dynamicBuffer(1);
/*     */       
/*     */ 
/*     */ 
/* 103 */       if (files == null)
/*     */       {
/* 105 */         filesToRename.writeInt(0);
/*     */       }
/*     */       else
/*     */       {
/* 109 */         filesToRename.writeInt(files.size());
/*     */         
/* 111 */         for (JournalFile file : files)
/*     */         {
/* 113 */           filesToRename.writeUTF(file.getFile().getFileName());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 119 */       if (newFiles == null)
/*     */       {
/* 121 */         filesToRename.writeInt(0);
/*     */       }
/*     */       else
/*     */       {
/* 125 */         filesToRename.writeInt(newFiles.size());
/*     */         
/* 127 */         for (JournalFile file : newFiles)
/*     */         {
/* 129 */           filesToRename.writeUTF(file.getFile().getFileName());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 134 */       if (renames == null)
/*     */       {
/* 136 */         filesToRename.writeInt(0);
/*     */       }
/*     */       else
/*     */       {
/* 140 */         filesToRename.writeInt(renames.size());
/* 141 */         for (Pair<String, String> rename : renames)
/*     */         {
/* 143 */           filesToRename.writeUTF((String)rename.getA());
/* 144 */           filesToRename.writeUTF((String)rename.getB());
/*     */         }
/*     */       }
/*     */       
/* 148 */       JournalInternalRecord controlRecord = new JournalAddRecord(true, 1L, (byte)0, new ByteArrayEncoding(filesToRename.toByteBuffer().array()));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 154 */       HornetQBuffer renameBuffer = HornetQBuffers.dynamicBuffer(filesToRename.writerIndex());
/*     */       
/* 156 */       controlRecord.setFileID(0);
/*     */       
/* 158 */       controlRecord.encode(renameBuffer);
/*     */       
/* 160 */       ByteBuffer writeBuffer = fileFactory.newBuffer(renameBuffer.writerIndex());
/*     */       
/* 162 */       writeBuffer.put(renameBuffer.toByteBuffer().array(), 0, renameBuffer.writerIndex());
/*     */       
/* 164 */       writeBuffer.rewind();
/*     */       
/* 166 */       controlFile.writeDirect(writeBuffer, true);
/*     */       
/* 168 */       return controlFile;
/*     */     }
/*     */     finally
/*     */     {
/* 172 */       controlFile.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush()
/*     */     throws Exception
/*     */   {
/* 179 */     if (this.writingChannel != null)
/*     */     {
/* 181 */       this.sequentialFile.position(0L);
/*     */       
/*     */ 
/* 184 */       this.writingChannel.writerIndex(this.writingChannel.capacity());
/*     */       
/* 186 */       this.sequentialFile.writeInternal(this.writingChannel.toByteBuffer());
/* 187 */       this.sequentialFile.close();
/* 188 */       this.newDataFiles.add(this.currentFile);
/*     */     }
/*     */     
/* 191 */     this.writingChannel = null;
/*     */   }
/*     */   
/*     */   public boolean lookupRecord(long id)
/*     */   {
/* 196 */     return this.recordsSnapshot.contains(Long.valueOf(id));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void openFile()
/*     */     throws Exception
/*     */   {
/* 208 */     flush();
/*     */     
/* 210 */     ByteBuffer bufferWrite = this.fileFactory.newBuffer(this.journal.getFileSize());
/*     */     
/* 212 */     this.writingChannel = HornetQBuffers.wrappedBuffer(bufferWrite);
/*     */     
/* 214 */     this.currentFile = this.filesRepository.takeFile(false, false, false, true);
/*     */     
/* 216 */     this.sequentialFile = this.currentFile.getFile();
/*     */     
/* 218 */     this.sequentialFile.open(1, false);
/*     */     
/* 220 */     this.currentFile = new JournalFileImpl(this.sequentialFile, this.nextOrderingID++, 2);
/*     */     
/* 222 */     JournalImpl.writeHeader(this.writingChannel, this.journal.getUserVersion(), this.currentFile.getFileID());
/*     */   }
/*     */   
/*     */   protected void addToRecordsSnaptshot(long id)
/*     */   {
/* 227 */     this.recordsSnapshot.add(Long.valueOf(id));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected HornetQBuffer getWritingChannel()
/*     */   {
/* 235 */     return this.writingChannel;
/*     */   }
/*     */   
/*     */   protected void writeEncoder(JournalInternalRecord record) throws Exception
/*     */   {
/* 240 */     record.setFileID(this.currentFile.getRecordID());
/* 241 */     record.encode(getWritingChannel());
/*     */   }
/*     */   
/*     */   protected void writeEncoder(JournalInternalRecord record, int txcounter) throws Exception
/*     */   {
/* 246 */     record.setNumberOfRecords(txcounter);
/* 247 */     writeEncoder(record);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\AbstractJournalUpdateTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */