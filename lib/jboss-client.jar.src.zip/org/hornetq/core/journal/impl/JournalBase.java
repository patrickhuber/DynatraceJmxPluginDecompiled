/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.journal.EncodingSupport;
/*     */ import org.hornetq.core.journal.IOCompletion;
/*     */ import org.hornetq.core.journal.Journal;
/*     */ import org.hornetq.core.journal.impl.dataformat.ByteArrayEncoding;
/*     */ 
/*     */ abstract class JournalBase
/*     */   implements Journal
/*     */ {
/*     */   protected final int fileSize;
/*     */   private final boolean supportsCallback;
/*     */   
/*     */   public JournalBase(boolean supportsCallback, int fileSize)
/*     */   {
/*  17 */     if (fileSize < 1024)
/*     */     {
/*  19 */       throw new IllegalArgumentException("File size cannot be less than 1024 bytes");
/*     */     }
/*  21 */     this.supportsCallback = supportsCallback;
/*  22 */     this.fileSize = fileSize;
/*     */   }
/*     */   
/*     */   public abstract void appendAddRecord(long paramLong, byte paramByte, EncodingSupport paramEncodingSupport, boolean paramBoolean, IOCompletion paramIOCompletion)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendAddRecordTransactional(long paramLong1, long paramLong2, byte paramByte, EncodingSupport paramEncodingSupport)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendCommitRecord(long paramLong, boolean paramBoolean1, IOCompletion paramIOCompletion, boolean paramBoolean2)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendDeleteRecord(long paramLong, boolean paramBoolean, IOCompletion paramIOCompletion)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendDeleteRecordTransactional(long paramLong1, long paramLong2, EncodingSupport paramEncodingSupport)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendPrepareRecord(long paramLong, EncodingSupport paramEncodingSupport, boolean paramBoolean, IOCompletion paramIOCompletion)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendUpdateRecord(long paramLong, byte paramByte, EncodingSupport paramEncodingSupport, boolean paramBoolean, IOCompletion paramIOCompletion)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendUpdateRecordTransactional(long paramLong1, long paramLong2, byte paramByte, EncodingSupport paramEncodingSupport)
/*     */     throws Exception;
/*     */   
/*     */   public abstract void appendRollbackRecord(long paramLong, boolean paramBoolean, IOCompletion paramIOCompletion)
/*     */     throws Exception;
/*     */   
/*     */   public void appendAddRecord(long id, byte recordType, byte[] record, boolean sync)
/*     */     throws Exception
/*     */   {
/*  55 */     appendAddRecord(id, recordType, new ByteArrayEncoding(record), sync);
/*     */   }
/*     */   
/*     */   public void appendAddRecord(long id, byte recordType, EncodingSupport record, boolean sync) throws Exception
/*     */   {
/*  60 */     SyncIOCompletion callback = getSyncCallback(sync);
/*     */     
/*  62 */     appendAddRecord(id, recordType, record, sync, callback);
/*     */     
/*  64 */     if (callback != null)
/*     */     {
/*  66 */       callback.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendCommitRecord(long txID, boolean sync) throws Exception
/*     */   {
/*  72 */     SyncIOCompletion syncCompletion = getSyncCallback(sync);
/*     */     
/*  74 */     appendCommitRecord(txID, sync, syncCompletion, true);
/*     */     
/*  76 */     if (syncCompletion != null)
/*     */     {
/*  78 */       syncCompletion.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendCommitRecord(long txID, boolean sync, IOCompletion callback) throws Exception
/*     */   {
/*  84 */     appendCommitRecord(txID, sync, callback, true);
/*     */   }
/*     */   
/*     */   public void appendUpdateRecord(long id, byte recordType, byte[] record, boolean sync)
/*     */     throws Exception
/*     */   {
/*  90 */     appendUpdateRecord(id, recordType, new ByteArrayEncoding(record), sync);
/*     */   }
/*     */   
/*     */   public void appendUpdateRecordTransactional(long txID, long id, byte recordType, byte[] record)
/*     */     throws Exception
/*     */   {
/*  96 */     appendUpdateRecordTransactional(txID, id, recordType, new ByteArrayEncoding(record));
/*     */   }
/*     */   
/*     */   public void appendAddRecordTransactional(long txID, long id, byte recordType, byte[] record)
/*     */     throws Exception
/*     */   {
/* 102 */     appendAddRecordTransactional(txID, id, recordType, new ByteArrayEncoding(record));
/*     */   }
/*     */   
/*     */   public void appendDeleteRecordTransactional(long txID, long id) throws Exception
/*     */   {
/* 107 */     appendDeleteRecordTransactional(txID, id, NullEncoding.instance);
/*     */   }
/*     */   
/*     */   public void appendPrepareRecord(long txID, byte[] transactionData, boolean sync) throws Exception
/*     */   {
/* 112 */     appendPrepareRecord(txID, new ByteArrayEncoding(transactionData), sync);
/*     */   }
/*     */   
/*     */   public void appendPrepareRecord(long txID, EncodingSupport transactionData, boolean sync)
/*     */     throws Exception
/*     */   {
/* 118 */     SyncIOCompletion syncCompletion = getSyncCallback(sync);
/*     */     
/* 120 */     appendPrepareRecord(txID, transactionData, sync, syncCompletion);
/*     */     
/* 122 */     if (syncCompletion != null)
/*     */     {
/* 124 */       syncCompletion.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendDeleteRecordTransactional(long txID, long id, byte[] record) throws Exception
/*     */   {
/* 130 */     appendDeleteRecordTransactional(txID, id, new ByteArrayEncoding(record));
/*     */   }
/*     */   
/*     */ 
/*     */   public void appendUpdateRecord(long id, byte recordType, EncodingSupport record, boolean sync)
/*     */     throws Exception
/*     */   {
/* 137 */     SyncIOCompletion callback = getSyncCallback(sync);
/*     */     
/* 139 */     appendUpdateRecord(id, recordType, record, sync, callback);
/*     */     
/* 141 */     if (callback != null)
/*     */     {
/* 143 */       callback.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendRollbackRecord(long txID, boolean sync) throws Exception
/*     */   {
/* 149 */     SyncIOCompletion syncCompletion = getSyncCallback(sync);
/*     */     
/* 151 */     appendRollbackRecord(txID, sync, syncCompletion);
/*     */     
/* 153 */     if (syncCompletion != null)
/*     */     {
/* 155 */       syncCompletion.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */   public void appendDeleteRecord(long id, boolean sync)
/*     */     throws Exception
/*     */   {
/* 162 */     SyncIOCompletion callback = getSyncCallback(sync);
/*     */     
/* 164 */     appendDeleteRecord(id, sync, callback);
/*     */     
/* 166 */     if (callback != null)
/*     */     {
/* 168 */       callback.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */   abstract void scheduleReclaim();
/*     */   
/*     */   protected SyncIOCompletion getSyncCallback(boolean sync)
/*     */   {
/* 176 */     if (this.supportsCallback)
/*     */     {
/* 178 */       if (sync)
/*     */       {
/* 180 */         return new SimpleWaitIOCallback();
/*     */       }
/* 182 */       return DummyCallback.getInstance();
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */   
/*     */   private static final class NullEncoding
/*     */     implements EncodingSupport
/*     */   {
/* 190 */     private static NullEncoding instance = new NullEncoding();
/*     */     
/*     */ 
/*     */ 
/*     */     public void decode(HornetQBuffer buffer) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void encode(HornetQBuffer buffer) {}
/*     */     
/*     */ 
/*     */ 
/*     */     public int getEncodeSize()
/*     */     {
/* 204 */       return 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFileSize()
/*     */   {
/* 210 */     return this.fileSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */