/*      */ package org.hornetq.core.journal.impl;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import org.hornetq.api.core.HornetQBuffer;
/*      */ import org.hornetq.api.core.HornetQBuffers;
/*      */ import org.hornetq.api.core.Pair;
/*      */ import org.hornetq.core.journal.EncodingSupport;
/*      */ import org.hornetq.core.journal.IOAsyncTask;
/*      */ import org.hornetq.core.journal.IOCompletion;
/*      */ import org.hornetq.core.journal.Journal.JournalState;
/*      */ import org.hornetq.core.journal.JournalLoadInformation;
/*      */ import org.hornetq.core.journal.LoaderCallback;
/*      */ import org.hornetq.core.journal.PreparedTransactionInfo;
/*      */ import org.hornetq.core.journal.RecordInfo;
/*      */ import org.hornetq.core.journal.SequentialFile;
/*      */ import org.hornetq.core.journal.SequentialFileFactory;
/*      */ import org.hornetq.core.journal.TestableJournal;
/*      */ import org.hornetq.core.journal.TransactionFailureCallback;
/*      */ import org.hornetq.core.journal.impl.dataformat.ByteArrayEncoding;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecord;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalAddRecordTX;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalCompleteRecordTX;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalCompleteRecordTX.TX_RECORD_TYPE;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalDeleteRecord;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalDeleteRecordTX;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalInternalRecord;
/*      */ import org.hornetq.core.journal.impl.dataformat.JournalRollbackRecordTX;
/*      */ import org.hornetq.journal.HornetQJournalBundle;
/*      */ import org.hornetq.journal.HornetQJournalLogger;
/*      */ import org.hornetq.utils.ConcurrentHashSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JournalImpl
/*      */   extends JournalBase
/*      */   implements TestableJournal, JournalRecordProvider
/*      */ {
/*      */   public static final int FORMAT_VERSION = 2;
/*   86 */   private static final int[] COMPATIBLE_VERSIONS = { 1 };
/*      */   
/*      */ 
/*   89 */   private static final boolean trace = HornetQJournalLogger.LOGGER.isTraceEnabled();
/*      */   
/*      */ 
/*      */ 
/*   93 */   private static final boolean TRACE_RECORDS = trace;
/*      */   public static final int MIN_FILE_SIZE = 1024;
/*      */   public static final int SIZE_HEADER = 16;
/*      */   private static final int BASIC_SIZE = 9;
/*      */   public static final int SIZE_ADD_RECORD = 22;
/*      */   public static final byte ADD_RECORD = 11;
/*      */   
/*  100 */   private static void trace(String message) { HornetQJournalLogger.LOGGER.trace(message); }
/*      */   
/*      */ 
/*      */   private static void traceRecord(String message)
/*      */   {
/*  105 */     HornetQJournalLogger.LOGGER.trace(message);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte UPDATE_RECORD = 12;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int SIZE_ADD_RECORD_TX = 30;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte ADD_RECORD_TX = 13;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte UPDATE_RECORD_TX = 14;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int SIZE_DELETE_RECORD_TX = 29;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final byte DELETE_RECORD_TX = 15;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int SIZE_DELETE_RECORD = 17;
/*      */   
/*      */ 
/*      */   public static final byte DELETE_RECORD = 16;
/*      */   
/*      */ 
/*      */   public static final int SIZE_COMPLETE_TRANSACTION_RECORD = 21;
/*      */   
/*      */ 
/*      */   public static final int SIZE_PREPARE_RECORD = 25;
/*      */   
/*      */ 
/*      */   public static final byte PREPARE_RECORD = 17;
/*      */   
/*      */ 
/*      */   public static final int SIZE_COMMIT_RECORD = 21;
/*      */   
/*      */ 
/*      */   public static final byte COMMIT_RECORD = 18;
/*      */   
/*      */ 
/*      */   public static final int SIZE_ROLLBACK_RECORD = 17;
/*      */   
/*      */ 
/*      */   public static final byte ROLLBACK_RECORD = 19;
/*      */   
/*      */ 
/*      */   protected static final byte FILL_CHARACTER = 74;
/*      */   
/*      */ 
/*  165 */   private volatile boolean autoReclaim = true;
/*      */   
/*      */ 
/*      */   private final int userVersion;
/*      */   
/*      */   private final int minFiles;
/*      */   
/*      */   private final float compactPercentage;
/*      */   
/*      */   private final int compactMinFiles;
/*      */   
/*      */   private final SequentialFileFactory fileFactory;
/*      */   
/*      */   private final JournalFilesRepository filesRepository;
/*      */   
/*  180 */   private final ConcurrentMap<Long, JournalRecord> records = new ConcurrentHashMap();
/*      */   
/*      */ 
/*  183 */   private final ConcurrentMap<Long, JournalTransaction> transactions = new ConcurrentHashMap();
/*      */   
/*      */ 
/*      */   private volatile JournalCompactor compactor;
/*      */   
/*  188 */   private final AtomicBoolean compactorRunning = new AtomicBoolean();
/*      */   
/*  190 */   private ExecutorService filesExecutor = null;
/*      */   
/*  192 */   private ExecutorService compactorExecutor = null;
/*      */   
/*  194 */   private ConcurrentHashSet<CountDownLatch> latches = new ConcurrentHashSet();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  199 */   private final ReentrantLock lockAppend = new ReentrantLock();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  208 */   private final ReadWriteLock journalLock = new ReentrantReadWriteLock();
/*  209 */   private final ReadWriteLock compactorLock = new ReentrantReadWriteLock();
/*      */   
/*      */   private volatile JournalFile currentFile;
/*      */   
/*  213 */   private volatile Journal.JournalState state = Journal.JournalState.STOPPED;
/*      */   
/*  215 */   private final Reclaimer reclaimer = new Reclaimer();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JournalImpl(int fileSize, int minFiles, int compactMinFiles, int compactPercentage, SequentialFileFactory fileFactory, String filePrefix, String fileExtension, int maxAIO)
/*      */   {
/*  228 */     this(fileSize, minFiles, compactMinFiles, compactPercentage, fileFactory, filePrefix, fileExtension, maxAIO, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JournalImpl(int fileSize, int minFiles, int compactMinFiles, int compactPercentage, SequentialFileFactory fileFactory, String filePrefix, String fileExtension, int maxAIO, int userVersion)
/*      */   {
/*  241 */     super(fileFactory.isSupportsCallbacks(), fileSize);
/*  242 */     if (fileSize % fileFactory.getAlignment() != 0)
/*      */     {
/*  244 */       throw new IllegalArgumentException("Invalid journal-file-size " + fileSize + ", It should be multiple of " + fileFactory.getAlignment());
/*      */     }
/*      */     
/*  247 */     if (minFiles < 2)
/*      */     {
/*  249 */       throw new IllegalArgumentException("minFiles cannot be less than 2");
/*      */     }
/*  251 */     if ((compactPercentage < 0) || (compactPercentage > 100))
/*      */     {
/*  253 */       throw new IllegalArgumentException("Compact Percentage out of range");
/*      */     }
/*      */     
/*  256 */     if (compactPercentage == 0)
/*      */     {
/*  258 */       this.compactPercentage = 0.0F;
/*      */     }
/*      */     else
/*      */     {
/*  262 */       this.compactPercentage = (compactPercentage / 100.0F);
/*      */     }
/*      */     
/*  265 */     this.compactMinFiles = compactMinFiles;
/*  266 */     this.minFiles = minFiles;
/*      */     
/*  268 */     this.fileFactory = fileFactory;
/*      */     
/*  270 */     this.filesRepository = new JournalFilesRepository(fileFactory, this, filePrefix, fileExtension, userVersion, maxAIO, fileSize, minFiles);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  279 */     this.userVersion = userVersion;
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/*  285 */     return "JournalImpl(state=" + this.state + ", currentFile=[" + this.currentFile + "], hash=" + super.toString() + ")";
/*      */   }
/*      */   
/*      */   public void runDirectJournalBlast() throws Exception
/*      */   {
/*  290 */     int numIts = 100000000;
/*      */     
/*  292 */     HornetQJournalLogger.LOGGER.runningJournalBlast(Integer.valueOf(100000000));
/*      */     
/*  294 */     final CountDownLatch latch = new CountDownLatch(200000000);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  313 */     IOCompletion task = new IOCompletion()
/*      */     {
/*      */       public void done()
/*      */       {
/*  300 */         latch.countDown();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void onError(int errorCode, String errorMessage) {}
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       public void storeLineUp() {}
/*  314 */     };
/*  315 */     int recordSize = 1024;
/*      */     
/*  317 */     final byte[] bytes = new byte['Ѐ'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  338 */     EncodingSupport record = new EncodingSupport()
/*      */     {
/*      */       public void decode(HornetQBuffer buffer) {}
/*      */       
/*      */       public void encode(HornetQBuffer buffer)
/*      */       {
/*  328 */         buffer.writeBytes(bytes);
/*      */       }
/*      */       
/*      */       public int getEncodeSize()
/*      */       {
/*  333 */         return 1024;
/*      */       }
/*      */     };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  340 */     for (int i = 0; i < 100000000; i++)
/*      */     {
/*  342 */       appendAddRecord(i, (byte)1, record, true, task);
/*  343 */       appendDeleteRecord(i, true, task);
/*      */     }
/*      */     
/*  346 */     latch.await();
/*      */   }
/*      */   
/*      */   public Map<Long, JournalRecord> getRecords()
/*      */   {
/*  351 */     return this.records;
/*      */   }
/*      */   
/*      */   public JournalFile getCurrentFile()
/*      */   {
/*  356 */     return this.currentFile;
/*      */   }
/*      */   
/*      */   public JournalCompactor getCompactor()
/*      */   {
/*  361 */     return this.compactor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<JournalFile> orderFiles()
/*      */     throws Exception
/*      */   {
/*  370 */     List<String> fileNames = this.fileFactory.listFiles(this.filesRepository.getFileExtension());
/*      */     
/*  372 */     List<JournalFile> orderedFiles = new ArrayList(fileNames.size());
/*      */     
/*  374 */     for (String fileName : fileNames)
/*      */     {
/*  376 */       SequentialFile file = this.fileFactory.createSequentialFile(fileName, this.filesRepository.getMaxAIO());
/*      */       
/*  378 */       file.open(1, false);
/*      */       
/*      */ 
/*      */       try
/*      */       {
/*  383 */         JournalFileImpl jrnFile = readFileHeader(file);
/*      */         
/*  385 */         orderedFiles.add(jrnFile);
/*      */       }
/*      */       finally
/*      */       {
/*  389 */         file.close();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  396 */     Collections.sort(orderedFiles, new JournalFileComparator(null));
/*      */     
/*  398 */     return orderedFiles;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int readJournalFile(SequentialFileFactory fileFactory, JournalFile file, JournalReaderCallback reader)
/*      */     throws Exception
/*      */   {
/*  408 */     file.getFile().open(1, false);
/*  409 */     ByteBuffer wholeFileBuffer = null;
/*      */     try
/*      */     {
/*  412 */       int filesize = (int)file.getFile().size();
/*      */       
/*  414 */       wholeFileBuffer = fileFactory.newBuffer(filesize);
/*      */       
/*  416 */       int journalFileSize = file.getFile().read(wholeFileBuffer);
/*      */       
/*  418 */       if (journalFileSize != filesize)
/*      */       {
/*  420 */         throw new RuntimeException("Invalid read! The system couldn't read the entire file into memory");
/*      */       }
/*      */       
/*      */ 
/*  424 */       wholeFileBuffer.position(16);
/*      */       
/*  426 */       int lastDataPos = 16;
/*      */       int pos;
/*  428 */       while (wholeFileBuffer.hasRemaining())
/*      */       {
/*  430 */         pos = wholeFileBuffer.position();
/*      */         
/*  432 */         byte recordType = wholeFileBuffer.get();
/*      */         
/*  434 */         if ((recordType >= 11) && (recordType <= 19))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  442 */           if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 4))
/*      */           {
/*  444 */             reader.markAsDataFile(file);
/*      */             
/*  446 */             wholeFileBuffer.position(pos + 1);
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  453 */             int readFileId = wholeFileBuffer.getInt();
/*      */             
/*      */ 
/*      */ 
/*  457 */             if (readFileId != file.getRecordID())
/*      */             {
/*  459 */               wholeFileBuffer.position(pos + 1);
/*      */             }
/*      */             else
/*      */             {
/*  463 */               short compactCount = 0;
/*      */               
/*  465 */               if (file.getJournalVersion() >= 2)
/*      */               {
/*  467 */                 if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 1))
/*      */                 {
/*  469 */                   reader.markAsDataFile(file);
/*      */                   
/*  471 */                   wholeFileBuffer.position(pos + 1);
/*      */                 }
/*      */                 else
/*      */                 {
/*  475 */                   compactCount = (short)wholeFileBuffer.get();
/*      */                 }
/*      */               } else {
/*  478 */                 long transactionID = 0L;
/*      */                 
/*  480 */                 if (isTransaction(recordType))
/*      */                 {
/*  482 */                   if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 8))
/*      */                   {
/*  484 */                     wholeFileBuffer.position(pos + 1);
/*  485 */                     reader.markAsDataFile(file);
/*      */                   }
/*      */                   else
/*      */                   {
/*  489 */                     transactionID = wholeFileBuffer.getLong();
/*      */                   }
/*      */                 } else {
/*  492 */                   long recordID = 0L;
/*      */                   
/*      */ 
/*  495 */                   if (!isCompleteTransaction(recordType))
/*      */                   {
/*  497 */                     if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 8))
/*      */                     {
/*  499 */                       wholeFileBuffer.position(pos + 1);
/*  500 */                       reader.markAsDataFile(file);
/*      */                     }
/*      */                     else
/*      */                     {
/*  504 */                       recordID = wholeFileBuffer.getLong();
/*      */                     }
/*      */                     
/*      */ 
/*      */                   }
/*      */                   else
/*      */                   {
/*      */ 
/*  512 */                     int variableSize = 0;
/*      */                     
/*      */ 
/*  515 */                     int preparedTransactionExtraDataSize = 0;
/*      */                     
/*  517 */                     byte userRecordType = 0;
/*      */                     
/*  519 */                     byte[] record = null;
/*      */                     
/*  521 */                     if (isContainsBody(recordType))
/*      */                     {
/*  523 */                       if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 4))
/*      */                       {
/*  525 */                         wholeFileBuffer.position(pos + 1);
/*  526 */                         reader.markAsDataFile(file);
/*      */                       }
/*      */                       else
/*      */                       {
/*  530 */                         variableSize = wholeFileBuffer.getInt();
/*      */                         
/*  532 */                         if (recordType != 15)
/*      */                         {
/*  534 */                           if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 1))
/*      */                           {
/*  536 */                             wholeFileBuffer.position(pos + 1);
/*      */                           }
/*      */                           else
/*      */                           {
/*  540 */                             userRecordType = wholeFileBuffer.get();
/*      */                           }
/*      */                         }
/*  543 */                         else if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), variableSize))
/*      */                         {
/*  545 */                           wholeFileBuffer.position(pos + 1);
/*      */                         }
/*      */                         else
/*      */                         {
/*  549 */                           record = new byte[variableSize];
/*      */                           
/*  551 */                           wholeFileBuffer.get(record);
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                     else {
/*  556 */                       int transactionCheckNumberOfRecords = 0;
/*      */                       
/*  558 */                       if ((recordType == 17) || (recordType == 18))
/*      */                       {
/*  560 */                         if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 4))
/*      */                         {
/*  562 */                           wholeFileBuffer.position(pos + 1);
/*      */                         }
/*      */                         else
/*      */                         {
/*  566 */                           transactionCheckNumberOfRecords = wholeFileBuffer.getInt();
/*      */                           
/*  568 */                           if (recordType == 17)
/*      */                           {
/*  570 */                             if (isInvalidSize(journalFileSize, wholeFileBuffer.position(), 4))
/*      */                             {
/*  572 */                               wholeFileBuffer.position(pos + 1);
/*      */                             }
/*      */                             else
/*      */                             {
/*  576 */                               preparedTransactionExtraDataSize = wholeFileBuffer.getInt(); }
/*      */                           } else
/*  578 */                             variableSize = 0;
/*      */                         }
/*      */                       } else {
/*  581 */                         int recordSize = getRecordSize(recordType, file.getJournalVersion());
/*      */                         
/*      */ 
/*      */ 
/*      */ 
/*  586 */                         if (isInvalidSize(journalFileSize, pos, recordSize + variableSize + preparedTransactionExtraDataSize))
/*      */                         {
/*      */ 
/*      */ 
/*      */ 
/*  591 */                           trace("Record at position " + pos + " recordType = " + recordType + " file:" + file.getFile().getFileName() + " recordSize: " + recordSize + " variableSize: " + variableSize + " preparedTransactionExtraDataSize: " + preparedTransactionExtraDataSize + " is corrupted and it is being ignored (II)");
/*      */                           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  605 */                           reader.markAsDataFile(file);
/*  606 */                           wholeFileBuffer.position(pos + 1);
/*      */ 
/*      */                         }
/*      */                         else
/*      */                         {
/*  611 */                           int oldPos = wholeFileBuffer.position();
/*      */                           
/*  613 */                           wholeFileBuffer.position(pos + variableSize + recordSize + preparedTransactionExtraDataSize - 4);
/*      */                           
/*      */ 
/*      */ 
/*      */ 
/*  618 */                           int checkSize = wholeFileBuffer.getInt();
/*      */                           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  624 */                           if (checkSize != variableSize + recordSize + preparedTransactionExtraDataSize)
/*      */                           {
/*  626 */                             trace("Record at position " + pos + " recordType = " + recordType + " possible transactionID = " + transactionID + " possible recordID = " + recordID + " file:" + file.getFile().getFileName() + " is corrupted and it is being ignored (III)");
/*      */                             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  639 */                             reader.markAsDataFile(file);
/*      */                             
/*  641 */                             wholeFileBuffer.position(pos + 1);
/*      */ 
/*      */                           }
/*      */                           else
/*      */                           {
/*  646 */                             wholeFileBuffer.position(oldPos);
/*      */                             
/*      */ 
/*      */ 
/*      */ 
/*  651 */                             switch (recordType)
/*      */                             {
/*      */ 
/*      */                             case 11: 
/*  655 */                               reader.onReadAddRecord(new RecordInfo(recordID, userRecordType, record, false, compactCount));
/*  656 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */                             case 12: 
/*  661 */                               reader.onReadUpdateRecord(new RecordInfo(recordID, userRecordType, record, true, compactCount));
/*  662 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */                             case 16: 
/*  667 */                               reader.onReadDeleteRecord(recordID);
/*  668 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */                             case 13: 
/*  673 */                               reader.onReadAddRecordTX(transactionID, new RecordInfo(recordID, userRecordType, record, false, compactCount));
/*      */                               
/*      */ 
/*      */ 
/*      */ 
/*  678 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */                             case 14: 
/*  683 */                               reader.onReadUpdateRecordTX(transactionID, new RecordInfo(recordID, userRecordType, record, true, compactCount));
/*      */                               
/*      */ 
/*      */ 
/*      */ 
/*  688 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */                             case 15: 
/*  693 */                               reader.onReadDeleteRecordTX(transactionID, new RecordInfo(recordID, (byte)0, record, true, compactCount));
/*      */                               
/*      */ 
/*      */ 
/*      */ 
/*  698 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */ 
/*      */                             case 17: 
/*  704 */                               byte[] extraData = new byte[preparedTransactionExtraDataSize];
/*      */                               
/*  706 */                               wholeFileBuffer.get(extraData);
/*      */                               
/*  708 */                               reader.onReadPrepareRecord(transactionID, extraData, transactionCheckNumberOfRecords);
/*      */                               
/*  710 */                               break;
/*      */                             
/*      */ 
/*      */ 
/*      */                             case 18: 
/*  715 */                               reader.onReadCommitRecord(transactionID, transactionCheckNumberOfRecords);
/*  716 */                               break;
/*      */                             
/*      */ 
/*      */                             case 19: 
/*  720 */                               reader.onReadRollbackRecord(transactionID);
/*  721 */                               break;
/*      */                             
/*      */ 
/*      */                             default: 
/*  725 */                               throw new IllegalStateException("Journal " + file.getFile().getFileName() + " is corrupt, invalid record type " + recordType);
/*      */                             }
/*      */                             
/*      */                             
/*      */ 
/*      */ 
/*  731 */                             checkSize = wholeFileBuffer.getInt();
/*      */                             
/*      */ 
/*      */ 
/*      */ 
/*  736 */                             if (checkSize != variableSize + recordSize + preparedTransactionExtraDataSize)
/*      */                             {
/*  738 */                               throw new IllegalStateException("Internal error on loading file. Position doesn't match with checkSize, file = " + file.getFile() + ", pos = " + pos);
/*      */                             }
/*      */                             
/*      */ 
/*      */ 
/*  743 */                             lastDataPos = wholeFileBuffer.position();
/*      */                           }
/*      */                         }
/*      */                       } } } } } } } } }
/*  747 */       return lastDataPos;
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*  751 */       HornetQJournalLogger.LOGGER.errorReadingFile(e);
/*  752 */       throw new Exception(e.getMessage(), e);
/*      */     }
/*      */     finally
/*      */     {
/*  756 */       if (wholeFileBuffer != null)
/*      */       {
/*  758 */         fileFactory.releaseBuffer(wholeFileBuffer);
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  763 */         file.getFile().close();
/*      */       }
/*      */       catch (Throwable ignored) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendAddRecord(long id, byte recordType, EncodingSupport record, boolean sync, IOCompletion callback)
/*      */     throws Exception
/*      */   {
/*  781 */     checkJournalIsLoaded();
/*      */     
/*  783 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/*  787 */       JournalInternalRecord addRecord = new JournalAddRecord(true, id, recordType, record);
/*      */       
/*  789 */       if (callback != null)
/*      */       {
/*  791 */         callback.storeLineUp();
/*      */       }
/*      */       
/*  794 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/*  797 */         JournalFile usedFile = appendRecord(addRecord, false, sync, null, callback);
/*      */         
/*  799 */         if (TRACE_RECORDS)
/*      */         {
/*  801 */           traceRecord("appendAddRecord::id=" + id + ", userRecordType=" + recordType + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  808 */         this.records.put(Long.valueOf(id), new JournalRecord(usedFile, addRecord.getEncodeSize()));
/*      */       }
/*      */       finally
/*      */       {
/*  812 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  817 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendUpdateRecord(long id, byte recordType, EncodingSupport record, boolean sync, IOCompletion callback)
/*      */     throws Exception
/*      */   {
/*  828 */     checkJournalIsLoaded();
/*      */     
/*  830 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/*  834 */       JournalRecord jrnRecord = (JournalRecord)this.records.get(Long.valueOf(id));
/*      */       
/*  836 */       if (jrnRecord == null)
/*      */       {
/*  838 */         if ((this.compactor == null) || (!this.compactor.lookupRecord(id)))
/*      */         {
/*  840 */           throw new IllegalStateException("Cannot find add info " + id);
/*      */         }
/*      */       }
/*      */       
/*  844 */       JournalInternalRecord updateRecord = new JournalAddRecord(false, id, recordType, record);
/*      */       
/*  846 */       if (callback != null)
/*      */       {
/*  848 */         callback.storeLineUp();
/*      */       }
/*      */       
/*  851 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/*  854 */         JournalFile usedFile = appendRecord(updateRecord, false, sync, null, callback);
/*      */         
/*  856 */         if (TRACE_RECORDS)
/*      */         {
/*  858 */           traceRecord("appendUpdateRecord::id=" + id + ", userRecordType=" + recordType + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  867 */         if (jrnRecord == null)
/*      */         {
/*  869 */           this.compactor.addCommandUpdate(id, usedFile, updateRecord.getEncodeSize());
/*      */         }
/*      */         else
/*      */         {
/*  873 */           jrnRecord.addUpdateFile(usedFile, updateRecord.getEncodeSize());
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  878 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  883 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void appendDeleteRecord(long id, boolean sync, IOCompletion callback)
/*      */     throws Exception
/*      */   {
/*  891 */     checkJournalIsLoaded();
/*      */     
/*  893 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/*  897 */       JournalRecord record = null;
/*      */       
/*  899 */       if (this.compactor == null)
/*      */       {
/*  901 */         record = (JournalRecord)this.records.remove(Long.valueOf(id));
/*      */         
/*  903 */         if (record == null)
/*      */         {
/*  905 */           throw new IllegalStateException("Cannot find add info " + id);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*  910 */       else if ((!this.records.containsKey(Long.valueOf(id))) && (!this.compactor.lookupRecord(id)))
/*      */       {
/*  912 */         throw new IllegalStateException("Cannot find add info " + id + " on compactor or current records");
/*      */       }
/*      */       
/*      */ 
/*  916 */       JournalInternalRecord deleteRecord = new JournalDeleteRecord(id);
/*      */       
/*  918 */       if (callback != null)
/*      */       {
/*  920 */         callback.storeLineUp();
/*      */       }
/*      */       
/*  923 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/*  926 */         JournalFile usedFile = appendRecord(deleteRecord, false, sync, null, callback);
/*      */         
/*  928 */         if (TRACE_RECORDS)
/*      */         {
/*  930 */           traceRecord("appendDeleteRecord::id=" + id + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  935 */         if (record == null)
/*      */         {
/*  937 */           this.compactor.addCommandDelete(id, usedFile);
/*      */         }
/*      */         else
/*      */         {
/*  941 */           record.delete(usedFile);
/*      */         }
/*      */         
/*      */       }
/*      */       finally
/*      */       {
/*  947 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  952 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendAddRecordTransactional(long txID, long id, byte recordType, EncodingSupport record)
/*      */     throws Exception
/*      */   {
/*  962 */     checkJournalIsLoaded();
/*      */     
/*  964 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/*  968 */       JournalInternalRecord addRecord = new JournalAddRecordTX(true, txID, id, recordType, record);
/*      */       
/*  970 */       JournalTransaction tx = getTransactionInfo(txID);
/*      */       
/*  972 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/*  975 */         JournalFile usedFile = appendRecord(addRecord, false, false, tx, null);
/*      */         
/*  977 */         if (TRACE_RECORDS)
/*      */         {
/*  979 */           traceRecord("appendAddRecordTransactional:txID=" + txID + ",id=" + id + ", userRecordType=" + recordType + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  988 */         tx.addPositive(usedFile, id, addRecord.getEncodeSize());
/*      */       }
/*      */       finally
/*      */       {
/*  992 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  997 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkJournalIsLoaded()
/*      */   {
/* 1003 */     if ((this.state != Journal.JournalState.LOADED) && (this.state != Journal.JournalState.SYNCING))
/*      */     {
/* 1005 */       throw new IllegalStateException("Journal must be in state=" + Journal.JournalState.LOADED + ", was [" + this.state + "]");
/*      */     }
/*      */   }
/*      */   
/*      */   private void setJournalState(Journal.JournalState newState)
/*      */   {
/* 1011 */     this.state = newState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendUpdateRecordTransactional(long txID, long id, byte recordType, EncodingSupport record)
/*      */     throws Exception
/*      */   {
/* 1020 */     checkJournalIsLoaded();
/*      */     
/* 1022 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/* 1026 */       JournalInternalRecord updateRecordTX = new JournalAddRecordTX(false, txID, id, recordType, record);
/*      */       
/* 1028 */       JournalTransaction tx = getTransactionInfo(txID);
/*      */       
/* 1030 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/* 1033 */         JournalFile usedFile = appendRecord(updateRecordTX, false, false, tx, null);
/*      */         
/* 1035 */         if (TRACE_RECORDS)
/*      */         {
/* 1037 */           traceRecord("appendUpdateRecordTransactional::txID=" + txID + ",id=" + id + ", userRecordType=" + recordType + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1046 */         tx.addPositive(usedFile, id, updateRecordTX.getEncodeSize());
/*      */       }
/*      */       finally
/*      */       {
/* 1050 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1055 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void appendDeleteRecordTransactional(long txID, long id, EncodingSupport record)
/*      */     throws Exception
/*      */   {
/* 1063 */     checkJournalIsLoaded();
/*      */     
/* 1065 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/* 1069 */       JournalInternalRecord deleteRecordTX = new JournalDeleteRecordTX(txID, id, record);
/*      */       
/* 1071 */       JournalTransaction tx = getTransactionInfo(txID);
/*      */       
/* 1073 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/* 1076 */         JournalFile usedFile = appendRecord(deleteRecordTX, false, false, tx, null);
/*      */         
/* 1078 */         if (TRACE_RECORDS)
/*      */         {
/* 1080 */           traceRecord("appendDeleteRecordTransactional::txID=" + txID + ", id=" + id + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1087 */         tx.addNegative(usedFile, id);
/*      */       }
/*      */       finally
/*      */       {
/* 1091 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1096 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendPrepareRecord(long txID, EncodingSupport transactionData, boolean sync, IOCompletion callback)
/*      */     throws Exception
/*      */   {
/* 1119 */     checkJournalIsLoaded();
/*      */     
/* 1121 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/* 1125 */       JournalTransaction tx = getTransactionInfo(txID);
/*      */       
/* 1127 */       JournalInternalRecord prepareRecord = new JournalCompleteRecordTX(JournalCompleteRecordTX.TX_RECORD_TYPE.PREPARE, txID, transactionData);
/*      */       
/*      */ 
/* 1130 */       if (callback != null)
/*      */       {
/* 1132 */         callback.storeLineUp();
/*      */       }
/*      */       
/* 1135 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/* 1138 */         JournalFile usedFile = appendRecord(prepareRecord, true, sync, tx, callback);
/*      */         
/* 1140 */         if (TRACE_RECORDS)
/*      */         {
/* 1142 */           traceRecord("appendPrepareRecord::txID=" + txID + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/* 1145 */         tx.prepare(usedFile);
/*      */       }
/*      */       finally
/*      */       {
/* 1149 */         this.lockAppend.unlock();
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/* 1155 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void lineUpContext(IOCompletion callback)
/*      */   {
/* 1162 */     callback.storeLineUp();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void appendCommitRecord(long txID, boolean sync, IOCompletion callback, boolean lineUpContext)
/*      */     throws Exception
/*      */   {
/* 1172 */     checkJournalIsLoaded();
/*      */     
/* 1174 */     this.journalLock.readLock().lock();
/*      */     
/*      */     try
/*      */     {
/* 1178 */       JournalTransaction tx = (JournalTransaction)this.transactions.remove(Long.valueOf(txID));
/*      */       
/* 1180 */       if (tx == null)
/*      */       {
/* 1182 */         throw new IllegalStateException("Cannot find tx with id " + txID);
/*      */       }
/*      */       
/* 1185 */       JournalInternalRecord commitRecord = new JournalCompleteRecordTX(JournalCompleteRecordTX.TX_RECORD_TYPE.COMMIT, txID, null);
/*      */       
/* 1187 */       if ((callback != null) && (lineUpContext))
/*      */       {
/* 1189 */         callback.storeLineUp();
/*      */       }
/*      */       
/* 1192 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/* 1195 */         JournalFile usedFile = appendRecord(commitRecord, true, sync, tx, callback);
/*      */         
/* 1197 */         if (TRACE_RECORDS)
/*      */         {
/* 1199 */           traceRecord("appendCommitRecord::txID=" + txID + ", usedFile = " + usedFile);
/*      */         }
/*      */         
/* 1202 */         tx.commit(usedFile);
/*      */       }
/*      */       finally
/*      */       {
/* 1206 */         this.lockAppend.unlock();
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/* 1212 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public void appendRollbackRecord(long txID, boolean sync, IOCompletion callback)
/*      */     throws Exception
/*      */   {
/* 1219 */     checkJournalIsLoaded();
/*      */     
/* 1221 */     this.journalLock.readLock().lock();
/*      */     
/* 1223 */     JournalTransaction tx = null;
/*      */     
/*      */     try
/*      */     {
/* 1227 */       tx = (JournalTransaction)this.transactions.remove(Long.valueOf(txID));
/*      */       
/* 1229 */       if (tx == null)
/*      */       {
/* 1231 */         throw new IllegalStateException("Cannot find tx with id " + txID);
/*      */       }
/*      */       
/* 1234 */       JournalInternalRecord rollbackRecord = new JournalRollbackRecordTX(txID);
/*      */       
/* 1236 */       if (callback != null)
/*      */       {
/* 1238 */         callback.storeLineUp();
/*      */       }
/*      */       
/* 1241 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/* 1244 */         JournalFile usedFile = appendRecord(rollbackRecord, false, sync, tx, callback);
/*      */         
/* 1246 */         tx.rollback(usedFile);
/*      */       }
/*      */       finally
/*      */       {
/* 1250 */         this.lockAppend.unlock();
/*      */       }
/*      */       
/*      */     }
/*      */     finally
/*      */     {
/* 1256 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public int getAlignment()
/*      */     throws Exception
/*      */   {
/* 1263 */     return this.fileFactory.getAlignment();
/*      */   }
/*      */   
/*      */   private static final class DummyLoader implements LoaderCallback
/*      */   {
/* 1268 */     static final LoaderCallback INSTANCE = new DummyLoader();
/*      */     
/*      */ 
/*      */ 
/*      */     public void failedTransaction(long transactionID, List<RecordInfo> records, List<RecordInfo> recordsToDelete) {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void updateRecord(RecordInfo info) {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void deleteRecord(long id) {}
/*      */     
/*      */ 
/*      */ 
/*      */     public void addRecord(RecordInfo info) {}
/*      */     
/*      */ 
/*      */     public void addPreparedTransaction(PreparedTransactionInfo preparedTransaction) {}
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized JournalLoadInformation loadInternalOnly()
/*      */     throws Exception
/*      */   {
/* 1294 */     return load(DummyLoader.INSTANCE, true, null);
/*      */   }
/*      */   
/*      */   public synchronized JournalLoadInformation loadSyncOnly(Journal.JournalState syncState) throws Exception
/*      */   {
/* 1299 */     assert ((syncState == Journal.JournalState.SYNCING) || (syncState == Journal.JournalState.SYNCING_UP_TO_DATE));
/* 1300 */     return load(DummyLoader.INSTANCE, true, syncState);
/*      */   }
/*      */   
/*      */ 
/*      */   public JournalLoadInformation load(List<RecordInfo> committedRecords, List<PreparedTransactionInfo> preparedTransactions, TransactionFailureCallback failureCallback)
/*      */     throws Exception
/*      */   {
/* 1307 */     return load(committedRecords, preparedTransactions, failureCallback, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized JournalLoadInformation load(List<RecordInfo> committedRecords, final List<PreparedTransactionInfo> preparedTransactions, final TransactionFailureCallback failureCallback, boolean fixBadTX)
/*      */     throws Exception
/*      */   {
/* 1318 */     final Set<Long> recordsToDelete = new HashSet();
/*      */     
/* 1320 */     final List<RecordInfo> records = new LinkedList();
/*      */     
/* 1322 */     int DELETE_FLUSH = 20000;
/*      */     
/* 1324 */     JournalLoadInformation info = load(new LoaderCallback()
/*      */     {
/* 1326 */       Runtime runtime = Runtime.getRuntime();
/*      */       
/*      */ 
/*      */       private void checkDeleteSize()
/*      */       {
/* 1331 */         if ((recordsToDelete.size() > 20000) && (this.runtime.freeMemory() < this.runtime.maxMemory() * 0.2D))
/*      */         {
/* 1333 */           HornetQJournalLogger.LOGGER.debug("Flushing deletes during loading, deleteCount = " + recordsToDelete.size());
/*      */           
/*      */ 
/* 1336 */           Iterator<RecordInfo> iter = records.iterator();
/* 1337 */           while (iter.hasNext())
/*      */           {
/* 1339 */             RecordInfo record = (RecordInfo)iter.next();
/*      */             
/* 1341 */             if (recordsToDelete.contains(Long.valueOf(record.id)))
/*      */             {
/* 1343 */               iter.remove();
/*      */             }
/*      */           }
/*      */           
/* 1347 */           recordsToDelete.clear();
/*      */           
/* 1349 */           HornetQJournalLogger.LOGGER.debug("flush delete done");
/*      */         }
/*      */       }
/*      */       
/*      */       public void addPreparedTransaction(PreparedTransactionInfo preparedTransaction)
/*      */       {
/* 1355 */         preparedTransactions.add(preparedTransaction);
/* 1356 */         checkDeleteSize();
/*      */       }
/*      */       
/*      */       public void addRecord(RecordInfo info)
/*      */       {
/* 1361 */         records.add(info);
/* 1362 */         checkDeleteSize();
/*      */       }
/*      */       
/*      */       public void updateRecord(RecordInfo info)
/*      */       {
/* 1367 */         records.add(info);
/* 1368 */         checkDeleteSize();
/*      */       }
/*      */       
/*      */       public void deleteRecord(long id)
/*      */       {
/* 1373 */         recordsToDelete.add(Long.valueOf(id));
/* 1374 */         checkDeleteSize();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       public void failedTransaction(long transactionID, List<RecordInfo> records, List<RecordInfo> recordsToDelete)
/*      */       {
/* 1381 */         if (failureCallback != null)
/*      */         {
/* 1383 */           failureCallback.failedTransaction(transactionID, records, recordsToDelete); } } }, fixBadTX, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1388 */     for (RecordInfo record : records)
/*      */     {
/* 1390 */       if (!recordsToDelete.contains(Long.valueOf(record.id)))
/*      */       {
/* 1392 */         committedRecords.add(record);
/*      */       }
/*      */     }
/*      */     
/* 1396 */     return info;
/*      */   }
/*      */   
/*      */   public void scheduleCompactAndBlock(int timeout)
/*      */     throws Exception
/*      */   {
/* 1402 */     final AtomicInteger errors = new AtomicInteger(0);
/*      */     
/* 1404 */     final CountDownLatch latch = newLatch(1);
/*      */     
/* 1406 */     this.compactorRunning.set(true);
/*      */     
/*      */ 
/*      */ 
/* 1410 */     this.compactorExecutor.execute(new Runnable()
/*      */     {
/*      */ 
/*      */       public void run()
/*      */       {
/*      */         try
/*      */         {
/* 1417 */           JournalImpl.this.compact();
/*      */         }
/*      */         catch (Throwable e)
/*      */         {
/* 1421 */           errors.incrementAndGet();
/* 1422 */           HornetQJournalLogger.LOGGER.errorCompacting(e);
/* 1423 */           e.printStackTrace();
/*      */         }
/*      */         finally
/*      */         {
/* 1427 */           latch.countDown();
/*      */         }
/*      */       }
/*      */     });
/*      */     
/*      */ 
/*      */     try
/*      */     {
/* 1435 */       awaitLatch(latch, timeout);
/*      */       
/* 1437 */       if (errors.get() > 0)
/*      */       {
/* 1439 */         throw new RuntimeException("Error during compact, look at the logs");
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1444 */       this.compactorRunning.set(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected synchronized void compact()
/*      */     throws Exception
/*      */   {
/* 1457 */     if (this.compactor != null)
/*      */     {
/* 1459 */       throw new IllegalStateException("There is pending compacting operation");
/*      */     }
/*      */     
/* 1462 */     this.compactorLock.writeLock().lock();
/*      */     try
/*      */     {
/* 1465 */       ArrayList<JournalFile> dataFilesToProcess = new ArrayList(this.filesRepository.getDataFilesCount());
/*      */       
/* 1467 */       boolean previousReclaimValue = isAutoReclaim();
/*      */       
/*      */       try
/*      */       {
/* 1471 */         HornetQJournalLogger.LOGGER.debug("Starting compacting operation on journal");
/*      */         
/* 1473 */         onCompactStart();
/*      */         
/*      */ 
/*      */ 
/* 1477 */         this.journalLock.writeLock().lock();
/*      */         try
/*      */         {
/* 1480 */           if (this.state != Journal.JournalState.LOADED)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1522 */             this.journalLock.writeLock().unlock();
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1635 */             if (this.compactor != null)
/*      */             {
/*      */               try
/*      */               {
/* 1639 */                 this.compactor.flush();
/*      */               }
/*      */               catch (Throwable ignored) {}
/*      */               
/*      */ 
/*      */ 
/* 1645 */               this.compactor = null;
/*      */             }
/* 1647 */             setAutoReclaim(previousReclaimValue); return;
/*      */           }
/* 1485 */           onCompactLockingTheJournal();
/*      */           
/* 1487 */           setAutoReclaim(false);
/*      */           
/*      */ 
/* 1490 */           moveNextFile(false);
/*      */           
/*      */ 
/*      */ 
/* 1494 */           dataFilesToProcess.addAll(this.filesRepository.getDataFiles());
/*      */           
/* 1496 */           this.filesRepository.clearDataFiles();
/*      */           
/* 1498 */           if (dataFilesToProcess.size() == 0)
/*      */           {
/* 1500 */             trace("Finishing compacting, nothing to process");
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1522 */             this.journalLock.writeLock().unlock();
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1635 */             if (this.compactor != null)
/*      */             {
/*      */               try
/*      */               {
/* 1639 */                 this.compactor.flush();
/*      */               }
/*      */               catch (Throwable ignored) {}
/*      */               
/*      */ 
/*      */ 
/* 1645 */               this.compactor = null;
/*      */             }
/* 1647 */             setAutoReclaim(previousReclaimValue); return;
/*      */           }
/* 1504 */           this.compactor = new JournalCompactor(this.fileFactory, this, this.filesRepository, this.records.keySet(), ((JournalFile)dataFilesToProcess.get(0)).getFileID());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1510 */           for (Map.Entry<Long, JournalTransaction> entry : this.transactions.entrySet())
/*      */           {
/* 1512 */             this.compactor.addPendingTransaction(((Long)entry.getKey()).longValue(), ((JournalTransaction)entry.getValue()).getPositiveArray());
/* 1513 */             ((JournalTransaction)entry.getValue()).setCompacting();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1518 */           this.records.clear();
/*      */         }
/*      */         finally
/*      */         {
/* 1522 */           this.journalLock.writeLock().unlock();
/*      */         }
/*      */         
/* 1525 */         Collections.sort(dataFilesToProcess, new JournalFileComparator(null));
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1532 */         for (JournalFile file : dataFilesToProcess)
/*      */         {
/*      */           try
/*      */           {
/* 1536 */             readJournalFile(this.fileFactory, file, this.compactor);
/*      */           }
/*      */           catch (Throwable e)
/*      */           {
/* 1540 */             HornetQJournalLogger.LOGGER.compactReadError(file);
/* 1541 */             throw new Exception("Error on reading compacting for " + file, e);
/*      */           }
/*      */         }
/*      */         
/* 1545 */         this.compactor.flush();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1550 */         onCompactDone();
/*      */         
/* 1552 */         List<JournalFile> newDatafiles = null;
/*      */         
/* 1554 */         JournalCompactor localCompactor = this.compactor;
/*      */         
/* 1556 */         SequentialFile controlFile = createControlFile(dataFilesToProcess, this.compactor.getNewDataFiles(), null);
/*      */         
/* 1558 */         this.journalLock.writeLock().lock();
/*      */         
/*      */         try
/*      */         {
/* 1562 */           this.compactor = null;
/*      */           
/* 1564 */           onCompactLockingTheJournal();
/*      */           
/* 1566 */           newDatafiles = localCompactor.getNewDataFiles();
/*      */           
/*      */ 
/* 1569 */           for (Map.Entry<Long, JournalRecord> newRecordEntry : localCompactor.getNewRecords().entrySet())
/*      */           {
/* 1571 */             this.records.put(newRecordEntry.getKey(), newRecordEntry.getValue());
/*      */           }
/*      */           
/*      */ 
/* 1575 */           for (int i = newDatafiles.size() - 1; i >= 0; i--)
/*      */           {
/* 1577 */             JournalFile fileToAdd = (JournalFile)newDatafiles.get(i);
/* 1578 */             if (trace)
/*      */             {
/* 1580 */               trace("Adding file " + fileToAdd + " back as datafile");
/*      */             }
/* 1582 */             this.filesRepository.addDataFileOnTop(fileToAdd);
/*      */           }
/*      */           
/* 1585 */           if (trace)
/*      */           {
/* 1587 */             trace("There are " + this.filesRepository.getDataFilesCount() + " datafiles Now");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1592 */           for (JournalTransaction newTransaction : localCompactor.getNewTransactions().values())
/*      */           {
/* 1594 */             newTransaction.replaceRecordProvider(this);
/*      */           }
/*      */           
/* 1597 */           localCompactor.replayPendingCommands();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1603 */           for (JournalTransaction newTransaction : localCompactor.getNewTransactions().values())
/*      */           {
/* 1605 */             if (trace)
/*      */             {
/* 1607 */               trace("Merging pending transaction " + newTransaction + " after compacting the journal");
/*      */             }
/* 1609 */             JournalTransaction liveTransaction = (JournalTransaction)this.transactions.get(Long.valueOf(newTransaction.getId()));
/* 1610 */             if (liveTransaction != null)
/*      */             {
/* 1612 */               liveTransaction.merge(newTransaction);
/*      */             }
/*      */             else
/*      */             {
/* 1616 */               HornetQJournalLogger.LOGGER.compactMergeError(Long.valueOf(newTransaction.getId()));
/*      */             }
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/* 1622 */           this.journalLock.writeLock().unlock();
/*      */         }
/*      */         
/*      */ 
/* 1626 */         renameFiles(dataFilesToProcess, newDatafiles);
/* 1627 */         deleteControlFile(controlFile);
/*      */         
/* 1629 */         HornetQJournalLogger.LOGGER.debug("Finished compacting on journal");
/*      */ 
/*      */       }
/*      */       finally
/*      */       {
/*      */ 
/* 1635 */         if (this.compactor != null)
/*      */         {
/*      */           try
/*      */           {
/* 1639 */             this.compactor.flush();
/*      */           }
/*      */           catch (Throwable ignored) {}
/*      */           
/*      */ 
/*      */ 
/* 1645 */           this.compactor = null;
/*      */         }
/* 1647 */         setAutoReclaim(previousReclaimValue);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1652 */       this.compactorLock.writeLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JournalLoadInformation load(LoaderCallback loadManager)
/*      */     throws Exception
/*      */   {
/* 1695 */     return load(loadManager, true, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private synchronized JournalLoadInformation load(final LoaderCallback loadManager, boolean changeData, Journal.JournalState replicationSync)
/*      */     throws Exception
/*      */   {
/* 1708 */     if ((this.state == Journal.JournalState.STOPPED) || (this.state == Journal.JournalState.LOADED))
/*      */     {
/* 1710 */       throw new IllegalStateException("Journal " + this + " must be in " + Journal.JournalState.STARTED + " state, was " + this.state);
/*      */     }
/*      */     
/* 1713 */     if (this.state == replicationSync)
/*      */     {
/* 1715 */       throw new IllegalStateException("Journal cannot be in state " + Journal.JournalState.STARTED);
/*      */     }
/*      */     
/* 1718 */     checkControlFile();
/*      */     
/* 1720 */     this.records.clear();
/*      */     
/* 1722 */     this.filesRepository.clear();
/*      */     
/* 1724 */     this.transactions.clear();
/* 1725 */     this.currentFile = null;
/*      */     
/* 1727 */     final Map<Long, TransactionHolder> loadTransactions = new LinkedHashMap();
/*      */     
/* 1729 */     final List<JournalFile> orderedFiles = orderFiles();
/*      */     
/* 1731 */     this.filesRepository.calculateNextfileID(orderedFiles);
/*      */     
/* 1733 */     int lastDataPos = 16;
/*      */     
/*      */ 
/* 1736 */     final AtomicLong maxID = new AtomicLong(-1L);
/*      */     
/* 1738 */     for (final JournalFile file : orderedFiles)
/*      */     {
/* 1740 */       trace("Loading file " + file.getFile().getFileName());
/*      */       
/* 1742 */       final AtomicBoolean hasData = new AtomicBoolean(false);
/*      */       
/* 1744 */       int resultLastPost = readJournalFile(this.fileFactory, file, new JournalReaderCallback()
/*      */       {
/*      */ 
/*      */         private void checkID(long id)
/*      */         {
/* 1749 */           if (id > maxID.longValue())
/*      */           {
/* 1751 */             maxID.set(id);
/*      */           }
/*      */         }
/*      */         
/*      */         public void onReadAddRecord(RecordInfo info) throws Exception
/*      */         {
/* 1757 */           checkID(info.id);
/*      */           
/* 1759 */           hasData.set(true);
/*      */           
/* 1761 */           loadManager.addRecord(info);
/*      */           
/* 1763 */           JournalImpl.this.records.put(Long.valueOf(info.id), new JournalRecord(file, info.data.length + 22 + 1));
/*      */         }
/*      */         
/*      */         public void onReadUpdateRecord(RecordInfo info) throws Exception
/*      */         {
/* 1768 */           checkID(info.id);
/*      */           
/* 1770 */           hasData.set(true);
/*      */           
/* 1772 */           loadManager.updateRecord(info);
/*      */           
/* 1774 */           JournalRecord posFiles = (JournalRecord)JournalImpl.this.records.get(Long.valueOf(info.id));
/*      */           
/* 1776 */           if (posFiles != null)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1782 */             posFiles.addUpdateFile(file, info.data.length + 22 + 1);
/*      */           }
/*      */         }
/*      */         
/*      */         public void onReadDeleteRecord(long recordID)
/*      */           throws Exception
/*      */         {
/* 1789 */           hasData.set(true);
/*      */           
/* 1791 */           loadManager.deleteRecord(recordID);
/*      */           
/* 1793 */           JournalRecord posFiles = (JournalRecord)JournalImpl.this.records.remove(Long.valueOf(recordID));
/*      */           
/* 1795 */           if (posFiles != null)
/*      */           {
/* 1797 */             posFiles.delete(file);
/*      */           }
/*      */         }
/*      */         
/*      */         public void onReadUpdateRecordTX(long transactionID, RecordInfo info) throws Exception
/*      */         {
/* 1803 */           onReadAddRecordTX(transactionID, info);
/*      */         }
/*      */         
/*      */         public void onReadAddRecordTX(long transactionID, RecordInfo info)
/*      */           throws Exception
/*      */         {
/* 1809 */           checkID(info.id);
/*      */           
/* 1811 */           hasData.set(true);
/*      */           
/* 1813 */           JournalImpl.TransactionHolder tx = (JournalImpl.TransactionHolder)loadTransactions.get(Long.valueOf(transactionID));
/*      */           
/* 1815 */           if (tx == null)
/*      */           {
/* 1817 */             tx = new JournalImpl.TransactionHolder(transactionID);
/*      */             
/* 1819 */             loadTransactions.put(Long.valueOf(transactionID), tx);
/*      */           }
/*      */           
/* 1822 */           tx.recordInfos.add(info);
/*      */           
/* 1824 */           JournalTransaction tnp = (JournalTransaction)JournalImpl.this.transactions.get(Long.valueOf(transactionID));
/*      */           
/* 1826 */           if (tnp == null)
/*      */           {
/* 1828 */             tnp = new JournalTransaction(transactionID, JournalImpl.this);
/*      */             
/* 1830 */             JournalImpl.this.transactions.put(Long.valueOf(transactionID), tnp);
/*      */           }
/*      */           
/* 1833 */           tnp.addPositive(file, info.id, info.data.length + 30 + 1);
/*      */         }
/*      */         
/*      */         public void onReadDeleteRecordTX(long transactionID, RecordInfo info)
/*      */           throws Exception
/*      */         {
/* 1839 */           hasData.set(true);
/*      */           
/* 1841 */           JournalImpl.TransactionHolder tx = (JournalImpl.TransactionHolder)loadTransactions.get(Long.valueOf(transactionID));
/*      */           
/* 1843 */           if (tx == null)
/*      */           {
/* 1845 */             tx = new JournalImpl.TransactionHolder(transactionID);
/*      */             
/* 1847 */             loadTransactions.put(Long.valueOf(transactionID), tx);
/*      */           }
/*      */           
/* 1850 */           tx.recordsToDelete.add(info);
/*      */           
/* 1852 */           JournalTransaction tnp = (JournalTransaction)JournalImpl.this.transactions.get(Long.valueOf(transactionID));
/*      */           
/* 1854 */           if (tnp == null)
/*      */           {
/* 1856 */             tnp = new JournalTransaction(transactionID, JournalImpl.this);
/*      */             
/* 1858 */             JournalImpl.this.transactions.put(Long.valueOf(transactionID), tnp);
/*      */           }
/*      */           
/* 1861 */           tnp.addNegative(file, info.id);
/*      */         }
/*      */         
/*      */         public void onReadPrepareRecord(long transactionID, byte[] extraData, int numberOfRecords)
/*      */           throws Exception
/*      */         {
/* 1867 */           hasData.set(true);
/*      */           
/* 1869 */           JournalImpl.TransactionHolder tx = (JournalImpl.TransactionHolder)loadTransactions.get(Long.valueOf(transactionID));
/*      */           
/* 1871 */           if (tx == null)
/*      */           {
/*      */ 
/* 1874 */             tx = new JournalImpl.TransactionHolder(transactionID);
/*      */             
/* 1876 */             loadTransactions.put(Long.valueOf(transactionID), tx);
/*      */           }
/*      */           
/* 1879 */           tx.prepared = true;
/*      */           
/* 1881 */           tx.extraData = extraData;
/*      */           
/* 1883 */           JournalTransaction journalTransaction = (JournalTransaction)JournalImpl.this.transactions.get(Long.valueOf(transactionID));
/*      */           
/* 1885 */           if (journalTransaction == null)
/*      */           {
/* 1887 */             journalTransaction = new JournalTransaction(transactionID, JournalImpl.this);
/*      */             
/* 1889 */             JournalImpl.this.transactions.put(Long.valueOf(transactionID), journalTransaction);
/*      */           }
/*      */           
/* 1892 */           boolean healthy = JournalImpl.this.checkTransactionHealth(file, journalTransaction, orderedFiles, numberOfRecords);
/*      */           
/* 1894 */           if (healthy)
/*      */           {
/* 1896 */             journalTransaction.prepare(file);
/*      */           }
/*      */           else
/*      */           {
/* 1900 */             HornetQJournalLogger.LOGGER.preparedTXIncomplete(Long.valueOf(transactionID));
/* 1901 */             tx.invalid = true;
/*      */           }
/*      */         }
/*      */         
/*      */         public void onReadCommitRecord(long transactionID, int numberOfRecords) throws Exception
/*      */         {
/* 1907 */           JournalImpl.TransactionHolder tx = (JournalImpl.TransactionHolder)loadTransactions.remove(Long.valueOf(transactionID));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1916 */           if (tx != null)
/*      */           {
/* 1918 */             JournalTransaction journalTransaction = (JournalTransaction)JournalImpl.this.transactions.remove(Long.valueOf(transactionID));
/*      */             
/* 1920 */             if (journalTransaction == null)
/*      */             {
/* 1922 */               throw new IllegalStateException("Cannot find tx " + transactionID);
/*      */             }
/*      */             
/* 1925 */             boolean healthy = JournalImpl.this.checkTransactionHealth(file, journalTransaction, orderedFiles, numberOfRecords);
/*      */             
/* 1927 */             if (healthy)
/*      */             {
/* 1929 */               for (RecordInfo txRecord : tx.recordInfos)
/*      */               {
/* 1931 */                 if (txRecord.isUpdate)
/*      */                 {
/* 1933 */                   loadManager.updateRecord(txRecord);
/*      */                 }
/*      */                 else
/*      */                 {
/* 1937 */                   loadManager.addRecord(txRecord);
/*      */                 }
/*      */               }
/*      */               
/* 1941 */               for (RecordInfo deleteValue : tx.recordsToDelete)
/*      */               {
/* 1943 */                 loadManager.deleteRecord(deleteValue.id);
/*      */               }
/*      */               
/* 1946 */               journalTransaction.commit(file);
/*      */             }
/*      */             else
/*      */             {
/* 1950 */               HornetQJournalLogger.LOGGER.txMissingElements(Long.valueOf(transactionID));
/*      */               
/* 1952 */               journalTransaction.forget();
/*      */             }
/*      */             
/* 1955 */             hasData.set(true);
/*      */           }
/*      */         }
/*      */         
/*      */         public void onReadRollbackRecord(long transactionID)
/*      */           throws Exception
/*      */         {
/* 1962 */           JournalImpl.TransactionHolder tx = (JournalImpl.TransactionHolder)loadTransactions.remove(Long.valueOf(transactionID));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1968 */           if (tx != null)
/*      */           {
/* 1970 */             JournalTransaction tnp = (JournalTransaction)JournalImpl.this.transactions.remove(Long.valueOf(transactionID));
/*      */             
/* 1972 */             if (tnp == null)
/*      */             {
/* 1974 */               throw new IllegalStateException("Cannot find tx " + transactionID);
/*      */             }
/*      */             
/*      */ 
/*      */ 
/* 1979 */             tnp.rollback(file);
/*      */             
/* 1981 */             hasData.set(true);
/*      */           }
/*      */         }
/*      */         
/*      */         public void markAsDataFile(JournalFile file)
/*      */         {
/* 1987 */           hasData.set(true);
/*      */         }
/*      */       });
/*      */       
/*      */ 
/* 1992 */       if (hasData.get())
/*      */       {
/* 1994 */         lastDataPos = resultLastPost;
/* 1995 */         this.filesRepository.addDataFileOnBottom(file);
/*      */ 
/*      */ 
/*      */       }
/* 1999 */       else if (changeData)
/*      */       {
/*      */ 
/* 2002 */         this.filesRepository.addFreeFile(file, false, false);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2007 */     if (replicationSync == Journal.JournalState.SYNCING)
/*      */     {
/* 2009 */       assert (this.filesRepository.getDataFiles().isEmpty());
/* 2010 */       setJournalState(Journal.JournalState.SYNCING);
/* 2011 */       return new JournalLoadInformation(0, -1L);
/*      */     }
/*      */     
/* 2014 */     setUpCurrentFile(lastDataPos);
/*      */     
/* 2016 */     setJournalState(Journal.JournalState.LOADED);
/*      */     
/* 2018 */     for (TransactionHolder transaction : loadTransactions.values())
/*      */     {
/* 2020 */       if (((!transaction.prepared) || (transaction.invalid)) && (replicationSync != Journal.JournalState.SYNCING_UP_TO_DATE))
/*      */       {
/* 2022 */         HornetQJournalLogger.LOGGER.uncomittedTxFound(Long.valueOf(transaction.transactionID));
/*      */         
/* 2024 */         if (changeData)
/*      */         {
/*      */ 
/* 2027 */           appendRollbackRecord(transaction.transactionID, false);
/*      */         }
/*      */         
/* 2030 */         loadManager.failedTransaction(transaction.transactionID, transaction.recordInfos, transaction.recordsToDelete);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 2036 */         for (RecordInfo info : transaction.recordInfos)
/*      */         {
/* 2038 */           if (info.id > maxID.get())
/*      */           {
/* 2040 */             maxID.set(info.id);
/*      */           }
/*      */         }
/*      */         
/* 2044 */         PreparedTransactionInfo info = new PreparedTransactionInfo(transaction.transactionID, transaction.extraData);
/*      */         
/* 2046 */         info.records.addAll(transaction.recordInfos);
/*      */         
/* 2048 */         info.recordsToDelete.addAll(transaction.recordsToDelete);
/*      */         
/* 2050 */         loadManager.addPreparedTransaction(info);
/*      */       }
/*      */     }
/*      */     
/* 2054 */     checkReclaimStatus();
/*      */     
/* 2056 */     return new JournalLoadInformation(this.records.size(), maxID.longValue());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean checkReclaimStatus()
/*      */     throws Exception
/*      */   {
/* 2065 */     if (this.compactorRunning.get())
/*      */     {
/* 2067 */       return false;
/*      */     }
/*      */     
/*      */ 
/*      */     for (;;)
/*      */     {
/* 2073 */       if (this.state != Journal.JournalState.LOADED)
/* 2074 */         return false;
/* 2075 */       if (!isAutoReclaim())
/* 2076 */         return false;
/* 2077 */       if (this.journalLock.readLock().tryLock(250L, TimeUnit.MILLISECONDS)) {
/*      */         break;
/*      */       }
/*      */     }
/*      */     try {
/* 2082 */       this.reclaimer.scan(getDataFiles());
/*      */       
/* 2084 */       for (JournalFile file : this.filesRepository.getDataFiles())
/*      */       {
/* 2086 */         if (file.isCanReclaim())
/*      */         {
/*      */ 
/* 2089 */           if (trace)
/*      */           {
/* 2091 */             trace("Reclaiming file " + file);
/*      */           }
/*      */           
/* 2094 */           this.filesRepository.removeDataFile(file);
/*      */           
/* 2096 */           this.filesRepository.addFreeFile(file, false);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2102 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */     
/* 2105 */     return false;
/*      */   }
/*      */   
/*      */   private boolean needsCompact() throws Exception
/*      */   {
/* 2110 */     JournalFile[] dataFiles = getDataFiles();
/*      */     
/* 2112 */     long totalLiveSize = 0L;
/*      */     
/* 2114 */     for (JournalFile file : dataFiles)
/*      */     {
/* 2116 */       totalLiveSize += file.getLiveSize();
/*      */     }
/*      */     
/* 2119 */     long totalBytes = dataFiles.length * this.fileSize;
/*      */     
/* 2121 */     long compactMargin = ((float)totalBytes * this.compactPercentage);
/*      */     
/* 2123 */     boolean needCompact = (totalLiveSize < compactMargin) && (dataFiles.length > this.compactMinFiles);
/*      */     
/* 2125 */     return needCompact;
/*      */   }
/*      */   
/*      */   private void checkCompact()
/*      */     throws Exception
/*      */   {
/* 2131 */     if (this.compactMinFiles == 0)
/*      */     {
/*      */ 
/* 2134 */       return;
/*      */     }
/*      */     
/* 2137 */     if (this.state != Journal.JournalState.LOADED)
/*      */     {
/* 2139 */       return;
/*      */     }
/*      */     
/* 2142 */     if ((!this.compactorRunning.get()) && (needsCompact()))
/*      */     {
/* 2144 */       scheduleCompact();
/*      */     }
/*      */   }
/*      */   
/*      */   private void scheduleCompact()
/*      */   {
/* 2150 */     if (!this.compactorRunning.compareAndSet(false, true))
/*      */     {
/* 2152 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2157 */     this.compactorExecutor.execute(new Runnable()
/*      */     {
/*      */ 
/*      */       public void run()
/*      */       {
/*      */         try
/*      */         {
/* 2164 */           JournalImpl.this.compact();
/*      */         }
/*      */         catch (Throwable e)
/*      */         {
/* 2168 */           HornetQJournalLogger.LOGGER.errorCompacting(e);
/*      */         }
/*      */         finally
/*      */         {
/* 2172 */           JournalImpl.this.compactorRunning.set(false);
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setAutoReclaim(boolean autoReclaim)
/*      */   {
/* 2183 */     this.autoReclaim = autoReclaim;
/*      */   }
/*      */   
/*      */   public final boolean isAutoReclaim()
/*      */   {
/* 2188 */     return this.autoReclaim;
/*      */   }
/*      */   
/*      */ 
/*      */   public String debug()
/*      */     throws Exception
/*      */   {
/* 2195 */     this.reclaimer.scan(getDataFiles());
/*      */     
/* 2197 */     StringBuilder builder = new StringBuilder();
/*      */     
/* 2199 */     for (JournalFile file : this.filesRepository.getDataFiles())
/*      */     {
/* 2201 */       builder.append("DataFile:" + file + " posCounter = " + file.getPosCount() + " reclaimStatus = " + file.isCanReclaim() + " live size = " + file.getLiveSize() + "\n");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2209 */       if ((file instanceof JournalFileImpl))
/*      */       {
/* 2211 */         builder.append(((JournalFileImpl)file).debug());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2216 */     for (JournalFile file : this.filesRepository.getFreeFiles())
/*      */     {
/* 2218 */       builder.append("FreeFile:" + file + "\n");
/*      */     }
/*      */     
/* 2221 */     if (this.currentFile != null)
/*      */     {
/* 2223 */       builder.append("CurrentFile:" + this.currentFile + " posCounter = " + this.currentFile.getPosCount() + "\n");
/*      */       
/* 2225 */       if ((this.currentFile instanceof JournalFileImpl))
/*      */       {
/* 2227 */         builder.append(((JournalFileImpl)this.currentFile).debug());
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2232 */       builder.append("CurrentFile: No current file at this point!");
/*      */     }
/*      */     
/* 2235 */     return builder.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void debugWait()
/*      */     throws InterruptedException
/*      */   {
/* 2244 */     this.fileFactory.flush();
/*      */     
/* 2246 */     for (JournalTransaction tx : this.transactions.values())
/*      */     {
/* 2248 */       tx.waitCallbacks();
/*      */     }
/*      */     
/* 2251 */     if ((this.filesExecutor != null) && (!this.filesExecutor.isShutdown()))
/*      */     {
/*      */ 
/*      */ 
/* 2255 */       final CountDownLatch latch = newLatch(1);
/*      */       
/* 2257 */       this.filesExecutor.execute(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/* 2261 */           latch.countDown();
/*      */         }
/*      */         
/* 2264 */       });
/* 2265 */       awaitLatch(latch, -1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int getDataFilesCount()
/*      */   {
/* 2272 */     return this.filesRepository.getDataFilesCount();
/*      */   }
/*      */   
/*      */   public JournalFile[] getDataFiles()
/*      */   {
/* 2277 */     return this.filesRepository.getDataFilesArray();
/*      */   }
/*      */   
/*      */   public int getFreeFilesCount()
/*      */   {
/* 2282 */     return this.filesRepository.getFreeFilesCount();
/*      */   }
/*      */   
/*      */   public int getOpenedFilesCount()
/*      */   {
/* 2287 */     return this.filesRepository.getOpenedFilesCount();
/*      */   }
/*      */   
/*      */   public int getIDMapSize()
/*      */   {
/* 2292 */     return this.records.size();
/*      */   }
/*      */   
/*      */ 
/*      */   public int getFileSize()
/*      */   {
/* 2298 */     return this.fileSize;
/*      */   }
/*      */   
/*      */   public int getMinFiles()
/*      */   {
/* 2303 */     return this.minFiles;
/*      */   }
/*      */   
/*      */   public String getFilePrefix()
/*      */   {
/* 2308 */     return this.filesRepository.getFilePrefix();
/*      */   }
/*      */   
/*      */   public String getFileExtension()
/*      */   {
/* 2313 */     return this.filesRepository.getFileExtension();
/*      */   }
/*      */   
/*      */   public int getMaxAIO()
/*      */   {
/* 2318 */     return this.filesRepository.getMaxAIO();
/*      */   }
/*      */   
/*      */   public int getUserVersion()
/*      */   {
/* 2323 */     return this.userVersion;
/*      */   }
/*      */   
/*      */   public void forceMoveNextFile()
/*      */     throws Exception
/*      */   {
/* 2329 */     this.journalLock.readLock().lock();
/*      */     try
/*      */     {
/* 2332 */       this.lockAppend.lock();
/*      */       try
/*      */       {
/* 2335 */         moveNextFile(false);
/* 2336 */         debugWait();
/*      */       }
/*      */       finally
/*      */       {
/* 2340 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2345 */       this.journalLock.readLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public void perfBlast(int pages)
/*      */   {
/* 2351 */     new PerfBlast(pages, null).start();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean isStarted()
/*      */   {
/* 2359 */     return this.state != Journal.JournalState.STOPPED;
/*      */   }
/*      */   
/*      */   public synchronized void start()
/*      */   {
/* 2364 */     if (this.state != Journal.JournalState.STOPPED)
/*      */     {
/* 2366 */       throw new IllegalStateException("Journal " + this + " is not stopped, state is " + this.state);
/*      */     }
/*      */     
/* 2369 */     this.filesExecutor = Executors.newSingleThreadExecutor(new ThreadFactory()
/*      */     {
/*      */ 
/*      */       public Thread newThread(Runnable r)
/*      */       {
/* 2374 */         return new Thread(r, "JournalImpl::FilesExecutor");
/*      */       }
/*      */       
/* 2377 */     });
/* 2378 */     this.compactorExecutor = Executors.newSingleThreadExecutor(new ThreadFactory()
/*      */     {
/*      */ 
/*      */       public Thread newThread(Runnable r)
/*      */       {
/* 2383 */         return new Thread(r, "JournalImpl::CompactorExecutor");
/*      */       }
/*      */       
/* 2386 */     });
/* 2387 */     this.filesRepository.setExecutor(this.filesExecutor);
/*      */     
/* 2389 */     this.fileFactory.start();
/*      */     
/* 2391 */     setJournalState(Journal.JournalState.STARTED);
/*      */   }
/*      */   
/*      */   public synchronized void stop() throws Exception
/*      */   {
/* 2396 */     if (this.state == Journal.JournalState.STOPPED)
/*      */     {
/* 2398 */       throw new IllegalStateException("Journal is already stopped");
/*      */     }
/*      */     
/*      */ 
/* 2402 */     this.journalLock.writeLock().lock();
/*      */     try
/*      */     {
/* 2405 */       this.lockAppend.lock();
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 2410 */         setJournalState(Journal.JournalState.STOPPED);
/*      */         
/* 2412 */         this.compactorExecutor.shutdown();
/*      */         
/* 2414 */         if (!this.compactorExecutor.awaitTermination(120L, TimeUnit.SECONDS))
/*      */         {
/* 2416 */           HornetQJournalLogger.LOGGER.couldNotStopCompactor();
/*      */         }
/*      */         
/* 2419 */         this.filesExecutor.shutdown();
/*      */         
/* 2421 */         this.filesRepository.setExecutor(null);
/*      */         
/* 2423 */         if (!this.filesExecutor.awaitTermination(60L, TimeUnit.SECONDS))
/*      */         {
/* 2425 */           HornetQJournalLogger.LOGGER.couldNotStopJournalExecutor();
/*      */         }
/*      */         
/*      */         try
/*      */         {
/* 2430 */           for (CountDownLatch latch : this.latches)
/*      */           {
/* 2432 */             latch.countDown();
/*      */           }
/*      */         }
/*      */         catch (Throwable e)
/*      */         {
/* 2437 */           HornetQJournalLogger.LOGGER.warn(e.getMessage(), e);
/*      */         }
/*      */         
/* 2440 */         this.fileFactory.deactivateBuffer();
/*      */         
/* 2442 */         if ((this.currentFile != null) && (this.currentFile.getFile().isOpen()))
/*      */         {
/* 2444 */           this.currentFile.getFile().close();
/*      */         }
/*      */         
/* 2447 */         this.filesRepository.clear();
/*      */         
/* 2449 */         this.fileFactory.stop();
/*      */         
/* 2451 */         this.currentFile = null;
/*      */       }
/*      */       finally
/*      */       {
/* 2455 */         this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2460 */       this.journalLock.writeLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public int getNumberOfRecords()
/*      */   {
/* 2466 */     return this.records.size();
/*      */   }
/*      */   
/*      */ 
/*      */   protected SequentialFile createControlFile(List<JournalFile> files, List<JournalFile> newFiles, Pair<String, String> cleanupRename)
/*      */     throws Exception
/*      */   {
/*      */     ArrayList<Pair<String, String>> cleanupList;
/*      */     ArrayList<Pair<String, String>> cleanupList;
/* 2475 */     if (cleanupRename == null)
/*      */     {
/* 2477 */       cleanupList = null;
/*      */     }
/*      */     else
/*      */     {
/* 2481 */       cleanupList = new ArrayList();
/* 2482 */       cleanupList.add(cleanupRename);
/*      */     }
/* 2484 */     return AbstractJournalUpdateTask.writeControlFile(this.fileFactory, files, newFiles, cleanupList);
/*      */   }
/*      */   
/*      */   protected void deleteControlFile(SequentialFile controlFile) throws Exception
/*      */   {
/* 2489 */     controlFile.delete();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void renameFiles(final List<JournalFile> oldFiles, List<JournalFile> newFiles)
/*      */     throws Exception
/*      */   {
/* 2503 */     final CountDownLatch done = newLatch(1);
/*      */     
/* 2505 */     this.filesExecutor.execute(new Runnable()
/*      */     {
/*      */       public void run()
/*      */       {
/*      */         try
/*      */         {
/* 2511 */           for (JournalFile file : oldFiles)
/*      */           {
/*      */             try
/*      */             {
/* 2515 */               JournalImpl.this.filesRepository.addFreeFile(file, false);
/*      */             }
/*      */             catch (Throwable e)
/*      */             {
/* 2519 */               HornetQJournalLogger.LOGGER.errorReinitializingFile(e, file);
/*      */             }
/*      */           }
/*      */         }
/*      */         finally
/*      */         {
/* 2525 */           done.countDown();
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/* 2532 */     });
/* 2533 */     awaitLatch(done, -1);
/*      */     
/* 2535 */     for (JournalFile file : newFiles)
/*      */     {
/* 2537 */       String newName = renameExtensionFile(file.getFile().getFileName(), ".cmp");
/* 2538 */       file.getFile().renameTo(newName);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static String renameExtensionFile(String name, String extension)
/*      */   {
/* 2549 */     name = name.substring(0, name.lastIndexOf(extension));
/* 2550 */     return name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void onCompactStart()
/*      */     throws Exception
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void onCompactLockingTheJournal()
/*      */     throws Exception
/*      */   {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void onCompactDone() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkTransactionHealth(JournalFile currentFile, JournalTransaction journalTransaction, List<JournalFile> orderedFiles, int numberOfRecords)
/*      */   {
/* 2597 */     return journalTransaction.getCounter(currentFile) == numberOfRecords;
/*      */   }
/*      */   
/*      */   private static boolean isTransaction(byte recordType)
/*      */   {
/* 2602 */     return (recordType == 13) || (recordType == 14) || (recordType == 15) || (isCompleteTransaction(recordType));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static boolean isCompleteTransaction(byte recordType)
/*      */   {
/* 2609 */     return (recordType == 18) || (recordType == 17) || (recordType == 19);
/*      */   }
/*      */   
/*      */ 
/*      */   private static boolean isContainsBody(byte recordType)
/*      */   {
/* 2615 */     return (recordType >= 11) && (recordType <= 15);
/*      */   }
/*      */   
/*      */ 
/*      */   private static int getRecordSize(byte recordType, int journalVersion)
/*      */   {
/* 2621 */     int recordSize = 0;
/* 2622 */     switch (recordType)
/*      */     {
/*      */     case 11: 
/* 2625 */       recordSize = 22;
/* 2626 */       break;
/*      */     case 12: 
/* 2628 */       recordSize = 22;
/* 2629 */       break;
/*      */     case 13: 
/* 2631 */       recordSize = 30;
/* 2632 */       break;
/*      */     case 14: 
/* 2634 */       recordSize = 30;
/* 2635 */       break;
/*      */     case 16: 
/* 2637 */       recordSize = 17;
/* 2638 */       break;
/*      */     case 15: 
/* 2640 */       recordSize = 29;
/* 2641 */       break;
/*      */     case 17: 
/* 2643 */       recordSize = 25;
/* 2644 */       break;
/*      */     case 18: 
/* 2646 */       recordSize = 21;
/* 2647 */       break;
/*      */     case 19: 
/* 2649 */       recordSize = 17;
/* 2650 */       break;
/*      */     
/*      */ 
/*      */     default: 
/* 2654 */       throw new IllegalStateException("Record other than expected");
/*      */     }
/*      */     
/* 2657 */     if (journalVersion >= 2)
/*      */     {
/* 2659 */       return recordSize + 1;
/*      */     }
/*      */     
/*      */ 
/* 2663 */     return recordSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private JournalFileImpl readFileHeader(SequentialFile file)
/*      */     throws Exception
/*      */   {
/* 2674 */     ByteBuffer bb = this.fileFactory.newBuffer(16);
/*      */     
/* 2676 */     file.read(bb);
/*      */     
/* 2678 */     int journalVersion = bb.getInt();
/*      */     
/* 2680 */     if (journalVersion != 2)
/*      */     {
/* 2682 */       boolean isCompatible = false;
/*      */       
/* 2684 */       for (int v : COMPATIBLE_VERSIONS)
/*      */       {
/* 2686 */         if (v == journalVersion)
/*      */         {
/* 2688 */           isCompatible = true;
/*      */         }
/*      */       }
/*      */       
/* 2692 */       if (!isCompatible)
/*      */       {
/* 2694 */         throw HornetQJournalBundle.BUNDLE.journalFileMisMatch();
/*      */       }
/*      */     }
/*      */     
/* 2698 */     int readUserVersion = bb.getInt();
/*      */     
/* 2700 */     if (readUserVersion != this.userVersion)
/*      */     {
/* 2702 */       throw HornetQJournalBundle.BUNDLE.journalDifferentVersion();
/*      */     }
/*      */     
/* 2705 */     long fileID = bb.getLong();
/*      */     
/* 2707 */     this.fileFactory.releaseBuffer(bb);
/*      */     
/* 2709 */     bb = null;
/*      */     
/* 2711 */     return new JournalFileImpl(file, fileID, journalVersion);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int initFileHeader(SequentialFileFactory fileFactory, SequentialFile sequentialFile, int userVersion, long fileID)
/*      */     throws Exception
/*      */   {
/* 2725 */     ByteBuffer bb = fileFactory.newBuffer(16);
/*      */     
/* 2727 */     HornetQBuffer buffer = HornetQBuffers.wrappedBuffer(bb);
/*      */     
/* 2729 */     writeHeader(buffer, userVersion, fileID);
/*      */     
/* 2731 */     bb.rewind();
/*      */     
/* 2733 */     int bufferSize = bb.limit();
/*      */     
/* 2735 */     sequentialFile.position(0L);
/*      */     
/* 2737 */     sequentialFile.writeDirect(bb, true);
/*      */     
/* 2739 */     return bufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void writeHeader(HornetQBuffer buffer, int userVersion, long fileID)
/*      */   {
/* 2749 */     buffer.writeInt(2);
/*      */     
/* 2751 */     buffer.writeInt(userVersion);
/*      */     
/* 2753 */     buffer.writeLong(fileID);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private JournalFile appendRecord(JournalInternalRecord encoder, boolean completeTransaction, boolean sync, JournalTransaction tx, IOAsyncTask parameterCallback)
/*      */     throws Exception
/*      */   {
/* 2767 */     checkJournalIsLoaded();
/*      */     
/*      */ 
/*      */ 
/* 2771 */     int size = encoder.getEncodeSize();
/*      */     
/* 2773 */     switchFileIfNecessary(size);
/*      */     IOAsyncTask callback;
/* 2775 */     if (tx != null)
/*      */     {
/*      */       IOAsyncTask callback;
/*      */       
/*      */       IOAsyncTask callback;
/* 2780 */       if (this.fileFactory.isSupportsCallbacks())
/*      */       {
/*      */ 
/* 2783 */         TransactionCallback txcallback = tx.getCallback(this.currentFile);
/* 2784 */         if (parameterCallback != null)
/*      */         {
/* 2786 */           txcallback.setDelegateCompletion(parameterCallback);
/*      */         }
/* 2788 */         callback = txcallback;
/*      */       }
/*      */       else
/*      */       {
/* 2792 */         callback = null;
/*      */       }
/*      */       
/*      */ 
/* 2796 */       if (completeTransaction)
/*      */       {
/*      */ 
/* 2799 */         tx.fillNumberOfRecords(this.currentFile, encoder);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2804 */       callback = parameterCallback;
/*      */     }
/*      */     
/*      */ 
/* 2808 */     encoder.setFileID(this.currentFile.getRecordID());
/*      */     
/* 2810 */     if (callback != null)
/*      */     {
/* 2812 */       this.currentFile.getFile().write(encoder, sync, callback);
/*      */     }
/*      */     else
/*      */     {
/* 2816 */       this.currentFile.getFile().write(encoder, sync);
/*      */     }
/*      */     
/* 2819 */     return this.currentFile;
/*      */   }
/*      */   
/*      */ 
/*      */   void scheduleReclaim()
/*      */   {
/* 2825 */     if (this.state != Journal.JournalState.LOADED)
/*      */     {
/* 2827 */       return;
/*      */     }
/*      */     
/* 2830 */     if ((isAutoReclaim()) && (!this.compactorRunning.get()))
/*      */     {
/* 2832 */       this.compactorExecutor.execute(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*      */           try
/*      */           {
/* 2838 */             if (!JournalImpl.this.checkReclaimStatus())
/*      */             {
/* 2840 */               JournalImpl.this.checkCompact();
/*      */             }
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/* 2845 */             HornetQJournalLogger.LOGGER.errorSchedulingCompacting(e);
/*      */           }
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   private JournalTransaction getTransactionInfo(long txID)
/*      */   {
/* 2854 */     JournalTransaction tx = (JournalTransaction)this.transactions.get(Long.valueOf(txID));
/*      */     
/* 2856 */     if (tx == null)
/*      */     {
/* 2858 */       tx = new JournalTransaction(txID, this);
/*      */       
/* 2860 */       JournalTransaction trans = (JournalTransaction)this.transactions.putIfAbsent(Long.valueOf(txID), tx);
/*      */       
/* 2862 */       if (trans != null)
/*      */       {
/* 2864 */         tx = trans;
/*      */       }
/*      */     }
/*      */     
/* 2868 */     return tx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void checkControlFile()
/*      */     throws Exception
/*      */   {
/* 2876 */     ArrayList<String> dataFiles = new ArrayList();
/* 2877 */     ArrayList<String> newFiles = new ArrayList();
/* 2878 */     ArrayList<Pair<String, String>> renames = new ArrayList();
/*      */     
/* 2880 */     SequentialFile controlFile = JournalCompactor.readControlFile(this.fileFactory, dataFiles, newFiles, renames);
/* 2881 */     if (controlFile != null)
/*      */     {
/* 2883 */       for (String dataFile : dataFiles)
/*      */       {
/* 2885 */         SequentialFile file = this.fileFactory.createSequentialFile(dataFile, 1);
/* 2886 */         if (file.exists())
/*      */         {
/* 2888 */           file.delete();
/*      */         }
/*      */       }
/*      */       
/* 2892 */       for (String newFile : newFiles)
/*      */       {
/* 2894 */         SequentialFile file = this.fileFactory.createSequentialFile(newFile, 1);
/* 2895 */         if (file.exists())
/*      */         {
/* 2897 */           String originalName = file.getFileName();
/* 2898 */           String newName = originalName.substring(0, originalName.lastIndexOf(".cmp"));
/* 2899 */           file.renameTo(newName);
/*      */         }
/*      */       }
/*      */       
/* 2903 */       for (Pair<String, String> rename : renames)
/*      */       {
/* 2905 */         SequentialFile fileTmp = this.fileFactory.createSequentialFile((String)rename.getA(), 1);
/* 2906 */         SequentialFile fileTo = this.fileFactory.createSequentialFile((String)rename.getB(), 1);
/*      */         
/*      */ 
/* 2909 */         if (fileTmp.exists())
/*      */         {
/* 2911 */           fileTo.delete();
/* 2912 */           fileTmp.renameTo((String)rename.getB());
/*      */         }
/*      */       }
/*      */       
/* 2916 */       controlFile.delete();
/*      */     }
/*      */     
/* 2919 */     cleanupTmpFiles(".cmp");
/*      */     
/* 2921 */     cleanupTmpFiles(".tmp");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void cleanupTmpFiles(String extension)
/*      */     throws Exception
/*      */   {
/* 2931 */     List<String> leftFiles = this.fileFactory.listFiles(getFileExtension() + extension);
/*      */     
/* 2933 */     if (leftFiles.size() > 0)
/*      */     {
/* 2935 */       HornetQJournalLogger.LOGGER.tempFilesLeftOpen();
/*      */       
/* 2937 */       for (String fileToDelete : leftFiles)
/*      */       {
/* 2939 */         HornetQJournalLogger.LOGGER.deletingOrphanedFile(fileToDelete);
/* 2940 */         SequentialFile file = this.fileFactory.createSequentialFile(fileToDelete, 1);
/* 2941 */         file.delete();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static boolean isInvalidSize(int fileSize, int bufferPos, int size)
/*      */   {
/* 2948 */     if (size < 0)
/*      */     {
/* 2950 */       return true;
/*      */     }
/*      */     
/*      */ 
/* 2954 */     int position = bufferPos + size;
/*      */     
/* 2956 */     return (position > fileSize) || (position < 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static final class TransactionHolder
/*      */   {
/*      */     public final long transactionID;
/*      */     
/*      */ 
/*      */ 
/*      */     public TransactionHolder(long id)
/*      */     {
/* 2969 */       this.transactionID = id;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2974 */     public final List<RecordInfo> recordInfos = new ArrayList();
/*      */     
/* 2976 */     public final List<RecordInfo> recordsToDelete = new ArrayList();
/*      */     
/*      */     public boolean prepared;
/*      */     
/*      */     public boolean invalid;
/*      */     
/*      */     public byte[] extraData;
/*      */   }
/*      */   
/*      */   private static final class JournalFileComparator
/*      */     implements Comparator<JournalFile>, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -6264728973604070321L;
/*      */     
/*      */     public int compare(JournalFile f1, JournalFile f2)
/*      */     {
/* 2992 */       long id1 = f1.getFileID();
/* 2993 */       long id2 = f2.getFileID();
/*      */       
/* 2995 */       return id1 == id2 ? 0 : id1 < id2 ? -1 : 1;
/*      */     }
/*      */   }
/*      */   
/*      */   private final class PerfBlast extends Thread
/*      */   {
/*      */     private final int pages;
/*      */     
/*      */     private PerfBlast(int pages)
/*      */     {
/* 3005 */       super();
/*      */       
/* 3007 */       this.pages = pages;
/*      */     }
/*      */     
/*      */ 
/*      */     public void run()
/*      */     {
/* 3013 */       JournalImpl.this.lockAppend.lock();
/*      */       
/*      */       try
/*      */       {
/* 3017 */         final ByteArrayEncoding byteEncoder = new ByteArrayEncoding(new byte[131072]);
/*      */         
/* 3019 */         JournalInternalRecord blastRecord = new JournalInternalRecord()
/*      */         {
/*      */ 
/*      */           public int getEncodeSize()
/*      */           {
/*      */ 
/* 3025 */             return byteEncoder.getEncodeSize();
/*      */           }
/*      */           
/*      */           public void encode(HornetQBuffer buffer)
/*      */           {
/* 3030 */             byteEncoder.encode(buffer);
/*      */           }
/*      */         };
/*      */         
/* 3034 */         for (int i = 0; i < this.pages; i++)
/*      */         {
/* 3036 */           JournalImpl.this.appendRecord(blastRecord, false, false, null, null);
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 3041 */         HornetQJournalLogger.LOGGER.failedToPerfBlast(e);
/*      */       }
/*      */       finally
/*      */       {
/* 3045 */         JournalImpl.this.lockAppend.unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final void synchronizationLock()
/*      */   {
/* 3052 */     this.compactorLock.writeLock().lock();
/* 3053 */     this.journalLock.writeLock().lock();
/*      */   }
/*      */   
/*      */   public final void synchronizationUnlock()
/*      */   {
/*      */     try
/*      */     {
/* 3060 */       this.compactorLock.writeLock().unlock();
/*      */     }
/*      */     finally
/*      */     {
/* 3064 */       this.journalLock.writeLock().unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized Map<Long, JournalFile> createFilesForBackupSync(long[] fileIds)
/*      */     throws Exception
/*      */   {
/* 3080 */     synchronizationLock();
/*      */     try
/*      */     {
/* 3083 */       Map<Long, JournalFile> map = new HashMap();
/* 3084 */       long maxID = -1L;
/* 3085 */       for (long id : fileIds)
/*      */       {
/* 3087 */         maxID = Math.max(maxID, id);
/* 3088 */         map.put(Long.valueOf(id), this.filesRepository.createRemoteBackupSyncFile(id));
/*      */       }
/* 3090 */       this.filesRepository.setNextFileID(maxID);
/* 3091 */       return map;
/*      */     }
/*      */     finally
/*      */     {
/* 3095 */       synchronizationUnlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public SequentialFileFactory getFileFactory()
/*      */   {
/* 3102 */     return this.fileFactory;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JournalFile setUpCurrentFile(int lastDataPos)
/*      */     throws Exception
/*      */   {
/* 3114 */     this.filesRepository.ensureMinFiles();
/*      */     
/*      */ 
/*      */ 
/* 3118 */     this.currentFile = this.filesRepository.pollLastDataFile();
/* 3119 */     if (this.currentFile != null)
/*      */     {
/* 3121 */       if (!this.currentFile.getFile().isOpen())
/* 3122 */         this.currentFile.getFile().open();
/* 3123 */       this.currentFile.getFile().position(this.currentFile.getFile().calculateBlockStart(lastDataPos));
/*      */     }
/*      */     else
/*      */     {
/* 3127 */       this.currentFile = this.filesRepository.getFreeFile();
/* 3128 */       this.filesRepository.openFile(this.currentFile, true);
/*      */     }
/*      */     
/* 3131 */     this.fileFactory.activateBuffer(this.currentFile.getFile());
/*      */     
/* 3133 */     this.filesRepository.pushOpenedFile();
/* 3134 */     return this.currentFile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected JournalFile switchFileIfNecessary(int size)
/*      */     throws Exception
/*      */   {
/* 3145 */     if (size > this.fileSize - this.currentFile.getFile().calculateBlockStart(16))
/*      */     {
/* 3147 */       throw new IllegalArgumentException("Record is too large to store " + size);
/*      */     }
/*      */     
/* 3150 */     if (!this.currentFile.getFile().fits(size))
/*      */     {
/* 3152 */       moveNextFile(true);
/*      */       
/*      */ 
/* 3155 */       if (!this.currentFile.getFile().fits(size))
/*      */       {
/*      */ 
/* 3158 */         throw new IllegalStateException("Invalid logic on buffer allocation");
/*      */       }
/*      */     }
/* 3161 */     return this.currentFile;
/*      */   }
/*      */   
/*      */   private CountDownLatch newLatch(int countDown)
/*      */   {
/* 3166 */     if (this.state == Journal.JournalState.STOPPED)
/*      */     {
/* 3168 */       throw new RuntimeException("Server is not started");
/*      */     }
/* 3170 */     CountDownLatch latch = new CountDownLatch(countDown);
/* 3171 */     this.latches.add(latch);
/* 3172 */     return latch;
/*      */   }
/*      */   
/*      */   private void awaitLatch(CountDownLatch latch, int timeout) throws InterruptedException
/*      */   {
/*      */     try
/*      */     {
/* 3179 */       if (timeout < 0)
/*      */       {
/* 3181 */         latch.await();
/*      */       }
/*      */       else
/*      */       {
/* 3185 */         latch.await(timeout, TimeUnit.SECONDS);
/*      */       }
/*      */       
/*      */ 
/* 3189 */       if (this.state == Journal.JournalState.STOPPED)
/*      */       {
/* 3191 */         throw new RuntimeException("Server is not started");
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 3196 */       this.latches.remove(latch);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void moveNextFile(boolean scheduleReclaim)
/*      */     throws Exception
/*      */   {
/* 3205 */     this.filesRepository.closeFile(this.currentFile);
/*      */     
/* 3207 */     this.currentFile = this.filesRepository.openFile();
/*      */     
/* 3209 */     if (scheduleReclaim)
/*      */     {
/* 3211 */       scheduleReclaim();
/*      */     }
/*      */     
/* 3214 */     if (trace)
/*      */     {
/* 3216 */       HornetQJournalLogger.LOGGER.movingNextFile(this.currentFile);
/*      */     }
/*      */     
/* 3219 */     this.fileFactory.activateBuffer(this.currentFile.getFile());
/*      */   }
/*      */   
/*      */ 
/*      */   public void replicationSyncPreserveOldFiles()
/*      */   {
/* 3225 */     setAutoReclaim(false);
/*      */   }
/*      */   
/*      */ 
/*      */   public void replicationSyncFinished()
/*      */   {
/* 3231 */     setAutoReclaim(true);
/*      */   }
/*      */   
/*      */ 
/*      */   public void testCompact()
/*      */   {
/*      */     try
/*      */     {
/* 3239 */       scheduleCompactAndBlock(60);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 3243 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */