/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQExceptionType;
/*     */ import org.hornetq.api.core.HornetQIOErrorException;
/*     */ import org.hornetq.api.core.HornetQIllegalStateException;
/*     */ import org.hornetq.core.journal.IOAsyncTask;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.journal.HornetQJournalBundle;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NIOSequentialFile
/*     */   extends AbstractSequentialFile
/*     */ {
/*     */   private FileChannel channel;
/*     */   private RandomAccessFile rfile;
/*     */   private Semaphore maxIOSemaphore;
/*     */   private final int defaultMaxIO;
/*     */   private int maxIO;
/*     */   
/*     */   public NIOSequentialFile(SequentialFileFactory factory, String directory, String fileName, int maxIO, Executor writerExecutor)
/*     */   {
/*  62 */     super(directory, new File(directory + "/" + fileName), factory, writerExecutor);
/*  63 */     this.defaultMaxIO = maxIO;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public NIOSequentialFile(SequentialFileFactory factory, File file, int maxIO, Executor writerExecutor)
/*     */   {
/*  71 */     super(file.getParent(), new File(file.getPath()), factory, writerExecutor);
/*  72 */     this.defaultMaxIO = maxIO;
/*     */   }
/*     */   
/*     */   public int getAlignment()
/*     */   {
/*  77 */     return 1;
/*     */   }
/*     */   
/*     */   public int calculateBlockStart(int position)
/*     */   {
/*  82 */     return position;
/*     */   }
/*     */   
/*     */   public synchronized boolean isOpen()
/*     */   {
/*  87 */     return this.channel != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void open()
/*     */     throws IOException
/*     */   {
/*  96 */     open(this.defaultMaxIO, true);
/*     */   }
/*     */   
/*     */   public void open(int maxIO, boolean useExecutor) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 103 */       this.rfile = new RandomAccessFile(getFile(), "rw");
/*     */       
/* 105 */       this.channel = this.rfile.getChannel();
/*     */       
/* 107 */       this.fileSize = this.channel.size();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 111 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 112 */       throw e;
/*     */     }
/*     */     
/* 115 */     if ((this.writerExecutor != null) && (useExecutor))
/*     */     {
/* 117 */       this.maxIOSemaphore = new Semaphore(maxIO);
/* 118 */       this.maxIO = maxIO;
/*     */     }
/*     */   }
/*     */   
/*     */   public void fill(int position, int size, byte fillCharacter) throws IOException
/*     */   {
/* 124 */     ByteBuffer bb = ByteBuffer.allocate(size);
/*     */     
/* 126 */     for (int i = 0; i < size; i++)
/*     */     {
/* 128 */       bb.put(fillCharacter);
/*     */     }
/*     */     
/* 131 */     bb.flip();
/*     */     
/*     */     try
/*     */     {
/* 135 */       this.channel.position(position);
/* 136 */       this.channel.write(bb);
/* 137 */       this.channel.force(false);
/* 138 */       this.channel.position(0L);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 142 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 143 */       throw e;
/*     */     }
/*     */     
/* 146 */     this.fileSize = this.channel.size();
/*     */   }
/*     */   
/*     */   public synchronized void waitForClose() throws InterruptedException
/*     */   {
/* 151 */     while (isOpen())
/*     */     {
/* 153 */       wait();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void close()
/*     */     throws IOException, InterruptedException, HornetQException
/*     */   {
/* 160 */     super.close();
/*     */     
/* 162 */     if (this.maxIOSemaphore != null)
/*     */     {
/* 164 */       while (!this.maxIOSemaphore.tryAcquire(this.maxIO, 60L, TimeUnit.SECONDS))
/*     */       {
/* 166 */         HornetQJournalLogger.LOGGER.errorClosingFile(getFileName());
/*     */       }
/*     */     }
/*     */     
/* 170 */     this.maxIOSemaphore = null;
/*     */     try
/*     */     {
/* 173 */       if (this.channel != null)
/*     */       {
/* 175 */         this.channel.close();
/*     */       }
/*     */       
/* 178 */       if (this.rfile != null)
/*     */       {
/* 180 */         this.rfile.close();
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 185 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 186 */       throw e;
/*     */     }
/* 188 */     this.channel = null;
/*     */     
/* 190 */     this.rfile = null;
/*     */     
/* 192 */     notifyAll();
/*     */   }
/*     */   
/*     */   public int read(ByteBuffer bytes) throws Exception
/*     */   {
/* 197 */     return read(bytes, null);
/*     */   }
/*     */   
/*     */   public synchronized int read(ByteBuffer bytes, IOAsyncTask callback)
/*     */     throws IOException, HornetQIllegalStateException
/*     */   {
/*     */     try
/*     */     {
/* 205 */       if (this.channel == null)
/*     */       {
/* 207 */         throw new HornetQIllegalStateException("File " + getFileName() + " has a null channel");
/*     */       }
/* 209 */       int bytesRead = this.channel.read(bytes);
/*     */       
/* 211 */       if (callback != null)
/*     */       {
/* 213 */         callback.done();
/*     */       }
/*     */       
/* 216 */       bytes.flip();
/*     */       
/* 218 */       return bytesRead;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 222 */       if (callback != null)
/*     */       {
/* 224 */         callback.onError(HornetQExceptionType.IO_ERROR.getCode(), e.getLocalizedMessage());
/*     */       }
/*     */       
/* 227 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/*     */       
/* 229 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   public void sync() throws IOException
/*     */   {
/* 235 */     if (this.channel != null)
/*     */     {
/*     */       try
/*     */       {
/* 239 */         this.channel.force(false);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 243 */         this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 244 */         throw e;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public long size() throws IOException
/*     */   {
/* 251 */     if (this.channel == null)
/*     */     {
/* 253 */       return getFile().length();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 258 */       return this.channel.size();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 262 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 263 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   public void position(long pos)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 272 */       super.position(pos);
/* 273 */       this.channel.position(pos);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 277 */       this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/* 278 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 285 */     return "NIOSequentialFile " + getFile();
/*     */   }
/*     */   
/*     */   public SequentialFile cloneFile()
/*     */   {
/* 290 */     return new NIOSequentialFile(this.factory, getFile(), this.maxIO, this.writerExecutor);
/*     */   }
/*     */   
/*     */   public void writeDirect(ByteBuffer bytes, boolean sync, IOAsyncTask callback)
/*     */   {
/* 295 */     if (callback == null)
/*     */     {
/* 297 */       throw new NullPointerException("callback parameter need to be set");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 302 */       internalWrite(bytes, sync, callback);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 306 */       callback.onError(HornetQExceptionType.GENERIC_EXCEPTION.getCode(), e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeDirect(ByteBuffer bytes, boolean sync) throws Exception
/*     */   {
/* 312 */     internalWrite(bytes, sync, null);
/*     */   }
/*     */   
/*     */   public void writeInternal(ByteBuffer bytes) throws Exception
/*     */   {
/* 317 */     internalWrite(bytes, true, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ByteBuffer newBuffer(int size, int limit)
/*     */   {
/* 325 */     size = limit;
/*     */     
/* 327 */     return super.newBuffer(size, limit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void internalWrite(final ByteBuffer bytes, final boolean sync, final IOAsyncTask callback)
/*     */     throws IOException, HornetQIOErrorException, InterruptedException
/*     */   {
/* 335 */     if (!isOpen())
/*     */     {
/* 337 */       if (callback != null)
/*     */       {
/* 339 */         callback.onError(HornetQExceptionType.IO_ERROR.getCode(), "File not opened");
/*     */       }
/*     */       else
/*     */       {
/* 343 */         throw HornetQJournalBundle.BUNDLE.fileNotOpened();
/*     */       }
/* 345 */       return;
/*     */     }
/*     */     
/* 348 */     this.position.addAndGet(bytes.limit());
/*     */     
/* 350 */     if ((this.maxIOSemaphore == null) || (callback == null))
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/* 355 */         doInternalWrite(bytes, sync, callback);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 359 */         this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), this);
/*     */       }
/*     */       
/*     */     }
/*     */     else
/*     */     {
/* 365 */       this.maxIOSemaphore.acquire();
/*     */       
/* 367 */       this.writerExecutor.execute(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           try
/*     */           {
/*     */             try
/*     */             {
/* 375 */               NIOSequentialFile.this.doInternalWrite(bytes, sync, callback);
/*     */             }
/*     */             catch (IOException e)
/*     */             {
/* 379 */               HornetQJournalLogger.LOGGER.errorSubmittingWrite(e);
/* 380 */               NIOSequentialFile.this.factory.onIOError(new HornetQIOErrorException(e.getMessage(), e), e.getMessage(), NIOSequentialFile.this);
/* 381 */               callback.onError(HornetQExceptionType.IO_ERROR.getCode(), e.getMessage());
/*     */             }
/*     */             catch (Throwable e)
/*     */             {
/* 385 */               HornetQJournalLogger.LOGGER.errorSubmittingWrite(e);
/* 386 */               callback.onError(HornetQExceptionType.IO_ERROR.getCode(), e.getMessage());
/*     */             }
/*     */           }
/*     */           finally
/*     */           {
/* 391 */             NIOSequentialFile.this.maxIOSemaphore.release();
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doInternalWrite(ByteBuffer bytes, boolean sync, IOAsyncTask callback)
/*     */     throws IOException
/*     */   {
/* 407 */     this.channel.write(bytes);
/*     */     
/* 409 */     if (sync)
/*     */     {
/* 411 */       sync();
/*     */     }
/*     */     
/* 414 */     if (callback != null)
/*     */     {
/* 416 */       callback.done();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\NIOSequentialFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */