package org.hornetq.core.journal.impl;

import org.hornetq.core.journal.RecordInfo;

public abstract interface JournalReaderCallback
{
  public abstract void onReadAddRecord(RecordInfo paramRecordInfo)
    throws Exception;
  
  public abstract void onReadUpdateRecord(RecordInfo paramRecordInfo)
    throws Exception;
  
  public abstract void onReadDeleteRecord(long paramLong)
    throws Exception;
  
  public abstract void onReadAddRecordTX(long paramLong, RecordInfo paramRecordInfo)
    throws Exception;
  
  public abstract void onReadUpdateRecordTX(long paramLong, RecordInfo paramRecordInfo)
    throws Exception;
  
  public abstract void onReadDeleteRecordTX(long paramLong, RecordInfo paramRecordInfo)
    throws Exception;
  
  public abstract void onReadPrepareRecord(long paramLong, byte[] paramArrayOfByte, int paramInt)
    throws Exception;
  
  public abstract void onReadCommitRecord(long paramLong, int paramInt)
    throws Exception;
  
  public abstract void onReadRollbackRecord(long paramLong)
    throws Exception;
  
  public abstract void markAsDataFile(JournalFile paramJournalFile);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalReaderCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */