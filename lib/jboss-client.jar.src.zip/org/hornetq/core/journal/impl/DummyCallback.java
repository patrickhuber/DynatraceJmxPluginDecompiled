/*    */ package org.hornetq.core.journal.impl;
/*    */ 
/*    */ import org.hornetq.journal.HornetQJournalLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DummyCallback
/*    */   extends SyncIOCompletion
/*    */ {
/* 27 */   private static final DummyCallback instance = new DummyCallback();
/*    */   
/*    */   public static DummyCallback getInstance()
/*    */   {
/* 31 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */   public void done() {}
/*    */   
/*    */ 
/*    */   public void onError(int errorCode, String errorMessage)
/*    */   {
/* 40 */     HornetQJournalLogger.LOGGER.errorWritingData(new Exception(errorMessage), errorMessage, Integer.valueOf(errorCode));
/*    */   }
/*    */   
/*    */   public void waitCompletion()
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */   public void storeLineUp() {}
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\DummyCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */