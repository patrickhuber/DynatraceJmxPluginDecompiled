/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.core.asyncio.AsynchronousFile;
/*     */ import org.hornetq.core.asyncio.BufferCallback;
/*     */ import org.hornetq.core.asyncio.IOExceptionListener;
/*     */ import org.hornetq.core.asyncio.impl.AsynchronousFileImpl;
/*     */ import org.hornetq.core.journal.IOAsyncTask;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AIOSequentialFile
/*     */   extends AbstractSequentialFile
/*     */   implements IOExceptionListener
/*     */ {
/*  39 */   private boolean opened = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private final int maxIO;
/*     */   
/*     */ 
/*     */ 
/*     */   private AsynchronousFile aioFile;
/*     */   
/*     */ 
/*     */ 
/*     */   private final BufferCallback bufferCallback;
/*     */   
/*     */ 
/*     */   private final Executor pollerExecutor;
/*     */   
/*     */ 
/*     */ 
/*     */   public AIOSequentialFile(SequentialFileFactory factory, int bufferSize, long bufferTimeoutMilliseconds, String directory, String fileName, int maxIO, BufferCallback bufferCallback, Executor writerExecutor, Executor pollerExecutor)
/*     */   {
/*  60 */     super(directory, new File(directory + "/" + fileName), factory, writerExecutor);
/*  61 */     this.maxIO = maxIO;
/*  62 */     this.bufferCallback = bufferCallback;
/*  63 */     this.pollerExecutor = pollerExecutor;
/*     */   }
/*     */   
/*     */   public boolean isOpen()
/*     */   {
/*  68 */     return this.opened;
/*     */   }
/*     */   
/*     */   public int getAlignment()
/*     */   {
/*  73 */     checkOpened();
/*     */     
/*  75 */     return this.aioFile.getBlockSize();
/*     */   }
/*     */   
/*     */   public int calculateBlockStart(int position)
/*     */   {
/*  80 */     int alignment = getAlignment();
/*     */     
/*  82 */     int pos = (position / alignment + (position % alignment != 0 ? 1 : 0)) * alignment;
/*     */     
/*  84 */     return pos;
/*     */   }
/*     */   
/*     */   public SequentialFile cloneFile()
/*     */   {
/*  89 */     return new AIOSequentialFile(this.factory, -1, -1L, getFile().getParent(), getFileName(), this.maxIO, this.bufferCallback, this.writerExecutor, this.pollerExecutor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */     throws IOException, InterruptedException, HornetQException
/*     */   {
/* 103 */     if (!this.opened)
/*     */     {
/* 105 */       return;
/*     */     }
/*     */     
/* 108 */     super.close();
/*     */     
/* 110 */     this.opened = false;
/*     */     
/* 112 */     this.timedBuffer = null;
/*     */     
/* 114 */     this.aioFile.close();
/* 115 */     this.aioFile = null;
/*     */     
/* 117 */     notifyAll();
/*     */   }
/*     */   
/*     */   public synchronized void waitForClose()
/*     */     throws Exception
/*     */   {
/* 123 */     while (isOpen())
/*     */     {
/* 125 */       wait();
/*     */     }
/*     */   }
/*     */   
/*     */   public void fill(int position, int size, byte fillCharacter) throws Exception
/*     */   {
/* 131 */     checkOpened();
/*     */     
/* 133 */     int fileblockSize = this.aioFile.getBlockSize();
/*     */     
/* 135 */     int blockSize = fileblockSize;
/*     */     
/* 137 */     if (size % 104857600 == 0)
/*     */     {
/* 139 */       blockSize = 104857600;
/*     */     }
/* 141 */     else if (size % 10485760 == 0)
/*     */     {
/* 143 */       blockSize = 10485760;
/*     */     }
/* 145 */     else if (size % 1048576 == 0)
/*     */     {
/* 147 */       blockSize = 1048576;
/*     */     }
/* 149 */     else if (size % 10240 == 0)
/*     */     {
/* 151 */       blockSize = 10240;
/*     */     }
/*     */     else
/*     */     {
/* 155 */       blockSize = fileblockSize;
/*     */     }
/*     */     
/* 158 */     int blocks = size / blockSize;
/*     */     
/* 160 */     if (size % blockSize != 0)
/*     */     {
/* 162 */       blocks++;
/*     */     }
/*     */     
/* 165 */     int filePosition = position;
/*     */     
/* 167 */     if (position % fileblockSize != 0)
/*     */     {
/* 169 */       filePosition = (position / fileblockSize + 1) * fileblockSize;
/*     */     }
/*     */     
/* 172 */     this.aioFile.fill(filePosition, blocks, blockSize, fillCharacter);
/*     */     
/* 174 */     this.fileSize = this.aioFile.size();
/*     */   }
/*     */   
/*     */   public void open() throws Exception
/*     */   {
/* 179 */     open(this.maxIO, true);
/*     */   }
/*     */   
/*     */   public synchronized void open(int maxIO, boolean useExecutor) throws HornetQException
/*     */   {
/* 184 */     this.opened = true;
/*     */     
/* 186 */     this.aioFile = new AsynchronousFileImpl(useExecutor ? this.writerExecutor : null, this.pollerExecutor, this);
/*     */     
/*     */     try
/*     */     {
/* 190 */       this.aioFile.open(getFile().getAbsolutePath(), maxIO);
/*     */     }
/*     */     catch (HornetQException e)
/*     */     {
/* 194 */       this.factory.onIOError(e, e.getMessage(), this);
/* 195 */       throw e;
/*     */     }
/*     */     
/* 198 */     this.position.set(0L);
/*     */     
/* 200 */     this.aioFile.setBufferCallback(this.bufferCallback);
/*     */     
/* 202 */     this.fileSize = this.aioFile.size();
/*     */   }
/*     */   
/*     */   public void setBufferCallback(BufferCallback callback)
/*     */   {
/* 207 */     this.aioFile.setBufferCallback(callback);
/*     */   }
/*     */   
/*     */   public int read(ByteBuffer bytes, IOAsyncTask callback) throws HornetQException
/*     */   {
/* 212 */     int bytesToRead = bytes.limit();
/*     */     
/* 214 */     long positionToRead = this.position.getAndAdd(bytesToRead);
/*     */     
/* 216 */     bytes.rewind();
/*     */     
/* 218 */     this.aioFile.read(positionToRead, bytesToRead, bytes, callback);
/*     */     
/* 220 */     return bytesToRead;
/*     */   }
/*     */   
/*     */   public int read(ByteBuffer bytes) throws Exception
/*     */   {
/* 225 */     SimpleWaitIOCallback waitCompletion = new SimpleWaitIOCallback();
/*     */     
/* 227 */     int bytesRead = read(bytes, waitCompletion);
/*     */     
/* 229 */     waitCompletion.waitCompletion();
/*     */     
/* 231 */     return bytesRead;
/*     */   }
/*     */   
/*     */   public void sync()
/*     */   {
/* 236 */     throw new UnsupportedOperationException("This method is not supported on AIO");
/*     */   }
/*     */   
/*     */   public long size() throws Exception
/*     */   {
/* 241 */     if (this.aioFile == null)
/*     */     {
/* 243 */       return getFile().length();
/*     */     }
/*     */     
/*     */ 
/* 247 */     return this.aioFile.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 254 */     return "AIOSequentialFile:" + getFile().getAbsolutePath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void onIOException(Exception code, String message)
/*     */   {
/* 263 */     this.factory.onIOError(code, message, this);
/*     */   }
/*     */   
/*     */   public void writeDirect(ByteBuffer bytes, boolean sync)
/*     */     throws Exception
/*     */   {
/* 269 */     if (sync)
/*     */     {
/* 271 */       SimpleWaitIOCallback completion = new SimpleWaitIOCallback();
/*     */       
/* 273 */       writeDirect(bytes, true, completion);
/*     */       
/* 275 */       completion.waitCompletion();
/*     */     }
/*     */     else
/*     */     {
/* 279 */       writeDirect(bytes, false, DummyCallback.getInstance());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeDirect(ByteBuffer bytes, boolean sync, IOAsyncTask callback)
/*     */   {
/* 289 */     int bytesToWrite = this.factory.calculateBlockSize(bytes.limit());
/*     */     
/* 291 */     long positionToWrite = this.position.getAndAdd(bytesToWrite);
/*     */     
/* 293 */     this.aioFile.write(positionToWrite, bytesToWrite, bytes, callback);
/*     */   }
/*     */   
/*     */   public void writeInternal(ByteBuffer bytes) throws HornetQException
/*     */   {
/* 298 */     int bytesToWrite = this.factory.calculateBlockSize(bytes.limit());
/*     */     
/* 300 */     long positionToWrite = this.position.getAndAdd(bytesToWrite);
/*     */     
/* 302 */     this.aioFile.writeInternal(positionToWrite, bytesToWrite, bytes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ByteBuffer newBuffer(int size, int limit)
/*     */   {
/* 311 */     size = this.factory.calculateBlockSize(size);
/* 312 */     limit = this.factory.calculateBlockSize(limit);
/*     */     
/* 314 */     ByteBuffer buffer = this.factory.newBuffer(size);
/* 315 */     buffer.limit(limit);
/* 316 */     return buffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkOpened()
/*     */   {
/* 324 */     if ((this.aioFile == null) || (!this.opened))
/*     */     {
/* 326 */       throw new IllegalStateException("File not opened");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\AIOSequentialFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */