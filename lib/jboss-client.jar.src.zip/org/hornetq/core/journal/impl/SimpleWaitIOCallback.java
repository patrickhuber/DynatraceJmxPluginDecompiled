/*    */ package org.hornetq.core.journal.impl;
/*    */ 
/*    */ import java.util.concurrent.CountDownLatch;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.hornetq.api.core.HornetQException;
/*    */ import org.hornetq.api.core.HornetQExceptionType;
/*    */ import org.hornetq.journal.HornetQJournalLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleWaitIOCallback
/*    */   extends SyncIOCompletion
/*    */ {
/* 32 */   private final CountDownLatch latch = new CountDownLatch(1);
/*    */   
/*    */   private volatile String errorMessage;
/*    */   
/* 36 */   private volatile int errorCode = 0;
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     return SimpleWaitIOCallback.class.getName();
/*    */   }
/*    */   
/*    */   public void done()
/*    */   {
/* 46 */     this.latch.countDown();
/*    */   }
/*    */   
/*    */   public void onError(int errorCode1, String errorMessage1)
/*    */   {
/* 51 */     this.errorCode = errorCode1;
/*    */     
/* 53 */     this.errorMessage = errorMessage1;
/*    */     
/* 55 */     HornetQJournalLogger.LOGGER.errorOnIOCallback(errorMessage1);
/*    */     
/* 57 */     this.latch.countDown();
/*    */   }
/*    */   
/*    */   public void waitCompletion()
/*    */     throws InterruptedException, HornetQException
/*    */   {
/*    */     for (;;)
/*    */     {
/* 65 */       if (this.latch.await(2L, TimeUnit.SECONDS)) {
/*    */         break;
/*    */       }
/*    */     }
/* 69 */     if (this.errorMessage != null)
/*    */     {
/* 71 */       throw HornetQExceptionType.createException(this.errorCode, this.errorMessage);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean waitCompletion(long timeout)
/*    */     throws InterruptedException, HornetQException
/*    */   {
/* 79 */     boolean retValue = this.latch.await(timeout, TimeUnit.MILLISECONDS);
/*    */     
/* 81 */     if (this.errorMessage != null)
/*    */     {
/* 83 */       throw HornetQExceptionType.createException(this.errorCode, this.errorMessage);
/*    */     }
/*    */     
/* 86 */     return retValue;
/*    */   }
/*    */   
/*    */   public void storeLineUp() {}
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\SimpleWaitIOCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */