package org.hornetq.core.journal.impl;

import org.hornetq.core.journal.SequentialFile;

public abstract interface JournalFile
{
  public abstract int getNegCount(JournalFile paramJournalFile);
  
  public abstract void incNegCount(JournalFile paramJournalFile);
  
  public abstract int getPosCount();
  
  public abstract void incPosCount();
  
  public abstract void decPosCount();
  
  public abstract void addSize(int paramInt);
  
  public abstract void decSize(int paramInt);
  
  public abstract int getLiveSize();
  
  public abstract int getTotalNegativeToOthers();
  
  public abstract void setCanReclaim(boolean paramBoolean);
  
  public abstract boolean isCanReclaim();
  
  public abstract int getRecordID();
  
  public abstract long getFileID();
  
  public abstract int getJournalVersion();
  
  public abstract SequentialFile getFile();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */