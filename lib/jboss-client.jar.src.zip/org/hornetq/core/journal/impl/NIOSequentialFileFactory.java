/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.hornetq.core.journal.IOCriticalErrorListener;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NIOSequentialFileFactory
/*     */   extends AbstractSequentialFileFactory
/*     */ {
/*     */   public NIOSequentialFileFactory(String journalDir)
/*     */   {
/*  34 */     this(journalDir, null);
/*     */   }
/*     */   
/*     */   public NIOSequentialFileFactory(String journalDir, IOCriticalErrorListener listener)
/*     */   {
/*  39 */     this(journalDir, false, 501760, 3333333, false, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NIOSequentialFileFactory(String journalDir, boolean buffered)
/*     */   {
/*  49 */     this(journalDir, buffered, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public NIOSequentialFileFactory(String journalDir, boolean buffered, IOCriticalErrorListener listener)
/*     */   {
/*  56 */     this(journalDir, buffered, 501760, 3333333, false, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NIOSequentialFileFactory(String journalDir, boolean buffered, int bufferSize, int bufferTimeout, boolean logRates)
/*     */   {
/*  70 */     this(journalDir, buffered, bufferSize, bufferTimeout, logRates, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NIOSequentialFileFactory(String journalDir, boolean buffered, int bufferSize, int bufferTimeout, boolean logRates, IOCriticalErrorListener listener)
/*     */   {
/*  80 */     super(journalDir, buffered, bufferSize, bufferTimeout, logRates, listener);
/*     */   }
/*     */   
/*     */   public SequentialFile createSequentialFile(String fileName, int maxIO)
/*     */   {
/*  85 */     if (maxIO < 1)
/*     */     {
/*     */ 
/*  88 */       maxIO = 1;
/*     */     }
/*     */     
/*  91 */     return new NIOSequentialFile(this, this.journalDir, fileName, maxIO, this.writeExecutor);
/*     */   }
/*     */   
/*     */   public boolean isSupportsCallbacks()
/*     */   {
/*  96 */     return this.timedBuffer != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ByteBuffer allocateDirectBuffer(int size)
/*     */   {
/* 103 */     ByteBuffer buffer2 = null;
/*     */     try
/*     */     {
/* 106 */       buffer2 = ByteBuffer.allocateDirect(size);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (OutOfMemoryError error)
/*     */     {
/*     */ 
/*     */ 
/* 114 */       WeakReference<Object> obj = new WeakReference(new Object());
/*     */       try
/*     */       {
/* 117 */         long timeout = System.currentTimeMillis() + 5000L;
/* 118 */         while ((System.currentTimeMillis() > timeout) && (obj.get() != null))
/*     */         {
/* 120 */           System.gc();
/* 121 */           Thread.sleep(100L);
/*     */         }
/*     */       }
/*     */       catch (InterruptedException e) {}
/*     */       
/*     */ 
/*     */ 
/* 128 */       buffer2 = ByteBuffer.allocateDirect(size);
/*     */     }
/*     */     
/* 131 */     return buffer2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void releaseDirectBuffer(ByteBuffer buffer) {}
/*     */   
/*     */ 
/*     */   public ByteBuffer newBuffer(int size)
/*     */   {
/* 141 */     return ByteBuffer.allocate(size);
/*     */   }
/*     */   
/*     */   public void clearBuffer(ByteBuffer buffer)
/*     */   {
/* 146 */     int limit = buffer.limit();
/* 147 */     buffer.rewind();
/*     */     
/* 149 */     for (int i = 0; i < limit; i++)
/*     */     {
/* 151 */       buffer.put((byte)0);
/*     */     }
/*     */     
/* 154 */     buffer.rewind();
/*     */   }
/*     */   
/*     */   public ByteBuffer wrapBuffer(byte[] bytes)
/*     */   {
/* 159 */     return ByteBuffer.wrap(bytes);
/*     */   }
/*     */   
/*     */   public int getAlignment()
/*     */   {
/* 164 */     return 1;
/*     */   }
/*     */   
/*     */   public int calculateBlockSize(int bytes)
/*     */   {
/* 169 */     return bytes;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\NIOSequentialFileFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */