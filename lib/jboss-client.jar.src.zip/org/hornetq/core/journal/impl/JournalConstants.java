package org.hornetq.core.journal.impl;

public final class JournalConstants
{
  public static final int DEFAULT_JOURNAL_BUFFER_SIZE_AIO = 501760;
  public static final int DEFAULT_JOURNAL_BUFFER_TIMEOUT_AIO = 500000;
  public static final int DEFAULT_JOURNAL_BUFFER_TIMEOUT_NIO = 3333333;
  public static final int DEFAULT_JOURNAL_BUFFER_SIZE_NIO = 501760;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */