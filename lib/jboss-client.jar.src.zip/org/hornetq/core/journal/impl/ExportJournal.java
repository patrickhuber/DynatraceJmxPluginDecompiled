/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import org.hornetq.core.journal.RecordInfo;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.utils.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExportJournal
/*     */ {
/*     */   public static void main(String[] arg)
/*     */   {
/*  52 */     if (arg.length != 5)
/*     */     {
/*  54 */       System.err.println("Use: java -cp hornetq-core.jar org.hornetq.core.journal.impl.ExportJournal <JournalDirectory> <JournalPrefix> <FileExtension> <FileSize> <FileOutput>");
/*  55 */       return;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  60 */       exportJournal(arg[0], arg[1], arg[2], 2, Integer.parseInt(arg[3]), arg[4]);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  64 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exportJournal(String directory, String journalPrefix, String journalSuffix, int minFiles, int fileSize, String fileOutput)
/*     */     throws Exception
/*     */   {
/*  77 */     FileOutputStream fileOut = new FileOutputStream(new File(fileOutput));
/*     */     
/*  79 */     BufferedOutputStream buffOut = new BufferedOutputStream(fileOut);
/*     */     
/*  81 */     PrintStream out = new PrintStream(buffOut);
/*     */     
/*  83 */     exportJournal(directory, journalPrefix, journalSuffix, minFiles, fileSize, out);
/*     */     
/*  85 */     out.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exportJournal(String directory, String journalPrefix, String journalSuffix, int minFiles, int fileSize, PrintStream out)
/*     */     throws Exception
/*     */   {
/*  95 */     NIOSequentialFileFactory nio = new NIOSequentialFileFactory(directory, null);
/*     */     
/*  97 */     JournalImpl journal = new JournalImpl(fileSize, minFiles, 0, 0, nio, journalPrefix, journalSuffix, 1);
/*     */     
/*  99 */     List<JournalFile> files = journal.orderFiles();
/*     */     
/* 101 */     for (JournalFile file : files)
/*     */     {
/* 103 */       out.println("#File," + file);
/*     */       
/* 105 */       exportJournalFile(out, nio, file);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exportJournalFile(PrintStream out, SequentialFileFactory fileFactory, JournalFile file)
/*     */     throws Exception
/*     */   {
/* 119 */     JournalImpl.readJournalFile(fileFactory, file, new JournalReaderCallback()
/*     */     {
/*     */       public void onReadUpdateRecordTX(long transactionID, RecordInfo recordInfo)
/*     */         throws Exception
/*     */       {
/* 124 */         this.val$out.println("operation@UpdateTX,txID@" + transactionID + "," + ExportJournal.describeRecord(recordInfo));
/*     */       }
/*     */       
/*     */       public void onReadUpdateRecord(RecordInfo recordInfo) throws Exception
/*     */       {
/* 129 */         this.val$out.println("operation@Update," + ExportJournal.describeRecord(recordInfo));
/*     */       }
/*     */       
/*     */       public void onReadRollbackRecord(long transactionID) throws Exception
/*     */       {
/* 134 */         this.val$out.println("operation@Rollback,txID@" + transactionID);
/*     */       }
/*     */       
/*     */       public void onReadPrepareRecord(long transactionID, byte[] extraData, int numberOfRecords) throws Exception
/*     */       {
/* 139 */         this.val$out.println("operation@Prepare,txID@" + transactionID + ",numberOfRecords@" + numberOfRecords + ",extraData@" + ExportJournal.encode(extraData));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       public void onReadDeleteRecordTX(long transactionID, RecordInfo recordInfo)
/*     */         throws Exception
/*     */       {
/* 148 */         this.val$out.println("operation@DeleteRecordTX,txID@" + transactionID + "," + ExportJournal.describeRecord(recordInfo));
/*     */       }
/*     */       
/*     */ 
/*     */       public void onReadDeleteRecord(long recordID)
/*     */         throws Exception
/*     */       {
/* 155 */         this.val$out.println("operation@DeleteRecord,id@" + recordID);
/*     */       }
/*     */       
/*     */       public void onReadCommitRecord(long transactionID, int numberOfRecords) throws Exception
/*     */       {
/* 160 */         this.val$out.println("operation@Commit,txID@" + transactionID + ",numberOfRecords@" + numberOfRecords);
/*     */       }
/*     */       
/*     */       public void onReadAddRecordTX(long transactionID, RecordInfo recordInfo) throws Exception
/*     */       {
/* 165 */         this.val$out.println("operation@AddRecordTX,txID@" + transactionID + "," + ExportJournal.describeRecord(recordInfo));
/*     */       }
/*     */       
/*     */       public void onReadAddRecord(RecordInfo recordInfo) throws Exception
/*     */       {
/* 170 */         this.val$out.println("operation@AddRecord," + ExportJournal.describeRecord(recordInfo));
/*     */       }
/*     */       
/*     */ 
/*     */       public void markAsDataFile(JournalFile file) {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private static String describeRecord(RecordInfo recordInfo)
/*     */   {
/* 181 */     return "id@" + recordInfo.id + ",userRecordType@" + recordInfo.userRecordType + ",length@" + recordInfo.data.length + ",isUpdate@" + recordInfo.isUpdate + ",compactCount@" + recordInfo.compactCount + ",data@" + encode(recordInfo.data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String encode(byte[] data)
/*     */   {
/* 196 */     return Base64.encodeBytes(data, 0, data.length, 24);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\ExportJournal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */