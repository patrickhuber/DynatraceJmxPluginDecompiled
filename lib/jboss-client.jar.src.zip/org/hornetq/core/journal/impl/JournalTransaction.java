/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.hornetq.api.core.HornetQExceptionType;
/*     */ import org.hornetq.core.journal.impl.dataformat.JournalInternalRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JournalTransaction
/*     */ {
/*     */   private JournalRecordProvider journal;
/*     */   private List<JournalUpdate> pos;
/*     */   private List<JournalUpdate> neg;
/*     */   private final long id;
/*     */   private Set<JournalFile> pendingFiles;
/*     */   private TransactionCallback currentCallback;
/*  51 */   private boolean compacting = false;
/*     */   
/*     */   private Map<JournalFile, TransactionCallback> callbackList;
/*     */   
/*  55 */   private JournalFile lastFile = null;
/*     */   
/*  57 */   private final AtomicInteger counter = new AtomicInteger();
/*     */   
/*     */   public JournalTransaction(long id, JournalRecordProvider journal)
/*     */   {
/*  61 */     this.id = id;
/*  62 */     this.journal = journal;
/*     */   }
/*     */   
/*     */   public void replaceRecordProvider(JournalRecordProvider provider)
/*     */   {
/*  67 */     this.journal = provider;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getId()
/*     */   {
/*  75 */     return this.id;
/*     */   }
/*     */   
/*     */   public int getCounter(JournalFile file)
/*     */   {
/*  80 */     return internalgetCounter(file).intValue();
/*     */   }
/*     */   
/*     */   public void incCounter(JournalFile file)
/*     */   {
/*  85 */     internalgetCounter(file).incrementAndGet();
/*     */   }
/*     */   
/*     */   public long[] getPositiveArray()
/*     */   {
/*  90 */     if (this.pos == null)
/*     */     {
/*  92 */       return new long[0];
/*     */     }
/*     */     
/*     */ 
/*  96 */     int i = 0;
/*  97 */     long[] ids = new long[this.pos.size()];
/*  98 */     for (JournalUpdate el : this.pos)
/*     */     {
/* 100 */       ids[(i++)] = el.getId();
/*     */     }
/* 102 */     return ids;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCompacting()
/*     */   {
/* 108 */     this.compacting = true;
/*     */     
/*     */ 
/*     */ 
/* 112 */     clear();
/*     */   }
/*     */   
/*     */ 
/*     */   public void merge(JournalTransaction other)
/*     */   {
/* 118 */     if (other.pos != null)
/*     */     {
/* 120 */       if (this.pos == null)
/*     */       {
/* 122 */         this.pos = new ArrayList();
/*     */       }
/*     */       
/* 125 */       this.pos.addAll(other.pos);
/*     */     }
/*     */     
/* 128 */     if (other.neg != null)
/*     */     {
/* 130 */       if (this.neg == null)
/*     */       {
/* 132 */         this.neg = new ArrayList();
/*     */       }
/*     */       
/* 135 */       this.neg.addAll(other.neg);
/*     */     }
/*     */     
/* 138 */     if (other.pendingFiles != null)
/*     */     {
/* 140 */       if (this.pendingFiles == null)
/*     */       {
/* 142 */         this.pendingFiles = new HashSet();
/*     */       }
/*     */       
/* 145 */       this.pendingFiles.addAll(other.pendingFiles);
/*     */     }
/*     */     
/* 148 */     this.compacting = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 160 */     if (this.pendingFiles != null)
/*     */     {
/* 162 */       this.pendingFiles.clear();
/*     */     }
/*     */     
/* 165 */     if (this.callbackList != null)
/*     */     {
/* 167 */       this.callbackList.clear();
/*     */     }
/*     */     
/* 170 */     if (this.pos != null)
/*     */     {
/* 172 */       this.pos.clear();
/*     */     }
/*     */     
/* 175 */     if (this.neg != null)
/*     */     {
/* 177 */       this.neg.clear();
/*     */     }
/*     */     
/* 180 */     this.counter.set(0);
/*     */     
/* 182 */     this.lastFile = null;
/*     */     
/* 184 */     this.currentCallback = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fillNumberOfRecords(JournalFile currentFile, JournalInternalRecord data)
/*     */   {
/* 193 */     data.setNumberOfRecords(getCounter(currentFile));
/*     */   }
/*     */   
/*     */   public TransactionCallback getCallback(JournalFile file) throws Exception
/*     */   {
/* 198 */     if (this.callbackList == null)
/*     */     {
/* 200 */       this.callbackList = new HashMap();
/*     */     }
/*     */     
/* 203 */     this.currentCallback = ((TransactionCallback)this.callbackList.get(file));
/*     */     
/* 205 */     if (this.currentCallback == null)
/*     */     {
/* 207 */       this.currentCallback = new TransactionCallback();
/* 208 */       this.callbackList.put(file, this.currentCallback);
/*     */     }
/*     */     
/* 211 */     if (this.currentCallback.getErrorMessage() != null)
/*     */     {
/* 213 */       throw HornetQExceptionType.createException(this.currentCallback.getErrorCode(), this.currentCallback.getErrorMessage());
/*     */     }
/*     */     
/* 216 */     this.currentCallback.countUp();
/*     */     
/* 218 */     return this.currentCallback;
/*     */   }
/*     */   
/*     */   public void addPositive(JournalFile file, long id, int size)
/*     */   {
/* 223 */     incCounter(file);
/*     */     
/* 225 */     addFile(file);
/*     */     
/* 227 */     if (this.pos == null)
/*     */     {
/* 229 */       this.pos = new ArrayList();
/*     */     }
/*     */     
/* 232 */     this.pos.add(new JournalUpdate(file, id, size, null));
/*     */   }
/*     */   
/*     */   public void addNegative(JournalFile file, long id)
/*     */   {
/* 237 */     incCounter(file);
/*     */     
/* 239 */     addFile(file);
/*     */     
/* 241 */     if (this.neg == null)
/*     */     {
/* 243 */       this.neg = new ArrayList();
/*     */     }
/*     */     
/* 246 */     this.neg.add(new JournalUpdate(file, id, 0, null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void commit(JournalFile file)
/*     */   {
/* 254 */     JournalCompactor compactor = this.journal.getCompactor();
/*     */     
/* 256 */     if (this.compacting)
/*     */     {
/* 258 */       compactor.addCommandCommit(this, file);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 263 */       if (this.pos != null)
/*     */       {
/* 265 */         for (JournalUpdate trUpdate : this.pos)
/*     */         {
/* 267 */           JournalRecord posFiles = (JournalRecord)this.journal.getRecords().get(Long.valueOf(trUpdate.id));
/*     */           
/* 269 */           if ((compactor != null) && (compactor.lookupRecord(trUpdate.id)))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 274 */             compactor.addCommandUpdate(trUpdate.id, trUpdate.file, trUpdate.size);
/*     */           }
/* 276 */           else if (posFiles == null)
/*     */           {
/* 278 */             posFiles = new JournalRecord(trUpdate.file, trUpdate.size);
/*     */             
/* 280 */             this.journal.getRecords().put(Long.valueOf(trUpdate.id), posFiles);
/*     */           }
/*     */           else
/*     */           {
/* 284 */             posFiles.addUpdateFile(trUpdate.file, trUpdate.size);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 289 */       if (this.neg != null)
/*     */       {
/* 291 */         for (JournalUpdate trDelete : this.neg)
/*     */         {
/* 293 */           if (compactor != null)
/*     */           {
/* 295 */             compactor.addCommandDelete(trDelete.id, trDelete.file);
/*     */           }
/*     */           else
/*     */           {
/* 299 */             JournalRecord posFiles = (JournalRecord)this.journal.getRecords().remove(Long.valueOf(trDelete.id));
/*     */             
/* 301 */             if (posFiles != null)
/*     */             {
/* 303 */               posFiles.delete(trDelete.file);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 312 */       for (JournalFile jf : this.pendingFiles)
/*     */       {
/* 314 */         file.incNegCount(jf);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void waitCallbacks() throws InterruptedException
/*     */   {
/* 321 */     if (this.callbackList != null)
/*     */     {
/* 323 */       for (TransactionCallback callback : this.callbackList.values())
/*     */       {
/* 325 */         callback.waitCompletion();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void waitCompletion()
/*     */     throws Exception
/*     */   {
/* 333 */     if (this.currentCallback != null)
/*     */     {
/* 335 */       this.currentCallback.waitCompletion();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rollback(JournalFile file)
/*     */   {
/* 345 */     JournalCompactor compactor = this.journal.getCompactor();
/*     */     
/* 347 */     if ((this.compacting) && (compactor != null))
/*     */     {
/* 349 */       compactor.addCommandRollback(this, file);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 363 */       for (JournalFile jf : this.pendingFiles)
/*     */       {
/* 365 */         file.incNegCount(jf);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepare(JournalFile file)
/*     */   {
/* 378 */     addFile(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void forget()
/*     */   {
/* 386 */     for (JournalFile jf : this.pendingFiles)
/*     */     {
/* 388 */       jf.decPosCount();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 396 */     return "JournalTransaction(" + this.id + ")";
/*     */   }
/*     */   
/*     */   private AtomicInteger internalgetCounter(JournalFile file)
/*     */   {
/* 401 */     if (this.lastFile != file)
/*     */     {
/*     */ 
/* 404 */       this.lastFile = file;
/* 405 */       this.counter.set(0);
/*     */     }
/* 407 */     return this.counter;
/*     */   }
/*     */   
/*     */   private void addFile(JournalFile file)
/*     */   {
/* 412 */     if (this.pendingFiles == null)
/*     */     {
/* 414 */       this.pendingFiles = new HashSet();
/*     */     }
/*     */     
/* 417 */     if (!this.pendingFiles.contains(file))
/*     */     {
/* 419 */       this.pendingFiles.add(file);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 424 */       file.incPosCount();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class JournalUpdate
/*     */   {
/*     */     private final JournalFile file;
/*     */     
/*     */ 
/*     */     long id;
/*     */     
/*     */ 
/*     */     int size;
/*     */     
/*     */ 
/*     */ 
/*     */     private JournalUpdate(JournalFile file, long id, int size)
/*     */     {
/* 444 */       this.file = file;
/* 445 */       this.id = id;
/* 446 */       this.size = size;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public long getId()
/*     */     {
/* 454 */       return this.id;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */