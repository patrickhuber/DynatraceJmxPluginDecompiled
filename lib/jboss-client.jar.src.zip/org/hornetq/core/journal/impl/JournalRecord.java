/*    */ package org.hornetq.core.journal.impl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.hornetq.api.core.Pair;
/*    */ import org.hornetq.core.journal.SequentialFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JournalRecord
/*    */ {
/*    */   private final JournalFile addFile;
/*    */   private final int size;
/*    */   private List<Pair<JournalFile, Integer>> updateFiles;
/*    */   
/*    */   public JournalRecord(JournalFile addFile, int size)
/*    */   {
/* 39 */     this.addFile = addFile;
/*    */     
/* 41 */     this.size = size;
/*    */     
/* 43 */     addFile.incPosCount();
/*    */     
/* 45 */     addFile.addSize(size);
/*    */   }
/*    */   
/*    */   void addUpdateFile(JournalFile updateFile, int size)
/*    */   {
/* 50 */     if (this.updateFiles == null)
/*    */     {
/* 52 */       this.updateFiles = new ArrayList();
/*    */     }
/*    */     
/* 55 */     this.updateFiles.add(new Pair(updateFile, Integer.valueOf(size)));
/*    */     
/* 57 */     updateFile.incPosCount();
/*    */     
/* 59 */     updateFile.addSize(size);
/*    */   }
/*    */   
/*    */   void delete(JournalFile file)
/*    */   {
/* 64 */     file.incNegCount(this.addFile);
/* 65 */     this.addFile.decSize(this.size);
/*    */     
/* 67 */     if (this.updateFiles != null)
/*    */     {
/* 69 */       for (Pair<JournalFile, Integer> updFile : this.updateFiles)
/*    */       {
/* 71 */         file.incNegCount((JournalFile)updFile.getA());
/* 72 */         ((JournalFile)updFile.getA()).decSize(((Integer)updFile.getB()).intValue());
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     StringBuilder buffer = new StringBuilder();
/* 81 */     buffer.append("JournalRecord(add=" + this.addFile.getFile().getFileName());
/*    */     
/* 83 */     if (this.updateFiles != null)
/*    */     {
/*    */ 
/* 86 */       for (Pair<JournalFile, Integer> update : this.updateFiles)
/*    */       {
/* 88 */         buffer.append(", update=" + ((JournalFile)update.getA()).getFile().getFileName());
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 93 */     buffer.append(")");
/*    */     
/* 95 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\JournalRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */