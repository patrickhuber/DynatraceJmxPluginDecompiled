/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.core.journal.EncodingSupport;
/*     */ import org.hornetq.core.journal.IOAsyncTask;
/*     */ import org.hornetq.core.journal.impl.dataformat.ByteArrayEncoding;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimedBuffer
/*     */ {
/*     */   public static final int MAX_CHECKS_ON_SLEEP = 20;
/*     */   private TimedBufferObserver bufferObserver;
/*  53 */   private final Semaphore spinLimiter = new Semaphore(1);
/*     */   
/*  55 */   private CheckTimer timerRunnable = new CheckTimer(null);
/*     */   
/*     */   private final int bufferSize;
/*     */   
/*     */   private final HornetQBuffer buffer;
/*     */   
/*  61 */   private int bufferLimit = 0;
/*     */   
/*     */ 
/*     */   private List<IOAsyncTask> callbacks;
/*     */   
/*     */   private volatile int timeout;
/*     */   
/*  68 */   private volatile boolean pendingSync = false;
/*     */   
/*     */ 
/*     */   private Thread timerThread;
/*     */   
/*     */ 
/*     */   private volatile boolean started;
/*     */   
/*     */ 
/*     */   private boolean delayFlush;
/*     */   
/*     */ 
/*     */   private final boolean logRates;
/*     */   
/*     */ 
/*  83 */   private final AtomicLong bytesFlushed = new AtomicLong(0L);
/*     */   
/*  85 */   private final AtomicLong flushesDone = new AtomicLong(0L);
/*     */   
/*     */   private Timer logRatesTimer;
/*     */   
/*     */   private TimerTask logRatesTimerTask;
/*     */   
/*  91 */   private boolean useSleep = true;
/*     */   
/*     */ 
/*  94 */   private boolean spinning = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TimedBuffer(int size, int timeout, boolean logRates)
/*     */   {
/* 104 */     this.bufferSize = size;
/*     */     
/* 106 */     this.logRates = logRates;
/*     */     
/* 108 */     if (logRates)
/*     */     {
/* 110 */       this.logRatesTimer = new Timer(true);
/*     */     }
/*     */     
/*     */ 
/* 114 */     this.buffer = HornetQBuffers.fixedBuffer(this.bufferSize);
/*     */     
/* 116 */     this.buffer.clear();
/*     */     
/* 118 */     this.bufferLimit = 0;
/*     */     
/* 120 */     this.callbacks = new ArrayList();
/*     */     
/* 122 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized boolean isUseSleep()
/*     */   {
/* 128 */     return this.useSleep;
/*     */   }
/*     */   
/*     */   public synchronized void setUseSleep(boolean useSleep)
/*     */   {
/* 133 */     this.useSleep = useSleep;
/*     */   }
/*     */   
/*     */   public synchronized void start()
/*     */   {
/* 138 */     if (this.started)
/*     */     {
/* 140 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 146 */       this.spinLimiter.acquire();
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 150 */       throw new HornetQInterruptedException(e);
/*     */     }
/*     */     
/* 153 */     this.timerRunnable = new CheckTimer(null);
/*     */     
/* 155 */     this.timerThread = new Thread(this.timerRunnable, "hornetq-buffer-timeout");
/*     */     
/* 157 */     this.timerThread.start();
/*     */     
/* 159 */     if (this.logRates)
/*     */     {
/* 161 */       this.logRatesTimerTask = new LogRatesTimerTask(null);
/*     */       
/* 163 */       this.logRatesTimer.scheduleAtFixedRate(this.logRatesTimerTask, 2000L, 2000L);
/*     */     }
/*     */     
/* 166 */     this.started = true;
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 171 */     if (!this.started)
/*     */     {
/* 173 */       return;
/*     */     }
/*     */     
/* 176 */     flush();
/*     */     
/* 178 */     this.bufferObserver = null;
/*     */     
/* 180 */     this.timerRunnable.close();
/*     */     
/* 182 */     this.spinLimiter.release();
/*     */     
/* 184 */     if (this.logRates)
/*     */     {
/* 186 */       this.logRatesTimerTask.cancel();
/*     */     }
/*     */     
/* 189 */     while (this.timerThread.isAlive())
/*     */     {
/*     */       try
/*     */       {
/* 193 */         this.timerThread.join();
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 197 */         throw new HornetQInterruptedException(e);
/*     */       }
/*     */     }
/*     */     
/* 201 */     this.started = false;
/*     */   }
/*     */   
/*     */   public synchronized void setObserver(TimedBufferObserver observer)
/*     */   {
/* 206 */     if (this.bufferObserver != null)
/*     */     {
/* 208 */       flush();
/*     */     }
/*     */     
/* 211 */     this.bufferObserver = observer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean checkSize(int sizeChecked)
/*     */   {
/* 221 */     if (!this.started)
/*     */     {
/* 223 */       throw new IllegalStateException("TimedBuffer is not started");
/*     */     }
/*     */     
/* 226 */     if (sizeChecked > this.bufferSize)
/*     */     {
/* 228 */       throw new IllegalStateException("Can't write records bigger than the bufferSize(" + this.bufferSize + ") on the journal");
/*     */     }
/*     */     
/*     */ 
/* 232 */     if ((this.bufferLimit == 0) || (this.buffer.writerIndex() + sizeChecked > this.bufferLimit))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 237 */       flush();
/*     */       
/* 239 */       this.delayFlush = true;
/*     */       
/* 241 */       int remainingInFile = this.bufferObserver.getRemainingBytes();
/*     */       
/* 243 */       if (sizeChecked > remainingInFile)
/*     */       {
/* 245 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */       this.bufferLimit = Math.min(remainingInFile, this.bufferSize);
/*     */       
/* 255 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 260 */     this.delayFlush = true;
/*     */     
/* 262 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void addBytes(HornetQBuffer bytes, boolean sync, IOAsyncTask callback)
/*     */   {
/* 268 */     addBytes(new ByteArrayEncoding(bytes.toByteBuffer().array()), sync, callback);
/*     */   }
/*     */   
/*     */   public synchronized void addBytes(EncodingSupport bytes, boolean sync, IOAsyncTask callback)
/*     */   {
/* 273 */     if (!this.started)
/*     */     {
/* 275 */       throw new IllegalStateException("TimedBuffer is not started");
/*     */     }
/*     */     
/* 278 */     this.delayFlush = false;
/*     */     
/* 280 */     bytes.encode(this.buffer);
/*     */     
/* 282 */     this.callbacks.add(callback);
/*     */     
/* 284 */     if (sync)
/*     */     {
/* 286 */       this.pendingSync = true;
/*     */       
/* 288 */       startSpin();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void flush()
/*     */   {
/* 295 */     flush(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush(boolean force)
/*     */   {
/* 304 */     synchronized (this)
/*     */     {
/* 306 */       if (!this.started)
/*     */       {
/* 308 */         throw new IllegalStateException("TimedBuffer is not started");
/*     */       }
/*     */       
/* 311 */       if (((force) || (!this.delayFlush)) && (this.buffer.writerIndex() > 0))
/*     */       {
/* 313 */         int pos = this.buffer.writerIndex();
/*     */         
/* 315 */         if (this.logRates)
/*     */         {
/* 317 */           this.bytesFlushed.addAndGet(pos);
/*     */         }
/*     */         
/* 320 */         ByteBuffer bufferToFlush = this.bufferObserver.newBuffer(this.bufferSize, pos);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */         bufferToFlush.put(this.buffer.toByteBuffer().array(), 0, pos);
/*     */         
/* 328 */         this.bufferObserver.flushBuffer(bufferToFlush, this.pendingSync, this.callbacks);
/*     */         
/* 330 */         stopSpin();
/*     */         
/* 332 */         this.pendingSync = false;
/*     */         
/*     */ 
/* 335 */         this.callbacks = new LinkedList();
/*     */         
/* 337 */         this.buffer.clear();
/*     */         
/* 339 */         this.bufferLimit = 0;
/*     */         
/* 341 */         this.flushesDone.incrementAndGet();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class LogRatesTimerTask
/*     */     extends TimerTask
/*     */   {
/*     */     private boolean closed;
/*     */     
/*     */ 
/*     */     private long lastExecution;
/*     */     
/*     */ 
/*     */     private long lastBytesFlushed;
/*     */     
/*     */     private long lastFlushesDone;
/*     */     
/*     */ 
/*     */     private LogRatesTimerTask() {}
/*     */     
/*     */ 
/*     */     public synchronized void run()
/*     */     {
/* 367 */       if (!this.closed)
/*     */       {
/* 369 */         long now = System.currentTimeMillis();
/*     */         
/* 371 */         long bytesF = TimedBuffer.this.bytesFlushed.get();
/* 372 */         long flushesD = TimedBuffer.this.flushesDone.get();
/*     */         
/* 374 */         if (this.lastExecution != 0L)
/*     */         {
/* 376 */           double rate = 1000.0D * (bytesF - this.lastBytesFlushed) / (now - this.lastExecution);
/* 377 */           HornetQJournalLogger.LOGGER.writeRate(Double.valueOf(rate), Long.valueOf((rate / 1048576.0D)));
/* 378 */           double flushRate = 1000.0D * (flushesD - this.lastFlushesDone) / (now - this.lastExecution);
/* 379 */           HornetQJournalLogger.LOGGER.flushRate(Double.valueOf(flushRate));
/*     */         }
/*     */         
/* 382 */         this.lastExecution = now;
/*     */         
/* 384 */         this.lastBytesFlushed = bytesF;
/*     */         
/* 386 */         this.lastFlushesDone = flushesD;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     public synchronized boolean cancel()
/*     */     {
/* 393 */       this.closed = true;
/*     */       
/* 395 */       return super.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   private class CheckTimer implements Runnable
/*     */   {
/* 401 */     private volatile boolean closed = false;
/*     */     
/* 403 */     int checks = 0;
/* 404 */     int failedChecks = 0;
/* 405 */     long timeBefore = 0L;
/*     */     
/* 407 */     final int sleepMillis = TimedBuffer.this.timeout / 1000000;
/* 408 */     final int sleepNanos = TimedBuffer.this.timeout % 1000000;
/*     */     
/*     */     private CheckTimer() {}
/*     */     
/*     */     public void run() {
/* 413 */       long lastFlushTime = 0L;
/*     */       
/* 415 */       while (!this.closed)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 422 */         if (TimedBuffer.this.pendingSync)
/*     */         {
/* 424 */           if (TimedBuffer.this.isUseSleep())
/*     */           {
/*     */ 
/* 427 */             TimedBuffer.this.flush();
/* 428 */             lastFlushTime = System.nanoTime();
/*     */           }
/* 430 */           else if ((TimedBuffer.this.bufferObserver != null) && (System.nanoTime() > lastFlushTime + TimedBuffer.this.timeout))
/*     */           {
/*     */ 
/* 433 */             TimedBuffer.this.flush();
/* 434 */             lastFlushTime = System.nanoTime();
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 439 */         sleepIfPossible();
/*     */         
/*     */         try
/*     */         {
/* 443 */           TimedBuffer.this.spinLimiter.acquire();
/*     */           
/* 445 */           Thread.yield();
/*     */           
/* 447 */           TimedBuffer.this.spinLimiter.release();
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/* 451 */           throw new HornetQInterruptedException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void sleepIfPossible()
/*     */     {
/* 463 */       if (TimedBuffer.this.isUseSleep())
/*     */       {
/* 465 */         if (this.checks < 20)
/*     */         {
/* 467 */           this.timeBefore = System.nanoTime();
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 472 */           TimedBuffer.this.sleep(this.sleepMillis, this.sleepNanos);
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/* 476 */           throw new HornetQInterruptedException(e);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 480 */           TimedBuffer.this.setUseSleep(false);
/* 481 */           HornetQJournalLogger.LOGGER.warn(e.getMessage() + ", disabling sleep on TimedBuffer, using spin now", e);
/*     */         }
/*     */         
/* 484 */         if (this.checks < 20)
/*     */         {
/* 486 */           long realTimeSleep = System.nanoTime() - this.timeBefore;
/*     */           
/*     */ 
/* 489 */           if (realTimeSleep > TimedBuffer.this.timeout * 1.5D)
/*     */           {
/* 491 */             this.failedChecks += 1;
/*     */           }
/*     */           
/* 494 */           if (++this.checks >= 20)
/*     */           {
/* 496 */             if (this.failedChecks > 10.0D)
/*     */             {
/* 498 */               HornetQJournalLogger.LOGGER.debug("Thread.sleep with nano seconds is not working as expected, Your kernel possibly doesn't support real time. the Journal TimedBuffer will spin for timeouts");
/* 499 */               TimedBuffer.this.setUseSleep(false);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public void close()
/*     */     {
/* 508 */       this.closed = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sleep(int sleepMillis, int sleepNanos)
/*     */     throws InterruptedException
/*     */   {
/* 521 */     Thread.sleep(sleepMillis, sleepNanos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopSpin()
/*     */   {
/* 529 */     if (this.spinning)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/*     */ 
/* 535 */         this.spinLimiter.acquire();
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 539 */         throw new HornetQInterruptedException(e);
/*     */       }
/*     */       
/* 542 */       this.spinning = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startSpin()
/*     */   {
/* 552 */     if (!this.spinning)
/*     */     {
/* 554 */       this.spinLimiter.release();
/*     */       
/* 556 */       this.spinning = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\TimedBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */