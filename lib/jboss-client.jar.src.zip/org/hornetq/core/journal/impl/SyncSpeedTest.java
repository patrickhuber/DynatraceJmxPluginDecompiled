/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileChannel;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.hornetq.core.journal.IOAsyncTask;
/*     */ import org.hornetq.core.journal.SequentialFile;
/*     */ import org.hornetq.core.journal.SequentialFileFactory;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncSpeedTest
/*     */ {
/*     */   protected SequentialFileFactory fileFactory;
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/*  46 */       new SyncSpeedTest().testScaleAIO();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  50 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  56 */   public boolean AIO = true;
/*     */   
/*     */   protected void setupFactory()
/*     */   {
/*  60 */     if (this.AIO)
/*     */     {
/*  62 */       this.fileFactory = new AIOSequentialFileFactory(".", 0, 0, false, null);
/*     */     }
/*     */     else
/*     */     {
/*  66 */       this.fileFactory = new NIOSequentialFileFactory(".", false, 0, 0, false, null);
/*     */     }
/*     */   }
/*     */   
/*     */   protected SequentialFile createSequentialFile(String fileName)
/*     */   {
/*  72 */     if (this.AIO)
/*     */     {
/*  74 */       return new AIOSequentialFile(this.fileFactory, 0, 0L, ".", fileName, 100000, null, null, Executors.newSingleThreadExecutor());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */     return new NIOSequentialFile(this.fileFactory, new File(fileName), 1000, null);
/*     */   }
/*     */   
/*     */   public void run2()
/*     */     throws Exception
/*     */   {
/*  92 */     setupFactory();
/*     */     
/*  94 */     int recordSize = 131072;
/*     */     
/*     */     for (;;)
/*     */     {
/*  98 */       System.out.println("** record size is " + recordSize);
/*     */       
/* 100 */       int warmup = 500;
/*     */       
/* 102 */       int its = 500;
/*     */       
/* 104 */       int fileSize = (its + warmup) * recordSize;
/*     */       
/* 106 */       SequentialFile file = createSequentialFile("sync-speed-test.dat");
/*     */       
/* 108 */       if (file.exists())
/*     */       {
/* 110 */         file.delete();
/*     */       }
/*     */       
/* 113 */       file.open();
/*     */       
/* 115 */       file.fill(0, fileSize, (byte)88);
/*     */       
/* 117 */       if (!this.AIO)
/*     */       {
/* 119 */         file.sync();
/*     */       }
/*     */       
/* 122 */       ByteBuffer bb1 = generateBuffer(recordSize, (byte)104);
/*     */       
/* 124 */       long start = 0L;
/*     */       
/* 126 */       for (int i = 0; i < its + warmup; i++)
/*     */       {
/* 128 */         if (i == warmup)
/*     */         {
/* 130 */           start = System.currentTimeMillis();
/*     */         }
/*     */         
/* 133 */         bb1.rewind();
/*     */         
/* 135 */         file.writeDirect(bb1, true);
/*     */       }
/*     */       
/* 138 */       long end = System.currentTimeMillis();
/*     */       
/* 140 */       double rate = 1000.0D * its / (end - start);
/*     */       
/* 142 */       double throughput = recordSize * rate;
/*     */       
/* 144 */       System.out.println("Rate of " + rate + " syncs per sec");
/* 145 */       System.out.println("Throughput " + throughput + " bytes per sec");
/* 146 */       System.out.println("*************");
/*     */       
/* 148 */       recordSize *= 2;
/*     */     }
/*     */   }
/*     */   
/*     */   public void run() throws Exception
/*     */   {
/* 154 */     int recordSize = 256;
/*     */     
/*     */     for (;;)
/*     */     {
/* 158 */       System.out.println("** record size is " + recordSize);
/*     */       
/* 160 */       int warmup = 500;
/*     */       
/* 162 */       int its = 500;
/*     */       
/* 164 */       int fileSize = (its + warmup) * recordSize;
/*     */       
/* 166 */       File file = new File("sync-speed-test.dat");
/*     */       
/* 168 */       if (file.exists())
/*     */       {
/* 170 */         if (!file.delete())
/*     */         {
/* 172 */           HornetQJournalLogger.LOGGER.errorDeletingFile(file);
/*     */         }
/*     */       }
/*     */       
/* 176 */       boolean created = file.createNewFile();
/* 177 */       if (!created) {
/* 178 */         throw new IOException("could not create file " + file);
/*     */       }
/* 180 */       RandomAccessFile rfile = new RandomAccessFile(file, "rw");
/*     */       
/* 182 */       FileChannel channel = rfile.getChannel();
/*     */       
/* 184 */       ByteBuffer bb = generateBuffer(fileSize, (byte)120);
/*     */       
/* 186 */       write(bb, channel, fileSize);
/*     */       
/* 188 */       channel.force(true);
/*     */       
/* 190 */       channel.position(0L);
/*     */       
/* 192 */       ByteBuffer bb1 = generateBuffer(recordSize, (byte)104);
/*     */       
/* 194 */       long start = 0L;
/*     */       
/* 196 */       for (int i = 0; i < its + warmup; i++)
/*     */       {
/* 198 */         if (i == warmup)
/*     */         {
/* 200 */           start = System.currentTimeMillis();
/*     */         }
/*     */         
/* 203 */         bb1.flip();
/* 204 */         channel.write(bb1);
/* 205 */         channel.force(false);
/*     */       }
/*     */       
/* 208 */       long end = System.currentTimeMillis();
/*     */       
/* 210 */       double rate = 1000.0D * its / (end - start);
/*     */       
/* 212 */       double throughput = recordSize * rate;
/*     */       
/* 214 */       System.out.println("Rate of " + rate + " syncs per sec");
/* 215 */       System.out.println("Throughput " + throughput + " bytes per sec");
/*     */       
/* 217 */       recordSize *= 2;
/*     */     }
/*     */   }
/*     */   
/*     */   public void testScaleAIO() throws Exception
/*     */   {
/* 223 */     setupFactory();
/*     */     
/* 225 */     int recordSize = 1024;
/*     */     
/* 227 */     System.out.println("** record size is 1024");
/*     */     
/* 229 */     int its = 10;
/*     */     
/* 231 */     for (int numThreads = 1; numThreads <= 10; numThreads++)
/*     */     {
/*     */ 
/* 234 */       int fileSize = 10240 * numThreads;
/*     */       
/* 236 */       final SequentialFile file = createSequentialFile("sync-speed-test.dat");
/*     */       
/* 238 */       if (file.exists())
/*     */       {
/* 240 */         file.delete();
/*     */       }
/*     */       
/* 243 */       file.open();
/*     */       
/* 245 */       file.fill(0, fileSize, (byte)88);
/*     */       
/* 247 */       if (!this.AIO)
/*     */       {
/* 249 */         file.sync();
/*     */       }
/*     */       
/* 252 */       final CountDownLatch latch = new CountDownLatch(10 * numThreads);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 267 */       final IOAsyncTask task = new IOAsyncTask()
/*     */       {
/*     */         public void done()
/*     */         {
/* 258 */           latch.countDown();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         public void onError(int errorCode, String errorMessage) {}
/* 296 */       };
/* 297 */       Set<Thread> threads = new HashSet();
/*     */       
/* 299 */       for (int i = 0; i < numThreads; i++)
/*     */       {
/* 301 */         Runnable runner = new Runnable()
/*     */         {
/*     */           private final ByteBuffer bb1;
/*     */           
/*     */           public void run()
/*     */           {
/* 280 */             for (int i = 0; i < 10; i++)
/*     */             {
/* 282 */               this.bb1.rewind();
/*     */               
/* 284 */               file.writeDirect(this.bb1, true, task);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */         };
/* 303 */         Thread t = new Thread(runner);
/*     */         
/* 305 */         threads.add(t);
/*     */       }
/*     */       
/* 308 */       long start = System.currentTimeMillis();
/*     */       
/* 310 */       for (Thread t : threads)
/*     */       {
/* 312 */         HornetQJournalLogger.LOGGER.startingThread();
/* 313 */         t.start();
/*     */       }
/*     */       
/* 316 */       for (Thread t : threads)
/*     */       {
/* 318 */         t.join();
/*     */       }
/*     */       
/* 321 */       latch.await();
/*     */       
/* 323 */       long end = System.currentTimeMillis();
/*     */       
/* 325 */       double rate = 10000.0D * numThreads / (end - start);
/*     */       
/* 327 */       double throughput = 1024.0D * rate;
/*     */       
/* 329 */       System.out.println("For " + numThreads + " threads:");
/* 330 */       System.out.println("Rate of " + rate + " records per sec");
/* 331 */       System.out.println("Throughput " + throughput + " bytes per sec");
/* 332 */       System.out.println("*************");
/*     */     }
/*     */   }
/*     */   
/*     */   private void write(ByteBuffer buffer, FileChannel channel, int size) throws Exception
/*     */   {
/* 338 */     buffer.flip();
/*     */     
/* 340 */     channel.write(buffer);
/*     */   }
/*     */   
/*     */   private ByteBuffer generateBuffer(int size, byte ch)
/*     */   {
/* 345 */     ByteBuffer bb = ByteBuffer.allocateDirect(size);
/*     */     
/* 347 */     for (int i = 0; i < size; i++)
/*     */     {
/* 349 */       bb.put(ch);
/*     */     }
/*     */     
/* 352 */     return bb;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\SyncSpeedTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */