/*     */ package org.hornetq.core.journal.impl;
/*     */ 
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Reclaimer
/*     */ {
/*  40 */   private static boolean trace = HornetQJournalLogger.LOGGER.isTraceEnabled();
/*     */   
/*     */   private static void trace(String message)
/*     */   {
/*  44 */     HornetQJournalLogger.LOGGER.trace(message);
/*     */   }
/*     */   
/*     */   public void scan(JournalFile[] files)
/*     */   {
/*  49 */     for (int i = 0; i < files.length; i++)
/*     */     {
/*     */ 
/*     */ 
/*  53 */       JournalFile currentFile = files[i];
/*     */       
/*  55 */       int posCount = currentFile.getPosCount();
/*     */       
/*  57 */       int totNeg = 0;
/*     */       
/*  59 */       if (trace)
/*     */       {
/*  61 */         trace("posCount on " + currentFile + " = " + posCount);
/*     */       }
/*     */       
/*  64 */       for (int j = i; j < files.length; j++)
/*     */       {
/*  66 */         if (trace)
/*     */         {
/*  68 */           if (files[j].getNegCount(currentFile) != 0)
/*     */           {
/*  70 */             trace("Negative from " + files[j] + " into " + currentFile + " = " + files[j].getNegCount(currentFile));
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */         totNeg += files[j].getNegCount(currentFile);
/*     */       }
/*     */       
/*  81 */       currentFile.setCanReclaim(true);
/*     */       
/*  83 */       if (posCount <= totNeg)
/*     */       {
/*     */ 
/*     */ 
/*  87 */         for (int j = 0; j <= i; j++)
/*     */         {
/*  89 */           JournalFile file = files[j];
/*     */           
/*  91 */           int negCount = currentFile.getNegCount(file);
/*     */           
/*  93 */           if (negCount != 0)
/*     */           {
/*  95 */             if (!file.isCanReclaim())
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */               if (trace)
/*     */               {
/* 103 */                 trace(currentFile + " Can't be reclaimed because " + file + " has negative values");
/*     */               }
/*     */               
/* 106 */               currentFile.setCanReclaim(false);
/*     */               
/* 108 */               break;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/*     */       } else {
/* 115 */         currentFile.setCanReclaim(false);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\impl\Reclaimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */