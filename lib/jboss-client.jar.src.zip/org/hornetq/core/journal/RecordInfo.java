/*    */ package org.hornetq.core.journal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RecordInfo
/*    */ {
/*    */   public final short compactCount;
/*    */   
/*    */ 
/*    */   public final long id;
/*    */   
/*    */ 
/*    */   public final byte userRecordType;
/*    */   
/*    */ 
/*    */   public final byte[] data;
/*    */   
/*    */ 
/*    */   public boolean isUpdate;
/*    */   
/*    */ 
/*    */ 
/*    */   public RecordInfo(long id, byte userRecordType, byte[] data, boolean isUpdate, short compactCount)
/*    */   {
/* 26 */     this.id = id;
/*    */     
/* 28 */     this.userRecordType = userRecordType;
/*    */     
/* 30 */     this.data = data;
/*    */     
/* 32 */     this.isUpdate = isUpdate;
/*    */     
/* 34 */     this.compactCount = compactCount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte getUserRecordType()
/*    */   {
/* 54 */     return this.userRecordType;
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 60 */     return (int)(this.id >>> 32 ^ this.id);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 66 */     if (!(other instanceof RecordInfo))
/*    */     {
/* 68 */       return false;
/*    */     }
/* 70 */     RecordInfo r = (RecordInfo)other;
/*    */     
/* 72 */     return r.id == this.id;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 78 */     return "RecordInfo (id=" + this.id + ", userRecordType = " + this.userRecordType + ", data.length = " + this.data.length + ", isUpdate = " + this.isUpdate;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\RecordInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */