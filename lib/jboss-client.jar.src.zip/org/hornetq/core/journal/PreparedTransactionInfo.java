/*    */ package org.hornetq.core.journal;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreparedTransactionInfo
/*    */ {
/*    */   public final long id;
/*    */   public final byte[] extraData;
/* 33 */   public final List<RecordInfo> records = new ArrayList();
/*    */   
/* 35 */   public final List<RecordInfo> recordsToDelete = new ArrayList();
/*    */   
/*    */   public PreparedTransactionInfo(long id, byte[] extraData)
/*    */   {
/* 39 */     this.id = id;
/*    */     
/* 41 */     this.extraData = extraData;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\PreparedTransactionInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */