/*     */ package org.hornetq.core.journal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JournalLoadInformation
/*     */ {
/*  23 */   private int numberOfRecords = 0;
/*     */   
/*  25 */   private long maxID = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalLoadInformation() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JournalLoadInformation(int numberOfRecords, long maxID)
/*     */   {
/*  39 */     this.numberOfRecords = numberOfRecords;
/*  40 */     this.maxID = maxID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfRecords()
/*     */   {
/*  48 */     return this.numberOfRecords;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNumberOfRecords(int numberOfRecords)
/*     */   {
/*  56 */     this.numberOfRecords = numberOfRecords;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMaxID()
/*     */   {
/*  64 */     return this.maxID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaxID(long maxID)
/*     */   {
/*  72 */     this.maxID = maxID;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  78 */     int prime = 31;
/*  79 */     int result = 1;
/*  80 */     result = 31 * result + (int)(this.maxID ^ this.maxID >>> 32);
/*  81 */     result = 31 * result + this.numberOfRecords;
/*  82 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (this == obj)
/*     */     {
/*  90 */       return true;
/*     */     }
/*  92 */     if (obj == null)
/*     */     {
/*  94 */       return false;
/*     */     }
/*  96 */     if (getClass() != obj.getClass())
/*     */     {
/*  98 */       return false;
/*     */     }
/* 100 */     JournalLoadInformation other = (JournalLoadInformation)obj;
/* 101 */     if (this.maxID != other.maxID)
/*     */     {
/* 103 */       return false;
/*     */     }
/* 105 */     if (this.numberOfRecords != other.numberOfRecords)
/*     */     {
/* 107 */       return false;
/*     */     }
/* 109 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 115 */     return "JournalLoadInformation [maxID=" + this.maxID + ", numberOfRecords=" + this.numberOfRecords + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\journal\JournalLoadInformation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */