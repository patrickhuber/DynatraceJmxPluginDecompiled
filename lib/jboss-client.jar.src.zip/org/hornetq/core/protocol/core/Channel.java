package org.hornetq.core.protocol.core;

import java.util.concurrent.locks.Lock;
import org.hornetq.api.core.HornetQException;

public abstract interface Channel
{
  public abstract long getID();
  
  public abstract boolean supports(byte paramByte);
  
  public abstract boolean send(Packet paramPacket);
  
  public abstract boolean sendBatched(Packet paramPacket);
  
  public abstract boolean sendAndFlush(Packet paramPacket);
  
  public abstract Packet sendBlocking(Packet paramPacket, byte paramByte)
    throws HornetQException;
  
  public abstract void setHandler(ChannelHandler paramChannelHandler);
  
  public abstract ChannelHandler getHandler();
  
  public abstract void close();
  
  public abstract void transferConnection(CoreRemotingConnection paramCoreRemotingConnection);
  
  public abstract void replayCommands(int paramInt);
  
  public abstract int getLastConfirmedCommandID();
  
  public abstract void lock();
  
  public abstract void unlock();
  
  public abstract void returnBlocking();
  
  public abstract void returnBlocking(Throwable paramThrowable);
  
  public abstract Lock getLock();
  
  public abstract CoreRemotingConnection getConnection();
  
  public abstract void confirm(Packet paramPacket);
  
  public abstract void setCommandConfirmationHandler(CommandConfirmationHandler paramCommandConfirmationHandler);
  
  public abstract void flushConfirmations();
  
  public abstract void handlePacket(Packet paramPacket);
  
  public abstract void clearCommands();
  
  public abstract int getConfirmationWindowSize();
  
  public abstract void setTransferring(boolean paramBoolean);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\Channel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */