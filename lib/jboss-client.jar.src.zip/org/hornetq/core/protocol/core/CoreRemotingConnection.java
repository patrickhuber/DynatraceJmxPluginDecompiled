package org.hornetq.core.protocol.core;

import org.hornetq.core.security.HornetQPrincipal;
import org.hornetq.spi.core.protocol.RemotingConnection;

public abstract interface CoreRemotingConnection
  extends RemotingConnection
{
  public abstract int getClientVersion();
  
  public abstract void setClientVersion(int paramInt);
  
  public abstract Channel getChannel(long paramLong, int paramInt);
  
  public abstract void putChannel(long paramLong, Channel paramChannel);
  
  public abstract boolean removeChannel(long paramLong);
  
  public abstract long generateChannelID();
  
  public abstract void syncIDGeneratorSequence(long paramLong);
  
  public abstract long getIDGeneratorSequence();
  
  public abstract long getBlockingCallTimeout();
  
  public abstract long getBlockingCallFailoverTimeout();
  
  public abstract Object getTransferLock();
  
  public abstract HornetQPrincipal getDefaultHornetQPrincipal();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\CoreRemotingConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */