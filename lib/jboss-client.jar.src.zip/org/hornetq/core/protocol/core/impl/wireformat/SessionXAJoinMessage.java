/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAJoinMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXAJoinMessage(Xid xid)
/*    */   {
/* 32 */     super((byte)57);
/*    */     
/* 34 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXAJoinMessage()
/*    */   {
/* 39 */     super((byte)57);
/*    */   }
/*    */   
/*    */   public Xid getXid()
/*    */   {
/* 44 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 50 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 56 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 62 */     int prime = 31;
/* 63 */     int result = super.hashCode();
/* 64 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 65 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 71 */     if (this == obj)
/* 72 */       return true;
/* 73 */     if (!super.equals(obj))
/* 74 */       return false;
/* 75 */     if (!(obj instanceof SessionXAJoinMessage))
/* 76 */       return false;
/* 77 */     SessionXAJoinMessage other = (SessionXAJoinMessage)obj;
/* 78 */     if (this.xid == null)
/*    */     {
/* 80 */       if (other.xid != null) {
/* 81 */         return false;
/*    */       }
/* 83 */     } else if (!this.xid.equals(other.xid))
/* 84 */       return false;
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAJoinMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */