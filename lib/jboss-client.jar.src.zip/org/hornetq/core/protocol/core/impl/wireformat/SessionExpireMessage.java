/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionExpireMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private long consumerID;
/*     */   private long messageID;
/*     */   
/*     */   public SessionExpireMessage(long consumerID, long messageID)
/*     */   {
/*  38 */     super((byte)42);
/*     */     
/*  40 */     this.consumerID = consumerID;
/*     */     
/*  42 */     this.messageID = messageID;
/*     */   }
/*     */   
/*     */   public SessionExpireMessage()
/*     */   {
/*  47 */     super((byte)42);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getConsumerID()
/*     */   {
/*  54 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public long getMessageID()
/*     */   {
/*  59 */     return this.messageID;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  65 */     buffer.writeLong(this.consumerID);
/*     */     
/*  67 */     buffer.writeLong(this.messageID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  73 */     this.consumerID = buffer.readLong();
/*     */     
/*  75 */     this.messageID = buffer.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  81 */     int prime = 31;
/*  82 */     int result = super.hashCode();
/*  83 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/*  84 */     result = 31 * result + (int)(this.messageID ^ this.messageID >>> 32);
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  91 */     if (this == obj)
/*  92 */       return true;
/*  93 */     if (!super.equals(obj))
/*  94 */       return false;
/*  95 */     if (!(obj instanceof SessionExpireMessage))
/*  96 */       return false;
/*  97 */     SessionExpireMessage other = (SessionExpireMessage)obj;
/*  98 */     if (this.consumerID != other.consumerID)
/*  99 */       return false;
/* 100 */     if (this.messageID != other.messageID)
/* 101 */       return false;
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionExpireMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */