/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAGetTimeoutResponseMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private int timeoutSeconds;
/*    */   
/*    */   public SessionXAGetTimeoutResponseMessage(int timeoutSeconds)
/*    */   {
/* 29 */     super((byte)66);
/*    */     
/* 31 */     this.timeoutSeconds = timeoutSeconds;
/*    */   }
/*    */   
/*    */   public SessionXAGetTimeoutResponseMessage()
/*    */   {
/* 36 */     super((byte)66);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isResponse()
/*    */   {
/* 42 */     return true;
/*    */   }
/*    */   
/*    */   public int getTimeoutSeconds()
/*    */   {
/* 47 */     return this.timeoutSeconds;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 53 */     buffer.writeInt(this.timeoutSeconds);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 59 */     this.timeoutSeconds = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 65 */     int prime = 31;
/* 66 */     int result = super.hashCode();
/* 67 */     result = 31 * result + this.timeoutSeconds;
/* 68 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 74 */     if (this == obj)
/* 75 */       return true;
/* 76 */     if (!super.equals(obj))
/* 77 */       return false;
/* 78 */     if (!(obj instanceof SessionXAGetTimeoutResponseMessage))
/* 79 */       return false;
/* 80 */     SessionXAGetTimeoutResponseMessage other = (SessionXAGetTimeoutResponseMessage)obj;
/* 81 */     if (this.timeoutSeconds != other.timeoutSeconds)
/* 82 */       return false;
/* 83 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAGetTimeoutResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */