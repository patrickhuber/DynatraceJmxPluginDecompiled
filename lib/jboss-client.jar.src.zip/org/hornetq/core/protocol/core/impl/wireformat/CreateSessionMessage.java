/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateSessionMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private String name;
/*     */   private long sessionChannelID;
/*     */   private int version;
/*     */   private String username;
/*     */   private String password;
/*     */   private int minLargeMessageSize;
/*     */   private boolean xa;
/*     */   private boolean autoCommitSends;
/*     */   private boolean autoCommitAcks;
/*     */   private boolean preAcknowledge;
/*     */   private int windowSize;
/*     */   private String defaultAddress;
/*     */   
/*     */   public CreateSessionMessage(String name, long sessionChannelID, int version, String username, String password, int minLargeMessageSize, boolean xa, boolean autoCommitSends, boolean autoCommitAcks, boolean preAcknowledge, int windowSize, String defaultAddress)
/*     */   {
/*  63 */     super((byte)30);
/*     */     
/*  65 */     this.name = name;
/*     */     
/*  67 */     this.sessionChannelID = sessionChannelID;
/*     */     
/*  69 */     this.version = version;
/*     */     
/*  71 */     this.username = username;
/*     */     
/*  73 */     this.password = password;
/*     */     
/*  75 */     this.minLargeMessageSize = minLargeMessageSize;
/*     */     
/*  77 */     this.xa = xa;
/*     */     
/*  79 */     this.autoCommitSends = autoCommitSends;
/*     */     
/*  81 */     this.autoCommitAcks = autoCommitAcks;
/*     */     
/*  83 */     this.windowSize = windowSize;
/*     */     
/*  85 */     this.preAcknowledge = preAcknowledge;
/*     */     
/*  87 */     this.defaultAddress = defaultAddress;
/*     */   }
/*     */   
/*     */   public CreateSessionMessage()
/*     */   {
/*  92 */     super((byte)30);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  99 */     return this.name;
/*     */   }
/*     */   
/*     */   public long getSessionChannelID()
/*     */   {
/* 104 */     return this.sessionChannelID;
/*     */   }
/*     */   
/*     */   public int getVersion()
/*     */   {
/* 109 */     return this.version;
/*     */   }
/*     */   
/*     */   public String getUsername()
/*     */   {
/* 114 */     return this.username;
/*     */   }
/*     */   
/*     */   public String getPassword()
/*     */   {
/* 119 */     return this.password;
/*     */   }
/*     */   
/*     */   public boolean isXA()
/*     */   {
/* 124 */     return this.xa;
/*     */   }
/*     */   
/*     */   public boolean isAutoCommitSends()
/*     */   {
/* 129 */     return this.autoCommitSends;
/*     */   }
/*     */   
/*     */   public boolean isAutoCommitAcks()
/*     */   {
/* 134 */     return this.autoCommitAcks;
/*     */   }
/*     */   
/*     */   public boolean isPreAcknowledge()
/*     */   {
/* 139 */     return this.preAcknowledge;
/*     */   }
/*     */   
/*     */   public int getWindowSize()
/*     */   {
/* 144 */     return this.windowSize;
/*     */   }
/*     */   
/*     */   public String getDefaultAddress()
/*     */   {
/* 149 */     return this.defaultAddress;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/* 155 */     buffer.writeString(this.name);
/* 156 */     buffer.writeLong(this.sessionChannelID);
/* 157 */     buffer.writeInt(this.version);
/* 158 */     buffer.writeNullableString(this.username);
/* 159 */     buffer.writeNullableString(this.password);
/* 160 */     buffer.writeInt(this.minLargeMessageSize);
/* 161 */     buffer.writeBoolean(this.xa);
/* 162 */     buffer.writeBoolean(this.autoCommitSends);
/* 163 */     buffer.writeBoolean(this.autoCommitAcks);
/* 164 */     buffer.writeInt(this.windowSize);
/* 165 */     buffer.writeBoolean(this.preAcknowledge);
/* 166 */     buffer.writeNullableString(this.defaultAddress);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 172 */     this.name = buffer.readString();
/* 173 */     this.sessionChannelID = buffer.readLong();
/* 174 */     this.version = buffer.readInt();
/* 175 */     this.username = buffer.readNullableString();
/* 176 */     this.password = buffer.readNullableString();
/* 177 */     this.minLargeMessageSize = buffer.readInt();
/* 178 */     this.xa = buffer.readBoolean();
/* 179 */     this.autoCommitSends = buffer.readBoolean();
/* 180 */     this.autoCommitAcks = buffer.readBoolean();
/* 181 */     this.windowSize = buffer.readInt();
/* 182 */     this.preAcknowledge = buffer.readBoolean();
/* 183 */     this.defaultAddress = buffer.readNullableString();
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/* 189 */     return false;
/*     */   }
/*     */   
/*     */   public int getMinLargeMessageSize()
/*     */   {
/* 194 */     return this.minLargeMessageSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 200 */     int prime = 31;
/* 201 */     int result = super.hashCode();
/* 202 */     result = 31 * result + (this.autoCommitAcks ? 1231 : 1237);
/* 203 */     result = 31 * result + (this.autoCommitSends ? 1231 : 1237);
/* 204 */     result = 31 * result + (this.defaultAddress == null ? 0 : this.defaultAddress.hashCode());
/* 205 */     result = 31 * result + this.minLargeMessageSize;
/* 206 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 207 */     result = 31 * result + (this.password == null ? 0 : this.password.hashCode());
/* 208 */     result = 31 * result + (this.preAcknowledge ? 1231 : 1237);
/* 209 */     result = 31 * result + (int)(this.sessionChannelID ^ this.sessionChannelID >>> 32);
/* 210 */     result = 31 * result + (this.username == null ? 0 : this.username.hashCode());
/* 211 */     result = 31 * result + this.version;
/* 212 */     result = 31 * result + this.windowSize;
/* 213 */     result = 31 * result + (this.xa ? 1231 : 1237);
/* 214 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 220 */     if (this == obj)
/* 221 */       return true;
/* 222 */     if (!super.equals(obj))
/* 223 */       return false;
/* 224 */     if (!(obj instanceof CreateSessionMessage))
/* 225 */       return false;
/* 226 */     CreateSessionMessage other = (CreateSessionMessage)obj;
/* 227 */     if (this.autoCommitAcks != other.autoCommitAcks)
/* 228 */       return false;
/* 229 */     if (this.autoCommitSends != other.autoCommitSends)
/* 230 */       return false;
/* 231 */     if (this.defaultAddress == null)
/*     */     {
/* 233 */       if (other.defaultAddress != null) {
/* 234 */         return false;
/*     */       }
/* 236 */     } else if (!this.defaultAddress.equals(other.defaultAddress))
/* 237 */       return false;
/* 238 */     if (this.minLargeMessageSize != other.minLargeMessageSize)
/* 239 */       return false;
/* 240 */     if (this.name == null)
/*     */     {
/* 242 */       if (other.name != null) {
/* 243 */         return false;
/*     */       }
/* 245 */     } else if (!this.name.equals(other.name))
/* 246 */       return false;
/* 247 */     if (this.password == null)
/*     */     {
/* 249 */       if (other.password != null) {
/* 250 */         return false;
/*     */       }
/* 252 */     } else if (!this.password.equals(other.password))
/* 253 */       return false;
/* 254 */     if (this.preAcknowledge != other.preAcknowledge)
/* 255 */       return false;
/* 256 */     if (this.sessionChannelID != other.sessionChannelID)
/* 257 */       return false;
/* 258 */     if (this.username == null)
/*     */     {
/* 260 */       if (other.username != null) {
/* 261 */         return false;
/*     */       }
/* 263 */     } else if (!this.username.equals(other.username))
/* 264 */       return false;
/* 265 */     if (this.version != other.version)
/* 266 */       return false;
/* 267 */     if (this.windowSize != other.windowSize)
/* 268 */       return false;
/* 269 */     if (this.xa != other.xa)
/* 270 */       return false;
/* 271 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\CreateSessionMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */