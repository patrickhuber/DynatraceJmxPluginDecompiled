/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionForceConsumerDelivery
/*     */   extends PacketImpl
/*     */ {
/*     */   private long consumerID;
/*     */   private long sequence;
/*     */   
/*     */   public SessionForceConsumerDelivery(long consumerID, long sequence)
/*     */   {
/*  33 */     super((byte)78);
/*     */     
/*  35 */     this.consumerID = consumerID;
/*  36 */     this.sequence = sequence;
/*     */   }
/*     */   
/*     */   public SessionForceConsumerDelivery()
/*     */   {
/*  41 */     super((byte)78);
/*     */   }
/*     */   
/*     */   public long getConsumerID()
/*     */   {
/*  46 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public long getSequence()
/*     */   {
/*  51 */     return this.sequence;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  57 */     buffer.writeLong(this.consumerID);
/*  58 */     buffer.writeLong(this.sequence);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  64 */     this.consumerID = buffer.readLong();
/*  65 */     this.sequence = buffer.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  71 */     StringBuffer buf = new StringBuffer(getParentString());
/*  72 */     buf.append(", consumerID=" + this.consumerID);
/*  73 */     buf.append(", sequence=" + this.sequence);
/*  74 */     buf.append("]");
/*  75 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  81 */     int prime = 31;
/*  82 */     int result = super.hashCode();
/*  83 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/*  84 */     result = 31 * result + (int)(this.sequence ^ this.sequence >>> 32);
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  91 */     if (this == obj)
/*  92 */       return true;
/*  93 */     if (!super.equals(obj))
/*  94 */       return false;
/*  95 */     if (!(obj instanceof SessionForceConsumerDelivery))
/*  96 */       return false;
/*  97 */     SessionForceConsumerDelivery other = (SessionForceConsumerDelivery)obj;
/*  98 */     if (this.consumerID != other.consumerID)
/*  99 */       return false;
/* 100 */     if (this.sequence != other.sequence)
/* 101 */       return false;
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionForceConsumerDelivery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */