/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionConsumerFlowCreditMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private long consumerID;
/*    */   private int credits;
/*    */   
/*    */   public SessionConsumerFlowCreditMessage(long consumerID, int credits)
/*    */   {
/* 31 */     super((byte)70);
/* 32 */     this.consumerID = consumerID;
/* 33 */     this.credits = credits;
/*    */   }
/*    */   
/*    */   public SessionConsumerFlowCreditMessage()
/*    */   {
/* 38 */     super((byte)70);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public long getConsumerID()
/*    */   {
/* 45 */     return this.consumerID;
/*    */   }
/*    */   
/*    */   public int getCredits()
/*    */   {
/* 50 */     return this.credits;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 56 */     buffer.writeLong(this.consumerID);
/* 57 */     buffer.writeInt(this.credits);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 63 */     this.consumerID = buffer.readLong();
/* 64 */     this.credits = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 70 */     return getParentString() + ", consumerID=" + this.consumerID + ", credits=" + this.credits + "]";
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 76 */     int prime = 31;
/* 77 */     int result = super.hashCode();
/* 78 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/* 79 */     result = 31 * result + this.credits;
/* 80 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 86 */     if (this == obj)
/* 87 */       return true;
/* 88 */     if (!super.equals(obj))
/* 89 */       return false;
/* 90 */     if (!(obj instanceof SessionConsumerFlowCreditMessage))
/* 91 */       return false;
/* 92 */     SessionConsumerFlowCreditMessage other = (SessionConsumerFlowCreditMessage)obj;
/* 93 */     if (this.consumerID != other.consumerID)
/* 94 */       return false;
/* 95 */     if (this.credits != other.credits)
/* 96 */       return false;
/* 97 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionConsumerFlowCreditMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */