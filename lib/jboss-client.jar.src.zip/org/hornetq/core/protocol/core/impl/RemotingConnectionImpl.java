/*     */ package org.hornetq.core.protocol.core.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.api.core.Interceptor;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.core.protocol.core.Channel;
/*     */ import org.hornetq.core.protocol.core.CoreRemotingConnection;
/*     */ import org.hornetq.core.protocol.core.Packet;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.DisconnectMessage;
/*     */ import org.hornetq.core.remoting.CloseListener;
/*     */ import org.hornetq.core.remoting.FailureListener;
/*     */ import org.hornetq.core.security.HornetQPrincipal;
/*     */ import org.hornetq.spi.core.remoting.Connection;
/*     */ import org.hornetq.utils.SimpleIDGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RemotingConnectionImpl
/*     */   implements CoreRemotingConnection
/*     */ {
/*  52 */   private static final boolean isTrace = HornetQClientLogger.LOGGER.isTraceEnabled();
/*     */   
/*     */ 
/*     */ 
/*     */   private final PacketDecoder packetDecoder;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Connection transportConnection;
/*     */   
/*     */ 
/*  63 */   private final Map<Long, Channel> channels = new ConcurrentHashMap();
/*     */   
/*  65 */   private final List<FailureListener> failureListeners = new CopyOnWriteArrayList();
/*     */   
/*  67 */   private final List<CloseListener> closeListeners = new CopyOnWriteArrayList();
/*     */   
/*     */   private final long blockingCallTimeout;
/*     */   
/*     */   private final long blockingCallFailoverTimeout;
/*     */   
/*     */   private final List<Interceptor> incomingInterceptors;
/*     */   
/*     */   private final List<Interceptor> outgoingInterceptors;
/*     */   
/*     */   private volatile boolean destroyed;
/*     */   
/*     */   private final boolean client;
/*     */   
/*     */   private int clientVersion;
/*     */   
/*  83 */   private volatile SimpleIDGenerator idGenerator = new SimpleIDGenerator(ChannelImpl.CHANNEL_ID.USER.id);
/*     */   
/*  85 */   private boolean idGeneratorSynced = false;
/*     */   
/*  87 */   private final Object transferLock = new Object();
/*     */   
/*  89 */   private final Object failLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */   private volatile boolean dataReceived;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Executor executor;
/*     */   
/*     */ 
/*     */ 
/*     */   private volatile boolean executing;
/*     */   
/*     */ 
/*     */   private final SimpleString nodeID;
/*     */   
/*     */ 
/*     */   private final long creationTime;
/*     */   
/*     */ 
/*     */   private String clientID;
/*     */   
/*     */ 
/*     */ 
/*     */   public RemotingConnectionImpl(PacketDecoder packetDecoder, Connection transportConnection, long blockingCallTimeout, long blockingCallFailoverTimeout, List<Interceptor> incomingInterceptors, List<Interceptor> outgoingInterceptors)
/*     */   {
/* 116 */     this(packetDecoder, transportConnection, blockingCallTimeout, blockingCallFailoverTimeout, incomingInterceptors, outgoingInterceptors, true, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   RemotingConnectionImpl(PacketDecoder packetDecoder, Connection transportConnection, List<Interceptor> incomingInterceptors, List<Interceptor> outgoingInterceptors, Executor executor, SimpleString nodeID)
/*     */   {
/* 130 */     this(packetDecoder, transportConnection, -1L, -1L, incomingInterceptors, outgoingInterceptors, false, executor, nodeID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RemotingConnectionImpl(PacketDecoder packetDecoder, Connection transportConnection, long blockingCallTimeout, long blockingCallFailoverTimeout, List<Interceptor> incomingInterceptors, List<Interceptor> outgoingInterceptors, boolean client, Executor executor, SimpleString nodeID)
/*     */   {
/* 144 */     this.packetDecoder = packetDecoder;
/*     */     
/* 146 */     this.transportConnection = transportConnection;
/*     */     
/* 148 */     this.blockingCallTimeout = blockingCallTimeout;
/*     */     
/* 150 */     this.blockingCallFailoverTimeout = blockingCallFailoverTimeout;
/*     */     
/* 152 */     this.incomingInterceptors = incomingInterceptors;
/*     */     
/* 154 */     this.outgoingInterceptors = outgoingInterceptors;
/*     */     
/* 156 */     this.client = client;
/*     */     
/* 158 */     this.executor = executor;
/*     */     
/* 160 */     this.nodeID = nodeID;
/*     */     
/* 162 */     this.creationTime = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 174 */     return "RemotingConnectionImpl [clientID=" + this.clientID + ", nodeID=" + this.nodeID + ", transportConnection=" + this.transportConnection + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Connection getTransportConnection()
/*     */   {
/* 184 */     return this.transportConnection;
/*     */   }
/*     */   
/*     */   public List<FailureListener> getFailureListeners()
/*     */   {
/* 189 */     return new ArrayList(this.failureListeners);
/*     */   }
/*     */   
/*     */   public void setFailureListeners(List<FailureListener> listeners)
/*     */   {
/* 194 */     this.failureListeners.clear();
/*     */     
/* 196 */     this.failureListeners.addAll(listeners);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getClientVersion()
/*     */   {
/* 204 */     return this.clientVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setClientVersion(int clientVersion)
/*     */   {
/* 212 */     this.clientVersion = clientVersion;
/*     */   }
/*     */   
/*     */   public Object getID()
/*     */   {
/* 217 */     return this.transportConnection.getID();
/*     */   }
/*     */   
/*     */   public String getRemoteAddress()
/*     */   {
/* 222 */     return this.transportConnection.getRemoteAddress();
/*     */   }
/*     */   
/*     */   public long getCreationTime()
/*     */   {
/* 227 */     return this.creationTime;
/*     */   }
/*     */   
/*     */   public synchronized Channel getChannel(long channelID, int confWindowSize)
/*     */   {
/* 232 */     Channel channel = (Channel)this.channels.get(Long.valueOf(channelID));
/*     */     
/* 234 */     if (channel == null)
/*     */     {
/* 236 */       channel = new ChannelImpl(this, channelID, confWindowSize, this.outgoingInterceptors);
/*     */       
/* 238 */       this.channels.put(Long.valueOf(channelID), channel);
/*     */     }
/*     */     
/* 241 */     return channel;
/*     */   }
/*     */   
/*     */   public synchronized boolean removeChannel(long channelID)
/*     */   {
/* 246 */     return this.channels.remove(Long.valueOf(channelID)) != null;
/*     */   }
/*     */   
/*     */   public synchronized void putChannel(long channelID, Channel channel)
/*     */   {
/* 251 */     this.channels.put(Long.valueOf(channelID), channel);
/*     */   }
/*     */   
/*     */   public void addFailureListener(FailureListener listener)
/*     */   {
/* 256 */     if (listener == null)
/*     */     {
/* 258 */       throw HornetQClientMessageBundle.BUNDLE.failListenerCannotBeNull();
/*     */     }
/* 260 */     this.failureListeners.add(listener);
/*     */   }
/*     */   
/*     */   public boolean removeFailureListener(FailureListener listener)
/*     */   {
/* 265 */     if (listener == null)
/*     */     {
/* 267 */       throw HornetQClientMessageBundle.BUNDLE.failListenerCannotBeNull();
/*     */     }
/*     */     
/* 270 */     return this.failureListeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void addCloseListener(CloseListener listener)
/*     */   {
/* 275 */     if (listener == null)
/*     */     {
/* 277 */       throw HornetQClientMessageBundle.BUNDLE.closeListenerCannotBeNull();
/*     */     }
/*     */     
/* 280 */     this.closeListeners.add(listener);
/*     */   }
/*     */   
/*     */   public boolean removeCloseListener(CloseListener listener)
/*     */   {
/* 285 */     if (listener == null)
/*     */     {
/* 287 */       throw HornetQClientMessageBundle.BUNDLE.closeListenerCannotBeNull();
/*     */     }
/*     */     
/* 290 */     return this.closeListeners.remove(listener);
/*     */   }
/*     */   
/*     */   public List<CloseListener> removeCloseListeners()
/*     */   {
/* 295 */     List<CloseListener> ret = new ArrayList(this.closeListeners);
/*     */     
/* 297 */     this.closeListeners.clear();
/*     */     
/* 299 */     return ret;
/*     */   }
/*     */   
/*     */   public List<FailureListener> removeFailureListeners()
/*     */   {
/* 304 */     List<FailureListener> ret = new ArrayList(this.failureListeners);
/*     */     
/* 306 */     this.failureListeners.clear();
/*     */     
/* 308 */     return ret;
/*     */   }
/*     */   
/*     */   public void setCloseListeners(List<CloseListener> listeners)
/*     */   {
/* 313 */     this.closeListeners.clear();
/*     */     
/* 315 */     this.closeListeners.addAll(listeners);
/*     */   }
/*     */   
/*     */   public HornetQBuffer createBuffer(int size)
/*     */   {
/* 320 */     return this.transportConnection.createBuffer(size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fail(HornetQException me)
/*     */   {
/* 328 */     synchronized (this.failLock)
/*     */     {
/* 330 */       if (this.destroyed)
/*     */       {
/* 332 */         return;
/*     */       }
/*     */       
/* 335 */       this.destroyed = true;
/*     */     }
/*     */     
/* 338 */     HornetQClientLogger.LOGGER.connectionFailureDetected(me.getMessage(), me.getType());
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 343 */       this.transportConnection.forceClose();
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 347 */       HornetQClientLogger.LOGGER.warn(e.getMessage(), e);
/*     */     }
/*     */     
/*     */ 
/* 351 */     callFailureListeners(me);
/*     */     
/* 353 */     callClosingListeners();
/*     */     
/* 355 */     internalClose();
/*     */     
/* 357 */     for (Channel channel : this.channels.values())
/*     */     {
/* 359 */       channel.returnBlocking(me);
/*     */     }
/*     */   }
/*     */   
/*     */   public void destroy()
/*     */   {
/* 365 */     synchronized (this.failLock)
/*     */     {
/* 367 */       if (this.destroyed)
/*     */       {
/* 369 */         return;
/*     */       }
/*     */       
/* 372 */       this.destroyed = true;
/*     */     }
/*     */     
/* 375 */     internalClose();
/*     */     
/* 377 */     callClosingListeners();
/*     */   }
/*     */   
/*     */   public void disconnect(boolean criticalError)
/*     */   {
/* 382 */     Channel channel0 = getChannel(0L, -1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 388 */     Set<Channel> allChannels = new HashSet(this.channels.values());
/*     */     
/* 390 */     if (!criticalError)
/*     */     {
/* 392 */       removeAllChannels();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 398 */       this.channels.clear();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 403 */     if (!criticalError)
/*     */     {
/* 405 */       for (Channel channel : allChannels)
/*     */       {
/* 407 */         channel.flushConfirmations();
/*     */       }
/*     */     }
/*     */     
/* 411 */     Packet disconnect = new DisconnectMessage(this.nodeID);
/* 412 */     channel0.sendAndFlush(disconnect);
/*     */   }
/*     */   
/*     */   public long generateChannelID()
/*     */   {
/* 417 */     return this.idGenerator.generateID();
/*     */   }
/*     */   
/*     */   public synchronized void syncIDGeneratorSequence(long id)
/*     */   {
/* 422 */     if (!this.idGeneratorSynced)
/*     */     {
/* 424 */       this.idGenerator = new SimpleIDGenerator(id);
/*     */       
/* 426 */       this.idGeneratorSynced = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public long getIDGeneratorSequence()
/*     */   {
/* 432 */     return this.idGenerator.getCurrentID();
/*     */   }
/*     */   
/*     */   public Object getTransferLock()
/*     */   {
/* 437 */     return this.transferLock;
/*     */   }
/*     */   
/*     */   public boolean isClient()
/*     */   {
/* 442 */     return this.client;
/*     */   }
/*     */   
/*     */   public boolean isDestroyed()
/*     */   {
/* 447 */     return this.destroyed;
/*     */   }
/*     */   
/*     */   public long getBlockingCallTimeout()
/*     */   {
/* 452 */     return this.blockingCallTimeout;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getBlockingCallFailoverTimeout()
/*     */   {
/* 458 */     return this.blockingCallFailoverTimeout;
/*     */   }
/*     */   
/*     */   public boolean checkDataReceived()
/*     */   {
/* 463 */     boolean res = this.dataReceived;
/*     */     
/* 465 */     this.dataReceived = false;
/*     */     
/* 467 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */   {
/* 474 */     synchronized (this.transferLock)
/*     */     {
/* 476 */       for (Channel channel : this.channels.values())
/*     */       {
/* 478 */         channel.flushConfirmations();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public HornetQPrincipal getDefaultHornetQPrincipal()
/*     */   {
/* 485 */     return this.transportConnection.getDefaultHornetQPrincipal();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void bufferReceived(Object connectionID, HornetQBuffer buffer)
/*     */   {
/*     */     try
/*     */     {
/* 495 */       final Packet packet = this.packetDecoder.decode(buffer);
/*     */       
/* 497 */       if (isTrace)
/*     */       {
/* 499 */         HornetQClientLogger.LOGGER.trace("handling packet " + packet);
/*     */       }
/*     */       
/* 502 */       if ((packet.isAsyncExec()) && (this.executor != null))
/*     */       {
/* 504 */         this.executing = true;
/*     */         
/* 506 */         this.executor.execute(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*     */             try
/*     */             {
/* 512 */               RemotingConnectionImpl.this.doBufferReceived(packet);
/*     */             }
/*     */             catch (Throwable t)
/*     */             {
/* 516 */               HornetQClientLogger.LOGGER.errorHandlingPacket(t, packet);
/*     */             }
/*     */             
/* 519 */             RemotingConnectionImpl.this.executing = false;
/*     */           }
/*     */           
/*     */         });
/*     */       }
/*     */       else
/*     */       {
/* 526 */         while (this.executing)
/*     */         {
/* 528 */           Thread.yield();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 533 */         doBufferReceived(packet);
/*     */       }
/*     */       
/* 536 */       this.dataReceived = true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 540 */       HornetQClientLogger.LOGGER.errorDecodingPacket(e);
/*     */     }
/*     */   }
/*     */   
/*     */   private void doBufferReceived(Packet packet)
/*     */   {
/* 546 */     if (ChannelImpl.invokeInterceptors(packet, this.incomingInterceptors, this) != null)
/*     */     {
/* 548 */       return;
/*     */     }
/*     */     
/* 551 */     synchronized (this.transferLock)
/*     */     {
/* 553 */       Channel channel = (Channel)this.channels.get(Long.valueOf(packet.getChannelID()));
/*     */       
/* 555 */       if (channel != null)
/*     */       {
/* 557 */         channel.handlePacket(packet);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void removeAllChannels()
/*     */   {
/* 566 */     synchronized (this.transferLock)
/*     */     {
/* 568 */       this.channels.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private void callFailureListeners(HornetQException me)
/*     */   {
/* 574 */     List<FailureListener> listenersClone = new ArrayList(this.failureListeners);
/*     */     
/* 576 */     for (FailureListener listener : listenersClone)
/*     */     {
/*     */       try
/*     */       {
/* 580 */         listener.connectionFailed(me, false);
/*     */ 
/*     */       }
/*     */       catch (HornetQInterruptedException interrupted)
/*     */       {
/* 585 */         HornetQClientLogger.LOGGER.debug("thread interrupted", interrupted);
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */ 
/* 592 */         HornetQClientLogger.LOGGER.errorCallingFailureListener(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void callClosingListeners()
/*     */   {
/* 599 */     List<CloseListener> listenersClone = new ArrayList(this.closeListeners);
/*     */     
/* 601 */     for (CloseListener listener : listenersClone)
/*     */     {
/*     */       try
/*     */       {
/* 605 */         listener.connectionClosed();
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*     */ 
/* 612 */         HornetQClientLogger.LOGGER.errorCallingFailureListener(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void internalClose()
/*     */   {
/* 620 */     this.transportConnection.close();
/*     */     
/* 622 */     for (Channel channel : this.channels.values())
/*     */     {
/* 624 */       channel.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setClientID(String cID)
/*     */   {
/* 630 */     this.clientID = cID;
/*     */   }
/*     */   
/*     */   public String getClientID()
/*     */   {
/* 635 */     return this.clientID;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\RemotingConnectionImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */