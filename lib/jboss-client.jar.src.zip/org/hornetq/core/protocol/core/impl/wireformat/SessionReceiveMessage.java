/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.message.impl.MessageInternal;
/*     */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionReceiveMessage
/*     */   extends MessagePacket
/*     */ {
/*     */   private long consumerID;
/*     */   private int deliveryCount;
/*     */   
/*     */   public SessionReceiveMessage(long consumerID, MessageInternal message, int deliveryCount)
/*     */   {
/*  37 */     super((byte)75, message);
/*     */     
/*  39 */     this.consumerID = consumerID;
/*     */     
/*  41 */     this.deliveryCount = deliveryCount;
/*     */   }
/*     */   
/*     */   public SessionReceiveMessage(MessageInternal message)
/*     */   {
/*  46 */     super((byte)75, message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getConsumerID()
/*     */   {
/*  53 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public int getDeliveryCount()
/*     */   {
/*  58 */     return this.deliveryCount;
/*     */   }
/*     */   
/*     */ 
/*     */   public HornetQBuffer encode(RemotingConnection connection)
/*     */   {
/*  64 */     HornetQBuffer buffer = this.message.getEncodedBuffer();
/*     */     
/*     */ 
/*  67 */     if (buffer.writerIndex() != this.message.getEndOfMessagePosition())
/*     */     {
/*  69 */       throw new IllegalStateException("Wrong encode position");
/*     */     }
/*     */     
/*  72 */     buffer.writeLong(this.consumerID);
/*  73 */     buffer.writeInt(this.deliveryCount);
/*     */     
/*  75 */     this.size = buffer.writerIndex();
/*     */     
/*     */ 
/*     */ 
/*  79 */     int len = this.size - 4;
/*  80 */     buffer.setInt(0, len);
/*  81 */     buffer.setByte(4, getType());
/*  82 */     buffer.setLong(5, this.channelID);
/*     */     
/*     */ 
/*  85 */     buffer.setIndex(0, this.size);
/*     */     
/*  87 */     return buffer;
/*     */   }
/*     */   
/*     */ 
/*     */   public void decode(HornetQBuffer buffer)
/*     */   {
/*  93 */     this.channelID = buffer.readLong();
/*     */     
/*  95 */     this.message.decodeFromBuffer(buffer);
/*     */     
/*  97 */     this.consumerID = buffer.readLong();
/*     */     
/*  99 */     this.deliveryCount = buffer.readInt();
/*     */     
/* 101 */     this.size = buffer.readerIndex();
/*     */     
/*     */ 
/*     */ 
/* 105 */     buffer.setIndex(17, this.message.getEndOfBodyPosition());
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 111 */     int prime = 31;
/* 112 */     int result = super.hashCode();
/* 113 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/* 114 */     result = 31 * result + this.deliveryCount;
/* 115 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 121 */     if (this == obj)
/* 122 */       return true;
/* 123 */     if (!super.equals(obj))
/* 124 */       return false;
/* 125 */     if (!(obj instanceof SessionReceiveMessage))
/* 126 */       return false;
/* 127 */     SessionReceiveMessage other = (SessionReceiveMessage)obj;
/* 128 */     if (this.consumerID != other.consumerID)
/* 129 */       return false;
/* 130 */     if (this.deliveryCount != other.deliveryCount)
/* 131 */       return false;
/* 132 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionReceiveMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */