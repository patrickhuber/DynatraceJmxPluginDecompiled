/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQExceptionType;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HornetQExceptionMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private HornetQException exception;
/*     */   
/*     */   public HornetQExceptionMessage(HornetQException exception)
/*     */   {
/*  36 */     super((byte)20);
/*     */     
/*  38 */     this.exception = exception;
/*     */   }
/*     */   
/*     */   public HornetQExceptionMessage()
/*     */   {
/*  43 */     super((byte)20);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isResponse()
/*     */   {
/*  51 */     return true;
/*     */   }
/*     */   
/*     */   public HornetQException getException()
/*     */   {
/*  56 */     return this.exception;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  62 */     buffer.writeInt(this.exception.getType().getCode());
/*  63 */     buffer.writeNullableString(this.exception.getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  69 */     int code = buffer.readInt();
/*  70 */     String msg = buffer.readNullableString();
/*     */     
/*  72 */     this.exception = HornetQExceptionType.createException(code, msg);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  78 */     return getParentString() + ", exception= " + this.exception + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  84 */     int prime = 31;
/*  85 */     int result = super.hashCode();
/*  86 */     result = 31 * result + (this.exception == null ? 0 : this.exception.hashCode());
/*  87 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  93 */     if (this == obj)
/*     */     {
/*  95 */       return true;
/*     */     }
/*  97 */     if (!super.equals(obj))
/*     */     {
/*  99 */       return false;
/*     */     }
/* 101 */     if (!(obj instanceof HornetQExceptionMessage))
/*     */     {
/* 103 */       return false;
/*     */     }
/* 105 */     HornetQExceptionMessage other = (HornetQExceptionMessage)obj;
/* 106 */     if (this.exception == null)
/*     */     {
/* 108 */       if (other.exception != null)
/*     */       {
/* 110 */         return false;
/*     */       }
/*     */     }
/* 113 */     else if (!this.exception.equals(other.exception))
/*     */     {
/* 115 */       return false;
/*     */     }
/* 117 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\HornetQExceptionMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */