/*     */ package org.hornetq.core.protocol.core.impl;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.locks.Condition;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.api.core.Interceptor;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.core.protocol.core.Channel;
/*     */ import org.hornetq.core.protocol.core.ChannelHandler;
/*     */ import org.hornetq.core.protocol.core.CommandConfirmationHandler;
/*     */ import org.hornetq.core.protocol.core.CoreRemotingConnection;
/*     */ import org.hornetq.core.protocol.core.Packet;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.HornetQExceptionMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.PacketsConfirmedMessage;
/*     */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*     */ import org.hornetq.spi.core.remoting.Connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChannelImpl
/*     */   implements Channel
/*     */ {
/*     */   public static enum CHANNEL_ID
/*     */   {
/*  53 */     PING(0L), 
/*     */     
/*     */ 
/*     */ 
/*  57 */     SESSION(1L), 
/*     */     
/*     */ 
/*     */ 
/*  61 */     REPLICATION(2L), 
/*     */     
/*     */ 
/*     */ 
/*  65 */     USER(10L);
/*     */     
/*     */     public final long id;
/*     */     
/*     */     private CHANNEL_ID(long id)
/*     */     {
/*  71 */       this.id = id;
/*     */     }
/*     */     
/*     */     protected static String idToString(long code)
/*     */     {
/*  76 */       for (CHANNEL_ID channel : EnumSet.allOf(CHANNEL_ID.class))
/*     */       {
/*  78 */         if (channel.id == code) return channel.toString();
/*     */       }
/*  80 */       return Long.toString(code);
/*     */     }
/*     */   }
/*     */   
/*  84 */   private static final boolean isTrace = HornetQClientLogger.LOGGER.isTraceEnabled();
/*     */   
/*     */   private volatile long id;
/*     */   
/*     */   private ChannelHandler handler;
/*     */   
/*     */   private Packet response;
/*     */   
/*     */   private final Queue<Packet> resendCache;
/*     */   
/*     */   private volatile int firstStoredCommandID;
/*     */   
/*  96 */   private final AtomicInteger lastConfirmedCommandID = new AtomicInteger(-1);
/*     */   
/*     */   private volatile CoreRemotingConnection connection;
/*     */   
/*     */   private volatile boolean closed;
/*     */   
/* 102 */   private final Lock lock = new ReentrantLock();
/*     */   
/* 104 */   private final Condition sendCondition = this.lock.newCondition();
/*     */   
/* 106 */   private final Condition failoverCondition = this.lock.newCondition();
/*     */   
/* 108 */   private final Object sendLock = new Object();
/*     */   
/* 110 */   private final Object sendBlockingLock = new Object();
/*     */   
/*     */   private boolean failingOver;
/*     */   
/*     */   private final int confWindowSize;
/*     */   
/*     */   private int receivedBytes;
/*     */   
/*     */   private CommandConfirmationHandler commandConfirmationHandler;
/*     */   
/*     */   private volatile boolean transferring;
/*     */   
/*     */   private final List<Interceptor> interceptors;
/*     */   
/*     */   public ChannelImpl(CoreRemotingConnection connection, long id, int confWindowSize, List<Interceptor> interceptors)
/*     */   {
/* 126 */     this.connection = connection;
/*     */     
/* 128 */     this.id = id;
/*     */     
/* 130 */     this.confWindowSize = confWindowSize;
/*     */     
/* 132 */     if (confWindowSize != -1)
/*     */     {
/* 134 */       this.resendCache = new ConcurrentLinkedQueue();
/*     */     }
/*     */     else
/*     */     {
/* 138 */       this.resendCache = null;
/*     */     }
/*     */     
/* 141 */     this.interceptors = interceptors;
/*     */   }
/*     */   
/*     */   public boolean supports(byte packetType)
/*     */   {
/* 146 */     int version = this.connection.getClientVersion();
/*     */     
/* 148 */     switch (packetType)
/*     */     {
/*     */     case 114: 
/* 151 */       return version >= 122;
/*     */     }
/* 153 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getID()
/*     */   {
/* 159 */     return this.id;
/*     */   }
/*     */   
/*     */   public int getLastConfirmedCommandID()
/*     */   {
/* 164 */     return this.lastConfirmedCommandID.get();
/*     */   }
/*     */   
/*     */   public Lock getLock()
/*     */   {
/* 169 */     return this.lock;
/*     */   }
/*     */   
/*     */   public int getConfirmationWindowSize()
/*     */   {
/* 174 */     return this.confWindowSize;
/*     */   }
/*     */   
/*     */   public void returnBlocking()
/*     */   {
/* 179 */     returnBlocking(null);
/*     */   }
/*     */   
/*     */   public void returnBlocking(Throwable cause)
/*     */   {
/* 184 */     this.lock.lock();
/*     */     
/*     */     try
/*     */     {
/* 188 */       this.response = new HornetQExceptionMessage(HornetQClientMessageBundle.BUNDLE.unblockingACall(cause));
/*     */       
/* 190 */       this.sendCondition.signal();
/*     */     }
/*     */     finally
/*     */     {
/* 194 */       this.lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean sendAndFlush(Packet packet)
/*     */   {
/* 200 */     return send(packet, true, false);
/*     */   }
/*     */   
/*     */   public boolean send(Packet packet)
/*     */   {
/* 205 */     return send(packet, false, false);
/*     */   }
/*     */   
/*     */   public boolean sendBatched(Packet packet)
/*     */   {
/* 210 */     return send(packet, false, true);
/*     */   }
/*     */   
/*     */   public void setTransferring(boolean transferring)
/*     */   {
/* 215 */     this.transferring = transferring;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean send(Packet packet, boolean flush, boolean batch)
/*     */   {
/* 221 */     if (invokeInterceptors(packet, this.interceptors, this.connection) != null)
/*     */     {
/* 223 */       return false;
/*     */     }
/*     */     
/* 226 */     synchronized (this.sendLock)
/*     */     {
/* 228 */       packet.setChannelID(this.id);
/*     */       
/* 230 */       if (isTrace)
/*     */       {
/* 232 */         HornetQClientLogger.LOGGER.trace("Sending packet nonblocking " + packet + " on channeID=" + this.id);
/*     */       }
/*     */       
/* 235 */       HornetQBuffer buffer = packet.encode(this.connection);
/*     */       
/* 237 */       this.lock.lock();
/*     */       
/*     */       try
/*     */       {
/* 241 */         if (this.failingOver)
/*     */         {
/*     */           try
/*     */           {
/*     */ 
/* 246 */             this.failoverCondition.await(10000L, TimeUnit.MILLISECONDS);
/*     */           }
/*     */           catch (InterruptedException e)
/*     */           {
/* 250 */             throw new HornetQInterruptedException(e);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 255 */         if (this.transferring)
/*     */         {
/* 257 */           throw new IllegalStateException("Cannot send a packet while channel is doing failover");
/*     */         }
/*     */         
/* 260 */         if ((this.resendCache != null) && (packet.isRequiresConfirmations()))
/*     */         {
/* 262 */           this.resendCache.add(packet);
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 267 */         this.lock.unlock();
/*     */       }
/*     */       
/* 270 */       if (isTrace)
/*     */       {
/* 272 */         HornetQClientLogger.LOGGER.trace("Writing buffer for channelID=" + this.id);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 278 */       this.connection.getTransportConnection().write(buffer, flush, batch);
/*     */       
/* 280 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Packet sendBlocking(Packet packet, byte expectedPacket)
/*     */     throws HornetQException
/*     */   {
/* 291 */     String interceptionResult = invokeInterceptors(packet, this.interceptors, this.connection);
/*     */     
/* 293 */     if (interceptionResult != null)
/*     */     {
/*     */ 
/* 296 */       throw HornetQClientMessageBundle.BUNDLE.interceptorRejectedPacket(interceptionResult);
/*     */     }
/*     */     
/* 299 */     if (this.closed)
/*     */     {
/* 301 */       throw HornetQClientMessageBundle.BUNDLE.connectionDestroyed();
/*     */     }
/*     */     
/* 304 */     if (this.connection.getBlockingCallTimeout() == -1L)
/*     */     {
/* 306 */       throw new IllegalStateException("Cannot do a blocking call timeout on a server side connection");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 311 */     synchronized (this.sendBlockingLock)
/*     */     {
/* 313 */       packet.setChannelID(this.id);
/*     */       
/* 315 */       HornetQBuffer buffer = packet.encode(this.connection);
/*     */       
/* 317 */       this.lock.lock();
/*     */       
/*     */       try
/*     */       {
/* 321 */         if (this.failingOver)
/*     */         {
/*     */           try
/*     */           {
/* 325 */             if (this.connection.getBlockingCallFailoverTimeout() < 0L)
/*     */             {
/* 327 */               while (this.failingOver)
/*     */               {
/* 329 */                 this.failoverCondition.await();
/*     */               }
/*     */             }
/*     */             
/*     */ 
/* 334 */             if (!this.failoverCondition.await(this.connection.getBlockingCallFailoverTimeout(), TimeUnit.MILLISECONDS))
/*     */             {
/* 336 */               HornetQClientLogger.LOGGER.debug("timed-out waiting for failover condition");
/*     */             }
/*     */             
/*     */           }
/*     */           catch (InterruptedException e)
/*     */           {
/* 342 */             throw new HornetQInterruptedException(e);
/*     */           }
/*     */         }
/*     */         
/* 346 */         this.response = null;
/*     */         
/* 348 */         if ((this.resendCache != null) && (packet.isRequiresConfirmations()))
/*     */         {
/* 350 */           this.resendCache.add(packet);
/*     */         }
/*     */         
/* 353 */         this.connection.getTransportConnection().write(buffer, false, false);
/*     */         
/* 355 */         long toWait = this.connection.getBlockingCallTimeout();
/*     */         
/* 357 */         long start = System.currentTimeMillis();
/*     */         
/* 359 */         while ((!this.closed) && ((this.response == null) || ((this.response.getType() != 20) && (this.response.getType() != expectedPacket))) && (toWait > 0L))
/*     */         {
/*     */ 
/*     */           try
/*     */           {
/* 364 */             this.sendCondition.await(toWait, TimeUnit.MILLISECONDS);
/*     */           }
/*     */           catch (InterruptedException e)
/*     */           {
/* 368 */             throw new HornetQInterruptedException(e);
/*     */           }
/*     */           
/* 371 */           if ((this.response != null) && (this.response.getType() != 20) && (this.response.getType() != expectedPacket))
/*     */           {
/* 373 */             HornetQClientLogger.LOGGER.packetOutOfOrder(this.response, new Exception("trace"));
/*     */           }
/*     */           
/* 376 */           if (this.closed) {
/*     */             break;
/*     */           }
/*     */           
/*     */ 
/* 381 */           long now = System.currentTimeMillis();
/*     */           
/* 383 */           toWait -= now - start;
/*     */           
/* 385 */           start = now;
/*     */         }
/*     */         
/* 388 */         if (this.response == null)
/*     */         {
/* 390 */           throw HornetQClientMessageBundle.BUNDLE.timedOutSendingPacket(Byte.valueOf(packet.getType()));
/*     */         }
/*     */         
/* 393 */         if (this.response.getType() == 20)
/*     */         {
/* 395 */           HornetQExceptionMessage mem = (HornetQExceptionMessage)this.response;
/*     */           
/* 397 */           HornetQException e = mem.getException();
/*     */           
/* 399 */           e.fillInStackTrace();
/*     */           
/* 401 */           throw e;
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 406 */         this.lock.unlock();
/*     */       }
/*     */       
/* 409 */       return this.response;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String invokeInterceptors(Packet packet, List<Interceptor> interceptors, RemotingConnection connection)
/*     */   {
/* 420 */     if (interceptors != null)
/*     */     {
/* 422 */       for (Interceptor interceptor : interceptors)
/*     */       {
/*     */         try
/*     */         {
/* 426 */           boolean callNext = interceptor.intercept(packet, connection);
/*     */           
/* 428 */           if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*     */           {
/*     */ 
/* 431 */             StringBuilder msg = new StringBuilder();
/* 432 */             msg.append("Invocation of interceptor ").append(interceptor.getClass().getName()).append(" on ").append(packet).append(" returned ").append(callNext);
/*     */             
/* 434 */             HornetQClientLogger.LOGGER.debug(msg.toString());
/*     */           }
/*     */           
/* 437 */           if (!callNext)
/*     */           {
/* 439 */             return interceptor.getClass().getName();
/*     */           }
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 444 */           HornetQClientLogger.LOGGER.errorCallingInterceptor(e, interceptor);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 449 */     return null;
/*     */   }
/*     */   
/*     */   public void setCommandConfirmationHandler(CommandConfirmationHandler handler)
/*     */   {
/* 454 */     if (this.confWindowSize < 0)
/*     */     {
/* 456 */       String msg = "You can't set confirmationHandler on a connection with confirmation-window-size < 0. Look at the documentation for more information.";
/*     */       
/*     */ 
/* 459 */       throw new IllegalStateException("You can't set confirmationHandler on a connection with confirmation-window-size < 0. Look at the documentation for more information.");
/*     */     }
/* 461 */     this.commandConfirmationHandler = handler;
/*     */   }
/*     */   
/*     */   public void setHandler(ChannelHandler handler)
/*     */   {
/* 466 */     this.handler = handler;
/*     */   }
/*     */   
/*     */   public ChannelHandler getHandler()
/*     */   {
/* 471 */     return this.handler;
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/* 476 */     if (this.closed)
/*     */     {
/* 478 */       return;
/*     */     }
/*     */     
/* 481 */     if ((!this.connection.isDestroyed()) && (!this.connection.removeChannel(this.id)))
/*     */     {
/* 483 */       throw HornetQClientMessageBundle.BUNDLE.noChannelToClose(Long.valueOf(this.id));
/*     */     }
/*     */     
/* 486 */     if (this.failingOver)
/*     */     {
/* 488 */       unlock();
/*     */     }
/* 490 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void transferConnection(CoreRemotingConnection newConnection)
/*     */   {
/* 497 */     synchronized (this.connection.getTransferLock())
/*     */     {
/* 499 */       this.connection.removeChannel(this.id);
/*     */       
/*     */ 
/*     */ 
/* 503 */       CoreRemotingConnection rnewConnection = newConnection;
/*     */       
/* 505 */       rnewConnection.putChannel(this.id, this);
/*     */       
/* 507 */       this.connection = rnewConnection;
/*     */       
/* 509 */       this.transferring = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void replayCommands(int otherLastConfirmedCommandID)
/*     */   {
/* 515 */     if (this.resendCache != null)
/*     */     {
/* 517 */       if (isTrace)
/*     */       {
/* 519 */         HornetQClientLogger.LOGGER.trace("Replaying commands on channelID=" + this.id);
/*     */       }
/* 521 */       clearUpTo(otherLastConfirmedCommandID);
/*     */       
/* 523 */       for (Packet packet : this.resendCache)
/*     */       {
/* 525 */         doWrite(packet);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void lock()
/*     */   {
/* 532 */     this.lock.lock();
/*     */     
/* 534 */     this.failingOver = true;
/*     */     
/* 536 */     this.lock.unlock();
/*     */   }
/*     */   
/*     */   public void unlock()
/*     */   {
/* 541 */     this.lock.lock();
/*     */     
/* 543 */     this.failingOver = false;
/*     */     
/* 545 */     this.failoverCondition.signalAll();
/*     */     
/* 547 */     this.lock.unlock();
/*     */   }
/*     */   
/*     */   public CoreRemotingConnection getConnection()
/*     */   {
/* 552 */     return this.connection;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void flushConfirmations()
/*     */   {
/* 558 */     if ((this.resendCache != null) && (this.receivedBytes != 0))
/*     */     {
/* 560 */       this.receivedBytes = 0;
/*     */       
/* 562 */       Packet confirmed = new PacketsConfirmedMessage(this.lastConfirmedCommandID.get());
/*     */       
/* 564 */       confirmed.setChannelID(this.id);
/*     */       
/* 566 */       doWrite(confirmed);
/*     */     }
/*     */   }
/*     */   
/*     */   public void confirm(Packet packet)
/*     */   {
/* 572 */     if ((this.resendCache != null) && (packet.isRequiresConfirmations()))
/*     */     {
/* 574 */       this.lastConfirmedCommandID.incrementAndGet();
/*     */       
/* 576 */       this.receivedBytes += packet.getPacketSize();
/*     */       
/* 578 */       if (this.receivedBytes >= this.confWindowSize)
/*     */       {
/* 580 */         this.receivedBytes = 0;
/*     */         
/* 582 */         Packet confirmed = new PacketsConfirmedMessage(this.lastConfirmedCommandID.get());
/*     */         
/* 584 */         confirmed.setChannelID(this.id);
/*     */         
/* 586 */         doWrite(confirmed);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearCommands()
/*     */   {
/* 593 */     if (this.resendCache != null)
/*     */     {
/* 595 */       this.lastConfirmedCommandID.set(-1);
/*     */       
/* 597 */       this.firstStoredCommandID = 0;
/*     */       
/* 599 */       this.resendCache.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void handlePacket(Packet packet)
/*     */   {
/* 605 */     if (packet.getType() == 22)
/*     */     {
/* 607 */       if (this.resendCache != null)
/*     */       {
/* 609 */         PacketsConfirmedMessage msg = (PacketsConfirmedMessage)packet;
/*     */         
/* 611 */         clearUpTo(msg.getCommandID());
/*     */       }
/*     */       
/* 614 */       if (!this.connection.isClient())
/*     */       {
/* 616 */         this.handler.handlePacket(packet);
/*     */       }
/*     */       
/* 619 */       return;
/*     */     }
/*     */     
/*     */ 
/* 623 */     if (packet.isResponse())
/*     */     {
/* 625 */       confirm(packet);
/*     */       
/* 627 */       this.lock.lock();
/*     */       
/*     */       try
/*     */       {
/* 631 */         this.response = packet;
/* 632 */         this.sendCondition.signal();
/*     */       }
/*     */       finally
/*     */       {
/* 636 */         this.lock.unlock();
/*     */       }
/*     */     }
/* 639 */     else if (this.handler != null)
/*     */     {
/* 641 */       this.handler.handlePacket(packet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void doWrite(Packet packet)
/*     */   {
/* 648 */     HornetQBuffer buffer = packet.encode(this.connection);
/*     */     
/* 650 */     this.connection.getTransportConnection().write(buffer, false, false);
/*     */   }
/*     */   
/*     */   private void clearUpTo(int lastReceivedCommandID)
/*     */   {
/* 655 */     int numberToClear = 1 + lastReceivedCommandID - this.firstStoredCommandID;
/*     */     
/* 657 */     if (numberToClear == -1)
/*     */     {
/* 659 */       throw HornetQClientMessageBundle.BUNDLE.invalidCommandID(Integer.valueOf(lastReceivedCommandID));
/*     */     }
/*     */     
/* 662 */     int sizeToFree = 0;
/*     */     
/* 664 */     for (int i = 0; i < numberToClear; i++)
/*     */     {
/* 666 */       Packet packet = (Packet)this.resendCache.poll();
/*     */       
/* 668 */       if (packet == null)
/*     */       {
/* 670 */         HornetQClientLogger.LOGGER.cannotFindPacketToClear(Integer.valueOf(lastReceivedCommandID), Integer.valueOf(this.firstStoredCommandID));
/* 671 */         this.firstStoredCommandID = (lastReceivedCommandID + 1);
/* 672 */         return;
/*     */       }
/*     */       
/* 675 */       if (packet.getType() != 22)
/*     */       {
/* 677 */         sizeToFree += packet.getPacketSize();
/*     */       }
/*     */       
/* 680 */       if (this.commandConfirmationHandler != null)
/*     */       {
/* 682 */         this.commandConfirmationHandler.commandConfirmed(packet);
/*     */       }
/*     */     }
/*     */     
/* 686 */     this.firstStoredCommandID += numberToClear;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 692 */     return "Channel[id=" + CHANNEL_ID.idToString(this.id) + ", handler=" + this.handler + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\ChannelImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */