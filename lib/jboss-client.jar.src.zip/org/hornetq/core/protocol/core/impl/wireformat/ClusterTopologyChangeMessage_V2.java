/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.Pair;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterTopologyChangeMessage_V2
/*     */   extends ClusterTopologyChangeMessage
/*     */ {
/*     */   private long uniqueEventID;
/*     */   private String nodeName;
/*     */   
/*     */   public ClusterTopologyChangeMessage_V2(long uniqueEventID, String nodeID, String nodeName, Pair<TransportConfiguration, TransportConfiguration> pair, boolean last)
/*     */   {
/*  31 */     super((byte)114);
/*     */     
/*  33 */     this.nodeID = nodeID;
/*     */     
/*  35 */     this.pair = pair;
/*     */     
/*  37 */     this.last = last;
/*     */     
/*  39 */     this.exit = false;
/*     */     
/*  41 */     this.uniqueEventID = uniqueEventID;
/*     */     
/*  43 */     this.nodeName = nodeName;
/*     */   }
/*     */   
/*     */   public ClusterTopologyChangeMessage_V2(long uniqueEventID, String nodeID)
/*     */   {
/*  48 */     super((byte)114);
/*     */     
/*  50 */     this.exit = true;
/*     */     
/*  52 */     this.nodeID = nodeID;
/*     */     
/*  54 */     this.uniqueEventID = uniqueEventID;
/*     */   }
/*     */   
/*     */   public ClusterTopologyChangeMessage_V2()
/*     */   {
/*  59 */     super((byte)114);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getUniqueEventID()
/*     */   {
/*  67 */     return this.uniqueEventID;
/*     */   }
/*     */   
/*     */   public String getNodeName()
/*     */   {
/*  72 */     return this.nodeName;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  78 */     buffer.writeBoolean(this.exit);
/*  79 */     buffer.writeString(this.nodeID);
/*  80 */     buffer.writeLong(this.uniqueEventID);
/*  81 */     if (!this.exit)
/*     */     {
/*  83 */       if (this.pair.getA() != null)
/*     */       {
/*  85 */         buffer.writeBoolean(true);
/*  86 */         ((TransportConfiguration)this.pair.getA()).encode(buffer);
/*     */       }
/*     */       else
/*     */       {
/*  90 */         buffer.writeBoolean(false);
/*     */       }
/*  92 */       if (this.pair.getB() != null)
/*     */       {
/*  94 */         buffer.writeBoolean(true);
/*  95 */         ((TransportConfiguration)this.pair.getB()).encode(buffer);
/*     */       }
/*     */       else
/*     */       {
/*  99 */         buffer.writeBoolean(false);
/*     */       }
/* 101 */       buffer.writeBoolean(this.last);
/*     */     }
/* 103 */     buffer.writeNullableString(this.nodeName);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 109 */     this.exit = buffer.readBoolean();
/* 110 */     this.nodeID = buffer.readString();
/* 111 */     this.uniqueEventID = buffer.readLong();
/* 112 */     if (!this.exit)
/*     */     {
/* 114 */       boolean hasLive = buffer.readBoolean();
/*     */       TransportConfiguration a;
/* 116 */       if (hasLive)
/*     */       {
/* 118 */         TransportConfiguration a = new TransportConfiguration();
/* 119 */         a.decode(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 123 */         a = null;
/*     */       }
/* 125 */       boolean hasBackup = buffer.readBoolean();
/*     */       TransportConfiguration b;
/* 127 */       if (hasBackup)
/*     */       {
/* 129 */         TransportConfiguration b = new TransportConfiguration();
/* 130 */         b.decode(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 134 */         b = null;
/*     */       }
/* 136 */       this.pair = new Pair(a, b);
/* 137 */       this.last = buffer.readBoolean();
/*     */     }
/* 139 */     if (buffer.readableBytes() > 0)
/*     */     {
/* 141 */       this.nodeName = buffer.readNullableString();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 148 */     int prime = 31;
/* 149 */     int result = super.hashCode();
/* 150 */     result = 31 * result + (this.exit ? 1231 : 1237);
/* 151 */     result = 31 * result + (this.last ? 1231 : 1237);
/* 152 */     result = 31 * result + (this.nodeID == null ? 0 : this.nodeID.hashCode());
/* 153 */     result = 31 * result + (this.pair == null ? 0 : this.pair.hashCode());
/* 154 */     result = 31 * result + (int)(this.uniqueEventID ^ this.uniqueEventID >>> 32);
/* 155 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 161 */     if (this == obj)
/*     */     {
/* 163 */       return true;
/*     */     }
/* 165 */     if (!super.equals(obj))
/*     */     {
/* 167 */       return false;
/*     */     }
/* 169 */     if (!(obj instanceof ClusterTopologyChangeMessage_V2))
/*     */     {
/* 171 */       return false;
/*     */     }
/* 173 */     ClusterTopologyChangeMessage_V2 other = (ClusterTopologyChangeMessage_V2)obj;
/* 174 */     if (this.exit != other.exit)
/*     */     {
/* 176 */       return false;
/*     */     }
/* 178 */     if (this.last != other.last)
/*     */     {
/* 180 */       return false;
/*     */     }
/* 182 */     if (this.nodeID == null)
/*     */     {
/* 184 */       if (other.nodeID != null)
/*     */       {
/* 186 */         return false;
/*     */       }
/*     */     }
/* 189 */     else if (!this.nodeID.equals(other.nodeID))
/*     */     {
/* 191 */       return false;
/*     */     }
/* 193 */     if (this.pair == null)
/*     */     {
/* 195 */       if (other.pair != null)
/*     */       {
/* 197 */         return false;
/*     */       }
/*     */     }
/* 200 */     else if (!this.pair.equals(other.pair))
/*     */     {
/* 202 */       return false;
/*     */     }
/* 204 */     if (this.uniqueEventID != other.uniqueEventID)
/*     */     {
/* 206 */       return false;
/*     */     }
/* 208 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\ClusterTopologyChangeMessage_V2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */