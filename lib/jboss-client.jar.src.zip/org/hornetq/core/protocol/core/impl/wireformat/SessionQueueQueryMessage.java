/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.api.core.SimpleString;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionQueueQueryMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private SimpleString queueName;
/*    */   
/*    */   public SessionQueueQueryMessage(SimpleString queueName)
/*    */   {
/* 33 */     super((byte)45);
/*    */     
/* 35 */     this.queueName = queueName;
/*    */   }
/*    */   
/*    */   public SessionQueueQueryMessage()
/*    */   {
/* 40 */     super((byte)45);
/*    */   }
/*    */   
/*    */   public SimpleString getQueueName()
/*    */   {
/* 45 */     return this.queueName;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 51 */     buffer.writeSimpleString(this.queueName);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 57 */     this.queueName = buffer.readSimpleString();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 63 */     int prime = 31;
/* 64 */     int result = super.hashCode();
/* 65 */     result = 31 * result + (this.queueName == null ? 0 : this.queueName.hashCode());
/* 66 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 72 */     if (this == obj)
/* 73 */       return true;
/* 74 */     if (!super.equals(obj))
/* 75 */       return false;
/* 76 */     if (!(obj instanceof SessionQueueQueryMessage))
/* 77 */       return false;
/* 78 */     SessionQueueQueryMessage other = (SessionQueueQueryMessage)obj;
/* 79 */     if (this.queueName == null)
/*    */     {
/* 81 */       if (other.queueName != null) {
/* 82 */         return false;
/*    */       }
/* 84 */     } else if (!this.queueName.equals(other.queueName))
/* 85 */       return false;
/* 86 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionQueueQueryMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */