/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.message.impl.MessageInternal;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionSendLargeMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private final MessageInternal largeMessage;
/*    */   
/*    */   public SessionSendLargeMessage(MessageInternal largeMessage)
/*    */   {
/* 39 */     super((byte)72);
/*    */     
/* 41 */     this.largeMessage = largeMessage;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public MessageInternal getLargeMessage()
/*    */   {
/* 48 */     return this.largeMessage;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 54 */     this.largeMessage.encodeHeadersAndProperties(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 60 */     this.largeMessage.decodeHeadersAndProperties(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 66 */     int prime = 31;
/* 67 */     int result = super.hashCode();
/* 68 */     result = 31 * result + (this.largeMessage == null ? 0 : this.largeMessage.hashCode());
/* 69 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 75 */     if (this == obj)
/* 76 */       return true;
/* 77 */     if (!super.equals(obj))
/* 78 */       return false;
/* 79 */     if (!(obj instanceof SessionSendLargeMessage))
/* 80 */       return false;
/* 81 */     SessionSendLargeMessage other = (SessionSendLargeMessage)obj;
/* 82 */     if (this.largeMessage == null)
/*    */     {
/* 84 */       if (other.largeMessage != null) {
/* 85 */         return false;
/*    */       }
/* 87 */     } else if (!this.largeMessage.equals(other.largeMessage))
/* 88 */       return false;
/* 89 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionSendLargeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */