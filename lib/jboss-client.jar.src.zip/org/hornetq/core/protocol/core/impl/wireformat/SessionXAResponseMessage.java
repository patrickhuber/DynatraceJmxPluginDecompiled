/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionXAResponseMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private boolean error;
/*     */   private int responseCode;
/*     */   private String message;
/*     */   
/*     */   public SessionXAResponseMessage(boolean isError, int responseCode, String message)
/*     */   {
/*  32 */     super((byte)55);
/*     */     
/*  34 */     this.error = isError;
/*     */     
/*  36 */     this.responseCode = responseCode;
/*     */     
/*  38 */     this.message = message;
/*     */   }
/*     */   
/*     */   public SessionXAResponseMessage()
/*     */   {
/*  43 */     super((byte)55);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isResponse()
/*     */   {
/*  51 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isError()
/*     */   {
/*  56 */     return this.error;
/*     */   }
/*     */   
/*     */   public int getResponseCode()
/*     */   {
/*  61 */     return this.responseCode;
/*     */   }
/*     */   
/*     */   public String getMessage()
/*     */   {
/*  66 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  72 */     buffer.writeBoolean(this.error);
/*  73 */     buffer.writeInt(this.responseCode);
/*  74 */     buffer.writeNullableString(this.message);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  80 */     this.error = buffer.readBoolean();
/*  81 */     this.responseCode = buffer.readInt();
/*  82 */     this.message = buffer.readNullableString();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  88 */     int prime = 31;
/*  89 */     int result = super.hashCode();
/*  90 */     result = 31 * result + (this.error ? 1231 : 1237);
/*  91 */     result = 31 * result + (this.message == null ? 0 : this.message.hashCode());
/*  92 */     result = 31 * result + this.responseCode;
/*  93 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  99 */     if (this == obj)
/* 100 */       return true;
/* 101 */     if (!super.equals(obj))
/* 102 */       return false;
/* 103 */     if (!(obj instanceof SessionXAResponseMessage))
/* 104 */       return false;
/* 105 */     SessionXAResponseMessage other = (SessionXAResponseMessage)obj;
/* 106 */     if (this.error != other.error)
/* 107 */       return false;
/* 108 */     if (this.message == null)
/*     */     {
/* 110 */       if (other.message != null) {
/* 111 */         return false;
/*     */       }
/* 113 */     } else if (!this.message.equals(other.message))
/* 114 */       return false;
/* 115 */     if (this.responseCode != other.responseCode)
/* 116 */       return false;
/* 117 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */