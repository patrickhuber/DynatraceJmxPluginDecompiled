/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAResumeMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXAResumeMessage(Xid xid)
/*    */   {
/* 32 */     super((byte)59);
/*    */     
/* 34 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXAResumeMessage()
/*    */   {
/* 39 */     super((byte)59);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Xid getXid()
/*    */   {
/* 46 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 52 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 58 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 64 */     int prime = 31;
/* 65 */     int result = super.hashCode();
/* 66 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 67 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 73 */     if (this == obj)
/* 74 */       return true;
/* 75 */     if (!super.equals(obj))
/* 76 */       return false;
/* 77 */     if (!(obj instanceof SessionXAResumeMessage))
/* 78 */       return false;
/* 79 */     SessionXAResumeMessage other = (SessionXAResumeMessage)obj;
/* 80 */     if (this.xid == null)
/*    */     {
/* 82 */       if (other.xid != null) {
/* 83 */         return false;
/*    */       }
/* 85 */     } else if (!this.xid.equals(other.xid))
/* 86 */       return false;
/* 87 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAResumeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */