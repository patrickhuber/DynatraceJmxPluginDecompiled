/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionBindingQueryResponseMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private boolean exists;
/*     */   private List<SimpleString> queueNames;
/*     */   
/*     */   public SessionBindingQueryResponseMessage(boolean exists, List<SimpleString> queueNames)
/*     */   {
/*  38 */     super((byte)50);
/*     */     
/*  40 */     this.exists = exists;
/*     */     
/*  42 */     this.queueNames = queueNames;
/*     */   }
/*     */   
/*     */   public SessionBindingQueryResponseMessage()
/*     */   {
/*  47 */     super((byte)50);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isResponse()
/*     */   {
/*  53 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isExists()
/*     */   {
/*  58 */     return this.exists;
/*     */   }
/*     */   
/*     */   public List<SimpleString> getQueueNames()
/*     */   {
/*  63 */     return this.queueNames;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  69 */     buffer.writeBoolean(this.exists);
/*  70 */     buffer.writeInt(this.queueNames.size());
/*  71 */     for (SimpleString queueName : this.queueNames)
/*     */     {
/*  73 */       buffer.writeSimpleString(queueName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  80 */     this.exists = buffer.readBoolean();
/*  81 */     int numQueues = buffer.readInt();
/*  82 */     this.queueNames = new ArrayList(numQueues);
/*  83 */     for (int i = 0; i < numQueues; i++)
/*     */     {
/*  85 */       this.queueNames.add(buffer.readSimpleString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  92 */     int prime = 31;
/*  93 */     int result = super.hashCode();
/*  94 */     result = 31 * result + (this.exists ? 1231 : 1237);
/*  95 */     result = 31 * result + (this.queueNames == null ? 0 : this.queueNames.hashCode());
/*  96 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 102 */     if (this == obj)
/* 103 */       return true;
/* 104 */     if (!super.equals(obj))
/* 105 */       return false;
/* 106 */     if (!(obj instanceof SessionBindingQueryResponseMessage))
/* 107 */       return false;
/* 108 */     SessionBindingQueryResponseMessage other = (SessionBindingQueryResponseMessage)obj;
/* 109 */     if (this.exists != other.exists)
/* 110 */       return false;
/* 111 */     if (this.queueNames == null)
/*     */     {
/* 113 */       if (other.queueNames != null) {
/* 114 */         return false;
/*     */       }
/* 116 */     } else if (!this.queueNames.equals(other.queueNames))
/* 117 */       return false;
/* 118 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionBindingQueryResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */