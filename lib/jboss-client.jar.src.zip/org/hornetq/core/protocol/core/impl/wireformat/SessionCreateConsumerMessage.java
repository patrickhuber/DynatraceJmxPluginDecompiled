/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionCreateConsumerMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private long id;
/*     */   private SimpleString queueName;
/*     */   private SimpleString filterString;
/*     */   private boolean browseOnly;
/*     */   private boolean requiresResponse;
/*     */   
/*     */   public SessionCreateConsumerMessage(long id, SimpleString queueName, SimpleString filterString, boolean browseOnly, boolean requiresResponse)
/*     */   {
/*  42 */     super((byte)40);
/*     */     
/*  44 */     this.id = id;
/*  45 */     this.queueName = queueName;
/*  46 */     this.filterString = filterString;
/*  47 */     this.browseOnly = browseOnly;
/*  48 */     this.requiresResponse = requiresResponse;
/*     */   }
/*     */   
/*     */   public SessionCreateConsumerMessage()
/*     */   {
/*  53 */     super((byte)40);
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  59 */     StringBuffer buff = new StringBuffer(getParentString());
/*  60 */     buff.append(", queueName=" + this.queueName);
/*  61 */     buff.append(", filterString=" + this.filterString);
/*  62 */     buff.append("]");
/*  63 */     return buff.toString();
/*     */   }
/*     */   
/*     */   public long getID()
/*     */   {
/*  68 */     return this.id;
/*     */   }
/*     */   
/*     */   public SimpleString getQueueName()
/*     */   {
/*  73 */     return this.queueName;
/*     */   }
/*     */   
/*     */   public SimpleString getFilterString()
/*     */   {
/*  78 */     return this.filterString;
/*     */   }
/*     */   
/*     */   public boolean isBrowseOnly()
/*     */   {
/*  83 */     return this.browseOnly;
/*     */   }
/*     */   
/*     */   public boolean isRequiresResponse()
/*     */   {
/*  88 */     return this.requiresResponse;
/*     */   }
/*     */   
/*     */   public void setQueueName(SimpleString queueName)
/*     */   {
/*  93 */     this.queueName = queueName;
/*     */   }
/*     */   
/*     */   public void setFilterString(SimpleString filterString)
/*     */   {
/*  98 */     this.filterString = filterString;
/*     */   }
/*     */   
/*     */   public void setBrowseOnly(boolean browseOnly)
/*     */   {
/* 103 */     this.browseOnly = browseOnly;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/* 109 */     buffer.writeLong(this.id);
/* 110 */     buffer.writeSimpleString(this.queueName);
/* 111 */     buffer.writeNullableSimpleString(this.filterString);
/* 112 */     buffer.writeBoolean(this.browseOnly);
/* 113 */     buffer.writeBoolean(this.requiresResponse);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 119 */     this.id = buffer.readLong();
/* 120 */     this.queueName = buffer.readSimpleString();
/* 121 */     this.filterString = buffer.readNullableSimpleString();
/* 122 */     this.browseOnly = buffer.readBoolean();
/* 123 */     this.requiresResponse = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 129 */     int prime = 31;
/* 130 */     int result = super.hashCode();
/* 131 */     result = 31 * result + (this.browseOnly ? 1231 : 1237);
/* 132 */     result = 31 * result + (this.filterString == null ? 0 : this.filterString.hashCode());
/* 133 */     result = 31 * result + (int)(this.id ^ this.id >>> 32);
/* 134 */     result = 31 * result + (this.queueName == null ? 0 : this.queueName.hashCode());
/* 135 */     result = 31 * result + (this.requiresResponse ? 1231 : 1237);
/* 136 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 142 */     if (this == obj)
/* 143 */       return true;
/* 144 */     if (!super.equals(obj))
/* 145 */       return false;
/* 146 */     if (!(obj instanceof SessionCreateConsumerMessage))
/* 147 */       return false;
/* 148 */     SessionCreateConsumerMessage other = (SessionCreateConsumerMessage)obj;
/* 149 */     if (this.browseOnly != other.browseOnly)
/* 150 */       return false;
/* 151 */     if (this.filterString == null)
/*     */     {
/* 153 */       if (other.filterString != null) {
/* 154 */         return false;
/*     */       }
/* 156 */     } else if (!this.filterString.equals(other.filterString))
/* 157 */       return false;
/* 158 */     if (this.id != other.id)
/* 159 */       return false;
/* 160 */     if (this.queueName == null)
/*     */     {
/* 162 */       if (other.queueName != null) {
/* 163 */         return false;
/*     */       }
/* 165 */     } else if (!this.queueName.equals(other.queueName))
/* 166 */       return false;
/* 167 */     if (this.requiresResponse != other.requiresResponse)
/* 168 */       return false;
/* 169 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionCreateConsumerMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */