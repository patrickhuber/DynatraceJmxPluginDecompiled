/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.api.core.SimpleString;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionDeleteQueueMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private SimpleString queueName;
/*    */   
/*    */   public SessionDeleteQueueMessage(SimpleString queueName)
/*    */   {
/* 30 */     super((byte)35);
/*    */     
/* 32 */     this.queueName = queueName;
/*    */   }
/*    */   
/*    */   public SessionDeleteQueueMessage()
/*    */   {
/* 37 */     super((byte)35);
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 43 */     StringBuffer buff = new StringBuffer(getParentString());
/* 44 */     buff.append(", queueName=" + this.queueName);
/* 45 */     buff.append("]");
/* 46 */     return buff.toString();
/*    */   }
/*    */   
/*    */   public SimpleString getQueueName()
/*    */   {
/* 51 */     return this.queueName;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 57 */     buffer.writeSimpleString(this.queueName);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 63 */     this.queueName = buffer.readSimpleString();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 69 */     int prime = 31;
/* 70 */     int result = super.hashCode();
/* 71 */     result = 31 * result + (this.queueName == null ? 0 : this.queueName.hashCode());
/* 72 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 78 */     if (this == obj)
/* 79 */       return true;
/* 80 */     if (!super.equals(obj))
/* 81 */       return false;
/* 82 */     if (!(obj instanceof SessionDeleteQueueMessage))
/* 83 */       return false;
/* 84 */     SessionDeleteQueueMessage other = (SessionDeleteQueueMessage)obj;
/* 85 */     if (this.queueName == null)
/*    */     {
/* 87 */       if (other.queueName != null) {
/* 88 */         return false;
/*    */       }
/* 90 */     } else if (!this.queueName.equals(other.queueName))
/* 91 */       return false;
/* 92 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionDeleteQueueMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */