/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.api.core.SimpleString;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionBindingQueryMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private SimpleString address;
/*    */   
/*    */   public SessionBindingQueryMessage(SimpleString address)
/*    */   {
/* 33 */     super((byte)49);
/*    */     
/* 35 */     this.address = address;
/*    */   }
/*    */   
/*    */   public SessionBindingQueryMessage()
/*    */   {
/* 40 */     super((byte)49);
/*    */   }
/*    */   
/*    */   public SimpleString getAddress()
/*    */   {
/* 45 */     return this.address;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 51 */     buffer.writeSimpleString(this.address);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 57 */     this.address = buffer.readSimpleString();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 63 */     int prime = 31;
/* 64 */     int result = super.hashCode();
/* 65 */     result = 31 * result + (this.address == null ? 0 : this.address.hashCode());
/* 66 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 72 */     if (this == obj)
/* 73 */       return true;
/* 74 */     if (!super.equals(obj))
/* 75 */       return false;
/* 76 */     if (!(obj instanceof SessionBindingQueryMessage))
/* 77 */       return false;
/* 78 */     SessionBindingQueryMessage other = (SessionBindingQueryMessage)obj;
/* 79 */     if (this.address == null)
/*    */     {
/* 81 */       if (other.address != null) {
/* 82 */         return false;
/*    */       }
/* 84 */     } else if (!this.address.equals(other.address))
/* 85 */       return false;
/* 86 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionBindingQueryMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */