/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAAfterFailedMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXAAfterFailedMessage(Xid xid)
/*    */   {
/* 41 */     super((byte)39);
/*    */     
/* 43 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXAAfterFailedMessage()
/*    */   {
/* 48 */     super((byte)39);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Xid getXid()
/*    */   {
/* 55 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 61 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 67 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 73 */     int prime = 31;
/* 74 */     int result = super.hashCode();
/* 75 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 76 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 82 */     if (this == obj)
/* 83 */       return true;
/* 84 */     if (!super.equals(obj))
/* 85 */       return false;
/* 86 */     if (!(obj instanceof SessionXAAfterFailedMessage))
/* 87 */       return false;
/* 88 */     SessionXAAfterFailedMessage other = (SessionXAAfterFailedMessage)obj;
/* 89 */     if (this.xid == null)
/*    */     {
/* 91 */       if (other.xid != null) {
/* 92 */         return false;
/*    */       }
/* 94 */     } else if (!this.xid.equals(other.xid))
/* 95 */       return false;
/* 96 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAAfterFailedMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */