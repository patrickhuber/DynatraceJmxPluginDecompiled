/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAForgetMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXAForgetMessage(Xid xid)
/*    */   {
/* 31 */     super((byte)60);
/*    */     
/* 33 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXAForgetMessage()
/*    */   {
/* 38 */     super((byte)60);
/*    */   }
/*    */   
/*    */   public Xid getXid()
/*    */   {
/* 43 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 49 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 55 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 61 */     int prime = 31;
/* 62 */     int result = super.hashCode();
/* 63 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 64 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 70 */     if (this == obj)
/* 71 */       return true;
/* 72 */     if (!super.equals(obj))
/* 73 */       return false;
/* 74 */     if (!(obj instanceof SessionXAForgetMessage))
/* 75 */       return false;
/* 76 */     SessionXAForgetMessage other = (SessionXAForgetMessage)obj;
/* 77 */     if (this.xid == null)
/*    */     {
/* 79 */       if (other.xid != null) {
/* 80 */         return false;
/*    */       }
/* 82 */     } else if (!this.xid.equals(other.xid))
/* 83 */       return false;
/* 84 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAForgetMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */