/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionConsumerCloseMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private long consumerID;
/*    */   
/*    */   public SessionConsumerCloseMessage(long objectID)
/*    */   {
/* 29 */     super((byte)74);
/*    */     
/* 31 */     this.consumerID = objectID;
/*    */   }
/*    */   
/*    */   public SessionConsumerCloseMessage()
/*    */   {
/* 36 */     super((byte)74);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public long getConsumerID()
/*    */   {
/* 43 */     return this.consumerID;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 49 */     buffer.writeLong(this.consumerID);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 55 */     this.consumerID = buffer.readLong();
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 61 */     return getParentString() + ", consumerID=" + this.consumerID + "]";
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 67 */     int prime = 31;
/* 68 */     int result = super.hashCode();
/* 69 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/* 70 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 76 */     if (this == obj)
/* 77 */       return true;
/* 78 */     if (!super.equals(obj))
/* 79 */       return false;
/* 80 */     if (!(obj instanceof SessionConsumerCloseMessage))
/* 81 */       return false;
/* 82 */     SessionConsumerCloseMessage other = (SessionConsumerCloseMessage)obj;
/* 83 */     if (this.consumerID != other.consumerID)
/* 84 */       return false;
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionConsumerCloseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */