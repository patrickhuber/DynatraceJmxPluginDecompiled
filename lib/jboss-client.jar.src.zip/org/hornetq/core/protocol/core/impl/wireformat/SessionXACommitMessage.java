/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import javax.transaction.xa.Xid;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ import org.hornetq.utils.XidCodecSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionXACommitMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private boolean onePhase;
/*     */   private Xid xid;
/*     */   
/*     */   public SessionXACommitMessage(Xid xid, boolean onePhase)
/*     */   {
/*  34 */     super((byte)53);
/*     */     
/*  36 */     this.xid = xid;
/*  37 */     this.onePhase = onePhase;
/*     */   }
/*     */   
/*     */   public SessionXACommitMessage()
/*     */   {
/*  42 */     super((byte)53);
/*     */   }
/*     */   
/*     */   public Xid getXid()
/*     */   {
/*  47 */     return this.xid;
/*     */   }
/*     */   
/*     */   public boolean isOnePhase()
/*     */   {
/*  52 */     return this.onePhase;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isAsyncExec()
/*     */   {
/*  58 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  64 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*  65 */     buffer.writeBoolean(this.onePhase);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  71 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*  72 */     this.onePhase = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  78 */     return getParentString() + ", xid=" + this.xid + ", onePhase=" + this.onePhase + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  84 */     int prime = 31;
/*  85 */     int result = super.hashCode();
/*  86 */     result = 31 * result + (this.onePhase ? 1231 : 1237);
/*  87 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/*  88 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  94 */     if (this == obj)
/*  95 */       return true;
/*  96 */     if (!super.equals(obj))
/*  97 */       return false;
/*  98 */     if (!(obj instanceof SessionXACommitMessage))
/*  99 */       return false;
/* 100 */     SessionXACommitMessage other = (SessionXACommitMessage)obj;
/* 101 */     if (this.onePhase != other.onePhase)
/* 102 */       return false;
/* 103 */     if (this.xid == null)
/*     */     {
/* 105 */       if (other.xid != null) {
/* 106 */         return false;
/*     */       }
/* 108 */     } else if (!this.xid.equals(other.xid))
/* 109 */       return false;
/* 110 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXACommitMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */