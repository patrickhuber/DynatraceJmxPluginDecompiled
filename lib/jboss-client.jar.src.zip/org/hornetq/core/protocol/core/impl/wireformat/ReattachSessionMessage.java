/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReattachSessionMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private String name;
/*     */   private int lastConfirmedCommandID;
/*     */   
/*     */   public ReattachSessionMessage(String name, int lastConfirmedCommandID)
/*     */   {
/*  34 */     super((byte)32);
/*     */     
/*  36 */     this.name = name;
/*     */     
/*  38 */     this.lastConfirmedCommandID = lastConfirmedCommandID;
/*     */   }
/*     */   
/*     */   public ReattachSessionMessage()
/*     */   {
/*  43 */     super((byte)32);
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  48 */     return this.name;
/*     */   }
/*     */   
/*     */   public int getLastConfirmedCommandID()
/*     */   {
/*  53 */     return this.lastConfirmedCommandID;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  59 */     buffer.writeString(this.name);
/*  60 */     buffer.writeInt(this.lastConfirmedCommandID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  66 */     this.name = buffer.readString();
/*  67 */     this.lastConfirmedCommandID = buffer.readInt();
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/*  73 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  79 */     int prime = 31;
/*  80 */     int result = super.hashCode();
/*  81 */     result = 31 * result + this.lastConfirmedCommandID;
/*  82 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/*  83 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  89 */     if (this == obj)
/*  90 */       return true;
/*  91 */     if (!super.equals(obj))
/*  92 */       return false;
/*  93 */     if (!(obj instanceof ReattachSessionMessage))
/*  94 */       return false;
/*  95 */     ReattachSessionMessage other = (ReattachSessionMessage)obj;
/*  96 */     if (this.lastConfirmedCommandID != other.lastConfirmedCommandID)
/*  97 */       return false;
/*  98 */     if (this.name == null)
/*     */     {
/* 100 */       if (other.name != null) {
/* 101 */         return false;
/*     */       }
/* 103 */     } else if (!this.name.equals(other.name))
/* 104 */       return false;
/* 105 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\ReattachSessionMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */