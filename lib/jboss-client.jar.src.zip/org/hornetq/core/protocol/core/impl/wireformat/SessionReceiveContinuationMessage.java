/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionReceiveContinuationMessage
/*     */   extends SessionContinuationMessage
/*     */ {
/*     */   public static final int SESSION_RECEIVE_CONTINUATION_BASE_SIZE = 26;
/*     */   private long consumerID;
/*     */   
/*     */   public SessionReceiveContinuationMessage()
/*     */   {
/*  45 */     super((byte)77);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionReceiveContinuationMessage(long consumerID, byte[] body, boolean continues, boolean requiresResponse)
/*     */   {
/*  59 */     super((byte)77, body, continues);
/*  60 */     this.consumerID = consumerID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionReceiveContinuationMessage(long consumerID, byte[] body, boolean continues, boolean requiresResponse, int packetSize)
/*     */   {
/*  69 */     this(consumerID, body, continues, requiresResponse);
/*  70 */     this.size = packetSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getConsumerID()
/*     */   {
/*  78 */     return this.consumerID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  86 */     super.encodeRest(buffer);
/*  87 */     buffer.writeLong(this.consumerID);
/*     */   }
/*     */   
/*     */   public int getPacketSize()
/*     */   {
/*  92 */     if (this.size == -1)
/*     */     {
/*     */ 
/*  95 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*  99 */     return this.size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 108 */     super.decodeRest(buffer);
/* 109 */     this.consumerID = buffer.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 115 */     int prime = 31;
/* 116 */     int result = super.hashCode();
/* 117 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/* 118 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 124 */     if (this == obj)
/* 125 */       return true;
/* 126 */     if (!super.equals(obj))
/* 127 */       return false;
/* 128 */     if (!(obj instanceof SessionReceiveContinuationMessage))
/* 129 */       return false;
/* 130 */     SessionReceiveContinuationMessage other = (SessionReceiveContinuationMessage)obj;
/* 131 */     if (this.consumerID != other.consumerID)
/* 132 */       return false;
/* 133 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionReceiveContinuationMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */