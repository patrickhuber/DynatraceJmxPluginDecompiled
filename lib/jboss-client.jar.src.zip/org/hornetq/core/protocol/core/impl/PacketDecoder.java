/*     */ package org.hornetq.core.protocol.core.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.core.protocol.core.Packet;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.ClusterTopologyChangeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.ClusterTopologyChangeMessage_V2;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.CreateQueueMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.CreateSessionMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.CreateSessionResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.DisconnectMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.HornetQExceptionMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.NodeAnnounceMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.NullResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.PacketsConfirmedMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.Ping;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.ReattachSessionMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.ReattachSessionResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.RollbackMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionAcknowledgeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionAddMetaDataMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionAddMetaDataMessageV2;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionBindingQueryMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionBindingQueryResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionCloseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionCommitMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionConsumerCloseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionConsumerFlowCreditMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionCreateConsumerMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionDeleteQueueMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionExpireMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionForceConsumerDelivery;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionIndividualAcknowledgeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionProducerCreditsFailMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionProducerCreditsMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionQueueQueryMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionQueueQueryResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionRequestProducerCreditsMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionSendContinuationMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionUniqueAddMetaDataMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAAfterFailedMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXACommitMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAEndMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAForgetMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAGetInDoubtXidsResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAGetTimeoutResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAJoinMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAPrepareMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAResumeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXARollbackMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXASetTimeoutMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXASetTimeoutResponseMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAStartMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SubscribeClusterTopologyUpdatesMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SubscribeClusterTopologyUpdatesMessageV2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PacketDecoder
/*     */   implements Serializable
/*     */ {
/*     */   public abstract Packet decode(HornetQBuffer paramHornetQBuffer);
/*     */   
/*     */   public Packet decode(byte packetType)
/*     */   {
/*     */     Packet packet;
/* 145 */     switch (packetType)
/*     */     {
/*     */ 
/*     */     case 10: 
/* 149 */       packet = new Ping();
/* 150 */       break;
/*     */     
/*     */ 
/*     */     case 11: 
/* 154 */       packet = new DisconnectMessage();
/* 155 */       break;
/*     */     
/*     */ 
/*     */     case 20: 
/* 159 */       packet = new HornetQExceptionMessage();
/* 160 */       break;
/*     */     
/*     */ 
/*     */     case 22: 
/* 164 */       packet = new PacketsConfirmedMessage();
/* 165 */       break;
/*     */     
/*     */ 
/*     */     case 30: 
/* 169 */       packet = new CreateSessionMessage();
/* 170 */       break;
/*     */     
/*     */ 
/*     */     case 31: 
/* 174 */       packet = new CreateSessionResponseMessage();
/* 175 */       break;
/*     */     
/*     */ 
/*     */     case 32: 
/* 179 */       packet = new ReattachSessionMessage();
/* 180 */       break;
/*     */     
/*     */ 
/*     */     case 33: 
/* 184 */       packet = new ReattachSessionResponseMessage();
/* 185 */       break;
/*     */     
/*     */ 
/*     */     case 69: 
/* 189 */       packet = new SessionCloseMessage();
/* 190 */       break;
/*     */     
/*     */ 
/*     */     case 40: 
/* 194 */       packet = new SessionCreateConsumerMessage();
/* 195 */       break;
/*     */     
/*     */ 
/*     */     case 41: 
/* 199 */       packet = new SessionAcknowledgeMessage();
/* 200 */       break;
/*     */     
/*     */ 
/*     */     case 42: 
/* 204 */       packet = new SessionExpireMessage();
/* 205 */       break;
/*     */     
/*     */ 
/*     */     case 43: 
/* 209 */       packet = new SessionCommitMessage();
/* 210 */       break;
/*     */     
/*     */ 
/*     */     case 44: 
/* 214 */       packet = new RollbackMessage();
/* 215 */       break;
/*     */     
/*     */ 
/*     */     case 45: 
/* 219 */       packet = new SessionQueueQueryMessage();
/* 220 */       break;
/*     */     
/*     */ 
/*     */     case 46: 
/* 224 */       packet = new SessionQueueQueryResponseMessage();
/* 225 */       break;
/*     */     
/*     */ 
/*     */     case 34: 
/* 229 */       packet = new CreateQueueMessage();
/* 230 */       break;
/*     */     
/*     */ 
/*     */     case 35: 
/* 234 */       packet = new SessionDeleteQueueMessage();
/* 235 */       break;
/*     */     
/*     */ 
/*     */     case 49: 
/* 239 */       packet = new SessionBindingQueryMessage();
/* 240 */       break;
/*     */     
/*     */ 
/*     */     case 50: 
/* 244 */       packet = new SessionBindingQueryResponseMessage();
/* 245 */       break;
/*     */     
/*     */ 
/*     */     case 51: 
/* 249 */       packet = new SessionXAStartMessage();
/* 250 */       break;
/*     */     
/*     */ 
/*     */     case 39: 
/* 254 */       packet = new SessionXAAfterFailedMessage();
/* 255 */       break;
/*     */     
/*     */ 
/*     */     case 52: 
/* 259 */       packet = new SessionXAEndMessage();
/* 260 */       break;
/*     */     
/*     */ 
/*     */     case 53: 
/* 264 */       packet = new SessionXACommitMessage();
/* 265 */       break;
/*     */     
/*     */ 
/*     */     case 54: 
/* 269 */       packet = new SessionXAPrepareMessage();
/* 270 */       break;
/*     */     
/*     */ 
/*     */     case 55: 
/* 274 */       packet = new SessionXAResponseMessage();
/* 275 */       break;
/*     */     
/*     */ 
/*     */     case 56: 
/* 279 */       packet = new SessionXARollbackMessage();
/* 280 */       break;
/*     */     
/*     */ 
/*     */     case 57: 
/* 284 */       packet = new SessionXAJoinMessage();
/* 285 */       break;
/*     */     
/*     */ 
/*     */     case 58: 
/* 289 */       packet = new PacketImpl((byte)58);
/* 290 */       break;
/*     */     
/*     */ 
/*     */     case 59: 
/* 294 */       packet = new SessionXAResumeMessage();
/* 295 */       break;
/*     */     
/*     */ 
/*     */     case 60: 
/* 299 */       packet = new SessionXAForgetMessage();
/* 300 */       break;
/*     */     
/*     */ 
/*     */     case 61: 
/* 304 */       packet = new PacketImpl((byte)61);
/* 305 */       break;
/*     */     
/*     */ 
/*     */     case 62: 
/* 309 */       packet = new SessionXAGetInDoubtXidsResponseMessage();
/* 310 */       break;
/*     */     
/*     */ 
/*     */     case 63: 
/* 314 */       packet = new SessionXASetTimeoutMessage();
/* 315 */       break;
/*     */     
/*     */ 
/*     */     case 64: 
/* 319 */       packet = new SessionXASetTimeoutResponseMessage();
/* 320 */       break;
/*     */     
/*     */ 
/*     */     case 65: 
/* 324 */       packet = new PacketImpl((byte)65);
/* 325 */       break;
/*     */     
/*     */ 
/*     */     case 66: 
/* 329 */       packet = new SessionXAGetTimeoutResponseMessage();
/* 330 */       break;
/*     */     
/*     */ 
/*     */     case 67: 
/* 334 */       packet = new PacketImpl((byte)67);
/* 335 */       break;
/*     */     
/*     */ 
/*     */     case 68: 
/* 339 */       packet = new PacketImpl((byte)68);
/* 340 */       break;
/*     */     
/*     */ 
/*     */     case 70: 
/* 344 */       packet = new SessionConsumerFlowCreditMessage();
/* 345 */       break;
/*     */     
/*     */ 
/*     */     case 74: 
/* 349 */       packet = new SessionConsumerCloseMessage();
/* 350 */       break;
/*     */     
/*     */ 
/*     */     case 81: 
/* 354 */       packet = new SessionIndividualAcknowledgeMessage();
/* 355 */       break;
/*     */     
/*     */ 
/*     */     case 21: 
/* 359 */       packet = new NullResponseMessage();
/* 360 */       break;
/*     */     
/*     */ 
/*     */     case 77: 
/* 364 */       packet = new SessionReceiveContinuationMessage();
/* 365 */       break;
/*     */     
/*     */ 
/*     */     case 73: 
/* 369 */       packet = new SessionSendContinuationMessage();
/* 370 */       break;
/*     */     
/*     */ 
/*     */     case 79: 
/* 374 */       packet = new SessionRequestProducerCreditsMessage();
/* 375 */       break;
/*     */     
/*     */ 
/*     */     case 80: 
/* 379 */       packet = new SessionProducerCreditsMessage();
/* 380 */       break;
/*     */     
/*     */ 
/*     */     case 82: 
/* 384 */       packet = new SessionProducerCreditsFailMessage();
/* 385 */       break;
/*     */     
/*     */ 
/*     */     case 78: 
/* 389 */       packet = new SessionForceConsumerDelivery();
/* 390 */       break;
/*     */     
/*     */ 
/*     */     case 110: 
/* 394 */       packet = new ClusterTopologyChangeMessage();
/* 395 */       break;
/*     */     
/*     */ 
/*     */     case 114: 
/* 399 */       packet = new ClusterTopologyChangeMessage_V2();
/* 400 */       break;
/*     */     
/*     */ 
/*     */     case 111: 
/* 404 */       packet = new NodeAnnounceMessage();
/* 405 */       break;
/*     */     
/*     */ 
/*     */     case 112: 
/* 409 */       packet = new SubscribeClusterTopologyUpdatesMessage();
/* 410 */       break;
/*     */     
/*     */ 
/*     */     case 113: 
/* 414 */       packet = new SubscribeClusterTopologyUpdatesMessageV2();
/* 415 */       break;
/*     */     
/*     */ 
/*     */     case 104: 
/* 419 */       packet = new SessionAddMetaDataMessage();
/* 420 */       break;
/*     */     
/*     */ 
/*     */     case 105: 
/* 424 */       packet = new SessionAddMetaDataMessageV2();
/* 425 */       break;
/*     */     
/*     */ 
/*     */     case 106: 
/* 429 */       packet = new SessionUniqueAddMetaDataMessage();
/* 430 */       break;
/*     */     case 12: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 36: case 37: 
/*     */     case 38: case 47: case 48: case 71: case 72: case 75: case 76: case 83: case 84: case 85: case 86: case 87: case 88: case 89: case 90: case 91: 
/*     */     case 92: case 93: case 94: case 95: case 96: case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 107: case 108: case 109: default: 
/* 434 */       throw HornetQClientMessageBundle.BUNDLE.invalidType(Byte.valueOf(packetType));
/*     */     }
/*     */     
/*     */     
/* 438 */     return packet;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\PacketDecoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */