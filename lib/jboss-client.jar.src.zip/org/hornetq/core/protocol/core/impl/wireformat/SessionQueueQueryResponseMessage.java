/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ import org.hornetq.core.server.QueueQueryResult;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionQueueQueryResponseMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private SimpleString name;
/*     */   private boolean exists;
/*     */   private boolean durable;
/*     */   private int consumerCount;
/*     */   private long messageCount;
/*     */   private SimpleString filterString;
/*     */   private SimpleString address;
/*     */   private boolean temporary;
/*     */   
/*     */   public SessionQueueQueryResponseMessage(QueueQueryResult result)
/*     */   {
/*  48 */     this(result.getName(), result.getAddress(), result.isDurable(), result.isTemporary(), result.getFilterString(), result.getConsumerCount(), result.getMessageCount(), result.isExists());
/*     */   }
/*     */   
/*     */ 
/*     */   public SessionQueueQueryResponseMessage()
/*     */   {
/*  54 */     this(null, null, false, false, null, 0, 0L, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SessionQueueQueryResponseMessage(SimpleString name, SimpleString address, boolean durable, boolean temporary, SimpleString filterString, int consumerCount, long messageCount, boolean exists)
/*     */   {
/*  66 */     super((byte)46);
/*     */     
/*  68 */     this.durable = durable;
/*     */     
/*  70 */     this.temporary = temporary;
/*     */     
/*  72 */     this.consumerCount = consumerCount;
/*     */     
/*  74 */     this.messageCount = messageCount;
/*     */     
/*  76 */     this.filterString = filterString;
/*     */     
/*  78 */     this.address = address;
/*     */     
/*  80 */     this.name = name;
/*     */     
/*  82 */     this.exists = exists;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isResponse()
/*     */   {
/*  88 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isExists()
/*     */   {
/*  93 */     return this.exists;
/*     */   }
/*     */   
/*     */   public boolean isDurable()
/*     */   {
/*  98 */     return this.durable;
/*     */   }
/*     */   
/*     */   public int getConsumerCount()
/*     */   {
/* 103 */     return this.consumerCount;
/*     */   }
/*     */   
/*     */   public long getMessageCount()
/*     */   {
/* 108 */     return this.messageCount;
/*     */   }
/*     */   
/*     */   public SimpleString getFilterString()
/*     */   {
/* 113 */     return this.filterString;
/*     */   }
/*     */   
/*     */   public SimpleString getAddress()
/*     */   {
/* 118 */     return this.address;
/*     */   }
/*     */   
/*     */   public SimpleString getName()
/*     */   {
/* 123 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean isTemporary()
/*     */   {
/* 128 */     return this.temporary;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/* 134 */     buffer.writeBoolean(this.exists);
/* 135 */     buffer.writeBoolean(this.durable);
/* 136 */     buffer.writeBoolean(this.temporary);
/* 137 */     buffer.writeInt(this.consumerCount);
/* 138 */     buffer.writeLong(this.messageCount);
/* 139 */     buffer.writeNullableSimpleString(this.filterString);
/* 140 */     buffer.writeNullableSimpleString(this.address);
/* 141 */     buffer.writeNullableSimpleString(this.name);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 147 */     this.exists = buffer.readBoolean();
/* 148 */     this.durable = buffer.readBoolean();
/* 149 */     this.temporary = buffer.readBoolean();
/* 150 */     this.consumerCount = buffer.readInt();
/* 151 */     this.messageCount = buffer.readLong();
/* 152 */     this.filterString = buffer.readNullableSimpleString();
/* 153 */     this.address = buffer.readNullableSimpleString();
/* 154 */     this.name = buffer.readNullableSimpleString();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 160 */     int prime = 31;
/* 161 */     int result = super.hashCode();
/* 162 */     result = 31 * result + (this.address == null ? 0 : this.address.hashCode());
/* 163 */     result = 31 * result + this.consumerCount;
/* 164 */     result = 31 * result + (this.durable ? 1231 : 1237);
/* 165 */     result = 31 * result + (this.exists ? 1231 : 1237);
/* 166 */     result = 31 * result + (this.filterString == null ? 0 : this.filterString.hashCode());
/* 167 */     result = 31 * result + (int)(this.messageCount ^ this.messageCount >>> 32);
/* 168 */     result = 31 * result + (this.name == null ? 0 : this.name.hashCode());
/* 169 */     result = 31 * result + (this.temporary ? 1231 : 1237);
/* 170 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 176 */     if (this == obj)
/* 177 */       return true;
/* 178 */     if (!super.equals(obj))
/* 179 */       return false;
/* 180 */     if (!(obj instanceof SessionQueueQueryResponseMessage))
/* 181 */       return false;
/* 182 */     SessionQueueQueryResponseMessage other = (SessionQueueQueryResponseMessage)obj;
/* 183 */     if (this.address == null)
/*     */     {
/* 185 */       if (other.address != null) {
/* 186 */         return false;
/*     */       }
/* 188 */     } else if (!this.address.equals(other.address))
/* 189 */       return false;
/* 190 */     if (this.consumerCount != other.consumerCount)
/* 191 */       return false;
/* 192 */     if (this.durable != other.durable)
/* 193 */       return false;
/* 194 */     if (this.exists != other.exists)
/* 195 */       return false;
/* 196 */     if (this.filterString == null)
/*     */     {
/* 198 */       if (other.filterString != null) {
/* 199 */         return false;
/*     */       }
/* 201 */     } else if (!this.filterString.equals(other.filterString))
/* 202 */       return false;
/* 203 */     if (this.messageCount != other.messageCount)
/* 204 */       return false;
/* 205 */     if (this.name == null)
/*     */     {
/* 207 */       if (other.name != null) {
/* 208 */         return false;
/*     */       }
/* 210 */     } else if (!this.name.equals(other.name))
/* 211 */       return false;
/* 212 */     if (this.temporary != other.temporary)
/* 213 */       return false;
/* 214 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionQueueQueryResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */