/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.message.impl.MessageInternal;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionReceiveLargeMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private final MessageInternal message;
/*     */   private long largeMessageSize;
/*     */   private long consumerID;
/*     */   private int deliveryCount;
/*     */   
/*     */   public SessionReceiveLargeMessage(MessageInternal message)
/*     */   {
/*  41 */     super((byte)76);
/*  42 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionReceiveLargeMessage(long consumerID, MessageInternal message, long largeMessageSize, int deliveryCount)
/*     */   {
/*  50 */     super((byte)76);
/*     */     
/*  52 */     this.consumerID = consumerID;
/*     */     
/*  54 */     this.message = message;
/*     */     
/*  56 */     this.deliveryCount = deliveryCount;
/*     */     
/*  58 */     this.largeMessageSize = largeMessageSize;
/*     */   }
/*     */   
/*     */   public MessageInternal getLargeMessage()
/*     */   {
/*  63 */     return this.message;
/*     */   }
/*     */   
/*     */   public long getConsumerID()
/*     */   {
/*  68 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public int getDeliveryCount()
/*     */   {
/*  73 */     return this.deliveryCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLargeMessageSize()
/*     */   {
/*  81 */     return this.largeMessageSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  87 */     buffer.writeLong(this.consumerID);
/*  88 */     buffer.writeInt(this.deliveryCount);
/*  89 */     buffer.writeLong(this.largeMessageSize);
/*  90 */     this.message.encodeHeadersAndProperties(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  96 */     this.consumerID = buffer.readLong();
/*  97 */     this.deliveryCount = buffer.readInt();
/*  98 */     this.largeMessageSize = buffer.readLong();
/*  99 */     this.message.decodeHeadersAndProperties(buffer);
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 105 */     int prime = 31;
/* 106 */     int result = super.hashCode();
/* 107 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/* 108 */     result = 31 * result + this.deliveryCount;
/* 109 */     result = 31 * result + (int)(this.largeMessageSize ^ this.largeMessageSize >>> 32);
/* 110 */     result = 31 * result + (this.message == null ? 0 : this.message.hashCode());
/* 111 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 117 */     if (this == obj)
/* 118 */       return true;
/* 119 */     if (!super.equals(obj))
/* 120 */       return false;
/* 121 */     if (!(obj instanceof SessionReceiveLargeMessage))
/* 122 */       return false;
/* 123 */     SessionReceiveLargeMessage other = (SessionReceiveLargeMessage)obj;
/* 124 */     if (this.consumerID != other.consumerID)
/* 125 */       return false;
/* 126 */     if (this.deliveryCount != other.deliveryCount)
/* 127 */       return false;
/* 128 */     if (this.largeMessageSize != other.largeMessageSize)
/* 129 */       return false;
/* 130 */     if (this.message == null)
/*     */     {
/* 132 */       if (other.message != null) {
/* 133 */         return false;
/*     */       }
/* 135 */     } else if (!this.message.equals(other.message))
/* 136 */       return false;
/* 137 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionReceiveLargeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */