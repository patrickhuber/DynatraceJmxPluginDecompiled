/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import javax.transaction.xa.Xid;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ import org.hornetq.utils.XidCodecSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionXAEndMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private Xid xid;
/*     */   private boolean failed;
/*     */   
/*     */   public SessionXAEndMessage(Xid xid, boolean failed)
/*     */   {
/*  33 */     super((byte)52);
/*     */     
/*  35 */     this.xid = xid;
/*     */     
/*  37 */     this.failed = failed;
/*     */   }
/*     */   
/*     */   public SessionXAEndMessage()
/*     */   {
/*  42 */     super((byte)52);
/*     */   }
/*     */   
/*     */   public boolean isFailed()
/*     */   {
/*  47 */     return this.failed;
/*     */   }
/*     */   
/*     */   public Xid getXid()
/*     */   {
/*  52 */     return this.xid;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  58 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*  59 */     buffer.writeBoolean(this.failed);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  65 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*  66 */     this.failed = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  72 */     return getParentString() + ", xid=" + this.xid + ", failed=" + this.failed + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  78 */     int prime = 31;
/*  79 */     int result = super.hashCode();
/*  80 */     result = 31 * result + (this.failed ? 1231 : 1237);
/*  81 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/*  82 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (this == obj)
/*  89 */       return true;
/*  90 */     if (!super.equals(obj))
/*  91 */       return false;
/*  92 */     if (!(obj instanceof SessionXAEndMessage))
/*  93 */       return false;
/*  94 */     SessionXAEndMessage other = (SessionXAEndMessage)obj;
/*  95 */     if (this.failed != other.failed)
/*  96 */       return false;
/*  97 */     if (this.xid == null)
/*     */     {
/*  99 */       if (other.xid != null) {
/* 100 */         return false;
/*     */       }
/* 102 */     } else if (!this.xid.equals(other.xid))
/* 103 */       return false;
/* 104 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAEndMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */