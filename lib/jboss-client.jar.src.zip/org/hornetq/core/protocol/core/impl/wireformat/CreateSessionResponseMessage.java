/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateSessionResponseMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private int serverVersion;
/*    */   
/*    */   public CreateSessionResponseMessage(int serverVersion)
/*    */   {
/* 30 */     super((byte)31);
/*    */     
/* 32 */     this.serverVersion = serverVersion;
/*    */   }
/*    */   
/*    */   public CreateSessionResponseMessage()
/*    */   {
/* 37 */     super((byte)31);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isResponse()
/*    */   {
/* 43 */     return true;
/*    */   }
/*    */   
/*    */   public int getServerVersion()
/*    */   {
/* 48 */     return this.serverVersion;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 54 */     buffer.writeInt(this.serverVersion);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 60 */     this.serverVersion = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */   public final boolean isRequiresConfirmations()
/*    */   {
/* 66 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int prime = 31;
/* 73 */     int result = super.hashCode();
/* 74 */     result = 31 * result + this.serverVersion;
/* 75 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 81 */     if (this == obj)
/* 82 */       return true;
/* 83 */     if (!super.equals(obj))
/* 84 */       return false;
/* 85 */     if (!(obj instanceof CreateSessionResponseMessage))
/* 86 */       return false;
/* 87 */     CreateSessionResponseMessage other = (CreateSessionResponseMessage)obj;
/* 88 */     if (this.serverVersion != other.serverVersion)
/* 89 */       return false;
/* 90 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\CreateSessionResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */