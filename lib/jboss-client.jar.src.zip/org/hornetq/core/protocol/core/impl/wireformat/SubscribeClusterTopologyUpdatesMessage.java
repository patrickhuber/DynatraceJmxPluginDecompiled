/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscribeClusterTopologyUpdatesMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private boolean clusterConnection;
/*     */   
/*     */   public SubscribeClusterTopologyUpdatesMessage(boolean clusterConnection)
/*     */   {
/*  30 */     super((byte)112);
/*     */     
/*  32 */     this.clusterConnection = clusterConnection;
/*     */   }
/*     */   
/*     */   protected SubscribeClusterTopologyUpdatesMessage(byte packetType, boolean clusterConnection)
/*     */   {
/*  37 */     super(packetType);
/*     */     
/*  39 */     this.clusterConnection = clusterConnection;
/*     */   }
/*     */   
/*     */   public SubscribeClusterTopologyUpdatesMessage()
/*     */   {
/*  44 */     super((byte)112);
/*     */   }
/*     */   
/*     */   protected SubscribeClusterTopologyUpdatesMessage(byte packetType)
/*     */   {
/*  49 */     super(packetType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isClusterConnection()
/*     */   {
/*  56 */     return this.clusterConnection;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  62 */     buffer.writeBoolean(this.clusterConnection);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  68 */     this.clusterConnection = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  74 */     return "SubscribeClusterTopologyUpdatesMessage [clusterConnection=" + this.clusterConnection + ", toString()=" + super.toString() + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  83 */     int prime = 31;
/*  84 */     int result = super.hashCode();
/*  85 */     result = 31 * result + (this.clusterConnection ? 1231 : 1237);
/*  86 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  92 */     if (this == obj)
/*  93 */       return true;
/*  94 */     if (!super.equals(obj))
/*  95 */       return false;
/*  96 */     if (!(obj instanceof SubscribeClusterTopologyUpdatesMessage))
/*  97 */       return false;
/*  98 */     SubscribeClusterTopologyUpdatesMessage other = (SubscribeClusterTopologyUpdatesMessage)obj;
/*  99 */     if (this.clusterConnection != other.clusterConnection)
/* 100 */       return false;
/* 101 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SubscribeClusterTopologyUpdatesMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */