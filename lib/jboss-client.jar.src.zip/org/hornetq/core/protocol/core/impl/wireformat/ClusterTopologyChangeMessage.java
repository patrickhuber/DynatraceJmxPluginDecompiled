/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.Pair;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusterTopologyChangeMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   protected boolean exit;
/*     */   protected String nodeID;
/*     */   protected Pair<TransportConfiguration, TransportConfiguration> pair;
/*     */   protected boolean last;
/*     */   
/*     */   public ClusterTopologyChangeMessage(String nodeID, Pair<TransportConfiguration, TransportConfiguration> pair, boolean last)
/*     */   {
/*  40 */     super((byte)110);
/*     */     
/*  42 */     this.nodeID = nodeID;
/*     */     
/*  44 */     this.pair = pair;
/*     */     
/*  46 */     this.last = last;
/*     */     
/*  48 */     this.exit = false;
/*     */   }
/*     */   
/*     */   public ClusterTopologyChangeMessage(String nodeID)
/*     */   {
/*  53 */     super((byte)110);
/*     */     
/*  55 */     this.exit = true;
/*     */     
/*  57 */     this.nodeID = nodeID;
/*     */   }
/*     */   
/*     */   public ClusterTopologyChangeMessage()
/*     */   {
/*  62 */     super((byte)110);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClusterTopologyChangeMessage(byte clusterTopologyV2)
/*     */   {
/*  72 */     super(clusterTopologyV2);
/*     */   }
/*     */   
/*     */   public String getNodeID()
/*     */   {
/*  77 */     return this.nodeID;
/*     */   }
/*     */   
/*     */   public Pair<TransportConfiguration, TransportConfiguration> getPair()
/*     */   {
/*  82 */     return this.pair;
/*     */   }
/*     */   
/*     */   public boolean isLast()
/*     */   {
/*  87 */     return this.last;
/*     */   }
/*     */   
/*     */   public boolean isExit()
/*     */   {
/*  92 */     return this.exit;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  98 */     buffer.writeBoolean(this.exit);
/*  99 */     buffer.writeString(this.nodeID);
/* 100 */     if (!this.exit)
/*     */     {
/* 102 */       if (this.pair.getA() != null)
/*     */       {
/* 104 */         buffer.writeBoolean(true);
/* 105 */         ((TransportConfiguration)this.pair.getA()).encode(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 109 */         buffer.writeBoolean(false);
/*     */       }
/* 111 */       if (this.pair.getB() != null)
/*     */       {
/* 113 */         buffer.writeBoolean(true);
/* 114 */         ((TransportConfiguration)this.pair.getB()).encode(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 118 */         buffer.writeBoolean(false);
/*     */       }
/* 120 */       buffer.writeBoolean(this.last);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 127 */     this.exit = buffer.readBoolean();
/* 128 */     this.nodeID = buffer.readString();
/* 129 */     if (!this.exit)
/*     */     {
/* 131 */       boolean hasLive = buffer.readBoolean();
/*     */       TransportConfiguration a;
/* 133 */       if (hasLive)
/*     */       {
/* 135 */         TransportConfiguration a = new TransportConfiguration();
/* 136 */         a.decode(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 140 */         a = null;
/*     */       }
/* 142 */       boolean hasBackup = buffer.readBoolean();
/*     */       TransportConfiguration b;
/* 144 */       if (hasBackup)
/*     */       {
/* 146 */         TransportConfiguration b = new TransportConfiguration();
/* 147 */         b.decode(buffer);
/*     */       }
/*     */       else
/*     */       {
/* 151 */         b = null;
/*     */       }
/* 153 */       this.pair = new Pair(a, b);
/* 154 */       this.last = buffer.readBoolean();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 161 */     int prime = 31;
/* 162 */     int result = super.hashCode();
/* 163 */     result = 31 * result + (this.exit ? 1231 : 1237);
/* 164 */     result = 31 * result + (this.last ? 1231 : 1237);
/* 165 */     result = 31 * result + (this.nodeID == null ? 0 : this.nodeID.hashCode());
/* 166 */     result = 31 * result + (this.pair == null ? 0 : this.pair.hashCode());
/* 167 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 173 */     if (this == obj)
/*     */     {
/* 175 */       return true;
/*     */     }
/* 177 */     if (!super.equals(obj))
/*     */     {
/* 179 */       return false;
/*     */     }
/* 181 */     if (!(obj instanceof ClusterTopologyChangeMessage))
/*     */     {
/* 183 */       return false;
/*     */     }
/* 185 */     ClusterTopologyChangeMessage other = (ClusterTopologyChangeMessage)obj;
/* 186 */     if (this.exit != other.exit)
/*     */     {
/* 188 */       return false;
/*     */     }
/* 190 */     if (this.last != other.last)
/*     */     {
/* 192 */       return false;
/*     */     }
/* 194 */     if (this.nodeID == null)
/*     */     {
/* 196 */       if (other.nodeID != null)
/*     */       {
/* 198 */         return false;
/*     */       }
/*     */     }
/* 201 */     else if (!this.nodeID.equals(other.nodeID))
/*     */     {
/* 203 */       return false;
/*     */     }
/* 205 */     if (this.pair == null)
/*     */     {
/* 207 */       if (other.pair != null)
/*     */       {
/* 209 */         return false;
/*     */       }
/*     */     }
/* 212 */     else if (!this.pair.equals(other.pair))
/*     */     {
/* 214 */       return false;
/*     */     }
/* 216 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\ClusterTopologyChangeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */