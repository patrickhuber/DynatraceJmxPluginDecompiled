/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeAnnounceMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private String nodeID;
/*     */   private String nodeName;
/*     */   private boolean backup;
/*     */   private long currentEventID;
/*     */   private TransportConfiguration connector;
/*     */   private TransportConfiguration backupConnector;
/*     */   
/*     */   public NodeAnnounceMessage(long currentEventID, String nodeID, String nodeName, boolean backup, TransportConfiguration tc, TransportConfiguration backupConnector)
/*     */   {
/*  44 */     super((byte)111);
/*     */     
/*  46 */     this.currentEventID = currentEventID;
/*     */     
/*  48 */     this.nodeID = nodeID;
/*     */     
/*  50 */     this.nodeName = nodeName;
/*     */     
/*  52 */     this.backup = backup;
/*     */     
/*  54 */     this.connector = tc;
/*     */     
/*  56 */     this.backupConnector = backupConnector;
/*     */   }
/*     */   
/*     */   public NodeAnnounceMessage()
/*     */   {
/*  61 */     super((byte)111);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getNodeID()
/*     */   {
/*  69 */     return this.nodeID;
/*     */   }
/*     */   
/*     */   public String getNodeName()
/*     */   {
/*  74 */     return this.nodeName;
/*     */   }
/*     */   
/*     */   public boolean isBackup()
/*     */   {
/*  79 */     return this.backup;
/*     */   }
/*     */   
/*     */   public TransportConfiguration getConnector()
/*     */   {
/*  84 */     return this.connector;
/*     */   }
/*     */   
/*     */   public TransportConfiguration getBackupConnector()
/*     */   {
/*  89 */     return this.backupConnector;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCurrentEventID()
/*     */   {
/*  97 */     return this.currentEventID;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/* 103 */     buffer.writeString(this.nodeID);
/* 104 */     buffer.writeNullableString(this.nodeName);
/* 105 */     buffer.writeBoolean(this.backup);
/* 106 */     buffer.writeLong(this.currentEventID);
/* 107 */     if (this.connector != null)
/*     */     {
/* 109 */       buffer.writeBoolean(true);
/* 110 */       this.connector.encode(buffer);
/*     */     }
/*     */     else
/*     */     {
/* 114 */       buffer.writeBoolean(false);
/*     */     }
/* 116 */     if (this.backupConnector != null)
/*     */     {
/* 118 */       buffer.writeBoolean(true);
/* 119 */       this.backupConnector.encode(buffer);
/*     */     }
/*     */     else
/*     */     {
/* 123 */       buffer.writeBoolean(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 130 */     this.nodeID = buffer.readString();
/* 131 */     this.nodeName = buffer.readNullableString();
/* 132 */     this.backup = buffer.readBoolean();
/* 133 */     this.currentEventID = buffer.readLong();
/* 134 */     if (buffer.readBoolean())
/*     */     {
/* 136 */       this.connector = new TransportConfiguration();
/* 137 */       this.connector.decode(buffer);
/*     */     }
/* 139 */     if (buffer.readBoolean())
/*     */     {
/* 141 */       this.backupConnector = new TransportConfiguration();
/* 142 */       this.backupConnector.decode(buffer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 149 */     return "NodeAnnounceMessage [backup=" + this.backup + ", connector=" + this.connector + ", nodeID=" + this.nodeID + ", toString()=" + super.toString() + "]";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 162 */     int prime = 31;
/* 163 */     int result = super.hashCode();
/* 164 */     result = 31 * result + (this.backup ? 1231 : 1237);
/* 165 */     result = 31 * result + (this.backupConnector == null ? 0 : this.backupConnector.hashCode());
/* 166 */     result = 31 * result + (this.connector == null ? 0 : this.connector.hashCode());
/* 167 */     result = 31 * result + (int)(this.currentEventID ^ this.currentEventID >>> 32);
/* 168 */     result = 31 * result + (this.nodeID == null ? 0 : this.nodeID.hashCode());
/* 169 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 175 */     if (this == obj)
/*     */     {
/* 177 */       return true;
/*     */     }
/* 179 */     if (!super.equals(obj))
/*     */     {
/* 181 */       return false;
/*     */     }
/* 183 */     if (!(obj instanceof NodeAnnounceMessage))
/*     */     {
/* 185 */       return false;
/*     */     }
/* 187 */     NodeAnnounceMessage other = (NodeAnnounceMessage)obj;
/* 188 */     if (this.backup != other.backup)
/*     */     {
/* 190 */       return false;
/*     */     }
/* 192 */     if (this.backupConnector == null)
/*     */     {
/* 194 */       if (other.backupConnector != null)
/*     */       {
/* 196 */         return false;
/*     */       }
/*     */     }
/* 199 */     else if (!this.backupConnector.equals(other.backupConnector))
/*     */     {
/* 201 */       return false;
/*     */     }
/* 203 */     if (this.connector == null)
/*     */     {
/* 205 */       if (other.connector != null)
/*     */       {
/* 207 */         return false;
/*     */       }
/*     */     }
/* 210 */     else if (!this.connector.equals(other.connector))
/*     */     {
/* 212 */       return false;
/*     */     }
/* 214 */     if (this.currentEventID != other.currentEventID)
/*     */     {
/* 216 */       return false;
/*     */     }
/* 218 */     if (this.nodeID == null)
/*     */     {
/* 220 */       if (other.nodeID != null)
/*     */       {
/* 222 */         return false;
/*     */       }
/*     */     }
/* 225 */     else if (!this.nodeID.equals(other.nodeID))
/*     */     {
/* 227 */       return false;
/*     */     }
/* 229 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\NodeAnnounceMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */