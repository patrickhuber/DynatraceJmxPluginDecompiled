/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReattachSessionResponseMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private int lastConfirmedCommandID;
/*     */   private boolean reattached;
/*     */   
/*     */   public ReattachSessionResponseMessage(int lastConfirmedCommandID, boolean reattached)
/*     */   {
/*  34 */     super((byte)33);
/*     */     
/*  36 */     this.lastConfirmedCommandID = lastConfirmedCommandID;
/*     */     
/*  38 */     this.reattached = reattached;
/*     */   }
/*     */   
/*     */   public ReattachSessionResponseMessage()
/*     */   {
/*  43 */     super((byte)33);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLastConfirmedCommandID()
/*     */   {
/*  50 */     return this.lastConfirmedCommandID;
/*     */   }
/*     */   
/*     */   public boolean isReattached()
/*     */   {
/*  55 */     return this.reattached;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  61 */     buffer.writeInt(this.lastConfirmedCommandID);
/*  62 */     buffer.writeBoolean(this.reattached);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  68 */     this.lastConfirmedCommandID = buffer.readInt();
/*  69 */     this.reattached = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isResponse()
/*     */   {
/*  75 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/*  81 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  87 */     int prime = 31;
/*  88 */     int result = super.hashCode();
/*  89 */     result = 31 * result + this.lastConfirmedCommandID;
/*  90 */     result = 31 * result + (this.reattached ? 1231 : 1237);
/*  91 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  97 */     if (this == obj)
/*  98 */       return true;
/*  99 */     if (!super.equals(obj))
/* 100 */       return false;
/* 101 */     if (!(obj instanceof ReattachSessionResponseMessage))
/* 102 */       return false;
/* 103 */     ReattachSessionResponseMessage other = (ReattachSessionResponseMessage)obj;
/* 104 */     if (this.lastConfirmedCommandID != other.lastConfirmedCommandID)
/* 105 */       return false;
/* 106 */     if (this.reattached != other.reattached)
/* 107 */       return false;
/* 108 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\ReattachSessionResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */