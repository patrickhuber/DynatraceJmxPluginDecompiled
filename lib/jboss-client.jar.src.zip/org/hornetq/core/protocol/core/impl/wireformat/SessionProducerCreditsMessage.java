/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.api.core.SimpleString;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionProducerCreditsMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private int credits;
/*    */   private SimpleString address;
/*    */   
/*    */   public SessionProducerCreditsMessage(int credits, SimpleString address)
/*    */   {
/* 32 */     super((byte)80);
/*    */     
/* 34 */     this.credits = credits;
/*    */     
/* 36 */     this.address = address;
/*    */   }
/*    */   
/*    */   public SessionProducerCreditsMessage()
/*    */   {
/* 41 */     super((byte)80);
/*    */   }
/*    */   
/*    */   public int getCredits()
/*    */   {
/* 46 */     return this.credits;
/*    */   }
/*    */   
/*    */   public SimpleString getAddress()
/*    */   {
/* 51 */     return this.address;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 57 */     buffer.writeInt(this.credits);
/* 58 */     buffer.writeSimpleString(this.address);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 64 */     this.credits = buffer.readInt();
/* 65 */     this.address = buffer.readSimpleString();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 71 */     int prime = 31;
/* 72 */     int result = super.hashCode();
/* 73 */     result = 31 * result + (this.address == null ? 0 : this.address.hashCode());
/* 74 */     result = 31 * result + this.credits;
/* 75 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 81 */     if (this == obj)
/* 82 */       return true;
/* 83 */     if (!super.equals(obj))
/* 84 */       return false;
/* 85 */     if (!(obj instanceof SessionProducerCreditsMessage))
/* 86 */       return false;
/* 87 */     SessionProducerCreditsMessage other = (SessionProducerCreditsMessage)obj;
/* 88 */     if (this.address == null)
/*    */     {
/* 90 */       if (other.address != null) {
/* 91 */         return false;
/*    */       }
/* 93 */     } else if (!this.address.equals(other.address))
/* 94 */       return false;
/* 95 */     if (this.credits != other.credits)
/* 96 */       return false;
/* 97 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionProducerCreditsMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */