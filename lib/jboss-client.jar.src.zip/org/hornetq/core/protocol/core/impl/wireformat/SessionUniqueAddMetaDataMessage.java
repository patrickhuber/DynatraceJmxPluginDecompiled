/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionUniqueAddMetaDataMessage
/*    */   extends SessionAddMetaDataMessageV2
/*    */ {
/*    */   public SessionUniqueAddMetaDataMessage()
/*    */   {
/* 37 */     super((byte)106);
/*    */   }
/*    */   
/*    */ 
/*    */   public SessionUniqueAddMetaDataMessage(String key, String data)
/*    */   {
/* 43 */     super((byte)106, key, data);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionUniqueAddMetaDataMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */