/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionAcknowledgeMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private long consumerID;
/*     */   private long messageID;
/*     */   private boolean requiresResponse;
/*     */   
/*     */   public SessionAcknowledgeMessage(long consumerID, long messageID, boolean requiresResponse)
/*     */   {
/*  32 */     super((byte)41);
/*     */     
/*  34 */     this.consumerID = consumerID;
/*     */     
/*  36 */     this.messageID = messageID;
/*     */     
/*  38 */     this.requiresResponse = requiresResponse;
/*     */   }
/*     */   
/*     */   public SessionAcknowledgeMessage()
/*     */   {
/*  43 */     super((byte)41);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getConsumerID()
/*     */   {
/*  50 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public long getMessageID()
/*     */   {
/*  55 */     return this.messageID;
/*     */   }
/*     */   
/*     */   public boolean isRequiresResponse()
/*     */   {
/*  60 */     return this.requiresResponse;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  66 */     buffer.writeLong(this.consumerID);
/*     */     
/*  68 */     buffer.writeLong(this.messageID);
/*     */     
/*  70 */     buffer.writeBoolean(this.requiresResponse);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  76 */     this.consumerID = buffer.readLong();
/*     */     
/*  78 */     this.messageID = buffer.readLong();
/*     */     
/*  80 */     this.requiresResponse = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  86 */     int prime = 31;
/*  87 */     int result = super.hashCode();
/*  88 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/*  89 */     result = 31 * result + (int)(this.messageID ^ this.messageID >>> 32);
/*  90 */     result = 31 * result + (this.requiresResponse ? 1231 : 1237);
/*  91 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  97 */     if (this == obj)
/*  98 */       return true;
/*  99 */     if (!super.equals(obj))
/* 100 */       return false;
/* 101 */     if (!(obj instanceof SessionAcknowledgeMessage))
/* 102 */       return false;
/* 103 */     SessionAcknowledgeMessage other = (SessionAcknowledgeMessage)obj;
/* 104 */     if (this.consumerID != other.consumerID)
/* 105 */       return false;
/* 106 */     if (this.messageID != other.messageID)
/* 107 */       return false;
/* 108 */     if (this.requiresResponse != other.requiresResponse)
/* 109 */       return false;
/* 110 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionAcknowledgeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */