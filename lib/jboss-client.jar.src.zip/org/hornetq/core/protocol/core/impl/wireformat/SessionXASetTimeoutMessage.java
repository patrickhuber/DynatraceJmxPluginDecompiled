/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXASetTimeoutMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private int timeoutSeconds;
/*    */   
/*    */   public SessionXASetTimeoutMessage(int timeoutSeconds)
/*    */   {
/* 29 */     super((byte)63);
/*    */     
/* 31 */     this.timeoutSeconds = timeoutSeconds;
/*    */   }
/*    */   
/*    */   public SessionXASetTimeoutMessage()
/*    */   {
/* 36 */     super((byte)63);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getTimeoutSeconds()
/*    */   {
/* 43 */     return this.timeoutSeconds;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 49 */     buffer.writeInt(this.timeoutSeconds);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 55 */     this.timeoutSeconds = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 61 */     int prime = 31;
/* 62 */     int result = super.hashCode();
/* 63 */     result = 31 * result + this.timeoutSeconds;
/* 64 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 70 */     if (this == obj)
/* 71 */       return true;
/* 72 */     if (!super.equals(obj))
/* 73 */       return false;
/* 74 */     if (!(obj instanceof SessionXASetTimeoutMessage))
/* 75 */       return false;
/* 76 */     SessionXASetTimeoutMessage other = (SessionXASetTimeoutMessage)obj;
/* 77 */     if (this.timeoutSeconds != other.timeoutSeconds)
/* 78 */       return false;
/* 79 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXASetTimeoutMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */