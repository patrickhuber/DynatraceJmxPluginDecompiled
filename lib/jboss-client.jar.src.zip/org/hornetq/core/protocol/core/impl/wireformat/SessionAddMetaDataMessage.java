/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionAddMetaDataMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private String key;
/*     */   private String data;
/*     */   
/*     */   public SessionAddMetaDataMessage()
/*     */   {
/*  35 */     super((byte)104);
/*     */   }
/*     */   
/*     */   public SessionAddMetaDataMessage(String k, String d)
/*     */   {
/*  40 */     this();
/*  41 */     this.key = k;
/*  42 */     this.data = d;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  48 */     buffer.writeString(this.key);
/*  49 */     buffer.writeString(this.data);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  55 */     this.key = buffer.readString();
/*  56 */     this.data = buffer.readString();
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/*  62 */     return false;
/*     */   }
/*     */   
/*     */   public String getKey()
/*     */   {
/*  67 */     return this.key;
/*     */   }
/*     */   
/*     */   public String getData()
/*     */   {
/*  72 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  78 */     int prime = 31;
/*  79 */     int result = super.hashCode();
/*  80 */     result = 31 * result + (this.data == null ? 0 : this.data.hashCode());
/*  81 */     result = 31 * result + (this.key == null ? 0 : this.key.hashCode());
/*  82 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (this == obj)
/*  89 */       return true;
/*  90 */     if (!super.equals(obj))
/*  91 */       return false;
/*  92 */     if (!(obj instanceof SessionAddMetaDataMessage))
/*  93 */       return false;
/*  94 */     SessionAddMetaDataMessage other = (SessionAddMetaDataMessage)obj;
/*  95 */     if (this.data == null)
/*     */     {
/*  97 */       if (other.data != null) {
/*  98 */         return false;
/*     */       }
/* 100 */     } else if (!this.data.equals(other.data))
/* 101 */       return false;
/* 102 */     if (this.key == null)
/*     */     {
/* 104 */       if (other.key != null) {
/* 105 */         return false;
/*     */       }
/* 107 */     } else if (!this.key.equals(other.key))
/* 108 */       return false;
/* 109 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionAddMetaDataMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */