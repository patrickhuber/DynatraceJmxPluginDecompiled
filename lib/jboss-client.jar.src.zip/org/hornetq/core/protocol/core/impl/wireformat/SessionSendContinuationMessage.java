/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.message.impl.MessageInternal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionSendContinuationMessage
/*     */   extends SessionContinuationMessage
/*     */ {
/*     */   private boolean requiresResponse;
/*     */   private MessageInternal message;
/*  40 */   private long messageBodySize = -1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionSendContinuationMessage()
/*     */   {
/*  48 */     super((byte)73);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionSendContinuationMessage(MessageInternal message, byte[] body, boolean continues, boolean requiresResponse)
/*     */   {
/*  58 */     super((byte)73, body, continues);
/*  59 */     this.requiresResponse = requiresResponse;
/*  60 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SessionSendContinuationMessage(MessageInternal message, byte[] body, boolean continues, boolean requiresResponse, long messageBodySize)
/*     */   {
/*  70 */     this(message, body, continues, requiresResponse);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isRequiresResponse()
/*     */   {
/*  81 */     return this.requiresResponse;
/*     */   }
/*     */   
/*     */   public long getMessageBodySize()
/*     */   {
/*  86 */     return this.messageBodySize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageInternal getMessage()
/*     */   {
/*  95 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/* 101 */     super.encodeRest(buffer);
/* 102 */     if (!this.continues)
/*     */     {
/* 104 */       buffer.writeLong(this.messageBodySize);
/*     */     }
/* 106 */     buffer.writeBoolean(this.requiresResponse);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 112 */     super.decodeRest(buffer);
/* 113 */     if (!this.continues)
/*     */     {
/* 115 */       this.messageBodySize = buffer.readLong();
/*     */     }
/* 117 */     this.requiresResponse = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 123 */     int prime = 31;
/* 124 */     int result = super.hashCode();
/* 125 */     result = 31 * result + (this.message == null ? 0 : this.message.hashCode());
/* 126 */     result = 31 * result + (int)(this.messageBodySize ^ this.messageBodySize >>> 32);
/* 127 */     result = 31 * result + (this.requiresResponse ? 1231 : 1237);
/* 128 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 134 */     if (this == obj)
/* 135 */       return true;
/* 136 */     if (!super.equals(obj))
/* 137 */       return false;
/* 138 */     if (!(obj instanceof SessionSendContinuationMessage))
/* 139 */       return false;
/* 140 */     SessionSendContinuationMessage other = (SessionSendContinuationMessage)obj;
/* 141 */     if (this.message == null)
/*     */     {
/* 143 */       if (other.message != null) {
/* 144 */         return false;
/*     */       }
/* 146 */     } else if (!this.message.equals(other.message))
/* 147 */       return false;
/* 148 */     if (this.messageBodySize != other.messageBodySize)
/* 149 */       return false;
/* 150 */     if (this.requiresResponse != other.requiresResponse)
/* 151 */       return false;
/* 152 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionSendContinuationMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */