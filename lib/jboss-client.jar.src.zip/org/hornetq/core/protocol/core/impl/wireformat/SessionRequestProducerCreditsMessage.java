/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionRequestProducerCreditsMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private int credits;
/*     */   private SimpleString address;
/*     */   
/*     */   public SessionRequestProducerCreditsMessage(int credits, SimpleString address)
/*     */   {
/*  32 */     super((byte)79);
/*     */     
/*  34 */     this.credits = credits;
/*     */     
/*  36 */     this.address = address;
/*     */   }
/*     */   
/*     */   public SessionRequestProducerCreditsMessage()
/*     */   {
/*  41 */     super((byte)79);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getCredits()
/*     */   {
/*  48 */     return this.credits;
/*     */   }
/*     */   
/*     */   public SimpleString getAddress()
/*     */   {
/*  53 */     return this.address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  64 */     buffer.writeInt(this.credits);
/*  65 */     buffer.writeSimpleString(this.address);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  71 */     this.credits = buffer.readInt();
/*  72 */     this.address = buffer.readSimpleString();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  78 */     int prime = 31;
/*  79 */     int result = super.hashCode();
/*  80 */     result = 31 * result + (this.address == null ? 0 : this.address.hashCode());
/*  81 */     result = 31 * result + this.credits;
/*  82 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  88 */     if (this == obj)
/*  89 */       return true;
/*  90 */     if (!super.equals(obj))
/*  91 */       return false;
/*  92 */     if (!(obj instanceof SessionRequestProducerCreditsMessage))
/*  93 */       return false;
/*  94 */     SessionRequestProducerCreditsMessage other = (SessionRequestProducerCreditsMessage)obj;
/*  95 */     if (this.address == null)
/*     */     {
/*  97 */       if (other.address != null) {
/*  98 */         return false;
/*     */       }
/* 100 */     } else if (!this.address.equals(other.address))
/* 101 */       return false;
/* 102 */     if (this.credits != other.credits)
/* 103 */       return false;
/* 104 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionRequestProducerCreditsMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */