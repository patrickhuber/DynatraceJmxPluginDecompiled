/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionIndividualAcknowledgeMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private long consumerID;
/*     */   private long messageID;
/*     */   private boolean requiresResponse;
/*     */   
/*     */   public SessionIndividualAcknowledgeMessage(long consumerID, long messageID, boolean requiresResponse)
/*     */   {
/*  40 */     super((byte)81);
/*     */     
/*  42 */     this.consumerID = consumerID;
/*     */     
/*  44 */     this.messageID = messageID;
/*     */     
/*  46 */     this.requiresResponse = requiresResponse;
/*     */   }
/*     */   
/*     */   public SessionIndividualAcknowledgeMessage()
/*     */   {
/*  51 */     super((byte)81);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getConsumerID()
/*     */   {
/*  58 */     return this.consumerID;
/*     */   }
/*     */   
/*     */   public long getMessageID()
/*     */   {
/*  63 */     return this.messageID;
/*     */   }
/*     */   
/*     */   public boolean isRequiresResponse()
/*     */   {
/*  68 */     return this.requiresResponse;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  74 */     buffer.writeLong(this.consumerID);
/*     */     
/*  76 */     buffer.writeLong(this.messageID);
/*     */     
/*  78 */     buffer.writeBoolean(this.requiresResponse);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  84 */     this.consumerID = buffer.readLong();
/*     */     
/*  86 */     this.messageID = buffer.readLong();
/*     */     
/*  88 */     this.requiresResponse = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  94 */     int prime = 31;
/*  95 */     int result = super.hashCode();
/*  96 */     result = 31 * result + (int)(this.consumerID ^ this.consumerID >>> 32);
/*  97 */     result = 31 * result + (int)(this.messageID ^ this.messageID >>> 32);
/*  98 */     result = 31 * result + (this.requiresResponse ? 1231 : 1237);
/*  99 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 105 */     if (this == obj)
/* 106 */       return true;
/* 107 */     if (!super.equals(obj))
/* 108 */       return false;
/* 109 */     if (!(obj instanceof SessionIndividualAcknowledgeMessage))
/* 110 */       return false;
/* 111 */     SessionIndividualAcknowledgeMessage other = (SessionIndividualAcknowledgeMessage)obj;
/* 112 */     if (this.consumerID != other.consumerID)
/* 113 */       return false;
/* 114 */     if (this.messageID != other.messageID)
/* 115 */       return false;
/* 116 */     if (this.requiresResponse != other.requiresResponse)
/* 117 */       return false;
/* 118 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionIndividualAcknowledgeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */