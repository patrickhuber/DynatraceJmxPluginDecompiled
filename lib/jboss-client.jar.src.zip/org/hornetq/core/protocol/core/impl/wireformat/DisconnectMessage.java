/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisconnectMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private SimpleString nodeID;
/*     */   
/*     */   public DisconnectMessage(SimpleString nodeID)
/*     */   {
/*  34 */     super((byte)11);
/*     */     
/*  36 */     this.nodeID = nodeID;
/*     */   }
/*     */   
/*     */   public DisconnectMessage()
/*     */   {
/*  41 */     super((byte)11);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SimpleString getNodeID()
/*     */   {
/*  48 */     return this.nodeID;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  54 */     buffer.writeNullableSimpleString(this.nodeID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  60 */     this.nodeID = buffer.readNullableSimpleString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  66 */     StringBuffer buf = new StringBuffer(getParentString());
/*  67 */     buf.append(", nodeID=" + this.nodeID);
/*  68 */     buf.append("]");
/*  69 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/*  75 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  81 */     int prime = 31;
/*  82 */     int result = super.hashCode();
/*  83 */     result = 31 * result + (this.nodeID == null ? 0 : this.nodeID.hashCode());
/*  84 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  90 */     if (this == obj)
/*     */     {
/*  92 */       return true;
/*     */     }
/*  94 */     if (!super.equals(obj))
/*     */     {
/*  96 */       return false;
/*     */     }
/*  98 */     if (!(obj instanceof DisconnectMessage))
/*     */     {
/* 100 */       return false;
/*     */     }
/* 102 */     DisconnectMessage other = (DisconnectMessage)obj;
/* 103 */     if (this.nodeID == null)
/*     */     {
/* 105 */       if (other.nodeID != null)
/*     */       {
/* 107 */         return false;
/*     */       }
/*     */     }
/* 110 */     else if (!this.nodeID.equals(other.nodeID))
/*     */     {
/* 112 */       return false;
/*     */     }
/* 114 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\DisconnectMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */