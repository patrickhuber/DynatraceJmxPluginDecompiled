/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXASetTimeoutResponseMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private boolean ok;
/*    */   
/*    */   public SessionXASetTimeoutResponseMessage(boolean ok)
/*    */   {
/* 29 */     super((byte)64);
/*    */     
/* 31 */     this.ok = ok;
/*    */   }
/*    */   
/*    */   public SessionXASetTimeoutResponseMessage()
/*    */   {
/* 36 */     super((byte)64);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isResponse()
/*    */   {
/* 44 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isOK()
/*    */   {
/* 49 */     return this.ok;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 55 */     buffer.writeBoolean(this.ok);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 61 */     this.ok = buffer.readBoolean();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 67 */     int prime = 31;
/* 68 */     int result = super.hashCode();
/* 69 */     result = 31 * result + (this.ok ? 1231 : 1237);
/* 70 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 76 */     if (this == obj)
/* 77 */       return true;
/* 78 */     if (!super.equals(obj))
/* 79 */       return false;
/* 80 */     if (!(obj instanceof SessionXASetTimeoutResponseMessage))
/* 81 */       return false;
/* 82 */     SessionXASetTimeoutResponseMessage other = (SessionXASetTimeoutResponseMessage)obj;
/* 83 */     if (this.ok != other.ok)
/* 84 */       return false;
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXASetTimeoutResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */