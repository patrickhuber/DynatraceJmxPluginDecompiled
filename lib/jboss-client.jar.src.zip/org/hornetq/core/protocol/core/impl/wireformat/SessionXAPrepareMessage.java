/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAPrepareMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXAPrepareMessage(Xid xid)
/*    */   {
/* 33 */     super((byte)54);
/*    */     
/* 35 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXAPrepareMessage()
/*    */   {
/* 40 */     super((byte)54);
/*    */   }
/*    */   
/*    */ 
/*    */   public Xid getXid()
/*    */   {
/* 46 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 52 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 58 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isAsyncExec()
/*    */   {
/* 64 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 70 */     int prime = 31;
/* 71 */     int result = super.hashCode();
/* 72 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 73 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 79 */     if (this == obj)
/* 80 */       return true;
/* 81 */     if (!super.equals(obj))
/* 82 */       return false;
/* 83 */     if (!(obj instanceof SessionXAPrepareMessage))
/* 84 */       return false;
/* 85 */     SessionXAPrepareMessage other = (SessionXAPrepareMessage)obj;
/* 86 */     if (this.xid == null)
/*    */     {
/* 88 */       if (other.xid != null) {
/* 89 */         return false;
/*    */       }
/* 91 */     } else if (!this.xid.equals(other.xid))
/* 92 */       return false;
/* 93 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAPrepareMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */