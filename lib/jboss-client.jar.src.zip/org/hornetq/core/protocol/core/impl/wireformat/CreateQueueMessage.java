/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateQueueMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private SimpleString address;
/*     */   private SimpleString queueName;
/*     */   private SimpleString filterString;
/*     */   private boolean durable;
/*     */   private boolean temporary;
/*     */   private boolean requiresResponse;
/*     */   
/*     */   public CreateQueueMessage(SimpleString address, SimpleString queueName, SimpleString filterString, boolean durable, boolean temporary, boolean requiresResponse)
/*     */   {
/*  46 */     this();
/*     */     
/*  48 */     this.address = address;
/*  49 */     this.queueName = queueName;
/*  50 */     this.filterString = filterString;
/*  51 */     this.durable = durable;
/*  52 */     this.temporary = temporary;
/*  53 */     this.requiresResponse = requiresResponse;
/*     */   }
/*     */   
/*     */   public CreateQueueMessage()
/*     */   {
/*  58 */     super((byte)34);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  66 */     StringBuffer buff = new StringBuffer(getParentString());
/*  67 */     buff.append(", address=" + this.address);
/*  68 */     buff.append(", queueName=" + this.queueName);
/*  69 */     buff.append(", filterString=" + this.filterString);
/*  70 */     buff.append(", durable=" + this.durable);
/*  71 */     buff.append(", temporary=" + this.temporary);
/*  72 */     buff.append("]");
/*  73 */     return buff.toString();
/*     */   }
/*     */   
/*     */   public SimpleString getAddress()
/*     */   {
/*  78 */     return this.address;
/*     */   }
/*     */   
/*     */   public SimpleString getQueueName()
/*     */   {
/*  83 */     return this.queueName;
/*     */   }
/*     */   
/*     */   public SimpleString getFilterString()
/*     */   {
/*  88 */     return this.filterString;
/*     */   }
/*     */   
/*     */   public boolean isDurable()
/*     */   {
/*  93 */     return this.durable;
/*     */   }
/*     */   
/*     */   public boolean isTemporary()
/*     */   {
/*  98 */     return this.temporary;
/*     */   }
/*     */   
/*     */   public boolean isRequiresResponse()
/*     */   {
/* 103 */     return this.requiresResponse;
/*     */   }
/*     */   
/*     */   public void setAddress(SimpleString address)
/*     */   {
/* 108 */     this.address = address;
/*     */   }
/*     */   
/*     */   public void setQueueName(SimpleString queueName)
/*     */   {
/* 113 */     this.queueName = queueName;
/*     */   }
/*     */   
/*     */   public void setFilterString(SimpleString filterString)
/*     */   {
/* 118 */     this.filterString = filterString;
/*     */   }
/*     */   
/*     */   public void setDurable(boolean durable)
/*     */   {
/* 123 */     this.durable = durable;
/*     */   }
/*     */   
/*     */   public void setTemporary(boolean temporary)
/*     */   {
/* 128 */     this.temporary = temporary;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/* 134 */     buffer.writeSimpleString(this.address);
/* 135 */     buffer.writeSimpleString(this.queueName);
/* 136 */     buffer.writeNullableSimpleString(this.filterString);
/* 137 */     buffer.writeBoolean(this.durable);
/* 138 */     buffer.writeBoolean(this.temporary);
/* 139 */     buffer.writeBoolean(this.requiresResponse);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/* 145 */     this.address = buffer.readSimpleString();
/* 146 */     this.queueName = buffer.readSimpleString();
/* 147 */     this.filterString = buffer.readNullableSimpleString();
/* 148 */     this.durable = buffer.readBoolean();
/* 149 */     this.temporary = buffer.readBoolean();
/* 150 */     this.requiresResponse = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 156 */     int prime = 31;
/* 157 */     int result = super.hashCode();
/* 158 */     result = 31 * result + (this.address == null ? 0 : this.address.hashCode());
/* 159 */     result = 31 * result + (this.durable ? 1231 : 1237);
/* 160 */     result = 31 * result + (this.filterString == null ? 0 : this.filterString.hashCode());
/* 161 */     result = 31 * result + (this.queueName == null ? 0 : this.queueName.hashCode());
/* 162 */     result = 31 * result + (this.requiresResponse ? 1231 : 1237);
/* 163 */     result = 31 * result + (this.temporary ? 1231 : 1237);
/* 164 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 170 */     if (this == obj)
/* 171 */       return true;
/* 172 */     if (!super.equals(obj))
/* 173 */       return false;
/* 174 */     if (!(obj instanceof CreateQueueMessage))
/* 175 */       return false;
/* 176 */     CreateQueueMessage other = (CreateQueueMessage)obj;
/* 177 */     if (this.address == null)
/*     */     {
/* 179 */       if (other.address != null) {
/* 180 */         return false;
/*     */       }
/* 182 */     } else if (!this.address.equals(other.address))
/* 183 */       return false;
/* 184 */     if (this.durable != other.durable)
/* 185 */       return false;
/* 186 */     if (this.filterString == null)
/*     */     {
/* 188 */       if (other.filterString != null) {
/* 189 */         return false;
/*     */       }
/* 191 */     } else if (!this.filterString.equals(other.filterString))
/* 192 */       return false;
/* 193 */     if (this.queueName == null)
/*     */     {
/* 195 */       if (other.queueName != null) {
/* 196 */         return false;
/*     */       }
/* 198 */     } else if (!this.queueName.equals(other.queueName))
/* 199 */       return false;
/* 200 */     if (this.requiresResponse != other.requiresResponse)
/* 201 */       return false;
/* 202 */     if (this.temporary != other.temporary)
/* 203 */       return false;
/* 204 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\CreateQueueMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */