/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXARollbackMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXARollbackMessage(Xid xid)
/*    */   {
/* 32 */     super((byte)56);
/*    */     
/* 34 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXARollbackMessage()
/*    */   {
/* 39 */     super((byte)56);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Xid getXid()
/*    */   {
/* 46 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 53 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 59 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isAsyncExec()
/*    */   {
/* 65 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 71 */     int prime = 31;
/* 72 */     int result = super.hashCode();
/* 73 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 74 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 80 */     if (this == obj)
/* 81 */       return true;
/* 82 */     if (!super.equals(obj))
/* 83 */       return false;
/* 84 */     if (!(obj instanceof SessionXARollbackMessage))
/* 85 */       return false;
/* 86 */     SessionXARollbackMessage other = (SessionXARollbackMessage)obj;
/* 87 */     if (this.xid == null)
/*    */     {
/* 89 */       if (other.xid != null) {
/* 90 */         return false;
/*    */       }
/* 92 */     } else if (!this.xid.equals(other.xid))
/* 93 */       return false;
/* 94 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXARollbackMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */