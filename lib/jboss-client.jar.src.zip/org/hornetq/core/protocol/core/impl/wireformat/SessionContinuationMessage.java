/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SessionContinuationMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   public static final int SESSION_CONTINUATION_BASE_SIZE = 18;
/*     */   protected byte[] body;
/*     */   protected boolean continues;
/*     */   
/*     */   public SessionContinuationMessage(byte type, byte[] body, boolean continues)
/*     */   {
/*  43 */     super(type);
/*  44 */     this.body = body;
/*  45 */     this.continues = continues;
/*     */   }
/*     */   
/*     */   public SessionContinuationMessage(byte type)
/*     */   {
/*  50 */     super(type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBody()
/*     */   {
/*  60 */     if (this.size <= 0)
/*     */     {
/*  62 */       return new byte[0];
/*     */     }
/*     */     
/*     */ 
/*  66 */     return this.body;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isContinues()
/*     */   {
/*  75 */     return this.continues;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  81 */     buffer.writeInt(this.body.length);
/*  82 */     buffer.writeBytes(this.body);
/*  83 */     buffer.writeBoolean(this.continues);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  89 */     int size = buffer.readInt();
/*  90 */     this.body = new byte[size];
/*  91 */     buffer.readBytes(this.body);
/*  92 */     this.continues = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  98 */     int prime = 31;
/*  99 */     int result = super.hashCode();
/* 100 */     result = 31 * result + Arrays.hashCode(this.body);
/* 101 */     result = 31 * result + (this.continues ? 1231 : 1237);
/* 102 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 108 */     if (this == obj)
/* 109 */       return true;
/* 110 */     if (!super.equals(obj))
/* 111 */       return false;
/* 112 */     if (!(obj instanceof SessionContinuationMessage))
/* 113 */       return false;
/* 114 */     SessionContinuationMessage other = (SessionContinuationMessage)obj;
/* 115 */     if (!Arrays.equals(this.body, other.body))
/* 116 */       return false;
/* 117 */     if (this.continues != other.continues)
/* 118 */       return false;
/* 119 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionContinuationMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */