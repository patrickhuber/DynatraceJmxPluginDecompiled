/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.transaction.xa.Xid;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ import org.hornetq.utils.XidCodecSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionXAGetInDoubtXidsResponseMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private List<Xid> xids;
/*     */   
/*     */   public SessionXAGetInDoubtXidsResponseMessage(List<Xid> xids)
/*     */   {
/*  34 */     super((byte)62);
/*     */     
/*  36 */     this.xids = xids;
/*     */   }
/*     */   
/*     */   public SessionXAGetInDoubtXidsResponseMessage()
/*     */   {
/*  41 */     super((byte)62);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isResponse()
/*     */   {
/*  47 */     return true;
/*     */   }
/*     */   
/*     */   public List<Xid> getXids()
/*     */   {
/*  52 */     return this.xids;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  58 */     buffer.writeInt(this.xids.size());
/*     */     
/*  60 */     for (Xid xid : this.xids)
/*     */     {
/*  62 */       XidCodecSupport.encodeXid(xid, buffer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  69 */     int len = buffer.readInt();
/*  70 */     this.xids = new ArrayList(len);
/*  71 */     for (int i = 0; i < len; i++)
/*     */     {
/*  73 */       Xid xid = XidCodecSupport.decodeXid(buffer);
/*     */       
/*  75 */       this.xids.add(xid);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  82 */     int prime = 31;
/*  83 */     int result = super.hashCode();
/*  84 */     result = 31 * result + (this.xids == null ? 0 : this.xids.hashCode());
/*  85 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  91 */     if (this == obj)
/*  92 */       return true;
/*  93 */     if (!super.equals(obj))
/*  94 */       return false;
/*  95 */     if (!(obj instanceof SessionXAGetInDoubtXidsResponseMessage))
/*  96 */       return false;
/*  97 */     SessionXAGetInDoubtXidsResponseMessage other = (SessionXAGetInDoubtXidsResponseMessage)obj;
/*  98 */     if (this.xids == null)
/*     */     {
/* 100 */       if (other.xids != null) {
/* 101 */         return false;
/*     */       }
/* 103 */     } else if (!this.xids.equals(other.xids))
/* 104 */       return false;
/* 105 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAGetInDoubtXidsResponseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */