/*     */ package org.hornetq.core.protocol.core.impl;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.Packet;
/*     */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketImpl
/*     */   implements Packet
/*     */ {
/*     */   public static final int PACKET_HEADERS_SIZE = 13;
/*     */   private static final int INITIAL_PACKET_SIZE = 1500;
/*     */   protected long channelID;
/*     */   private final byte type;
/*  40 */   protected int size = -1;
/*     */   
/*     */ 
/*     */   public static final byte PING = 10;
/*     */   
/*     */ 
/*     */   public static final byte DISCONNECT = 11;
/*     */   
/*     */ 
/*     */   public static final byte EXCEPTION = 20;
/*     */   
/*     */ 
/*     */   public static final byte NULL_RESPONSE = 21;
/*     */   
/*     */ 
/*     */   public static final byte PACKETS_CONFIRMED = 22;
/*     */   
/*     */ 
/*     */   public static final byte CREATESESSION = 30;
/*     */   
/*     */ 
/*     */   public static final byte CREATESESSION_RESP = 31;
/*     */   
/*     */ 
/*     */   public static final byte REATTACH_SESSION = 32;
/*     */   
/*     */ 
/*     */   public static final byte REATTACH_SESSION_RESP = 33;
/*     */   
/*     */ 
/*     */   public static final byte CREATE_QUEUE = 34;
/*     */   
/*     */ 
/*     */   public static final byte DELETE_QUEUE = 35;
/*     */   
/*     */ 
/*     */   public static final byte SESS_XA_FAILED = 39;
/*     */   
/*     */ 
/*     */   public static final byte SESS_CREATECONSUMER = 40;
/*     */   
/*     */ 
/*     */   public static final byte SESS_ACKNOWLEDGE = 41;
/*     */   
/*     */ 
/*     */   public static final byte SESS_EXPIRED = 42;
/*     */   
/*     */ 
/*     */   public static final byte SESS_COMMIT = 43;
/*     */   
/*     */ 
/*     */   public static final byte SESS_ROLLBACK = 44;
/*     */   
/*     */ 
/*     */   public static final byte SESS_QUEUEQUERY = 45;
/*     */   
/*     */ 
/*     */   public static final byte SESS_QUEUEQUERY_RESP = 46;
/*     */   
/*     */   public static final byte SESS_BINDINGQUERY = 49;
/*     */   
/*     */   public static final byte SESS_BINDINGQUERY_RESP = 50;
/*     */   
/*     */   public static final byte SESS_XA_START = 51;
/*     */   
/*     */   public static final byte SESS_XA_END = 52;
/*     */   
/*     */   public static final byte SESS_XA_COMMIT = 53;
/*     */   
/*     */   public static final byte SESS_XA_PREPARE = 54;
/*     */   
/*     */   public static final byte SESS_XA_RESP = 55;
/*     */   
/*     */   public static final byte SESS_XA_ROLLBACK = 56;
/*     */   
/*     */   public static final byte SESS_XA_JOIN = 57;
/*     */   
/*     */   public static final byte SESS_XA_SUSPEND = 58;
/*     */   
/*     */   public static final byte SESS_XA_RESUME = 59;
/*     */   
/*     */   public static final byte SESS_XA_FORGET = 60;
/*     */   
/*     */   public static final byte SESS_XA_INDOUBT_XIDS = 61;
/*     */   
/*     */   public static final byte SESS_XA_INDOUBT_XIDS_RESP = 62;
/*     */   
/*     */   public static final byte SESS_XA_SET_TIMEOUT = 63;
/*     */   
/*     */   public static final byte SESS_XA_SET_TIMEOUT_RESP = 64;
/*     */   
/*     */   public static final byte SESS_XA_GET_TIMEOUT = 65;
/*     */   
/*     */   public static final byte SESS_XA_GET_TIMEOUT_RESP = 66;
/*     */   
/*     */   public static final byte SESS_START = 67;
/*     */   
/*     */   public static final byte SESS_STOP = 68;
/*     */   
/*     */   public static final byte SESS_CLOSE = 69;
/*     */   
/*     */   public static final byte SESS_FLOWTOKEN = 70;
/*     */   
/*     */   public static final byte SESS_SEND = 71;
/*     */   
/*     */   public static final byte SESS_SEND_LARGE = 72;
/*     */   
/*     */   public static final byte SESS_SEND_CONTINUATION = 73;
/*     */   
/*     */   public static final byte SESS_CONSUMER_CLOSE = 74;
/*     */   
/*     */   public static final byte SESS_RECEIVE_MSG = 75;
/*     */   
/*     */   public static final byte SESS_RECEIVE_LARGE_MSG = 76;
/*     */   
/*     */   public static final byte SESS_RECEIVE_CONTINUATION = 77;
/*     */   
/*     */   public static final byte SESS_FORCE_CONSUMER_DELIVERY = 78;
/*     */   
/*     */   public static final byte SESS_PRODUCER_REQUEST_CREDITS = 79;
/*     */   
/*     */   public static final byte SESS_PRODUCER_CREDITS = 80;
/*     */   
/*     */   public static final byte SESS_INDIVIDUAL_ACKNOWLEDGE = 81;
/*     */   
/*     */   public static final byte SESS_PRODUCER_FAIL_CREDITS = 82;
/*     */   
/*     */   public static final byte REPLICATION_RESPONSE = 90;
/*     */   
/*     */   public static final byte REPLICATION_APPEND = 91;
/*     */   
/*     */   public static final byte REPLICATION_APPEND_TX = 92;
/*     */   
/*     */   public static final byte REPLICATION_DELETE = 93;
/*     */   
/*     */   public static final byte REPLICATION_DELETE_TX = 94;
/*     */   
/*     */   public static final byte REPLICATION_PREPARE = 95;
/*     */   
/*     */   public static final byte REPLICATION_COMMIT_ROLLBACK = 96;
/*     */   
/*     */   public static final byte REPLICATION_PAGE_WRITE = 97;
/*     */   
/*     */   public static final byte REPLICATION_PAGE_EVENT = 98;
/*     */   
/*     */   public static final byte REPLICATION_LARGE_MESSAGE_BEGIN = 99;
/*     */   
/*     */   public static final byte REPLICATION_LARGE_MESSAGE_END = 100;
/*     */   
/*     */   public static final byte REPLICATION_LARGE_MESSAGE_WRITE = 101;
/*     */   
/*     */   public static final byte REPLICATION_SYNC_FILE = 103;
/*     */   
/*     */   public static final byte SESS_ADD_METADATA = 104;
/*     */   
/*     */   public static final byte SESS_ADD_METADATA2 = 105;
/*     */   
/*     */   public static final byte SESS_UNIQUE_ADD_METADATA = 106;
/*     */   
/*     */   public static final byte CLUSTER_TOPOLOGY = 110;
/*     */   
/*     */   public static final byte NODE_ANNOUNCE = 111;
/*     */   
/*     */   public static final byte SUBSCRIBE_TOPOLOGY = 112;
/*     */   
/*     */   public static final byte SUBSCRIBE_TOPOLOGY_V2 = 113;
/*     */   
/*     */   public static final byte CLUSTER_TOPOLOGY_V2 = 114;
/*     */   
/*     */   public static final byte BACKUP_REGISTRATION = 115;
/*     */   
/*     */   public static final byte BACKUP_REGISTRATION_FAILED = 116;
/*     */   
/*     */   public static final byte REPLICATION_START_FINISH_SYNC = 120;
/*     */   
/*     */   public static final byte REPLICATION_SCHEDULED_FAILOVER = 121;
/*     */   
/*     */ 
/*     */   public PacketImpl(byte type)
/*     */   {
/* 220 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte getType()
/*     */   {
/* 227 */     return this.type;
/*     */   }
/*     */   
/*     */   public long getChannelID()
/*     */   {
/* 232 */     return this.channelID;
/*     */   }
/*     */   
/*     */   public void setChannelID(long channelID)
/*     */   {
/* 237 */     this.channelID = channelID;
/*     */   }
/*     */   
/*     */   public HornetQBuffer encode(RemotingConnection connection)
/*     */   {
/* 242 */     HornetQBuffer buffer = connection.createBuffer(1500);
/*     */     
/*     */ 
/*     */ 
/* 246 */     buffer.writeInt(0);
/* 247 */     buffer.writeByte(this.type);
/* 248 */     buffer.writeLong(this.channelID);
/*     */     
/* 250 */     encodeRest(buffer);
/*     */     
/* 252 */     this.size = buffer.writerIndex();
/*     */     
/*     */ 
/* 255 */     int len = this.size - 4;
/*     */     
/* 257 */     buffer.setInt(0, len);
/*     */     
/* 259 */     return buffer;
/*     */   }
/*     */   
/*     */   public void decode(HornetQBuffer buffer)
/*     */   {
/* 264 */     this.channelID = buffer.readLong();
/*     */     
/* 266 */     decodeRest(buffer);
/*     */     
/* 268 */     this.size = buffer.readerIndex();
/*     */   }
/*     */   
/*     */   public int getPacketSize()
/*     */   {
/* 273 */     if (this.size == -1)
/*     */     {
/* 275 */       throw new IllegalStateException("Packet hasn't been encoded/decoded yet");
/*     */     }
/*     */     
/* 278 */     return this.size;
/*     */   }
/*     */   
/*     */   public boolean isResponse()
/*     */   {
/* 283 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer) {}
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer) {}
/*     */   
/*     */ 
/*     */   public boolean isRequiresConfirmations()
/*     */   {
/* 296 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isAsyncExec()
/*     */   {
/* 301 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 307 */     return getParentString() + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 313 */     int prime = 31;
/* 314 */     int result = 1;
/* 315 */     result = 31 * result + (int)(this.channelID ^ this.channelID >>> 32);
/* 316 */     result = 31 * result + this.size;
/* 317 */     result = 31 * result + this.type;
/* 318 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 324 */     if (this == obj)
/*     */     {
/* 326 */       return true;
/*     */     }
/* 328 */     if (!(obj instanceof PacketImpl))
/*     */     {
/* 330 */       return false;
/*     */     }
/* 332 */     PacketImpl other = (PacketImpl)obj;
/* 333 */     return (this.channelID == other.channelID) && (this.size == other.size) && (this.type != other.type);
/*     */   }
/*     */   
/*     */   protected String getParentString()
/*     */   {
/* 338 */     return "PACKET(" + getClass().getSimpleName() + ")[type=" + this.type + ", channelID=" + this.channelID + ", packetObject=" + getClass().getSimpleName();
/*     */   }
/*     */   
/*     */   private int stringEncodeSize(String str)
/*     */   {
/* 343 */     return 4 + str.length() * 2;
/*     */   }
/*     */   
/*     */   protected int nullableStringEncodeSize(String str)
/*     */   {
/* 348 */     return 1 + (str != null ? stringEncodeSize(str) : 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\PacketImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */