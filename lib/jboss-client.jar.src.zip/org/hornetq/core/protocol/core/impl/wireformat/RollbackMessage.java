/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RollbackMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private boolean considerLastMessageAsDelivered;
/*    */   
/*    */   public RollbackMessage()
/*    */   {
/* 28 */     super((byte)44);
/*    */   }
/*    */   
/*    */   public RollbackMessage(boolean considerLastMessageAsDelivered)
/*    */   {
/* 33 */     super((byte)44);
/*    */     
/* 35 */     this.considerLastMessageAsDelivered = considerLastMessageAsDelivered;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isConsiderLastMessageAsDelivered()
/*    */   {
/* 46 */     return this.considerLastMessageAsDelivered;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setConsiderLastMessageAsDelivered(boolean isLastMessageAsDelivered)
/*    */   {
/* 54 */     this.considerLastMessageAsDelivered = isLastMessageAsDelivered;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 60 */     buffer.writeBoolean(this.considerLastMessageAsDelivered);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 66 */     this.considerLastMessageAsDelivered = buffer.readBoolean();
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isAsyncExec()
/*    */   {
/* 72 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 78 */     int prime = 31;
/* 79 */     int result = super.hashCode();
/* 80 */     result = 31 * result + (this.considerLastMessageAsDelivered ? 1231 : 1237);
/* 81 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 87 */     if (this == obj)
/* 88 */       return true;
/* 89 */     if (!super.equals(obj))
/* 90 */       return false;
/* 91 */     if (!(obj instanceof RollbackMessage))
/* 92 */       return false;
/* 93 */     RollbackMessage other = (RollbackMessage)obj;
/* 94 */     if (this.considerLastMessageAsDelivered != other.considerLastMessageAsDelivered)
/* 95 */       return false;
/* 96 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\RollbackMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */