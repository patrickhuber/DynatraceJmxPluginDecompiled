/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscribeClusterTopologyUpdatesMessageV2
/*    */   extends SubscribeClusterTopologyUpdatesMessage
/*    */ {
/*    */   private int clientVersion;
/*    */   
/*    */   public SubscribeClusterTopologyUpdatesMessageV2(boolean clusterConnection, int clientVersion)
/*    */   {
/* 29 */     super((byte)113, clusterConnection);
/*    */     
/* 31 */     this.clientVersion = clientVersion;
/*    */   }
/*    */   
/*    */   public SubscribeClusterTopologyUpdatesMessageV2()
/*    */   {
/* 36 */     super((byte)113);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 46 */     super.encodeRest(buffer);
/* 47 */     buffer.writeInt(this.clientVersion);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getClientVersion()
/*    */   {
/* 55 */     return this.clientVersion;
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 61 */     super.decodeRest(buffer);
/* 62 */     this.clientVersion = buffer.readInt();
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 68 */     int prime = 31;
/* 69 */     int result = super.hashCode();
/* 70 */     result = 31 * result + this.clientVersion;
/* 71 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 77 */     if (this == obj)
/* 78 */       return true;
/* 79 */     if (!super.equals(obj))
/* 80 */       return false;
/* 81 */     if (!(obj instanceof SubscribeClusterTopologyUpdatesMessageV2))
/* 82 */       return false;
/* 83 */     SubscribeClusterTopologyUpdatesMessageV2 other = (SubscribeClusterTopologyUpdatesMessageV2)obj;
/* 84 */     if (this.clientVersion != other.clientVersion)
/* 85 */       return false;
/* 86 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SubscribeClusterTopologyUpdatesMessageV2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */