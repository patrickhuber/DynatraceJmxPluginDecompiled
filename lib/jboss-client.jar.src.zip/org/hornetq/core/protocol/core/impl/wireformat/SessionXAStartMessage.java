/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ import org.hornetq.utils.XidCodecSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionXAStartMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   private Xid xid;
/*    */   
/*    */   public SessionXAStartMessage(Xid xid)
/*    */   {
/* 40 */     super((byte)51);
/*    */     
/* 42 */     this.xid = xid;
/*    */   }
/*    */   
/*    */   public SessionXAStartMessage()
/*    */   {
/* 47 */     super((byte)51);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Xid getXid()
/*    */   {
/* 54 */     return this.xid;
/*    */   }
/*    */   
/*    */ 
/*    */   public void encodeRest(HornetQBuffer buffer)
/*    */   {
/* 60 */     XidCodecSupport.encodeXid(this.xid, buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 66 */     this.xid = XidCodecSupport.decodeXid(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 72 */     int prime = 31;
/* 73 */     int result = super.hashCode();
/* 74 */     result = 31 * result + (this.xid == null ? 0 : this.xid.hashCode());
/* 75 */     return result;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 81 */     if (this == obj)
/* 82 */       return true;
/* 83 */     if (!super.equals(obj))
/* 84 */       return false;
/* 85 */     if (!(obj instanceof SessionXAStartMessage))
/* 86 */       return false;
/* 87 */     SessionXAStartMessage other = (SessionXAStartMessage)obj;
/* 88 */     if (this.xid == null)
/*    */     {
/* 90 */       if (other.xid != null) {
/* 91 */         return false;
/*    */       }
/* 93 */     } else if (!this.xid.equals(other.xid))
/* 94 */       return false;
/* 95 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionXAStartMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */