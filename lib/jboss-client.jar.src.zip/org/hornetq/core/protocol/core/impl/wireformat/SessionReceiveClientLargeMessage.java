/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQBuffer;
/*    */ import org.hornetq.core.client.impl.ClientLargeMessageInternal;
/*    */ import org.hornetq.core.message.impl.MessageInternal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionReceiveClientLargeMessage
/*    */   extends SessionReceiveLargeMessage
/*    */ {
/*    */   public SessionReceiveClientLargeMessage(MessageInternal message)
/*    */   {
/* 36 */     super(message);
/*    */   }
/*    */   
/*    */ 
/*    */   public void decodeRest(HornetQBuffer buffer)
/*    */   {
/* 42 */     super.decodeRest(buffer);
/*    */     
/* 44 */     ((ClientLargeMessageInternal)getLargeMessage()).setLargeMessageSize(getLargeMessageSize());
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionReceiveClientLargeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */