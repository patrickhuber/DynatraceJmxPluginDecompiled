/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PacketsConfirmedMessage
/*     */   extends PacketImpl
/*     */ {
/*     */   private int commandID;
/*     */   
/*     */   public PacketsConfirmedMessage(int commandID)
/*     */   {
/*  33 */     super((byte)22);
/*     */     
/*  35 */     this.commandID = commandID;
/*     */   }
/*     */   
/*     */   public PacketsConfirmedMessage()
/*     */   {
/*  40 */     super((byte)22);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getCommandID()
/*     */   {
/*  47 */     return this.commandID;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  53 */     buffer.writeInt(this.commandID);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  59 */     this.commandID = buffer.readInt();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/*  66 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  72 */     return getParentString() + ", commandID=" + this.commandID + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  78 */     int prime = 31;
/*  79 */     int result = super.hashCode();
/*  80 */     result = 31 * result + this.commandID;
/*  81 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  87 */     if (this == obj)
/*     */     {
/*  89 */       return true;
/*     */     }
/*  91 */     if (!super.equals(obj))
/*     */     {
/*  93 */       return false;
/*     */     }
/*  95 */     if (!(obj instanceof PacketsConfirmedMessage))
/*     */     {
/*  97 */       return false;
/*     */     }
/*  99 */     PacketsConfirmedMessage other = (PacketsConfirmedMessage)obj;
/* 100 */     if (this.commandID != other.commandID)
/*     */     {
/* 102 */       return false;
/*     */     }
/* 104 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\PacketsConfirmedMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */