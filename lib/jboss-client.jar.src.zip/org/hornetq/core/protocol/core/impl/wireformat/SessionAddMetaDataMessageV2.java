/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionAddMetaDataMessageV2
/*     */   extends PacketImpl
/*     */ {
/*     */   private String key;
/*     */   private String data;
/*  35 */   private boolean requiresConfirmation = true;
/*     */   
/*     */   public SessionAddMetaDataMessageV2()
/*     */   {
/*  39 */     super((byte)105);
/*     */   }
/*     */   
/*     */   protected SessionAddMetaDataMessageV2(byte packetCode)
/*     */   {
/*  44 */     super(packetCode);
/*     */   }
/*     */   
/*     */   public SessionAddMetaDataMessageV2(String k, String d)
/*     */   {
/*  49 */     this();
/*  50 */     this.key = k;
/*  51 */     this.data = d;
/*     */   }
/*     */   
/*     */   protected SessionAddMetaDataMessageV2(byte packetCode, String k, String d)
/*     */   {
/*  56 */     super(packetCode);
/*  57 */     this.key = k;
/*  58 */     this.data = d;
/*     */   }
/*     */   
/*     */   public SessionAddMetaDataMessageV2(String k, String d, boolean requiresConfirmation)
/*     */   {
/*  63 */     this();
/*  64 */     this.key = k;
/*  65 */     this.data = d;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  72 */     buffer.writeString(this.key);
/*  73 */     buffer.writeString(this.data);
/*  74 */     buffer.writeBoolean(this.requiresConfirmation);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  80 */     this.key = buffer.readString();
/*  81 */     this.data = buffer.readString();
/*  82 */     this.requiresConfirmation = buffer.readBoolean();
/*     */   }
/*     */   
/*     */ 
/*     */   public final boolean isRequiresConfirmations()
/*     */   {
/*  88 */     return this.requiresConfirmation;
/*     */   }
/*     */   
/*     */   public String getKey()
/*     */   {
/*  93 */     return this.key;
/*     */   }
/*     */   
/*     */   public String getData()
/*     */   {
/*  98 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 104 */     int prime = 31;
/* 105 */     int result = super.hashCode();
/* 106 */     result = 31 * result + (this.data == null ? 0 : this.data.hashCode());
/* 107 */     result = 31 * result + (this.key == null ? 0 : this.key.hashCode());
/* 108 */     result = 31 * result + (this.requiresConfirmation ? 1231 : 1237);
/* 109 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 115 */     if (this == obj)
/* 116 */       return true;
/* 117 */     if (!super.equals(obj))
/* 118 */       return false;
/* 119 */     if (!(obj instanceof SessionAddMetaDataMessageV2))
/* 120 */       return false;
/* 121 */     SessionAddMetaDataMessageV2 other = (SessionAddMetaDataMessageV2)obj;
/* 122 */     if (this.data == null)
/*     */     {
/* 124 */       if (other.data != null) {
/* 125 */         return false;
/*     */       }
/* 127 */     } else if (!this.data.equals(other.data))
/* 128 */       return false;
/* 129 */     if (this.key == null)
/*     */     {
/* 131 */       if (other.key != null) {
/* 132 */         return false;
/*     */       }
/* 134 */     } else if (!this.key.equals(other.key))
/* 135 */       return false;
/* 136 */     if (this.requiresConfirmation != other.requiresConfirmation)
/* 137 */       return false;
/* 138 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionAddMetaDataMessageV2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */