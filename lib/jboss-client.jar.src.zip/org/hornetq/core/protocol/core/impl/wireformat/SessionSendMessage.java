/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.message.impl.MessageInternal;
/*     */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionSendMessage
/*     */   extends MessagePacket
/*     */ {
/*     */   private boolean requiresResponse;
/*     */   
/*     */   public SessionSendMessage(MessageInternal message, boolean requiresResponse)
/*     */   {
/*  32 */     super((byte)71, message);
/*     */     
/*  34 */     this.requiresResponse = requiresResponse;
/*     */   }
/*     */   
/*     */   public SessionSendMessage(MessageInternal message)
/*     */   {
/*  39 */     super((byte)71, message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRequiresResponse()
/*     */   {
/*  46 */     return this.requiresResponse;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HornetQBuffer encode(RemotingConnection connection)
/*     */   {
/*  56 */     HornetQBuffer buffer = this.message.getEncodedBuffer();
/*     */     
/*     */ 
/*  59 */     if (buffer.writerIndex() != this.message.getEndOfMessagePosition())
/*     */     {
/*  61 */       throw new IllegalStateException("Wrong encode position");
/*     */     }
/*     */     
/*  64 */     buffer.writeBoolean(this.requiresResponse);
/*     */     
/*  66 */     this.size = buffer.writerIndex();
/*     */     
/*     */ 
/*     */ 
/*  70 */     int len = this.size - 4;
/*  71 */     buffer.setInt(0, len);
/*  72 */     buffer.setByte(4, getType());
/*  73 */     buffer.setLong(5, this.channelID);
/*     */     
/*     */ 
/*  76 */     buffer.readerIndex(0);
/*     */     
/*  78 */     this.message.resetCopied();
/*     */     
/*  80 */     return buffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  88 */     this.message.decodeFromBuffer(buffer);
/*     */     
/*  90 */     int ri = buffer.readerIndex();
/*     */     
/*  92 */     this.requiresResponse = buffer.readBoolean();
/*     */     
/*  94 */     buffer.readerIndex(ri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 101 */     int prime = 31;
/* 102 */     int result = super.hashCode();
/* 103 */     result = 31 * result + (this.requiresResponse ? 1231 : 1237);
/* 104 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 110 */     if (this == obj)
/* 111 */       return true;
/* 112 */     if (!super.equals(obj))
/* 113 */       return false;
/* 114 */     if (!(obj instanceof SessionSendMessage))
/* 115 */       return false;
/* 116 */     SessionSendMessage other = (SessionSendMessage)obj;
/* 117 */     if (this.requiresResponse != other.requiresResponse)
/* 118 */       return false;
/* 119 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionSendMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */