/*     */ package org.hornetq.core.protocol.core.impl.wireformat;
/*     */ 
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Ping
/*     */   extends PacketImpl
/*     */ {
/*     */   private long connectionTTL;
/*     */   
/*     */   public Ping(long connectionTTL)
/*     */   {
/*  32 */     super((byte)10);
/*     */     
/*  34 */     this.connectionTTL = connectionTTL;
/*     */   }
/*     */   
/*     */   public Ping()
/*     */   {
/*  39 */     super((byte)10);
/*     */   }
/*     */   
/*     */   public long getConnectionTTL()
/*     */   {
/*  44 */     return this.connectionTTL;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encodeRest(HornetQBuffer buffer)
/*     */   {
/*  50 */     buffer.writeLong(this.connectionTTL);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decodeRest(HornetQBuffer buffer)
/*     */   {
/*  56 */     this.connectionTTL = buffer.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isRequiresConfirmations()
/*     */   {
/*  62 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/*  68 */     StringBuffer buf = new StringBuffer(getParentString());
/*  69 */     buf.append(", connectionTTL=" + this.connectionTTL);
/*  70 */     buf.append("]");
/*  71 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  77 */     int prime = 31;
/*  78 */     int result = super.hashCode();
/*  79 */     result = 31 * result + (int)(this.connectionTTL ^ this.connectionTTL >>> 32);
/*  80 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  86 */     if (this == obj)
/*     */     {
/*  88 */       return true;
/*     */     }
/*  90 */     if (!super.equals(obj))
/*     */     {
/*  92 */       return false;
/*     */     }
/*  94 */     if (!(obj instanceof Ping))
/*     */     {
/*  96 */       return false;
/*     */     }
/*  98 */     Ping other = (Ping)obj;
/*  99 */     if (this.connectionTTL != other.connectionTTL)
/*     */     {
/* 101 */       return false;
/*     */     }
/* 103 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\Ping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */