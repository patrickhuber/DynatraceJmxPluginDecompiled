/*    */ package org.hornetq.core.protocol.core.impl.wireformat;
/*    */ 
/*    */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionCloseMessage
/*    */   extends PacketImpl
/*    */ {
/*    */   public SessionCloseMessage()
/*    */   {
/* 27 */     super((byte)69);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 35 */     if (!(other instanceof SessionCloseMessage))
/*    */     {
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     return super.equals(other);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isAsyncExec()
/*    */   {
/* 53 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\protocol\core\impl\wireformat\SessionCloseMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */