/*      */ package org.hornetq.core.filter.impl;
/*      */ 
/*      */ import java.util.HashSet;
/*      */ import org.hornetq.api.core.SimpleString;
/*      */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Operator
/*      */ {
/*      */   int operation;
/*      */   Object oper1;
/*      */   Object oper2;
/*      */   Object oper3;
/*      */   private Object arg1;
/*      */   Object arg2;
/*      */   Object arg3;
/*      */   int class1;
/*      */   int class2;
/*      */   int class3;
/*   65 */   RegExp re = null;
/*      */   
/*      */ 
/*      */   public static final int EQUAL = 0;
/*      */   
/*      */   public static final int NOT = 1;
/*      */   
/*      */   public static final int AND = 2;
/*      */   
/*      */   public static final int OR = 3;
/*      */   
/*      */   public static final int GT = 4;
/*      */   
/*      */   public static final int GE = 5;
/*      */   
/*      */   public static final int LT = 6;
/*      */   
/*      */   public static final int LE = 7;
/*      */   
/*      */   public static final int DIFFERENT = 8;
/*      */   
/*      */   static final int ADD = 9;
/*      */   
/*      */   public static final int SUB = 10;
/*      */   
/*      */   public static final int NEG = 11;
/*      */   
/*      */   public static final int MUL = 12;
/*      */   
/*      */   public static final int DIV = 13;
/*      */   
/*      */   public static final int BETWEEN = 14;
/*      */   
/*      */   public static final int NOT_BETWEEN = 15;
/*      */   
/*      */   public static final int LIKE = 16;
/*      */   
/*      */   public static final int NOT_LIKE = 17;
/*      */   
/*      */   public static final int LIKE_ESCAPE = 18;
/*      */   
/*      */   public static final int NOT_LIKE_ESCAPE = 19;
/*      */   
/*      */   public static final int IS_NULL = 20;
/*      */   
/*      */   public static final int IS_NOT_NULL = 21;
/*      */   
/*      */   public static final int IN = 22;
/*      */   
/*      */   public static final int NOT_IN = 23;
/*      */   
/*      */   public static final int DOUBLE = 1;
/*      */   
/*      */   public static final int LONG = 2;
/*      */   
/*      */   public static final int BOOLEAN = 3;
/*      */   
/*      */   public static final int SIMPLE_STRING = 4;
/*      */   
/*      */ 
/*      */   public Operator(int operation, Object oper1, Object oper2, Object oper3)
/*      */   {
/*  127 */     this.operation = operation;
/*  128 */     this.oper1 = oper1;
/*  129 */     this.oper2 = oper2;
/*  130 */     this.oper3 = oper3;
/*      */   }
/*      */   
/*      */   public Operator(int operation, Object oper1, Object oper2)
/*      */   {
/*  135 */     this.operation = operation;
/*  136 */     this.oper1 = oper1;
/*  137 */     this.oper2 = oper2;
/*  138 */     this.oper3 = null;
/*      */   }
/*      */   
/*      */   public Operator(int operation, Object oper1)
/*      */   {
/*  143 */     this.operation = operation;
/*  144 */     this.oper1 = oper1;
/*  145 */     this.oper2 = null;
/*  146 */     this.oper3 = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  154 */     return print("");
/*      */   }
/*      */   
/*      */   public String print(String level)
/*      */   {
/*  159 */     String st = level + this.operation + ":" + operationString(this.operation) + "(\n";
/*      */     
/*  161 */     String nextLevel = level + "  ";
/*      */     
/*  163 */     if (this.oper1 == null)
/*      */     {
/*  165 */       st = st + nextLevel + "null\n";
/*      */     }
/*  167 */     else if ((this.oper1 instanceof Operator))
/*      */     {
/*  169 */       st = st + ((Operator)this.oper1).print(nextLevel);
/*      */     }
/*      */     else
/*      */     {
/*  173 */       st = st + nextLevel + this.oper1.toString() + "\n";
/*      */     }
/*      */     
/*  176 */     if (this.oper2 != null)
/*      */     {
/*  178 */       if ((this.oper2 instanceof Operator))
/*      */       {
/*  180 */         st = st + ((Operator)this.oper2).print(nextLevel);
/*      */       }
/*      */       else
/*      */       {
/*  184 */         st = st + nextLevel + this.oper2.toString() + "\n";
/*      */       }
/*      */     }
/*      */     
/*  188 */     if (this.oper3 != null)
/*      */     {
/*  190 */       if ((this.oper3 instanceof Operator))
/*      */       {
/*  192 */         st = st + ((Operator)this.oper3).print(nextLevel);
/*      */       }
/*      */       else
/*      */       {
/*  196 */         st = st + nextLevel + this.oper3.toString() + "\n";
/*      */       }
/*      */     }
/*      */     
/*  200 */     st = st + level + ")\n";
/*      */     
/*  202 */     return st;
/*      */   }
/*      */   
/*      */   Object is_null()
/*      */     throws Exception
/*      */   {
/*  208 */     computeArgument1();
/*  209 */     if (this.arg1 == null)
/*      */     {
/*  211 */       return Boolean.TRUE;
/*      */     }
/*      */     
/*      */ 
/*  215 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */ 
/*      */   Object is_not_null()
/*      */     throws Exception
/*      */   {
/*  222 */     computeArgument1();
/*  223 */     if (this.arg1 != null)
/*      */     {
/*  225 */       return Boolean.TRUE;
/*      */     }
/*      */     
/*      */ 
/*  229 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */ 
/*      */   Object equal()
/*      */     throws Exception
/*      */   {
/*  236 */     computeArgument1();
/*  237 */     if (this.arg1 == null)
/*      */     {
/*  239 */       return Boolean.FALSE;
/*      */     }
/*      */     
/*  242 */     switch (this.class1)
/*      */     {
/*      */     case 2: 
/*  245 */       computeArgument1();
/*  246 */       if (this.arg1 == null)
/*      */       {
/*  248 */         return null;
/*      */       }
/*  250 */       computeArgument2();
/*  251 */       if (this.arg2 == null)
/*      */       {
/*  253 */         return null;
/*      */       }
/*  255 */       if (this.class2 == 2)
/*      */       {
/*  257 */         return Boolean.valueOf(((Number)this.arg1).longValue() == ((Number)this.arg2).longValue());
/*      */       }
/*  259 */       if (this.class2 == 1)
/*      */       {
/*  261 */         return Boolean.valueOf(((Number)this.arg1).longValue() == ((Number)this.arg2).doubleValue());
/*      */       }
/*  263 */       return Boolean.FALSE;
/*      */     case 1: 
/*  265 */       computeArgument1();
/*  266 */       if (this.arg1 == null)
/*      */       {
/*  268 */         return null;
/*      */       }
/*  270 */       computeArgument2();
/*  271 */       if (this.arg2 == null)
/*      */       {
/*  273 */         return null;
/*      */       }
/*  275 */       if (this.class2 == 2)
/*      */       {
/*  277 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() == ((Number)this.arg2).longValue());
/*      */       }
/*  279 */       if (this.class2 == 1)
/*      */       {
/*  281 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() == ((Number)this.arg2).doubleValue());
/*      */       }
/*  283 */       return Boolean.FALSE;
/*      */     case 3: 
/*      */     case 4: 
/*  286 */       computeArgument2();
/*  287 */       if (this.arg2 == null)
/*      */       {
/*  289 */         return Boolean.FALSE;
/*      */       }
/*  291 */       if (this.class2 != this.class1)
/*      */       {
/*  293 */         throwBadObjectException(this.class1, this.class2);
/*      */       }
/*  295 */       return Boolean.valueOf(this.arg1.equals(this.arg2));
/*      */     }
/*  297 */     throwBadObjectException(this.class1);
/*  298 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   Object not()
/*      */     throws Exception
/*      */   {
/*  306 */     computeArgument1();
/*  307 */     if (this.arg1 == null)
/*      */     {
/*  309 */       return null;
/*      */     }
/*  311 */     if (this.class1 != 3)
/*      */     {
/*  313 */       throwBadObjectException(this.class1);
/*      */     }
/*  315 */     if (((Boolean)this.arg1).booleanValue())
/*      */     {
/*  317 */       return Boolean.FALSE;
/*      */     }
/*      */     
/*      */ 
/*  321 */     return Boolean.TRUE;
/*      */   }
/*      */   
/*      */ 
/*      */   Object and()
/*      */     throws Exception
/*      */   {
/*  328 */     computeArgument1();
/*  329 */     if (this.arg1 == null)
/*      */     {
/*  331 */       computeArgument2();
/*  332 */       if (this.arg2 == null)
/*      */       {
/*  334 */         return null;
/*      */       }
/*  336 */       if (this.class2 != 3)
/*      */       {
/*  338 */         throwBadObjectException(this.class2);
/*      */       }
/*  340 */       if (!((Boolean)this.arg2).booleanValue())
/*      */       {
/*  342 */         return Boolean.FALSE;
/*      */       }
/*  344 */       return null;
/*      */     }
/*      */     
/*  347 */     if (this.class1 == 3)
/*      */     {
/*  349 */       if (!((Boolean)this.arg1).booleanValue())
/*      */       {
/*  351 */         return Boolean.FALSE;
/*      */       }
/*  353 */       computeArgument2();
/*  354 */       if (this.arg2 == null)
/*      */       {
/*  356 */         return null;
/*      */       }
/*  358 */       if (this.class2 != 3)
/*      */       {
/*  360 */         throwBadObjectException(this.class2);
/*      */       }
/*  362 */       return this.arg2;
/*      */     }
/*      */     
/*  365 */     throwBadObjectException(this.class1);
/*  366 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object or()
/*      */     throws Exception
/*      */   {
/*  381 */     short falseCounter = 0;
/*      */     
/*  383 */     computeArgument1();
/*  384 */     if (this.arg1 != null)
/*      */     {
/*  386 */       if (this.class1 != 3)
/*      */       {
/*  388 */         throwBadObjectException(this.class1);
/*      */       }
/*  390 */       if (((Boolean)this.arg1).booleanValue())
/*      */       {
/*  392 */         return Boolean.TRUE;
/*      */       }
/*      */       
/*      */ 
/*  396 */       falseCounter = (short)(falseCounter + 1);
/*      */     }
/*      */     
/*      */ 
/*  400 */     computeArgument2();
/*  401 */     if (this.arg2 != null)
/*      */     {
/*  403 */       if (this.class2 != 3)
/*      */       {
/*  405 */         throwBadObjectException(this.class2);
/*      */       }
/*  407 */       if (((Boolean)this.arg2).booleanValue())
/*      */       {
/*  409 */         return Boolean.TRUE;
/*      */       }
/*      */       
/*      */ 
/*  413 */       falseCounter = (short)(falseCounter + 1);
/*      */     }
/*      */     
/*      */ 
/*  417 */     if (falseCounter == 2)
/*      */     {
/*  419 */       return Boolean.FALSE;
/*      */     }
/*      */     
/*  422 */     return null;
/*      */   }
/*      */   
/*      */   Object gt()
/*      */     throws Exception
/*      */   {
/*  428 */     computeArgument1();
/*  429 */     if (this.arg1 == null)
/*      */     {
/*  431 */       return null;
/*      */     }
/*      */     
/*  434 */     if (this.class1 == 2)
/*      */     {
/*  436 */       computeArgument2();
/*  437 */       if (this.arg2 == null)
/*      */       {
/*  439 */         return null;
/*      */       }
/*  441 */       if (this.class2 == 2)
/*      */       {
/*  443 */         return Boolean.valueOf(((Number)this.arg1).longValue() > ((Number)this.arg2).longValue());
/*      */       }
/*  445 */       if (this.class2 == 1)
/*      */       {
/*  447 */         return Boolean.valueOf(((Number)this.arg1).longValue() > ((Number)this.arg2).doubleValue());
/*      */       }
/*      */     }
/*  450 */     else if (this.class1 == 1)
/*      */     {
/*  452 */       computeArgument2();
/*  453 */       if (this.arg2 == null)
/*      */       {
/*  455 */         return null;
/*      */       }
/*  457 */       if (this.class2 == 2)
/*      */       {
/*  459 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() > ((Number)this.arg2).longValue());
/*      */       }
/*  461 */       if (this.class2 == 1)
/*      */       {
/*  463 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() > ((Number)this.arg2).doubleValue());
/*      */       }
/*  465 */       return Boolean.FALSE;
/*      */     }
/*  467 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   Object ge()
/*      */     throws Exception
/*      */   {
/*  473 */     computeArgument1();
/*  474 */     if (this.arg1 == null)
/*      */     {
/*  476 */       return null;
/*      */     }
/*      */     
/*  479 */     if (this.class1 == 2)
/*      */     {
/*  481 */       computeArgument2();
/*  482 */       if (this.arg2 == null)
/*      */       {
/*  484 */         return null;
/*      */       }
/*  486 */       if (this.class2 == 2)
/*      */       {
/*  488 */         return Boolean.valueOf(((Number)this.arg1).longValue() >= ((Number)this.arg2).longValue());
/*      */       }
/*  490 */       if (this.class2 == 1)
/*      */       {
/*  492 */         return Boolean.valueOf(((Number)this.arg1).longValue() >= ((Number)this.arg2).doubleValue());
/*      */       }
/*      */     }
/*  495 */     else if (this.class1 == 1)
/*      */     {
/*  497 */       computeArgument2();
/*  498 */       if (this.arg2 == null)
/*      */       {
/*  500 */         return null;
/*      */       }
/*  502 */       if (this.class2 == 2)
/*      */       {
/*  504 */         return Boolean.valueOf(((Number)this.arg1).longValue() >= ((Number)this.arg2).longValue());
/*      */       }
/*  506 */       if (this.class2 == 1)
/*      */       {
/*  508 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() >= ((Number)this.arg2).doubleValue());
/*      */       }
/*  510 */       return Boolean.FALSE;
/*      */     }
/*  512 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   Object lt()
/*      */     throws Exception
/*      */   {
/*  518 */     computeArgument1();
/*  519 */     if (this.arg1 == null)
/*      */     {
/*  521 */       return null;
/*      */     }
/*      */     
/*  524 */     if (this.class1 == 2)
/*      */     {
/*  526 */       computeArgument2();
/*  527 */       if (this.arg2 == null)
/*      */       {
/*  529 */         return null;
/*      */       }
/*  531 */       if (this.class2 == 2)
/*      */       {
/*  533 */         return Boolean.valueOf(((Number)this.arg1).longValue() < ((Number)this.arg2).longValue());
/*      */       }
/*  535 */       if (this.class2 == 1)
/*      */       {
/*  537 */         return Boolean.valueOf(((Number)this.arg1).longValue() < ((Number)this.arg2).doubleValue());
/*      */       }
/*      */     }
/*  540 */     else if (this.class1 == 1)
/*      */     {
/*  542 */       computeArgument2();
/*  543 */       if (this.arg2 == null)
/*      */       {
/*  545 */         return null;
/*      */       }
/*  547 */       if (this.class2 == 2)
/*      */       {
/*  549 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() < ((Number)this.arg2).longValue());
/*      */       }
/*  551 */       if (this.class2 == 1)
/*      */       {
/*  553 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() < ((Number)this.arg2).doubleValue());
/*      */       }
/*      */     }
/*      */     
/*  557 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   Object le()
/*      */     throws Exception
/*      */   {
/*  563 */     computeArgument1();
/*  564 */     if (this.arg1 == null)
/*      */     {
/*  566 */       return null;
/*      */     }
/*      */     
/*  569 */     if (this.class1 == 2)
/*      */     {
/*  571 */       computeArgument2();
/*  572 */       if (this.arg2 == null)
/*      */       {
/*  574 */         return null;
/*      */       }
/*  576 */       if (this.class2 == 2)
/*      */       {
/*  578 */         return Boolean.valueOf(((Number)this.arg1).longValue() <= ((Number)this.arg2).longValue());
/*      */       }
/*  580 */       if (this.class2 == 1)
/*      */       {
/*  582 */         return Boolean.valueOf(((Number)this.arg1).longValue() <= ((Number)this.arg2).doubleValue());
/*      */       }
/*      */     }
/*  585 */     else if (this.class1 == 1)
/*      */     {
/*  587 */       computeArgument2();
/*  588 */       if (this.arg2 == null)
/*      */       {
/*  590 */         return null;
/*      */       }
/*  592 */       if (this.class2 == 2)
/*      */       {
/*  594 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() <= ((Number)this.arg2).longValue());
/*      */       }
/*  596 */       if (this.class2 == 1)
/*      */       {
/*  598 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() <= ((Number)this.arg2).doubleValue());
/*      */       }
/*      */     }
/*  601 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   Object different()
/*      */     throws Exception
/*      */   {
/*  607 */     computeArgument1();
/*      */     
/*  609 */     if (this.arg1 == null)
/*      */     {
/*  611 */       computeArgument2();
/*  612 */       if (this.arg2 == null)
/*      */       {
/*  614 */         return Boolean.FALSE;
/*      */       }
/*      */       
/*      */ 
/*  618 */       return Boolean.TRUE;
/*      */     }
/*      */     
/*      */ 
/*  622 */     switch (this.class1)
/*      */     {
/*      */     case 2: 
/*  625 */       computeArgument1();
/*  626 */       if (this.arg1 == null)
/*      */       {
/*  628 */         return null;
/*      */       }
/*  630 */       computeArgument2();
/*  631 */       if (this.arg2 == null)
/*      */       {
/*  633 */         return null;
/*      */       }
/*  635 */       if (this.class2 == 2)
/*      */       {
/*  637 */         return Boolean.valueOf(((Number)this.arg1).longValue() != ((Number)this.arg2).longValue());
/*      */       }
/*  639 */       if (this.class2 == 1)
/*      */       {
/*  641 */         return Boolean.valueOf(((Number)this.arg1).longValue() != ((Number)this.arg2).doubleValue());
/*      */       }
/*  643 */       return Boolean.FALSE;
/*      */     case 1: 
/*  645 */       computeArgument1();
/*  646 */       if (this.arg1 == null)
/*      */       {
/*  648 */         return null;
/*      */       }
/*  650 */       computeArgument2();
/*  651 */       if (this.arg2 == null)
/*      */       {
/*  653 */         return null;
/*      */       }
/*  655 */       if (this.class2 == 2)
/*      */       {
/*  657 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() != ((Number)this.arg2).longValue());
/*      */       }
/*  659 */       if (this.class2 == 1)
/*      */       {
/*  661 */         return Boolean.valueOf(((Number)this.arg1).doubleValue() != ((Number)this.arg2).doubleValue());
/*      */       }
/*  663 */       return Boolean.FALSE;
/*      */     case 3: 
/*      */     case 4: 
/*  666 */       computeArgument2();
/*  667 */       if (this.arg2 == null)
/*      */       {
/*  669 */         return null;
/*      */       }
/*  671 */       if (this.class2 != this.class1)
/*      */       {
/*  673 */         throwBadObjectException(this.class1, this.class2);
/*      */       }
/*  675 */       return Boolean.valueOf(!this.arg1.equals(this.arg2));
/*      */     }
/*  677 */     throwBadObjectException(this.class1);
/*      */     
/*  679 */     return null;
/*      */   }
/*      */   
/*      */   Object add()
/*      */     throws Exception
/*      */   {
/*  685 */     computeArgument1();
/*  686 */     computeArgument2();
/*      */     
/*  688 */     if ((this.arg1 == null) || (this.arg2 == null))
/*      */     {
/*  690 */       return null;
/*      */     }
/*  692 */     switch (this.class1)
/*      */     {
/*      */     case 1: 
/*  695 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  698 */         return Double.valueOf(((Number)this.arg1).doubleValue() + ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  700 */         return Double.valueOf(((Number)this.arg1).doubleValue() + ((Number)this.arg2).doubleValue());
/*      */       }
/*  702 */       throwBadObjectException(this.class2);
/*      */       
/*  704 */       break;
/*      */     case 2: 
/*  706 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  709 */         return Double.valueOf(((Number)this.arg1).doubleValue() + ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  711 */         return Long.valueOf(((Number)this.arg1).longValue() + ((Number)this.arg2).longValue());
/*      */       }
/*  713 */       throwBadObjectException(this.class2);
/*      */       
/*  715 */       break;
/*      */     default: 
/*  717 */       throwBadObjectException(this.class1);
/*      */     }
/*  719 */     return null;
/*      */   }
/*      */   
/*      */   Object sub()
/*      */     throws Exception
/*      */   {
/*  725 */     computeArgument1();
/*  726 */     computeArgument2();
/*      */     
/*  728 */     if ((this.arg1 == null) || (this.arg2 == null))
/*      */     {
/*  730 */       return null;
/*      */     }
/*  732 */     switch (this.class1)
/*      */     {
/*      */     case 1: 
/*  735 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  738 */         return Double.valueOf(((Number)this.arg1).doubleValue() - ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  740 */         return Double.valueOf(((Number)this.arg1).doubleValue() - ((Number)this.arg2).doubleValue());
/*      */       }
/*  742 */       throwBadObjectException(this.class2);
/*      */       
/*  744 */       break;
/*      */     case 2: 
/*  746 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  749 */         return Double.valueOf(((Number)this.arg1).doubleValue() - ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  751 */         return Long.valueOf(((Number)this.arg1).longValue() - ((Number)this.arg2).longValue());
/*      */       }
/*  753 */       throwBadObjectException(this.class2);
/*      */       
/*  755 */       break;
/*      */     default: 
/*  757 */       throwBadObjectException(this.class1);
/*      */     }
/*  759 */     return null;
/*      */   }
/*      */   
/*      */   Object neg()
/*      */     throws Exception
/*      */   {
/*  765 */     computeArgument1();
/*  766 */     if (this.arg1 == null)
/*      */     {
/*  768 */       return null;
/*      */     }
/*  770 */     switch (this.class1)
/*      */     {
/*      */     case 1: 
/*  773 */       return Double.valueOf(-((Number)this.arg1).doubleValue());
/*      */     case 2: 
/*  775 */       return Long.valueOf(-((Number)this.arg1).longValue());
/*      */     }
/*  777 */     throwBadObjectException(this.class1);
/*      */     
/*  779 */     return null;
/*      */   }
/*      */   
/*      */   Object mul()
/*      */     throws Exception
/*      */   {
/*  785 */     computeArgument1();
/*  786 */     computeArgument2();
/*  787 */     if ((this.arg1 == null) || (this.arg2 == null))
/*      */     {
/*  789 */       return null;
/*      */     }
/*  791 */     switch (this.class1)
/*      */     {
/*      */     case 1: 
/*  794 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  797 */         return Double.valueOf(((Number)this.arg1).doubleValue() * ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  799 */         return Double.valueOf(((Number)this.arg1).doubleValue() * ((Number)this.arg2).doubleValue());
/*      */       }
/*  801 */       throwBadObjectException(this.class2);
/*      */       
/*  803 */       break;
/*      */     case 2: 
/*  805 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  808 */         return Double.valueOf(((Number)this.arg1).doubleValue() * ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  810 */         return Long.valueOf(((Number)this.arg1).longValue() * ((Number)this.arg2).longValue());
/*      */       }
/*  812 */       throwBadObjectException(this.class2);
/*      */       
/*  814 */       break;
/*      */     default: 
/*  816 */       throwBadObjectException(this.class1);
/*      */     }
/*  818 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   Object div()
/*      */     throws Exception
/*      */   {
/*  825 */     computeArgument1();
/*  826 */     computeArgument2();
/*  827 */     if ((this.arg1 == null) || (this.arg2 == null))
/*      */     {
/*  829 */       return null;
/*      */     }
/*  831 */     switch (this.class1)
/*      */     {
/*      */     case 1: 
/*  834 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  837 */         return Double.valueOf(((Number)this.arg1).doubleValue() / ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  839 */         return Double.valueOf(((Number)this.arg1).doubleValue() / ((Number)this.arg2).doubleValue());
/*      */       }
/*  841 */       throwBadObjectException(this.class2);
/*      */       
/*  843 */       break;
/*      */     case 2: 
/*  845 */       switch (this.class2)
/*      */       {
/*      */       case 1: 
/*  848 */         return Double.valueOf(((Number)this.arg1).doubleValue() / ((Number)this.arg2).doubleValue());
/*      */       case 2: 
/*  850 */         return Long.valueOf(((Number)this.arg1).longValue() / ((Number)this.arg2).longValue());
/*      */       }
/*  852 */       throwBadObjectException(this.class2);
/*      */       
/*  854 */       break;
/*      */     default: 
/*  856 */       throwBadObjectException(this.class1);
/*      */     }
/*  858 */     return null;
/*      */   }
/*      */   
/*      */   Object between()
/*      */     throws Exception
/*      */   {
/*  864 */     Object res = ge();
/*  865 */     if (res == null)
/*      */     {
/*  867 */       return null;
/*      */     }
/*  869 */     if (!((Boolean)res).booleanValue())
/*      */     {
/*  871 */       return res;
/*      */     }
/*      */     
/*  874 */     Object oper4 = this.oper2;
/*  875 */     this.oper2 = this.oper3;
/*  876 */     res = le();
/*  877 */     this.oper2 = oper4;
/*  878 */     return res;
/*      */   }
/*      */   
/*      */   Object not_between()
/*      */     throws Exception
/*      */   {
/*  884 */     Object res = lt();
/*  885 */     if (res == null)
/*      */     {
/*  887 */       return null;
/*      */     }
/*  889 */     if (((Boolean)res).booleanValue())
/*      */     {
/*  891 */       return res;
/*      */     }
/*      */     
/*  894 */     Object oper4 = this.oper2;
/*  895 */     this.oper2 = this.oper3;
/*  896 */     res = gt();
/*  897 */     this.oper2 = oper4;
/*  898 */     return res;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Object like(boolean not, boolean use_escape)
/*      */     throws Exception
/*      */   {
/*  914 */     Character escapeChar = null;
/*      */     
/*  916 */     computeArgument1();
/*      */     
/*  918 */     if (this.arg1 == null)
/*      */     {
/*  920 */       return null;
/*      */     }
/*      */     
/*  923 */     if (this.class1 != 4)
/*      */     {
/*  925 */       throwBadObjectException(this.class1);
/*      */     }
/*      */     
/*  928 */     computeArgument2();
/*      */     
/*  930 */     if (this.arg2 == null)
/*      */     {
/*  932 */       return Boolean.FALSE;
/*      */     }
/*  934 */     if (this.class2 != 4)
/*      */     {
/*  936 */       throwBadObjectException(this.class2);
/*      */     }
/*      */     
/*  939 */     if (use_escape)
/*      */     {
/*  941 */       computeArgument3();
/*  942 */       if (this.arg3 == null)
/*      */       {
/*  944 */         return null;
/*      */       }
/*      */       
/*  947 */       if (this.class3 != 4)
/*      */       {
/*  949 */         throwBadObjectException(this.class3);
/*      */       }
/*      */       
/*  952 */       SimpleString escapeString = (SimpleString)this.arg3;
/*  953 */       if (escapeString.length() != 1)
/*      */       {
/*  955 */         throw new Exception("LIKE ESCAPE: Bad escape character " + escapeString.toString());
/*      */       }
/*      */       
/*  958 */       escapeChar = Character.valueOf(escapeString.charAt(0));
/*      */     }
/*      */     
/*  961 */     if (this.re == null)
/*      */     {
/*      */ 
/*  964 */       this.re = new RegExp(this.arg2.toString(), escapeChar);
/*      */     }
/*      */     
/*  967 */     boolean result = this.re.isMatch(this.arg1);
/*  968 */     if (not)
/*      */     {
/*  970 */       result = !result;
/*      */     }
/*      */     
/*  973 */     if (result == true)
/*      */     {
/*  975 */       return Boolean.TRUE;
/*      */     }
/*      */     
/*      */ 
/*  979 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */ 
/*      */   Object in()
/*      */     throws Exception
/*      */   {
/*  986 */     computeArgument1();
/*  987 */     if (this.arg1 == null)
/*      */     {
/*  989 */       return Boolean.valueOf(false);
/*      */     }
/*  991 */     if (this.class1 != 4)
/*      */     {
/*  993 */       throwBadObjectException(this.class1);
/*      */     }
/*  995 */     if (((HashSet)this.oper2).contains(this.arg1))
/*      */     {
/*  997 */       return Boolean.TRUE;
/*      */     }
/*      */     
/*      */ 
/* 1001 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */ 
/*      */   Object not_in()
/*      */     throws Exception
/*      */   {
/* 1008 */     computeArgument1();
/* 1009 */     if (this.arg1 == null)
/*      */     {
/* 1011 */       return null;
/*      */     }
/* 1013 */     if (this.class1 != 4)
/*      */     {
/* 1015 */       throwBadObjectException(this.class1);
/*      */     }
/* 1017 */     if (((HashSet)this.oper2).contains(this.arg1))
/*      */     {
/* 1019 */       return Boolean.FALSE;
/*      */     }
/*      */     
/*      */ 
/* 1023 */     return Boolean.TRUE;
/*      */   }
/*      */   
/*      */   void computeArgument1()
/*      */     throws Exception
/*      */   {
/* 1029 */     if (this.oper1 == null)
/*      */     {
/* 1031 */       this.class1 = 0;
/* 1032 */       return;
/*      */     }
/* 1034 */     Class className = this.oper1.getClass();
/*      */     
/* 1036 */     if (className == Identifier.class)
/*      */     {
/* 1038 */       this.arg1 = ((Identifier)this.oper1).getValue();
/*      */     }
/* 1040 */     else if (className == Operator.class)
/*      */     {
/* 1042 */       this.arg1 = ((Operator)this.oper1).apply();
/*      */     }
/*      */     else
/*      */     {
/* 1046 */       this.arg1 = this.oper1;
/*      */     }
/*      */     
/* 1049 */     if (this.arg1 == null)
/*      */     {
/* 1051 */       this.class1 = 0;
/* 1052 */       return;
/*      */     }
/*      */     
/* 1055 */     className = this.arg1.getClass();
/*      */     
/* 1057 */     if (className == SimpleString.class)
/*      */     {
/* 1059 */       this.class1 = 4;
/*      */     }
/* 1061 */     else if (className == Double.class)
/*      */     {
/* 1063 */       this.class1 = 1;
/*      */     }
/* 1065 */     else if (className == Long.class)
/*      */     {
/* 1067 */       this.class1 = 2;
/*      */     }
/* 1069 */     else if (className == Integer.class)
/*      */     {
/* 1071 */       this.class1 = 2;
/* 1072 */       this.arg1 = Long.valueOf(((Integer)this.arg1).longValue());
/*      */     }
/* 1074 */     else if (className == Short.class)
/*      */     {
/* 1076 */       this.class1 = 2;
/* 1077 */       this.arg1 = Long.valueOf(((Short)this.arg1).longValue());
/*      */     }
/* 1079 */     else if (className == Byte.class)
/*      */     {
/* 1081 */       this.class1 = 2;
/* 1082 */       this.arg1 = Long.valueOf(((Byte)this.arg1).longValue());
/*      */     }
/* 1084 */     else if (className == Float.class)
/*      */     {
/* 1086 */       this.class1 = 1;
/* 1087 */       this.arg1 = Double.valueOf(((Float)this.arg1).doubleValue());
/*      */     }
/* 1089 */     else if (className == Boolean.class)
/*      */     {
/* 1091 */       this.class1 = 3;
/*      */     }
/*      */     else
/*      */     {
/* 1095 */       throwBadObjectException(className);
/*      */     }
/*      */   }
/*      */   
/*      */   void computeArgument2() throws Exception
/*      */   {
/* 1101 */     if (this.oper2 == null)
/*      */     {
/* 1103 */       this.class2 = 0;
/* 1104 */       return;
/*      */     }
/*      */     
/* 1107 */     Class className = this.oper2.getClass();
/*      */     
/* 1109 */     if (className == Identifier.class)
/*      */     {
/* 1111 */       this.arg2 = ((Identifier)this.oper2).getValue();
/*      */     }
/* 1113 */     else if (className == Operator.class)
/*      */     {
/* 1115 */       this.arg2 = ((Operator)this.oper2).apply();
/*      */     }
/*      */     else
/*      */     {
/* 1119 */       this.arg2 = this.oper2;
/*      */     }
/*      */     
/* 1122 */     if (this.arg2 == null)
/*      */     {
/* 1124 */       this.class2 = 0;
/* 1125 */       return;
/*      */     }
/*      */     
/* 1128 */     className = this.arg2.getClass();
/*      */     
/* 1130 */     if (className == SimpleString.class)
/*      */     {
/* 1132 */       this.class2 = 4;
/*      */     }
/* 1134 */     else if (className == Double.class)
/*      */     {
/* 1136 */       this.class2 = 1;
/*      */     }
/* 1138 */     else if (className == Long.class)
/*      */     {
/* 1140 */       this.class2 = 2;
/*      */     }
/* 1142 */     else if (className == Integer.class)
/*      */     {
/* 1144 */       this.class2 = 2;
/* 1145 */       this.arg2 = Long.valueOf(((Integer)this.arg2).longValue());
/*      */     }
/* 1147 */     else if (className == Short.class)
/*      */     {
/* 1149 */       this.class2 = 2;
/* 1150 */       this.arg2 = Long.valueOf(((Short)this.arg2).longValue());
/*      */     }
/* 1152 */     else if (className == Byte.class)
/*      */     {
/* 1154 */       this.class2 = 2;
/* 1155 */       this.arg2 = Long.valueOf(((Byte)this.arg2).longValue());
/*      */     }
/* 1157 */     else if (className == Float.class)
/*      */     {
/* 1159 */       this.class2 = 1;
/* 1160 */       this.arg2 = Double.valueOf(((Float)this.arg2).doubleValue());
/*      */     }
/* 1162 */     else if (className == Boolean.class)
/*      */     {
/* 1164 */       this.class2 = 3;
/*      */     }
/*      */     else
/*      */     {
/* 1168 */       throwBadObjectException(className);
/*      */     }
/*      */   }
/*      */   
/*      */   void computeArgument3() throws Exception
/*      */   {
/* 1174 */     if (this.oper3 == null)
/*      */     {
/* 1176 */       this.class3 = 0;
/* 1177 */       return;
/*      */     }
/*      */     
/* 1180 */     Class className = this.oper3.getClass();
/*      */     
/* 1182 */     if (className == Identifier.class)
/*      */     {
/* 1184 */       this.arg3 = ((Identifier)this.oper3).getValue();
/*      */     }
/* 1186 */     else if (className == Operator.class)
/*      */     {
/* 1188 */       this.arg3 = ((Operator)this.oper3).apply();
/*      */     }
/*      */     else
/*      */     {
/* 1192 */       this.arg3 = this.oper3;
/*      */     }
/*      */     
/* 1195 */     if (this.arg3 == null)
/*      */     {
/* 1197 */       this.class3 = 0;
/* 1198 */       return;
/*      */     }
/*      */     
/* 1201 */     className = this.arg3.getClass();
/*      */     
/* 1203 */     if (className == SimpleString.class)
/*      */     {
/* 1205 */       this.class3 = 4;
/*      */     }
/* 1207 */     else if (className == Double.class)
/*      */     {
/* 1209 */       this.class3 = 1;
/*      */     }
/* 1211 */     else if (className == Long.class)
/*      */     {
/* 1213 */       this.class3 = 2;
/*      */     }
/* 1215 */     else if (className == Integer.class)
/*      */     {
/* 1217 */       this.class3 = 2;
/* 1218 */       this.arg3 = Long.valueOf(((Integer)this.arg3).longValue());
/*      */     }
/* 1220 */     else if (className == Short.class)
/*      */     {
/* 1222 */       this.class3 = 2;
/* 1223 */       this.arg3 = Long.valueOf(((Short)this.arg3).longValue());
/*      */     }
/* 1225 */     else if (className == Byte.class)
/*      */     {
/* 1227 */       this.class3 = 2;
/* 1228 */       this.arg3 = Long.valueOf(((Byte)this.arg3).longValue());
/*      */     }
/* 1230 */     else if (className == Float.class)
/*      */     {
/* 1232 */       this.class3 = 1;
/* 1233 */       this.arg3 = Double.valueOf(((Float)this.arg3).doubleValue());
/*      */     }
/* 1235 */     else if (className == Boolean.class)
/*      */     {
/* 1237 */       this.class3 = 3;
/*      */     }
/*      */     else
/*      */     {
/* 1241 */       throwBadObjectException(className);
/*      */     }
/*      */   }
/*      */   
/*      */   public Object apply() throws Exception
/*      */   {
/* 1247 */     switch (this.operation)
/*      */     {
/*      */     case 0: 
/* 1250 */       return equal();
/*      */     case 1: 
/* 1252 */       return not();
/*      */     case 2: 
/* 1254 */       return and();
/*      */     case 3: 
/* 1256 */       return or();
/*      */     case 4: 
/* 1258 */       return gt();
/*      */     case 5: 
/* 1260 */       return ge();
/*      */     case 6: 
/* 1262 */       return lt();
/*      */     case 7: 
/* 1264 */       return le();
/*      */     case 8: 
/* 1266 */       return different();
/*      */     case 9: 
/* 1268 */       return add();
/*      */     case 10: 
/* 1270 */       return sub();
/*      */     case 11: 
/* 1272 */       return neg();
/*      */     case 12: 
/* 1274 */       return mul();
/*      */     case 13: 
/* 1276 */       return div();
/*      */     case 14: 
/* 1278 */       return between();
/*      */     case 15: 
/* 1280 */       return not_between();
/*      */     case 16: 
/* 1282 */       return like(false, false);
/*      */     case 17: 
/* 1284 */       return like(true, false);
/*      */     case 18: 
/* 1286 */       return like(false, true);
/*      */     case 19: 
/* 1288 */       return like(true, true);
/*      */     case 20: 
/* 1290 */       return is_null();
/*      */     case 21: 
/* 1292 */       return is_not_null();
/*      */     case 22: 
/* 1294 */       return in();
/*      */     case 23: 
/* 1296 */       return not_in();
/*      */     }
/* 1298 */     throw HornetQClientMessageBundle.BUNDLE.noOperationMapped(Integer.valueOf(this.operation));
/*      */   }
/*      */   
/*      */   public void throwBadObjectException(Class<?> class1)
/*      */     throws Exception
/*      */   {
/* 1304 */     throw new Exception("Bad Object: '" + class1.getName() + "' for operation: " + toString());
/*      */   }
/*      */   
/*      */   public void throwBadObjectException(int class1) throws Exception
/*      */   {
/* 1309 */     throw new Exception("Bad Object: '" + getClassName(class1) + "' for operation: " + toString());
/*      */   }
/*      */   
/*      */   public void throwBadObjectException(int class1, int class2) throws Exception
/*      */   {
/* 1314 */     throw new Exception("Bad Object: expected '" + getClassName(class1) + "' got '" + getClassName(class2) + "' for operation: " + toString());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static String getClassName(int class1)
/*      */   {
/* 1323 */     switch (class1)
/*      */     {
/*      */     case 4: 
/* 1326 */       return "SimpleString";
/*      */     case 2: 
/* 1328 */       return "Long";
/*      */     case 1: 
/* 1330 */       return "Double";
/*      */     case 3: 
/* 1332 */       return "Boolean";
/*      */     }
/* 1334 */     return "Unknown";
/*      */   }
/*      */   
/*      */ 
/*      */   static String operationString(int operation)
/*      */   {
/* 1340 */     switch (operation)
/*      */     {
/*      */     case 0: 
/* 1343 */       return "EQUAL";
/*      */     case 1: 
/* 1345 */       return "NOT";
/*      */     case 2: 
/* 1347 */       return "AND";
/*      */     case 3: 
/* 1349 */       return "OR";
/*      */     case 4: 
/* 1351 */       return "GT";
/*      */     case 5: 
/* 1353 */       return "GE";
/*      */     case 6: 
/* 1355 */       return "LT";
/*      */     case 7: 
/* 1357 */       return "LE";
/*      */     case 8: 
/* 1359 */       return "DIFFERENT";
/*      */     case 9: 
/* 1361 */       return "ADD";
/*      */     case 10: 
/* 1363 */       return "SUB";
/*      */     case 11: 
/* 1365 */       return "NEG";
/*      */     case 12: 
/* 1367 */       return "MUL";
/*      */     case 13: 
/* 1369 */       return "DIV";
/*      */     case 14: 
/* 1371 */       return "BETWEEN";
/*      */     case 15: 
/* 1373 */       return "NOT_BETWEEN";
/*      */     case 16: 
/* 1375 */       return "LIKE";
/*      */     case 17: 
/* 1377 */       return "NOT_LIKE";
/*      */     case 18: 
/* 1379 */       return "LIKE_ESCAPE";
/*      */     case 19: 
/* 1381 */       return "NOT_LIKE_ESCAPE";
/*      */     case 20: 
/* 1383 */       return "IS_NULL";
/*      */     case 21: 
/* 1385 */       return "IS_NOT_NULL";
/*      */     case 22: 
/* 1387 */       return "IN";
/*      */     case 23: 
/* 1389 */       return "NOT_IN";
/*      */     }
/* 1391 */     return "Unknown";
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\Operator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */