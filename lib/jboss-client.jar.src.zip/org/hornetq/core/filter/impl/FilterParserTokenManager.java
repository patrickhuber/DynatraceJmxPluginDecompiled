/*      */ package org.hornetq.core.filter.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilterParserTokenManager
/*      */   implements FilterParserConstants
/*      */ {
/*   15 */   public PrintStream debugStream = System.out;
/*      */   
/*   17 */   public void setDebugStream(PrintStream ds) { this.debugStream = ds; }
/*      */   
/*      */   private int jjStopAtPos(int pos, int kind) {
/*   20 */     this.jjmatchedKind = kind;
/*   21 */     this.jjmatchedPos = pos;
/*   22 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa0_0() {
/*   26 */     switch (this.curChar)
/*      */     {
/*      */     case '\t': 
/*   29 */       this.jjmatchedKind = 3;
/*   30 */       return jjMoveNfa_0(0, 0);
/*      */     case '\n': 
/*   32 */       this.jjmatchedKind = 5;
/*   33 */       return jjMoveNfa_0(0, 0);
/*      */     case '\f': 
/*   35 */       this.jjmatchedKind = 4;
/*   36 */       return jjMoveNfa_0(0, 0);
/*      */     case '\r': 
/*   38 */       this.jjmatchedKind = 2;
/*   39 */       return jjMoveNfa_0(0, 0);
/*      */     case ' ': 
/*   41 */       this.jjmatchedKind = 1;
/*   42 */       return jjMoveNfa_0(0, 0);
/*      */     case '(': 
/*   44 */       this.jjmatchedKind = 17;
/*   45 */       return jjMoveNfa_0(0, 0);
/*      */     case ')': 
/*   47 */       this.jjmatchedKind = 18;
/*   48 */       return jjMoveNfa_0(0, 0);
/*      */     case '*': 
/*   50 */       this.jjmatchedKind = 21;
/*   51 */       return jjMoveNfa_0(0, 0);
/*      */     case '+': 
/*   53 */       this.jjmatchedKind = 24;
/*   54 */       return jjMoveNfa_0(0, 0);
/*      */     case ',': 
/*   56 */       this.jjmatchedKind = 20;
/*   57 */       return jjMoveNfa_0(0, 0);
/*      */     case '-': 
/*   59 */       this.jjmatchedKind = 23;
/*   60 */       return jjMoveNfa_0(0, 0);
/*      */     case '/': 
/*   62 */       this.jjmatchedKind = 22;
/*   63 */       return jjMoveNfa_0(0, 0);
/*      */     case ';': 
/*   65 */       this.jjmatchedKind = 19;
/*   66 */       return jjMoveNfa_0(0, 0);
/*      */     case '<': 
/*   68 */       this.jjmatchedKind = 27;
/*   69 */       return jjMoveStringLiteralDfa1_0(805306368L);
/*      */     case '=': 
/*   71 */       this.jjmatchedKind = 30;
/*   72 */       return jjMoveNfa_0(0, 0);
/*      */     case '>': 
/*   74 */       this.jjmatchedKind = 25;
/*   75 */       return jjMoveStringLiteralDfa1_0(67108864L);
/*      */     case 'A': 
/*   77 */       return jjMoveStringLiteralDfa1_0(512L);
/*      */     case 'B': 
/*   79 */       return jjMoveStringLiteralDfa1_0(4096L);
/*      */     case 'E': 
/*   81 */       return jjMoveStringLiteralDfa1_0(65536L);
/*      */     case 'F': 
/*   83 */       return jjMoveStringLiteralDfa1_0(128L);
/*      */     case 'I': 
/*   85 */       return jjMoveStringLiteralDfa1_0(49152L);
/*      */     case 'L': 
/*   87 */       return jjMoveStringLiteralDfa1_0(8192L);
/*      */     case 'N': 
/*   89 */       return jjMoveStringLiteralDfa1_0(1280L);
/*      */     case 'O': 
/*   91 */       return jjMoveStringLiteralDfa1_0(2048L);
/*      */     case 'T': 
/*   93 */       return jjMoveStringLiteralDfa1_0(64L);
/*      */     case 'a': 
/*   95 */       return jjMoveStringLiteralDfa1_0(512L);
/*      */     case 'b': 
/*   97 */       return jjMoveStringLiteralDfa1_0(4096L);
/*      */     case 'e': 
/*   99 */       return jjMoveStringLiteralDfa1_0(65536L);
/*      */     case 'f': 
/*  101 */       return jjMoveStringLiteralDfa1_0(128L);
/*      */     case 'i': 
/*  103 */       return jjMoveStringLiteralDfa1_0(49152L);
/*      */     case 'l': 
/*  105 */       return jjMoveStringLiteralDfa1_0(8192L);
/*      */     case 'n': 
/*  107 */       return jjMoveStringLiteralDfa1_0(1280L);
/*      */     case 'o': 
/*  109 */       return jjMoveStringLiteralDfa1_0(2048L);
/*      */     case 't': 
/*  111 */       return jjMoveStringLiteralDfa1_0(64L);
/*      */     }
/*  113 */     return jjMoveNfa_0(0, 0);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa1_0(long active0) {
/*      */     try {
/*  118 */       this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  120 */       return jjMoveNfa_0(0, 0);
/*      */     }
/*  122 */     switch (this.curChar)
/*      */     {
/*      */     case '=': 
/*  125 */       if ((active0 & 0x4000000) != 0L)
/*      */       {
/*  127 */         this.jjmatchedKind = 26;
/*  128 */         this.jjmatchedPos = 1;
/*      */       }
/*  130 */       else if ((active0 & 0x10000000) != 0L)
/*      */       {
/*  132 */         this.jjmatchedKind = 28;
/*  133 */         this.jjmatchedPos = 1;
/*      */       }
/*      */       break;
/*      */     case '>': 
/*  137 */       if ((active0 & 0x20000000) != 0L)
/*      */       {
/*  139 */         this.jjmatchedKind = 29;
/*  140 */         this.jjmatchedPos = 1;
/*      */       }
/*      */       break;
/*      */     case 'A': 
/*  144 */       return jjMoveStringLiteralDfa2_0(active0, 128L);
/*      */     case 'E': 
/*  146 */       return jjMoveStringLiteralDfa2_0(active0, 4096L);
/*      */     case 'I': 
/*  148 */       return jjMoveStringLiteralDfa2_0(active0, 8192L);
/*      */     case 'N': 
/*  150 */       if ((active0 & 0x4000) != 0L)
/*      */       {
/*  152 */         this.jjmatchedKind = 14;
/*  153 */         this.jjmatchedPos = 1;
/*      */       }
/*  155 */       return jjMoveStringLiteralDfa2_0(active0, 512L);
/*      */     case 'O': 
/*  157 */       return jjMoveStringLiteralDfa2_0(active0, 1024L);
/*      */     case 'R': 
/*  159 */       if ((active0 & 0x800) != 0L)
/*      */       {
/*  161 */         this.jjmatchedKind = 11;
/*  162 */         this.jjmatchedPos = 1;
/*      */       }
/*  164 */       return jjMoveStringLiteralDfa2_0(active0, 64L);
/*      */     case 'S': 
/*  166 */       if ((active0 & 0x8000) != 0L)
/*      */       {
/*  168 */         this.jjmatchedKind = 15;
/*  169 */         this.jjmatchedPos = 1;
/*      */       }
/*  171 */       return jjMoveStringLiteralDfa2_0(active0, 65536L);
/*      */     case 'U': 
/*  173 */       return jjMoveStringLiteralDfa2_0(active0, 256L);
/*      */     case 'a': 
/*  175 */       return jjMoveStringLiteralDfa2_0(active0, 128L);
/*      */     case 'e': 
/*  177 */       return jjMoveStringLiteralDfa2_0(active0, 4096L);
/*      */     case 'i': 
/*  179 */       return jjMoveStringLiteralDfa2_0(active0, 8192L);
/*      */     case 'n': 
/*  181 */       if ((active0 & 0x4000) != 0L)
/*      */       {
/*  183 */         this.jjmatchedKind = 14;
/*  184 */         this.jjmatchedPos = 1;
/*      */       }
/*  186 */       return jjMoveStringLiteralDfa2_0(active0, 512L);
/*      */     case 'o': 
/*  188 */       return jjMoveStringLiteralDfa2_0(active0, 1024L);
/*      */     case 'r': 
/*  190 */       if ((active0 & 0x800) != 0L)
/*      */       {
/*  192 */         this.jjmatchedKind = 11;
/*  193 */         this.jjmatchedPos = 1;
/*      */       }
/*  195 */       return jjMoveStringLiteralDfa2_0(active0, 64L);
/*      */     case 's': 
/*  197 */       if ((active0 & 0x8000) != 0L)
/*      */       {
/*  199 */         this.jjmatchedKind = 15;
/*  200 */         this.jjmatchedPos = 1;
/*      */       }
/*  202 */       return jjMoveStringLiteralDfa2_0(active0, 65536L);
/*      */     case 'u': 
/*  204 */       return jjMoveStringLiteralDfa2_0(active0, 256L);
/*      */     }
/*      */     
/*      */     
/*  208 */     return jjMoveNfa_0(0, 1);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa2_0(long old0, long active0) {
/*  212 */     if ((active0 &= old0) == 0L)
/*  213 */       return jjMoveNfa_0(0, 1);
/*  214 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  216 */       return jjMoveNfa_0(0, 1);
/*      */     }
/*  218 */     switch (this.curChar)
/*      */     {
/*      */     case 'C': 
/*  221 */       return jjMoveStringLiteralDfa3_0(active0, 65536L);
/*      */     case 'D': 
/*  223 */       if ((active0 & 0x200) != 0L)
/*      */       {
/*  225 */         this.jjmatchedKind = 9;
/*  226 */         this.jjmatchedPos = 2;
/*      */       }
/*      */       break;
/*      */     case 'K': 
/*  230 */       return jjMoveStringLiteralDfa3_0(active0, 8192L);
/*      */     case 'L': 
/*  232 */       return jjMoveStringLiteralDfa3_0(active0, 384L);
/*      */     case 'T': 
/*  234 */       if ((active0 & 0x400) != 0L)
/*      */       {
/*  236 */         this.jjmatchedKind = 10;
/*  237 */         this.jjmatchedPos = 2;
/*      */       }
/*  239 */       return jjMoveStringLiteralDfa3_0(active0, 4096L);
/*      */     case 'U': 
/*  241 */       return jjMoveStringLiteralDfa3_0(active0, 64L);
/*      */     case 'c': 
/*  243 */       return jjMoveStringLiteralDfa3_0(active0, 65536L);
/*      */     case 'd': 
/*  245 */       if ((active0 & 0x200) != 0L)
/*      */       {
/*  247 */         this.jjmatchedKind = 9;
/*  248 */         this.jjmatchedPos = 2;
/*      */       }
/*      */       break;
/*      */     case 'k': 
/*  252 */       return jjMoveStringLiteralDfa3_0(active0, 8192L);
/*      */     case 'l': 
/*  254 */       return jjMoveStringLiteralDfa3_0(active0, 384L);
/*      */     case 't': 
/*  256 */       if ((active0 & 0x400) != 0L)
/*      */       {
/*  258 */         this.jjmatchedKind = 10;
/*  259 */         this.jjmatchedPos = 2;
/*      */       }
/*  261 */       return jjMoveStringLiteralDfa3_0(active0, 4096L);
/*      */     case 'u': 
/*  263 */       return jjMoveStringLiteralDfa3_0(active0, 64L);
/*      */     }
/*      */     
/*      */     
/*  267 */     return jjMoveNfa_0(0, 2);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa3_0(long old0, long active0) {
/*  271 */     if ((active0 &= old0) == 0L)
/*  272 */       return jjMoveNfa_0(0, 2);
/*  273 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  275 */       return jjMoveNfa_0(0, 2);
/*      */     }
/*  277 */     switch (this.curChar)
/*      */     {
/*      */     case 'A': 
/*  280 */       return jjMoveStringLiteralDfa4_0(active0, 65536L);
/*      */     case 'E': 
/*  282 */       if ((active0 & 0x40) != 0L)
/*      */       {
/*  284 */         this.jjmatchedKind = 6;
/*  285 */         this.jjmatchedPos = 3;
/*      */       }
/*  287 */       else if ((active0 & 0x2000) != 0L)
/*      */       {
/*  289 */         this.jjmatchedKind = 13;
/*  290 */         this.jjmatchedPos = 3;
/*      */       }
/*      */       break;
/*      */     case 'L': 
/*  294 */       if ((active0 & 0x100) != 0L)
/*      */       {
/*  296 */         this.jjmatchedKind = 8;
/*  297 */         this.jjmatchedPos = 3;
/*      */       }
/*      */       break;
/*      */     case 'S': 
/*  301 */       return jjMoveStringLiteralDfa4_0(active0, 128L);
/*      */     case 'W': 
/*  303 */       return jjMoveStringLiteralDfa4_0(active0, 4096L);
/*      */     case 'a': 
/*  305 */       return jjMoveStringLiteralDfa4_0(active0, 65536L);
/*      */     case 'e': 
/*  307 */       if ((active0 & 0x40) != 0L)
/*      */       {
/*  309 */         this.jjmatchedKind = 6;
/*  310 */         this.jjmatchedPos = 3;
/*      */       }
/*  312 */       else if ((active0 & 0x2000) != 0L)
/*      */       {
/*  314 */         this.jjmatchedKind = 13;
/*  315 */         this.jjmatchedPos = 3;
/*      */       }
/*      */       break;
/*      */     case 'l': 
/*  319 */       if ((active0 & 0x100) != 0L)
/*      */       {
/*  321 */         this.jjmatchedKind = 8;
/*  322 */         this.jjmatchedPos = 3;
/*      */       }
/*      */       break;
/*      */     case 's': 
/*  326 */       return jjMoveStringLiteralDfa4_0(active0, 128L);
/*      */     case 'w': 
/*  328 */       return jjMoveStringLiteralDfa4_0(active0, 4096L);
/*      */     }
/*      */     
/*      */     
/*  332 */     return jjMoveNfa_0(0, 3);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa4_0(long old0, long active0) {
/*  336 */     if ((active0 &= old0) == 0L)
/*  337 */       return jjMoveNfa_0(0, 3);
/*  338 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  340 */       return jjMoveNfa_0(0, 3);
/*      */     }
/*  342 */     switch (this.curChar)
/*      */     {
/*      */     case 'E': 
/*  345 */       if ((active0 & 0x80) != 0L)
/*      */       {
/*  347 */         this.jjmatchedKind = 7;
/*  348 */         this.jjmatchedPos = 4;
/*      */       }
/*  350 */       return jjMoveStringLiteralDfa5_0(active0, 4096L);
/*      */     case 'P': 
/*  352 */       return jjMoveStringLiteralDfa5_0(active0, 65536L);
/*      */     case 'e': 
/*  354 */       if ((active0 & 0x80) != 0L)
/*      */       {
/*  356 */         this.jjmatchedKind = 7;
/*  357 */         this.jjmatchedPos = 4;
/*      */       }
/*  359 */       return jjMoveStringLiteralDfa5_0(active0, 4096L);
/*      */     case 'p': 
/*  361 */       return jjMoveStringLiteralDfa5_0(active0, 65536L);
/*      */     }
/*      */     
/*      */     
/*  365 */     return jjMoveNfa_0(0, 4);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa5_0(long old0, long active0) {
/*  369 */     if ((active0 &= old0) == 0L)
/*  370 */       return jjMoveNfa_0(0, 4);
/*  371 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  373 */       return jjMoveNfa_0(0, 4);
/*      */     }
/*  375 */     switch (this.curChar)
/*      */     {
/*      */     case 'E': 
/*  378 */       if ((active0 & 0x10000) != 0L)
/*      */       {
/*  380 */         this.jjmatchedKind = 16;
/*  381 */         this.jjmatchedPos = 5;
/*      */       }
/*  383 */       return jjMoveStringLiteralDfa6_0(active0, 4096L);
/*      */     case 'e': 
/*  385 */       if ((active0 & 0x10000) != 0L)
/*      */       {
/*  387 */         this.jjmatchedKind = 16;
/*  388 */         this.jjmatchedPos = 5;
/*      */       }
/*  390 */       return jjMoveStringLiteralDfa6_0(active0, 4096L);
/*      */     }
/*      */     
/*      */     
/*  394 */     return jjMoveNfa_0(0, 5);
/*      */   }
/*      */   
/*      */   private int jjMoveStringLiteralDfa6_0(long old0, long active0) {
/*  398 */     if ((active0 &= old0) == 0L)
/*  399 */       return jjMoveNfa_0(0, 5);
/*  400 */     try { this.curChar = this.input_stream.readChar();
/*      */     } catch (IOException e) {
/*  402 */       return jjMoveNfa_0(0, 5);
/*      */     }
/*  404 */     switch (this.curChar)
/*      */     {
/*      */     case 'N': 
/*  407 */       if ((active0 & 0x1000) != 0L)
/*      */       {
/*  409 */         this.jjmatchedKind = 12;
/*  410 */         this.jjmatchedPos = 6;
/*      */       }
/*      */       break;
/*      */     case 'n': 
/*  414 */       if ((active0 & 0x1000) != 0L)
/*      */       {
/*  416 */         this.jjmatchedKind = 12;
/*  417 */         this.jjmatchedPos = 6;
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*  423 */     return jjMoveNfa_0(0, 6); }
/*      */   
/*  425 */   static final long[] jjbitVec0 = { -2L, -1L, -1L, -1L };
/*      */   
/*      */ 
/*  428 */   static final long[] jjbitVec2 = { 0L, 0L, -1L, -1L };
/*      */   
/*      */ 
/*      */   private int jjMoveNfa_0(int startState, int curPos)
/*      */   {
/*  433 */     int strKind = this.jjmatchedKind;
/*  434 */     int strPos = this.jjmatchedPos;
/*      */     int seenUpto;
/*  436 */     this.input_stream.backup(seenUpto = curPos + 1);
/*  437 */     try { this.curChar = this.input_stream.readChar();
/*  438 */     } catch (IOException e) { throw new Error("Internal Error"); }
/*  439 */     curPos = 0;
/*  440 */     int startsAt = 0;
/*  441 */     this.jjnewStateCnt = 96;
/*  442 */     int i = 1;
/*  443 */     this.jjstateSet[0] = startState;
/*  444 */     int kind = Integer.MAX_VALUE;
/*      */     for (;;)
/*      */     {
/*  447 */       if (++this.jjround == Integer.MAX_VALUE)
/*  448 */         ReInitRounds();
/*  449 */       if (this.curChar < '@')
/*      */       {
/*  451 */         long l = 1L << this.curChar;
/*      */         do
/*      */         {
/*  454 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/*  457 */             if ((0x3FF000000000000 & l) != 0L) {
/*  458 */               jjCheckNAddStates(0, 6);
/*  459 */             } else if ((0x280000000000 & l) != 0L) {
/*  460 */               jjCheckNAdd(4);
/*  461 */             } else if (this.curChar == '$')
/*      */             {
/*  463 */               if (kind > 38)
/*  464 */                 kind = 38;
/*  465 */               jjCheckNAdd(22);
/*      */             }
/*  467 */             else if (this.curChar == '\'') {
/*  468 */               jjCheckNAddStates(7, 9);
/*  469 */             } else if (this.curChar == '.') {
/*  470 */               jjCheckNAdd(12); }
/*  471 */             if ((0x3FE000000000000 & l) != 0L)
/*      */             {
/*  473 */               if (kind > 31)
/*  474 */                 kind = 31;
/*  475 */               jjCheckNAddTwoStates(1, 2);
/*      */             }
/*  477 */             else if (this.curChar == '0')
/*      */             {
/*  479 */               if (kind > 31)
/*  480 */                 kind = 31;
/*  481 */               jjCheckNAddStates(10, 12);
/*      */             }
/*  483 */             else if (this.curChar == '-') {
/*  484 */               jjAddStates(13, 15);
/*      */             }
/*      */             break;
/*  487 */           case 1:  if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  489 */               if (kind > 31)
/*  490 */                 kind = 31;
/*  491 */               jjCheckNAddTwoStates(1, 2); }
/*  492 */             break;
/*      */           case 3: 
/*  494 */             if ((0x280000000000 & l) != 0L)
/*  495 */               jjCheckNAdd(4);
/*      */             break;
/*      */           case 4: 
/*  498 */             if ((0x3FF000000000000 & l) != 0L)
/*  499 */               jjCheckNAddTwoStates(4, 5);
/*      */             break;
/*      */           case 5: 
/*  502 */             if (this.curChar == '.')
/*      */             {
/*  504 */               if (kind > 35)
/*  505 */                 kind = 35;
/*  506 */               jjCheckNAddStates(16, 18); }
/*  507 */             break;
/*      */           case 6: 
/*  509 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  511 */               if (kind > 35)
/*  512 */                 kind = 35;
/*  513 */               jjCheckNAddStates(16, 18); }
/*  514 */             break;
/*      */           case 8: 
/*  516 */             if ((0x280000000000 & l) != 0L)
/*  517 */               jjCheckNAdd(9);
/*      */             break;
/*      */           case 9: 
/*  520 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  522 */               if (kind > 35)
/*  523 */                 kind = 35;
/*  524 */               jjCheckNAddTwoStates(9, 10); }
/*  525 */             break;
/*      */           case 11: 
/*  527 */             if (this.curChar == '.')
/*  528 */               jjCheckNAdd(12);
/*      */             break;
/*      */           case 12: 
/*  531 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  533 */               if (kind > 35)
/*  534 */                 kind = 35;
/*  535 */               jjCheckNAddStates(19, 21); }
/*  536 */             break;
/*      */           case 14: 
/*  538 */             if ((0x280000000000 & l) != 0L)
/*  539 */               jjCheckNAdd(15);
/*      */             break;
/*      */           case 15: 
/*  542 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  544 */               if (kind > 35)
/*  545 */                 kind = 35;
/*  546 */               jjCheckNAddTwoStates(15, 10); }
/*  547 */             break;
/*      */           case 16: 
/*      */           case 18: 
/*  550 */             if (this.curChar == '\'')
/*  551 */               jjCheckNAddStates(7, 9);
/*      */             break;
/*      */           case 17: 
/*  554 */             if ((0xFFFFFF7FFFFFDBFF & l) != 0L)
/*  555 */               jjCheckNAddStates(7, 9);
/*      */             break;
/*      */           case 19: 
/*  558 */             if (this.curChar == '\'')
/*  559 */               this.jjstateSet[(this.jjnewStateCnt++)] = 18;
/*      */             break;
/*      */           case 20: 
/*  562 */             if ((this.curChar == '\'') && (kind > 37))
/*  563 */               kind = 37;
/*      */             break;
/*      */           case 21: 
/*  566 */             if (this.curChar == '$')
/*      */             {
/*  568 */               if (kind > 38)
/*  569 */                 kind = 38;
/*  570 */               jjCheckNAdd(22); }
/*  571 */             break;
/*      */           case 22: 
/*  573 */             if ((0x3FF001000000000 & l) != 0L)
/*      */             {
/*  575 */               if (kind > 38)
/*  576 */                 kind = 38;
/*  577 */               jjCheckNAdd(22); }
/*  578 */             break;
/*      */           case 23: 
/*  580 */             if ((0x3FF000000000000 & l) != 0L)
/*  581 */               jjCheckNAddStates(0, 6);
/*      */             break;
/*      */           case 24: 
/*  584 */             if ((0x3FF000000000000 & l) != 0L)
/*  585 */               jjCheckNAddTwoStates(24, 25);
/*      */             break;
/*      */           case 26: 
/*  588 */             if ((0x280000000000 & l) != 0L)
/*  589 */               jjCheckNAdd(27);
/*      */             break;
/*      */           case 27: 
/*  592 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  594 */               if (kind > 35)
/*  595 */                 kind = 35;
/*  596 */               jjCheckNAddTwoStates(27, 10); }
/*  597 */             break;
/*      */           case 28: 
/*  599 */             if ((0x3FF000000000000 & l) != 0L)
/*  600 */               jjCheckNAddStates(22, 24);
/*      */             break;
/*      */           case 30: 
/*  603 */             if ((0x280000000000 & l) != 0L)
/*  604 */               jjCheckNAdd(31);
/*      */             break;
/*      */           case 31: 
/*  607 */             if ((0x3FF000000000000 & l) != 0L)
/*  608 */               jjCheckNAddTwoStates(31, 10);
/*      */             break;
/*      */           case 32: 
/*  611 */             if (this.curChar == '-')
/*  612 */               jjAddStates(13, 15);
/*      */             break;
/*      */           case 33: 
/*  615 */             if ((this.curChar == '8') && (kind > 31))
/*  616 */               kind = 31;
/*      */             break;
/*      */           case 34: 
/*  619 */             if (this.curChar == '0')
/*  620 */               this.jjstateSet[(this.jjnewStateCnt++)] = 33;
/*      */             break;
/*      */           case 35: 
/*  623 */             if (this.curChar == '8')
/*  624 */               this.jjstateSet[(this.jjnewStateCnt++)] = 34;
/*      */             break;
/*      */           case 36: 
/*  627 */             if (this.curChar == '5')
/*  628 */               this.jjstateSet[(this.jjnewStateCnt++)] = 35;
/*      */             break;
/*      */           case 37: 
/*  631 */             if (this.curChar == '7')
/*  632 */               this.jjstateSet[(this.jjnewStateCnt++)] = 36;
/*      */             break;
/*      */           case 38: 
/*  635 */             if (this.curChar == '7')
/*  636 */               this.jjstateSet[(this.jjnewStateCnt++)] = 37;
/*      */             break;
/*      */           case 39: 
/*  639 */             if (this.curChar == '4')
/*  640 */               this.jjstateSet[(this.jjnewStateCnt++)] = 38;
/*      */             break;
/*      */           case 40: 
/*  643 */             if (this.curChar == '5')
/*  644 */               this.jjstateSet[(this.jjnewStateCnt++)] = 39;
/*      */             break;
/*      */           case 41: 
/*  647 */             if (this.curChar == '8')
/*  648 */               this.jjstateSet[(this.jjnewStateCnt++)] = 40;
/*      */             break;
/*      */           case 42: 
/*  651 */             if (this.curChar == '6')
/*  652 */               this.jjstateSet[(this.jjnewStateCnt++)] = 41;
/*      */             break;
/*      */           case 43: 
/*  655 */             if (this.curChar == '3')
/*  656 */               this.jjstateSet[(this.jjnewStateCnt++)] = 42;
/*      */             break;
/*      */           case 44: 
/*  659 */             if (this.curChar == '0')
/*  660 */               this.jjstateSet[(this.jjnewStateCnt++)] = 43;
/*      */             break;
/*      */           case 45: 
/*  663 */             if (this.curChar == '2')
/*  664 */               this.jjstateSet[(this.jjnewStateCnt++)] = 44;
/*      */             break;
/*      */           case 46: 
/*  667 */             if (this.curChar == '7')
/*  668 */               this.jjstateSet[(this.jjnewStateCnt++)] = 45;
/*      */             break;
/*      */           case 47: 
/*  671 */             if (this.curChar == '3')
/*  672 */               this.jjstateSet[(this.jjnewStateCnt++)] = 46;
/*      */             break;
/*      */           case 48: 
/*  675 */             if (this.curChar == '3')
/*  676 */               this.jjstateSet[(this.jjnewStateCnt++)] = 47;
/*      */             break;
/*      */           case 49: 
/*  679 */             if (this.curChar == '2')
/*  680 */               this.jjstateSet[(this.jjnewStateCnt++)] = 48;
/*      */             break;
/*      */           case 50: 
/*  683 */             if (this.curChar == '2')
/*  684 */               this.jjstateSet[(this.jjnewStateCnt++)] = 49;
/*      */             break;
/*      */           case 51: 
/*  687 */             if (this.curChar == '9')
/*  688 */               this.jjstateSet[(this.jjnewStateCnt++)] = 50;
/*      */             break;
/*      */           case 53: 
/*  691 */             if (this.curChar == '8')
/*  692 */               this.jjstateSet[(this.jjnewStateCnt++)] = 52;
/*      */             break;
/*      */           case 54: 
/*  695 */             if (this.curChar == '0')
/*  696 */               this.jjstateSet[(this.jjnewStateCnt++)] = 53;
/*      */             break;
/*      */           case 55: 
/*  699 */             if (this.curChar == '8')
/*  700 */               this.jjstateSet[(this.jjnewStateCnt++)] = 54;
/*      */             break;
/*      */           case 56: 
/*  703 */             if (this.curChar == '5')
/*  704 */               this.jjstateSet[(this.jjnewStateCnt++)] = 55;
/*      */             break;
/*      */           case 57: 
/*  707 */             if (this.curChar == '7')
/*  708 */               this.jjstateSet[(this.jjnewStateCnt++)] = 56;
/*      */             break;
/*      */           case 58: 
/*  711 */             if (this.curChar == '7')
/*  712 */               this.jjstateSet[(this.jjnewStateCnt++)] = 57;
/*      */             break;
/*      */           case 59: 
/*  715 */             if (this.curChar == '4')
/*  716 */               this.jjstateSet[(this.jjnewStateCnt++)] = 58;
/*      */             break;
/*      */           case 60: 
/*  719 */             if (this.curChar == '5')
/*  720 */               this.jjstateSet[(this.jjnewStateCnt++)] = 59;
/*      */             break;
/*      */           case 61: 
/*  723 */             if (this.curChar == '8')
/*  724 */               this.jjstateSet[(this.jjnewStateCnt++)] = 60;
/*      */             break;
/*      */           case 62: 
/*  727 */             if (this.curChar == '6')
/*  728 */               this.jjstateSet[(this.jjnewStateCnt++)] = 61;
/*      */             break;
/*      */           case 63: 
/*  731 */             if (this.curChar == '3')
/*  732 */               this.jjstateSet[(this.jjnewStateCnt++)] = 62;
/*      */             break;
/*      */           case 64: 
/*  735 */             if (this.curChar == '0')
/*  736 */               this.jjstateSet[(this.jjnewStateCnt++)] = 63;
/*      */             break;
/*      */           case 65: 
/*  739 */             if (this.curChar == '2')
/*  740 */               this.jjstateSet[(this.jjnewStateCnt++)] = 64;
/*      */             break;
/*      */           case 66: 
/*  743 */             if (this.curChar == '7')
/*  744 */               this.jjstateSet[(this.jjnewStateCnt++)] = 65;
/*      */             break;
/*      */           case 67: 
/*  747 */             if (this.curChar == '3')
/*  748 */               this.jjstateSet[(this.jjnewStateCnt++)] = 66;
/*      */             break;
/*      */           case 68: 
/*  751 */             if (this.curChar == '3')
/*  752 */               this.jjstateSet[(this.jjnewStateCnt++)] = 67;
/*      */             break;
/*      */           case 69: 
/*  755 */             if (this.curChar == '2')
/*  756 */               this.jjstateSet[(this.jjnewStateCnt++)] = 68;
/*      */             break;
/*      */           case 70: 
/*  759 */             if (this.curChar == '2')
/*  760 */               this.jjstateSet[(this.jjnewStateCnt++)] = 69;
/*      */             break;
/*      */           case 71: 
/*  763 */             if (this.curChar == '9')
/*  764 */               this.jjstateSet[(this.jjnewStateCnt++)] = 70;
/*      */             break;
/*      */           case 73: 
/*  767 */             if (this.curChar == '8')
/*  768 */               this.jjstateSet[(this.jjnewStateCnt++)] = 72;
/*      */             break;
/*      */           case 74: 
/*  771 */             if (this.curChar == '0')
/*  772 */               this.jjstateSet[(this.jjnewStateCnt++)] = 73;
/*      */             break;
/*      */           case 75: 
/*  775 */             if (this.curChar == '8')
/*  776 */               this.jjstateSet[(this.jjnewStateCnt++)] = 74;
/*      */             break;
/*      */           case 76: 
/*  779 */             if (this.curChar == '5')
/*  780 */               this.jjstateSet[(this.jjnewStateCnt++)] = 75;
/*      */             break;
/*      */           case 77: 
/*  783 */             if (this.curChar == '7')
/*  784 */               this.jjstateSet[(this.jjnewStateCnt++)] = 76;
/*      */             break;
/*      */           case 78: 
/*  787 */             if (this.curChar == '7')
/*  788 */               this.jjstateSet[(this.jjnewStateCnt++)] = 77;
/*      */             break;
/*      */           case 79: 
/*  791 */             if (this.curChar == '4')
/*  792 */               this.jjstateSet[(this.jjnewStateCnt++)] = 78;
/*      */             break;
/*      */           case 80: 
/*  795 */             if (this.curChar == '5')
/*  796 */               this.jjstateSet[(this.jjnewStateCnt++)] = 79;
/*      */             break;
/*      */           case 81: 
/*  799 */             if (this.curChar == '8')
/*  800 */               this.jjstateSet[(this.jjnewStateCnt++)] = 80;
/*      */             break;
/*      */           case 82: 
/*  803 */             if (this.curChar == '6')
/*  804 */               this.jjstateSet[(this.jjnewStateCnt++)] = 81;
/*      */             break;
/*      */           case 83: 
/*  807 */             if (this.curChar == '3')
/*  808 */               this.jjstateSet[(this.jjnewStateCnt++)] = 82;
/*      */             break;
/*      */           case 84: 
/*  811 */             if (this.curChar == '0')
/*  812 */               this.jjstateSet[(this.jjnewStateCnt++)] = 83;
/*      */             break;
/*      */           case 85: 
/*  815 */             if (this.curChar == '2')
/*  816 */               this.jjstateSet[(this.jjnewStateCnt++)] = 84;
/*      */             break;
/*      */           case 86: 
/*  819 */             if (this.curChar == '7')
/*  820 */               this.jjstateSet[(this.jjnewStateCnt++)] = 85;
/*      */             break;
/*      */           case 87: 
/*  823 */             if (this.curChar == '3')
/*  824 */               this.jjstateSet[(this.jjnewStateCnt++)] = 86;
/*      */             break;
/*      */           case 88: 
/*  827 */             if (this.curChar == '3')
/*  828 */               this.jjstateSet[(this.jjnewStateCnt++)] = 87;
/*      */             break;
/*      */           case 89: 
/*  831 */             if (this.curChar == '2')
/*  832 */               this.jjstateSet[(this.jjnewStateCnt++)] = 88;
/*      */             break;
/*      */           case 90: 
/*  835 */             if (this.curChar == '2')
/*  836 */               this.jjstateSet[(this.jjnewStateCnt++)] = 89;
/*      */             break;
/*      */           case 91: 
/*  839 */             if (this.curChar == '9')
/*  840 */               this.jjstateSet[(this.jjnewStateCnt++)] = 90;
/*      */             break;
/*      */           case 92: 
/*  843 */             if (this.curChar == '0')
/*      */             {
/*  845 */               if (kind > 31)
/*  846 */                 kind = 31;
/*  847 */               jjCheckNAddStates(10, 12); }
/*  848 */             break;
/*      */           case 94: 
/*  850 */             if ((0x3FF000000000000 & l) != 0L)
/*      */             {
/*  852 */               if (kind > 31)
/*  853 */                 kind = 31;
/*  854 */               jjCheckNAddTwoStates(94, 2); }
/*  855 */             break;
/*      */           case 95: 
/*  857 */             if ((0xFF000000000000 & l) != 0L)
/*      */             {
/*  859 */               if (kind > 31)
/*  860 */                 kind = 31;
/*  861 */               jjCheckNAddTwoStates(95, 2);
/*      */             }
/*      */             break;
/*      */           }
/*  865 */         } while (i != startsAt);
/*      */       }
/*  867 */       else if (this.curChar < '')
/*      */       {
/*  869 */         long l = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/*  872 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 0: 
/*      */           case 22: 
/*  876 */             if ((0x7FFFFFE87FFFFFE & l) != 0L)
/*      */             {
/*  878 */               if (kind > 38)
/*  879 */                 kind = 38;
/*  880 */               jjCheckNAdd(22); }
/*  881 */             break;
/*      */           case 2: 
/*  883 */             if (((0x100000001000 & l) != 0L) && (kind > 31))
/*  884 */               kind = 31;
/*      */             break;
/*      */           case 7: 
/*  887 */             if ((0x2000000020 & l) != 0L)
/*  888 */               jjAddStates(25, 26);
/*      */             break;
/*      */           case 10: 
/*  891 */             if (((0x5000000050 & l) != 0L) && (kind > 35))
/*  892 */               kind = 35;
/*      */             break;
/*      */           case 13: 
/*  895 */             if ((0x2000000020 & l) != 0L)
/*  896 */               jjAddStates(27, 28);
/*      */             break;
/*      */           case 17: 
/*  899 */             jjAddStates(7, 9);
/*  900 */             break;
/*      */           case 25: 
/*  902 */             if ((0x2000000020 & l) != 0L)
/*  903 */               jjAddStates(29, 30);
/*      */             break;
/*      */           case 29: 
/*  906 */             if ((0x2000000020 & l) != 0L)
/*  907 */               jjAddStates(31, 32);
/*      */             break;
/*      */           case 52: 
/*  910 */             if ((this.curChar == 'l') && (kind > 31))
/*  911 */               kind = 31;
/*      */             break;
/*      */           case 72: 
/*  914 */             if ((this.curChar == 'L') && (kind > 31))
/*  915 */               kind = 31;
/*      */             break;
/*      */           case 93: 
/*  918 */             if ((0x100000001000000 & l) != 0L)
/*  919 */               jjCheckNAdd(94);
/*      */             break;
/*      */           case 94: 
/*  922 */             if ((0x7E0000007E & l) != 0L)
/*      */             {
/*  924 */               if (kind > 31)
/*  925 */                 kind = 31;
/*  926 */               jjCheckNAddTwoStates(94, 2);
/*      */             }
/*      */             break;
/*      */           }
/*  930 */         } while (i != startsAt);
/*      */       }
/*      */       else
/*      */       {
/*  934 */         int hiByte = this.curChar >> '\b';
/*  935 */         int i1 = hiByte >> 6;
/*  936 */         long l1 = 1L << (hiByte & 0x3F);
/*  937 */         int i2 = (this.curChar & 0xFF) >> '\006';
/*  938 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         do
/*      */         {
/*  941 */           switch (this.jjstateSet[(--i)])
/*      */           {
/*      */           case 17: 
/*  944 */             if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/*  945 */               jjAddStates(7, 9);
/*      */             }
/*      */             break;
/*      */           }
/*  949 */         } while (i != startsAt);
/*      */       }
/*  951 */       if (kind != Integer.MAX_VALUE)
/*      */       {
/*  953 */         this.jjmatchedKind = kind;
/*  954 */         this.jjmatchedPos = curPos;
/*  955 */         kind = Integer.MAX_VALUE;
/*      */       }
/*  957 */       curPos++;
/*  958 */       if ((i = this.jjnewStateCnt) != (startsAt = 96 - (this.jjnewStateCnt = startsAt)))
/*      */         try {
/*  960 */           this.curChar = this.input_stream.readChar();
/*      */         } catch (IOException e) {}
/*      */     }
/*  963 */     if (this.jjmatchedPos > strPos) {
/*  964 */       return curPos;
/*      */     }
/*  966 */     int toRet = Math.max(curPos, seenUpto);
/*      */     
/*  968 */     if (curPos < toRet)
/*  969 */       for (i = toRet - Math.min(curPos, seenUpto); i-- > 0;)
/*  970 */         try { this.curChar = this.input_stream.readChar();
/*  971 */         } catch (IOException e) { throw new Error("Internal Error : Please send a bug report.");
/*      */         }
/*  973 */     if (this.jjmatchedPos < strPos)
/*      */     {
/*  975 */       this.jjmatchedKind = strKind;
/*  976 */       this.jjmatchedPos = strPos;
/*      */     }
/*  978 */     else if ((this.jjmatchedPos == strPos) && (this.jjmatchedKind > strKind)) {
/*  979 */       this.jjmatchedKind = strKind;
/*      */     }
/*  981 */     return toRet; }
/*      */   
/*  983 */   static final int[] jjnextStates = { 4, 5, 24, 25, 28, 29, 10, 17, 19, 20, 93, 95, 2, 51, 71, 91, 6, 7, 10, 12, 13, 10, 28, 29, 10, 8, 9, 14, 15, 26, 27, 30, 31 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2)
/*      */   {
/*  990 */     switch (hiByte)
/*      */     {
/*      */     case 0: 
/*  993 */       return (jjbitVec2[i2] & l2) != 0L;
/*      */     }
/*  995 */     if ((jjbitVec0[i1] & l1) != 0L)
/*  996 */       return true;
/*  997 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/* 1002 */   public static final String[] jjstrLiteralImages = { "", null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, "(", ")", ";", ",", "*", "/", "-", "+", ">", ">=", "<", "<=", "<>", "=", null, null, null, null, null, null, null, null, null, null };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1009 */   public static final String[] lexStateNames = { "DEFAULT" };
/*      */   
/*      */ 
/* 1012 */   static final long[] jjtoToken = { 450971566017L };
/*      */   
/*      */ 
/* 1015 */   static final long[] jjtoSkip = { 62L };
/*      */   
/*      */   protected SimpleCharStream input_stream;
/*      */   
/* 1019 */   private final int[] jjrounds = new int[96];
/* 1020 */   private final int[] jjstateSet = new int['À'];
/*      */   
/*      */   protected char curChar;
/*      */   
/*      */   public FilterParserTokenManager(SimpleCharStream stream)
/*      */   {
/* 1026 */     this.input_stream = stream;
/*      */   }
/*      */   
/*      */   public FilterParserTokenManager(SimpleCharStream stream, int lexState)
/*      */   {
/* 1031 */     this(stream);
/* 1032 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */ 
/*      */   public void ReInit(SimpleCharStream stream)
/*      */   {
/* 1038 */     this.jjmatchedPos = (this.jjnewStateCnt = 0);
/* 1039 */     this.curLexState = this.defaultLexState;
/* 1040 */     this.input_stream = stream;
/* 1041 */     ReInitRounds();
/*      */   }
/*      */   
/*      */   private void ReInitRounds()
/*      */   {
/* 1046 */     this.jjround = -2147483647;
/* 1047 */     for (int i = 96; i-- > 0;) {
/* 1048 */       this.jjrounds[i] = Integer.MIN_VALUE;
/*      */     }
/*      */   }
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState)
/*      */   {
/* 1054 */     ReInit(stream);
/* 1055 */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */ 
/*      */   public void SwitchTo(int lexState)
/*      */   {
/* 1061 */     if ((lexState >= 1) || (lexState < 0)) {
/* 1062 */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
/*      */     }
/* 1064 */     this.curLexState = lexState;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Token jjFillToken()
/*      */   {
/* 1075 */     String im = jjstrLiteralImages[this.jjmatchedKind];
/* 1076 */     String curTokenImage = im == null ? this.input_stream.GetImage() : im;
/* 1077 */     int beginLine = this.input_stream.getBeginLine();
/* 1078 */     int beginColumn = this.input_stream.getBeginColumn();
/* 1079 */     int endLine = this.input_stream.getEndLine();
/* 1080 */     int endColumn = this.input_stream.getEndColumn();
/* 1081 */     Token t = Token.newToken(this.jjmatchedKind, curTokenImage);
/*      */     
/* 1083 */     t.beginLine = beginLine;
/* 1084 */     t.endLine = endLine;
/* 1085 */     t.beginColumn = beginColumn;
/* 1086 */     t.endColumn = endColumn;
/*      */     
/* 1088 */     return t;
/*      */   }
/*      */   
/* 1091 */   int curLexState = 0;
/* 1092 */   int defaultLexState = 0;
/*      */   
/*      */   int jjnewStateCnt;
/*      */   
/*      */   int jjround;
/*      */   int jjmatchedPos;
/*      */   int jjmatchedKind;
/*      */   
/*      */   public Token getNextToken()
/*      */   {
/* 1102 */     int curPos = 0;
/*      */     
/*      */ 
/*      */     do
/*      */     {
/*      */       try
/*      */       {
/* 1109 */         this.curChar = this.input_stream.BeginToken();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/* 1113 */         this.jjmatchedKind = 0;
/* 1114 */         return jjFillToken();
/*      */       }
/*      */       
/*      */ 
/* 1118 */       this.jjmatchedKind = Integer.MAX_VALUE;
/* 1119 */       this.jjmatchedPos = 0;
/* 1120 */       curPos = jjMoveStringLiteralDfa0_0();
/* 1121 */       if (this.jjmatchedKind == Integer.MAX_VALUE)
/*      */         break;
/* 1123 */       if (this.jjmatchedPos + 1 < curPos)
/* 1124 */         this.input_stream.backup(curPos - this.jjmatchedPos - 1);
/* 1125 */     } while ((jjtoToken[(this.jjmatchedKind >> 6)] & 1L << (this.jjmatchedKind & 0x3F)) == 0L);
/*      */     
/* 1127 */     Token matchedToken = jjFillToken();
/* 1128 */     return matchedToken;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1135 */     int error_line = this.input_stream.getEndLine();
/* 1136 */     int error_column = this.input_stream.getEndColumn();
/* 1137 */     String error_after = null;
/* 1138 */     boolean EOFSeen = false;
/* 1139 */     try { this.input_stream.readChar();this.input_stream.backup(1);
/*      */     } catch (IOException e1) {
/* 1141 */       EOFSeen = true;
/* 1142 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/* 1143 */       if ((this.curChar == '\n') || (this.curChar == '\r')) {
/* 1144 */         error_line++;
/* 1145 */         error_column = 0;
/*      */       }
/*      */       else {
/* 1148 */         error_column++;
/*      */       } }
/* 1150 */     if (!EOFSeen) {
/* 1151 */       this.input_stream.backup(1);
/* 1152 */       error_after = curPos <= 1 ? "" : this.input_stream.GetImage();
/*      */     }
/* 1154 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */   
/*      */ 
/*      */   private void jjCheckNAdd(int state)
/*      */   {
/* 1160 */     if (this.jjrounds[state] != this.jjround)
/*      */     {
/* 1162 */       this.jjstateSet[(this.jjnewStateCnt++)] = state;
/* 1163 */       this.jjrounds[state] = this.jjround;
/*      */     }
/*      */   }
/*      */   
/*      */   private void jjAddStates(int start, int end) {
/*      */     do {
/* 1169 */       this.jjstateSet[(this.jjnewStateCnt++)] = jjnextStates[start];
/* 1170 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddTwoStates(int state1, int state2) {
/* 1174 */     jjCheckNAdd(state1);
/* 1175 */     jjCheckNAdd(state2);
/*      */   }
/*      */   
/*      */   private void jjCheckNAddStates(int start, int end)
/*      */   {
/*      */     do {
/* 1181 */       jjCheckNAdd(jjnextStates[start]);
/* 1182 */     } while (start++ != end);
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\FilterParserTokenManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */