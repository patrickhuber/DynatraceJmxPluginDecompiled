/*    */ package org.hornetq.core.filter.impl;
/*    */ 
/*    */ import org.hornetq.api.core.SimpleString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Identifier
/*    */ {
/*    */   private final SimpleString name;
/*    */   private final int hash;
/*    */   private Object value;
/*    */   
/*    */   public Identifier(SimpleString name)
/*    */   {
/* 48 */     this.name = name;
/*    */     
/* 50 */     this.hash = name.hashCode();
/*    */     
/* 52 */     this.value = null;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 58 */     return "Identifier@" + this.name;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 64 */     if (!(obj instanceof Identifier))
/*    */     {
/* 66 */       return false;
/*    */     }
/* 68 */     if (obj.hashCode() != this.hash)
/*    */     {
/* 70 */       return false;
/*    */     }
/* 72 */     return ((Identifier)obj).name.equals(this.name);
/*    */   }
/*    */   
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 78 */     return this.hash;
/*    */   }
/*    */   
/*    */   public SimpleString getName()
/*    */   {
/* 83 */     return this.name;
/*    */   }
/*    */   
/*    */   public Object getValue()
/*    */   {
/* 88 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(Object value)
/*    */   {
/* 93 */     this.value = value;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\Identifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */