/*      */ package org.hornetq.core.filter.impl;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.hornetq.api.core.SimpleString;
/*      */ 
/*      */ public class FilterParser implements FilterParserConstants
/*      */ {
/*      */   private static final String LOFFER_L = "l";
/*      */   private static final String UPPER_L = "L";
/*      */   private static final String OX = "0X";
/*      */   private static final String Ox = "0x";
/*      */   private static final String ZERRO = "0";
/*      */   private Map<SimpleString, Identifier> identifierMap;
/*      */   public FilterParserTokenManager token_source;
/*      */   SimpleCharStream jj_input_stream;
/*      */   public Token token;
/*      */   public Token jj_nt;
/*      */   private int jj_ntk;
/*      */   private Token jj_scanpos;
/*      */   private Token jj_lastpos;
/*      */   private int jj_la;
/*      */   private int jj_gen;
/*      */   
/*      */   public FilterParser()
/*      */   {
/*   35 */     this(new StringReader(""));
/*      */   }
/*      */   
/*      */   public Object parse(SimpleString selector, Map<SimpleString, Identifier> identifierMap)
/*      */     throws ParseException
/*      */   {
/*   41 */     return parse(selector, identifierMap, false);
/*      */   }
/*      */   
/*      */   public Object parse(SimpleString selector, Map<SimpleString, Identifier> identifierMap, boolean trace)
/*      */     throws ParseException
/*      */   {
/*   47 */     SimpleStringReader sr = new SimpleStringReader(selector);
/*   48 */     ReInit(sr);
/*      */     
/*      */ 
/*   51 */     if (trace)
/*      */     {
/*   53 */       enable_tracing();
/*      */     }
/*      */     else
/*      */     {
/*   57 */       disable_tracing();
/*      */     }
/*      */     
/*   60 */     this.identifierMap = identifierMap;
/*   61 */     return expression();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private SimpleString stripQuotes(String image)
/*      */   {
/*   70 */     StringBuffer result = new StringBuffer(image.length() - 2);
/*   71 */     int i = 1;
/*   72 */     boolean escaped = false;
/*   73 */     while (i < image.length() - 1)
/*      */     {
/*   75 */       if (escaped)
/*      */       {
/*   77 */         if (image.charAt(i) == '\'') {
/*   78 */           result.append('\'');
/*      */         } else
/*   80 */           throw new RuntimeException("Invalid uses of quotes: " + image);
/*   81 */         escaped = false;
/*      */       }
/*   83 */       else if (image.charAt(i) == '\'') {
/*   84 */         escaped = true;
/*      */       } else {
/*   86 */         result.append(image.charAt(i)); }
/*   87 */       i++;
/*      */     }
/*   89 */     return new SimpleString(result.toString());
/*      */   }
/*      */   
/*      */   public static Object doParse(SimpleString selector, Map<SimpleString, Identifier> identifierMap)
/*      */     throws ParseException
/*      */   {
/*   95 */     return doParse(selector, identifierMap, false);
/*      */   }
/*      */   
/*      */   public static Object doParse(SimpleString selector, Map<SimpleString, Identifier> identifierMap, boolean trace)
/*      */     throws ParseException
/*      */   {
/*  101 */     FilterParser parser = new FilterParser();
/*  102 */     return parser.parse(selector, identifierMap, trace);
/*      */   }
/*      */   
/*      */   public final Object expression() throws ParseException
/*      */   {
/*  107 */     Object exp1 = null;
/*  108 */     exp1 = selectorExpression();
/*  109 */     jj_consume_token(0);
/*  110 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object selectorExpression() throws ParseException
/*      */   {
/*  115 */     Object exp1 = null;
/*  116 */     Object exp2 = null;
/*  117 */     exp1 = selectorTerm();
/*      */     for (;;)
/*      */     {
/*  120 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk)
/*      */       {
/*      */       case 11: 
/*      */         break;
/*      */       default: 
/*  125 */         this.jj_la1[0] = this.jj_gen;
/*  126 */         break;
/*      */       }
/*  128 */       jj_consume_token(11);
/*  129 */       exp2 = selectorTerm();
/*  130 */       exp1 = new Operator(3, exp1, exp2);
/*      */     }
/*  132 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object selectorTerm() throws ParseException
/*      */   {
/*  137 */     Object exp1 = null;
/*  138 */     Object exp2 = null;
/*  139 */     exp1 = selectorFactor();
/*      */     for (;;)
/*      */     {
/*  142 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk)
/*      */       {
/*      */       case 9: 
/*      */         break;
/*      */       default: 
/*  147 */         this.jj_la1[1] = this.jj_gen;
/*  148 */         break;
/*      */       }
/*  150 */       jj_consume_token(9);
/*  151 */       exp2 = selectorFactor();
/*  152 */       exp1 = new Operator(2, exp1, exp2);
/*      */     }
/*  154 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object selectorFactor() throws ParseException
/*      */   {
/*  159 */     Object exp1 = null;
/*  160 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 17: 
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 31: 
/*      */     case 35: 
/*      */     case 37: 
/*      */     case 38: 
/*  170 */       exp1 = conditionalExpression();
/*  171 */       return exp1;
/*      */     
/*      */     case 10: 
/*  174 */       jj_consume_token(10);
/*  175 */       exp1 = conditionalExpression();
/*  176 */       exp1 = new Operator(1, exp1);
/*  177 */       return exp1;
/*      */     }
/*      */     
/*  180 */     this.jj_la1[2] = this.jj_gen;
/*  181 */     jj_consume_token(-1);
/*  182 */     throw new ParseException();
/*      */   }
/*      */   
/*      */   public final Object conditionalExpression()
/*      */     throws ParseException
/*      */   {
/*  188 */     Object exp1 = null;
/*  189 */     if (jj_2_1(3)) {
/*  190 */       jj_consume_token(17);
/*  191 */       exp1 = selectorExpression();
/*  192 */       jj_consume_token(18);
/*  193 */       return exp1;
/*      */     }
/*  195 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 17: 
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 31: 
/*      */     case 35: 
/*      */     case 37: 
/*      */     case 38: 
/*  205 */       exp1 = comparisonExpression();
/*  206 */       return exp1;
/*      */     }
/*      */     
/*  209 */     this.jj_la1[3] = this.jj_gen;
/*  210 */     jj_consume_token(-1);
/*  211 */     throw new ParseException();
/*      */   }
/*      */   
/*      */ 
/*      */   public final Object comparisonExpression()
/*      */     throws ParseException
/*      */   {
/*  218 */     int op = -1;
/*  219 */     Set set = null;
/*  220 */     Object exp1 = null;
/*  221 */     Object exp2 = null;
/*  222 */     Object exp3 = null;
/*  223 */     Object id = null;
/*  224 */     Token not = null;
/*  225 */     if (jj_2_2(Integer.MAX_VALUE)) {
/*  226 */       exp1 = identifier();
/*  227 */       jj_consume_token(15);
/*  228 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 10: 
/*  230 */         not = jj_consume_token(10);
/*  231 */         break;
/*      */       default: 
/*  233 */         this.jj_la1[4] = this.jj_gen;
/*      */       }
/*      */       
/*  236 */       jj_consume_token(8);
/*  237 */       int opCode = not == null ? 20 : 21;
/*  238 */       return new Operator(opCode, exp1); }
/*  239 */     if (jj_2_3(Integer.MAX_VALUE)) {
/*  240 */       id = identifier();
/*  241 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 10: 
/*  243 */         not = jj_consume_token(10);
/*  244 */         break;
/*      */       default: 
/*  246 */         this.jj_la1[5] = this.jj_gen;
/*      */       }
/*      */       
/*  249 */       jj_consume_token(14);
/*  250 */       jj_consume_token(17);
/*  251 */       set = new HashSet();
/*  252 */       stringList(set);
/*  253 */       jj_consume_token(18);
/*  254 */       if (not == null) {
/*  255 */         return new Operator(22, id, set);
/*      */       }
/*  257 */       return new Operator(23, id, set);
/*      */     }
/*  259 */     if (jj_2_4(Integer.MAX_VALUE)) {
/*  260 */       id = identifier();
/*  261 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 10: 
/*  263 */         not = jj_consume_token(10);
/*  264 */         break;
/*      */       default: 
/*  266 */         this.jj_la1[6] = this.jj_gen;
/*      */       }
/*      */       
/*  269 */       jj_consume_token(13);
/*  270 */       exp1 = patternExpression(id);
/*  271 */       if (not != null)
/*  272 */         exp1 = new Operator(1, exp1);
/*  273 */       return exp1; }
/*  274 */     if (jj_2_5(Integer.MAX_VALUE)) {
/*  275 */       exp1 = stringExpression();
/*  276 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 30: 
/*  278 */         jj_consume_token(30);
/*  279 */         op = 0;
/*  280 */         break;
/*      */       case 29: 
/*  282 */         jj_consume_token(29);
/*  283 */         op = 8;
/*  284 */         break;
/*      */       default: 
/*  286 */         this.jj_la1[7] = this.jj_gen;
/*  287 */         jj_consume_token(-1);
/*  288 */         throw new ParseException();
/*      */       }
/*  290 */       exp2 = stringExpression();
/*  291 */       return new Operator(op, exp1, exp2); }
/*  292 */     if (jj_2_6(Integer.MAX_VALUE)) {
/*  293 */       exp1 = booleanExpression();
/*  294 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 30: 
/*  296 */         jj_consume_token(30);
/*  297 */         op = 0;
/*  298 */         break;
/*      */       case 29: 
/*  300 */         jj_consume_token(29);
/*  301 */         op = 8;
/*  302 */         break;
/*      */       default: 
/*  304 */         this.jj_la1[8] = this.jj_gen;
/*  305 */         jj_consume_token(-1);
/*  306 */         throw new ParseException();
/*      */       }
/*  308 */       exp2 = booleanExpression();
/*  309 */       return new Operator(op, exp1, exp2); }
/*  310 */     if (jj_2_7(Integer.MAX_VALUE)) {
/*  311 */       exp1 = arithExpression();
/*  312 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 30: 
/*  314 */         jj_consume_token(30);
/*  315 */         op = 0;
/*  316 */         break;
/*      */       case 29: 
/*  318 */         jj_consume_token(29);
/*  319 */         op = 8;
/*  320 */         break;
/*      */       case 25: 
/*  322 */         jj_consume_token(25);
/*  323 */         op = 4;
/*  324 */         break;
/*      */       case 26: 
/*  326 */         jj_consume_token(26);
/*  327 */         op = 5;
/*  328 */         break;
/*      */       case 27: 
/*  330 */         jj_consume_token(27);
/*  331 */         op = 6;
/*  332 */         break;
/*      */       case 28: 
/*  334 */         jj_consume_token(28);
/*  335 */         op = 7;
/*  336 */         break;
/*      */       default: 
/*  338 */         this.jj_la1[9] = this.jj_gen;
/*  339 */         jj_consume_token(-1);
/*  340 */         throw new ParseException();
/*      */       }
/*  342 */       exp2 = arithExpression();
/*  343 */       return new Operator(op, exp1, exp2); }
/*  344 */     if (jj_2_8(Integer.MAX_VALUE)) {
/*  345 */       exp1 = arithExpression();
/*  346 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 10: 
/*  348 */         not = jj_consume_token(10);
/*  349 */         break;
/*      */       default: 
/*  351 */         this.jj_la1[10] = this.jj_gen;
/*      */       }
/*      */       
/*  354 */       jj_consume_token(12);
/*  355 */       exp2 = arithExpression();
/*  356 */       jj_consume_token(9);
/*  357 */       exp3 = arithExpression();
/*  358 */       exp1 = new Operator(14, exp1, exp2, exp3);
/*  359 */       if (not != null)
/*  360 */         exp1 = new Operator(1, exp1);
/*  361 */       return exp1;
/*      */     }
/*  363 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 38: 
/*  367 */       exp1 = booleanExpression();
/*  368 */       return exp1;
/*      */     }
/*      */     
/*  371 */     this.jj_la1[11] = this.jj_gen;
/*  372 */     jj_consume_token(-1);
/*  373 */     throw new ParseException();
/*      */   }
/*      */   
/*      */ 
/*      */   public final void stringList(Set<SimpleString> set)
/*      */     throws ParseException
/*      */   {
/*  380 */     stringToken(set);
/*      */     for (;;)
/*      */     {
/*  383 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk)
/*      */       {
/*      */       case 20: 
/*      */         break;
/*      */       default: 
/*  388 */         this.jj_la1[12] = this.jj_gen;
/*  389 */         break;
/*      */       }
/*  391 */       jj_consume_token(20);
/*  392 */       stringToken(set);
/*      */     }
/*      */   }
/*      */   
/*      */   public final void stringToken(Set<SimpleString> set) throws ParseException {
/*  397 */     Token t = null;
/*  398 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 37: 
/*  400 */       t = jj_consume_token(37);
/*  401 */       break;
/*      */     default: 
/*  403 */       this.jj_la1[13] = this.jj_gen;
/*      */     }
/*      */     
/*  406 */     if (t != null)
/*  407 */       set.add(stripQuotes(t.image));
/*      */   }
/*      */   
/*      */   public final Object patternExpression(Object exp1) throws ParseException {
/*  411 */     Object exp2 = null;
/*  412 */     Token esc = null;
/*  413 */     Object escChar = null;
/*  414 */     exp2 = stringLiteral();
/*  415 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 16: 
/*  417 */       esc = jj_consume_token(16);
/*  418 */       escChar = stringLiteral();
/*  419 */       break;
/*      */     default: 
/*  421 */       this.jj_la1[14] = this.jj_gen;
/*      */     }
/*      */     
/*  424 */     Operator op = null;
/*  425 */     if (esc == null) {
/*  426 */       op = new Operator(16, exp1, exp2);
/*      */     } else
/*  428 */       op = new Operator(18, exp1, exp2, escChar);
/*  429 */     return op;
/*      */   }
/*      */   
/*      */   public final Object arithExpression() throws ParseException
/*      */   {
/*  434 */     Object exp1 = null;
/*  435 */     Object exp2 = null;
/*  436 */     exp1 = arithTerm();
/*      */     for (;;)
/*      */     {
/*  439 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk)
/*      */       {
/*      */       case 23: 
/*      */       case 24: 
/*      */         break;
/*      */       default: 
/*  445 */         this.jj_la1[15] = this.jj_gen;
/*  446 */         break;
/*      */       }
/*  448 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 24: 
/*  450 */         jj_consume_token(24);
/*  451 */         exp2 = arithTerm();
/*  452 */         exp1 = new Operator(9, exp1, exp2);
/*  453 */         break;
/*      */       case 23: 
/*  455 */         jj_consume_token(23);
/*  456 */         exp2 = arithTerm();
/*  457 */         exp1 = new Operator(10, exp1, exp2);
/*      */       }
/*      */     }
/*  460 */     this.jj_la1[16] = this.jj_gen;
/*  461 */     jj_consume_token(-1);
/*  462 */     throw new ParseException();
/*      */     
/*      */ 
/*  465 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object arithTerm() throws ParseException
/*      */   {
/*  470 */     Object exp1 = null;
/*  471 */     Object exp2 = null;
/*  472 */     exp1 = arithFactor();
/*      */     for (;;)
/*      */     {
/*  475 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk)
/*      */       {
/*      */       case 21: 
/*      */       case 22: 
/*      */         break;
/*      */       default: 
/*  481 */         this.jj_la1[17] = this.jj_gen;
/*  482 */         break;
/*      */       }
/*  484 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 21: 
/*  486 */         jj_consume_token(21);
/*  487 */         exp2 = arithFactor();
/*  488 */         exp1 = new Operator(12, exp1, exp2);
/*  489 */         break;
/*      */       case 22: 
/*  491 */         jj_consume_token(22);
/*  492 */         exp2 = arithFactor();
/*  493 */         exp1 = new Operator(13, exp1, exp2);
/*      */       }
/*      */     }
/*  496 */     this.jj_la1[18] = this.jj_gen;
/*  497 */     jj_consume_token(-1);
/*  498 */     throw new ParseException();
/*      */     
/*      */ 
/*  501 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object arithFactor() throws ParseException
/*      */   {
/*  506 */     Object exp1 = null;
/*  507 */     boolean negate = false;
/*  508 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 23: 
/*      */     case 24: 
/*  511 */       switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */       case 24: 
/*  513 */         jj_consume_token(24);
/*  514 */         break;
/*      */       case 23: 
/*  516 */         jj_consume_token(23);
/*  517 */         negate = true;
/*  518 */         break;
/*      */       default: 
/*  520 */         this.jj_la1[19] = this.jj_gen;
/*  521 */         jj_consume_token(-1);
/*  522 */         throw new ParseException();
/*      */       }
/*      */       break;
/*      */     default: 
/*  526 */       this.jj_la1[20] = this.jj_gen;
/*      */     }
/*      */     
/*  529 */     exp1 = numericExpression();
/*  530 */     if (negate)
/*  531 */       exp1 = new Operator(11, exp1);
/*  532 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object booleanExpression() throws ParseException
/*      */   {
/*  537 */     Object exp1 = null;
/*  538 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 38: 
/*  540 */       exp1 = identifier();
/*  541 */       break;
/*      */     case 6: 
/*      */     case 7: 
/*  544 */       exp1 = booleanLiteral();
/*  545 */       break;
/*      */     default: 
/*  547 */       this.jj_la1[21] = this.jj_gen;
/*  548 */       jj_consume_token(-1);
/*  549 */       throw new ParseException();
/*      */     }
/*  551 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object booleanLiteral() throws ParseException
/*      */   {
/*  556 */     boolean isTrue = true;
/*  557 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 6: 
/*  559 */       jj_consume_token(6);
/*  560 */       break;
/*      */     case 7: 
/*  562 */       jj_consume_token(7);
/*  563 */       isTrue = false;
/*  564 */       break;
/*      */     default: 
/*  566 */       this.jj_la1[22] = this.jj_gen;
/*  567 */       jj_consume_token(-1);
/*  568 */       throw new ParseException();
/*      */     }
/*  570 */     if (isTrue) {
/*  571 */       return Boolean.TRUE;
/*      */     }
/*  573 */     return Boolean.FALSE;
/*      */   }
/*      */   
/*      */   public final Object stringExpression() throws ParseException
/*      */   {
/*  578 */     Object exp1 = null;
/*  579 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 38: 
/*  581 */       exp1 = identifier();
/*  582 */       break;
/*      */     case 37: 
/*  584 */       exp1 = stringLiteral();
/*  585 */       break;
/*      */     default: 
/*  587 */       this.jj_la1[23] = this.jj_gen;
/*  588 */       jj_consume_token(-1);
/*  589 */       throw new ParseException();
/*      */     }
/*  591 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object stringLiteral() throws ParseException
/*      */   {
/*  596 */     Token string = null;
/*  597 */     string = jj_consume_token(37);
/*  598 */     return stripQuotes(string.image);
/*      */   }
/*      */   
/*      */   public final Object numericExpression() throws ParseException
/*      */   {
/*  603 */     Object exp1 = null;
/*  604 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 31: 
/*      */     case 35: 
/*  607 */       exp1 = numericLiteral();
/*  608 */       break;
/*      */     case 17: 
/*  610 */       jj_consume_token(17);
/*  611 */       exp1 = arithExpression();
/*  612 */       jj_consume_token(18);
/*  613 */       break;
/*      */     case 38: 
/*  615 */       exp1 = identifier();
/*  616 */       break;
/*      */     default: 
/*  618 */       this.jj_la1[24] = this.jj_gen;
/*  619 */       jj_consume_token(-1);
/*  620 */       throw new ParseException();
/*      */     }
/*  622 */     return exp1;
/*      */   }
/*      */   
/*      */   public final Object numericLiteral() throws ParseException
/*      */   {
/*  627 */     Token literal = null;
/*  628 */     switch (this.jj_ntk == -1 ? jj_ntk() : this.jj_ntk) {
/*      */     case 35: 
/*  630 */       literal = jj_consume_token(35);
/*  631 */       return Double.valueOf(literal.image);
/*      */     
/*      */     case 31: 
/*  634 */       literal = jj_consume_token(31);
/*  635 */       String number = literal.image;
/*      */       
/*      */ 
/*  638 */       if ((number.endsWith("l")) || (number.endsWith("L")))
/*      */       {
/*      */ 
/*  641 */         return Long.valueOf(number.substring(0, number.length() - 1));
/*      */       }
/*      */       
/*      */ 
/*  645 */       if ((number.startsWith("0X")) || (number.startsWith("0x")))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  650 */         if (number.length() == 18)
/*      */         {
/*  652 */           byte first = Byte.decode(number.substring(0, 3)).byteValue();
/*  653 */           if (first >= 8)
/*      */           {
/*  655 */             number = "0x" + (first - 8) + number.substring(3);
/*  656 */             return Long.valueOf(Long.decode(number).longValue() - Long.MAX_VALUE - 1L);
/*      */           }
/*      */         }
/*      */       }
/*  660 */       else if (number.startsWith("0"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  667 */         if (number.length() == 23)
/*      */         {
/*  669 */           if (number.charAt(1) == '1')
/*      */           {
/*  671 */             number = "0" + number.substring(2);
/*  672 */             return Long.valueOf(Long.decode(number).longValue() - Long.MAX_VALUE - 1L);
/*      */           }
/*      */         }
/*      */       }
/*  676 */       return Long.decode(number);
/*      */     }
/*      */     
/*  679 */     this.jj_la1[25] = this.jj_gen;
/*  680 */     jj_consume_token(-1);
/*  681 */     throw new ParseException();
/*      */   }
/*      */   
/*      */   public final Object identifier()
/*      */     throws ParseException
/*      */   {
/*  687 */     Token id = null;
/*  688 */     id = jj_consume_token(38);
/*  689 */     SimpleString simage = new SimpleString(id.image);
/*  690 */     Identifier identifier = (Identifier)this.identifierMap.get(simage);
/*  691 */     if (identifier == null)
/*      */     {
/*  693 */       identifier = new Identifier(simage);
/*  694 */       this.identifierMap.put(simage, identifier);
/*      */     }
/*  696 */     return identifier;
/*      */   }
/*      */   
/*      */   private boolean jj_2_1(int xla)
/*      */   {
/*  701 */     this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  702 */     try { return !jj_3_1();
/*  703 */     } catch (LookaheadSuccess ls) { return true;
/*  704 */     } finally { jj_save(0, xla);
/*      */     }
/*      */   }
/*      */   
/*  708 */   private boolean jj_2_2(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  709 */     try { return !jj_3_2();
/*  710 */     } catch (LookaheadSuccess ls) { return true;
/*  711 */     } finally { jj_save(1, xla);
/*      */     }
/*      */   }
/*      */   
/*  715 */   private boolean jj_2_3(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  716 */     try { return !jj_3_3();
/*  717 */     } catch (LookaheadSuccess ls) { return true;
/*  718 */     } finally { jj_save(2, xla);
/*      */     }
/*      */   }
/*      */   
/*  722 */   private boolean jj_2_4(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  723 */     try { return !jj_3_4();
/*  724 */     } catch (LookaheadSuccess ls) { return true;
/*  725 */     } finally { jj_save(3, xla);
/*      */     }
/*      */   }
/*      */   
/*  729 */   private boolean jj_2_5(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  730 */     try { return !jj_3_5();
/*  731 */     } catch (LookaheadSuccess ls) { return true;
/*  732 */     } finally { jj_save(4, xla);
/*      */     }
/*      */   }
/*      */   
/*  736 */   private boolean jj_2_6(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  737 */     try { return !jj_3_6();
/*  738 */     } catch (LookaheadSuccess ls) { return true;
/*  739 */     } finally { jj_save(5, xla);
/*      */     }
/*      */   }
/*      */   
/*  743 */   private boolean jj_2_7(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  744 */     try { return !jj_3_7();
/*  745 */     } catch (LookaheadSuccess ls) { return true;
/*  746 */     } finally { jj_save(6, xla);
/*      */     }
/*      */   }
/*      */   
/*  750 */   private boolean jj_2_8(int xla) { this.jj_la = xla;this.jj_lastpos = (this.jj_scanpos = this.token);
/*  751 */     try { return !jj_3_8();
/*  752 */     } catch (LookaheadSuccess ls) { return true;
/*  753 */     } finally { jj_save(7, xla);
/*      */     }
/*      */   }
/*      */   
/*  757 */   private boolean jj_3R_36() { if (jj_scan_token(9)) return true;
/*  758 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_33() {
/*  762 */     if (jj_3R_38()) return true;
/*      */     Token xsp;
/*      */     do {
/*  765 */       xsp = this.jj_scanpos;
/*  766 */     } while (!jj_3R_39()); this.jj_scanpos = xsp;
/*      */     
/*  768 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_53() {
/*  772 */     if (jj_3R_7()) return true;
/*  773 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_15() {
/*  777 */     if (jj_scan_token(29)) return true;
/*  778 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_52() {
/*  782 */     if (jj_scan_token(17)) return true;
/*  783 */     if (jj_3R_16()) return true;
/*  784 */     if (jj_scan_token(18)) return true;
/*  785 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_14() {
/*  789 */     if (jj_scan_token(30)) return true;
/*  790 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_51() {
/*  794 */     if (jj_3R_55()) return true;
/*  795 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_23() {
/*  799 */     if (jj_3R_35()) return true;
/*      */     Token xsp;
/*      */     do {
/*  802 */       xsp = this.jj_scanpos;
/*  803 */     } while (!jj_3R_36()); this.jj_scanpos = xsp;
/*      */     
/*  805 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_46()
/*      */   {
/*  810 */     Token xsp = this.jj_scanpos;
/*  811 */     if (jj_3R_51()) {
/*  812 */       this.jj_scanpos = xsp;
/*  813 */       if (jj_3R_52()) {
/*  814 */         this.jj_scanpos = xsp;
/*  815 */         if (jj_3R_53()) return true;
/*      */       }
/*      */     }
/*  818 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_6() {
/*  822 */     if (jj_3R_13()) { return true;
/*      */     }
/*  824 */     Token xsp = this.jj_scanpos;
/*  825 */     if (jj_3R_14()) {
/*  826 */       this.jj_scanpos = xsp;
/*  827 */       if (jj_3R_15()) return true;
/*      */     }
/*  829 */     if (jj_3R_13()) return true;
/*  830 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_12() {
/*  834 */     if (jj_scan_token(29)) return true;
/*  835 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_41() {
/*  839 */     if (jj_scan_token(23)) return true;
/*  840 */     if (jj_3R_33()) return true;
/*  841 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_11() {
/*  845 */     if (jj_scan_token(30)) return true;
/*  846 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_40() {
/*  850 */     if (jj_scan_token(24)) return true;
/*  851 */     if (jj_3R_33()) return true;
/*  852 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_34()
/*      */   {
/*  857 */     Token xsp = this.jj_scanpos;
/*  858 */     if (jj_3R_40()) {
/*  859 */       this.jj_scanpos = xsp;
/*  860 */       if (jj_3R_41()) return true;
/*      */     }
/*  862 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_28() {
/*  866 */     if (jj_scan_token(16)) return true;
/*  867 */     if (jj_3R_27()) return true;
/*  868 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_24() {
/*  872 */     if (jj_scan_token(11)) return true;
/*  873 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_5() {
/*  877 */     if (jj_3R_10()) { return true;
/*      */     }
/*  879 */     Token xsp = this.jj_scanpos;
/*  880 */     if (jj_3R_11()) {
/*  881 */       this.jj_scanpos = xsp;
/*  882 */       if (jj_3R_12()) return true;
/*      */     }
/*  884 */     if (jj_3R_10()) return true;
/*  885 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_27() {
/*  889 */     if (jj_scan_token(37)) return true;
/*  890 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_16() {
/*  894 */     if (jj_3R_33()) return true;
/*      */     Token xsp;
/*      */     do {
/*  897 */       xsp = this.jj_scanpos;
/*  898 */     } while (!jj_3R_34()); this.jj_scanpos = xsp;
/*      */     
/*  900 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_6() {
/*  904 */     if (jj_3R_23()) return true;
/*      */     Token xsp;
/*      */     do {
/*  907 */       xsp = this.jj_scanpos;
/*  908 */     } while (!jj_3R_24()); this.jj_scanpos = xsp;
/*      */     
/*  910 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_4() {
/*  914 */     if (jj_3R_7()) { return true;
/*      */     }
/*  916 */     Token xsp = this.jj_scanpos;
/*  917 */     if (jj_scan_token(10)) this.jj_scanpos = xsp;
/*  918 */     if (jj_scan_token(13)) return true;
/*  919 */     if (jj_3R_9()) return true;
/*  920 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_30() {
/*  924 */     if (jj_3R_27()) return true;
/*  925 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_29() {
/*  929 */     if (jj_3R_7()) return true;
/*  930 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_7() {
/*  934 */     if (jj_scan_token(38)) return true;
/*  935 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_10()
/*      */   {
/*  940 */     Token xsp = this.jj_scanpos;
/*  941 */     if (jj_3R_29()) {
/*  942 */       this.jj_scanpos = xsp;
/*  943 */       if (jj_3R_30()) return true;
/*      */     }
/*  945 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_3() {
/*  949 */     if (jj_3R_7()) { return true;
/*      */     }
/*  951 */     Token xsp = this.jj_scanpos;
/*  952 */     if (jj_scan_token(10)) this.jj_scanpos = xsp;
/*  953 */     if (jj_scan_token(14)) return true;
/*  954 */     if (jj_scan_token(17)) return true;
/*  955 */     if (jj_3R_8()) return true;
/*  956 */     if (jj_scan_token(18)) return true;
/*  957 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_44() {
/*  961 */     if (jj_scan_token(7)) return true;
/*  962 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_9() {
/*  966 */     if (jj_3R_27()) { return true;
/*      */     }
/*  968 */     Token xsp = this.jj_scanpos;
/*  969 */     if (jj_3R_28()) this.jj_scanpos = xsp;
/*  970 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_26() {
/*  974 */     if (jj_scan_token(20)) return true;
/*  975 */     if (jj_3R_25()) return true;
/*  976 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_56()
/*      */   {
/*  981 */     Token xsp = this.jj_scanpos;
/*  982 */     if (jj_3_2()) {
/*  983 */       this.jj_scanpos = xsp;
/*  984 */       if (jj_3_3()) {
/*  985 */         this.jj_scanpos = xsp;
/*  986 */         if (jj_3_4()) {
/*  987 */           this.jj_scanpos = xsp;
/*  988 */           if (jj_3_5()) {
/*  989 */             this.jj_scanpos = xsp;
/*  990 */             if (jj_3_6()) {
/*  991 */               this.jj_scanpos = xsp;
/*  992 */               if (jj_3_7()) {
/*  993 */                 this.jj_scanpos = xsp;
/*  994 */                 if (jj_3_8()) {
/*  995 */                   this.jj_scanpos = xsp;
/*  996 */                   if (jj_3R_59()) return true;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1004 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_2() {
/* 1008 */     if (jj_3R_7()) return true;
/* 1009 */     if (jj_scan_token(15)) { return true;
/*      */     }
/* 1011 */     Token xsp = this.jj_scanpos;
/* 1012 */     if (jj_scan_token(10)) this.jj_scanpos = xsp;
/* 1013 */     if (jj_scan_token(8)) return true;
/* 1014 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_37()
/*      */   {
/* 1019 */     Token xsp = this.jj_scanpos;
/* 1020 */     if (jj_scan_token(6)) {
/* 1021 */       this.jj_scanpos = xsp;
/* 1022 */       if (jj_3R_44()) return true;
/*      */     }
/* 1024 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_25()
/*      */   {
/* 1029 */     Token xsp = this.jj_scanpos;
/* 1030 */     if (jj_scan_token(37)) this.jj_scanpos = xsp;
/* 1031 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_32() {
/* 1035 */     if (jj_3R_37()) return true;
/* 1036 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_31() {
/* 1040 */     if (jj_3R_7()) return true;
/* 1041 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_54() {
/* 1045 */     if (jj_3R_56()) return true;
/* 1046 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_13()
/*      */   {
/* 1051 */     Token xsp = this.jj_scanpos;
/* 1052 */     if (jj_3R_31()) {
/* 1053 */       this.jj_scanpos = xsp;
/* 1054 */       if (jj_3R_32()) return true;
/*      */     }
/* 1056 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_8() {
/* 1060 */     if (jj_3R_25()) return true;
/*      */     Token xsp;
/*      */     do {
/* 1063 */       xsp = this.jj_scanpos;
/* 1064 */     } while (!jj_3R_26()); this.jj_scanpos = xsp;
/*      */     
/* 1066 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_50() {
/* 1070 */     if (jj_scan_token(23)) return true;
/* 1071 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_49()
/*      */   {
/* 1076 */     Token xsp = this.jj_scanpos;
/* 1077 */     if (jj_3_1()) {
/* 1078 */       this.jj_scanpos = xsp;
/* 1079 */       if (jj_3R_54()) return true;
/*      */     }
/* 1081 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_1() {
/* 1085 */     if (jj_scan_token(17)) return true;
/* 1086 */     if (jj_3R_6()) return true;
/* 1087 */     if (jj_scan_token(18)) return true;
/* 1088 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_59() {
/* 1092 */     if (jj_3R_13()) return true;
/* 1093 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_45()
/*      */   {
/* 1098 */     Token xsp = this.jj_scanpos;
/* 1099 */     if (jj_scan_token(24)) {
/* 1100 */       this.jj_scanpos = xsp;
/* 1101 */       if (jj_3R_50()) return true;
/*      */     }
/* 1103 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_38()
/*      */   {
/* 1108 */     Token xsp = this.jj_scanpos;
/* 1109 */     if (jj_3R_45()) this.jj_scanpos = xsp;
/* 1110 */     if (jj_3R_46()) return true;
/* 1111 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_8() {
/* 1115 */     if (jj_3R_16()) { return true;
/*      */     }
/* 1117 */     Token xsp = this.jj_scanpos;
/* 1118 */     if (jj_scan_token(10)) this.jj_scanpos = xsp;
/* 1119 */     if (jj_scan_token(12)) return true;
/* 1120 */     if (jj_3R_16()) return true;
/* 1121 */     if (jj_scan_token(9)) return true;
/* 1122 */     if (jj_3R_16()) return true;
/* 1123 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_43() {
/* 1127 */     if (jj_scan_token(10)) return true;
/* 1128 */     if (jj_3R_49()) return true;
/* 1129 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_22() {
/* 1133 */     if (jj_scan_token(28)) return true;
/* 1134 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_58() {
/* 1138 */     if (jj_scan_token(31)) return true;
/* 1139 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_21() {
/* 1143 */     if (jj_scan_token(27)) return true;
/* 1144 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_42() {
/* 1148 */     if (jj_3R_49()) return true;
/* 1149 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_35()
/*      */   {
/* 1154 */     Token xsp = this.jj_scanpos;
/* 1155 */     if (jj_3R_42()) {
/* 1156 */       this.jj_scanpos = xsp;
/* 1157 */       if (jj_3R_43()) return true;
/*      */     }
/* 1159 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_20() {
/* 1163 */     if (jj_scan_token(26)) return true;
/* 1164 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_48() {
/* 1168 */     if (jj_scan_token(22)) return true;
/* 1169 */     if (jj_3R_38()) return true;
/* 1170 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_19() {
/* 1174 */     if (jj_scan_token(25)) return true;
/* 1175 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_18() {
/* 1179 */     if (jj_scan_token(29)) return true;
/* 1180 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_17() {
/* 1184 */     if (jj_scan_token(30)) return true;
/* 1185 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_57() {
/* 1189 */     if (jj_scan_token(35)) return true;
/* 1190 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_55()
/*      */   {
/* 1195 */     Token xsp = this.jj_scanpos;
/* 1196 */     if (jj_3R_57()) {
/* 1197 */       this.jj_scanpos = xsp;
/* 1198 */       if (jj_3R_58()) return true;
/*      */     }
/* 1200 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_47() {
/* 1204 */     if (jj_scan_token(21)) return true;
/* 1205 */     if (jj_3R_38()) return true;
/* 1206 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3R_39()
/*      */   {
/* 1211 */     Token xsp = this.jj_scanpos;
/* 1212 */     if (jj_3R_47()) {
/* 1213 */       this.jj_scanpos = xsp;
/* 1214 */       if (jj_3R_48()) return true;
/*      */     }
/* 1216 */     return false;
/*      */   }
/*      */   
/*      */   private boolean jj_3_7() {
/* 1220 */     if (jj_3R_16()) { return true;
/*      */     }
/* 1222 */     Token xsp = this.jj_scanpos;
/* 1223 */     if (jj_3R_17()) {
/* 1224 */       this.jj_scanpos = xsp;
/* 1225 */       if (jj_3R_18()) {
/* 1226 */         this.jj_scanpos = xsp;
/* 1227 */         if (jj_3R_19()) {
/* 1228 */           this.jj_scanpos = xsp;
/* 1229 */           if (jj_3R_20()) {
/* 1230 */             this.jj_scanpos = xsp;
/* 1231 */             if (jj_3R_21()) {
/* 1232 */               this.jj_scanpos = xsp;
/* 1233 */               if (jj_3R_22()) return true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1239 */     if (jj_3R_16()) return true;
/* 1240 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1254 */   private final int[] jj_la1 = new int[26];
/*      */   private static int[] jj_la1_0;
/*      */   private static int[] jj_la1_1;
/*      */   
/* 1258 */   static { jj_la1_init_0();
/* 1259 */     jj_la1_init_1();
/*      */   }
/*      */   
/* 1262 */   private static void jj_la1_init_0() { jj_la1_0 = new int[] { 2048, 512, -2122185536, -2122186560, 1024, 1024, 1024, 1610612736, 1610612736, 2113929216, 1024, 192, 1048576, 0, 65536, 25165824, 25165824, 6291456, 6291456, 25165824, 25165824, 192, 192, 0, -2147352576, Integer.MIN_VALUE }; }
/*      */   
/*      */ 
/* 1265 */   private static void jj_la1_init_1() { jj_la1_1 = new int[] { 0, 0, 104, 104, 0, 0, 0, 0, 0, 0, 0, 64, 0, 32, 0, 0, 0, 0, 0, 0, 0, 64, 0, 96, 72, 8 }; }
/*      */   
/* 1267 */   private final JJCalls[] jj_2_rtns = new JJCalls[8];
/* 1268 */   private boolean jj_rescan = false;
/* 1269 */   private int jj_gc = 0;
/*      */   
/*      */ 
/*      */ 
/* 1273 */   public FilterParser(InputStream stream) { this(stream, null); }
/*      */   
/*      */   public FilterParser(InputStream stream, String encoding) {
/*      */     try {
/* 1277 */       this.jj_input_stream = new SimpleCharStream(stream, encoding, 1, 1); } catch (UnsupportedEncodingException e) { throw new RuntimeException(e); }
/* 1278 */     this.token_source = new FilterParserTokenManager(this.jj_input_stream);
/* 1279 */     this.token = new Token();
/* 1280 */     this.jj_ntk = -1;
/* 1281 */     this.jj_gen = 0;
/* 1282 */     for (int i = 0; i < 26; i++) this.jj_la1[i] = -1;
/* 1283 */     for (int i = 0; i < this.jj_2_rtns.length; i++) { this.jj_2_rtns[i] = new JJCalls();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/* 1288 */   public void ReInit(InputStream stream) { ReInit(stream, null); }
/*      */   
/*      */   public void ReInit(InputStream stream, String encoding) {
/*      */     try {
/* 1292 */       this.jj_input_stream.ReInit(stream, encoding, 1, 1); } catch (UnsupportedEncodingException e) { throw new RuntimeException(e); }
/* 1293 */     this.token_source.ReInit(this.jj_input_stream);
/* 1294 */     this.token = new Token();
/* 1295 */     this.jj_ntk = -1;
/* 1296 */     this.jj_gen = 0;
/* 1297 */     for (int i = 0; i < 26; i++) this.jj_la1[i] = -1;
/* 1298 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public FilterParser(Reader stream)
/*      */   {
/* 1303 */     this.jj_input_stream = new SimpleCharStream(stream, 1, 1);
/* 1304 */     this.token_source = new FilterParserTokenManager(this.jj_input_stream);
/* 1305 */     this.token = new Token();
/* 1306 */     this.jj_ntk = -1;
/* 1307 */     this.jj_gen = 0;
/* 1308 */     for (int i = 0; i < 26; i++) this.jj_la1[i] = -1;
/* 1309 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public void ReInit(Reader stream)
/*      */   {
/* 1314 */     this.jj_input_stream.ReInit(stream, 1, 1);
/* 1315 */     this.token_source.ReInit(this.jj_input_stream);
/* 1316 */     this.token = new Token();
/* 1317 */     this.jj_ntk = -1;
/* 1318 */     this.jj_gen = 0;
/* 1319 */     for (int i = 0; i < 26; i++) this.jj_la1[i] = -1;
/* 1320 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public FilterParser(FilterParserTokenManager tm)
/*      */   {
/* 1325 */     this.token_source = tm;
/* 1326 */     this.token = new Token();
/* 1327 */     this.jj_ntk = -1;
/* 1328 */     this.jj_gen = 0;
/* 1329 */     for (int i = 0; i < 26; i++) this.jj_la1[i] = -1;
/* 1330 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   public void ReInit(FilterParserTokenManager tm)
/*      */   {
/* 1335 */     this.token_source = tm;
/* 1336 */     this.token = new Token();
/* 1337 */     this.jj_ntk = -1;
/* 1338 */     this.jj_gen = 0;
/* 1339 */     for (int i = 0; i < 26; i++) this.jj_la1[i] = -1;
/* 1340 */     for (int i = 0; i < this.jj_2_rtns.length; i++) this.jj_2_rtns[i] = new JJCalls();
/*      */   }
/*      */   
/*      */   private Token jj_consume_token(int kind) throws ParseException {
/*      */     Token oldToken;
/* 1345 */     if ((oldToken = this.token).next != null) this.token = this.token.next; else
/* 1346 */       this.token = (this.token.next = this.token_source.getNextToken());
/* 1347 */     this.jj_ntk = -1;
/* 1348 */     if (this.token.kind == kind) {
/* 1349 */       this.jj_gen += 1;
/* 1350 */       if (++this.jj_gc > 100) {
/* 1351 */         this.jj_gc = 0;
/* 1352 */         for (int i = 0; i < this.jj_2_rtns.length; i++) {
/* 1353 */           JJCalls c = this.jj_2_rtns[i];
/* 1354 */           while (c != null) {
/* 1355 */             if (c.gen < this.jj_gen) c.first = null;
/* 1356 */             c = c.next;
/*      */           }
/*      */         }
/*      */       }
/* 1360 */       return this.token;
/*      */     }
/* 1362 */     this.token = oldToken;
/* 1363 */     this.jj_kind = kind;
/* 1364 */     throw generateParseException();
/*      */   }
/*      */   
/*      */ 
/* 1368 */   private final LookaheadSuccess jj_ls = new LookaheadSuccess(null);
/*      */   
/* 1370 */   private boolean jj_scan_token(int kind) { if (this.jj_scanpos == this.jj_lastpos) {
/* 1371 */       this.jj_la -= 1;
/* 1372 */       if (this.jj_scanpos.next == null) {
/* 1373 */         this.jj_lastpos = (this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken());
/*      */       } else {
/* 1375 */         this.jj_lastpos = (this.jj_scanpos = this.jj_scanpos.next);
/*      */       }
/*      */     } else {
/* 1378 */       this.jj_scanpos = this.jj_scanpos.next;
/*      */     }
/* 1380 */     if (this.jj_rescan) {
/* 1381 */       int i = 0; for (Token tok = this.token; 
/* 1382 */           (tok != null) && (tok != this.jj_scanpos); tok = tok.next) i++;
/* 1383 */       if (tok != null) jj_add_error_token(kind, i);
/*      */     }
/* 1385 */     if (this.jj_scanpos.kind != kind) return true;
/* 1386 */     if ((this.jj_la == 0) && (this.jj_scanpos == this.jj_lastpos)) throw this.jj_ls;
/* 1387 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public final Token getNextToken()
/*      */   {
/* 1393 */     if (this.token.next != null) this.token = this.token.next; else
/* 1394 */       this.token = (this.token.next = this.token_source.getNextToken());
/* 1395 */     this.jj_ntk = -1;
/* 1396 */     this.jj_gen += 1;
/* 1397 */     return this.token;
/*      */   }
/*      */   
/*      */   public final Token getToken(int index)
/*      */   {
/* 1402 */     Token t = this.token;
/* 1403 */     for (int i = 0; i < index; i++) {
/* 1404 */       if (t.next != null) t = t.next; else
/* 1405 */         t = t.next = this.token_source.getNextToken();
/*      */     }
/* 1407 */     return t;
/*      */   }
/*      */   
/*      */   private int jj_ntk() {
/* 1411 */     if ((this.jj_nt = this.token.next) == null) {
/* 1412 */       return this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind;
/*      */     }
/* 1414 */     return this.jj_ntk = this.jj_nt.kind;
/*      */   }
/*      */   
/* 1417 */   private List<int[]> jj_expentries = new ArrayList();
/*      */   private int[] jj_expentry;
/* 1419 */   private int jj_kind = -1;
/* 1420 */   private int[] jj_lasttokens = new int[100];
/*      */   private int jj_endpos;
/*      */   
/*      */   private void jj_add_error_token(int kind, int pos) {
/* 1424 */     if (pos >= 100) return;
/* 1425 */     if (pos == this.jj_endpos + 1) {
/* 1426 */       this.jj_lasttokens[(this.jj_endpos++)] = kind;
/* 1427 */     } else if (this.jj_endpos != 0) {
/* 1428 */       this.jj_expentry = new int[this.jj_endpos];
/* 1429 */       for (int i = 0; i < this.jj_endpos; i++) {
/* 1430 */         this.jj_expentry[i] = this.jj_lasttokens[i];
/*      */       }
/* 1432 */       for (Iterator<?> it = this.jj_expentries.iterator(); it.hasNext();) {
/* 1433 */         int[] oldentry = (int[])it.next();
/* 1434 */         if (oldentry.length == this.jj_expentry.length) {
/* 1435 */           for (int i = 0;; i++) { if (i >= this.jj_expentry.length) break label163;
/* 1436 */             if (oldentry[i] != this.jj_expentry[i]) {
/*      */               break;
/*      */             }
/*      */           }
/* 1440 */           this.jj_expentries.add(this.jj_expentry);
/* 1441 */           break;
/*      */         } }
/*      */       label163:
/* 1444 */       if (pos != 0) this.jj_lasttokens[((this.jj_endpos = pos) - 1)] = kind;
/*      */     }
/*      */   }
/*      */   
/*      */   public ParseException generateParseException()
/*      */   {
/* 1450 */     this.jj_expentries.clear();
/* 1451 */     boolean[] la1tokens = new boolean[41];
/* 1452 */     if (this.jj_kind >= 0) {
/* 1453 */       la1tokens[this.jj_kind] = true;
/* 1454 */       this.jj_kind = -1;
/*      */     }
/* 1456 */     for (int i = 0; i < 26; i++) {
/* 1457 */       if (this.jj_la1[i] == this.jj_gen) {
/* 1458 */         for (int j = 0; j < 32; j++) {
/* 1459 */           if ((jj_la1_0[i] & 1 << j) != 0) {
/* 1460 */             la1tokens[j] = true;
/*      */           }
/* 1462 */           if ((jj_la1_1[i] & 1 << j) != 0) {
/* 1463 */             la1tokens[(32 + j)] = true;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1468 */     for (int i = 0; i < 41; i++) {
/* 1469 */       if (la1tokens[i] != 0) {
/* 1470 */         this.jj_expentry = new int[1];
/* 1471 */         this.jj_expentry[0] = i;
/* 1472 */         this.jj_expentries.add(this.jj_expentry);
/*      */       }
/*      */     }
/* 1475 */     this.jj_endpos = 0;
/* 1476 */     jj_rescan_token();
/* 1477 */     jj_add_error_token(0, 0);
/* 1478 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 1479 */     for (int i = 0; i < this.jj_expentries.size(); i++) {
/* 1480 */       exptokseq[i] = ((int[])this.jj_expentries.get(i));
/*      */     }
/* 1482 */     return new ParseException(this.token, exptokseq, tokenImage);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void jj_rescan_token()
/*      */   {
/* 1494 */     this.jj_rescan = true;
/* 1495 */     for (int i = 0; i < 8; i++) {
/*      */       try {
/* 1497 */         JJCalls p = this.jj_2_rtns[i];
/*      */         do {
/* 1499 */           if (p.gen > this.jj_gen) {
/* 1500 */             this.jj_la = p.arg;this.jj_lastpos = (this.jj_scanpos = p.first);
/* 1501 */             switch (i) {
/* 1502 */             case 0:  jj_3_1(); break;
/* 1503 */             case 1:  jj_3_2(); break;
/* 1504 */             case 2:  jj_3_3(); break;
/* 1505 */             case 3:  jj_3_4(); break;
/* 1506 */             case 4:  jj_3_5(); break;
/* 1507 */             case 5:  jj_3_6(); break;
/* 1508 */             case 6:  jj_3_7(); break;
/* 1509 */             case 7:  jj_3_8();
/*      */             }
/*      */           }
/* 1512 */           p = p.next;
/* 1513 */         } while (p != null);
/*      */       } catch (LookaheadSuccess ls) {}
/*      */     }
/* 1516 */     this.jj_rescan = false;
/*      */   }
/*      */   
/*      */   private void jj_save(int index, int xla) {
/* 1520 */     JJCalls p = this.jj_2_rtns[index];
/* 1521 */     while (p.gen > this.jj_gen) {
/* 1522 */       if (p.next == null) { p = p.next = new JJCalls(); break; }
/* 1523 */       p = p.next;
/*      */     }
/* 1525 */     p.gen = (this.jj_gen + xla - this.jj_la);p.first = this.token;p.arg = xla;
/*      */   }
/*      */   
/*      */   public final void enable_tracing() {}
/*      */   
/*      */   public final void disable_tracing() {}
/*      */   
/*      */   static final class JJCalls
/*      */   {
/*      */     int gen;
/*      */     Token first;
/*      */     int arg;
/*      */     JJCalls next;
/*      */   }
/*      */   
/*      */   private static final class LookaheadSuccess
/*      */     extends Error
/*      */   {}
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\FilterParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */