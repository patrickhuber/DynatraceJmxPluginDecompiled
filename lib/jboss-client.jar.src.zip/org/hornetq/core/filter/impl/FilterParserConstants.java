/*    */ package org.hornetq.core.filter.impl;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface FilterParserConstants
/*    */ {
/*    */   public static final int EOF = 0;
/*    */   
/*    */ 
/*    */   public static final int TRUE = 6;
/*    */   
/*    */ 
/*    */   public static final int FALSE = 7;
/*    */   
/*    */ 
/*    */   public static final int NULL = 8;
/*    */   
/*    */ 
/*    */   public static final int AND = 9;
/*    */   
/*    */ 
/*    */   public static final int NOT = 10;
/*    */   
/*    */ 
/*    */   public static final int OR = 11;
/*    */   
/*    */ 
/*    */   public static final int BETWEEN = 12;
/*    */   
/*    */   public static final int LIKE = 13;
/*    */   
/*    */   public static final int IN = 14;
/*    */   
/*    */   public static final int IS = 15;
/*    */   
/*    */   public static final int ESCAPE = 16;
/*    */   
/*    */   public static final int LPAREN = 17;
/*    */   
/*    */   public static final int RPAREN = 18;
/*    */   
/*    */   public static final int SEMICOLON = 19;
/*    */   
/*    */   public static final int COMMA = 20;
/*    */   
/*    */   public static final int MULT = 21;
/*    */   
/*    */   public static final int DIV = 22;
/*    */   
/*    */   public static final int MINUS = 23;
/*    */   
/*    */   public static final int PLUS = 24;
/*    */   
/*    */   public static final int GT = 25;
/*    */   
/*    */   public static final int GE = 26;
/*    */   
/*    */   public static final int LT = 27;
/*    */   
/*    */   public static final int LE = 28;
/*    */   
/*    */   public static final int NE = 29;
/*    */   
/*    */   public static final int EQ = 30;
/*    */   
/*    */   public static final int INTEGER_LITERAL = 31;
/*    */   
/*    */   public static final int DECIMAL_LITERAL = 32;
/*    */   
/*    */   public static final int HEX_LITERAL = 33;
/*    */   
/*    */   public static final int OCTAL_LITERAL = 34;
/*    */   
/*    */   public static final int FLOATING_POINT_LITERAL = 35;
/*    */   
/*    */   public static final int EXPONENT = 36;
/*    */   
/*    */   public static final int SIMPLE_STRING = 37;
/*    */   
/*    */   public static final int IDENTIFIER = 38;
/*    */   
/*    */   public static final int LETTER = 39;
/*    */   
/*    */   public static final int DIGIT = 40;
/*    */   
/*    */   public static final int DEFAULT = 0;
/*    */   
/* 88 */   public static final String[] tokenImage = { "<EOF>", "\" \"", "\"\\r\"", "\"\\t\"", "\"\\f\"", "\"\\n\"", "\"TRUE\"", "\"FALSE\"", "\"NULL\"", "\"AND\"", "\"NOT\"", "\"OR\"", "\"BETWEEN\"", "\"LIKE\"", "\"IN\"", "\"IS\"", "\"ESCAPE\"", "\"(\"", "\")\"", "\";\"", "\",\"", "\"*\"", "\"/\"", "\"-\"", "\"+\"", "\">\"", "\">=\"", "\"<\"", "\"<=\"", "\"<>\"", "\"=\"", "<INTEGER_LITERAL>", "<DECIMAL_LITERAL>", "<HEX_LITERAL>", "<OCTAL_LITERAL>", "<FLOATING_POINT_LITERAL>", "<EXPONENT>", "<SIMPLE_STRING>", "<IDENTIFIER>", "<LETTER>", "<DIGIT>" };
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\FilterParserConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */