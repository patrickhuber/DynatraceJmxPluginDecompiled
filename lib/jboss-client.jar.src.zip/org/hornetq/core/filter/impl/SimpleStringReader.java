/*    */ package org.hornetq.core.filter.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ import org.hornetq.api.core.SimpleString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SimpleStringReader
/*    */   extends Reader
/*    */ {
/*    */   private final SimpleString simpleString;
/* 40 */   private int next = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   SimpleStringReader(SimpleString simpleString)
/*    */   {
/* 48 */     this.simpleString = simpleString;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read(char[] cbuf, int off, int len)
/*    */     throws IOException
/*    */   {
/* 58 */     synchronized (this.simpleString)
/*    */     {
/* 60 */       if ((off < 0) || (off > cbuf.length) || (len < 0) || (off + len > cbuf.length) || (off + len < 0))
/*    */       {
/* 62 */         throw new IndexOutOfBoundsException();
/*    */       }
/* 64 */       if (len == 0)
/*    */       {
/* 66 */         return 0;
/*    */       }
/* 68 */       int length = this.simpleString.length();
/* 69 */       if (this.next >= length)
/*    */       {
/* 71 */         return -1;
/*    */       }
/* 73 */       int n = Math.min(length - this.next, len);
/* 74 */       this.simpleString.getChars(this.next, this.next + n, cbuf, off);
/* 75 */       this.next += n;
/* 76 */       return n;
/*    */     }
/*    */   }
/*    */   
/*    */   public void close()
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\SimpleStringReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */