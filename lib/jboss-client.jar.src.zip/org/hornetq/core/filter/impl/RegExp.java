/*     */ package org.hornetq.core.filter.impl;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class RegExp
/*     */ {
/*     */   private final Pattern re;
/*     */   
/*     */   public RegExp(String pattern, Character escapeChar)
/*     */     throws Exception
/*     */   {
/*  46 */     String pat = adjustPattern(pattern, escapeChar);
/*     */     
/*  48 */     this.re = Pattern.compile(pat, 32);
/*     */   }
/*     */   
/*     */   public boolean isMatch(Object target)
/*     */   {
/*  53 */     String str = target != null ? target.toString() : "";
/*     */     
/*  55 */     return this.re.matcher(str).matches();
/*     */   }
/*     */   
/*     */   protected String adjustPattern(String pattern, Character escapeChar) throws Exception
/*     */   {
/*  60 */     int patternLen = pattern.length();
/*     */     
/*  62 */     StringBuilder REpattern = new StringBuilder(patternLen + 10);
/*     */     
/*  64 */     boolean useEscape = escapeChar != null;
/*     */     
/*  66 */     char escape = '\000';
/*     */     
/*  68 */     if (useEscape)
/*     */     {
/*  70 */       escape = escapeChar.charValue();
/*     */     }
/*     */     
/*  73 */     REpattern.append('^');
/*     */     
/*  75 */     for (int i = 0; i < patternLen; i++)
/*     */     {
/*  77 */       boolean escaped = false;
/*     */       
/*  79 */       char c = pattern.charAt(i);
/*     */       
/*  81 */       if ((useEscape) && (escape == c))
/*     */       {
/*  83 */         i++;
/*     */         
/*  85 */         if (i < patternLen)
/*     */         {
/*  87 */           escaped = true;
/*  88 */           c = pattern.charAt(i);
/*     */         }
/*     */         else
/*     */         {
/*  92 */           throw new Exception("LIKE ESCAPE: Bad use of escape character");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  98 */       switch (c)
/*     */       {
/*     */       case '_': 
/* 101 */         if (escaped)
/*     */         {
/* 103 */           REpattern.append(c);
/*     */         }
/*     */         else
/*     */         {
/* 107 */           REpattern.append('.');
/*     */         }
/* 109 */         break;
/*     */       case '%': 
/* 111 */         if (escaped)
/*     */         {
/* 113 */           REpattern.append(c);
/*     */         }
/*     */         else
/*     */         {
/* 117 */           REpattern.append(".*");
/*     */         }
/* 119 */         break;
/*     */       case '$': 
/*     */       case '(': 
/*     */       case ')': 
/*     */       case '*': 
/*     */       case '+': 
/*     */       case '.': 
/*     */       case '?': 
/*     */       case '[': 
/*     */       case '\\': 
/*     */       case ']': 
/*     */       case '^': 
/*     */       case '{': 
/*     */       case '|': 
/*     */       case '}': 
/* 134 */         REpattern.append("\\");
/* 135 */         REpattern.append(c);
/* 136 */         break;
/*     */       default: 
/* 138 */         REpattern.append(c);
/*     */       }
/*     */       
/*     */     }
/*     */     
/* 143 */     REpattern.append('$');
/* 144 */     return REpattern.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\filter\impl\RegExp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */