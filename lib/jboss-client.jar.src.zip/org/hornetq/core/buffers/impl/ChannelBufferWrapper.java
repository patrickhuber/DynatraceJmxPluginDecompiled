/*     */ package org.hornetq.core.buffers.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.utils.UTF8Util;
/*     */ import org.jboss.netty.buffer.ChannelBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelBufferWrapper
/*     */   implements HornetQBuffer
/*     */ {
/*     */   protected ChannelBuffer buffer;
/*     */   
/*     */   public ChannelBufferWrapper(ChannelBuffer buffer)
/*     */   {
/*  34 */     this.buffer = buffer;
/*     */   }
/*     */   
/*     */   public boolean readBoolean()
/*     */   {
/*  39 */     return readByte() != 0;
/*     */   }
/*     */   
/*     */   public SimpleString readNullableSimpleString()
/*     */   {
/*  44 */     int b = this.buffer.readByte();
/*  45 */     if (b == 0)
/*     */     {
/*  47 */       return null;
/*     */     }
/*  49 */     return readSimpleStringInternal();
/*     */   }
/*     */   
/*     */   public String readNullableString()
/*     */   {
/*  54 */     int b = this.buffer.readByte();
/*  55 */     if (b == 0)
/*     */     {
/*  57 */       return null;
/*     */     }
/*  59 */     return readStringInternal();
/*     */   }
/*     */   
/*     */   public SimpleString readSimpleString()
/*     */   {
/*  64 */     return readSimpleStringInternal();
/*     */   }
/*     */   
/*     */   private SimpleString readSimpleStringInternal()
/*     */   {
/*  69 */     int len = this.buffer.readInt();
/*  70 */     byte[] data = new byte[len];
/*  71 */     this.buffer.readBytes(data);
/*  72 */     return new SimpleString(data);
/*     */   }
/*     */   
/*     */   public String readString()
/*     */   {
/*  77 */     return readStringInternal();
/*     */   }
/*     */   
/*     */   private String readStringInternal()
/*     */   {
/*  82 */     int len = this.buffer.readInt();
/*     */     
/*  84 */     if (len < 9)
/*     */     {
/*  86 */       char[] chars = new char[len];
/*  87 */       for (int i = 0; i < len; i++)
/*     */       {
/*  89 */         chars[i] = ((char)this.buffer.readShort());
/*     */       }
/*  91 */       return new String(chars);
/*     */     }
/*  93 */     if (len < 4095)
/*     */     {
/*  95 */       return readUTF();
/*     */     }
/*     */     
/*     */ 
/*  99 */     return readSimpleStringInternal().toString();
/*     */   }
/*     */   
/*     */ 
/*     */   public String readUTF()
/*     */   {
/* 105 */     return UTF8Util.readUTF(this);
/*     */   }
/*     */   
/*     */   public void writeBoolean(boolean val)
/*     */   {
/* 110 */     this.buffer.writeByte((byte)(val ? -1 : 0));
/*     */   }
/*     */   
/*     */   public void writeNullableSimpleString(SimpleString val)
/*     */   {
/* 115 */     if (val == null)
/*     */     {
/* 117 */       this.buffer.writeByte(0);
/*     */     }
/*     */     else
/*     */     {
/* 121 */       this.buffer.writeByte(1);
/* 122 */       writeSimpleStringInternal(val);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeNullableString(String val)
/*     */   {
/* 128 */     if (val == null)
/*     */     {
/* 130 */       this.buffer.writeByte(0);
/*     */     }
/*     */     else
/*     */     {
/* 134 */       this.buffer.writeByte(1);
/* 135 */       writeStringInternal(val);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeSimpleString(SimpleString val)
/*     */   {
/* 141 */     writeSimpleStringInternal(val);
/*     */   }
/*     */   
/*     */   private void writeSimpleStringInternal(SimpleString val)
/*     */   {
/* 146 */     byte[] data = val.getData();
/* 147 */     this.buffer.writeInt(data.length);
/* 148 */     this.buffer.writeBytes(data);
/*     */   }
/*     */   
/*     */   public void writeString(String val)
/*     */   {
/* 153 */     writeStringInternal(val);
/*     */   }
/*     */   
/*     */   private void writeStringInternal(String val)
/*     */   {
/* 158 */     int length = val.length();
/*     */     
/* 160 */     this.buffer.writeInt(length);
/*     */     
/* 162 */     if (length < 9)
/*     */     {
/*     */ 
/* 165 */       for (int i = 0; i < val.length(); i++)
/*     */       {
/* 167 */         this.buffer.writeShort((short)val.charAt(i));
/*     */       }
/*     */       
/* 170 */     } else if (length < 4095)
/*     */     {
/*     */ 
/* 173 */       writeUTF(val);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 178 */       writeSimpleStringInternal(new SimpleString(val));
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeUTF(String utf)
/*     */   {
/* 184 */     UTF8Util.saveUTF(this, utf);
/*     */   }
/*     */   
/*     */   public int capacity()
/*     */   {
/* 189 */     return this.buffer.capacity();
/*     */   }
/*     */   
/*     */   public ChannelBuffer channelBuffer()
/*     */   {
/* 194 */     return this.buffer;
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/* 199 */     this.buffer.clear();
/*     */   }
/*     */   
/*     */   public HornetQBuffer copy()
/*     */   {
/* 204 */     return new ChannelBufferWrapper(this.buffer.copy());
/*     */   }
/*     */   
/*     */   public HornetQBuffer copy(int index, int length)
/*     */   {
/* 209 */     return new ChannelBufferWrapper(this.buffer.copy(index, length));
/*     */   }
/*     */   
/*     */   public void discardReadBytes()
/*     */   {
/* 214 */     this.buffer.discardReadBytes();
/*     */   }
/*     */   
/*     */   public HornetQBuffer duplicate()
/*     */   {
/* 219 */     return new ChannelBufferWrapper(this.buffer.duplicate());
/*     */   }
/*     */   
/*     */   public byte getByte(int index)
/*     */   {
/* 224 */     return this.buffer.getByte(index);
/*     */   }
/*     */   
/*     */   public void getBytes(int index, byte[] dst, int dstIndex, int length)
/*     */   {
/* 229 */     this.buffer.getBytes(index, dst, dstIndex, length);
/*     */   }
/*     */   
/*     */   public void getBytes(int index, byte[] dst)
/*     */   {
/* 234 */     this.buffer.getBytes(index, dst);
/*     */   }
/*     */   
/*     */   public void getBytes(int index, ByteBuffer dst)
/*     */   {
/* 239 */     this.buffer.getBytes(index, dst);
/*     */   }
/*     */   
/*     */   public void getBytes(int index, HornetQBuffer dst, int dstIndex, int length)
/*     */   {
/* 244 */     this.buffer.getBytes(index, dst.channelBuffer(), dstIndex, length);
/*     */   }
/*     */   
/*     */   public void getBytes(int index, HornetQBuffer dst, int length)
/*     */   {
/* 249 */     this.buffer.getBytes(index, dst.channelBuffer(), length);
/*     */   }
/*     */   
/*     */   public void getBytes(int index, HornetQBuffer dst)
/*     */   {
/* 254 */     this.buffer.getBytes(index, dst.channelBuffer());
/*     */   }
/*     */   
/*     */   public char getChar(int index)
/*     */   {
/* 259 */     return (char)this.buffer.getShort(index);
/*     */   }
/*     */   
/*     */   public double getDouble(int index)
/*     */   {
/* 264 */     return Double.longBitsToDouble(this.buffer.getLong(index));
/*     */   }
/*     */   
/*     */   public float getFloat(int index)
/*     */   {
/* 269 */     return Float.intBitsToFloat(this.buffer.getInt(index));
/*     */   }
/*     */   
/*     */   public int getInt(int index)
/*     */   {
/* 274 */     return this.buffer.getInt(index);
/*     */   }
/*     */   
/*     */   public long getLong(int index)
/*     */   {
/* 279 */     return this.buffer.getLong(index);
/*     */   }
/*     */   
/*     */   public short getShort(int index)
/*     */   {
/* 284 */     return this.buffer.getShort(index);
/*     */   }
/*     */   
/*     */   public short getUnsignedByte(int index)
/*     */   {
/* 289 */     return this.buffer.getUnsignedByte(index);
/*     */   }
/*     */   
/*     */   public long getUnsignedInt(int index)
/*     */   {
/* 294 */     return this.buffer.getUnsignedInt(index);
/*     */   }
/*     */   
/*     */   public int getUnsignedShort(int index)
/*     */   {
/* 299 */     return this.buffer.getUnsignedShort(index);
/*     */   }
/*     */   
/*     */   public void markReaderIndex()
/*     */   {
/* 304 */     this.buffer.markReaderIndex();
/*     */   }
/*     */   
/*     */   public void markWriterIndex()
/*     */   {
/* 309 */     this.buffer.markWriterIndex();
/*     */   }
/*     */   
/*     */   public boolean readable()
/*     */   {
/* 314 */     return this.buffer.readable();
/*     */   }
/*     */   
/*     */   public int readableBytes()
/*     */   {
/* 319 */     return this.buffer.readableBytes();
/*     */   }
/*     */   
/*     */   public byte readByte()
/*     */   {
/* 324 */     return this.buffer.readByte();
/*     */   }
/*     */   
/*     */   public void readBytes(byte[] dst, int dstIndex, int length)
/*     */   {
/* 329 */     this.buffer.readBytes(dst, dstIndex, length);
/*     */   }
/*     */   
/*     */   public void readBytes(byte[] dst)
/*     */   {
/* 334 */     this.buffer.readBytes(dst);
/*     */   }
/*     */   
/*     */   public void readBytes(ByteBuffer dst)
/*     */   {
/* 339 */     this.buffer.readBytes(dst);
/*     */   }
/*     */   
/*     */   public void readBytes(HornetQBuffer dst, int dstIndex, int length)
/*     */   {
/* 344 */     this.buffer.readBytes(dst.channelBuffer(), dstIndex, length);
/*     */   }
/*     */   
/*     */   public void readBytes(HornetQBuffer dst, int length)
/*     */   {
/* 349 */     this.buffer.readBytes(dst.channelBuffer(), length);
/*     */   }
/*     */   
/*     */   public void readBytes(HornetQBuffer dst)
/*     */   {
/* 354 */     this.buffer.readBytes(dst.channelBuffer());
/*     */   }
/*     */   
/*     */   public HornetQBuffer readBytes(int length)
/*     */   {
/* 359 */     return new ChannelBufferWrapper(this.buffer.readBytes(length));
/*     */   }
/*     */   
/*     */   public char readChar()
/*     */   {
/* 364 */     return (char)this.buffer.readShort();
/*     */   }
/*     */   
/*     */   public double readDouble()
/*     */   {
/* 369 */     return Double.longBitsToDouble(this.buffer.readLong());
/*     */   }
/*     */   
/*     */   public int readerIndex()
/*     */   {
/* 374 */     return this.buffer.readerIndex();
/*     */   }
/*     */   
/*     */   public void readerIndex(int readerIndex)
/*     */   {
/* 379 */     this.buffer.readerIndex(readerIndex);
/*     */   }
/*     */   
/*     */   public float readFloat()
/*     */   {
/* 384 */     return Float.intBitsToFloat(this.buffer.readInt());
/*     */   }
/*     */   
/*     */   public int readInt()
/*     */   {
/* 389 */     return this.buffer.readInt();
/*     */   }
/*     */   
/*     */   public long readLong()
/*     */   {
/* 394 */     return this.buffer.readLong();
/*     */   }
/*     */   
/*     */   public short readShort()
/*     */   {
/* 399 */     return this.buffer.readShort();
/*     */   }
/*     */   
/*     */   public HornetQBuffer readSlice(int length)
/*     */   {
/* 404 */     return new ChannelBufferWrapper(this.buffer.readSlice(length));
/*     */   }
/*     */   
/*     */   public short readUnsignedByte()
/*     */   {
/* 409 */     return this.buffer.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public long readUnsignedInt()
/*     */   {
/* 414 */     return this.buffer.readUnsignedInt();
/*     */   }
/*     */   
/*     */   public int readUnsignedShort()
/*     */   {
/* 419 */     return this.buffer.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public void resetReaderIndex()
/*     */   {
/* 424 */     this.buffer.resetReaderIndex();
/*     */   }
/*     */   
/*     */   public void resetWriterIndex()
/*     */   {
/* 429 */     this.buffer.resetWriterIndex();
/*     */   }
/*     */   
/*     */   public void setByte(int index, byte value)
/*     */   {
/* 434 */     this.buffer.setByte(index, value);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*     */   {
/* 439 */     this.buffer.setBytes(index, src, srcIndex, length);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, byte[] src)
/*     */   {
/* 444 */     this.buffer.setBytes(index, src);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, ByteBuffer src)
/*     */   {
/* 449 */     this.buffer.setBytes(index, src);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, HornetQBuffer src, int srcIndex, int length)
/*     */   {
/* 454 */     this.buffer.setBytes(index, src.channelBuffer(), srcIndex, length);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, HornetQBuffer src, int length)
/*     */   {
/* 459 */     this.buffer.setBytes(index, src.channelBuffer(), length);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, HornetQBuffer src)
/*     */   {
/* 464 */     this.buffer.setBytes(index, src.channelBuffer());
/*     */   }
/*     */   
/*     */   public void setChar(int index, char value)
/*     */   {
/* 469 */     this.buffer.setShort(index, (short)value);
/*     */   }
/*     */   
/*     */   public void setDouble(int index, double value)
/*     */   {
/* 474 */     this.buffer.setLong(index, Double.doubleToLongBits(value));
/*     */   }
/*     */   
/*     */   public void setFloat(int index, float value)
/*     */   {
/* 479 */     this.buffer.setInt(index, Float.floatToIntBits(value));
/*     */   }
/*     */   
/*     */   public void setIndex(int readerIndex, int writerIndex)
/*     */   {
/* 484 */     this.buffer.setIndex(readerIndex, writerIndex);
/*     */   }
/*     */   
/*     */   public void setInt(int index, int value)
/*     */   {
/* 489 */     this.buffer.setInt(index, value);
/*     */   }
/*     */   
/*     */   public void setLong(int index, long value)
/*     */   {
/* 494 */     this.buffer.setLong(index, value);
/*     */   }
/*     */   
/*     */   public void setShort(int index, short value)
/*     */   {
/* 499 */     this.buffer.setShort(index, value);
/*     */   }
/*     */   
/*     */   public void skipBytes(int length)
/*     */   {
/* 504 */     this.buffer.skipBytes(length);
/*     */   }
/*     */   
/*     */   public HornetQBuffer slice()
/*     */   {
/* 509 */     return new ChannelBufferWrapper(this.buffer.slice());
/*     */   }
/*     */   
/*     */   public HornetQBuffer slice(int index, int length)
/*     */   {
/* 514 */     return new ChannelBufferWrapper(this.buffer.slice(index, length));
/*     */   }
/*     */   
/*     */   public ByteBuffer toByteBuffer()
/*     */   {
/* 519 */     return this.buffer.toByteBuffer();
/*     */   }
/*     */   
/*     */   public ByteBuffer toByteBuffer(int index, int length)
/*     */   {
/* 524 */     return this.buffer.toByteBuffer(index, length);
/*     */   }
/*     */   
/*     */   public boolean writable()
/*     */   {
/* 529 */     return this.buffer.writable();
/*     */   }
/*     */   
/*     */   public int writableBytes()
/*     */   {
/* 534 */     return this.buffer.writableBytes();
/*     */   }
/*     */   
/*     */   public void writeByte(byte value)
/*     */   {
/* 539 */     this.buffer.writeByte(value);
/*     */   }
/*     */   
/*     */   public void writeBytes(byte[] src, int srcIndex, int length)
/*     */   {
/* 544 */     this.buffer.writeBytes(src, srcIndex, length);
/*     */   }
/*     */   
/*     */   public void writeBytes(byte[] src)
/*     */   {
/* 549 */     this.buffer.writeBytes(src);
/*     */   }
/*     */   
/*     */   public void writeBytes(ByteBuffer src)
/*     */   {
/* 554 */     this.buffer.writeBytes(src);
/*     */   }
/*     */   
/*     */   public void writeBytes(HornetQBuffer src, int srcIndex, int length)
/*     */   {
/* 559 */     this.buffer.writeBytes(src.channelBuffer(), srcIndex, length);
/*     */   }
/*     */   
/*     */   public void writeBytes(HornetQBuffer src, int length)
/*     */   {
/* 564 */     this.buffer.writeBytes(src.channelBuffer(), length);
/*     */   }
/*     */   
/*     */   public void writeChar(char chr)
/*     */   {
/* 569 */     this.buffer.writeShort((short)chr);
/*     */   }
/*     */   
/*     */   public void writeDouble(double value)
/*     */   {
/* 574 */     this.buffer.writeLong(Double.doubleToLongBits(value));
/*     */   }
/*     */   
/*     */   public void writeFloat(float value)
/*     */   {
/* 579 */     this.buffer.writeInt(Float.floatToIntBits(value));
/*     */   }
/*     */   
/*     */   public void writeInt(int value)
/*     */   {
/* 584 */     this.buffer.writeInt(value);
/*     */   }
/*     */   
/*     */   public void writeLong(long value)
/*     */   {
/* 589 */     this.buffer.writeLong(value);
/*     */   }
/*     */   
/*     */   public int writerIndex()
/*     */   {
/* 594 */     return this.buffer.writerIndex();
/*     */   }
/*     */   
/*     */   public void writerIndex(int writerIndex)
/*     */   {
/* 599 */     this.buffer.writerIndex(writerIndex);
/*     */   }
/*     */   
/*     */   public void writeShort(short value)
/*     */   {
/* 604 */     this.buffer.writeShort(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\buffers\impl\ChannelBufferWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */