/*     */ package org.hornetq.core.buffers.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.message.impl.MessageInternal;
/*     */ import org.jboss.netty.buffer.ChannelBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResetLimitWrappedHornetQBuffer
/*     */   extends ChannelBufferWrapper
/*     */ {
/*     */   private final int limit;
/*     */   private final MessageInternal message;
/*     */   
/*     */   public ResetLimitWrappedHornetQBuffer(int limit, HornetQBuffer buffer, MessageInternal message)
/*     */   {
/*  36 */     super(buffer.channelBuffer());
/*     */     
/*  38 */     this.limit = limit;
/*     */     
/*  40 */     if (writerIndex() < limit)
/*     */     {
/*  42 */       writerIndex(limit);
/*     */     }
/*     */     
/*  45 */     buffer.readerIndex(limit);
/*     */     
/*  47 */     this.message = message;
/*     */   }
/*     */   
/*     */   private void changed()
/*     */   {
/*  52 */     if (this.message != null)
/*     */     {
/*  54 */       this.message.bodyChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setBuffer(HornetQBuffer buffer)
/*     */   {
/*  60 */     this.buffer = buffer.channelBuffer();
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */   {
/*  66 */     changed();
/*     */     
/*  68 */     this.buffer.clear();
/*     */     
/*  70 */     this.buffer.setIndex(this.limit, this.limit);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readerIndex(int readerIndex)
/*     */   {
/*  77 */     changed();
/*     */     
/*  79 */     if (readerIndex < this.limit)
/*     */     {
/*  81 */       readerIndex = this.limit;
/*     */     }
/*     */     
/*  84 */     this.buffer.readerIndex(readerIndex);
/*     */   }
/*     */   
/*     */ 
/*     */   public void resetReaderIndex()
/*     */   {
/*  90 */     changed();
/*     */     
/*  92 */     this.buffer.readerIndex(this.limit);
/*     */   }
/*     */   
/*     */ 
/*     */   public void resetWriterIndex()
/*     */   {
/*  98 */     changed();
/*     */     
/* 100 */     this.buffer.writerIndex(this.limit);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setIndex(int readerIndex, int writerIndex)
/*     */   {
/* 106 */     changed();
/*     */     
/* 108 */     if (readerIndex < this.limit)
/*     */     {
/* 110 */       readerIndex = this.limit;
/*     */     }
/* 112 */     if (writerIndex < this.limit)
/*     */     {
/* 114 */       writerIndex = this.limit;
/*     */     }
/* 116 */     this.buffer.setIndex(readerIndex, writerIndex);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writerIndex(int writerIndex)
/*     */   {
/* 122 */     changed();
/*     */     
/* 124 */     if (writerIndex < this.limit)
/*     */     {
/* 126 */       writerIndex = this.limit;
/*     */     }
/*     */     
/* 129 */     this.buffer.writerIndex(writerIndex);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setByte(int index, byte value)
/*     */   {
/* 135 */     changed();
/*     */     
/* 137 */     super.setByte(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*     */   {
/* 143 */     changed();
/*     */     
/* 145 */     super.setBytes(index, src, srcIndex, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, byte[] src)
/*     */   {
/* 151 */     changed();
/*     */     
/* 153 */     super.setBytes(index, src);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, ByteBuffer src)
/*     */   {
/* 159 */     changed();
/*     */     
/* 161 */     super.setBytes(index, src);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, HornetQBuffer src, int srcIndex, int length)
/*     */   {
/* 167 */     changed();
/*     */     
/* 169 */     super.setBytes(index, src, srcIndex, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, HornetQBuffer src, int length)
/*     */   {
/* 175 */     changed();
/*     */     
/* 177 */     super.setBytes(index, src, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, HornetQBuffer src)
/*     */   {
/* 183 */     changed();
/*     */     
/* 185 */     super.setBytes(index, src);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setChar(int index, char value)
/*     */   {
/* 191 */     changed();
/*     */     
/* 193 */     super.setChar(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDouble(int index, double value)
/*     */   {
/* 199 */     changed();
/*     */     
/* 201 */     super.setDouble(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setFloat(int index, float value)
/*     */   {
/* 207 */     changed();
/*     */     
/* 209 */     super.setFloat(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInt(int index, int value)
/*     */   {
/* 215 */     changed();
/*     */     
/* 217 */     super.setInt(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLong(int index, long value)
/*     */   {
/* 223 */     changed();
/*     */     
/* 225 */     super.setLong(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setShort(int index, short value)
/*     */   {
/* 231 */     changed();
/*     */     
/* 233 */     super.setShort(index, value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBoolean(boolean val)
/*     */   {
/* 239 */     changed();
/*     */     
/* 241 */     super.writeBoolean(val);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeByte(byte value)
/*     */   {
/* 247 */     changed();
/*     */     
/* 249 */     super.writeByte(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBytes(byte[] src, int srcIndex, int length)
/*     */   {
/* 255 */     changed();
/*     */     
/* 257 */     super.writeBytes(src, srcIndex, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBytes(byte[] src)
/*     */   {
/* 263 */     changed();
/*     */     
/* 265 */     super.writeBytes(src);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBytes(ByteBuffer src)
/*     */   {
/* 271 */     changed();
/*     */     
/* 273 */     super.writeBytes(src);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBytes(HornetQBuffer src, int srcIndex, int length)
/*     */   {
/* 279 */     changed();
/*     */     
/* 281 */     super.writeBytes(src, srcIndex, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBytes(HornetQBuffer src, int length)
/*     */   {
/* 287 */     changed();
/*     */     
/* 289 */     super.writeBytes(src, length);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeChar(char chr)
/*     */   {
/* 295 */     changed();
/*     */     
/* 297 */     super.writeChar(chr);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeDouble(double value)
/*     */   {
/* 303 */     changed();
/*     */     
/* 305 */     super.writeDouble(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeFloat(float value)
/*     */   {
/* 311 */     changed();
/*     */     
/* 313 */     super.writeFloat(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeInt(int value)
/*     */   {
/* 319 */     changed();
/*     */     
/* 321 */     super.writeInt(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeLong(long value)
/*     */   {
/* 327 */     changed();
/*     */     
/* 329 */     super.writeLong(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeNullableSimpleString(SimpleString val)
/*     */   {
/* 335 */     changed();
/*     */     
/* 337 */     super.writeNullableSimpleString(val);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeNullableString(String val)
/*     */   {
/* 343 */     changed();
/*     */     
/* 345 */     super.writeNullableString(val);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeShort(short value)
/*     */   {
/* 351 */     changed();
/*     */     
/* 353 */     super.writeShort(value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeSimpleString(SimpleString val)
/*     */   {
/* 359 */     changed();
/*     */     
/* 361 */     super.writeSimpleString(val);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeString(String val)
/*     */   {
/* 367 */     changed();
/*     */     
/* 369 */     super.writeString(val);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeUTF(String utf)
/*     */   {
/* 375 */     changed();
/*     */     
/* 377 */     super.writeUTF(utf);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\buffers\impl\ResetLimitWrappedHornetQBuffer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */