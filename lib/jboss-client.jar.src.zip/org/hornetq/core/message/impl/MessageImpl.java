/*     */ package org.hornetq.core.message.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQPropertyConversionException;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.buffers.impl.ResetLimitWrappedHornetQBuffer;
/*     */ import org.hornetq.core.message.BodyEncoder;
/*     */ import org.hornetq.utils.TypedProperties;
/*     */ import org.hornetq.utils.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MessageImpl
/*     */   implements MessageInternal
/*     */ {
/*  49 */   public static final SimpleString HDR_ROUTE_TO_IDS = new SimpleString("_HQ_ROUTE_TO");
/*     */   
/*     */ 
/*  52 */   public static final SimpleString HDR_BRIDGE_DUPLICATE_ID = new SimpleString("_HQ_BRIDGE_DUP");
/*     */   
/*     */ 
/*     */   public static final int BUFFER_HEADER_SPACE = 13;
/*     */   
/*     */ 
/*     */   public static final int BODY_OFFSET = 17;
/*     */   
/*     */ 
/*     */   protected long messageID;
/*     */   
/*     */   protected SimpleString address;
/*     */   
/*     */   protected byte type;
/*     */   
/*     */   protected boolean durable;
/*     */   
/*     */   private long expiration;
/*     */   
/*     */   protected long timestamp;
/*     */   
/*     */   protected TypedProperties properties;
/*     */   
/*     */   protected byte priority;
/*     */   
/*     */   protected HornetQBuffer buffer;
/*     */   
/*     */   protected ResetLimitWrappedHornetQBuffer bodyBuffer;
/*     */   
/*     */   protected volatile boolean bufferValid;
/*     */   
/*  83 */   private int endOfBodyPosition = -1;
/*     */   
/*     */   private int endOfMessagePosition;
/*     */   
/*  87 */   private boolean copied = true;
/*     */   
/*     */ 
/*     */   private boolean bufferUsed;
/*     */   
/*     */   private UUID userID;
/*     */   
/*     */ 
/*     */   protected MessageImpl()
/*     */   {
/*  97 */     this.properties = new TypedProperties();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageImpl(byte type, boolean durable, long expiration, long timestamp, byte priority, int initialMessageBufferSize)
/*     */   {
/* 117 */     this();
/* 118 */     this.type = type;
/* 119 */     this.durable = durable;
/* 120 */     this.expiration = expiration;
/* 121 */     this.timestamp = timestamp;
/* 122 */     this.priority = priority;
/* 123 */     createBody(initialMessageBufferSize);
/*     */   }
/*     */   
/*     */   protected MessageImpl(int initialMessageBufferSize)
/*     */   {
/* 128 */     this();
/* 129 */     createBody(initialMessageBufferSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageImpl(MessageImpl other)
/*     */   {
/* 137 */     this(other, other.getProperties());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected MessageImpl(MessageImpl other, TypedProperties properties)
/*     */   {
/* 145 */     this.messageID = other.getMessageID();
/* 146 */     this.userID = other.getUserID();
/* 147 */     this.address = other.getAddress();
/* 148 */     this.type = other.getType();
/* 149 */     this.durable = other.isDurable();
/* 150 */     this.expiration = other.getExpiration();
/* 151 */     this.timestamp = other.getTimestamp();
/* 152 */     this.priority = other.getPriority();
/* 153 */     this.properties = new TypedProperties(properties);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 158 */     synchronized (other)
/*     */     {
/* 160 */       this.bufferValid = other.bufferValid;
/* 161 */       this.endOfBodyPosition = other.endOfBodyPosition;
/* 162 */       this.endOfMessagePosition = other.endOfMessagePosition;
/* 163 */       this.copied = other.copied;
/*     */       
/* 165 */       if (other.buffer != null)
/*     */       {
/* 167 */         other.bufferUsed = true;
/*     */         
/*     */ 
/*     */ 
/* 171 */         this.buffer = other.buffer.copy(0, other.buffer.writerIndex());
/*     */         
/* 173 */         this.buffer.setIndex(other.buffer.readerIndex(), this.buffer.capacity());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEncodeSize()
/*     */   {
/* 182 */     int headersPropsSize = getHeadersAndPropertiesEncodeSize();
/*     */     
/* 184 */     int bodyPos = getEndOfBodyPosition();
/*     */     
/* 186 */     int bodySize = bodyPos - 13 - 4;
/*     */     
/* 188 */     return 4 + bodySize + 4 + headersPropsSize;
/*     */   }
/*     */   
/*     */   public int getHeadersAndPropertiesEncodeSize()
/*     */   {
/* 193 */     return 9 + (this.userID == null ? 0 : 16) + SimpleString.sizeofNullableString(this.address) + 1 + 1 + 8 + 8 + 1 + this.properties.getEncodeSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void encodeHeadersAndProperties(HornetQBuffer buffer)
/*     */   {
/* 208 */     buffer.writeLong(this.messageID);
/* 209 */     buffer.writeNullableSimpleString(this.address);
/* 210 */     if (this.userID == null)
/*     */     {
/* 212 */       buffer.writeByte((byte)0);
/*     */     }
/*     */     else
/*     */     {
/* 216 */       buffer.writeByte((byte)1);
/* 217 */       buffer.writeBytes(this.userID.asBytes());
/*     */     }
/* 219 */     buffer.writeByte(this.type);
/* 220 */     buffer.writeBoolean(this.durable);
/* 221 */     buffer.writeLong(this.expiration);
/* 222 */     buffer.writeLong(this.timestamp);
/* 223 */     buffer.writeByte(this.priority);
/* 224 */     this.properties.encode(buffer);
/*     */   }
/*     */   
/*     */   public void decodeHeadersAndProperties(HornetQBuffer buffer)
/*     */   {
/* 229 */     this.messageID = buffer.readLong();
/* 230 */     this.address = buffer.readNullableSimpleString();
/* 231 */     if (buffer.readByte() == 1)
/*     */     {
/* 233 */       byte[] bytes = new byte[16];
/* 234 */       buffer.readBytes(bytes);
/* 235 */       this.userID = new UUID(1, bytes);
/*     */     }
/*     */     else
/*     */     {
/* 239 */       this.userID = null;
/*     */     }
/* 241 */     this.type = buffer.readByte();
/* 242 */     this.durable = buffer.readBoolean();
/* 243 */     this.expiration = buffer.readLong();
/* 244 */     this.timestamp = buffer.readLong();
/* 245 */     this.priority = buffer.readByte();
/* 246 */     this.properties.decode(buffer);
/*     */   }
/*     */   
/*     */   public void copyHeadersAndProperties(MessageInternal msg)
/*     */   {
/* 251 */     this.messageID = msg.getMessageID();
/* 252 */     this.address = msg.getAddress();
/* 253 */     this.userID = msg.getUserID();
/* 254 */     this.type = msg.getType();
/* 255 */     this.durable = msg.isDurable();
/* 256 */     this.expiration = msg.getExpiration();
/* 257 */     this.timestamp = msg.getTimestamp();
/* 258 */     this.priority = msg.getPriority();
/* 259 */     this.properties = msg.getTypedProperties();
/*     */   }
/*     */   
/*     */   public HornetQBuffer getBodyBuffer()
/*     */   {
/* 264 */     if (this.bodyBuffer == null)
/*     */     {
/* 266 */       this.bodyBuffer = new ResetLimitWrappedHornetQBuffer(17, this.buffer, this);
/*     */     }
/*     */     
/* 269 */     return this.bodyBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void checkCompletion()
/*     */     throws HornetQException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized HornetQBuffer getBodyBufferCopy()
/*     */   {
/* 282 */     HornetQBuffer newBuffer = this.buffer.copy(0, this.buffer.capacity());
/*     */     
/* 284 */     newBuffer.setIndex(0, getEndOfBodyPosition());
/*     */     
/* 286 */     return new ResetLimitWrappedHornetQBuffer(17, newBuffer, null);
/*     */   }
/*     */   
/*     */   public long getMessageID()
/*     */   {
/* 291 */     return this.messageID;
/*     */   }
/*     */   
/*     */   public UUID getUserID()
/*     */   {
/* 296 */     return this.userID;
/*     */   }
/*     */   
/*     */   public void setUserID(UUID userID)
/*     */   {
/* 301 */     this.userID = userID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleString getAddress()
/*     */   {
/* 310 */     return this.address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(SimpleString address)
/*     */   {
/* 321 */     synchronized (this)
/*     */     {
/* 323 */       if (this.address != address)
/*     */       {
/* 325 */         this.address = address;
/*     */         
/* 327 */         this.bufferValid = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public byte getType()
/*     */   {
/* 334 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(byte type)
/*     */   {
/* 339 */     this.type = type;
/*     */   }
/*     */   
/*     */   public boolean isDurable()
/*     */   {
/* 344 */     return this.durable;
/*     */   }
/*     */   
/*     */   public void setDurable(boolean durable)
/*     */   {
/* 349 */     if (this.durable != durable)
/*     */     {
/* 351 */       this.durable = durable;
/*     */       
/* 353 */       this.bufferValid = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public long getExpiration()
/*     */   {
/* 359 */     return this.expiration;
/*     */   }
/*     */   
/*     */   public void setExpiration(long expiration)
/*     */   {
/* 364 */     if (this.expiration != expiration)
/*     */     {
/* 366 */       this.expiration = expiration;
/*     */       
/* 368 */       this.bufferValid = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public long getTimestamp()
/*     */   {
/* 374 */     return this.timestamp;
/*     */   }
/*     */   
/*     */   public void setTimestamp(long timestamp)
/*     */   {
/* 379 */     if (this.timestamp != timestamp)
/*     */     {
/* 381 */       this.timestamp = timestamp;
/*     */       
/* 383 */       this.bufferValid = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public byte getPriority()
/*     */   {
/* 389 */     return this.priority;
/*     */   }
/*     */   
/*     */   public void setPriority(byte priority)
/*     */   {
/* 394 */     if (this.priority != priority)
/*     */     {
/* 396 */       this.priority = priority;
/*     */       
/* 398 */       this.bufferValid = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isExpired()
/*     */   {
/* 404 */     if (this.expiration == 0L)
/*     */     {
/* 406 */       return false;
/*     */     }
/*     */     
/* 409 */     return System.currentTimeMillis() - this.expiration >= 0L;
/*     */   }
/*     */   
/*     */   public Map<String, Object> toMap()
/*     */   {
/* 414 */     Map<String, Object> map = new HashMap();
/*     */     
/* 416 */     map.put("messageID", Long.valueOf(this.messageID));
/* 417 */     if (this.userID != null)
/*     */     {
/* 419 */       map.put("userID", "ID:" + this.userID.toString());
/*     */     }
/* 421 */     map.put("address", this.address.toString());
/* 422 */     map.put("type", Byte.valueOf(this.type));
/* 423 */     map.put("durable", Boolean.valueOf(this.durable));
/* 424 */     map.put("expiration", Long.valueOf(this.expiration));
/* 425 */     map.put("timestamp", Long.valueOf(this.timestamp));
/* 426 */     map.put("priority", Byte.valueOf(this.priority));
/* 427 */     for (SimpleString propName : this.properties.getPropertyNames())
/*     */     {
/* 429 */       map.put(propName.toString(), this.properties.getProperty(propName));
/*     */     }
/* 431 */     return map;
/*     */   }
/*     */   
/*     */   public void decodeFromBuffer(HornetQBuffer buffer)
/*     */   {
/* 436 */     this.buffer = buffer;
/*     */     
/* 438 */     decode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void bodyChanged()
/*     */   {
/* 445 */     checkCopy();
/*     */     
/* 447 */     this.bufferValid = false;
/*     */     
/* 449 */     this.endOfBodyPosition = -1;
/*     */   }
/*     */   
/*     */   public synchronized void checkCopy()
/*     */   {
/* 454 */     if (!this.copied)
/*     */     {
/* 456 */       forceCopy();
/*     */       
/* 458 */       this.copied = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void resetCopied()
/*     */   {
/* 464 */     this.copied = false;
/*     */   }
/*     */   
/*     */   public int getEndOfMessagePosition()
/*     */   {
/* 469 */     return this.endOfMessagePosition;
/*     */   }
/*     */   
/*     */   public int getEndOfBodyPosition()
/*     */   {
/* 474 */     if (this.endOfBodyPosition < 0)
/*     */     {
/* 476 */       this.endOfBodyPosition = this.buffer.writerIndex();
/*     */     }
/* 478 */     return this.endOfBodyPosition;
/*     */   }
/*     */   
/*     */ 
/*     */   public void encode(HornetQBuffer buff)
/*     */   {
/* 484 */     encodeToBuffer();
/*     */     
/* 486 */     buff.writeBytes(this.buffer, 13, this.endOfMessagePosition - 13);
/*     */   }
/*     */   
/*     */ 
/*     */   public void decode(HornetQBuffer buff)
/*     */   {
/* 492 */     int start = buff.readerIndex();
/*     */     
/* 494 */     this.endOfBodyPosition = buff.readInt();
/*     */     
/* 496 */     this.endOfMessagePosition = buff.getInt(this.endOfBodyPosition - 13 + start);
/*     */     
/* 498 */     int length = this.endOfMessagePosition - 13;
/*     */     
/* 500 */     this.buffer.setIndex(0, 13);
/*     */     
/* 502 */     this.buffer.writeBytes(buff, start, length);
/*     */     
/* 504 */     decode();
/*     */     
/* 506 */     buff.readerIndex(start + length);
/*     */   }
/*     */   
/*     */   public synchronized HornetQBuffer getEncodedBuffer()
/*     */   {
/* 511 */     HornetQBuffer buff = encodeToBuffer();
/*     */     
/* 513 */     if (this.bufferUsed)
/*     */     {
/* 515 */       HornetQBuffer copied = buff.copy(0, buff.capacity());
/*     */       
/* 517 */       copied.setIndex(0, this.endOfMessagePosition);
/*     */       
/* 519 */       return copied;
/*     */     }
/*     */     
/*     */ 
/* 523 */     this.buffer.setIndex(0, this.endOfMessagePosition);
/*     */     
/* 525 */     this.bufferUsed = true;
/*     */     
/* 527 */     return this.buffer;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setAddressTransient(SimpleString address)
/*     */   {
/* 533 */     this.address = address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putBooleanProperty(SimpleString key, boolean value)
/*     */   {
/* 542 */     this.properties.putBooleanProperty(key, value);
/*     */     
/* 544 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putByteProperty(SimpleString key, byte value)
/*     */   {
/* 549 */     this.properties.putByteProperty(key, value);
/*     */     
/* 551 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putBytesProperty(SimpleString key, byte[] value)
/*     */   {
/* 556 */     this.properties.putBytesProperty(key, value);
/*     */     
/* 558 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putShortProperty(SimpleString key, short value)
/*     */   {
/* 563 */     this.properties.putShortProperty(key, value);
/*     */     
/* 565 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putIntProperty(SimpleString key, int value)
/*     */   {
/* 570 */     this.properties.putIntProperty(key, value);
/*     */     
/* 572 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putLongProperty(SimpleString key, long value)
/*     */   {
/* 577 */     this.properties.putLongProperty(key, value);
/*     */     
/* 579 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putFloatProperty(SimpleString key, float value)
/*     */   {
/* 584 */     this.properties.putFloatProperty(key, value);
/*     */     
/* 586 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putDoubleProperty(SimpleString key, double value)
/*     */   {
/* 591 */     this.properties.putDoubleProperty(key, value);
/*     */     
/* 593 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putStringProperty(SimpleString key, SimpleString value)
/*     */   {
/* 598 */     this.properties.putSimpleStringProperty(key, value);
/*     */     
/* 600 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putObjectProperty(SimpleString key, Object value) throws HornetQPropertyConversionException
/*     */   {
/* 605 */     TypedProperties.setObjectProperty(key, value, this.properties);
/* 606 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putObjectProperty(String key, Object value) throws HornetQPropertyConversionException
/*     */   {
/* 611 */     putObjectProperty(new SimpleString(key), value);
/*     */     
/* 613 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putBooleanProperty(String key, boolean value)
/*     */   {
/* 618 */     this.properties.putBooleanProperty(new SimpleString(key), value);
/*     */     
/* 620 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putByteProperty(String key, byte value)
/*     */   {
/* 625 */     this.properties.putByteProperty(new SimpleString(key), value);
/*     */     
/* 627 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putBytesProperty(String key, byte[] value)
/*     */   {
/* 632 */     this.properties.putBytesProperty(new SimpleString(key), value);
/*     */     
/* 634 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putShortProperty(String key, short value)
/*     */   {
/* 639 */     this.properties.putShortProperty(new SimpleString(key), value);
/*     */     
/* 641 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putIntProperty(String key, int value)
/*     */   {
/* 646 */     this.properties.putIntProperty(new SimpleString(key), value);
/*     */     
/* 648 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putLongProperty(String key, long value)
/*     */   {
/* 653 */     this.properties.putLongProperty(new SimpleString(key), value);
/*     */     
/* 655 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putFloatProperty(String key, float value)
/*     */   {
/* 660 */     this.properties.putFloatProperty(new SimpleString(key), value);
/*     */     
/* 662 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putDoubleProperty(String key, double value)
/*     */   {
/* 667 */     this.properties.putDoubleProperty(new SimpleString(key), value);
/*     */     
/* 669 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putStringProperty(String key, String value)
/*     */   {
/* 674 */     this.properties.putSimpleStringProperty(new SimpleString(key), SimpleString.toSimpleString(value));
/*     */     
/* 676 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public void putTypedProperties(TypedProperties otherProps)
/*     */   {
/* 681 */     this.properties.putTypedProperties(otherProps);
/*     */     
/* 683 */     this.bufferValid = false;
/*     */   }
/*     */   
/*     */   public Object getObjectProperty(SimpleString key)
/*     */   {
/* 688 */     return this.properties.getProperty(key);
/*     */   }
/*     */   
/*     */   public Boolean getBooleanProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 693 */     return this.properties.getBooleanProperty(key);
/*     */   }
/*     */   
/*     */   public Boolean getBooleanProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 698 */     return this.properties.getBooleanProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Byte getByteProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 703 */     return this.properties.getByteProperty(key);
/*     */   }
/*     */   
/*     */   public Byte getByteProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 708 */     return this.properties.getByteProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public byte[] getBytesProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 713 */     return this.properties.getBytesProperty(key);
/*     */   }
/*     */   
/*     */   public byte[] getBytesProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 718 */     return getBytesProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Double getDoubleProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 723 */     return this.properties.getDoubleProperty(key);
/*     */   }
/*     */   
/*     */   public Double getDoubleProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 728 */     return this.properties.getDoubleProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Integer getIntProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 733 */     return this.properties.getIntProperty(key);
/*     */   }
/*     */   
/*     */   public Integer getIntProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 738 */     return this.properties.getIntProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Long getLongProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 743 */     return this.properties.getLongProperty(key);
/*     */   }
/*     */   
/*     */   public Long getLongProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 748 */     return this.properties.getLongProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Short getShortProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 753 */     return this.properties.getShortProperty(key);
/*     */   }
/*     */   
/*     */   public Short getShortProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 758 */     return this.properties.getShortProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Float getFloatProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 763 */     return this.properties.getFloatProperty(key);
/*     */   }
/*     */   
/*     */   public Float getFloatProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 768 */     return this.properties.getFloatProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public String getStringProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 773 */     SimpleString str = getSimpleStringProperty(key);
/*     */     
/* 775 */     if (str == null)
/*     */     {
/* 777 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 781 */     return str.toString();
/*     */   }
/*     */   
/*     */   public String getStringProperty(String key)
/*     */     throws HornetQPropertyConversionException
/*     */   {
/* 787 */     return getStringProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public SimpleString getSimpleStringProperty(SimpleString key) throws HornetQPropertyConversionException
/*     */   {
/* 792 */     return this.properties.getSimpleStringProperty(key);
/*     */   }
/*     */   
/*     */   public SimpleString getSimpleStringProperty(String key) throws HornetQPropertyConversionException
/*     */   {
/* 797 */     return this.properties.getSimpleStringProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Object getObjectProperty(String key)
/*     */   {
/* 802 */     return this.properties.getProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Object removeProperty(SimpleString key)
/*     */   {
/* 807 */     this.bufferValid = false;
/*     */     
/* 809 */     return this.properties.removeProperty(key);
/*     */   }
/*     */   
/*     */   public Object removeProperty(String key)
/*     */   {
/* 814 */     this.bufferValid = false;
/*     */     
/* 816 */     return this.properties.removeProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public boolean containsProperty(SimpleString key)
/*     */   {
/* 821 */     return this.properties.containsProperty(key);
/*     */   }
/*     */   
/*     */   public boolean containsProperty(String key)
/*     */   {
/* 826 */     return this.properties.containsProperty(new SimpleString(key));
/*     */   }
/*     */   
/*     */   public Set<SimpleString> getPropertyNames()
/*     */   {
/* 831 */     return this.properties.getPropertyNames();
/*     */   }
/*     */   
/*     */   public HornetQBuffer getWholeBuffer()
/*     */   {
/* 836 */     return this.buffer;
/*     */   }
/*     */   
/*     */   public BodyEncoder getBodyEncoder() throws HornetQException
/*     */   {
/* 841 */     return new DecodingContext();
/*     */   }
/*     */   
/*     */   public TypedProperties getTypedProperties()
/*     */   {
/* 846 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypedProperties getProperties()
/*     */   {
/* 859 */     return this.properties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private synchronized HornetQBuffer encodeToBuffer()
/*     */   {
/* 867 */     if (!this.bufferValid)
/*     */     {
/* 869 */       if (this.bufferUsed)
/*     */       {
/*     */ 
/*     */ 
/* 873 */         forceCopy();
/*     */       }
/*     */       
/* 876 */       int bodySize = getEndOfBodyPosition();
/*     */       
/*     */ 
/* 879 */       this.buffer.setInt(13, bodySize);
/*     */       
/*     */ 
/*     */ 
/* 883 */       if (bodySize + 4 > this.buffer.capacity())
/*     */       {
/* 885 */         this.buffer.setIndex(0, bodySize);
/* 886 */         this.buffer.writeInt(0);
/*     */       }
/*     */       else
/*     */       {
/* 890 */         this.buffer.setIndex(0, bodySize + 4);
/*     */       }
/*     */       
/* 893 */       encodeHeadersAndProperties(this.buffer);
/*     */       
/*     */ 
/*     */ 
/* 897 */       this.endOfMessagePosition = this.buffer.writerIndex();
/*     */       
/* 899 */       this.buffer.setInt(bodySize, this.endOfMessagePosition);
/*     */       
/* 901 */       this.bufferValid = true;
/*     */     }
/*     */     
/* 904 */     return this.buffer;
/*     */   }
/*     */   
/*     */   private void decode()
/*     */   {
/* 909 */     this.endOfBodyPosition = this.buffer.getInt(13);
/*     */     
/* 911 */     this.buffer.readerIndex(this.endOfBodyPosition + 4);
/*     */     
/* 913 */     decodeHeadersAndProperties(this.buffer);
/*     */     
/* 915 */     this.endOfMessagePosition = this.buffer.readerIndex();
/*     */     
/* 917 */     this.bufferValid = true;
/*     */   }
/*     */   
/*     */   public void createBody(int initialMessageBufferSize)
/*     */   {
/* 922 */     this.buffer = HornetQBuffers.dynamicBuffer(initialMessageBufferSize);
/*     */     
/*     */ 
/* 925 */     this.buffer.writeByte((byte)0);
/*     */     
/* 927 */     this.buffer.setIndex(17, 17);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void forceCopy()
/*     */   {
/* 934 */     this.buffer = this.buffer.copy(0, this.buffer.capacity());
/*     */     
/* 936 */     this.buffer.setIndex(0, getEndOfBodyPosition());
/*     */     
/* 938 */     if (this.bodyBuffer != null)
/*     */     {
/* 940 */       this.bodyBuffer.setBuffer(this.buffer);
/*     */     }
/*     */     
/* 943 */     this.bufferUsed = false;
/*     */   }
/*     */   
/*     */ 
/*     */   private final class DecodingContext
/*     */     implements BodyEncoder
/*     */   {
/* 950 */     private int lastPos = 0;
/*     */     
/*     */ 
/*     */ 
/*     */     public DecodingContext() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void open() {}
/*     */     
/*     */ 
/*     */     public void close() {}
/*     */     
/*     */ 
/*     */     public long getLargeBodySize()
/*     */     {
/* 966 */       return MessageImpl.this.buffer.writerIndex();
/*     */     }
/*     */     
/*     */     public int encode(ByteBuffer bufferRead) throws HornetQException
/*     */     {
/* 971 */       HornetQBuffer buffer = HornetQBuffers.wrappedBuffer(bufferRead);
/* 972 */       return encode(buffer, bufferRead.capacity());
/*     */     }
/*     */     
/*     */     public int encode(HornetQBuffer bufferOut, int size)
/*     */     {
/* 977 */       bufferOut.writeBytes(MessageImpl.this.getWholeBuffer(), this.lastPos, size);
/* 978 */       this.lastPos += size;
/* 979 */       return size;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\message\impl\MessageImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */