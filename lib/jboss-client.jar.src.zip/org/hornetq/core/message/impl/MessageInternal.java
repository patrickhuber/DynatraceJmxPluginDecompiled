package org.hornetq.core.message.impl;

import java.io.InputStream;
import org.hornetq.api.core.HornetQBuffer;
import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.Message;
import org.hornetq.api.core.SimpleString;
import org.hornetq.core.message.BodyEncoder;
import org.hornetq.utils.TypedProperties;

public abstract interface MessageInternal
  extends Message
{
  public abstract void decodeFromBuffer(HornetQBuffer paramHornetQBuffer);
  
  public abstract int getEndOfMessagePosition();
  
  public abstract int getEndOfBodyPosition();
  
  public abstract void checkCopy();
  
  public abstract void bodyChanged();
  
  public abstract void resetCopied();
  
  public abstract boolean isServerMessage();
  
  public abstract HornetQBuffer getEncodedBuffer();
  
  public abstract int getHeadersAndPropertiesEncodeSize();
  
  public abstract HornetQBuffer getWholeBuffer();
  
  public abstract void encodeHeadersAndProperties(HornetQBuffer paramHornetQBuffer);
  
  public abstract void decodeHeadersAndProperties(HornetQBuffer paramHornetQBuffer);
  
  public abstract BodyEncoder getBodyEncoder()
    throws HornetQException;
  
  public abstract InputStream getBodyInputStream();
  
  public abstract void setAddressTransient(SimpleString paramSimpleString);
  
  public abstract TypedProperties getTypedProperties();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\message\impl\MessageInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */