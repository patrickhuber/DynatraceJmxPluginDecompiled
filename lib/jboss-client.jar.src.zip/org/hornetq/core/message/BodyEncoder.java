package org.hornetq.core.message;

import java.nio.ByteBuffer;
import org.hornetq.api.core.HornetQBuffer;
import org.hornetq.api.core.HornetQException;

public abstract interface BodyEncoder
{
  public abstract void open()
    throws HornetQException;
  
  public abstract void close()
    throws HornetQException;
  
  public abstract int encode(ByteBuffer paramByteBuffer)
    throws HornetQException;
  
  public abstract int encode(HornetQBuffer paramHornetQBuffer, int paramInt)
    throws HornetQException;
  
  public abstract long getLargeBodySize();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\message\BodyEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */