/*    */ package org.hornetq.core.exception;
/*    */ 
/*    */ import javax.transaction.xa.XAException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HornetQXAException
/*    */   extends XAException
/*    */ {
/*    */   private static final long serialVersionUID = 6535914602965015803L;
/*    */   
/*    */   public HornetQXAException(int errorCode, String message)
/*    */   {
/* 31 */     super(message);
/*    */     
/* 33 */     this.errorCode = errorCode;
/*    */   }
/*    */   
/*    */   public HornetQXAException(int errorCode)
/*    */   {
/* 38 */     super(errorCode);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\exception\HornetQXAException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */