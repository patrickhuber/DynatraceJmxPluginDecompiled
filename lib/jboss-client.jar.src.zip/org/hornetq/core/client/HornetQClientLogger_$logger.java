/*     */ package org.hornetq.core.client;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.hornetq.api.core.HornetQExceptionType;
/*     */ import org.hornetq.api.core.Interceptor;
/*     */ import org.hornetq.core.protocol.core.Packet;
/*     */ import org.jboss.logging.BasicLogger;
/*     */ import org.jboss.logging.DelegatingBasicLogger;
/*     */ import org.jboss.logging.Logger;
/*     */ import org.jboss.logging.Logger.Level;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HornetQClientLogger_$logger
/*     */   extends DelegatingBasicLogger
/*     */   implements Serializable, HornetQClientLogger, BasicLogger
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String projectCode = "HQ";
/*  27 */   private static final String FQCN = logger.class.getName();
/*     */   private static final String sessionNotXA = "Session is not XA";
/*     */   private static final String unableToCloseSession = "Unable to close session";
/*     */   private static final String noVersionOnClasspath = "Cannot find hornetq-version.properties on classpath: {0}";
/*     */   private static final String errorSendingNotifOnDiscoveryStop = "unable to send notification when discovery group is stopped";
/*     */   private static final String waitingForRetry = "Waiting {0} milliseconds before next retry. RetryInterval={1} and multiplier={2}";
/*     */   private static final String createConnectorException = "connector.create or connectorFactory.createConnector should never throw an exception, implementation is badly behaved, but we will deal with it anyway.";
/*     */   private static final String errorSendingTopology = "error sending topology";
/*     */   private static final String errorCallingInterceptor = "Failure in calling interceptor: {0}";
/*     */   private static final String propertyNotLong = "Property {0} must be an Long, it is {1}";
/*     */   private static final String errorCallingEnd = "XA end operation failed ";
/*     */   private static final String dumpingSessionStacks = "**** Dumping session creation stacks ****";
/*     */   private static final String errorCallingFailureListener = "Failed to execute failure listener";
/*     */   private static final String errorStartingLocator = "error starting server locator";
/*     */   private static final String ioDiscoveryError = "Could not bind to {0} ({1} address); make sure your discovery group-address is of the same type as the IP stack (IPv4 or IPv6).\nIgnoring discovery group-address, but this may lead to cross talking.";
/*     */   private static final String errorClearingMessages = "Error on clearing messages";
/*     */   private static final String errorReceivingPAcketInDiscovery = "error receiving packet in discovery";
/*     */   private static final String failoverDuringPrepareRollingBack = "failover occurred during prepare rolling back";
/*     */   private static final String errorAddingPacket = "error adding packet";
/*     */   private static final String dumpingSessionStack = "session created";
/*     */   private static final String timedOutWaitingForScheduledPoolTermination = "Timed out waiting for scheduled pool to terminate";
/*     */   private static final String failedToExecuteListener = "Failed to execute failure listener";
/*     */   private static final String errorClosingCache = "error closing LargeMessage file cache";
/*     */   private static final String errorStoppingDiscoveryBroadcastEndpoint = "Exception happened while stopping Discovery BroadcastEndpoint {0}";
/*     */   private static final String invalidConcurrentSessionUsage = "Invalid concurrent session usage. Sessions are not supposed to be used by more than one thread concurrently.";
/*     */   private static final String failedToStopDiscovery = "Failed to stop discovery group";
/*     */   private static final String retryCreateSessionSeverStarting = "Server is starting, retry to create the session {0}";
/*     */   private static final String errorSendingTopologyNodedown = "error sending topology";
/*     */   private static final String errorReadingIndex = "error reading index";
/*     */   private static final String failoverDuringCommit = "failover occured during commit throwing XAException.XA_RETRY";
/*     */   private static final String multipleServersBroadcastingSameNode = "There are more than one servers on the network broadcasting the same node id. You will see this message exactly once (per node) if a node is restarted, in which case it can be safely ignored. But if it is logged continuously it means you really do have more than one node on the same network active concurrently with the same node id. This could occur if you have a backup node active at the same time as its live node. nodeID={0}";
/*     */   private static final String errorReSettingIndex = "error resetting index";
/*     */   private static final String clientSessionNotClosed = "I am closing a core ClientSession you left open. Please make sure you close all ClientSessions explicitly before letting them go out of scope! {0}";
/*     */   private static final String onMessageError = "Failed to call onMessage";
/*     */   private static final String errorCallingCancel = "error calling cancel";
/*     */   private static final String factoryLeftOpen = "I am closing a core ClientSessionFactory you left open. Please make sure you close all ClientSessionFactories explicitly before letting them go out of scope! {0}";
/*     */   private static final String serverLocatorNotClosed = "Closing a Server Locator left open. Please make sure you close all Server Locators explicitly before letting them go out of scope! {0}";
/*     */   private static final String broadcastGroupBindError = "local-bind-address specified for broadcast group but no local-bind-port specified so socket will NOT be bound to a local address/port";
/*     */   private static final String connectionFailureDetected = "Connection failure has been detected: {0} [code={1}]";
/*     */   private static final String errorCallingLifeCycleListener = "Failed to execute connection life cycle listener";
/*     */   private static final String warn = "{0}";
/*     */   private static final String errorFinalisingCache = "Exception during finalization for LargeMessage file cache";
/*     */   private static final String errorReadingCache = "error reading LargeMessage file cache";
/*     */   private static final String failedToReceiveDatagramInDiscovery = "Failed to receive datagram from Broadcaster UDP";
/*     */   private static final String errorSettingIndex = "error setting index";
/*     */   private static final String errorCreatingNettyConnection = "Failed to create netty connection";
/*     */   private static final String compressedLargeMessageError = "Compressed large message tried to read {0} bytes from stream {1}";
/*     */   private static final String errorDuringPrepare = "failover occurred during prepare rolling back";
/*     */   private static final String failedToCleanupSession = "failed to cleanup session";
/*     */   private static final String resettingSessionAfterFailure = "resetting session after failure";
/*     */   private static final String timedOutStoppingDiscovery = "Timed out waiting to stop discovery thread";
/*     */   private static final String timeoutClosingNettyChannel = "Timed out waiting for netty channel to close";
/*     */   private static final String commitAfterFailover = "committing transaction after failover occurred, any non persistent messages may be lost";
/*     */   private static final String timeoutFlushingPacket = "Timed out waiting for packet to be flushed";
/*     */   private static final String timedOutWaitingForTermination = "Timed out waiting for pool to terminate";
/*     */   private static final String packetOutOfOrder = "Packet {0} was answered out of sequence due to a previous server timeout and it's being ignored";
/*     */   private static final String caughtunexpectedThrowable = "Caught unexpected Throwable";
/*     */   private static final String failedToConnectToServer0 = "Failed to connect to server.";
/*     */   private static final String jvmAllocatedMoreMemory = "Warning: JVM allocated more data what would make results invalid {0}:{1}";
/*     */   private static final String receivedExceptionAsynchronously = "Received exception asynchronously from server";
/*     */   private static final String errorCallingStart = "XA start operation failed {0} code:{1}";
/*     */   private static final String timeoutClosingSSL = "Timed out waiting for netty ssl close future to complete";
/*     */   private static final String errorDecodingPacket = "Failed to decode packet";
/*     */   private static final String propertyNotBoolean = "Property {0} must be an Boolean, it is {1}";
/*     */   private static final String outOfCreditOnFlowControl = "Destination address={0} is blocked. If the system is configured to block make sure you consume messages on this configuration.";
/*     */   private static final String failoverDuringPrepare = "failover occurred during prepare re-trying";
/*     */   private static final String timeOutWaitingForProcessing = "Timed out waiting for handler to complete processing";
/*     */   private static final String errorOnXMLTransformInvalidConf = "Invalid configuration";
/*     */   private static final String failedToHandleFailover = "Failed to handle failover";
/*     */   private static final String propertyNotInteger = "Property {0} must be an Integer, it is {1}";
/*     */   private static final String cannotFindPacketToClear = "Can not find packet to clear: {0} last received command id first stored command id {1}";
/*     */   private static final String failedToHandlePacket = "Failed to handle packet";
/*     */   private static final String errorHandlingPacket = "Unexpected error handling packet {0}";
/*     */   private static final String failedToCallListenerInDiscovery = "Failed to call discovery listener";
/*     */   private static final String failedToConnectToServer1 = "Tried {0} times to connect. Now giving up on reconnecting it.";
/*     */   private static final String errorOnXMLTransform = "Failed to invoke getTextContent() on node {0}";
/*     */   private static final String errorConnectingToNodes = "did not connect the cluster connection to other nodes";
/*     */   
/*     */   public HornetQClientLogger_$logger(Logger log) {
/* 106 */     super(log);
/*     */   }
/*     */   
/*     */   public final void sessionNotXA()
/*     */   {
/* 111 */     this.log.logv(FQCN, Logger.Level.ERROR, null, "HQ214006: " + sessionNotXA$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String sessionNotXA$str() {
/* 115 */     return "Session is not XA";
/*     */   }
/*     */   
/*     */   public final void unableToCloseSession(Exception e)
/*     */   {
/* 120 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212003: " + unableToCloseSession$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String unableToCloseSession$str() {
/* 124 */     return "Unable to close session";
/*     */   }
/*     */   
/*     */   public final void noVersionOnClasspath(String classpath)
/*     */   {
/* 129 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212046: " + noVersionOnClasspath$str(), classpath);
/*     */   }
/*     */   
/*     */   protected String noVersionOnClasspath$str() {
/* 133 */     return "Cannot find hornetq-version.properties on classpath: {0}";
/*     */   }
/*     */   
/*     */   public final void errorSendingNotifOnDiscoveryStop(Throwable e)
/*     */   {
/* 138 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212033: " + errorSendingNotifOnDiscoveryStop$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorSendingNotifOnDiscoveryStop$str() {
/* 142 */     return "unable to send notification when discovery group is stopped";
/*     */   }
/*     */   
/*     */   public final void waitingForRetry(Long interval, Long retryInterval, Double multiplier)
/*     */   {
/* 147 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212006: " + waitingForRetry$str(), interval, retryInterval, multiplier);
/*     */   }
/*     */   
/*     */   protected String waitingForRetry$str() {
/* 151 */     return "Waiting {0} milliseconds before next retry. RetryInterval={1} and multiplier={2}";
/*     */   }
/*     */   
/*     */   public final void createConnectorException(Exception e)
/*     */   {
/* 156 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212007: " + createConnectorException$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String createConnectorException$str() {
/* 160 */     return "connector.create or connectorFactory.createConnector should never throw an exception, implementation is badly behaved, but we will deal with it anyway.";
/*     */   }
/*     */   
/*     */   public final void errorSendingTopology(Throwable e)
/*     */   {
/* 165 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212030: " + errorSendingTopology$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorSendingTopology$str() {
/* 169 */     return "error sending topology";
/*     */   }
/*     */   
/*     */   public final void errorCallingInterceptor(Throwable e, Interceptor interceptor)
/*     */   {
/* 174 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212038: " + errorCallingInterceptor$str(), interceptor);
/*     */   }
/*     */   
/*     */   protected String errorCallingInterceptor$str() {
/* 178 */     return "Failure in calling interceptor: {0}";
/*     */   }
/*     */   
/*     */   public final void propertyNotLong(String propName, String name)
/*     */   {
/* 183 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212044: " + propertyNotLong$str(), propName, name);
/*     */   }
/*     */   
/*     */   protected String propertyNotLong$str() {
/* 187 */     return "Property {0} must be an Long, it is {1}";
/*     */   }
/*     */   
/*     */   public final void errorCallingEnd(Throwable t)
/*     */   {
/* 192 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214004: " + errorCallingEnd$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorCallingEnd$str() {
/* 196 */     return "XA end operation failed ";
/*     */   }
/*     */   
/*     */   public final void dumpingSessionStacks()
/*     */   {
/* 201 */     this.log.logv(FQCN, Logger.Level.INFO, null, "HQ211000: " + dumpingSessionStacks$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String dumpingSessionStacks$str() {
/* 205 */     return "**** Dumping session creation stacks ****";
/*     */   }
/*     */   
/*     */   public final void errorCallingFailureListener(Throwable e)
/*     */   {
/* 210 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214014: " + errorCallingFailureListener$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorCallingFailureListener$str() {
/* 214 */     return "Failed to execute failure listener";
/*     */   }
/*     */   
/*     */   public final void errorStartingLocator(Exception e)
/*     */   {
/* 219 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212028: " + errorStartingLocator$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorStartingLocator$str() {
/* 223 */     return "error starting server locator";
/*     */   }
/*     */   
/*     */   public final void ioDiscoveryError(String hostAddress, String s)
/*     */   {
/* 228 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212049: " + ioDiscoveryError$str(), hostAddress, s);
/*     */   }
/*     */   
/*     */   protected String ioDiscoveryError$str() {
/* 232 */     return "Could not bind to {0} ({1} address); make sure your discovery group-address is of the same type as the IP stack (IPv4 or IPv6).\nIgnoring discovery group-address, but this may lead to cross talking.";
/*     */   }
/*     */   
/*     */   public final void errorClearingMessages(Throwable e)
/*     */   {
/* 237 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212001: " + errorClearingMessages$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorClearingMessages$str() {
/* 241 */     return "Error on clearing messages";
/*     */   }
/*     */   
/*     */   public final void errorReceivingPAcketInDiscovery(Throwable e)
/*     */   {
/* 246 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212035: " + errorReceivingPAcketInDiscovery$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorReceivingPAcketInDiscovery$str() {
/* 250 */     return "error receiving packet in discovery";
/*     */   }
/*     */   
/*     */   public final void failoverDuringPrepareRollingBack()
/*     */   {
/* 255 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212014: " + failoverDuringPrepareRollingBack$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failoverDuringPrepareRollingBack$str() {
/* 259 */     return "failover occurred during prepare rolling back";
/*     */   }
/*     */   
/*     */   public final void errorAddingPacket(Exception e)
/*     */   {
/* 264 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212017: " + errorAddingPacket$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorAddingPacket$str() {
/* 268 */     return "error adding packet";
/*     */   }
/*     */   
/*     */   public final void dumpingSessionStack(Exception e)
/*     */   {
/* 273 */     this.log.logv(FQCN, Logger.Level.INFO, e, "HQ211001: " + dumpingSessionStack$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String dumpingSessionStack$str() {
/* 277 */     return "session created";
/*     */   }
/*     */   
/*     */   public final void timedOutWaitingForScheduledPoolTermination()
/*     */   {
/* 282 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212027: " + timedOutWaitingForScheduledPoolTermination$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timedOutWaitingForScheduledPoolTermination$str() {
/* 286 */     return "Timed out waiting for scheduled pool to terminate";
/*     */   }
/*     */   
/*     */   public final void failedToExecuteListener(Throwable t)
/*     */   {
/* 291 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214002: " + failedToExecuteListener$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToExecuteListener$str() {
/* 295 */     return "Failed to execute failure listener";
/*     */   }
/*     */   
/*     */   public final void errorClosingCache(Exception e)
/*     */   {
/* 300 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212023: " + errorClosingCache$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorClosingCache$str() {
/* 304 */     return "error closing LargeMessage file cache";
/*     */   }
/*     */   
/*     */   public final void errorStoppingDiscoveryBroadcastEndpoint(Object endpoint, Throwable t)
/*     */   {
/* 309 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214020: " + errorStoppingDiscoveryBroadcastEndpoint$str(), endpoint);
/*     */   }
/*     */   
/*     */   protected String errorStoppingDiscoveryBroadcastEndpoint$str() {
/* 313 */     return "Exception happened while stopping Discovery BroadcastEndpoint {0}";
/*     */   }
/*     */   
/*     */   public final void invalidConcurrentSessionUsage(Throwable t)
/*     */   {
/* 318 */     this.log.logv(FQCN, Logger.Level.WARN, t, "HQ214021: " + invalidConcurrentSessionUsage$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String invalidConcurrentSessionUsage$str() {
/* 322 */     return "Invalid concurrent session usage. Sessions are not supposed to be used by more than one thread concurrently.";
/*     */   }
/*     */   
/*     */   public final void failedToStopDiscovery(Throwable e)
/*     */   {
/* 327 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214009: " + failedToStopDiscovery$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToStopDiscovery$str() {
/* 331 */     return "Failed to stop discovery group";
/*     */   }
/*     */   
/*     */   public final void retryCreateSessionSeverStarting(String name)
/*     */   {
/* 336 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212010: " + retryCreateSessionSeverStarting$str(), name);
/*     */   }
/*     */   
/*     */   protected String retryCreateSessionSeverStarting$str() {
/* 340 */     return "Server is starting, retry to create the session {0}";
/*     */   }
/*     */   
/*     */   public final void errorSendingTopologyNodedown(Throwable e)
/*     */   {
/* 345 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212031: " + errorSendingTopologyNodedown$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorSendingTopologyNodedown$str() {
/* 349 */     return "error sending topology";
/*     */   }
/*     */   
/*     */   public final void errorReadingIndex(Exception e)
/*     */   {
/* 354 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212019: " + errorReadingIndex$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorReadingIndex$str() {
/* 358 */     return "error reading index";
/*     */   }
/*     */   
/*     */   public final void failoverDuringCommit()
/*     */   {
/* 363 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212012: " + failoverDuringCommit$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failoverDuringCommit$str() {
/* 367 */     return "failover occured during commit throwing XAException.XA_RETRY";
/*     */   }
/*     */   
/*     */   public final void multipleServersBroadcastingSameNode(String nodeId)
/*     */   {
/* 372 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212034: " + multipleServersBroadcastingSameNode$str(), nodeId);
/*     */   }
/*     */   
/*     */   protected String multipleServersBroadcastingSameNode$str() {
/* 376 */     return "There are more than one servers on the network broadcasting the same node id. You will see this message exactly once (per node) if a node is restarted, in which case it can be safely ignored. But if it is logged continuously it means you really do have more than one node on the same network active concurrently with the same node id. This could occur if you have a backup node active at the same time as its live node. nodeID={0}";
/*     */   }
/*     */   
/*     */   public final void errorReSettingIndex(Exception e)
/*     */   {
/* 381 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212021: " + errorReSettingIndex$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorReSettingIndex$str() {
/* 385 */     return "error resetting index";
/*     */   }
/*     */   
/*     */   public final void clientSessionNotClosed(Exception e, int identity)
/*     */   {
/* 390 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212016: " + clientSessionNotClosed$str(), Integer.valueOf(identity));
/*     */   }
/*     */   
/*     */   protected String clientSessionNotClosed$str() {
/* 394 */     return "I am closing a core ClientSession you left open. Please make sure you close all ClientSessions explicitly before letting them go out of scope! {0}";
/*     */   }
/*     */   
/*     */   public final void onMessageError(Throwable e)
/*     */   {
/* 399 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214000: " + onMessageError$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String onMessageError$str() {
/* 403 */     return "Failed to call onMessage";
/*     */   }
/*     */   
/*     */   public final void errorCallingCancel(Exception e)
/*     */   {
/* 408 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212018: " + errorCallingCancel$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorCallingCancel$str() {
/* 412 */     return "error calling cancel";
/*     */   }
/*     */   
/*     */   public final void factoryLeftOpen(Exception e, int i)
/*     */   {
/* 417 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212008: " + factoryLeftOpen$str(), Integer.valueOf(i));
/*     */   }
/*     */   
/*     */   protected String factoryLeftOpen$str() {
/* 421 */     return "I am closing a core ClientSessionFactory you left open. Please make sure you close all ClientSessionFactories explicitly before letting them go out of scope! {0}";
/*     */   }
/*     */   
/*     */   public final void serverLocatorNotClosed(Exception e, int identity)
/*     */   {
/* 426 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212029: " + serverLocatorNotClosed$str(), Integer.valueOf(identity));
/*     */   }
/*     */   
/*     */   protected String serverLocatorNotClosed$str() {
/* 430 */     return "Closing a Server Locator left open. Please make sure you close all Server Locators explicitly before letting them go out of scope! {0}";
/*     */   }
/*     */   
/*     */   public final void broadcastGroupBindError()
/*     */   {
/* 435 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212048: " + broadcastGroupBindError$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String broadcastGroupBindError$str() {
/* 439 */     return "local-bind-address specified for broadcast group but no local-bind-port specified so socket will NOT be bound to a local address/port";
/*     */   }
/*     */   
/*     */   public final void connectionFailureDetected(String message, HornetQExceptionType type)
/*     */   {
/* 444 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212037: " + connectionFailureDetected$str(), message, type);
/*     */   }
/*     */   
/*     */   protected String connectionFailureDetected$str() {
/* 448 */     return "Connection failure has been detected: {0} [code={1}]";
/*     */   }
/*     */   
/*     */   public final void errorCallingLifeCycleListener(Throwable e)
/*     */   {
/* 453 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214015: " + errorCallingLifeCycleListener$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorCallingLifeCycleListener$str() {
/* 457 */     return "Failed to execute connection life cycle listener";
/*     */   }
/*     */   
/*     */   public final void warn(String message)
/*     */   {
/* 462 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212000: " + warn$str(), message);
/*     */   }
/*     */   
/*     */   protected String warn$str() {
/* 466 */     return "{0}";
/*     */   }
/*     */   
/*     */   public final void errorFinalisingCache(Exception e)
/*     */   {
/* 471 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212024: " + errorFinalisingCache$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorFinalisingCache$str() {
/* 475 */     return "Exception during finalization for LargeMessage file cache";
/*     */   }
/*     */   
/*     */   public final void errorReadingCache(Exception e)
/*     */   {
/* 480 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212022: " + errorReadingCache$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorReadingCache$str() {
/* 484 */     return "error reading LargeMessage file cache";
/*     */   }
/*     */   
/*     */   public final void failedToReceiveDatagramInDiscovery(Throwable e)
/*     */   {
/* 489 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214010: " + failedToReceiveDatagramInDiscovery$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToReceiveDatagramInDiscovery$str() {
/* 493 */     return "Failed to receive datagram from Broadcaster UDP";
/*     */   }
/*     */   
/*     */   public final void errorSettingIndex(Exception e)
/*     */   {
/* 498 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212020: " + errorSettingIndex$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorSettingIndex$str() {
/* 502 */     return "error setting index";
/*     */   }
/*     */   
/*     */   public final void errorCreatingNettyConnection(Throwable e)
/*     */   {
/* 507 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214016: " + errorCreatingNettyConnection$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorCreatingNettyConnection$str() {
/* 511 */     return "Failed to create netty connection";
/*     */   }
/*     */   
/*     */   public final void compressedLargeMessageError(int length, int nReadBytes)
/*     */   {
/* 516 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212050: " + compressedLargeMessageError$str(), Integer.valueOf(length), Integer.valueOf(nReadBytes));
/*     */   }
/*     */   
/*     */   protected String compressedLargeMessageError$str() {
/* 520 */     return "Compressed large message tried to read {0} bytes from stream {1}";
/*     */   }
/*     */   
/*     */   public final void errorDuringPrepare(Throwable e)
/*     */   {
/* 525 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212015: " + errorDuringPrepare$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorDuringPrepare$str() {
/* 529 */     return "failover occurred during prepare rolling back";
/*     */   }
/*     */   
/*     */   public final void failedToCleanupSession(Exception e)
/*     */   {
/* 534 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214001: " + failedToCleanupSession$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToCleanupSession$str() {
/* 538 */     return "failed to cleanup session";
/*     */   }
/*     */   
/*     */   public final void resettingSessionAfterFailure()
/*     */   {
/* 543 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212009: " + resettingSessionAfterFailure$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String resettingSessionAfterFailure$str() {
/* 547 */     return "resetting session after failure";
/*     */   }
/*     */   
/*     */   public final void timedOutStoppingDiscovery()
/*     */   {
/* 552 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212032: " + timedOutStoppingDiscovery$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timedOutStoppingDiscovery$str() {
/* 556 */     return "Timed out waiting to stop discovery thread";
/*     */   }
/*     */   
/*     */   public final void timeoutClosingNettyChannel()
/*     */   {
/* 561 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212041: " + timeoutClosingNettyChannel$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timeoutClosingNettyChannel$str() {
/* 565 */     return "Timed out waiting for netty channel to close";
/*     */   }
/*     */   
/*     */   public final void commitAfterFailover()
/*     */   {
/* 570 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212011: " + commitAfterFailover$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String commitAfterFailover$str() {
/* 574 */     return "committing transaction after failover occurred, any non persistent messages may be lost";
/*     */   }
/*     */   
/*     */   public final void timeoutFlushingPacket()
/*     */   {
/* 579 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212042: " + timeoutFlushingPacket$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timeoutFlushingPacket$str() {
/* 583 */     return "Timed out waiting for packet to be flushed";
/*     */   }
/*     */   
/*     */   public final void timedOutWaitingForTermination()
/*     */   {
/* 588 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212026: " + timedOutWaitingForTermination$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timedOutWaitingForTermination$str() {
/* 592 */     return "Timed out waiting for pool to terminate";
/*     */   }
/*     */   
/*     */   public final void packetOutOfOrder(Object obj, Throwable t)
/*     */   {
/* 597 */     this.log.logv(FQCN, Logger.Level.WARN, t, "HQ214022: " + packetOutOfOrder$str(), obj);
/*     */   }
/*     */   
/*     */   protected String packetOutOfOrder$str() {
/* 601 */     return "Packet {0} was answered out of sequence due to a previous server timeout and it's being ignored";
/*     */   }
/*     */   
/*     */   public final void caughtunexpectedThrowable(Throwable t)
/*     */   {
/* 606 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214017: " + caughtunexpectedThrowable$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String caughtunexpectedThrowable$str() {
/* 610 */     return "Caught unexpected Throwable";
/*     */   }
/*     */   
/*     */   public final void failedToConnectToServer()
/*     */   {
/* 615 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212004: " + failedToConnectToServer0$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToConnectToServer0$str() {
/* 619 */     return "Failed to connect to server.";
/*     */   }
/*     */   
/*     */   public final void jvmAllocatedMoreMemory(Long totalMemory1, Long totalMemory2)
/*     */   {
/* 624 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212047: " + jvmAllocatedMoreMemory$str(), totalMemory1, totalMemory2);
/*     */   }
/*     */   
/*     */   protected String jvmAllocatedMoreMemory$str() {
/* 628 */     return "Warning: JVM allocated more data what would make results invalid {0}:{1}";
/*     */   }
/*     */   
/*     */   public final void receivedExceptionAsynchronously(Exception e)
/*     */   {
/* 633 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214007: " + receivedExceptionAsynchronously$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String receivedExceptionAsynchronously$str() {
/* 637 */     return "Received exception asynchronously from server";
/*     */   }
/*     */   
/*     */   public final void errorCallingStart(String message, Integer code)
/*     */   {
/* 642 */     this.log.logv(FQCN, Logger.Level.ERROR, null, "HQ214005: " + errorCallingStart$str(), message, code);
/*     */   }
/*     */   
/*     */   protected String errorCallingStart$str() {
/* 646 */     return "XA start operation failed {0} code:{1}";
/*     */   }
/*     */   
/*     */   public final void timeoutClosingSSL()
/*     */   {
/* 651 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212040: " + timeoutClosingSSL$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timeoutClosingSSL$str() {
/* 655 */     return "Timed out waiting for netty ssl close future to complete";
/*     */   }
/*     */   
/*     */   public final void errorDecodingPacket(Exception e)
/*     */   {
/* 660 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214013: " + errorDecodingPacket$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorDecodingPacket$str() {
/* 664 */     return "Failed to decode packet";
/*     */   }
/*     */   
/*     */   public final void propertyNotBoolean(String propName, String name)
/*     */   {
/* 669 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212045: " + propertyNotBoolean$str(), propName, name);
/*     */   }
/*     */   
/*     */   protected String propertyNotBoolean$str() {
/* 673 */     return "Property {0} must be an Boolean, it is {1}";
/*     */   }
/*     */   
/*     */   public final void outOfCreditOnFlowControl(String address)
/*     */   {
/* 678 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ214024: " + outOfCreditOnFlowControl$str(), address);
/*     */   }
/*     */   
/*     */   protected String outOfCreditOnFlowControl$str() {
/* 682 */     return "Destination address={0} is blocked. If the system is configured to block make sure you consume messages on this configuration.";
/*     */   }
/*     */   
/*     */   public final void failoverDuringPrepare()
/*     */   {
/* 687 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212013: " + failoverDuringPrepare$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failoverDuringPrepare$str() {
/* 691 */     return "failover occurred during prepare re-trying";
/*     */   }
/*     */   
/*     */   public final void timeOutWaitingForProcessing()
/*     */   {
/* 696 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212002: " + timeOutWaitingForProcessing$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String timeOutWaitingForProcessing$str() {
/* 700 */     return "Timed out waiting for handler to complete processing";
/*     */   }
/*     */   
/*     */   public final void errorOnXMLTransformInvalidConf(Throwable t)
/*     */   {
/* 705 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214019: " + errorOnXMLTransformInvalidConf$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorOnXMLTransformInvalidConf$str() {
/* 709 */     return "Invalid configuration";
/*     */   }
/*     */   
/*     */   public final void failedToHandleFailover(Throwable t)
/*     */   {
/* 714 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214003: " + failedToHandleFailover$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToHandleFailover$str() {
/* 718 */     return "Failed to handle failover";
/*     */   }
/*     */   
/*     */   public final void propertyNotInteger(String propName, String name)
/*     */   {
/* 723 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212043: " + propertyNotInteger$str(), propName, name);
/*     */   }
/*     */   
/*     */   protected String propertyNotInteger$str() {
/* 727 */     return "Property {0} must be an Integer, it is {1}";
/*     */   }
/*     */   
/*     */   public final void cannotFindPacketToClear(Integer lastReceivedCommandID, Integer firstStoredCommandID)
/*     */   {
/* 732 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212036: " + cannotFindPacketToClear$str(), lastReceivedCommandID, firstStoredCommandID);
/*     */   }
/*     */   
/*     */   protected String cannotFindPacketToClear$str() {
/* 736 */     return "Can not find packet to clear: {0} last received command id first stored command id {1}";
/*     */   }
/*     */   
/*     */   public final void failedToHandlePacket(Exception e)
/*     */   {
/* 741 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214008: " + failedToHandlePacket$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToHandlePacket$str() {
/* 745 */     return "Failed to handle packet";
/*     */   }
/*     */   
/*     */   public final void errorHandlingPacket(Throwable t, Packet packet)
/*     */   {
/* 750 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214012: " + errorHandlingPacket$str(), packet);
/*     */   }
/*     */   
/*     */   protected String errorHandlingPacket$str() {
/* 754 */     return "Unexpected error handling packet {0}";
/*     */   }
/*     */   
/*     */   public final void failedToCallListenerInDiscovery(Throwable e)
/*     */   {
/* 759 */     this.log.logv(FQCN, Logger.Level.ERROR, e, "HQ214011: " + failedToCallListenerInDiscovery$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String failedToCallListenerInDiscovery$str() {
/* 763 */     return "Failed to call discovery listener";
/*     */   }
/*     */   
/*     */   public final void failedToConnectToServer(Integer reconnectAttempts)
/*     */   {
/* 768 */     this.log.logv(FQCN, Logger.Level.WARN, null, "HQ212005: " + failedToConnectToServer1$str(), reconnectAttempts);
/*     */   }
/*     */   
/*     */   protected String failedToConnectToServer1$str() {
/* 772 */     return "Tried {0} times to connect. Now giving up on reconnecting it.";
/*     */   }
/*     */   
/*     */   public final void errorOnXMLTransform(Throwable t, Node n)
/*     */   {
/* 777 */     this.log.logv(FQCN, Logger.Level.ERROR, t, "HQ214018: " + errorOnXMLTransform$str(), n);
/*     */   }
/*     */   
/*     */   protected String errorOnXMLTransform$str() {
/* 781 */     return "Failed to invoke getTextContent() on node {0}";
/*     */   }
/*     */   
/*     */   public final void errorConnectingToNodes(Exception e)
/*     */   {
/* 786 */     this.log.logv(FQCN, Logger.Level.WARN, e, "HQ212025: " + errorConnectingToNodes$str(), new Object[0]);
/*     */   }
/*     */   
/*     */   protected String errorConnectingToNodes$str() {
/* 790 */     return "did not connect the cluster connection to other nodes";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\HornetQClientLogger_$logger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */