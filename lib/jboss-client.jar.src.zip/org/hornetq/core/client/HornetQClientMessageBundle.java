/*    */ package org.hornetq.core.client;
/*    */ 
/*    */ import org.hornetq.api.core.HornetQAddressFullException;
/*    */ import org.hornetq.api.core.HornetQConnectionTimedOutException;
/*    */ import org.hornetq.api.core.HornetQDisconnectedException;
/*    */ import org.hornetq.api.core.HornetQIllegalStateException;
/*    */ import org.hornetq.api.core.HornetQInterceptorRejectedPacketException;
/*    */ import org.hornetq.api.core.HornetQInternalErrorException;
/*    */ import org.hornetq.api.core.HornetQLargeMessageException;
/*    */ import org.hornetq.api.core.HornetQLargeMessageInterruptedException;
/*    */ import org.hornetq.api.core.HornetQNotConnectedException;
/*    */ import org.hornetq.api.core.HornetQObjectClosedException;
/*    */ import org.hornetq.api.core.HornetQTransactionOutcomeUnknownException;
/*    */ import org.hornetq.api.core.HornetQTransactionRolledBackException;
/*    */ import org.hornetq.api.core.HornetQUnBlockedException;
/*    */ import org.hornetq.core.cluster.DiscoveryGroup;
/*    */ import org.hornetq.spi.core.remoting.Connection;
/*    */ import org.jboss.logging.Cause;
/*    */ import org.jboss.logging.Message;
/*    */ import org.jboss.logging.Message.Format;
/*    */ import org.jboss.logging.MessageBundle;
/*    */ import org.jboss.logging.Messages;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @MessageBundle(projectCode="HQ")
/*    */ public abstract interface HornetQClientMessageBundle
/*    */ {
/* 59 */   public static final HornetQClientMessageBundle BUNDLE = (HornetQClientMessageBundle)Messages.getBundle(HornetQClientMessageBundle.class);
/*    */   
/*    */   @Message(id=119000, value="ClientSession closed while creating session", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInternalErrorException clientSessionClosed();
/*    */   
/*    */   @Message(id=119001, value="Failed to create session", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInternalErrorException failedToCreateSession(@Cause Throwable paramThrowable);
/*    */   
/*    */   @Message(id=119002, value="Internal Error! ClientSessionFactoryImpl::createSessionInternal just reached a condition that was not supposed to happen. Please inform this condition to the HornetQ team", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInternalErrorException clietSessionInternal();
/*    */   
/*    */   @Message(id=119003, value="Queue can not be both durable and temporary", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInternalErrorException queueMisConfigured();
/*    */   
/*    */   @Message(id=119004, value="Failed to initialise session factory", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInternalErrorException failedToInitialiseSessionFactory(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119005, value="Exception in Netty transport", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInternalErrorException nettyError();
/*    */   
/*    */   @Message(id=119006, value="Channel disconnected", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQNotConnectedException channelDisconnected();
/*    */   
/*    */   @Message(id=119007, value="Cannot connect to server(s). Tried with all available servers.", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQNotConnectedException cannotConnectToServers();
/*    */   
/*    */   @Message(id=119008, value="Failed to connect to any static connectors", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQNotConnectedException cannotConnectToStaticConnectors(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119009, value="Failed to connect to any static connectors", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQNotConnectedException cannotConnectToStaticConnectors2();
/*    */   
/*    */   @Message(id=119010, value="Connection is destroyed", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQNotConnectedException connectionDestroyed();
/*    */   
/*    */   @Message(id=119011, value="Did not receive data from server for {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQConnectionTimedOutException connectionTimedOut(Connection paramConnection);
/*    */   
/*    */   @Message(id=119012, value="Timed out waiting to receive initial broadcast from cluster", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQConnectionTimedOutException connectionTimedOutInInitialBroadcast();
/*    */   
/*    */   @Message(id=119013, value="Timed out waiting to receive cluster topology. Group:{0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQConnectionTimedOutException connectionTimedOutOnReceiveTopology(DiscoveryGroup paramDiscoveryGroup);
/*    */   
/*    */   @Message(id=119014, value="Timed out waiting for response when sending packet {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQConnectionTimedOutException timedOutSendingPacket(Byte paramByte);
/*    */   
/*    */   @Message(id=119015, value="The connection was disconnected because of server shutdown", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQDisconnectedException disconnected();
/*    */   
/*    */   @Message(id=119016, value="Connection failure detected. Unblocking a blocking call that will never get a response", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQUnBlockedException unblockingACall(@Cause Throwable paramThrowable);
/*    */   
/*    */   @Message(id=119017, value="Consumer is closed", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQObjectClosedException consumerClosed();
/*    */   
/*    */   @Message(id=119018, value="Producer is closed", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQObjectClosedException producerClosed();
/*    */   
/*    */   @Message(id=119019, value="Session is closed", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQObjectClosedException sessionClosed();
/*    */   
/*    */   @Message(id=119020, value="Cannot call receive(...) - a MessageHandler is set", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQIllegalStateException messageHandlerSet();
/*    */   
/*    */   @Message(id=119021, value="Cannot set MessageHandler - consumer is in receive(...)", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQIllegalStateException inReceive();
/*    */   
/*    */   @Message(id=119022, value="Header size ({0}) is too big, use the messageBody for large data, or increase minLargeMessageSize", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQIllegalStateException headerSizeTooBig(Integer paramInteger);
/*    */   
/*    */   @Message(id=119023, value="The large message lost connection with its session, either because of a rollback or a closed session", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQIllegalStateException largeMessageLostSession();
/*    */   
/*    */   @Message(id=119024, value="Couldn't select a TransportConfiguration to create SessionFactory", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQIllegalStateException noTCForSessionFactory();
/*    */   
/*    */   @Message(id=119025, value="Error saving the message body", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQLargeMessageException errorSavingBody(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119026, value="Error reading the LargeMessageBody", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQLargeMessageException errorReadingBody(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119027, value="Error closing stream from LargeMessageBody", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQLargeMessageException errorClosingLargeMessage(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119028, value="Timeout waiting for LargeMessage Body", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQLargeMessageException timeoutOnLargeMessage();
/*    */   
/*    */   @Message(id=119029, value="Error writing body of message", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQLargeMessageException errorWritingLargeMessage(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119030, value="The transaction was rolled back on failover to a backup server", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQTransactionRolledBackException txRolledBack();
/*    */   
/*    */   @Message(id=119031, value="The transaction was rolled back on failover however commit may have been succesful", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQTransactionOutcomeUnknownException txOutcomeUnknown();
/*    */   
/*    */   @Message(id=119032, value="Invalid type: {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException invalidType(Object paramObject);
/*    */   
/*    */   @Message(id=119033, value="Invalid type: {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException invalidEncodeType(Object paramObject);
/*    */   
/*    */   @Message(id=119034, value="Params for management operations must be of the following type: int long double String boolean Map or array thereof but found {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException invalidManagementParam(Object paramObject);
/*    */   
/*    */   @Message(id=119035, value="Invalid window size {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException invalidWindowSize(Integer paramInteger);
/*    */   
/*    */   @Message(id=119036, value="No operation mapped to int {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException noOperationMapped(Integer paramInteger);
/*    */   
/*    */   @Message(id=119037, value="Invalid last Received Command ID: {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException invalidCommandID(Integer paramInteger);
/*    */   
/*    */   @Message(id=119038, value="Cannot find channel with id {0} to close", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException noChannelToClose(Long paramLong);
/*    */   
/*    */   @Message(id=119039, value="Close Listener cannot be null", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException closeListenerCannotBeNull();
/*    */   
/*    */   @Message(id=119040, value="Fail Listener cannot be null", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException failListenerCannotBeNull();
/*    */   
/*    */   @Message(id=119041, value="Connection already exists with id {0}", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException connectionExists(Object paramObject);
/*    */   
/*    */   @Message(id=119042, value="Invalid argument null listener", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException nullListener();
/*    */   
/*    */   @Message(id=119043, value="Invalid argument null handler", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException nullHandler();
/*    */   
/*    */   @Message(id=119044, value="No available codec to decode password!", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException noCodec();
/*    */   
/*    */   @Message(id=119045, value="the first node to be compared is null", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException firstNodeNull();
/*    */   
/*    */   @Message(id=119046, value="the second node to be compared is null", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException secondNodeNull();
/*    */   
/*    */   @Message(id=119047, value="nodes have different node names", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException nodeHaveDifferentNames();
/*    */   
/*    */   @Message(id=119048, value="nodes hava a different number of attributes", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException nodeHaveDifferentAttNumber();
/*    */   
/*    */   @Message(id=119049, value="attribute {0}={1} doesn't match", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException attsDontMatch(String paramString1, String paramString2);
/*    */   
/*    */   @Message(id=119050, value="one node has children and the other doesn't", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException oneNodeHasChildren();
/*    */   
/*    */   @Message(id=119051, value="nodes hava a different number of children", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException nodeHasDifferentChildNumber();
/*    */   
/*    */   @Message(id=119052, value="Element {0} requires a valid Boolean value, but '{1}' cannot be parsed as a Boolean", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException mustBeBoolean(Node paramNode, String paramString);
/*    */   
/*    */   @Message(id=119053, value="Element {0} requires a valid Double value, but '{1}' cannot be parsed as a Double", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException mustBeDouble(Node paramNode, String paramString);
/*    */   
/*    */   @Message(id=119054, value="Element {0} requires a valid Integer value, but '{1}' cannot be parsed as a Integer", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException mustBeInteger(Node paramNode, String paramString);
/*    */   
/*    */   @Message(id=119055, value="Element {0} requires a valid Long value, but '{1}' cannot be parsed as a Long", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException mustBeLong(Node paramNode, String paramString);
/*    */   
/*    */   @Message(id=119056, value="Failed to get decoder", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException failedToGetDecoder(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119057, value="Error decoding password", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract IllegalArgumentException errordecodingPassword(@Cause Exception paramException);
/*    */   
/*    */   @Message(id=119058, value="Address \"{0}\" is full. Message encode size = {1}B", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQAddressFullException addressIsFull(String paramString, int paramInt);
/*    */   
/*    */   @Message(id=119059, value="Interceptor {0} rejected packet in a blocking call. This call will never complete.", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQInterceptorRejectedPacketException interceptorRejectedPacket(String paramString);
/*    */   
/*    */   @Message(id=119060, value="Large Message Transmission interrupted on consumer shutdown.", format=Message.Format.MESSAGE_FORMAT)
/*    */   public abstract HornetQLargeMessageInterruptedException largeMessageInterrupted();
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\HornetQClientMessageBundle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */