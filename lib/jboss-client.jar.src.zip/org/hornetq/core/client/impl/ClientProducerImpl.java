/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.api.core.Message;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.core.message.BodyEncoder;
/*     */ import org.hornetq.core.message.impl.MessageInternal;
/*     */ import org.hornetq.core.protocol.core.Channel;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionSendContinuationMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionSendLargeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionSendMessage;
/*     */ import org.hornetq.utils.DeflaterReader;
/*     */ import org.hornetq.utils.HornetQBufferInputStream;
/*     */ import org.hornetq.utils.TokenBucketLimiter;
/*     */ import org.hornetq.utils.UUIDGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientProducerImpl
/*     */   implements ClientProducerInternal
/*     */ {
/*     */   private final SimpleString address;
/*     */   private final ClientSessionInternal session;
/*     */   private final Channel channel;
/*     */   private volatile boolean closed;
/*     */   private final TokenBucketLimiter rateLimiter;
/*     */   private final boolean blockOnNonDurableSend;
/*     */   private final boolean blockOnDurableSend;
/*     */   private final SimpleString groupID;
/*     */   private final int minLargeMessageSize;
/*     */   private final ClientProducerCredits credits;
/*     */   
/*     */   public ClientProducerImpl(ClientSessionInternal session, SimpleString address, TokenBucketLimiter rateLimiter, boolean blockOnNonDurableSend, boolean blockOnDurableSend, boolean autoGroup, SimpleString groupID, int minLargeMessageSize, Channel channel)
/*     */   {
/*  88 */     this.channel = channel;
/*     */     
/*  90 */     this.session = session;
/*     */     
/*  92 */     this.address = address;
/*     */     
/*  94 */     this.rateLimiter = rateLimiter;
/*     */     
/*  96 */     this.blockOnNonDurableSend = blockOnNonDurableSend;
/*     */     
/*  98 */     this.blockOnDurableSend = blockOnDurableSend;
/*     */     
/* 100 */     if (autoGroup)
/*     */     {
/* 102 */       this.groupID = UUIDGenerator.getInstance().generateSimpleStringUUID();
/*     */     }
/*     */     else
/*     */     {
/* 106 */       this.groupID = groupID;
/*     */     }
/*     */     
/* 109 */     this.minLargeMessageSize = minLargeMessageSize;
/*     */     
/* 111 */     if (address != null)
/*     */     {
/* 113 */       this.credits = session.getCredits(address, false);
/*     */     }
/*     */     else
/*     */     {
/* 117 */       this.credits = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SimpleString getAddress()
/*     */   {
/* 125 */     return this.address;
/*     */   }
/*     */   
/*     */   public void send(Message msg) throws HornetQException
/*     */   {
/* 130 */     checkClosed();
/*     */     
/* 132 */     doSend(null, msg);
/*     */   }
/*     */   
/*     */   public void send(SimpleString address, Message msg) throws HornetQException
/*     */   {
/* 137 */     checkClosed();
/*     */     
/* 139 */     doSend(address, msg);
/*     */   }
/*     */   
/*     */   public void send(String address, Message message) throws HornetQException
/*     */   {
/* 144 */     send(SimpleString.toSimpleString(address), message);
/*     */   }
/*     */   
/*     */   public synchronized void close() throws HornetQException
/*     */   {
/* 149 */     if (this.closed)
/*     */     {
/* 151 */       return;
/*     */     }
/*     */     
/* 154 */     doCleanup();
/*     */   }
/*     */   
/*     */   public void cleanUp()
/*     */   {
/* 159 */     if (this.closed)
/*     */     {
/* 161 */       return;
/*     */     }
/*     */     
/* 164 */     doCleanup();
/*     */   }
/*     */   
/*     */   public boolean isClosed()
/*     */   {
/* 169 */     return this.closed;
/*     */   }
/*     */   
/*     */   public boolean isBlockOnDurableSend()
/*     */   {
/* 174 */     return this.blockOnDurableSend;
/*     */   }
/*     */   
/*     */   public boolean isBlockOnNonDurableSend()
/*     */   {
/* 179 */     return this.blockOnNonDurableSend;
/*     */   }
/*     */   
/*     */   public int getMaxRate()
/*     */   {
/* 184 */     return this.rateLimiter == null ? -1 : this.rateLimiter.getRate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ClientProducerCredits getProducerCredits()
/*     */   {
/* 191 */     return this.credits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void doCleanup()
/*     */   {
/* 202 */     if (this.address != null)
/*     */     {
/* 204 */       this.session.returnCredits(this.address);
/*     */     }
/*     */     
/* 207 */     this.session.removeProducer(this);
/*     */     
/* 209 */     this.closed = true;
/*     */   }
/*     */   
/*     */   private void doSend(SimpleString address, Message msg) throws HornetQException
/*     */   {
/* 214 */     this.session.startCall();
/*     */     
/*     */     try
/*     */     {
/* 218 */       MessageInternal msgI = (MessageInternal)msg;
/*     */       
/*     */ 
/*     */       boolean isLarge;
/*     */       
/*     */ 
/*     */       boolean isLarge;
/*     */       
/*     */ 
/* 227 */       if ((msgI.getBodyInputStream() != null) || (msgI.isLargeMessage()) || ((msgI.getBodyBuffer().writerIndex() > this.minLargeMessageSize) && (!msgI.isServerMessage())))
/*     */       {
/*     */ 
/* 230 */         isLarge = true;
/*     */       }
/*     */       else
/*     */       {
/* 234 */         isLarge = false; }
/*     */       ClientProducerCredits theCredits;
/*     */       ClientProducerCredits theCredits;
/* 237 */       if (address != null)
/*     */       {
/* 239 */         if (!isLarge)
/*     */         {
/* 241 */           this.session.setAddress(msg, address);
/*     */         }
/*     */         else
/*     */         {
/* 245 */           msg.setAddress(address);
/*     */         }
/*     */         
/*     */ 
/* 249 */         theCredits = this.session.getCredits(address, true);
/*     */       }
/*     */       else
/*     */       {
/* 253 */         if (!isLarge)
/*     */         {
/* 255 */           this.session.setAddress(msg, this.address);
/*     */         }
/*     */         else
/*     */         {
/* 259 */           msg.setAddress(this.address);
/*     */         }
/*     */         
/* 262 */         theCredits = this.credits;
/*     */       }
/*     */       
/* 265 */       if (this.rateLimiter != null)
/*     */       {
/*     */ 
/*     */ 
/* 269 */         this.rateLimiter.limit();
/*     */       }
/*     */       
/* 272 */       if (this.groupID != null)
/*     */       {
/* 274 */         msgI.putStringProperty(Message.HDR_GROUP_ID, this.groupID);
/*     */       }
/*     */       
/* 277 */       boolean sendBlocking = msgI.isDurable() ? this.blockOnDurableSend : this.blockOnNonDurableSend;
/*     */       
/* 279 */       this.session.workDone();
/*     */       
/* 281 */       if (isLarge)
/*     */       {
/* 283 */         largeMessageSend(sendBlocking, msgI, theCredits);
/*     */       }
/*     */       else
/*     */       {
/* 287 */         sendRegularMessage(msgI, sendBlocking, theCredits);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 292 */       this.session.endCall();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void sendRegularMessage(MessageInternal msgI, boolean sendBlocking, ClientProducerCredits theCredits)
/*     */     throws HornetQException
/*     */   {
/*     */     try
/*     */     {
/* 306 */       theCredits.acquireCredits(msgI.getEncodeSize());
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 310 */       throw new HornetQInterruptedException(e);
/*     */     }
/*     */     
/* 313 */     SessionSendMessage packet = new SessionSendMessage(msgI, sendBlocking);
/*     */     
/* 315 */     if (sendBlocking)
/*     */     {
/* 317 */       this.channel.sendBlocking(packet, (byte)21);
/*     */     }
/*     */     else
/*     */     {
/* 321 */       this.channel.sendBatched(packet);
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkClosed() throws HornetQException
/*     */   {
/* 327 */     if (this.closed)
/*     */     {
/* 329 */       throw HornetQClientMessageBundle.BUNDLE.producerClosed();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void largeMessageSend(boolean sendBlocking, MessageInternal msgI, ClientProducerCredits credits)
/*     */     throws HornetQException
/*     */   {
/* 343 */     int headerSize = msgI.getHeadersAndPropertiesEncodeSize();
/*     */     
/* 345 */     if (msgI.getHeadersAndPropertiesEncodeSize() >= this.minLargeMessageSize)
/*     */     {
/* 347 */       throw HornetQClientMessageBundle.BUNDLE.headerSizeTooBig(Integer.valueOf(headerSize));
/*     */     }
/*     */     
/*     */ 
/* 351 */     if ((msgI.getBodyInputStream() == null) && (msgI.getWholeBuffer() != null))
/*     */     {
/* 353 */       msgI.getWholeBuffer().readerIndex(0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 358 */     if (msgI.isServerMessage())
/*     */     {
/* 360 */       largeMessageSendServer(sendBlocking, msgI, credits);
/*     */     } else { InputStream input;
/* 362 */       if ((input = msgI.getBodyInputStream()) != null)
/*     */       {
/* 364 */         largeMessageSendStreamed(sendBlocking, msgI, input, credits);
/*     */       }
/*     */       else
/*     */       {
/* 368 */         largeMessageSendBuffered(sendBlocking, msgI, credits);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void sendInitialLargeMessageHeader(MessageInternal msgI, ClientProducerCredits credits) throws HornetQException {
/* 374 */     SessionSendLargeMessage initialChunk = new SessionSendLargeMessage(msgI);
/*     */     
/* 376 */     this.channel.send(initialChunk);
/*     */     
/*     */     try
/*     */     {
/* 380 */       credits.acquireCredits(msgI.getHeadersAndPropertiesEncodeSize());
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 384 */       throw new HornetQInterruptedException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void largeMessageSendServer(boolean sendBlocking, MessageInternal msgI, ClientProducerCredits credits)
/*     */     throws HornetQException
/*     */   {
/* 400 */     sendInitialLargeMessageHeader(msgI, credits);
/*     */     
/* 402 */     BodyEncoder context = msgI.getBodyEncoder();
/*     */     
/* 404 */     long bodySize = context.getLargeBodySize();
/*     */     
/* 406 */     context.open();
/*     */     
/*     */     try
/*     */     {
/* 410 */       for (pos = 0; pos < bodySize;)
/*     */       {
/*     */ 
/*     */ 
/* 414 */         int chunkLength = Math.min((int)(bodySize - pos), this.minLargeMessageSize);
/*     */         
/* 416 */         HornetQBuffer bodyBuffer = HornetQBuffers.fixedBuffer(chunkLength);
/*     */         
/* 418 */         context.encode(bodyBuffer, chunkLength);
/*     */         
/* 420 */         pos += chunkLength;
/*     */         
/* 422 */         boolean lastChunk = pos >= bodySize;
/*     */         
/* 424 */         SessionSendContinuationMessage chunk = new SessionSendContinuationMessage(msgI, bodyBuffer.toByteBuffer().array(), !lastChunk, (lastChunk) && (sendBlocking));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 430 */         if ((sendBlocking) && (lastChunk))
/*     */         {
/*     */ 
/* 433 */           this.channel.sendBlocking(chunk, (byte)21);
/*     */         }
/*     */         else
/*     */         {
/* 437 */           this.channel.send(chunk);
/*     */         }
/*     */         
/*     */         try
/*     */         {
/* 442 */           credits.acquireCredits(chunk.getPacketSize());
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/* 446 */           throw new HornetQInterruptedException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/*     */       int pos;
/* 452 */       context.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void largeMessageSendBuffered(boolean sendBlocking, MessageInternal msgI, ClientProducerCredits credits)
/*     */     throws HornetQException
/*     */   {
/* 465 */     msgI.getBodyBuffer().readerIndex(0);
/* 466 */     largeMessageSendStreamed(sendBlocking, msgI, new HornetQBufferInputStream(msgI.getBodyBuffer()), credits);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void largeMessageSendStreamed(boolean sendBlocking, MessageInternal msgI, InputStream inputStreamParameter, ClientProducerCredits credits)
/*     */     throws HornetQException
/*     */   {
/* 481 */     boolean lastPacket = false;
/*     */     
/* 483 */     InputStream input = inputStreamParameter;
/*     */     
/*     */ 
/*     */ 
/* 487 */     AtomicLong messageSize = new AtomicLong();
/*     */     
/* 489 */     DeflaterReader deflaterReader = null;
/*     */     
/* 491 */     if (this.session.isCompressLargeMessages())
/*     */     {
/* 493 */       msgI.putBooleanProperty(Message.HDR_LARGE_COMPRESSED, true);
/* 494 */       deflaterReader = new DeflaterReader(inputStreamParameter, messageSize);
/* 495 */       input = deflaterReader;
/*     */     }
/*     */     
/* 498 */     long totalSize = 0L;
/*     */     
/* 500 */     boolean headerSent = false;
/*     */     
/* 502 */     while (!lastPacket)
/*     */     {
/* 504 */       byte[] buff = new byte[this.minLargeMessageSize];
/*     */       
/* 506 */       int pos = 0;
/*     */       
/*     */ 
/*     */ 
/*     */       do
/*     */       {
/* 512 */         int wanted = this.minLargeMessageSize - pos;
/*     */         int numberOfBytesRead;
/*     */         try
/*     */         {
/* 516 */           numberOfBytesRead = input.read(buff, pos, wanted);
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 520 */           throw HornetQClientMessageBundle.BUNDLE.errorReadingBody(e);
/*     */         }
/*     */         
/* 523 */         if (numberOfBytesRead == -1)
/*     */         {
/* 525 */           lastPacket = true;
/*     */           
/* 527 */           break;
/*     */         }
/*     */         
/* 530 */         pos += numberOfBytesRead;
/*     */       }
/* 532 */       while (pos < this.minLargeMessageSize);
/*     */       
/* 534 */       totalSize += pos;
/*     */       
/*     */       SessionSendContinuationMessage chunk;
/*     */       SessionSendContinuationMessage chunk;
/* 538 */       if (lastPacket)
/*     */       {
/* 540 */         if (!this.session.isCompressLargeMessages())
/*     */         {
/* 542 */           messageSize.set(totalSize);
/*     */         }
/*     */         
/*     */ 
/* 546 */         byte[] buff2 = new byte[pos];
/*     */         
/* 548 */         System.arraycopy(buff, 0, buff2, 0, pos);
/*     */         
/* 550 */         buff = buff2;
/*     */         
/*     */ 
/* 553 */         if ((!headerSent) && (this.session.isCompressLargeMessages()) && (buff2.length < this.minLargeMessageSize))
/*     */         {
/* 555 */           msgI.getBodyBuffer().resetReaderIndex();
/* 556 */           msgI.getBodyBuffer().resetWriterIndex();
/* 557 */           msgI.putLongProperty(Message.HDR_LARGE_BODY_SIZE, deflaterReader.getTotalSize());
/*     */           
/* 559 */           msgI.getBodyBuffer().writeBytes(buff, 0, pos);
/* 560 */           sendRegularMessage(msgI, sendBlocking, credits);
/* 561 */           return;
/*     */         }
/*     */         
/* 564 */         chunk = new SessionSendContinuationMessage(msgI, buff, false, sendBlocking, messageSize.get());
/*     */       }
/*     */       else
/*     */       {
/* 568 */         chunk = new SessionSendContinuationMessage(msgI, buff, true, false);
/*     */       }
/*     */       
/* 571 */       if (!headerSent)
/*     */       {
/* 573 */         sendInitialLargeMessageHeader(msgI, credits);
/* 574 */         headerSent = true;
/*     */       }
/*     */       
/*     */ 
/* 578 */       if ((sendBlocking) && (lastPacket))
/*     */       {
/*     */ 
/* 581 */         this.channel.sendBlocking(chunk, (byte)21);
/*     */       }
/*     */       else
/*     */       {
/* 585 */         this.channel.send(chunk);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 590 */         credits.acquireCredits(chunk.getPacketSize());
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/* 594 */         throw new HornetQInterruptedException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 600 */       input.close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 604 */       throw HornetQClientMessageBundle.BUNDLE.errorClosingLargeMessage(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientProducerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */