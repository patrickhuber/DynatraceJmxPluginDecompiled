/*      */ package org.hornetq.core.client.impl;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.Iterator;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.hornetq.api.core.HornetQBuffer;
/*      */ import org.hornetq.api.core.HornetQException;
/*      */ import org.hornetq.api.core.HornetQInterruptedException;
/*      */ import org.hornetq.api.core.Message;
/*      */ import org.hornetq.api.core.SimpleString;
/*      */ import org.hornetq.api.core.client.ClientMessage;
/*      */ import org.hornetq.api.core.client.ClientSessionFactory;
/*      */ import org.hornetq.api.core.client.MessageHandler;
/*      */ import org.hornetq.api.core.client.ServerLocator;
/*      */ import org.hornetq.core.client.HornetQClientLogger;
/*      */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*      */ import org.hornetq.core.protocol.core.Channel;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionConsumerCloseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionConsumerFlowCreditMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionQueueQueryResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveLargeMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveMessage;
/*      */ import org.hornetq.utils.FutureLatch;
/*      */ import org.hornetq.utils.PriorityLinkedList;
/*      */ import org.hornetq.utils.PriorityLinkedListImpl;
/*      */ import org.hornetq.utils.ReusableLatch;
/*      */ import org.hornetq.utils.TokenBucketLimiter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ClientConsumerImpl
/*      */   implements ClientConsumerInternal
/*      */ {
/*   62 */   private static final boolean isTrace = HornetQClientLogger.LOGGER.isTraceEnabled();
/*      */   
/*      */   private static final long CLOSE_TIMEOUT_MILLISECONDS = 10000L;
/*      */   
/*      */   private static final int NUM_PRIORITIES = 10;
/*      */   
/*   68 */   public static final SimpleString FORCED_DELIVERY_MESSAGE = new SimpleString("_hornetq.forced.delivery.seq");
/*      */   
/*      */ 
/*      */   private final ClientSessionInternal session;
/*      */   
/*      */ 
/*      */   private final Channel channel;
/*      */   
/*      */ 
/*      */   private final long id;
/*      */   
/*      */ 
/*      */   private final SimpleString filterString;
/*      */   
/*      */ 
/*      */   private final SimpleString queueName;
/*      */   
/*      */ 
/*      */   private final boolean browseOnly;
/*      */   
/*      */ 
/*      */   private final Executor sessionExecutor;
/*      */   
/*      */ 
/*      */   private final Executor flowControlExecutor;
/*      */   
/*      */ 
/*   95 */   private final ReusableLatch pendingFlowControl = new ReusableLatch(0);
/*      */   
/*      */   private final int clientWindowSize;
/*      */   
/*      */   private final int ackBatchSize;
/*      */   
/*  101 */   private final PriorityLinkedList<ClientMessageInternal> buffer = new PriorityLinkedListImpl(10);
/*      */   
/*  103 */   private final Runner runner = new Runner(null);
/*      */   
/*      */ 
/*      */   private LargeMessageControllerImpl currentLargeMessageController;
/*      */   
/*      */ 
/*      */   private ClientMessageInternal largeMessageReceived;
/*      */   
/*      */   private final TokenBucketLimiter rateLimiter;
/*      */   
/*      */   private volatile Thread receiverThread;
/*      */   
/*      */   private volatile Thread onMessageThread;
/*      */   
/*      */   private volatile MessageHandler handler;
/*      */   
/*      */   private volatile boolean closing;
/*      */   
/*      */   private volatile boolean closed;
/*      */   
/*      */   private volatile int creditsToSend;
/*      */   
/*      */   private volatile boolean failedOver;
/*      */   
/*      */   private volatile Exception lastException;
/*      */   
/*      */   private volatile int ackBytes;
/*      */   
/*      */   private volatile ClientMessageInternal lastAckedMessage;
/*      */   
/*  133 */   private boolean stopped = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private long forceDeliveryCount;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final SessionQueueQueryResponseMessage queueInfo;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private volatile boolean ackIndividually;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private final ClassLoader contextClassLoader;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientConsumerImpl(ClientSessionInternal session, long id, SimpleString queueName, SimpleString filterString, boolean browseOnly, int clientWindowSize, int ackBatchSize, TokenBucketLimiter rateLimiter, Executor executor, Executor flowControlExecutor, Channel channel, SessionQueueQueryResponseMessage queueInfo, ClassLoader contextClassLoader)
/*      */   {
/*  160 */     this.id = id;
/*      */     
/*  162 */     this.queueName = queueName;
/*      */     
/*  164 */     this.filterString = filterString;
/*      */     
/*  166 */     this.browseOnly = browseOnly;
/*      */     
/*  168 */     this.channel = channel;
/*      */     
/*  170 */     this.session = session;
/*      */     
/*  172 */     this.rateLimiter = rateLimiter;
/*      */     
/*  174 */     this.sessionExecutor = executor;
/*      */     
/*  176 */     this.clientWindowSize = clientWindowSize;
/*      */     
/*  178 */     this.ackBatchSize = ackBatchSize;
/*      */     
/*  180 */     this.queueInfo = queueInfo;
/*      */     
/*  182 */     this.contextClassLoader = contextClassLoader;
/*      */     
/*  184 */     this.flowControlExecutor = flowControlExecutor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private ClientMessage receive(long timeout, boolean forcingDelivery)
/*      */     throws HornetQException
/*      */   {
/*  192 */     checkClosed();
/*      */     
/*  194 */     if (this.largeMessageReceived != null)
/*      */     {
/*      */ 
/*  197 */       this.largeMessageReceived.discardBody();
/*  198 */       this.largeMessageReceived = null;
/*      */     }
/*      */     
/*  201 */     if (this.rateLimiter != null)
/*      */     {
/*  203 */       this.rateLimiter.limit();
/*      */     }
/*      */     
/*  206 */     if (this.handler != null)
/*      */     {
/*  208 */       throw HornetQClientMessageBundle.BUNDLE.messageHandlerSet();
/*      */     }
/*      */     
/*  211 */     if (this.clientWindowSize == 0)
/*      */     {
/*  213 */       startSlowConsumer();
/*      */     }
/*      */     
/*  216 */     this.receiverThread = Thread.currentThread();
/*      */     
/*      */ 
/*  219 */     boolean deliveryForced = false;
/*      */     
/*  221 */     boolean callForceDelivery = false;
/*      */     
/*  223 */     long start = -1L;
/*      */     
/*  225 */     long toWait = timeout == 0L ? Long.MAX_VALUE : timeout;
/*      */     try {
/*      */       ClientMessageInternal m;
/*      */       long now;
/*      */       boolean expired;
/*      */       do {
/*  231 */         for (;;) { m = null;
/*      */           
/*  233 */           synchronized (this)
/*      */           {
/*  235 */             while (((this.stopped) || ((m = (ClientMessageInternal)this.buffer.poll()) == null)) && (!this.closed) && (toWait > 0L))
/*      */             {
/*  237 */               if (start == -1L)
/*      */               {
/*  239 */                 start = System.currentTimeMillis();
/*      */               }
/*      */               
/*  242 */               if ((m == null) && (forcingDelivery))
/*      */               {
/*  244 */                 if (this.stopped) {
/*      */                   break;
/*      */                 }
/*      */                 
/*      */ 
/*      */ 
/*  250 */                 if (!deliveryForced)
/*      */                 {
/*  252 */                   callForceDelivery = true;
/*  253 */                   break;
/*      */                 }
/*      */               }
/*      */               
/*      */               try
/*      */               {
/*  259 */                 wait(toWait);
/*      */               }
/*      */               catch (InterruptedException e)
/*      */               {
/*  263 */                 throw new HornetQInterruptedException(e);
/*      */               }
/*      */               
/*  266 */               if ((m != null) || (this.closed)) {
/*      */                 break;
/*      */               }
/*      */               
/*      */ 
/*  271 */               now = System.currentTimeMillis();
/*      */               
/*  273 */               toWait -= now - start;
/*      */               
/*  275 */               start = now;
/*      */             }
/*      */           }
/*      */           
/*  279 */           if (this.failedOver)
/*      */           {
/*  281 */             if (m == null)
/*      */             {
/*      */ 
/*  284 */               this.failedOver = false;
/*  285 */               deliveryForced = false;
/*  286 */               toWait = timeout == 0L ? Long.MAX_VALUE : timeout;
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  291 */               this.failedOver = false;
/*      */             }
/*      */             
/*      */           }
/*  295 */           else if (callForceDelivery)
/*      */           {
/*  297 */             if (isTrace)
/*      */             {
/*  299 */               HornetQClientLogger.LOGGER.trace("Forcing delivery");
/*      */             }
/*      */             
/*  302 */             this.session.forceDelivery(this.id, this.forceDeliveryCount++);
/*  303 */             callForceDelivery = false;
/*  304 */             deliveryForced = true;
/*      */           }
/*      */           else
/*      */           {
/*  308 */             if (m == null)
/*      */               break label615;
/*  310 */             this.session.workDone();
/*      */             
/*  312 */             if (!m.containsProperty(FORCED_DELIVERY_MESSAGE))
/*      */               break;
/*  314 */             long seq = m.getLongProperty(FORCED_DELIVERY_MESSAGE).longValue();
/*      */             
/*      */ 
/*      */ 
/*  318 */             if ((forcingDelivery) && (deliveryForced) && (seq == this.forceDeliveryCount - 1L))
/*      */             {
/*      */ 
/*  321 */               resetIfSlowConsumer();
/*      */               
/*  323 */               if (isTrace)
/*      */               {
/*  325 */                 HornetQClientLogger.LOGGER.trace("There was nothing on the queue, leaving it now:: returning null");
/*      */               }
/*      */               
/*  328 */               return null;
/*      */             }
/*      */             
/*      */ 
/*  332 */             if (isTrace)
/*      */             {
/*  334 */               HornetQClientLogger.LOGGER.trace("Ignored force delivery answer as it belonged to another call");
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  341 */         expired = m.isExpired();
/*      */         
/*  343 */         flowControlBeforeConsumption(m);
/*      */         
/*  345 */         if (!expired)
/*      */           break;
/*  347 */         m.discardBody();
/*      */         
/*  349 */         this.session.expire(this.id, m.getMessageID());
/*      */         
/*  351 */         if (this.clientWindowSize == 0)
/*      */         {
/*  353 */           startSlowConsumer();
/*      */         }
/*      */         
/*  356 */       } while (toWait > 0L);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  362 */       return null;
/*      */       
/*      */ 
/*      */ 
/*  366 */       if (m.isLargeMessage())
/*      */       {
/*  368 */         this.largeMessageReceived = m;
/*      */       }
/*      */       
/*  371 */       if (isTrace)
/*      */       {
/*  373 */         HornetQClientLogger.LOGGER.trace("Returning " + m);
/*      */       }
/*      */       
/*  376 */       return m;
/*      */       
/*      */       label615:
/*      */       
/*  380 */       if (isTrace)
/*      */       {
/*  382 */         HornetQClientLogger.LOGGER.trace("Returning null");
/*      */       }
/*  384 */       resetIfSlowConsumer();
/*  385 */       return null;
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*  391 */       this.receiverThread = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public ClientMessage receive(long timeout) throws HornetQException
/*      */   {
/*  397 */     ClientMessage msg = receive(timeout, false);
/*      */     
/*  399 */     if ((msg == null) && (!this.closed))
/*      */     {
/*  401 */       msg = receive(0L, true);
/*      */     }
/*      */     
/*  404 */     return msg;
/*      */   }
/*      */   
/*      */   public ClientMessage receive() throws HornetQException
/*      */   {
/*  409 */     return receive(0L, false);
/*      */   }
/*      */   
/*      */   public ClientMessage receiveImmediate() throws HornetQException
/*      */   {
/*  414 */     return receive(0L, true);
/*      */   }
/*      */   
/*      */   public MessageHandler getMessageHandler() throws HornetQException
/*      */   {
/*  419 */     checkClosed();
/*      */     
/*  421 */     return this.handler;
/*      */   }
/*      */   
/*      */ 
/*      */   public synchronized void setMessageHandler(MessageHandler theHandler)
/*      */     throws HornetQException
/*      */   {
/*  428 */     checkClosed();
/*      */     
/*  430 */     if (this.receiverThread != null)
/*      */     {
/*  432 */       throw HornetQClientMessageBundle.BUNDLE.inReceive();
/*      */     }
/*      */     
/*  435 */     boolean noPreviousHandler = this.handler == null;
/*      */     
/*  437 */     if ((this.handler != theHandler) && (this.clientWindowSize == 0))
/*      */     {
/*  439 */       startSlowConsumer();
/*      */     }
/*      */     
/*  442 */     this.handler = theHandler;
/*      */     
/*      */ 
/*  445 */     if ((this.handler != null) && (noPreviousHandler))
/*      */     {
/*  447 */       requeueExecutors();
/*      */ 
/*      */     }
/*  450 */     else if ((this.handler == null) && (!noPreviousHandler))
/*      */     {
/*  452 */       waitForOnMessageToComplete(true);
/*      */     }
/*      */   }
/*      */   
/*      */   public void close() throws HornetQException
/*      */   {
/*  458 */     doCleanUp(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Thread prepareForClose(final FutureLatch future)
/*      */     throws HornetQException
/*      */   {
/*  469 */     this.closing = true;
/*      */     
/*  471 */     resetLargeMessageController();
/*      */     
/*      */ 
/*  474 */     this.sessionExecutor.execute(new Runnable()
/*      */     {
/*      */ 
/*      */       public void run()
/*      */       {
/*  479 */         future.run();
/*      */       }
/*      */       
/*  482 */     });
/*  483 */     return this.onMessageThread;
/*      */   }
/*      */   
/*      */   public void cleanUp()
/*      */   {
/*      */     try
/*      */     {
/*  490 */       doCleanUp(false);
/*      */     }
/*      */     catch (HornetQException e)
/*      */     {
/*  494 */       HornetQClientLogger.LOGGER.warn("problem cleaning up: " + this);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClosed()
/*      */   {
/*  500 */     return this.closed;
/*      */   }
/*      */   
/*      */   public void stop(boolean waitForOnMessage) throws HornetQException
/*      */   {
/*  505 */     waitForOnMessageToComplete(waitForOnMessage);
/*      */     
/*  507 */     if (this.browseOnly)
/*      */     {
/*      */ 
/*  510 */       return;
/*      */     }
/*      */     
/*  513 */     synchronized (this)
/*      */     {
/*  515 */       if (this.stopped)
/*      */       {
/*  517 */         return;
/*      */       }
/*      */       
/*  520 */       this.stopped = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearAtFailover()
/*      */   {
/*  526 */     clearBuffer();
/*      */     
/*      */ 
/*  529 */     this.stopped = true;
/*      */     
/*  531 */     resetLargeMessageController();
/*      */     
/*  533 */     this.lastAckedMessage = null;
/*      */     
/*  535 */     this.creditsToSend = 0;
/*      */     
/*  537 */     this.failedOver = true;
/*      */     
/*  539 */     this.ackIndividually = false;
/*      */   }
/*      */   
/*      */   public synchronized void start()
/*      */   {
/*  544 */     this.stopped = false;
/*      */     
/*  546 */     requeueExecutors();
/*      */   }
/*      */   
/*      */   public Exception getLastException()
/*      */   {
/*  551 */     return this.lastException;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public SessionQueueQueryResponseMessage getQueueInfo()
/*      */   {
/*  559 */     return this.queueInfo;
/*      */   }
/*      */   
/*      */   public long getID()
/*      */   {
/*  564 */     return this.id;
/*      */   }
/*      */   
/*      */   public SimpleString getFilterString()
/*      */   {
/*  569 */     return this.filterString;
/*      */   }
/*      */   
/*      */   public SimpleString getQueueName()
/*      */   {
/*  574 */     return this.queueName;
/*      */   }
/*      */   
/*      */   public boolean isBrowseOnly()
/*      */   {
/*  579 */     return this.browseOnly;
/*      */   }
/*      */   
/*      */   public synchronized void handleMessage(SessionReceiveMessage message) throws Exception
/*      */   {
/*  584 */     if (this.closing)
/*      */     {
/*      */ 
/*  587 */       return;
/*      */     }
/*      */     
/*  590 */     if (message.getMessage().getBooleanProperty(Message.HDR_LARGE_COMPRESSED).booleanValue())
/*      */     {
/*  592 */       handleCompressedMessage(message);
/*      */     }
/*      */     else
/*      */     {
/*  596 */       handleRegularMessage((ClientMessageInternal)message.getMessage(), message);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleRegularMessage(ClientMessageInternal message, SessionReceiveMessage messagePacket) throws Exception
/*      */   {
/*  602 */     message.setDeliveryCount(messagePacket.getDeliveryCount());
/*      */     
/*  604 */     message.setFlowControlSize(messagePacket.getPacketSize());
/*      */     
/*  606 */     handleRegularMessage(message);
/*      */   }
/*      */   
/*      */   private void handleRegularMessage(ClientMessageInternal message)
/*      */   {
/*  611 */     if (message.getAddress() == null)
/*      */     {
/*  613 */       message.setAddressTransient(this.queueInfo.getAddress());
/*      */     }
/*      */     
/*  616 */     message.onReceipt(this);
/*      */     
/*  618 */     if ((!this.ackIndividually) && (message.getPriority() != 4) && (!message.containsProperty(FORCED_DELIVERY_MESSAGE)))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  623 */       this.ackIndividually = true;
/*      */     }
/*      */     
/*      */ 
/*  627 */     this.buffer.addTail(message, message.getPriority());
/*      */     
/*  629 */     if (this.handler != null)
/*      */     {
/*      */ 
/*  632 */       if (!this.stopped)
/*      */       {
/*  634 */         queueExecutor();
/*      */       }
/*      */       
/*      */     }
/*      */     else {
/*  639 */       notify();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void handleCompressedMessage(SessionReceiveMessage message)
/*      */     throws Exception
/*      */   {
/*  657 */     ClientMessageImpl clMessage = (ClientMessageImpl)message.getMessage();
/*      */     
/*  659 */     ClientLargeMessageImpl largeMessage = new ClientLargeMessageImpl();
/*  660 */     largeMessage.retrieveExistingData(clMessage);
/*      */     
/*  662 */     File largeMessageCache = null;
/*      */     
/*  664 */     if (this.session.isCacheLargeMessageClient())
/*      */     {
/*  666 */       largeMessageCache = File.createTempFile("tmp-large-message-" + largeMessage.getMessageID() + "-", ".tmp");
/*      */       
/*  668 */       largeMessageCache.deleteOnExit();
/*      */     }
/*      */     
/*  671 */     ClientSessionFactory sf = this.session.getSessionFactory();
/*  672 */     ServerLocator locator = sf.getServerLocator();
/*  673 */     long callTimeout = locator.getCallTimeout();
/*      */     
/*  675 */     this.currentLargeMessageController = new LargeMessageControllerImpl(this, largeMessage.getLargeMessageSize(), callTimeout, largeMessageCache);
/*  676 */     this.currentLargeMessageController.setLocal(true);
/*      */     
/*      */ 
/*  679 */     HornetQBuffer qbuff = clMessage.getBodyBuffer();
/*  680 */     int bytesToRead = qbuff.writerIndex() - qbuff.readerIndex();
/*  681 */     byte[] body = qbuff.readBytes(bytesToRead).toByteBuffer().array();
/*      */     
/*  683 */     largeMessage.setLargeMessageController(new CompressedLargeMessageControllerImpl(this.currentLargeMessageController));
/*  684 */     SessionReceiveContinuationMessage packet = new SessionReceiveContinuationMessage(getID(), body, false, false, body.length);
/*  685 */     this.currentLargeMessageController.addPacket(packet);
/*      */     
/*  687 */     handleRegularMessage(largeMessage, message);
/*      */   }
/*      */   
/*      */   public synchronized void handleLargeMessage(SessionReceiveLargeMessage packet) throws Exception
/*      */   {
/*  692 */     if (this.closing)
/*      */     {
/*      */ 
/*  695 */       return;
/*      */     }
/*      */     
/*      */ 
/*  699 */     ClientLargeMessageInternal currentChunkMessage = (ClientLargeMessageInternal)packet.getLargeMessage();
/*      */     
/*  701 */     currentChunkMessage.setFlowControlSize(packet.getPacketSize());
/*      */     
/*  703 */     currentChunkMessage.setDeliveryCount(packet.getDeliveryCount());
/*      */     
/*  705 */     File largeMessageCache = null;
/*      */     
/*  707 */     if (this.session.isCacheLargeMessageClient())
/*      */     {
/*  709 */       largeMessageCache = File.createTempFile("tmp-large-message-" + currentChunkMessage.getMessageID() + "-", ".tmp");
/*      */       
/*  711 */       largeMessageCache.deleteOnExit();
/*      */     }
/*      */     
/*  714 */     ClientSessionFactory sf = this.session.getSessionFactory();
/*  715 */     ServerLocator locator = sf.getServerLocator();
/*  716 */     long callTimeout = locator.getCallTimeout();
/*      */     
/*  718 */     this.currentLargeMessageController = new LargeMessageControllerImpl(this, packet.getLargeMessageSize(), callTimeout, largeMessageCache);
/*      */     
/*  720 */     if (currentChunkMessage.isCompressed())
/*      */     {
/*  722 */       currentChunkMessage.setLargeMessageController(new CompressedLargeMessageControllerImpl(this.currentLargeMessageController));
/*      */     }
/*      */     else
/*      */     {
/*  726 */       currentChunkMessage.setLargeMessageController(this.currentLargeMessageController);
/*      */     }
/*      */     
/*  729 */     handleRegularMessage(currentChunkMessage);
/*      */   }
/*      */   
/*      */   public synchronized void handleLargeMessageContinuation(SessionReceiveContinuationMessage chunk) throws Exception
/*      */   {
/*  734 */     if (this.closing)
/*      */     {
/*  736 */       return;
/*      */     }
/*  738 */     if (this.currentLargeMessageController == null)
/*      */     {
/*  740 */       if (isTrace)
/*      */       {
/*  742 */         HornetQClientLogger.LOGGER.trace("Sending back credits for largeController = null " + chunk.getPacketSize());
/*      */       }
/*  744 */       flowControl(chunk.getPacketSize(), false);
/*      */     }
/*      */     else
/*      */     {
/*  748 */       this.currentLargeMessageController.addPacket(chunk);
/*      */     }
/*      */   }
/*      */   
/*      */   public void clear(boolean waitForOnMessage) throws HornetQException
/*      */   {
/*  754 */     synchronized (this)
/*      */     {
/*      */ 
/*      */ 
/*  758 */       Iterator<ClientMessageInternal> iter = this.buffer.iterator();
/*      */       
/*  760 */       while (iter.hasNext())
/*      */       {
/*      */         try
/*      */         {
/*  764 */           ClientMessageInternal message = (ClientMessageInternal)iter.next();
/*      */           
/*  766 */           if (message.isLargeMessage())
/*      */           {
/*  768 */             ClientLargeMessageInternal largeMessage = (ClientLargeMessageInternal)message;
/*  769 */             largeMessage.getLargeMessageController().cancel();
/*      */           }
/*      */           
/*  772 */           flowControlBeforeConsumption(message);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  776 */           HornetQClientLogger.LOGGER.errorClearingMessages(e);
/*      */         }
/*      */       }
/*      */       
/*  780 */       clearBuffer();
/*      */       
/*      */       try
/*      */       {
/*  784 */         resetLargeMessageController();
/*      */ 
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/*  789 */         HornetQClientLogger.LOGGER.errorClearingMessages(e);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  795 */     waitForOnMessageToComplete(waitForOnMessage);
/*      */   }
/*      */   
/*      */ 
/*      */   private void resetLargeMessageController()
/*      */   {
/*  801 */     LargeMessageController controller = this.currentLargeMessageController;
/*  802 */     if (controller != null)
/*      */     {
/*  804 */       controller.cancel();
/*  805 */       this.currentLargeMessageController = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public int getClientWindowSize()
/*      */   {
/*  811 */     return this.clientWindowSize;
/*      */   }
/*      */   
/*      */   public int getBufferSize()
/*      */   {
/*  816 */     return this.buffer.size();
/*      */   }
/*      */   
/*      */   public void acknowledge(ClientMessage message) throws HornetQException
/*      */   {
/*  821 */     ClientMessageInternal cmi = (ClientMessageInternal)message;
/*      */     
/*  823 */     if (this.ackIndividually)
/*      */     {
/*  825 */       individualAcknowledge(message);
/*      */     }
/*      */     else
/*      */     {
/*  829 */       this.ackBytes += message.getEncodeSize();
/*      */       
/*  831 */       if (this.ackBytes >= this.ackBatchSize)
/*      */       {
/*  833 */         doAck(cmi);
/*      */       }
/*      */       else
/*      */       {
/*  837 */         this.lastAckedMessage = cmi;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void individualAcknowledge(ClientMessage message) throws HornetQException
/*      */   {
/*  844 */     if (this.lastAckedMessage != null)
/*      */     {
/*  846 */       flushAcks();
/*      */     }
/*      */     
/*  849 */     this.session.individualAcknowledge(this.id, message.getMessageID());
/*      */   }
/*      */   
/*      */   public void flushAcks() throws HornetQException
/*      */   {
/*  854 */     if (this.lastAckedMessage != null)
/*      */     {
/*  856 */       doAck(this.lastAckedMessage);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void flowControl(int messageBytes, boolean discountSlowConsumer)
/*      */     throws HornetQException
/*      */   {
/*  869 */     if (this.clientWindowSize >= 0)
/*      */     {
/*  871 */       this.creditsToSend += messageBytes;
/*      */       
/*  873 */       if (this.creditsToSend >= this.clientWindowSize)
/*      */       {
/*  875 */         if ((this.clientWindowSize == 0) && (discountSlowConsumer))
/*      */         {
/*  877 */           if (isTrace)
/*      */           {
/*  879 */             HornetQClientLogger.LOGGER.trace("FlowControl::Sending " + this.creditsToSend + " -1, for slow consumer");
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*  884 */           int credits = this.creditsToSend - 1;
/*      */           
/*  886 */           this.creditsToSend = 0;
/*      */           
/*  888 */           if (credits > 0)
/*      */           {
/*  890 */             sendCredits(credits);
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*  895 */           if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */           {
/*  897 */             HornetQClientLogger.LOGGER.debug("Sending " + messageBytes + " from flow-control");
/*      */           }
/*      */           
/*  900 */           int credits = this.creditsToSend;
/*      */           
/*  902 */           this.creditsToSend = 0;
/*      */           
/*  904 */           if (credits > 0)
/*      */           {
/*  906 */             sendCredits(credits);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void startSlowConsumer()
/*      */   {
/*  930 */     if (isTrace)
/*      */     {
/*  932 */       HornetQClientLogger.LOGGER.trace("Sending 1 credit to start delivering of one message to slow consumer");
/*      */     }
/*  934 */     sendCredits(1);
/*      */     
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/*  940 */       this.pendingFlowControl.await(10L, TimeUnit.SECONDS);
/*      */ 
/*      */     }
/*      */     catch (InterruptedException e)
/*      */     {
/*  945 */       Thread.currentThread().interrupt();
/*      */     }
/*      */   }
/*      */   
/*      */   private void resetIfSlowConsumer()
/*      */   {
/*  951 */     if (this.clientWindowSize == 0)
/*      */     {
/*  953 */       sendCredits(0);
/*      */       
/*      */ 
/*  956 */       final CountDownLatch latch = new CountDownLatch(1);
/*  957 */       this.flowControlExecutor.execute(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  961 */           latch.countDown();
/*      */         }
/*      */       });
/*      */       
/*      */       try
/*      */       {
/*  967 */         latch.await(10L, TimeUnit.SECONDS);
/*      */       }
/*      */       catch (InterruptedException e)
/*      */       {
/*  971 */         throw new HornetQInterruptedException(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void requeueExecutors()
/*      */   {
/*  978 */     for (int i = 0; i < this.buffer.size(); i++)
/*      */     {
/*  980 */       queueExecutor();
/*      */     }
/*      */   }
/*      */   
/*      */   private void queueExecutor()
/*      */   {
/*  986 */     if (isTrace)
/*      */     {
/*  988 */       HornetQClientLogger.LOGGER.trace("Adding Runner on Executor for delivery");
/*      */     }
/*      */     
/*  991 */     this.sessionExecutor.execute(this.runner);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendCredits(final int credits)
/*      */   {
/*  999 */     this.pendingFlowControl.countUp();
/* 1000 */     this.flowControlExecutor.execute(new Runnable()
/*      */     {
/*      */       public void run()
/*      */       {
/*      */         try
/*      */         {
/* 1006 */           ClientConsumerImpl.this.channel.send(new SessionConsumerFlowCreditMessage(ClientConsumerImpl.this.id, credits));
/*      */         }
/*      */         finally
/*      */         {
/* 1010 */           ClientConsumerImpl.this.pendingFlowControl.countDown();
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   private void waitForOnMessageToComplete(boolean waitForOnMessage)
/*      */   {
/* 1018 */     if (this.handler == null)
/*      */     {
/* 1020 */       return;
/*      */     }
/*      */     
/* 1023 */     if ((!waitForOnMessage) || (Thread.currentThread() == this.onMessageThread))
/*      */     {
/*      */ 
/* 1026 */       return;
/*      */     }
/*      */     
/* 1029 */     FutureLatch future = new FutureLatch();
/*      */     
/* 1031 */     this.sessionExecutor.execute(future);
/*      */     
/* 1033 */     boolean ok = future.await(10000L);
/*      */     
/* 1035 */     if (!ok)
/*      */     {
/* 1037 */       HornetQClientLogger.LOGGER.timeOutWaitingForProcessing();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkClosed() throws HornetQException
/*      */   {
/* 1043 */     if (this.closed)
/*      */     {
/* 1045 */       throw HornetQClientMessageBundle.BUNDLE.consumerClosed();
/*      */     }
/*      */   }
/*      */   
/*      */   private void callOnMessage() throws Exception
/*      */   {
/* 1051 */     if ((this.closing) || (this.stopped))
/*      */     {
/* 1053 */       return;
/*      */     }
/*      */     
/* 1056 */     this.session.workDone();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1066 */     MessageHandler theHandler = this.handler;
/*      */     
/* 1068 */     if (theHandler != null)
/*      */     {
/* 1070 */       if (this.rateLimiter != null)
/*      */       {
/* 1072 */         this.rateLimiter.limit();
/*      */       }
/*      */       
/* 1075 */       this.failedOver = false;
/*      */       ClientMessageInternal message;
/* 1077 */       synchronized (this)
/*      */       {
/* 1079 */         message = (ClientMessageInternal)this.buffer.poll();
/*      */       }
/*      */       
/* 1082 */       if (message != null)
/*      */       {
/* 1084 */         if (message.containsProperty(FORCED_DELIVERY_MESSAGE))
/*      */         {
/*      */ 
/* 1087 */           return;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1092 */         boolean expired = message.isExpired();
/*      */         
/* 1094 */         flowControlBeforeConsumption(message);
/*      */         
/* 1096 */         if (!expired)
/*      */         {
/* 1098 */           if (isTrace)
/*      */           {
/* 1100 */             HornetQClientLogger.LOGGER.trace("Calling handler.onMessage");
/*      */           }
/* 1102 */           final ClassLoader originalLoader = (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*      */           {
/*      */             public ClassLoader run()
/*      */             {
/* 1106 */               ClassLoader originalLoader = Thread.currentThread().getContextClassLoader();
/*      */               
/* 1108 */               Thread.currentThread().setContextClassLoader(ClientConsumerImpl.this.contextClassLoader);
/*      */               
/* 1110 */               return originalLoader;
/*      */             }
/*      */             
/* 1113 */           });
/* 1114 */           this.onMessageThread = Thread.currentThread();
/*      */           try
/*      */           {
/* 1117 */             theHandler.onMessage(message);
/*      */           }
/*      */           finally
/*      */           {
/*      */             try
/*      */             {
/* 1123 */               AccessController.doPrivileged(new PrivilegedAction()
/*      */               {
/*      */                 public Object run()
/*      */                 {
/* 1127 */                   Thread.currentThread().setContextClassLoader(originalLoader);
/* 1128 */                   return null;
/*      */                 }
/*      */               });
/*      */             }
/*      */             catch (Exception e)
/*      */             {
/* 1134 */               HornetQClientLogger.LOGGER.warn(e.getMessage(), e);
/*      */             }
/*      */             
/* 1137 */             this.onMessageThread = null;
/*      */           }
/*      */           
/* 1140 */           if (isTrace)
/*      */           {
/* 1142 */             HornetQClientLogger.LOGGER.trace("Handler.onMessage done");
/*      */           }
/*      */           
/* 1145 */           if (message.isLargeMessage())
/*      */           {
/* 1147 */             message.discardBody();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1152 */           this.session.expire(this.id, message.getMessageID());
/*      */         }
/*      */         
/*      */ 
/* 1156 */         if (this.clientWindowSize == 0)
/*      */         {
/* 1158 */           startSlowConsumer();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void flowControlBeforeConsumption(ClientMessageInternal message)
/*      */     throws HornetQException
/*      */   {
/* 1171 */     if (message.getFlowControlSize() != 0)
/*      */     {
/*      */ 
/* 1174 */       flowControl(message.getFlowControlSize(), !message.isLargeMessage());
/*      */     }
/*      */   }
/*      */   
/*      */   private void doCleanUp(boolean sendCloseMessage) throws HornetQException
/*      */   {
/*      */     try
/*      */     {
/* 1182 */       if (this.closed)
/*      */       {
/* 1184 */         return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1190 */       this.closing = true;
/*      */       
/*      */ 
/* 1193 */       waitForOnMessageToComplete(true);
/*      */       
/* 1195 */       resetLargeMessageController();
/*      */       
/* 1197 */       this.closed = true;
/*      */       
/* 1199 */       synchronized (this)
/*      */       {
/* 1201 */         if (this.receiverThread != null)
/*      */         {
/*      */ 
/* 1204 */           notify();
/*      */         }
/*      */         
/* 1207 */         this.handler = null;
/*      */         
/* 1209 */         this.receiverThread = null;
/*      */       }
/*      */       
/* 1212 */       flushAcks();
/*      */       
/* 1214 */       clearBuffer();
/*      */       
/* 1216 */       if (sendCloseMessage)
/*      */       {
/* 1218 */         this.channel.sendBlocking(new SessionConsumerCloseMessage(this.id), (byte)21);
/*      */       }
/*      */     }
/*      */     catch (Throwable t) {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1226 */     this.session.removeConsumer(this);
/*      */   }
/*      */   
/*      */   private void clearBuffer()
/*      */   {
/* 1231 */     this.buffer.clear();
/*      */   }
/*      */   
/*      */   private void doAck(ClientMessageInternal message) throws HornetQException
/*      */   {
/* 1236 */     this.ackBytes = 0;
/*      */     
/* 1238 */     this.lastAckedMessage = null;
/*      */     
/* 1240 */     this.session.acknowledge(this.id, message.getMessageID());
/*      */   }
/*      */   
/*      */   private class Runner
/*      */     implements Runnable
/*      */   {
/*      */     private Runner() {}
/*      */     
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/* 1252 */         ClientConsumerImpl.this.callOnMessage();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1256 */         HornetQClientLogger.LOGGER.onMessageError(e);
/*      */         
/* 1258 */         ClientConsumerImpl.this.lastException = e;
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientConsumerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */