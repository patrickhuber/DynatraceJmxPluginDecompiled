/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.api.core.client.ClusterTopologyListener;
/*     */ import org.hornetq.api.core.client.TopologyMember;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.spi.core.remoting.Connector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Topology
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -9037171688692471371L;
/*  41 */   private final Set<ClusterTopologyListener> topologyListeners = new HashSet();
/*     */   
/*  43 */   private transient Executor executor = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private volatile Object owner;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  60 */   private final Map<String, TopologyMemberImpl> topology = new ConcurrentHashMap();
/*     */   
/*     */   private transient Map<String, Long> mapDelete;
/*     */   
/*     */   public Topology(Object owner)
/*     */   {
/*  66 */     this.owner = owner;
/*  67 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */     {
/*  69 */       HornetQClientLogger.LOGGER.trace("Topology@" + Integer.toHexString(System.identityHashCode(this)) + " CREATE", new Exception("trace"));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setExecutor(Executor executor)
/*     */   {
/*  76 */     this.executor = executor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  84 */     this.topology.clear();
/*     */   }
/*     */   
/*     */   public void addClusterTopologyListener(ClusterTopologyListener listener)
/*     */   {
/*  89 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */     {
/*  91 */       HornetQClientLogger.LOGGER.trace(this + "::Adding topology listener " + listener, new Exception("Trace"));
/*     */     }
/*  93 */     synchronized (this.topologyListeners)
/*     */     {
/*  95 */       this.topologyListeners.add(listener);
/*     */     }
/*  97 */     sendTopology(listener);
/*     */   }
/*     */   
/*     */   public void removeClusterTopologyListener(ClusterTopologyListener listener)
/*     */   {
/* 102 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */     {
/* 104 */       HornetQClientLogger.LOGGER.trace(this + "::Removing topology listener " + listener, new Exception("Trace"));
/*     */     }
/* 106 */     synchronized (this.topologyListeners)
/*     */     {
/* 108 */       this.topologyListeners.remove(listener);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void updateAsLive(String nodeId, TopologyMemberImpl memberInput)
/*     */   {
/* 115 */     synchronized (this)
/*     */     {
/* 117 */       if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*     */       {
/* 119 */         HornetQClientLogger.LOGGER.debug(this + "::node " + nodeId + "=" + memberInput);
/*     */       }
/* 121 */       memberInput.setUniqueEventID(System.currentTimeMillis());
/* 122 */       this.topology.remove(nodeId);
/* 123 */       this.topology.put(nodeId, memberInput);
/* 124 */       sendMemberUp(nodeId, memberInput);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resendNode(String nodeId)
/*     */   {
/* 134 */     synchronized (this)
/*     */     {
/* 136 */       TopologyMemberImpl memberInput = (TopologyMemberImpl)this.topology.get(nodeId);
/* 137 */       if (memberInput != null)
/*     */       {
/* 139 */         memberInput.setUniqueEventID(System.currentTimeMillis());
/* 140 */         sendMemberUp(nodeId, memberInput);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public TopologyMemberImpl updateBackup(TopologyMemberImpl memberInput)
/*     */   {
/* 148 */     String nodeId = memberInput.getNodeId();
/* 149 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */     {
/* 151 */       HornetQClientLogger.LOGGER.trace(this + "::updateBackup::" + nodeId + ", memberInput=" + memberInput);
/*     */     }
/*     */     
/* 154 */     synchronized (this)
/*     */     {
/* 156 */       TopologyMemberImpl currentMember = getMember(nodeId);
/* 157 */       if (currentMember == null)
/*     */       {
/* 159 */         if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */         {
/* 161 */           HornetQClientLogger.LOGGER.trace("There's no live to be updated on backup update, node=" + nodeId + " memberInput=" + memberInput, new Exception("trace"));
/*     */         }
/*     */         
/*     */ 
/* 165 */         currentMember = memberInput;
/* 166 */         this.topology.put(nodeId, currentMember);
/*     */       }
/*     */       
/* 169 */       TopologyMemberImpl newMember = new TopologyMemberImpl(nodeId, currentMember.getBackupGroupName(), currentMember.getLive(), memberInput.getBackup());
/*     */       
/*     */ 
/* 172 */       newMember.setUniqueEventID(System.currentTimeMillis());
/* 173 */       this.topology.remove(nodeId);
/* 174 */       this.topology.put(nodeId, newMember);
/* 175 */       sendMemberUp(nodeId, newMember);
/*     */       
/* 177 */       return newMember;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean updateMember(long uniqueEventID, String nodeId, TopologyMemberImpl memberInput)
/*     */   {
/* 191 */     Long deleteTme = (Long)getMapDelete().get(nodeId);
/* 192 */     if ((deleteTme != null) && (uniqueEventID != 0L) && (uniqueEventID < deleteTme.longValue()))
/*     */     {
/* 194 */       HornetQClientLogger.LOGGER.debug("Update uniqueEvent=" + uniqueEventID + ", nodeId=" + nodeId + ", memberInput=" + memberInput + " being rejected as there was a delete done after that");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */       return false;
/*     */     }
/*     */     
/* 203 */     synchronized (this)
/*     */     {
/* 205 */       TopologyMemberImpl currentMember = (TopologyMemberImpl)this.topology.get(nodeId);
/*     */       
/* 207 */       if (currentMember == null)
/*     */       {
/* 209 */         if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */         {
/* 211 */           HornetQClientLogger.LOGGER.trace(this + "::NewMemeberAdd nodeId=" + nodeId + " member = " + memberInput, new Exception("trace"));
/*     */         }
/*     */         
/* 214 */         memberInput.setUniqueEventID(uniqueEventID);
/* 215 */         this.topology.put(nodeId, memberInput);
/* 216 */         sendMemberUp(nodeId, memberInput);
/* 217 */         return true;
/*     */       }
/* 219 */       if (uniqueEventID > currentMember.getUniqueEventID())
/*     */       {
/* 221 */         TopologyMemberImpl newMember = new TopologyMemberImpl(nodeId, memberInput.getBackupGroupName(), memberInput.getLive(), memberInput.getBackup());
/*     */         
/*     */ 
/*     */ 
/* 225 */         if ((newMember.getLive() == null) && (currentMember.getLive() != null))
/*     */         {
/* 227 */           newMember.setLive(currentMember.getLive());
/*     */         }
/*     */         
/* 230 */         if ((newMember.getBackup() == null) && (currentMember.getBackup() != null))
/*     */         {
/* 232 */           newMember.setBackup(currentMember.getBackup());
/*     */         }
/*     */         
/* 235 */         if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */         {
/* 237 */           HornetQClientLogger.LOGGER.trace(this + "::updated currentMember=nodeID=" + nodeId + ", currentMember=" + currentMember + ", memberInput=" + memberInput + "newMember=" + newMember, new Exception("trace"));
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 243 */         newMember.setUniqueEventID(uniqueEventID);
/* 244 */         this.topology.remove(nodeId);
/* 245 */         this.topology.put(nodeId, newMember);
/* 246 */         sendMemberUp(nodeId, newMember);
/*     */         
/* 248 */         return true;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 254 */       if ((currentMember.getBackup() == null) && (memberInput.getBackup() != null))
/*     */       {
/* 256 */         currentMember.setBackup(memberInput.getBackup());
/*     */       }
/* 258 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void sendMemberUp(final String nodeId, final TopologyMemberImpl memberToSend)
/*     */   {
/* 268 */     final ArrayList<ClusterTopologyListener> copy = copyListeners();
/*     */     
/* 270 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */     {
/* 272 */       HornetQClientLogger.LOGGER.trace(this + "::prepare to send " + nodeId + " to " + copy.size() + " elements");
/*     */     }
/*     */     
/* 275 */     if (copy.size() > 0)
/*     */     {
/* 277 */       execute(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 281 */           for (ClusterTopologyListener listener : copy)
/*     */           {
/* 283 */             if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */             {
/* 285 */               HornetQClientLogger.LOGGER.trace(Topology.this + " informing " + listener + " about node up = " + nodeId + " connector = " + memberToSend.getConnector());
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             try
/*     */             {
/* 295 */               listener.nodeUP(memberToSend, false);
/*     */             }
/*     */             catch (Throwable e)
/*     */             {
/* 299 */               HornetQClientLogger.LOGGER.errorSendingTopology(e);
/*     */             }
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private ArrayList<ClusterTopologyListener> copyListeners()
/*     */   {
/*     */     ArrayList<ClusterTopologyListener> listenersCopy;
/*     */     
/* 313 */     synchronized (this.topologyListeners)
/*     */     {
/* 315 */       listenersCopy = new ArrayList(this.topologyListeners);
/*     */     }
/* 317 */     return listenersCopy;
/*     */   }
/*     */   
/*     */ 
/*     */   boolean removeMember(final long uniqueEventID, final String nodeId)
/*     */   {
/*     */     TopologyMemberImpl member;
/* 324 */     synchronized (this)
/*     */     {
/* 326 */       member = (TopologyMemberImpl)this.topology.get(nodeId);
/* 327 */       if (member != null)
/*     */       {
/* 329 */         if (member.getUniqueEventID() > uniqueEventID)
/*     */         {
/* 331 */           HornetQClientLogger.LOGGER.debug("The removeMember was issued before the node " + nodeId + " was started, ignoring call");
/* 332 */           member = null;
/*     */         }
/*     */         else
/*     */         {
/* 336 */           getMapDelete().put(nodeId, Long.valueOf(uniqueEventID));
/* 337 */           member = (TopologyMemberImpl)this.topology.remove(nodeId);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 342 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */     {
/* 344 */       HornetQClientLogger.LOGGER.trace("removeMember " + this + " removing nodeID=" + nodeId + ", result=" + member + ", size = " + this.topology.size(), new Exception("trace"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */     if (member != null)
/*     */     {
/* 355 */       final ArrayList<ClusterTopologyListener> copy = copyListeners();
/*     */       
/* 357 */       execute(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 361 */           for (ClusterTopologyListener listener : copy)
/*     */           {
/* 363 */             if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*     */             {
/* 365 */               HornetQClientLogger.LOGGER.trace(this + " informing " + listener + " about node down = " + nodeId);
/*     */             }
/*     */             try
/*     */             {
/* 369 */               listener.nodeDown(uniqueEventID, nodeId);
/*     */             }
/*     */             catch (Exception e)
/*     */             {
/* 373 */               HornetQClientLogger.LOGGER.errorSendingTopologyNodedown(e);
/*     */             }
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 380 */     return member != null;
/*     */   }
/*     */   
/*     */   private void execute(Runnable runnable)
/*     */   {
/* 385 */     if (this.executor != null)
/*     */     {
/* 387 */       this.executor.execute(runnable);
/*     */     }
/*     */     else
/*     */     {
/* 391 */       runnable.run();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void sendTopology(final ClusterTopologyListener listener)
/*     */   {
/* 397 */     if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*     */     {
/* 399 */       HornetQClientLogger.LOGGER.debug(this + " is sending topology to " + listener);
/*     */     }
/*     */     
/* 402 */     execute(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 406 */         int count = 0;
/*     */         
/*     */         Map<String, TopologyMemberImpl> copy;
/*     */         
/* 410 */         synchronized (Topology.this)
/*     */         {
/* 412 */           copy = new HashMap(Topology.this.topology);
/*     */         }
/*     */         
/* 415 */         for (Object entry : copy.entrySet())
/*     */         {
/* 417 */           if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*     */           {
/* 419 */             HornetQClientLogger.LOGGER.debug(Topology.this + " sending " + (String)((Map.Entry)entry).getKey() + " / " + ((TopologyMemberImpl)((Map.Entry)entry).getValue()).getConnector() + " to " + listener);
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 426 */           listener.nodeUP((TopologyMember)((Map.Entry)entry).getValue(), ++count == copy.size());
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public synchronized TopologyMemberImpl getMember(String nodeID)
/*     */   {
/* 434 */     return (TopologyMemberImpl)this.topology.get(nodeID);
/*     */   }
/*     */   
/*     */   public synchronized TopologyMemberImpl getMember(TransportConfiguration configuration)
/*     */   {
/* 439 */     for (TopologyMemberImpl member : this.topology.values())
/*     */     {
/* 441 */       if (member.isMember(configuration))
/*     */       {
/* 443 */         return member;
/*     */       }
/*     */     }
/*     */     
/* 447 */     return null;
/*     */   }
/*     */   
/*     */   public synchronized boolean isEmpty()
/*     */   {
/* 452 */     return this.topology.isEmpty();
/*     */   }
/*     */   
/*     */   public Collection<TopologyMemberImpl> getMembers()
/*     */   {
/*     */     ArrayList<TopologyMemberImpl> members;
/* 458 */     synchronized (this)
/*     */     {
/* 460 */       members = new ArrayList(this.topology.values());
/*     */     }
/* 462 */     return members;
/*     */   }
/*     */   
/*     */   synchronized int nodes()
/*     */   {
/* 467 */     int count = 0;
/* 468 */     for (TopologyMemberImpl member : this.topology.values())
/*     */     {
/* 470 */       if (member.getLive() != null)
/*     */       {
/* 472 */         count++;
/*     */       }
/* 474 */       if (member.getBackup() != null)
/*     */       {
/* 476 */         count++;
/*     */       }
/*     */     }
/* 479 */     return count;
/*     */   }
/*     */   
/*     */   public synchronized String describe()
/*     */   {
/* 484 */     return describe("");
/*     */   }
/*     */   
/*     */   private synchronized String describe(String text)
/*     */   {
/* 489 */     StringBuilder desc = new StringBuilder(text + "topology on " + this + ":\n");
/* 490 */     for (Map.Entry<String, TopologyMemberImpl> entry : new HashMap(this.topology).entrySet())
/*     */     {
/* 492 */       desc.append("\t" + (String)entry.getKey() + " => " + entry.getValue() + "\n");
/*     */     }
/* 494 */     desc.append("\tnodes=" + nodes() + "\t" + "members=" + members());
/* 495 */     if (this.topology.isEmpty())
/*     */     {
/* 497 */       desc.append("\tEmpty");
/*     */     }
/* 499 */     return desc.toString();
/*     */   }
/*     */   
/*     */   private int members()
/*     */   {
/* 504 */     return this.topology.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOwner(Object owner)
/*     */   {
/* 512 */     this.owner = owner;
/*     */   }
/*     */   
/*     */   public TransportConfiguration getBackupForConnector(Connector connector)
/*     */   {
/* 517 */     for (TopologyMemberImpl member : this.topology.values())
/*     */     {
/* 519 */       if ((member.getLive() != null) && (connector.isEquivalent(member.getLive().getParams())))
/*     */       {
/* 521 */         return member.getBackup();
/*     */       }
/*     */     }
/* 524 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 530 */     if (this.owner == null)
/*     */     {
/* 532 */       return "Topology@" + Integer.toHexString(System.identityHashCode(this));
/*     */     }
/* 534 */     return "Topology@" + Integer.toHexString(System.identityHashCode(this)) + "[owner=" + this.owner + "]";
/*     */   }
/*     */   
/*     */   private synchronized Map<String, Long> getMapDelete()
/*     */   {
/* 539 */     if (this.mapDelete == null)
/*     */     {
/* 541 */       this.mapDelete = new ConcurrentHashMap();
/*     */     }
/* 543 */     return this.mapDelete;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\Topology.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */