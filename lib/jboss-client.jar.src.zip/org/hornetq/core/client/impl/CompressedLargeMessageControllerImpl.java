/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*     */ import org.hornetq.utils.HornetQBufferInputStream;
/*     */ import org.hornetq.utils.InflaterReader;
/*     */ import org.hornetq.utils.InflaterWriter;
/*     */ import org.hornetq.utils.UTF8Util;
/*     */ import org.jboss.netty.buffer.ChannelBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CompressedLargeMessageControllerImpl
/*     */   implements LargeMessageController
/*     */ {
/*     */   private static final String OPERATION_NOT_SUPPORTED = "Operation not supported";
/*     */   private final LargeMessageController bufferDelegate;
/*     */   
/*     */   public CompressedLargeMessageControllerImpl(LargeMessageController bufferDelegate)
/*     */   {
/*  45 */     this.bufferDelegate = bufferDelegate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void discardUnusedPackets()
/*     */   {
/*  53 */     this.bufferDelegate.discardUnusedPackets();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPacket(SessionReceiveContinuationMessage packet)
/*     */   {
/*  63 */     this.bufferDelegate.addPacket(packet);
/*     */   }
/*     */   
/*     */   public synchronized void cancel()
/*     */   {
/*  68 */     this.bufferDelegate.cancel();
/*     */   }
/*     */   
/*     */   public synchronized void close()
/*     */   {
/*  73 */     this.bufferDelegate.cancel();
/*     */   }
/*     */   
/*     */   public void setOutputStream(OutputStream output) throws HornetQException
/*     */   {
/*  78 */     this.bufferDelegate.setOutputStream(new InflaterWriter(output));
/*     */   }
/*     */   
/*     */   public synchronized void saveBuffer(OutputStream output) throws HornetQException
/*     */   {
/*  83 */     setOutputStream(output);
/*  84 */     waitCompletion(0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized boolean waitCompletion(long timeWait)
/*     */     throws HornetQException
/*     */   {
/*  92 */     return this.bufferDelegate.waitCompletion(timeWait);
/*     */   }
/*     */   
/*     */ 
/*     */   public int capacity()
/*     */   {
/*  98 */     return -1;
/*     */   }
/*     */   
/* 101 */   DataInputStream dataInput = null;
/*     */   
/*     */   private DataInputStream getStream()
/*     */   {
/* 105 */     if (this.dataInput == null)
/*     */     {
/*     */       try
/*     */       {
/* 109 */         InputStream input = new HornetQBufferInputStream(this.bufferDelegate);
/*     */         
/* 111 */         this.dataInput = new DataInputStream(new InflaterReader(input));
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 115 */         throw new RuntimeException(e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 119 */     return this.dataInput;
/*     */   }
/*     */   
/*     */   private void positioningNotSupported()
/*     */   {
/* 124 */     throw new IllegalStateException("Position not supported over compressed large messages");
/*     */   }
/*     */   
/*     */   public byte readByte()
/*     */   {
/*     */     try
/*     */     {
/* 131 */       return getStream().readByte();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 135 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public byte getByte(int index)
/*     */   {
/* 142 */     positioningNotSupported();
/* 143 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void getBytes(int index, HornetQBuffer dst, int dstIndex, int length)
/*     */   {
/* 149 */     positioningNotSupported();
/*     */   }
/*     */   
/*     */ 
/*     */   public void getBytes(int index, byte[] dst, int dstIndex, int length)
/*     */   {
/* 155 */     positioningNotSupported();
/*     */   }
/*     */   
/*     */ 
/*     */   public void getBytes(int index, ByteBuffer dst)
/*     */   {
/* 161 */     positioningNotSupported();
/*     */   }
/*     */   
/*     */ 
/*     */   public int getInt(int index)
/*     */   {
/* 167 */     positioningNotSupported();
/* 168 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getLong(int index)
/*     */   {
/* 174 */     positioningNotSupported();
/* 175 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */   public short getShort(int index)
/*     */   {
/* 181 */     positioningNotSupported();
/* 182 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setByte(int index, byte value)
/*     */   {
/* 188 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, HornetQBuffer src, int srcIndex, int length)
/*     */   {
/* 194 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*     */   {
/* 200 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setBytes(int index, ByteBuffer src)
/*     */   {
/* 206 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setInt(int index, int value)
/*     */   {
/* 212 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLong(int index, long value)
/*     */   {
/* 218 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void setShort(int index, short value)
/*     */   {
/* 224 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public ByteBuffer toByteBuffer(int index, int length)
/*     */   {
/* 230 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public int readerIndex()
/*     */   {
/* 235 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readerIndex(int readerIndex) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public int writerIndex()
/*     */   {
/* 246 */     return 0;
/*     */   }
/*     */   
/*     */   public long getSize()
/*     */   {
/* 251 */     return this.bufferDelegate.getSize();
/*     */   }
/*     */   
/*     */   public void writerIndex(int writerIndex)
/*     */   {
/* 256 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void setIndex(int readerIndex, int writerIndex)
/*     */   {
/* 261 */     positioningNotSupported();
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear() {}
/*     */   
/*     */ 
/*     */   public boolean readable()
/*     */   {
/* 270 */     return true;
/*     */   }
/*     */   
/*     */   public boolean writable()
/*     */   {
/* 275 */     return false;
/*     */   }
/*     */   
/*     */   public int readableBytes()
/*     */   {
/* 280 */     return 1;
/*     */   }
/*     */   
/*     */   public int writableBytes()
/*     */   {
/* 285 */     return 0;
/*     */   }
/*     */   
/*     */   public void markReaderIndex()
/*     */   {
/* 290 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void resetReaderIndex() {}
/*     */   
/*     */ 
/*     */   public void markWriterIndex()
/*     */   {
/* 300 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void resetWriterIndex()
/*     */   {
/* 305 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void discardReadBytes()
/*     */   {
/* 310 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public short getUnsignedByte(int index)
/*     */   {
/* 315 */     return (short)(getByte(index) & 0xFF);
/*     */   }
/*     */   
/*     */   public int getUnsignedShort(int index)
/*     */   {
/* 320 */     return getShort(index) & 0xFFFF;
/*     */   }
/*     */   
/*     */   public long getUnsignedInt(int index)
/*     */   {
/* 325 */     return getInt(index) & 0xFFFFFFFF;
/*     */   }
/*     */   
/*     */ 
/*     */   public void getBytes(int index, byte[] dst)
/*     */   {
/* 331 */     for (int i = 0; i < dst.length; i++)
/*     */     {
/* 333 */       dst[i] = getByte(index++);
/*     */     }
/*     */   }
/*     */   
/*     */   public void getBytes(int index, HornetQBuffer dst)
/*     */   {
/* 339 */     getBytes(index, dst, dst.writableBytes());
/*     */   }
/*     */   
/*     */   public void getBytes(int index, HornetQBuffer dst, int length)
/*     */   {
/* 344 */     if (length > dst.writableBytes())
/*     */     {
/* 346 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 348 */     getBytes(index, dst, dst.writerIndex(), length);
/* 349 */     dst.writerIndex(dst.writerIndex() + length);
/*     */   }
/*     */   
/*     */   public void setBytes(int index, byte[] src)
/*     */   {
/* 354 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void setBytes(int index, HornetQBuffer src)
/*     */   {
/* 359 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void setBytes(int index, HornetQBuffer src, int length)
/*     */   {
/* 364 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public short readUnsignedByte()
/*     */   {
/*     */     try
/*     */     {
/* 371 */       return (short)getStream().readUnsignedByte();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 375 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public short readShort()
/*     */   {
/*     */     try
/*     */     {
/* 383 */       return getStream().readShort();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 387 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public int readUnsignedShort()
/*     */   {
/*     */     try
/*     */     {
/* 395 */       return getStream().readUnsignedShort();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 399 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public int readInt()
/*     */   {
/*     */     try
/*     */     {
/* 407 */       return getStream().readInt();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 411 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public long readUnsignedInt()
/*     */   {
/* 417 */     return readInt() & 0xFFFFFFFF;
/*     */   }
/*     */   
/*     */   public long readLong()
/*     */   {
/*     */     try
/*     */     {
/* 424 */       return getStream().readLong();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 428 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void readBytes(byte[] dst, int dstIndex, int length)
/*     */   {
/*     */     try
/*     */     {
/* 436 */       int nReadBytes = getStream().read(dst, dstIndex, length);
/* 437 */       if (nReadBytes < length)
/*     */       {
/* 439 */         HornetQClientLogger.LOGGER.compressedLargeMessageError(length, nReadBytes);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 444 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void readBytes(byte[] dst)
/*     */   {
/* 450 */     readBytes(dst, 0, dst.length);
/*     */   }
/*     */   
/*     */   public void readBytes(HornetQBuffer dst)
/*     */   {
/* 455 */     readBytes(dst, dst.writableBytes());
/*     */   }
/*     */   
/*     */   public void readBytes(HornetQBuffer dst, int length)
/*     */   {
/* 460 */     if (length > dst.writableBytes())
/*     */     {
/* 462 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 464 */     readBytes(dst, dst.writerIndex(), length);
/* 465 */     dst.writerIndex(dst.writerIndex() + length);
/*     */   }
/*     */   
/*     */   public void readBytes(HornetQBuffer dst, int dstIndex, int length)
/*     */   {
/* 470 */     byte[] destBytes = new byte[length];
/* 471 */     readBytes(destBytes);
/* 472 */     dst.setBytes(dstIndex, destBytes);
/*     */   }
/*     */   
/*     */   public void readBytes(ByteBuffer dst)
/*     */   {
/* 477 */     byte[] bytesToGet = new byte[dst.remaining()];
/* 478 */     readBytes(bytesToGet);
/* 479 */     dst.put(bytesToGet);
/*     */   }
/*     */   
/*     */ 
/*     */   public void skipBytes(int length)
/*     */   {
/*     */     try
/*     */     {
/* 487 */       for (int i = 0; i < length; i++)
/*     */       {
/* 489 */         getStream().read();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 494 */       throw new IllegalStateException(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeByte(byte value)
/*     */   {
/* 500 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeShort(short value)
/*     */   {
/* 505 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeInt(int value)
/*     */   {
/* 510 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeLong(long value)
/*     */   {
/* 515 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeBytes(byte[] src, int srcIndex, int length)
/*     */   {
/* 520 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeBytes(byte[] src)
/*     */   {
/* 525 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeBytes(HornetQBuffer src, int length)
/*     */   {
/* 530 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeBytes(ByteBuffer src)
/*     */   {
/* 535 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public ByteBuffer toByteBuffer()
/*     */   {
/* 540 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public Object getUnderlyingBuffer()
/*     */   {
/* 545 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean readBoolean()
/*     */   {
/* 551 */     return readByte() != 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public char readChar()
/*     */   {
/* 557 */     return (char)readShort();
/*     */   }
/*     */   
/*     */   public char getChar(int index)
/*     */   {
/* 562 */     return (char)getShort(index);
/*     */   }
/*     */   
/*     */   public double getDouble(int index)
/*     */   {
/* 567 */     return Double.longBitsToDouble(getLong(index));
/*     */   }
/*     */   
/*     */   public float getFloat(int index)
/*     */   {
/* 572 */     return Float.intBitsToFloat(getInt(index));
/*     */   }
/*     */   
/*     */   public HornetQBuffer readBytes(int length)
/*     */   {
/* 577 */     byte[] bytesToGet = new byte[length];
/* 578 */     readBytes(bytesToGet);
/* 579 */     return HornetQBuffers.wrappedBuffer(bytesToGet);
/*     */   }
/*     */   
/*     */ 
/*     */   public double readDouble()
/*     */   {
/* 585 */     return Double.longBitsToDouble(readLong());
/*     */   }
/*     */   
/*     */ 
/*     */   public float readFloat()
/*     */   {
/* 591 */     return Float.intBitsToFloat(readInt());
/*     */   }
/*     */   
/*     */ 
/*     */   public SimpleString readNullableSimpleString()
/*     */   {
/* 597 */     int b = readByte();
/* 598 */     if (b == 0)
/*     */     {
/* 600 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 604 */     return readSimpleString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String readNullableString()
/*     */   {
/* 611 */     int b = readByte();
/* 612 */     if (b == 0)
/*     */     {
/* 614 */       return null;
/*     */     }
/*     */     
/*     */ 
/* 618 */     return readString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public SimpleString readSimpleString()
/*     */   {
/* 625 */     int len = readInt();
/* 626 */     byte[] data = new byte[len];
/* 627 */     readBytes(data);
/* 628 */     return new SimpleString(data);
/*     */   }
/*     */   
/*     */ 
/*     */   public String readString()
/*     */   {
/* 634 */     int len = readInt();
/*     */     
/* 636 */     if (len < 9)
/*     */     {
/* 638 */       char[] chars = new char[len];
/* 639 */       for (int i = 0; i < len; i++)
/*     */       {
/* 641 */         chars[i] = ((char)readShort());
/*     */       }
/* 643 */       return new String(chars);
/*     */     }
/* 645 */     if (len < 4095)
/*     */     {
/* 647 */       return readUTF();
/*     */     }
/*     */     
/*     */ 
/* 651 */     return readSimpleString().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String readUTF()
/*     */   {
/* 658 */     return UTF8Util.readUTF(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeBoolean(boolean val)
/*     */   {
/* 664 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeChar(char val)
/*     */   {
/* 670 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeDouble(double val)
/*     */   {
/* 676 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeFloat(float val)
/*     */   {
/* 683 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeNullableSimpleString(SimpleString val)
/*     */   {
/* 690 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeNullableString(String val)
/*     */   {
/* 696 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeSimpleString(SimpleString val)
/*     */   {
/* 702 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeString(String val)
/*     */   {
/* 708 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeUTF(String utf)
/*     */   {
/* 714 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public HornetQBuffer copy()
/*     */   {
/* 719 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */   public HornetQBuffer slice(int index, int length)
/*     */   {
/* 724 */     throw new UnsupportedOperationException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ChannelBuffer channelBuffer()
/*     */   {
/* 731 */     return null;
/*     */   }
/*     */   
/*     */   public HornetQBuffer copy(int index, int length)
/*     */   {
/* 736 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public HornetQBuffer duplicate()
/*     */   {
/* 741 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public HornetQBuffer readSlice(int length)
/*     */   {
/* 746 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void setChar(int index, char value)
/*     */   {
/* 751 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void setDouble(int index, double value)
/*     */   {
/* 756 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void setFloat(int index, float value)
/*     */   {
/* 761 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public HornetQBuffer slice()
/*     */   {
/* 766 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */   
/*     */   public void writeBytes(HornetQBuffer src, int srcIndex, int length)
/*     */   {
/* 771 */     throw new IllegalAccessError("Operation not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\CompressedLargeMessageControllerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */