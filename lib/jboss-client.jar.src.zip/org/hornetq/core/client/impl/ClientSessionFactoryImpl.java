/*      */ package org.hornetq.core.client.impl;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import org.hornetq.api.core.HornetQBuffer;
/*      */ import org.hornetq.api.core.HornetQException;
/*      */ import org.hornetq.api.core.HornetQExceptionType;
/*      */ import org.hornetq.api.core.HornetQInterruptedException;
/*      */ import org.hornetq.api.core.HornetQNotConnectedException;
/*      */ import org.hornetq.api.core.Interceptor;
/*      */ import org.hornetq.api.core.Pair;
/*      */ import org.hornetq.api.core.SimpleString;
/*      */ import org.hornetq.api.core.TransportConfiguration;
/*      */ import org.hornetq.api.core.client.ClientSession;
/*      */ import org.hornetq.api.core.client.FailoverEventListener;
/*      */ import org.hornetq.api.core.client.FailoverEventType;
/*      */ import org.hornetq.api.core.client.ServerLocator;
/*      */ import org.hornetq.api.core.client.SessionFailureListener;
/*      */ import org.hornetq.core.client.HornetQClientLogger;
/*      */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*      */ import org.hornetq.core.protocol.core.Channel;
/*      */ import org.hornetq.core.protocol.core.ChannelHandler;
/*      */ import org.hornetq.core.protocol.core.CoreRemotingConnection;
/*      */ import org.hornetq.core.protocol.core.Packet;
/*      */ import org.hornetq.core.protocol.core.impl.PacketDecoder;
/*      */ import org.hornetq.core.protocol.core.impl.RemotingConnectionImpl;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.ClusterTopologyChangeMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.ClusterTopologyChangeMessage_V2;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.CreateSessionMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.CreateSessionResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.DisconnectMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.NodeAnnounceMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.Ping;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SubscribeClusterTopologyUpdatesMessageV2;
/*      */ import org.hornetq.core.remoting.FailureListener;
/*      */ import org.hornetq.core.server.HornetQComponent;
/*      */ import org.hornetq.core.version.Version;
/*      */ import org.hornetq.spi.core.protocol.ProtocolType;
/*      */ import org.hornetq.spi.core.remoting.BufferHandler;
/*      */ import org.hornetq.spi.core.remoting.Connection;
/*      */ import org.hornetq.spi.core.remoting.ConnectionLifeCycleListener;
/*      */ import org.hornetq.spi.core.remoting.Connector;
/*      */ import org.hornetq.spi.core.remoting.ConnectorFactory;
/*      */ import org.hornetq.utils.ClassloadingUtil;
/*      */ import org.hornetq.utils.ConcurrentHashSet;
/*      */ import org.hornetq.utils.ConfigurationHelper;
/*      */ import org.hornetq.utils.ExecutorFactory;
/*      */ import org.hornetq.utils.OrderedExecutorFactory;
/*      */ import org.hornetq.utils.UUIDGenerator;
/*      */ import org.hornetq.utils.VersionLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClientSessionFactoryImpl
/*      */   implements ClientSessionFactoryInternal, ConnectionLifeCycleListener
/*      */ {
/*   90 */   private static final boolean isTrace = HornetQClientLogger.LOGGER.isTraceEnabled();
/*      */   
/*   92 */   private static final boolean isDebug = HornetQClientLogger.LOGGER.isDebugEnabled();
/*      */   
/*      */ 
/*      */   private final ServerLocatorInternal serverLocator;
/*      */   
/*      */ 
/*      */   private TransportConfiguration connectorConfig;
/*      */   
/*      */ 
/*      */   private TransportConfiguration backupConfig;
/*      */   
/*      */   private ConnectorFactory connectorFactory;
/*      */   
/*  105 */   private transient boolean finalizeCheck = true;
/*      */   
/*      */   private final long callTimeout;
/*      */   
/*      */   private final long callFailoverTimeout;
/*      */   
/*      */   private final long clientFailureCheckPeriod;
/*      */   
/*      */   private final long connectionTTL;
/*      */   
/*  115 */   private final Set<ClientSessionInternal> sessions = new HashSet();
/*      */   
/*  117 */   private final Object createSessionLock = new Object();
/*  118 */   private final Object failoverLock = new Object();
/*  119 */   private final Object connectionLock = new Object();
/*      */   
/*      */   private final ExecutorFactory orderedExecutorFactory;
/*      */   
/*      */   private final Executor threadPool;
/*      */   
/*      */   private final ScheduledExecutorService scheduledThreadPool;
/*      */   
/*      */   private final Executor closeExecutor;
/*      */   
/*      */   private CoreRemotingConnection connection;
/*      */   
/*      */   private final long retryInterval;
/*      */   
/*      */   private final double retryIntervalMultiplier;
/*      */   
/*      */   private final long maxRetryInterval;
/*      */   
/*      */   private int reconnectAttempts;
/*      */   
/*  139 */   private final Set<SessionFailureListener> listeners = new ConcurrentHashSet();
/*      */   
/*  141 */   private final Set<FailoverEventListener> failoverListeners = new ConcurrentHashSet();
/*      */   
/*      */ 
/*      */   private Connector connector;
/*      */   
/*      */ 
/*      */   private Future<?> pingerFuture;
/*      */   
/*      */ 
/*      */   private PingRunnable pingRunnable;
/*      */   
/*      */ 
/*      */   private volatile boolean exitLoop;
/*      */   
/*  155 */   private final Object inCreateSessionGuard = new Object();
/*      */   
/*      */ 
/*      */   private boolean inCreateSession;
/*      */   
/*      */ 
/*      */   private CountDownLatch inCreateSessionLatch;
/*      */   
/*      */ 
/*      */   private final List<Interceptor> incomingInterceptors;
/*      */   
/*      */ 
/*      */   private final List<Interceptor> outgoingInterceptors;
/*      */   
/*      */   private volatile boolean stopPingingAfterOne;
/*      */   
/*      */   private volatile boolean closed;
/*      */   
/*  173 */   public final Exception e = new Exception();
/*      */   
/*  175 */   private final CountDownLatch waitLatch = new CountDownLatch(1);
/*      */   
/*  177 */   public static final Set<CloseRunnable> CLOSE_RUNNABLES = Collections.synchronizedSet(new HashSet());
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final PacketDecoder packetDecoder;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ClientSessionFactoryImpl(ServerLocatorInternal serverLocator, TransportConfiguration connectorConfig, long callTimeout, long callFailoverTimeout, long clientFailureCheckPeriod, long connectionTTL, long retryInterval, double retryIntervalMultiplier, long maxRetryInterval, int reconnectAttempts, Executor threadPool, ScheduledExecutorService scheduledThreadPool, List<Interceptor> incomingInterceptors, List<Interceptor> outgoingInterceptors, PacketDecoder packetDecoder)
/*      */   {
/*  204 */     this.e.fillInStackTrace();
/*      */     
/*  206 */     this.serverLocator = serverLocator;
/*      */     
/*  208 */     this.connectorConfig = connectorConfig;
/*      */     
/*  210 */     this.connectorFactory = instantiateConnectorFactory(connectorConfig.getFactoryClassName());
/*      */     
/*  212 */     checkTransportKeys(this.connectorFactory, connectorConfig.getParams());
/*      */     
/*  214 */     this.callTimeout = callTimeout;
/*      */     
/*  216 */     this.callFailoverTimeout = callFailoverTimeout;
/*      */     
/*  218 */     this.clientFailureCheckPeriod = clientFailureCheckPeriod;
/*      */     
/*  220 */     this.connectionTTL = connectionTTL;
/*      */     
/*  222 */     this.retryInterval = retryInterval;
/*      */     
/*  224 */     this.retryIntervalMultiplier = retryIntervalMultiplier;
/*      */     
/*  226 */     this.maxRetryInterval = maxRetryInterval;
/*      */     
/*  228 */     this.reconnectAttempts = reconnectAttempts;
/*      */     
/*  230 */     this.scheduledThreadPool = scheduledThreadPool;
/*      */     
/*  232 */     this.threadPool = threadPool;
/*      */     
/*  234 */     this.orderedExecutorFactory = new OrderedExecutorFactory(threadPool);
/*      */     
/*  236 */     this.closeExecutor = this.orderedExecutorFactory.getExecutor();
/*      */     
/*  238 */     this.incomingInterceptors = incomingInterceptors;
/*      */     
/*  240 */     this.outgoingInterceptors = outgoingInterceptors;
/*      */     
/*  242 */     this.packetDecoder = packetDecoder;
/*      */   }
/*      */   
/*      */   public void disableFinalizeCheck()
/*      */   {
/*  247 */     this.finalizeCheck = false;
/*      */   }
/*      */   
/*      */   public void connect(int initialConnectAttempts, boolean failoverOnInitialConnection)
/*      */     throws HornetQException
/*      */   {
/*  253 */     getConnectionWithRetry(initialConnectAttempts);
/*      */     
/*  255 */     if (this.connection == null)
/*      */     {
/*  257 */       StringBuilder msg = new StringBuilder("Unable to connect to server using configuration ").append(this.connectorConfig);
/*      */       
/*  259 */       if (this.backupConfig != null)
/*      */       {
/*  261 */         msg.append(" and backup configuration ").append(this.backupConfig);
/*      */       }
/*  263 */       throw new HornetQNotConnectedException(msg.toString());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public TransportConfiguration getConnectorConfiguration()
/*      */   {
/*  270 */     return this.connectorConfig;
/*      */   }
/*      */   
/*      */   public void setBackupConnector(TransportConfiguration live, TransportConfiguration backUp)
/*      */   {
/*  275 */     Connector localConnector = this.connector;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  280 */     if (localConnector == null)
/*      */     {
/*  282 */       localConnector = this.connectorFactory.createConnector(this.connectorConfig.getParams(), new DelegatingBufferHandler(null), this, this.closeExecutor, this.threadPool, this.scheduledThreadPool);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  290 */     if ((localConnector.isEquivalent(live.getParams())) && (backUp != null) && (!localConnector.isEquivalent(backUp.getParams())))
/*      */     {
/*  292 */       if (isDebug)
/*      */       {
/*  294 */         HornetQClientLogger.LOGGER.debug("Setting up backup config = " + backUp + " for live = " + live);
/*      */       }
/*  296 */       this.backupConfig = backUp;
/*      */ 
/*      */ 
/*      */     }
/*  300 */     else if (isDebug)
/*      */     {
/*  302 */       HornetQClientLogger.LOGGER.debug("ClientSessionFactoryImpl received backup update for live/backup pair = " + live + " / " + backUp + " but it didn't belong to " + this.connectorConfig);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getBackupConnector()
/*      */   {
/*  313 */     return this.backupConfig;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createSession(String username, String password, boolean xa, boolean autoCommitSends, boolean autoCommitAcks, boolean preAcknowledge, int ackBatchSize)
/*      */     throws HornetQException
/*      */   {
/*  324 */     return createSessionInternal(username, password, xa, autoCommitSends, autoCommitAcks, preAcknowledge, ackBatchSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createSession(boolean autoCommitSends, boolean autoCommitAcks, int ackBatchSize)
/*      */     throws HornetQException
/*      */   {
/*  337 */     return createSessionInternal(null, null, false, autoCommitSends, autoCommitAcks, this.serverLocator.isPreAcknowledge(), ackBatchSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createXASession()
/*      */     throws HornetQException
/*      */   {
/*  348 */     return createSessionInternal(null, null, true, false, false, this.serverLocator.isPreAcknowledge(), this.serverLocator.getAckBatchSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createTransactedSession()
/*      */     throws HornetQException
/*      */   {
/*  359 */     return createSessionInternal(null, null, false, false, false, this.serverLocator.isPreAcknowledge(), this.serverLocator.getAckBatchSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createSession()
/*      */     throws HornetQException
/*      */   {
/*  370 */     return createSessionInternal(null, null, false, true, true, this.serverLocator.isPreAcknowledge(), this.serverLocator.getAckBatchSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createSession(boolean autoCommitSends, boolean autoCommitAcks)
/*      */     throws HornetQException
/*      */   {
/*  381 */     return createSessionInternal(null, null, false, autoCommitSends, autoCommitAcks, this.serverLocator.isPreAcknowledge(), this.serverLocator.getAckBatchSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createSession(boolean xa, boolean autoCommitSends, boolean autoCommitAcks)
/*      */     throws HornetQException
/*      */   {
/*  392 */     return createSessionInternal(null, null, xa, autoCommitSends, autoCommitAcks, this.serverLocator.isPreAcknowledge(), this.serverLocator.getAckBatchSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientSession createSession(boolean xa, boolean autoCommitSends, boolean autoCommitAcks, boolean preAcknowledge)
/*      */     throws HornetQException
/*      */   {
/*  406 */     return createSessionInternal(null, null, xa, autoCommitSends, autoCommitAcks, preAcknowledge, this.serverLocator.getAckBatchSize());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void connectionCreated(HornetQComponent component, Connection connection, ProtocolType protocol) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void connectionDestroyed(final Object connectionID)
/*      */   {
/*  425 */     final HornetQException ex = HornetQClientMessageBundle.BUNDLE.channelDisconnected();
/*      */     
/*      */ 
/*      */ 
/*  429 */     this.closeExecutor.execute(new Runnable()
/*      */     {
/*      */       public void run()
/*      */       {
/*  433 */         ClientSessionFactoryImpl.this.handleConnectionFailure(connectionID, ex);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */   public void connectionException(Object connectionID, HornetQException me)
/*      */   {
/*  441 */     handleConnectionFailure(connectionID, me);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void removeSession(ClientSessionInternal session, boolean failingOver)
/*      */   {
/*  448 */     synchronized (this.sessions)
/*      */     {
/*  450 */       this.sessions.remove(session);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void connectionReadyForWrites(Object connectionID, boolean ready) {}
/*      */   
/*      */ 
/*      */   public synchronized int numConnections()
/*      */   {
/*  460 */     return this.connection != null ? 1 : 0;
/*      */   }
/*      */   
/*      */   public int numSessions()
/*      */   {
/*  465 */     return this.sessions.size();
/*      */   }
/*      */   
/*      */   public void addFailureListener(SessionFailureListener listener)
/*      */   {
/*  470 */     this.listeners.add(listener);
/*      */   }
/*      */   
/*      */   public boolean removeFailureListener(SessionFailureListener listener)
/*      */   {
/*  475 */     return this.listeners.remove(listener);
/*      */   }
/*      */   
/*      */   public void addFailoverListener(FailoverEventListener listener)
/*      */   {
/*  480 */     this.failoverListeners.add(listener);
/*      */   }
/*      */   
/*      */   public boolean removeFailoverListener(FailoverEventListener listener)
/*      */   {
/*  485 */     return this.failoverListeners.remove(listener);
/*      */   }
/*      */   
/*      */   public void causeExit()
/*      */   {
/*  490 */     this.exitLoop = true;
/*  491 */     this.waitLatch.countDown();
/*      */   }
/*      */   
/*      */   private void interruptConnectAndCloseAllSessions(boolean close)
/*      */   {
/*  496 */     this.exitLoop = true;
/*  497 */     synchronized (this.inCreateSessionGuard)
/*      */     {
/*  499 */       if (this.inCreateSessionLatch != null)
/*  500 */         this.inCreateSessionLatch.countDown();
/*      */     }
/*  502 */     forceReturnChannel1(null);
/*      */     
/*      */ 
/*  505 */     causeExit();
/*      */     
/*  507 */     synchronized (this.createSessionLock)
/*      */     {
/*  509 */       closeCleanSessions(close);
/*  510 */       this.closed = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void closeCleanSessions(boolean close)
/*      */   {
/*      */     HashSet<ClientSessionInternal> sessionsToClose;
/*      */     
/*  520 */     synchronized (this.sessions)
/*      */     {
/*  522 */       sessionsToClose = new HashSet(this.sessions);
/*      */     }
/*      */     
/*      */ 
/*  526 */     for (ClientSessionInternal session : sessionsToClose)
/*      */     {
/*      */       try
/*      */       {
/*  530 */         if (close) {
/*  531 */           session.close();
/*      */         } else {
/*  533 */           session.cleanUp(false);
/*      */         }
/*      */       }
/*      */       catch (Exception e1) {
/*  537 */         HornetQClientLogger.LOGGER.unableToCloseSession(e1);
/*      */       }
/*      */     }
/*  540 */     checkCloseConnection();
/*      */   }
/*      */   
/*      */   public void close()
/*      */   {
/*  545 */     if (this.closed)
/*      */     {
/*  547 */       return;
/*      */     }
/*  549 */     interruptConnectAndCloseAllSessions(true);
/*      */     
/*  551 */     this.serverLocator.factoryClosed(this);
/*      */   }
/*      */   
/*      */   public void cleanup()
/*      */   {
/*  556 */     if (this.closed)
/*      */     {
/*  558 */       return;
/*      */     }
/*      */     
/*  561 */     interruptConnectAndCloseAllSessions(false);
/*      */   }
/*      */   
/*      */   public boolean isClosed()
/*      */   {
/*  566 */     return (this.closed) || (this.serverLocator.isClosed());
/*      */   }
/*      */   
/*      */ 
/*      */   public ServerLocator getServerLocator()
/*      */   {
/*  572 */     return this.serverLocator;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stopPingingAfterOne()
/*      */   {
/*  580 */     this.stopPingingAfterOne = true;
/*      */   }
/*      */   
/*      */   private void handleConnectionFailure(Object connectionID, HornetQException me)
/*      */   {
/*      */     try
/*      */     {
/*  587 */       failoverOrReconnect(connectionID, me);
/*      */ 
/*      */     }
/*      */     catch (HornetQInterruptedException e1)
/*      */     {
/*  592 */       HornetQClientLogger.LOGGER.debug(e1.getMessage(), e1);
/*      */     }
/*      */   }
/*      */   
/*      */   private void failoverOrReconnect(Object connectionID, HornetQException me)
/*      */   {
/*  598 */     Set<ClientSessionInternal> sessionsToClose = null;
/*  599 */     if (this.exitLoop)
/*  600 */       return;
/*  601 */     synchronized (this.failoverLock)
/*      */     {
/*  603 */       if ((this.connection == null) || (this.connection.getID() != connectionID) || (this.exitLoop))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  610 */         return;
/*      */       }
/*      */       
/*  613 */       if (isTrace)
/*      */       {
/*  615 */         HornetQClientLogger.LOGGER.trace("Client Connection failed, calling failure listeners and trying to reconnect, reconnectAttempts=" + this.reconnectAttempts);
/*      */       }
/*      */       
/*  618 */       callFailoverListeners(FailoverEventType.FAILURE_DETECTED);
/*      */       
/*  620 */       callSessionFailureListeners(me, false, false);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  649 */       if (this.reconnectAttempts != 0)
/*      */       {
/*  651 */         if (lockChannel1())
/*      */         {
/*      */           boolean needToInterrupt;
/*      */           
/*      */           CountDownLatch exitLockLatch;
/*      */           
/*  657 */           synchronized (this.inCreateSessionGuard)
/*      */           {
/*  659 */             needToInterrupt = this.inCreateSession;
/*  660 */             exitLockLatch = this.inCreateSessionLatch;
/*      */           }
/*      */           
/*  663 */           unlockChannel1();
/*      */           
/*  665 */           if (needToInterrupt)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  670 */             forceReturnChannel1(me);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  676 */             while ((this.inCreateSession) && (!this.exitLoop))
/*      */             {
/*      */               try
/*      */               {
/*  680 */                 exitLockLatch.await(500L, TimeUnit.MILLISECONDS);
/*      */               }
/*      */               catch (InterruptedException e1)
/*      */               {
/*  684 */                 throw new HornetQInterruptedException(e1);
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  696 */           CoreRemotingConnection oldConnection = this.connection;
/*      */           
/*  698 */           this.connection = null;
/*      */           
/*  700 */           Connector localConnector = this.connector;
/*  701 */           if (localConnector != null)
/*      */           {
/*      */             try
/*      */             {
/*  705 */               localConnector.close();
/*      */             }
/*      */             catch (Exception ignore) {}
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  713 */           cancelScheduledTasks();
/*      */           
/*  715 */           this.connector = null;
/*      */           
/*  717 */           reconnectSessions(oldConnection, this.reconnectAttempts, me);
/*      */           
/*  719 */           if (oldConnection != null)
/*      */           {
/*  721 */             oldConnection.destroy();
/*      */           }
/*      */           
/*  724 */           if (this.connection != null)
/*      */           {
/*  726 */             callFailoverListeners(FailoverEventType.FAILOVER_COMPLETED);
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  732 */         CoreRemotingConnection connectionToDestory = this.connection;
/*  733 */         if (connectionToDestory != null)
/*      */         {
/*  735 */           connectionToDestory.destroy();
/*      */         }
/*  737 */         this.connection = null;
/*      */       }
/*      */       
/*  740 */       if (this.connection == null)
/*      */       {
/*  742 */         synchronized (this.sessions)
/*      */         {
/*  744 */           sessionsToClose = new HashSet(this.sessions);
/*      */         }
/*  746 */         callFailoverListeners(FailoverEventType.FAILOVER_FAILED);
/*  747 */         callSessionFailureListeners(me, true, false);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  752 */     if (this.connection != null)
/*      */     {
/*  754 */       callSessionFailureListeners(me, true, true);
/*      */     }
/*  756 */     if (sessionsToClose != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  761 */       for (ClientSessionInternal session : sessionsToClose)
/*      */       {
/*      */         try
/*      */         {
/*  765 */           session.cleanUp(true);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  769 */           HornetQClientLogger.LOGGER.failedToCleanupSession(e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClientSession createSessionInternal(String username, String password, boolean xa, boolean autoCommitSends, boolean autoCommitAcks, boolean preAcknowledge, int ackBatchSize)
/*      */     throws HornetQException
/*      */   {
/*  783 */     for (Version clientVersion : )
/*      */     {
/*      */       try
/*      */       {
/*  787 */         return createSessionInternal(clientVersion, username, password, xa, autoCommitSends, autoCommitAcks, preAcknowledge, ackBatchSize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (HornetQException e)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  798 */         if (e.getType() != HornetQExceptionType.INCOMPATIBLE_CLIENT_SERVER_VERSIONS)
/*      */         {
/*  800 */           throw e;
/*      */         }
/*      */       }
/*      */     }
/*  804 */     this.connection.destroy();
/*  805 */     throw new HornetQException(HornetQExceptionType.INCOMPATIBLE_CLIENT_SERVER_VERSIONS);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClientSession createSessionInternal(Version clientVersion, String username, String password, boolean xa, boolean autoCommitSends, boolean autoCommitAcks, boolean preAcknowledge, int ackBatchSize)
/*      */     throws HornetQException
/*      */   {
/*  817 */     synchronized (this.createSessionLock)
/*      */     {
/*  819 */       if (this.exitLoop)
/*  820 */         throw HornetQClientMessageBundle.BUNDLE.clientSessionClosed();
/*  821 */       String name = UUIDGenerator.getInstance().generateStringUUID();
/*      */       
/*  823 */       boolean retry = false;
/*      */       do
/*      */       {
/*  826 */         Lock lock = null;
/*      */         
/*      */         try
/*      */         {
/*      */           Channel channel1;
/*      */           
/*  832 */           synchronized (this.failoverLock)
/*      */           {
/*  834 */             if (this.connection == null)
/*      */             {
/*  836 */               throw new IllegalStateException("Connection is null");
/*      */             }
/*      */             
/*  839 */             channel1 = this.connection.getChannel(1L, -1);
/*      */             
/*      */ 
/*  842 */             while (!channel1.getLock().tryLock(100L, TimeUnit.MILLISECONDS))
/*      */             {
/*  844 */               if (this.exitLoop) {
/*  845 */                 throw HornetQClientMessageBundle.BUNDLE.clientSessionClosed();
/*      */               }
/*      */             }
/*  848 */             lock = channel1.getLock();
/*      */           }
/*      */           
/*      */ 
/*  852 */           synchronized (this.inCreateSessionGuard)
/*      */           {
/*  854 */             if (this.exitLoop)
/*  855 */               throw HornetQClientMessageBundle.BUNDLE.clientSessionClosed();
/*  856 */             this.inCreateSession = true;
/*  857 */             this.inCreateSessionLatch = new CountDownLatch(1);
/*      */           }
/*      */           
/*  860 */           long sessionChannelID = this.connection.generateChannelID();
/*      */           
/*  862 */           Object request = new CreateSessionMessage(name, sessionChannelID, clientVersion.getIncrementingVersion(), username, password, this.serverLocator.getMinLargeMessageSize(), xa, autoCommitSends, autoCommitAcks, preAcknowledge, this.serverLocator.getConfirmationWindowSize(), null);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           CreateSessionResponseMessage response;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*  878 */             response = (CreateSessionResponseMessage)channel1.sendBlocking((Packet)request, (byte)31);
/*      */           }
/*      */           catch (HornetQException e)
/*      */           {
/*  882 */             if (this.exitLoop) {
/*  883 */               throw e;
/*      */             }
/*  885 */             if (e.getType() == HornetQExceptionType.UNBLOCKED)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*  890 */               retry = true;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  967 */               if (lock != null)
/*      */               {
/*  969 */                 lock.unlock();
/*      */               }
/*      */               
/*      */ 
/*  973 */               this.inCreateSession = false;
/*  974 */               this.inCreateSessionLatch.countDown(); continue;
/*      */             }
/*  896 */             throw e;
/*      */           }
/*      */           
/*      */ 
/*  900 */           Channel sessionChannel = this.connection.getChannel(sessionChannelID, this.serverLocator.getConfirmationWindowSize());
/*      */           
/*      */ 
/*  903 */           ClientSessionInternal session = new ClientSessionImpl(this, name, username, password, xa, autoCommitSends, autoCommitAcks, preAcknowledge, this.serverLocator.isBlockOnAcknowledge(), this.serverLocator.isAutoGroup(), ackBatchSize, this.serverLocator.getConsumerWindowSize(), this.serverLocator.getConsumerMaxRate(), this.serverLocator.getConfirmationWindowSize(), this.serverLocator.getProducerWindowSize(), this.serverLocator.getProducerMaxRate(), this.serverLocator.isBlockOnNonDurableSend(), this.serverLocator.isBlockOnDurableSend(), this.serverLocator.isCacheLargeMessagesClient(), this.serverLocator.getMinLargeMessageSize(), this.serverLocator.isCompressLargeMessage(), this.serverLocator.getInitialMessagePacketSize(), this.serverLocator.getGroupID(), this.connection, response.getServerVersion(), sessionChannel, this.orderedExecutorFactory.getExecutor(), this.orderedExecutorFactory.getExecutor());
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  932 */           synchronized (this.sessions)
/*      */           {
/*  934 */             if ((this.closed) || (this.exitLoop))
/*      */             {
/*  936 */               session.close();
/*  937 */               localObject3 = null;
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  967 */               if (lock != null)
/*      */               {
/*  969 */                 lock.unlock();
/*      */               }
/*      */               
/*      */ 
/*  973 */               this.inCreateSession = false;
/*  974 */               this.inCreateSessionLatch.countDown();return (ClientSession)localObject3;
/*      */             }
/*  939 */             this.sessions.add(session);
/*      */           }
/*      */           
/*  942 */           ChannelHandler handler = new ClientSessionPacketHandler(session, sessionChannel);
/*      */           
/*  944 */           sessionChannel.setHandler(handler);
/*      */           
/*  946 */           Object localObject3 = new DelegatingSession(session);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  967 */           if (lock != null)
/*      */           {
/*  969 */             lock.unlock();
/*      */           }
/*      */           
/*      */ 
/*  973 */           this.inCreateSession = false;
/*  974 */           this.inCreateSessionLatch.countDown();return (ClientSession)localObject3;
/*      */         }
/*      */         catch (Throwable t)
/*      */         {
/*  950 */           if (lock != null)
/*      */           {
/*  952 */             lock.unlock();
/*  953 */             lock = null;
/*      */           }
/*      */           
/*  956 */           if ((t instanceof HornetQException))
/*      */           {
/*  958 */             throw ((HornetQException)t);
/*      */           }
/*      */           
/*      */ 
/*  962 */           throw HornetQClientMessageBundle.BUNDLE.failedToCreateSession(t);
/*      */ 
/*      */         }
/*      */         finally
/*      */         {
/*  967 */           if (lock != null)
/*      */           {
/*  969 */             lock.unlock();
/*      */           }
/*      */           
/*      */ 
/*  973 */           this.inCreateSession = false;
/*  974 */           this.inCreateSessionLatch.countDown();
/*      */         }
/*      */         
/*  977 */       } while (retry);
/*      */     }
/*      */     
/*      */ 
/*  981 */     throw HornetQClientMessageBundle.BUNDLE.clietSessionInternal();
/*      */   }
/*      */   
/*      */ 
/*      */   private void callSessionFailureListeners(HornetQException me, boolean afterReconnect, boolean failedOver)
/*      */   {
/*  987 */     List<SessionFailureListener> listenersClone = new ArrayList(this.listeners);
/*      */     
/*  989 */     for (SessionFailureListener listener : listenersClone)
/*      */     {
/*      */       try
/*      */       {
/*  993 */         if (afterReconnect)
/*      */         {
/*  995 */           listener.connectionFailed(me, failedOver);
/*      */         }
/*      */         else
/*      */         {
/*  999 */           listener.beforeReconnect(me);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*      */ 
/* 1007 */         HornetQClientLogger.LOGGER.failedToExecuteListener(t);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void callFailoverListeners(FailoverEventType type)
/*      */   {
/* 1014 */     List<FailoverEventListener> listenersClone = new ArrayList(this.failoverListeners);
/*      */     
/* 1016 */     for (FailoverEventListener listener : listenersClone)
/*      */     {
/*      */       try
/*      */       {
/* 1020 */         listener.failoverEvent(type);
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*      */ 
/* 1027 */         HornetQClientLogger.LOGGER.failedToExecuteListener(t);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void reconnectSessions(CoreRemotingConnection oldConnection, int reconnectAttempts, HornetQException cause)
/*      */   {
/*      */     HashSet<ClientSessionInternal> sessionsToFailover;
/*      */     
/* 1038 */     synchronized (this.sessions)
/*      */     {
/* 1040 */       sessionsToFailover = new HashSet(this.sessions);
/*      */     }
/*      */     
/* 1043 */     for (ClientSessionInternal session : sessionsToFailover)
/*      */     {
/* 1045 */       session.preHandleFailover(this.connection);
/*      */     }
/*      */     
/* 1048 */     getConnectionWithRetry(reconnectAttempts);
/*      */     
/* 1050 */     if (this.connection == null)
/*      */     {
/* 1052 */       if (!this.exitLoop) {
/* 1053 */         HornetQClientLogger.LOGGER.failedToConnectToServer();
/*      */       }
/* 1055 */       return;
/*      */     }
/*      */     
/* 1058 */     List<FailureListener> oldListeners = oldConnection.getFailureListeners();
/*      */     
/* 1060 */     Object newListeners = new ArrayList(this.connection.getFailureListeners());
/*      */     
/* 1062 */     for (FailureListener listener : oldListeners)
/*      */     {
/*      */ 
/* 1065 */       if (!(listener instanceof DelegatingFailureListener))
/*      */       {
/* 1067 */         ((List)newListeners).add(listener);
/*      */       }
/*      */     }
/*      */     
/* 1071 */     this.connection.setFailureListeners((List)newListeners);
/*      */     
/* 1073 */     for (ClientSessionInternal session : sessionsToFailover)
/*      */     {
/* 1075 */       session.handleFailover(this.connection, cause);
/*      */     }
/*      */   }
/*      */   
/*      */   private void getConnectionWithRetry(int reconnectAttempts)
/*      */   {
/* 1081 */     if (this.exitLoop)
/* 1082 */       return;
/* 1083 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1085 */       HornetQClientLogger.LOGGER.trace("getConnectionWithRetry::" + reconnectAttempts + " with retryInterval = " + this.retryInterval + " multiplier = " + this.retryIntervalMultiplier, new Exception("trace"));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1092 */     long interval = this.retryInterval;
/*      */     
/* 1094 */     int count = 0;
/*      */     
/* 1096 */     while (!this.exitLoop)
/*      */     {
/* 1098 */       if (isDebug)
/*      */       {
/* 1100 */         HornetQClientLogger.LOGGER.debug("Trying reconnection attempt " + count + "/" + reconnectAttempts);
/*      */       }
/*      */       
/* 1103 */       getConnection();
/*      */       
/* 1105 */       if (this.connection == null)
/*      */       {
/*      */ 
/*      */ 
/* 1109 */         if (reconnectAttempts != 0)
/*      */         {
/* 1111 */           count++;
/*      */           
/* 1113 */           if ((reconnectAttempts != -1) && (count == reconnectAttempts))
/*      */           {
/* 1115 */             if (reconnectAttempts != 1)
/*      */             {
/* 1117 */               HornetQClientLogger.LOGGER.failedToConnectToServer(Integer.valueOf(reconnectAttempts));
/*      */             }
/* 1119 */             else if (reconnectAttempts == 1)
/*      */             {
/* 1121 */               HornetQClientLogger.LOGGER.debug("Trying to connect towards " + this);
/*      */             }
/*      */             
/* 1124 */             return;
/*      */           }
/*      */           
/* 1127 */           if (isTrace)
/*      */           {
/* 1129 */             HornetQClientLogger.LOGGER.waitingForRetry(Long.valueOf(interval), Long.valueOf(this.retryInterval), Double.valueOf(this.retryIntervalMultiplier));
/*      */           }
/*      */           
/*      */           try
/*      */           {
/* 1134 */             if (this.waitLatch.await(interval, TimeUnit.MILLISECONDS)) {
/* 1135 */               return;
/*      */             }
/*      */           }
/*      */           catch (InterruptedException ignore) {
/* 1139 */             throw new HornetQInterruptedException(this.e);
/*      */           }
/*      */           
/*      */ 
/* 1143 */           long newInterval = (interval * this.retryIntervalMultiplier);
/*      */           
/* 1145 */           if (newInterval > this.maxRetryInterval)
/*      */           {
/* 1147 */             newInterval = this.maxRetryInterval;
/*      */           }
/*      */           
/* 1150 */           interval = newInterval;
/*      */         }
/*      */         else
/*      */         {
/* 1154 */           HornetQClientLogger.LOGGER.debug("Could not connect to any server. Didn't have reconnection configured on the ClientSessionFactory");
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 1160 */         if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */         {
/* 1162 */           HornetQClientLogger.LOGGER.debug("Reconnection successfull");
/*      */         }
/* 1164 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void cancelScheduledTasks()
/*      */   {
/* 1171 */     Future<?> pingerFutureLocal = this.pingerFuture;
/* 1172 */     if (pingerFutureLocal != null)
/*      */     {
/* 1174 */       pingerFutureLocal.cancel(false);
/*      */     }
/* 1176 */     PingRunnable pingRunnableLocal = this.pingRunnable;
/* 1177 */     if (pingRunnableLocal != null)
/*      */     {
/* 1179 */       pingRunnableLocal.cancel();
/*      */     }
/* 1181 */     this.pingerFuture = null;
/* 1182 */     this.pingRunnable = null;
/*      */   }
/*      */   
/*      */   private void checkCloseConnection()
/*      */   {
/* 1187 */     if ((this.connection != null) && (this.sessions.size() == 0))
/*      */     {
/* 1189 */       cancelScheduledTasks();
/*      */       
/*      */       try
/*      */       {
/* 1193 */         this.connection.destroy();
/*      */       }
/*      */       catch (Throwable ignore) {}
/*      */       
/*      */ 
/*      */ 
/* 1199 */       this.connection = null;
/*      */       
/*      */       try
/*      */       {
/* 1203 */         if (this.connector != null)
/*      */         {
/* 1205 */           this.connector.close();
/*      */         }
/*      */       }
/*      */       catch (Throwable ignore) {}
/*      */       
/*      */ 
/*      */ 
/* 1212 */       this.connector = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public CoreRemotingConnection getConnection()
/*      */   {
/* 1218 */     if (this.closed)
/* 1219 */       throw new IllegalStateException("ClientSessionFactory is closed!");
/* 1220 */     if (this.exitLoop)
/* 1221 */       return null;
/* 1222 */     synchronized (this.connectionLock)
/*      */     {
/* 1224 */       if (this.connection == null)
/*      */       {
/* 1226 */         Connection tc = null;
/*      */         
/*      */         try
/*      */         {
/* 1230 */           DelegatingBufferHandler handler = new DelegatingBufferHandler(null);
/*      */           
/* 1232 */           this.connector = this.connectorFactory.createConnector(this.connectorConfig.getParams(), handler, this, this.closeExecutor, this.threadPool, this.scheduledThreadPool);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1239 */           if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */           {
/* 1241 */             HornetQClientLogger.LOGGER.debug("Trying to connect with connector = " + this.connectorFactory + ", parameters = " + this.connectorConfig.getParams() + " connector = " + this.connector);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1248 */           if (this.connector != null)
/*      */           {
/* 1250 */             this.connector.start();
/*      */             
/* 1252 */             if (isDebug)
/*      */             {
/* 1254 */               HornetQClientLogger.LOGGER.debug("Trying to connect at the main server using connector :" + this.connectorConfig);
/*      */             }
/*      */             
/* 1257 */             tc = this.connector.createConnection();
/*      */             
/* 1259 */             if (tc == null)
/*      */             {
/* 1261 */               if (isDebug)
/*      */               {
/* 1263 */                 HornetQClientLogger.LOGGER.debug("Main server is not up. Hopefully there's a backup configured now!");
/*      */               }
/*      */               
/*      */               try
/*      */               {
/* 1268 */                 this.connector.close();
/*      */               }
/*      */               catch (Throwable t) {}
/*      */               
/*      */ 
/*      */ 
/* 1274 */               this.connector = null;
/*      */             }
/*      */           }
/*      */           
/* 1278 */           if (this.connector == null)
/*      */           {
/* 1280 */             if (this.backupConfig != null)
/*      */             {
/* 1282 */               if (isDebug)
/*      */               {
/* 1284 */                 HornetQClientLogger.LOGGER.debug("Trying backup config = " + this.backupConfig);
/*      */               }
/* 1286 */               ConnectorFactory backupConnectorFactory = instantiateConnectorFactory(this.backupConfig.getFactoryClassName());
/* 1287 */               this.connector = backupConnectorFactory.createConnector(this.backupConfig.getParams(), handler, this, this.closeExecutor, this.threadPool, this.scheduledThreadPool);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1293 */               if (this.connector != null)
/*      */               {
/* 1295 */                 this.connector.start();
/*      */                 
/* 1297 */                 tc = this.connector.createConnection();
/*      */                 
/* 1299 */                 if (tc == null)
/*      */                 {
/* 1301 */                   if (isDebug)
/*      */                   {
/* 1303 */                     HornetQClientLogger.LOGGER.debug("Backup is not active yet");
/*      */                   }
/*      */                   
/*      */                   try
/*      */                   {
/* 1308 */                     this.connector.close();
/*      */                   }
/*      */                   catch (Throwable t) {}
/*      */                   
/*      */ 
/*      */ 
/* 1314 */                   this.connector = null;
/*      */ 
/*      */                 }
/*      */                 else
/*      */                 {
/*      */ 
/* 1320 */                   if (isDebug)
/*      */                   {
/* 1322 */                     HornetQClientLogger.LOGGER.debug("Connected to the backup at " + this.backupConfig);
/*      */                   }
/*      */                   
/* 1325 */                   this.connectorConfig = this.backupConfig;
/*      */                   
/* 1327 */                   this.backupConfig = null;
/*      */                   
/* 1329 */                   this.connectorFactory = backupConnectorFactory;
/*      */                 }
/*      */                 
/*      */               }
/*      */               
/*      */             }
/* 1335 */             else if (isTrace)
/*      */             {
/* 1337 */               HornetQClientLogger.LOGGER.trace("No Backup configured!", new Exception("trace"));
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1346 */           HornetQClientLogger.LOGGER.createConnectorException(e);
/*      */           
/* 1348 */           if (tc != null)
/*      */           {
/*      */             try
/*      */             {
/* 1352 */               tc.close();
/*      */             }
/*      */             catch (Throwable t) {}
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1359 */           if (this.connector != null)
/*      */           {
/*      */             try
/*      */             {
/* 1363 */               this.connector.close();
/*      */             }
/*      */             catch (Throwable t) {}
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1370 */           tc = null;
/*      */           
/* 1372 */           this.connector = null;
/*      */         }
/*      */         
/* 1375 */         if (tc == null)
/*      */         {
/* 1377 */           if (isTrace)
/*      */           {
/* 1379 */             HornetQClientLogger.LOGGER.trace("returning connection = " + this.connection + " as tc == null");
/*      */           }
/* 1381 */           return this.connection;
/*      */         }
/*      */         
/* 1384 */         this.connection = new RemotingConnectionImpl(this.packetDecoder, tc, this.callTimeout, this.callFailoverTimeout, this.incomingInterceptors, this.outgoingInterceptors);
/*      */         
/* 1386 */         this.connection.addFailureListener(new DelegatingFailureListener(this.connection.getID()));
/*      */         
/* 1388 */         Channel channel0 = this.connection.getChannel(0L, -1);
/*      */         
/* 1390 */         channel0.setHandler(new Channel0Handler(this.connection, null));
/*      */         
/* 1392 */         if (this.clientFailureCheckPeriod != -1L)
/*      */         {
/* 1394 */           if (this.pingerFuture == null)
/*      */           {
/* 1396 */             this.pingRunnable = new PingRunnable(null);
/*      */             
/* 1398 */             this.pingerFuture = this.scheduledThreadPool.scheduleWithFixedDelay(new ActualScheduledPinger(this.pingRunnable), 0L, this.clientFailureCheckPeriod, TimeUnit.MILLISECONDS);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/* 1403 */             this.pingRunnable.send();
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/* 1409 */             this.pingRunnable.run();
/*      */           }
/*      */         }
/*      */         
/* 1413 */         if (this.serverLocator.getTopology() != null)
/*      */         {
/* 1415 */           if (isTrace)
/*      */           {
/* 1417 */             HornetQClientLogger.LOGGER.trace(this + "::Subscribing Topology");
/*      */           }
/*      */           
/* 1420 */           channel0.send(new SubscribeClusterTopologyUpdatesMessageV2(this.serverLocator.isClusterConnection(), VersionLoader.getVersion().getIncrementingVersion()));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1426 */       if (this.serverLocator.getAfterConnectInternalListener() != null)
/*      */       {
/* 1428 */         this.serverLocator.getAfterConnectInternalListener().onConnection(this);
/*      */       }
/*      */       
/* 1431 */       if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */       {
/* 1433 */         HornetQClientLogger.LOGGER.trace("returning " + this.connection);
/*      */       }
/*      */       
/* 1436 */       return this.connection;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendNodeAnnounce(long currentEventID, String nodeID, String nodeName, boolean isBackup, TransportConfiguration config, TransportConfiguration backupConfig)
/*      */   {
/* 1447 */     Channel channel0 = this.connection.getChannel(0L, -1);
/* 1448 */     if (isDebug)
/*      */     {
/* 1450 */       HornetQClientLogger.LOGGER.debug("Announcing node " + this.serverLocator.getNodeID() + ", isBackup=" + isBackup);
/*      */     }
/* 1452 */     channel0.send(new NodeAnnounceMessage(currentEventID, nodeID, nodeName, isBackup, config, backupConfig));
/*      */   }
/*      */   
/*      */   protected void finalize()
/*      */     throws Throwable
/*      */   {
/* 1458 */     if ((!this.closed) && (this.finalizeCheck))
/*      */     {
/* 1460 */       HornetQClientLogger.LOGGER.factoryLeftOpen(this.e, System.identityHashCode(this));
/*      */       
/* 1462 */       close();
/*      */     }
/*      */     
/* 1465 */     super.finalize();
/*      */   }
/*      */   
/*      */   private ConnectorFactory instantiateConnectorFactory(final String connectorFactoryClassName)
/*      */   {
/* 1470 */     (ConnectorFactory)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public ConnectorFactory run()
/*      */       {
/* 1474 */         return (ConnectorFactory)ClassloadingUtil.newInstanceFromClassLoader(connectorFactoryClassName);
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   private boolean lockChannel1()
/*      */   {
/* 1481 */     CoreRemotingConnection connection0 = this.connection;
/* 1482 */     if (connection0 == null) {
/* 1483 */       return false;
/*      */     }
/* 1485 */     Channel channel1 = connection0.getChannel(1L, -1);
/* 1486 */     if (channel1 == null) {
/* 1487 */       return false;
/*      */     }
/*      */     try {
/* 1490 */       while (!channel1.getLock().tryLock(200L, TimeUnit.MILLISECONDS))
/*      */       {
/* 1492 */         if (this.exitLoop)
/* 1493 */           return false;
/*      */       }
/* 1495 */       return true;
/*      */     }
/*      */     catch (InterruptedException e) {}
/*      */     
/* 1499 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   private void unlockChannel1()
/*      */   {
/* 1505 */     if (this.connection != null)
/*      */     {
/* 1507 */       Channel channel1 = this.connection.getChannel(1L, -1);
/*      */       
/* 1509 */       if (channel1 != null)
/*      */       {
/* 1511 */         channel1.getLock().unlock();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void forceReturnChannel1(HornetQException cause)
/*      */   {
/* 1518 */     if (this.connection != null)
/*      */     {
/* 1520 */       Channel channel1 = this.connection.getChannel(1L, -1);
/*      */       
/* 1522 */       if (channel1 != null)
/*      */       {
/* 1524 */         channel1.returnBlocking(cause);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkTransportKeys(ConnectorFactory factory, Map<String, Object> params)
/*      */   {
/* 1531 */     if (params != null)
/*      */     {
/* 1533 */       Set<String> invalid = ConfigurationHelper.checkKeys(factory.getAllowableProperties(), params.keySet());
/*      */       
/* 1535 */       if (!invalid.isEmpty())
/*      */       {
/* 1537 */         String msg = "The following keys are invalid for configuring a connector: " + ConfigurationHelper.stringSetToCommaListString(invalid);
/*      */         
/*      */ 
/* 1540 */         throw new IllegalStateException(msg);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final class Channel0Handler
/*      */     implements ChannelHandler
/*      */   {
/*      */     private final CoreRemotingConnection conn;
/*      */     
/*      */     private Channel0Handler(CoreRemotingConnection conn)
/*      */     {
/* 1552 */       this.conn = conn;
/*      */     }
/*      */     
/*      */     public void handlePacket(Packet packet)
/*      */     {
/* 1557 */       byte type = packet.getType();
/*      */       
/* 1559 */       if (type == 11)
/*      */       {
/* 1561 */         DisconnectMessage msg = (DisconnectMessage)packet;
/*      */         
/* 1563 */         SimpleString nodeID = msg.getNodeID();
/*      */         
/* 1565 */         if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */         {
/* 1567 */           HornetQClientLogger.LOGGER.trace("Disconnect being called on client:" + msg + " server locator = " + ClientSessionFactoryImpl.this.serverLocator + " notifying node " + nodeID + " as down", new Exception("trace"));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1575 */         if (nodeID != null)
/*      */         {
/* 1577 */           ClientSessionFactoryImpl.this.serverLocator.notifyNodeDown(System.currentTimeMillis(), msg.getNodeID().toString());
/*      */         }
/*      */         
/* 1580 */         ClientSessionFactoryImpl.this.closeExecutor.execute(new ClientSessionFactoryImpl.CloseRunnable(ClientSessionFactoryImpl.this, this.conn, null));
/*      */       }
/* 1582 */       else if (type == 110)
/*      */       {
/* 1584 */         ClusterTopologyChangeMessage topMessage = (ClusterTopologyChangeMessage)packet;
/* 1585 */         notifyTopologyChange(topMessage);
/*      */       }
/* 1587 */       else if (type == 114)
/*      */       {
/* 1589 */         ClusterTopologyChangeMessage_V2 topMessage = (ClusterTopologyChangeMessage_V2)packet;
/* 1590 */         notifyTopologyChange(topMessage);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     private void notifyTopologyChange(final ClusterTopologyChangeMessage topMessage)
/*      */     {
/* 1599 */       ClientSessionFactoryImpl.this.threadPool.execute(new Runnable()
/*      */       {
/*      */         public void run() {
/*      */           String nodeName;
/*      */           long eventUID;
/*      */           String nodeName;
/* 1605 */           if ((topMessage instanceof ClusterTopologyChangeMessage_V2))
/*      */           {
/* 1607 */             long eventUID = ((ClusterTopologyChangeMessage_V2)topMessage).getUniqueEventID();
/* 1608 */             nodeName = ((ClusterTopologyChangeMessage_V2)topMessage).getNodeName();
/*      */           }
/*      */           else
/*      */           {
/* 1612 */             eventUID = System.currentTimeMillis();
/* 1613 */             nodeName = null;
/*      */           }
/*      */           
/* 1616 */           if (topMessage.isExit())
/*      */           {
/* 1618 */             if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */             {
/* 1620 */               HornetQClientLogger.LOGGER.debug("Notifying " + topMessage.getNodeID() + " going down");
/*      */             }
/*      */             
/* 1623 */             ClientSessionFactoryImpl.this.serverLocator.notifyNodeDown(eventUID, topMessage.getNodeID());
/* 1624 */             return;
/*      */           }
/* 1626 */           if (ClientSessionFactoryImpl.isTrace)
/*      */           {
/* 1628 */             HornetQClientLogger.LOGGER.trace("Node " + topMessage.getNodeID() + " going up, connector = " + topMessage.getPair() + ", isLast=" + topMessage.isLast() + " csf created at\nserverLocator=" + ClientSessionFactoryImpl.this.serverLocator, ClientSessionFactoryImpl.this.e);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1637 */           Pair<TransportConfiguration, TransportConfiguration> transportConfig = topMessage.getPair();
/* 1638 */           if ((transportConfig.getA() == null) && (transportConfig.getB() == null))
/*      */           {
/* 1640 */             transportConfig = new Pair(ClientSessionFactoryImpl.Channel0Handler.this.conn.getTransportConnection().getConnectorConfig(), null);
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1645 */           ClientSessionFactoryImpl.this.serverLocator.notifyNodeUp(eventUID, topMessage.getNodeID(), nodeName, transportConfig, topMessage.isLast());
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   public class CloseRunnable implements Runnable
/*      */   {
/*      */     private final CoreRemotingConnection conn;
/*      */     
/*      */     private CloseRunnable(CoreRemotingConnection conn)
/*      */     {
/* 1657 */       this.conn = conn;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/* 1666 */         ClientSessionFactoryImpl.CLOSE_RUNNABLES.add(this);
/* 1667 */         this.conn.fail(HornetQClientMessageBundle.BUNDLE.disconnected());
/*      */       }
/*      */       finally
/*      */       {
/* 1671 */         ClientSessionFactoryImpl.CLOSE_RUNNABLES.remove(this);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public ClientSessionFactoryImpl stop()
/*      */     {
/* 1678 */       ClientSessionFactoryImpl.this.causeExit();
/* 1679 */       ClientSessionFactoryImpl.CLOSE_RUNNABLES.remove(this);
/* 1680 */       return ClientSessionFactoryImpl.this;
/*      */     }
/*      */   }
/*      */   
/*      */   private class DelegatingBufferHandler implements BufferHandler
/*      */   {
/*      */     private DelegatingBufferHandler() {}
/*      */     
/*      */     public void bufferReceived(Object connectionID, HornetQBuffer buffer) {
/* 1689 */       CoreRemotingConnection theConn = ClientSessionFactoryImpl.this.connection;
/*      */       
/* 1691 */       if ((theConn != null) && (connectionID == theConn.getID()))
/*      */       {
/* 1693 */         theConn.bufferReceived(connectionID, buffer);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final class DelegatingFailureListener implements FailureListener
/*      */   {
/*      */     private final Object connectionID;
/*      */     
/*      */     DelegatingFailureListener(Object connectionID)
/*      */     {
/* 1704 */       this.connectionID = connectionID;
/*      */     }
/*      */     
/*      */     public void connectionFailed(HornetQException me, boolean failedOver)
/*      */     {
/* 1709 */       ClientSessionFactoryImpl.this.handleConnectionFailure(this.connectionID, me);
/*      */     }
/*      */     
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1715 */       return DelegatingFailureListener.class.getSimpleName() + "('reconnectsOrFailover', hash=" + super.hashCode() + ")";
/*      */     }
/*      */   }
/*      */   
/*      */   private static final class ActualScheduledPinger
/*      */     implements Runnable
/*      */   {
/*      */     private final WeakReference<ClientSessionFactoryImpl.PingRunnable> pingRunnable;
/*      */     
/*      */     ActualScheduledPinger(ClientSessionFactoryImpl.PingRunnable runnable)
/*      */     {
/* 1726 */       this.pingRunnable = new WeakReference(runnable);
/*      */     }
/*      */     
/*      */     public void run()
/*      */     {
/* 1731 */       ClientSessionFactoryImpl.PingRunnable runnable = (ClientSessionFactoryImpl.PingRunnable)this.pingRunnable.get();
/*      */       
/* 1733 */       if (runnable != null)
/*      */       {
/* 1735 */         runnable.run();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private final class PingRunnable
/*      */     implements Runnable
/*      */   {
/*      */     private boolean cancelled;
/*      */     
/*      */     private boolean first;
/* 1747 */     private long lastCheck = System.currentTimeMillis();
/*      */     
/*      */     private PingRunnable() {}
/*      */     
/* 1751 */     public synchronized void run() { if ((this.cancelled) || ((ClientSessionFactoryImpl.this.stopPingingAfterOne) && (!this.first)))
/*      */       {
/* 1753 */         return;
/*      */       }
/*      */       
/* 1756 */       this.first = false;
/*      */       
/* 1758 */       long now = System.currentTimeMillis();
/*      */       
/* 1760 */       if ((ClientSessionFactoryImpl.this.clientFailureCheckPeriod != -1L) && (ClientSessionFactoryImpl.this.connectionTTL != -1L) && (now >= this.lastCheck + ClientSessionFactoryImpl.this.connectionTTL))
/*      */       {
/* 1762 */         if (!ClientSessionFactoryImpl.this.connection.checkDataReceived())
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/* 1767 */           final HornetQException me = HornetQClientMessageBundle.BUNDLE.connectionTimedOut(ClientSessionFactoryImpl.this.connection.getTransportConnection());
/*      */           
/* 1769 */           this.cancelled = true;
/*      */           
/* 1771 */           ClientSessionFactoryImpl.this.threadPool.execute(new Runnable()
/*      */           {
/*      */ 
/*      */             public void run()
/*      */             {
/* 1776 */               ClientSessionFactoryImpl.this.connection.fail(me);
/*      */             }
/*      */             
/* 1779 */           });
/* 1780 */           return;
/*      */         }
/*      */         
/*      */ 
/* 1784 */         this.lastCheck = now;
/*      */       }
/*      */       
/*      */ 
/* 1788 */       send();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void send()
/*      */     {
/* 1798 */       Ping ping = new Ping(ClientSessionFactoryImpl.this.connectionTTL);
/*      */       
/* 1800 */       Channel channel0 = ClientSessionFactoryImpl.this.connection.getChannel(0L, -1);
/*      */       
/* 1802 */       channel0.send(ping);
/*      */       
/* 1804 */       ClientSessionFactoryImpl.this.connection.flush();
/*      */     }
/*      */     
/*      */     public synchronized void cancel()
/*      */     {
/* 1809 */       this.cancelled = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1816 */     return "ClientSessionFactoryImpl [serverLocator=" + this.serverLocator + ", connectorConfig=" + this.connectorConfig + ", backupConfig=" + this.backupConfig + "]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setReconnectAttempts(int attempts)
/*      */   {
/* 1826 */     this.reconnectAttempts = attempts;
/*      */   }
/*      */   
/*      */   public Object getConnector()
/*      */   {
/* 1831 */     return this.connector;
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientSessionFactoryImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */