/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.Message;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ import org.hornetq.core.message.BodyEncoder;
/*     */ import org.hornetq.core.message.impl.MessageImpl;
/*     */ import org.hornetq.utils.TypedProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientMessageImpl
/*     */   extends MessageImpl
/*     */   implements ClientMessageInternal
/*     */ {
/*  41 */   public static final SimpleString REPLYTO_HEADER_NAME = new SimpleString("JMSReplyTo");
/*     */   
/*     */   private int deliveryCount;
/*     */   
/*     */   private ClientConsumerInternal consumer;
/*     */   
/*  47 */   private int flowControlSize = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private InputStream bodyInputStream;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientMessageImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientMessageImpl(byte type, boolean durable, long expiration, long timestamp, byte priority, int initialMessageBufferSize)
/*     */   {
/*  69 */     super(type, durable, expiration, timestamp, priority, initialMessageBufferSize);
/*     */   }
/*     */   
/*     */   public boolean isServerMessage()
/*     */   {
/*  74 */     return false;
/*     */   }
/*     */   
/*     */   public void onReceipt(ClientConsumerInternal consumer)
/*     */   {
/*  79 */     this.consumer = consumer;
/*     */   }
/*     */   
/*     */   public void setDeliveryCount(int deliveryCount)
/*     */   {
/*  84 */     this.deliveryCount = deliveryCount;
/*     */   }
/*     */   
/*     */   public int getDeliveryCount()
/*     */   {
/*  89 */     return this.deliveryCount;
/*     */   }
/*     */   
/*     */   public void acknowledge() throws HornetQException
/*     */   {
/*  94 */     if (this.consumer != null)
/*     */     {
/*  96 */       this.consumer.acknowledge(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void individualAcknowledge() throws HornetQException
/*     */   {
/* 102 */     if (this.consumer != null)
/*     */     {
/* 104 */       this.consumer.individualAcknowledge(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFlowControlSize()
/*     */   {
/* 110 */     if (this.flowControlSize < 0)
/*     */     {
/* 112 */       throw new IllegalStateException("Flow Control hasn't been set");
/*     */     }
/* 114 */     return this.flowControlSize;
/*     */   }
/*     */   
/*     */   public void setFlowControlSize(int flowControlSize)
/*     */   {
/* 119 */     this.flowControlSize = flowControlSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLargeMessage()
/*     */   {
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isCompressed()
/*     */   {
/* 132 */     return this.properties.getBooleanProperty(Message.HDR_LARGE_COMPRESSED).booleanValue();
/*     */   }
/*     */   
/*     */   public int getBodySize()
/*     */   {
/* 137 */     return this.buffer.writerIndex() - this.buffer.readerIndex();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 143 */     return "ClientMessage[messageID=" + this.messageID + ", durable=" + this.durable + ", address=" + getAddress() + ",userID=" + (getUserID() != null ? getUserID() : "null") + ",properties=" + this.properties.toString() + "]";
/*     */   }
/*     */   
/*     */   public void saveToOutputStream(OutputStream out)
/*     */     throws HornetQException
/*     */   {
/*     */     try
/*     */     {
/* 151 */       byte[] readBuffer = new byte[getBodySize()];
/* 152 */       getBodyBuffer().readBytes(readBuffer);
/* 153 */       out.write(readBuffer);
/* 154 */       out.flush();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 158 */       throw HornetQClientMessageBundle.BUNDLE.errorSavingBody(e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOutputStream(OutputStream out)
/*     */     throws HornetQException
/*     */   {
/* 165 */     saveToOutputStream(out);
/*     */   }
/*     */   
/*     */   public boolean waitOutputStreamCompletion(long timeMilliseconds)
/*     */     throws HornetQException
/*     */   {
/* 171 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void discardBody() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputStream getBodyInputStream()
/*     */   {
/* 184 */     return this.bodyInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBodyInputStream(InputStream bodyInputStream)
/*     */   {
/* 192 */     this.bodyInputStream = bodyInputStream;
/*     */   }
/*     */   
/*     */   public BodyEncoder getBodyEncoder()
/*     */     throws HornetQException
/*     */   {
/* 198 */     return new DecodingContext();
/*     */   }
/*     */   
/*     */ 
/*     */   private final class DecodingContext
/*     */     implements BodyEncoder
/*     */   {
/*     */     public DecodingContext() {}
/*     */     
/*     */     public void open()
/*     */     {
/* 209 */       ClientMessageImpl.this.getBodyBuffer().readerIndex(0);
/*     */     }
/*     */     
/*     */ 
/*     */     public void close() {}
/*     */     
/*     */ 
/*     */     public long getLargeBodySize()
/*     */     {
/* 218 */       if (ClientMessageImpl.this.isLargeMessage())
/*     */       {
/* 220 */         return ClientMessageImpl.this.getBodyBuffer().writerIndex();
/*     */       }
/*     */       
/*     */ 
/* 224 */       return ClientMessageImpl.this.getBodyBuffer().writerIndex() - 17;
/*     */     }
/*     */     
/*     */     public int encode(ByteBuffer bufferRead)
/*     */       throws HornetQException
/*     */     {
/* 230 */       HornetQBuffer buffer1 = HornetQBuffers.wrappedBuffer(bufferRead);
/* 231 */       return encode(buffer1, bufferRead.capacity());
/*     */     }
/*     */     
/*     */     public int encode(HornetQBuffer bufferOut, int size)
/*     */     {
/* 236 */       byte[] bytes = new byte[size];
/* 237 */       ClientMessageImpl.this.getWholeBuffer().readBytes(bytes);
/* 238 */       bufferOut.writeBytes(bytes, 0, size);
/* 239 */       return size;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientMessageImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */