package org.hornetq.core.client.impl;

import org.hornetq.api.core.HornetQException;

public abstract interface ClientProducerCredits
{
  public abstract void acquireCredits(int paramInt)
    throws InterruptedException, HornetQException;
  
  public abstract void receiveCredits(int paramInt);
  
  public abstract void receiveFailCredits(int paramInt);
  
  public abstract boolean isBlocked();
  
  public abstract void init();
  
  public abstract void reset();
  
  public abstract void close();
  
  public abstract void incrementRefCount();
  
  public abstract int decrementRefCount();
  
  public abstract void releaseOutstanding();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientProducerCredits.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */