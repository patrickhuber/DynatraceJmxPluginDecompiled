package org.hornetq.core.client.impl;

import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.TransportConfiguration;
import org.hornetq.api.core.client.ClientSessionFactory;
import org.hornetq.api.core.client.SessionFailureListener;

public abstract interface ClientSessionFactoryInternal
  extends ClientSessionFactory
{
  public abstract void causeExit();
  
  public abstract void addFailureListener(SessionFailureListener paramSessionFailureListener);
  
  public abstract boolean removeFailureListener(SessionFailureListener paramSessionFailureListener);
  
  public abstract void disableFinalizeCheck();
  
  public abstract int numConnections();
  
  public abstract int numSessions();
  
  public abstract void removeSession(ClientSessionInternal paramClientSessionInternal, boolean paramBoolean);
  
  public abstract void connect(int paramInt, boolean paramBoolean)
    throws HornetQException;
  
  public abstract void sendNodeAnnounce(long paramLong, String paramString1, String paramString2, boolean paramBoolean, TransportConfiguration paramTransportConfiguration1, TransportConfiguration paramTransportConfiguration2);
  
  public abstract TransportConfiguration getConnectorConfiguration();
  
  public abstract void setBackupConnector(TransportConfiguration paramTransportConfiguration1, TransportConfiguration paramTransportConfiguration2);
  
  public abstract Object getConnector();
  
  public abstract Object getBackupConnector();
  
  public abstract void setReconnectAttempts(int paramInt);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientSessionFactoryInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */