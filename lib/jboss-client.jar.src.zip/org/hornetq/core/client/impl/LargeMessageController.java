package org.hornetq.core.client.impl;

import java.io.OutputStream;
import org.hornetq.api.core.HornetQBuffer;
import org.hornetq.api.core.HornetQException;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;

public abstract interface LargeMessageController
  extends HornetQBuffer
{
  public abstract long getSize();
  
  public abstract void discardUnusedPackets();
  
  public abstract void close();
  
  public abstract void cancel();
  
  public abstract void setOutputStream(OutputStream paramOutputStream)
    throws HornetQException;
  
  public abstract void saveBuffer(OutputStream paramOutputStream)
    throws HornetQException;
  
  public abstract void addPacket(SessionReceiveContinuationMessage paramSessionReceiveContinuationMessage);
  
  public abstract boolean waitCompletion(long paramLong)
    throws HornetQException;
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\LargeMessageController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */