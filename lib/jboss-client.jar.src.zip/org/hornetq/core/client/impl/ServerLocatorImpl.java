/*      */ package org.hornetq.core.client.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ScheduledExecutorService;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.hornetq.api.core.BroadcastEndpointFactoryConfiguration;
/*      */ import org.hornetq.api.core.DiscoveryGroupConfiguration;
/*      */ import org.hornetq.api.core.HornetQException;
/*      */ import org.hornetq.api.core.HornetQExceptionType;
/*      */ import org.hornetq.api.core.HornetQIllegalStateException;
/*      */ import org.hornetq.api.core.HornetQInterruptedException;
/*      */ import org.hornetq.api.core.Interceptor;
/*      */ import org.hornetq.api.core.Pair;
/*      */ import org.hornetq.api.core.TransportConfiguration;
/*      */ import org.hornetq.api.core.client.ClientSessionFactory;
/*      */ import org.hornetq.api.core.client.ClusterTopologyListener;
/*      */ import org.hornetq.api.core.client.HornetQClient;
/*      */ import org.hornetq.api.core.client.TopologyMember;
/*      */ import org.hornetq.api.core.client.loadbalance.ConnectionLoadBalancingPolicy;
/*      */ import org.hornetq.core.client.HornetQClientLogger;
/*      */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*      */ import org.hornetq.core.cluster.DiscoveryEntry;
/*      */ import org.hornetq.core.cluster.DiscoveryGroup;
/*      */ import org.hornetq.core.cluster.DiscoveryListener;
/*      */ import org.hornetq.core.protocol.ClientPacketDecoder;
/*      */ import org.hornetq.core.protocol.core.CoreRemotingConnection;
/*      */ import org.hornetq.core.protocol.core.impl.PacketDecoder;
/*      */ import org.hornetq.core.remoting.FailureListener;
/*      */ import org.hornetq.spi.core.remoting.Connector;
/*      */ import org.hornetq.utils.ClassloadingUtil;
/*      */ import org.hornetq.utils.HornetQThreadFactory;
/*      */ import org.hornetq.utils.UUIDGenerator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ServerLocatorImpl
/*      */   implements ServerLocatorInternal, DiscoveryListener, Serializable
/*      */ {
/*   74 */   private final Set<ClusterTopologyListener> topologyListeners = new HashSet();
/*      */   private static final long serialVersionUID = -1615857864410205260L;
/*      */   private final boolean ha;
/*      */   
/*      */   private static enum STATE
/*      */   {
/*   80 */     INITIALIZED,  CLOSED,  CLOSING;
/*      */     
/*      */ 
/*      */     private STATE() {}
/*      */   }
/*      */   
/*      */ 
/*   87 */   private boolean finalizeCheck = true;
/*      */   
/*      */   private boolean clusterConnection;
/*      */   
/*      */   private transient String identity;
/*      */   
/*   93 */   private final Set<ClientSessionFactoryInternal> factories = new HashSet();
/*      */   
/*   95 */   private final Set<ClientSessionFactoryInternal> connectingFactories = new HashSet();
/*      */   
/*      */   private volatile TransportConfiguration[] initialConnectors;
/*      */   
/*      */   private final DiscoveryGroupConfiguration discoveryGroupConfiguration;
/*      */   
/*  101 */   private final StaticConnector staticConnector = new StaticConnector(null);
/*      */   
/*      */ 
/*      */   private final Topology topology;
/*      */   
/*  106 */   private String topologyArrayGuard = new String();
/*      */   
/*      */ 
/*      */   private volatile Pair<TransportConfiguration, TransportConfiguration>[] topologyArray;
/*      */   
/*      */ 
/*      */   private volatile boolean receivedTopology;
/*      */   
/*      */ 
/*      */   private boolean compressLargeMessage;
/*      */   
/*      */ 
/*      */   private transient boolean shutdownPool;
/*      */   
/*      */   private transient ExecutorService threadPool;
/*      */   
/*      */   private transient ScheduledExecutorService scheduledThreadPool;
/*      */   
/*      */   private transient DiscoveryGroup discoveryGroup;
/*      */   
/*      */   private transient ConnectionLoadBalancingPolicy loadBalancingPolicy;
/*      */   
/*      */   private boolean cacheLargeMessagesClient;
/*      */   
/*      */   private long clientFailureCheckPeriod;
/*      */   
/*      */   private long connectionTTL;
/*      */   
/*      */   private long callTimeout;
/*      */   
/*      */   private long callFailoverTimeout;
/*      */   
/*      */   private int minLargeMessageSize;
/*      */   
/*      */   private int consumerWindowSize;
/*      */   
/*      */   private int consumerMaxRate;
/*      */   
/*      */   private int confirmationWindowSize;
/*      */   
/*      */   private int producerWindowSize;
/*      */   
/*      */   private int producerMaxRate;
/*      */   
/*      */   private boolean blockOnAcknowledge;
/*      */   
/*      */   private boolean blockOnDurableSend;
/*      */   
/*      */   private boolean blockOnNonDurableSend;
/*      */   
/*      */   private boolean autoGroup;
/*      */   
/*      */   private boolean preAcknowledge;
/*      */   
/*      */   private String connectionLoadBalancingPolicyClassName;
/*      */   
/*      */   private int ackBatchSize;
/*      */   
/*      */   private boolean useGlobalPools;
/*      */   
/*      */   private int scheduledThreadPoolMaxSize;
/*      */   
/*      */   private int threadPoolMaxSize;
/*      */   
/*      */   private long retryInterval;
/*      */   
/*      */   private double retryIntervalMultiplier;
/*      */   
/*      */   private long maxRetryInterval;
/*      */   
/*      */   private int reconnectAttempts;
/*      */   
/*      */   private int initialConnectAttempts;
/*      */   
/*      */   private boolean failoverOnInitialConnection;
/*      */   
/*      */   private int initialMessagePacketSize;
/*      */   
/*  184 */   private String stateGuard = new String();
/*      */   
/*      */   private transient STATE state;
/*      */   private transient CountDownLatch latch;
/*  188 */   private final List<Interceptor> incomingInterceptors = new CopyOnWriteArrayList();
/*      */   
/*  190 */   private final List<Interceptor> outgoingInterceptors = new CopyOnWriteArrayList();
/*      */   
/*      */ 
/*      */ 
/*      */   private static ExecutorService globalThreadPool;
/*      */   
/*      */ 
/*      */ 
/*      */   private Executor startExecutor;
/*      */   
/*      */ 
/*      */   private static ScheduledExecutorService globalScheduledThreadPool;
/*      */   
/*      */ 
/*      */   private AfterConnectInternalListener afterConnectListener;
/*      */   
/*      */ 
/*      */   private String groupID;
/*      */   
/*      */ 
/*      */   private String nodeID;
/*      */   
/*      */ 
/*      */   private TransportConfiguration clusterTransportConfiguration;
/*      */   
/*      */ 
/*  216 */   private transient PacketDecoder packetDecoder = ClientPacketDecoder.INSTANCE;
/*      */   
/*  218 */   private final Exception traceException = new Exception();
/*      */   
/*      */ 
/*      */ 
/*  222 */   public static Runnable finalizeCallback = null;
/*      */   
/*      */ 
/*      */   public static synchronized void clearThreadPools()
/*      */   {
/*  227 */     if (globalThreadPool != null)
/*      */     {
/*  229 */       globalThreadPool.shutdown();
/*      */       try
/*      */       {
/*  232 */         if (!globalThreadPool.awaitTermination(10L, TimeUnit.SECONDS))
/*      */         {
/*  234 */           throw new IllegalStateException("Couldn't finish the globalThreadPool");
/*      */         }
/*      */       }
/*      */       catch (InterruptedException e)
/*      */       {
/*  239 */         throw new HornetQInterruptedException(e);
/*      */       }
/*      */       finally
/*      */       {
/*  243 */         globalThreadPool = null;
/*      */       }
/*      */     }
/*      */     
/*  247 */     if (globalScheduledThreadPool != null)
/*      */     {
/*  249 */       globalScheduledThreadPool.shutdown();
/*      */       try
/*      */       {
/*  252 */         if (!globalScheduledThreadPool.awaitTermination(10L, TimeUnit.SECONDS))
/*      */         {
/*  254 */           throw new IllegalStateException("Couldn't finish the globalScheduledThreadPool");
/*      */         }
/*      */       }
/*      */       catch (InterruptedException e)
/*      */       {
/*  259 */         throw new HornetQInterruptedException(e);
/*      */       }
/*      */       finally
/*      */       {
/*  263 */         globalScheduledThreadPool = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static synchronized ExecutorService getGlobalThreadPool()
/*      */   {
/*  270 */     if (globalThreadPool == null)
/*      */     {
/*  272 */       ThreadFactory factory = new HornetQThreadFactory("HornetQ-client-global-threads", true, getThisClassLoader());
/*      */       
/*  274 */       globalThreadPool = Executors.newCachedThreadPool(factory);
/*      */     }
/*      */     
/*  277 */     return globalThreadPool;
/*      */   }
/*      */   
/*      */   private static synchronized ScheduledExecutorService getGlobalScheduledThreadPool()
/*      */   {
/*  282 */     if (globalScheduledThreadPool == null)
/*      */     {
/*  284 */       ThreadFactory factory = new HornetQThreadFactory("HornetQ-client-global-scheduled-threads", true, getThisClassLoader());
/*      */       
/*      */ 
/*      */ 
/*  288 */       globalScheduledThreadPool = Executors.newScheduledThreadPool(5, factory);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  293 */     return globalScheduledThreadPool;
/*      */   }
/*      */   
/*      */   private synchronized void setThreadPools()
/*      */   {
/*  298 */     if (this.threadPool != null)
/*      */     {
/*  300 */       return;
/*      */     }
/*  302 */     if (this.useGlobalPools)
/*      */     {
/*  304 */       this.threadPool = getGlobalThreadPool();
/*      */       
/*  306 */       this.scheduledThreadPool = getGlobalScheduledThreadPool();
/*      */     }
/*      */     else
/*      */     {
/*  310 */       this.shutdownPool = true;
/*      */       
/*  312 */       ThreadFactory factory = new HornetQThreadFactory("HornetQ-client-factory-threads-" + System.identityHashCode(this), true, getThisClassLoader());
/*      */       
/*      */ 
/*      */ 
/*  316 */       if (this.threadPoolMaxSize == -1)
/*      */       {
/*  318 */         this.threadPool = Executors.newCachedThreadPool(factory);
/*      */       }
/*      */       else
/*      */       {
/*  322 */         this.threadPool = Executors.newFixedThreadPool(this.threadPoolMaxSize, factory);
/*      */       }
/*      */       
/*  325 */       factory = new HornetQThreadFactory("HornetQ-client-factory-pinger-threads-" + System.identityHashCode(this), true, getThisClassLoader());
/*      */       
/*      */ 
/*      */ 
/*  329 */       this.scheduledThreadPool = Executors.newScheduledThreadPool(this.scheduledThreadPoolMaxSize, factory);
/*      */     }
/*      */   }
/*      */   
/*      */   private static ClassLoader getThisClassLoader()
/*      */   {
/*  335 */     (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public ClassLoader run()
/*      */       {
/*  339 */         return ClientSessionFactoryImpl.class.getClassLoader();
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void instantiateLoadBalancingPolicy()
/*      */   {
/*  348 */     if (this.connectionLoadBalancingPolicyClassName == null)
/*      */     {
/*  350 */       throw new IllegalStateException("Please specify a load balancing policy class name on the session factory");
/*      */     }
/*  352 */     AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public Object run()
/*      */       {
/*  356 */         ServerLocatorImpl.this.loadBalancingPolicy = ((ConnectionLoadBalancingPolicy)ClassloadingUtil.newInstanceFromClassLoader(ServerLocatorImpl.this.connectionLoadBalancingPolicyClassName));
/*  357 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   private synchronized void initialise() throws HornetQException
/*      */   {
/*  364 */     if (this.state == STATE.INITIALIZED)
/*  365 */       return;
/*  366 */     synchronized (this.stateGuard)
/*      */     {
/*  368 */       if (this.state == STATE.CLOSING) {
/*  369 */         throw new HornetQIllegalStateException();
/*      */       }
/*      */       try {
/*  372 */         this.state = STATE.INITIALIZED;
/*  373 */         this.latch = new CountDownLatch(1);
/*      */         
/*  375 */         setThreadPools();
/*      */         
/*  377 */         instantiateLoadBalancingPolicy();
/*      */         
/*  379 */         if (this.discoveryGroupConfiguration != null)
/*      */         {
/*  381 */           this.discoveryGroup = createDiscoveryGroup(this.nodeID, this.discoveryGroupConfiguration);
/*      */           
/*  383 */           this.discoveryGroup.registerListener(this);
/*      */           
/*  385 */           this.discoveryGroup.start();
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  390 */         this.state = null;
/*  391 */         throw HornetQClientMessageBundle.BUNDLE.failedToInitialiseSessionFactory(e);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private static DiscoveryGroup createDiscoveryGroup(String nodeID, DiscoveryGroupConfiguration config) throws Exception
/*      */   {
/*  398 */     DiscoveryGroup group = new DiscoveryGroup(nodeID, config.getName(), config.getRefreshTimeout(), config.getBroadcastEndpointFactoryConfiguration().createBroadcastEndpointFactory(), null);
/*      */     
/*  400 */     return group;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ServerLocatorImpl(Topology topology, boolean useHA, DiscoveryGroupConfiguration discoveryGroupConfiguration, TransportConfiguration[] transportConfigs)
/*      */   {
/*  408 */     this.traceException.fillInStackTrace();
/*      */     
/*  410 */     this.topology = (topology == null ? new Topology(this) : topology);
/*      */     
/*  412 */     this.ha = useHA;
/*      */     
/*  414 */     this.discoveryGroupConfiguration = discoveryGroupConfiguration;
/*      */     
/*  416 */     this.initialConnectors = (transportConfigs != null ? transportConfigs : null);
/*      */     
/*  418 */     this.nodeID = UUIDGenerator.getInstance().generateStringUUID();
/*      */     
/*  420 */     this.clientFailureCheckPeriod = HornetQClient.DEFAULT_CLIENT_FAILURE_CHECK_PERIOD;
/*      */     
/*  422 */     this.connectionTTL = HornetQClient.DEFAULT_CONNECTION_TTL;
/*      */     
/*  424 */     this.callTimeout = 30000L;
/*      */     
/*  426 */     this.callFailoverTimeout = -1L;
/*      */     
/*  428 */     this.minLargeMessageSize = 102400;
/*      */     
/*  430 */     this.consumerWindowSize = 1048576;
/*      */     
/*  432 */     this.consumerMaxRate = -1;
/*      */     
/*  434 */     this.confirmationWindowSize = -1;
/*      */     
/*  436 */     this.producerWindowSize = 65536;
/*      */     
/*  438 */     this.producerMaxRate = -1;
/*      */     
/*  440 */     this.blockOnAcknowledge = false;
/*      */     
/*  442 */     this.blockOnDurableSend = true;
/*      */     
/*  444 */     this.blockOnNonDurableSend = false;
/*      */     
/*  446 */     this.autoGroup = false;
/*      */     
/*  448 */     this.preAcknowledge = false;
/*      */     
/*  450 */     this.ackBatchSize = 1048576;
/*      */     
/*  452 */     this.connectionLoadBalancingPolicyClassName = HornetQClient.DEFAULT_CONNECTION_LOAD_BALANCING_POLICY_CLASS_NAME;
/*      */     
/*  454 */     this.useGlobalPools = true;
/*      */     
/*  456 */     this.scheduledThreadPoolMaxSize = 5;
/*      */     
/*  458 */     this.threadPoolMaxSize = -1;
/*      */     
/*  460 */     this.retryInterval = 2000L;
/*      */     
/*  462 */     this.retryIntervalMultiplier = HornetQClient.DEFAULT_RETRY_INTERVAL_MULTIPLIER;
/*      */     
/*  464 */     this.maxRetryInterval = HornetQClient.DEFAULT_MAX_RETRY_INTERVAL;
/*      */     
/*  466 */     this.reconnectAttempts = 0;
/*      */     
/*  468 */     this.initialConnectAttempts = 1;
/*      */     
/*  470 */     this.failoverOnInitialConnection = false;
/*      */     
/*  472 */     this.cacheLargeMessagesClient = false;
/*      */     
/*  474 */     this.initialMessagePacketSize = 1500;
/*      */     
/*  476 */     this.cacheLargeMessagesClient = false;
/*      */     
/*  478 */     this.compressLargeMessage = false;
/*      */     
/*  480 */     this.clusterConnection = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServerLocatorImpl(boolean useHA, DiscoveryGroupConfiguration groupConfiguration)
/*      */   {
/*  488 */     this(new Topology(null), useHA, groupConfiguration, null);
/*  489 */     if (useHA)
/*      */     {
/*      */ 
/*      */ 
/*  493 */       this.topology.setOwner(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServerLocatorImpl(boolean useHA, TransportConfiguration... transportConfigs)
/*      */   {
/*  504 */     this(new Topology(null), useHA, null, transportConfigs);
/*  505 */     if (useHA)
/*      */     {
/*      */ 
/*      */ 
/*  509 */       this.topology.setOwner(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServerLocatorImpl(Topology topology, boolean useHA, DiscoveryGroupConfiguration groupConfiguration)
/*      */   {
/*  520 */     this(topology, useHA, groupConfiguration, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ServerLocatorImpl(Topology topology, boolean useHA, TransportConfiguration... transportConfigs)
/*      */   {
/*  532 */     this(topology, useHA, null, transportConfigs);
/*      */   }
/*      */   
/*      */   public void resetToInitialConnectors()
/*      */   {
/*  537 */     synchronized (this.topologyArrayGuard)
/*      */     {
/*  539 */       this.receivedTopology = false;
/*  540 */       this.topologyArray = null;
/*  541 */       this.topology.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   private ServerLocatorImpl(ServerLocatorImpl locator)
/*      */   {
/*  547 */     this.ha = locator.ha;
/*  548 */     this.finalizeCheck = locator.finalizeCheck;
/*  549 */     this.clusterConnection = locator.clusterConnection;
/*  550 */     this.initialConnectors = locator.initialConnectors;
/*  551 */     this.discoveryGroupConfiguration = locator.discoveryGroupConfiguration;
/*  552 */     this.topology = locator.topology;
/*  553 */     this.topologyArray = locator.topologyArray;
/*  554 */     this.receivedTopology = locator.receivedTopology;
/*  555 */     this.compressLargeMessage = locator.compressLargeMessage;
/*  556 */     this.cacheLargeMessagesClient = locator.cacheLargeMessagesClient;
/*  557 */     this.clientFailureCheckPeriod = locator.clientFailureCheckPeriod;
/*  558 */     this.connectionTTL = locator.connectionTTL;
/*  559 */     this.callTimeout = locator.callTimeout;
/*  560 */     this.callFailoverTimeout = locator.callFailoverTimeout;
/*  561 */     this.minLargeMessageSize = locator.minLargeMessageSize;
/*  562 */     this.consumerWindowSize = locator.consumerWindowSize;
/*  563 */     this.consumerMaxRate = locator.consumerMaxRate;
/*  564 */     this.confirmationWindowSize = locator.confirmationWindowSize;
/*  565 */     this.producerWindowSize = locator.producerWindowSize;
/*  566 */     this.producerMaxRate = locator.producerMaxRate;
/*  567 */     this.blockOnAcknowledge = locator.blockOnAcknowledge;
/*  568 */     this.blockOnDurableSend = locator.blockOnDurableSend;
/*  569 */     this.blockOnNonDurableSend = locator.blockOnNonDurableSend;
/*  570 */     this.autoGroup = locator.autoGroup;
/*  571 */     this.preAcknowledge = locator.preAcknowledge;
/*  572 */     this.connectionLoadBalancingPolicyClassName = locator.connectionLoadBalancingPolicyClassName;
/*  573 */     this.ackBatchSize = locator.ackBatchSize;
/*  574 */     this.useGlobalPools = locator.useGlobalPools;
/*  575 */     this.scheduledThreadPoolMaxSize = locator.scheduledThreadPoolMaxSize;
/*  576 */     this.threadPoolMaxSize = locator.threadPoolMaxSize;
/*  577 */     this.retryInterval = locator.retryInterval;
/*  578 */     this.retryIntervalMultiplier = locator.retryIntervalMultiplier;
/*  579 */     this.maxRetryInterval = locator.maxRetryInterval;
/*  580 */     this.reconnectAttempts = locator.reconnectAttempts;
/*  581 */     this.initialConnectAttempts = locator.initialConnectAttempts;
/*  582 */     this.failoverOnInitialConnection = locator.failoverOnInitialConnection;
/*  583 */     this.initialMessagePacketSize = locator.initialMessagePacketSize;
/*  584 */     this.startExecutor = locator.startExecutor;
/*  585 */     this.afterConnectListener = locator.afterConnectListener;
/*  586 */     this.groupID = locator.groupID;
/*  587 */     this.nodeID = locator.nodeID;
/*  588 */     this.clusterTransportConfiguration = locator.clusterTransportConfiguration;
/*      */   }
/*      */   
/*      */ 
/*      */   private synchronized TransportConfiguration selectConnector()
/*      */   {
/*      */     Pair<TransportConfiguration, TransportConfiguration>[] usedTopology;
/*  595 */     synchronized (this.topologyArrayGuard)
/*      */     {
/*  597 */       usedTopology = this.topologyArray;
/*      */     }
/*      */     
/*      */ 
/*  601 */     if (usedTopology != null)
/*      */     {
/*  603 */       int pos = this.loadBalancingPolicy.select(usedTopology.length);
/*  604 */       Pair<TransportConfiguration, TransportConfiguration> pair = usedTopology[pos];
/*      */       
/*  606 */       return (TransportConfiguration)pair.getA();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  612 */     int pos = this.loadBalancingPolicy.select(this.initialConnectors.length);
/*      */     
/*  614 */     return this.initialConnectors[pos];
/*      */   }
/*      */   
/*      */   public void start(Executor executor)
/*      */     throws Exception
/*      */   {
/*  620 */     initialise();
/*      */     
/*  622 */     this.startExecutor = executor;
/*      */     
/*  624 */     if (executor != null)
/*      */     {
/*  626 */       executor.execute(new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*      */           try
/*      */           {
/*  632 */             ServerLocatorImpl.this.connect();
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*  636 */             if (!ServerLocatorImpl.this.isClosed())
/*      */             {
/*  638 */               HornetQClientLogger.LOGGER.errorConnectingToNodes(e);
/*      */             }
/*      */           }
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */   public void disableFinalizeCheck()
/*      */   {
/*  648 */     this.finalizeCheck = false;
/*      */   }
/*      */   
/*      */   public ClientSessionFactoryInternal connect()
/*      */     throws HornetQException
/*      */   {
/*  654 */     return connect(false);
/*      */   }
/*      */   
/*      */   private ClientSessionFactoryInternal connect(boolean skipWarnings) throws HornetQException
/*      */   {
/*  659 */     synchronized (this)
/*      */     {
/*      */ 
/*  662 */       if ((getNumInitialConnectors() > 0) && (this.discoveryGroup == null))
/*      */       {
/*  664 */         ClientSessionFactoryInternal sf = (ClientSessionFactoryInternal)this.staticConnector.connect(skipWarnings);
/*  665 */         addFactory(sf);
/*  666 */         return sf;
/*      */       }
/*      */     }
/*      */     
/*  670 */     return (ClientSessionFactoryInternal)createSessionFactory();
/*      */   }
/*      */   
/*      */   public ClientSessionFactoryInternal connectNoWarnings()
/*      */     throws HornetQException
/*      */   {
/*  676 */     return connect(true);
/*      */   }
/*      */   
/*      */   public void setAfterConnectionInternalListener(AfterConnectInternalListener listener)
/*      */   {
/*  681 */     this.afterConnectListener = listener;
/*      */   }
/*      */   
/*      */   public AfterConnectInternalListener getAfterConnectInternalListener()
/*      */   {
/*  686 */     return this.afterConnectListener;
/*      */   }
/*      */   
/*      */   public ClientSessionFactory createSessionFactory(String nodeID) throws Exception
/*      */   {
/*  691 */     TopologyMember topologyMember = this.topology.getMember(nodeID);
/*      */     
/*  693 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/*  695 */       HornetQClientLogger.LOGGER.trace("Creating connection factory towards " + nodeID + " = " + topologyMember + ", topology=" + this.topology.describe());
/*      */     }
/*      */     
/*  698 */     if (topologyMember == null)
/*      */     {
/*  700 */       return null;
/*      */     }
/*  702 */     if (topologyMember.getLive() != null)
/*      */     {
/*  704 */       ClientSessionFactoryInternal factory = (ClientSessionFactoryInternal)createSessionFactory(topologyMember.getLive());
/*  705 */       if (topologyMember.getBackup() != null)
/*      */       {
/*  707 */         factory.setBackupConnector(topologyMember.getLive(), topologyMember.getBackup());
/*      */       }
/*  709 */       return factory;
/*      */     }
/*  711 */     if ((topologyMember.getLive() == null) && (topologyMember.getBackup() != null))
/*      */     {
/*      */ 
/*  714 */       ClientSessionFactoryInternal factory = (ClientSessionFactoryInternal)createSessionFactory(topologyMember.getBackup());
/*  715 */       return factory;
/*      */     }
/*      */     
/*  718 */     return null;
/*      */   }
/*      */   
/*      */   public ClientSessionFactory createSessionFactory(TransportConfiguration transportConfiguration) throws Exception
/*      */   {
/*  723 */     assertOpen();
/*      */     
/*  725 */     initialise();
/*      */     
/*  727 */     ClientSessionFactoryInternal factory = new ClientSessionFactoryImpl(this, transportConfiguration, this.callTimeout, this.callFailoverTimeout, this.clientFailureCheckPeriod, this.connectionTTL, this.retryInterval, this.retryIntervalMultiplier, this.maxRetryInterval, this.reconnectAttempts, this.threadPool, this.scheduledThreadPool, this.incomingInterceptors, this.outgoingInterceptors, this.packetDecoder);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  743 */     addToConnecting(factory);
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  748 */         factory.connect(this.reconnectAttempts, this.failoverOnInitialConnection);
/*      */ 
/*      */       }
/*      */       catch (HornetQException e1)
/*      */       {
/*  753 */         factory.close();
/*  754 */         throw e1;
/*      */       }
/*  756 */       addFactory(factory);
/*  757 */       return factory;
/*      */     }
/*      */     finally
/*      */     {
/*  761 */       removeFromConnecting(factory);
/*      */     }
/*      */   }
/*      */   
/*      */   public ClientSessionFactory createSessionFactory(TransportConfiguration transportConfiguration, int reconnectAttempts, boolean failoverOnInitialConnection) throws Exception
/*      */   {
/*  767 */     assertOpen();
/*      */     
/*  769 */     initialise();
/*      */     
/*  771 */     ClientSessionFactoryInternal factory = new ClientSessionFactoryImpl(this, transportConfiguration, this.callTimeout, this.callFailoverTimeout, this.clientFailureCheckPeriod, this.connectionTTL, this.retryInterval, this.retryIntervalMultiplier, this.maxRetryInterval, reconnectAttempts, this.threadPool, this.scheduledThreadPool, this.incomingInterceptors, this.outgoingInterceptors, this.packetDecoder);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  787 */     addToConnecting(factory);
/*      */     try
/*      */     {
/*      */       try
/*      */       {
/*  792 */         factory.connect(reconnectAttempts, failoverOnInitialConnection);
/*      */ 
/*      */       }
/*      */       catch (HornetQException e1)
/*      */       {
/*  797 */         factory.close();
/*  798 */         throw e1;
/*      */       }
/*  800 */       addFactory(factory);
/*  801 */       return factory;
/*      */     }
/*      */     finally
/*      */     {
/*  805 */       removeFromConnecting(factory);
/*      */     }
/*      */   }
/*      */   
/*      */   private void removeFromConnecting(ClientSessionFactoryInternal factory)
/*      */   {
/*  811 */     synchronized (this.connectingFactories)
/*      */     {
/*  813 */       this.connectingFactories.remove(factory);
/*      */     }
/*      */   }
/*      */   
/*      */   private void addToConnecting(ClientSessionFactoryInternal factory)
/*      */   {
/*  819 */     synchronized (this.connectingFactories)
/*      */     {
/*  821 */       assertOpen();
/*  822 */       this.connectingFactories.add(factory);
/*      */     }
/*      */   }
/*      */   
/*      */   public ClientSessionFactory createSessionFactory() throws HornetQException
/*      */   {
/*  828 */     assertOpen();
/*      */     
/*  830 */     initialise();
/*      */     
/*  832 */     if ((getNumInitialConnectors() == 0) && (this.discoveryGroup != null))
/*      */     {
/*      */ 
/*  835 */       long timeout = this.clusterConnection ? 0L : this.discoveryGroupConfiguration.getDiscoveryInitialWaitTimeout();
/*  836 */       boolean ok = this.discoveryGroup.waitForBroadcast(timeout);
/*      */       
/*  838 */       if (!ok)
/*      */       {
/*  840 */         throw HornetQClientMessageBundle.BUNDLE.connectionTimedOutInInitialBroadcast();
/*      */       }
/*      */     }
/*      */     
/*  844 */     ClientSessionFactoryInternal factory = null;
/*      */     
/*  846 */     synchronized (this)
/*      */     {
/*      */ 
/*  849 */       int attempts = 0;
/*      */       boolean retry;
/*      */       do {
/*  852 */         retry = false;
/*      */         
/*  854 */         TransportConfiguration tc = selectConnector();
/*  855 */         if (tc == null)
/*      */         {
/*  857 */           throw HornetQClientMessageBundle.BUNDLE.noTCForSessionFactory();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */         try
/*      */         {
/*  864 */           factory = new ClientSessionFactoryImpl(this, tc, this.callTimeout, this.callFailoverTimeout, this.clientFailureCheckPeriod, this.connectionTTL, this.retryInterval, this.retryIntervalMultiplier, this.maxRetryInterval, this.reconnectAttempts, this.threadPool, this.scheduledThreadPool, this.incomingInterceptors, this.outgoingInterceptors, this.packetDecoder);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           try
/*      */           {
/*  881 */             addToConnecting(factory);
/*  882 */             factory.connect(this.initialConnectAttempts, this.failoverOnInitialConnection);
/*      */           }
/*      */           finally
/*      */           {
/*  886 */             removeFromConnecting(factory);
/*      */           }
/*      */         }
/*      */         catch (HornetQException e)
/*      */         {
/*  891 */           factory.close();
/*  892 */           factory = null;
/*  893 */           if (e.getType() == HornetQExceptionType.NOT_CONNECTED)
/*      */           {
/*  895 */             attempts++;
/*      */             
/*  897 */             synchronized (this.topologyArrayGuard)
/*      */             {
/*      */ 
/*  900 */               if ((this.topologyArray != null) && (attempts == this.topologyArray.length))
/*      */               {
/*  902 */                 throw HornetQClientMessageBundle.BUNDLE.cannotConnectToServers();
/*      */               }
/*  904 */               if ((this.topologyArray == null) && (attempts == getNumInitialConnectors()))
/*      */               {
/*  906 */                 throw HornetQClientMessageBundle.BUNDLE.cannotConnectToServers();
/*      */               }
/*      */             }
/*  909 */             retry = true;
/*      */           }
/*      */           else
/*      */           {
/*  913 */             throw e;
/*      */           }
/*      */           
/*      */         }
/*  917 */       } while (retry);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  922 */       long timeout = System.currentTimeMillis() + this.callTimeout;
/*  923 */       while ((!isClosed()) && (!this.receivedTopology) && (timeout > System.currentTimeMillis()))
/*      */       {
/*      */         try
/*      */         {
/*      */ 
/*  928 */           wait(1000L);
/*      */         }
/*      */         catch (InterruptedException e)
/*      */         {
/*  932 */           throw new HornetQInterruptedException(e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  942 */       boolean hasTimedOut = timeout > System.currentTimeMillis();
/*  943 */       if ((!hasTimedOut) && (!this.receivedTopology))
/*      */       {
/*  945 */         if (factory != null)
/*  946 */           factory.cleanup();
/*  947 */         throw HornetQClientMessageBundle.BUNDLE.connectionTimedOutOnReceiveTopology(this.discoveryGroup);
/*      */       }
/*      */       
/*  950 */       addFactory(factory);
/*      */       
/*  952 */       return factory;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isHA()
/*      */   {
/*  959 */     return this.ha;
/*      */   }
/*      */   
/*      */   public boolean isCacheLargeMessagesClient()
/*      */   {
/*  964 */     return this.cacheLargeMessagesClient;
/*      */   }
/*      */   
/*      */   public void setCacheLargeMessagesClient(boolean cached)
/*      */   {
/*  969 */     this.cacheLargeMessagesClient = cached;
/*      */   }
/*      */   
/*      */   public long getClientFailureCheckPeriod()
/*      */   {
/*  974 */     return this.clientFailureCheckPeriod;
/*      */   }
/*      */   
/*      */   public void setClientFailureCheckPeriod(long clientFailureCheckPeriod)
/*      */   {
/*  979 */     checkWrite();
/*  980 */     this.clientFailureCheckPeriod = clientFailureCheckPeriod;
/*      */   }
/*      */   
/*      */   public long getConnectionTTL()
/*      */   {
/*  985 */     return this.connectionTTL;
/*      */   }
/*      */   
/*      */   public void setConnectionTTL(long connectionTTL)
/*      */   {
/*  990 */     checkWrite();
/*  991 */     this.connectionTTL = connectionTTL;
/*      */   }
/*      */   
/*      */   public long getCallTimeout()
/*      */   {
/*  996 */     return this.callTimeout;
/*      */   }
/*      */   
/*      */   public void setCallTimeout(long callTimeout)
/*      */   {
/* 1001 */     checkWrite();
/* 1002 */     this.callTimeout = callTimeout;
/*      */   }
/*      */   
/*      */   public long getCallFailoverTimeout()
/*      */   {
/* 1007 */     return this.callFailoverTimeout;
/*      */   }
/*      */   
/*      */   public void setCallFailoverTimeout(long callFailoverTimeout)
/*      */   {
/* 1012 */     checkWrite();
/* 1013 */     this.callFailoverTimeout = callFailoverTimeout;
/*      */   }
/*      */   
/*      */   public int getMinLargeMessageSize()
/*      */   {
/* 1018 */     return this.minLargeMessageSize;
/*      */   }
/*      */   
/*      */   public void setMinLargeMessageSize(int minLargeMessageSize)
/*      */   {
/* 1023 */     checkWrite();
/* 1024 */     this.minLargeMessageSize = minLargeMessageSize;
/*      */   }
/*      */   
/*      */   public int getConsumerWindowSize()
/*      */   {
/* 1029 */     return this.consumerWindowSize;
/*      */   }
/*      */   
/*      */   public void setConsumerWindowSize(int consumerWindowSize)
/*      */   {
/* 1034 */     checkWrite();
/* 1035 */     this.consumerWindowSize = consumerWindowSize;
/*      */   }
/*      */   
/*      */   public int getConsumerMaxRate()
/*      */   {
/* 1040 */     return this.consumerMaxRate;
/*      */   }
/*      */   
/*      */   public void setConsumerMaxRate(int consumerMaxRate)
/*      */   {
/* 1045 */     checkWrite();
/* 1046 */     this.consumerMaxRate = consumerMaxRate;
/*      */   }
/*      */   
/*      */   public int getConfirmationWindowSize()
/*      */   {
/* 1051 */     return this.confirmationWindowSize;
/*      */   }
/*      */   
/*      */   public void setConfirmationWindowSize(int confirmationWindowSize)
/*      */   {
/* 1056 */     checkWrite();
/* 1057 */     this.confirmationWindowSize = confirmationWindowSize;
/*      */   }
/*      */   
/*      */   public int getProducerWindowSize()
/*      */   {
/* 1062 */     return this.producerWindowSize;
/*      */   }
/*      */   
/*      */   public void setProducerWindowSize(int producerWindowSize)
/*      */   {
/* 1067 */     checkWrite();
/* 1068 */     this.producerWindowSize = producerWindowSize;
/*      */   }
/*      */   
/*      */   public int getProducerMaxRate()
/*      */   {
/* 1073 */     return this.producerMaxRate;
/*      */   }
/*      */   
/*      */   public void setProducerMaxRate(int producerMaxRate)
/*      */   {
/* 1078 */     checkWrite();
/* 1079 */     this.producerMaxRate = producerMaxRate;
/*      */   }
/*      */   
/*      */   public boolean isBlockOnAcknowledge()
/*      */   {
/* 1084 */     return this.blockOnAcknowledge;
/*      */   }
/*      */   
/*      */   public void setBlockOnAcknowledge(boolean blockOnAcknowledge)
/*      */   {
/* 1089 */     checkWrite();
/* 1090 */     this.blockOnAcknowledge = blockOnAcknowledge;
/*      */   }
/*      */   
/*      */   public boolean isBlockOnDurableSend()
/*      */   {
/* 1095 */     return this.blockOnDurableSend;
/*      */   }
/*      */   
/*      */   public void setBlockOnDurableSend(boolean blockOnDurableSend)
/*      */   {
/* 1100 */     checkWrite();
/* 1101 */     this.blockOnDurableSend = blockOnDurableSend;
/*      */   }
/*      */   
/*      */   public boolean isBlockOnNonDurableSend()
/*      */   {
/* 1106 */     return this.blockOnNonDurableSend;
/*      */   }
/*      */   
/*      */   public void setBlockOnNonDurableSend(boolean blockOnNonDurableSend)
/*      */   {
/* 1111 */     checkWrite();
/* 1112 */     this.blockOnNonDurableSend = blockOnNonDurableSend;
/*      */   }
/*      */   
/*      */   public boolean isAutoGroup()
/*      */   {
/* 1117 */     return this.autoGroup;
/*      */   }
/*      */   
/*      */   public void setAutoGroup(boolean autoGroup)
/*      */   {
/* 1122 */     checkWrite();
/* 1123 */     this.autoGroup = autoGroup;
/*      */   }
/*      */   
/*      */   public boolean isPreAcknowledge()
/*      */   {
/* 1128 */     return this.preAcknowledge;
/*      */   }
/*      */   
/*      */   public void setPreAcknowledge(boolean preAcknowledge)
/*      */   {
/* 1133 */     checkWrite();
/* 1134 */     this.preAcknowledge = preAcknowledge;
/*      */   }
/*      */   
/*      */   public int getAckBatchSize()
/*      */   {
/* 1139 */     return this.ackBatchSize;
/*      */   }
/*      */   
/*      */   public void setAckBatchSize(int ackBatchSize)
/*      */   {
/* 1144 */     checkWrite();
/* 1145 */     this.ackBatchSize = ackBatchSize;
/*      */   }
/*      */   
/*      */   public boolean isUseGlobalPools()
/*      */   {
/* 1150 */     return this.useGlobalPools;
/*      */   }
/*      */   
/*      */   public void setUseGlobalPools(boolean useGlobalPools)
/*      */   {
/* 1155 */     checkWrite();
/* 1156 */     this.useGlobalPools = useGlobalPools;
/*      */   }
/*      */   
/*      */   public int getScheduledThreadPoolMaxSize()
/*      */   {
/* 1161 */     return this.scheduledThreadPoolMaxSize;
/*      */   }
/*      */   
/*      */   public void setScheduledThreadPoolMaxSize(int scheduledThreadPoolMaxSize)
/*      */   {
/* 1166 */     checkWrite();
/* 1167 */     this.scheduledThreadPoolMaxSize = scheduledThreadPoolMaxSize;
/*      */   }
/*      */   
/*      */   public int getThreadPoolMaxSize()
/*      */   {
/* 1172 */     return this.threadPoolMaxSize;
/*      */   }
/*      */   
/*      */   public void setThreadPoolMaxSize(int threadPoolMaxSize)
/*      */   {
/* 1177 */     checkWrite();
/* 1178 */     this.threadPoolMaxSize = threadPoolMaxSize;
/*      */   }
/*      */   
/*      */   public long getRetryInterval()
/*      */   {
/* 1183 */     return this.retryInterval;
/*      */   }
/*      */   
/*      */   public void setRetryInterval(long retryInterval)
/*      */   {
/* 1188 */     checkWrite();
/* 1189 */     this.retryInterval = retryInterval;
/*      */   }
/*      */   
/*      */   public long getMaxRetryInterval()
/*      */   {
/* 1194 */     return this.maxRetryInterval;
/*      */   }
/*      */   
/*      */   public void setMaxRetryInterval(long retryInterval)
/*      */   {
/* 1199 */     checkWrite();
/* 1200 */     this.maxRetryInterval = retryInterval;
/*      */   }
/*      */   
/*      */   public double getRetryIntervalMultiplier()
/*      */   {
/* 1205 */     return this.retryIntervalMultiplier;
/*      */   }
/*      */   
/*      */   public void setRetryIntervalMultiplier(double retryIntervalMultiplier)
/*      */   {
/* 1210 */     checkWrite();
/* 1211 */     this.retryIntervalMultiplier = retryIntervalMultiplier;
/*      */   }
/*      */   
/*      */   public int getReconnectAttempts()
/*      */   {
/* 1216 */     return this.reconnectAttempts;
/*      */   }
/*      */   
/*      */   public void setReconnectAttempts(int reconnectAttempts)
/*      */   {
/* 1221 */     checkWrite();
/* 1222 */     this.reconnectAttempts = reconnectAttempts;
/*      */   }
/*      */   
/*      */   public void setInitialConnectAttempts(int initialConnectAttempts)
/*      */   {
/* 1227 */     checkWrite();
/* 1228 */     this.initialConnectAttempts = initialConnectAttempts;
/*      */   }
/*      */   
/*      */   public int getInitialConnectAttempts()
/*      */   {
/* 1233 */     return this.initialConnectAttempts;
/*      */   }
/*      */   
/*      */   public boolean isFailoverOnInitialConnection()
/*      */   {
/* 1238 */     return this.failoverOnInitialConnection;
/*      */   }
/*      */   
/*      */   public void setFailoverOnInitialConnection(boolean failover)
/*      */   {
/* 1243 */     checkWrite();
/* 1244 */     this.failoverOnInitialConnection = failover;
/*      */   }
/*      */   
/*      */   public String getConnectionLoadBalancingPolicyClassName()
/*      */   {
/* 1249 */     return this.connectionLoadBalancingPolicyClassName;
/*      */   }
/*      */   
/*      */   public void setConnectionLoadBalancingPolicyClassName(String loadBalancingPolicyClassName)
/*      */   {
/* 1254 */     checkWrite();
/* 1255 */     this.connectionLoadBalancingPolicyClassName = loadBalancingPolicyClassName;
/*      */   }
/*      */   
/*      */   public TransportConfiguration[] getStaticTransportConfigurations()
/*      */   {
/* 1260 */     if (this.initialConnectors == null) return new TransportConfiguration[0];
/* 1261 */     return (TransportConfiguration[])Arrays.copyOf(this.initialConnectors, this.initialConnectors.length);
/*      */   }
/*      */   
/*      */   public DiscoveryGroupConfiguration getDiscoveryGroupConfiguration()
/*      */   {
/* 1266 */     return this.discoveryGroupConfiguration;
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public void addInterceptor(Interceptor interceptor)
/*      */   {
/* 1273 */     addIncomingInterceptor(interceptor);
/*      */   }
/*      */   
/*      */   public void addIncomingInterceptor(Interceptor interceptor)
/*      */   {
/* 1278 */     this.incomingInterceptors.add(interceptor);
/*      */   }
/*      */   
/*      */   public void addOutgoingInterceptor(Interceptor interceptor)
/*      */   {
/* 1283 */     this.outgoingInterceptors.add(interceptor);
/*      */   }
/*      */   
/*      */ 
/*      */   @Deprecated
/*      */   public boolean removeInterceptor(Interceptor interceptor)
/*      */   {
/* 1290 */     return removeIncomingInterceptor(interceptor);
/*      */   }
/*      */   
/*      */   public boolean removeIncomingInterceptor(Interceptor interceptor)
/*      */   {
/* 1295 */     return this.incomingInterceptors.remove(interceptor);
/*      */   }
/*      */   
/*      */   public boolean removeOutgoingInterceptor(Interceptor interceptor)
/*      */   {
/* 1300 */     return this.outgoingInterceptors.remove(interceptor);
/*      */   }
/*      */   
/*      */   public int getInitialMessagePacketSize()
/*      */   {
/* 1305 */     return this.initialMessagePacketSize;
/*      */   }
/*      */   
/*      */   public void setInitialMessagePacketSize(int size)
/*      */   {
/* 1310 */     checkWrite();
/* 1311 */     this.initialMessagePacketSize = size;
/*      */   }
/*      */   
/*      */   public void setGroupID(String groupID)
/*      */   {
/* 1316 */     checkWrite();
/* 1317 */     this.groupID = groupID;
/*      */   }
/*      */   
/*      */   public String getGroupID()
/*      */   {
/* 1322 */     return this.groupID;
/*      */   }
/*      */   
/*      */   public boolean isCompressLargeMessage()
/*      */   {
/* 1327 */     return this.compressLargeMessage;
/*      */   }
/*      */   
/*      */   public void setCompressLargeMessage(boolean avoid)
/*      */   {
/* 1332 */     this.compressLargeMessage = avoid;
/*      */   }
/*      */   
/*      */   private void checkWrite()
/*      */   {
/* 1337 */     synchronized (this.stateGuard)
/*      */     {
/* 1339 */       if ((this.state != null) && (this.state != STATE.CLOSED))
/*      */       {
/* 1341 */         throw new IllegalStateException("Cannot set attribute on SessionFactory after it has been used");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private int getNumInitialConnectors()
/*      */   {
/* 1348 */     if (this.initialConnectors == null) return 0;
/* 1349 */     return this.initialConnectors.length;
/*      */   }
/*      */   
/*      */   public void setIdentity(String identity)
/*      */   {
/* 1354 */     this.identity = identity;
/*      */   }
/*      */   
/*      */   public void setNodeID(String nodeID)
/*      */   {
/* 1359 */     this.nodeID = nodeID;
/*      */   }
/*      */   
/*      */   public String getNodeID()
/*      */   {
/* 1364 */     return this.nodeID;
/*      */   }
/*      */   
/*      */   public void setClusterConnection(boolean clusterConnection)
/*      */   {
/* 1369 */     this.clusterConnection = clusterConnection;
/*      */   }
/*      */   
/*      */   public boolean isClusterConnection()
/*      */   {
/* 1374 */     return this.clusterConnection;
/*      */   }
/*      */   
/*      */   public TransportConfiguration getClusterTransportConfiguration()
/*      */   {
/* 1379 */     return this.clusterTransportConfiguration;
/*      */   }
/*      */   
/*      */   public void setClusterTransportConfiguration(TransportConfiguration tc)
/*      */   {
/* 1384 */     this.clusterTransportConfiguration = tc;
/*      */   }
/*      */   
/*      */   protected void finalize()
/*      */     throws Throwable
/*      */   {
/* 1390 */     if (this.finalizeCheck)
/*      */     {
/* 1392 */       close();
/*      */     }
/*      */     
/* 1395 */     super.finalize();
/*      */   }
/*      */   
/*      */   public void cleanup()
/*      */   {
/* 1400 */     doClose(false);
/*      */   }
/*      */   
/*      */   public void close()
/*      */   {
/* 1405 */     doClose(true);
/*      */   }
/*      */   
/*      */   private void doClose(boolean sendClose)
/*      */   {
/* 1410 */     synchronized (this.stateGuard)
/*      */     {
/* 1412 */       if (this.state == STATE.CLOSED)
/*      */       {
/* 1414 */         if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */         {
/* 1416 */           HornetQClientLogger.LOGGER.debug(this + " is already closed when calling closed");
/*      */         }
/* 1418 */         return;
/*      */       }
/*      */       
/* 1421 */       this.state = STATE.CLOSING;
/*      */     }
/* 1423 */     if (this.latch != null) {
/* 1424 */       this.latch.countDown();
/*      */     }
/* 1426 */     synchronized (this.connectingFactories)
/*      */     {
/* 1428 */       for (ClientSessionFactoryInternal csf : this.connectingFactories)
/*      */       {
/* 1430 */         csf.causeExit();
/*      */       }
/*      */     }
/*      */     
/* 1434 */     if (this.discoveryGroup != null)
/*      */     {
/* 1436 */       synchronized (this)
/*      */       {
/*      */         try
/*      */         {
/* 1440 */           this.discoveryGroup.stop();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1444 */           HornetQClientLogger.LOGGER.failedToStopDiscovery(e);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */     } else {
/* 1450 */       this.staticConnector.disconnect();
/*      */     }
/*      */     
/* 1453 */     synchronized (this.connectingFactories)
/*      */     {
/* 1455 */       for (ClientSessionFactoryInternal csf : this.connectingFactories)
/*      */       {
/* 1457 */         csf.causeExit();
/*      */       }
/* 1459 */       for (ClientSessionFactoryInternal csf : this.connectingFactories)
/*      */       {
/* 1461 */         csf.close();
/*      */       }
/* 1463 */       this.connectingFactories.clear();
/*      */     }
/*      */     
/*      */     Set<ClientSessionFactoryInternal> clonedFactory;
/* 1467 */     synchronized (this.factories)
/*      */     {
/* 1469 */       clonedFactory = new HashSet(this.factories);
/*      */       
/* 1471 */       this.factories.clear();
/*      */     }
/*      */     
/* 1474 */     for (ClientSessionFactoryInternal factory : clonedFactory)
/*      */     {
/* 1476 */       factory.causeExit();
/*      */     }
/* 1478 */     for (ClientSessionFactory factory : clonedFactory)
/*      */     {
/* 1480 */       if (sendClose)
/*      */       {
/* 1482 */         factory.close();
/*      */       }
/*      */       else
/*      */       {
/* 1486 */         factory.cleanup();
/*      */       }
/*      */     }
/*      */     
/* 1490 */     if (this.shutdownPool)
/*      */     {
/* 1492 */       if (this.threadPool != null)
/*      */       {
/* 1494 */         this.threadPool.shutdown();
/*      */         
/*      */         try
/*      */         {
/* 1498 */           if (!this.threadPool.awaitTermination(10000L, TimeUnit.MILLISECONDS))
/*      */           {
/* 1500 */             HornetQClientLogger.LOGGER.timedOutWaitingForTermination();
/*      */           }
/*      */         }
/*      */         catch (InterruptedException e)
/*      */         {
/* 1505 */           throw new HornetQInterruptedException(e);
/*      */         }
/*      */       }
/*      */       
/* 1509 */       if (this.scheduledThreadPool != null)
/*      */       {
/* 1511 */         this.scheduledThreadPool.shutdown();
/*      */         
/*      */         try
/*      */         {
/* 1515 */           if (!this.scheduledThreadPool.awaitTermination(10000L, TimeUnit.MILLISECONDS))
/*      */           {
/* 1517 */             HornetQClientLogger.LOGGER.timedOutWaitingForScheduledPoolTermination();
/*      */           }
/*      */         }
/*      */         catch (InterruptedException e)
/*      */         {
/* 1522 */           throw new HornetQInterruptedException(e);
/*      */         }
/*      */       }
/*      */     }
/* 1526 */     synchronized (this.stateGuard)
/*      */     {
/* 1528 */       this.state = STATE.CLOSED;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyNodeDown(long eventTime, String nodeID)
/*      */   {
/* 1540 */     if (!this.ha)
/*      */     {
/*      */ 
/* 1543 */       return;
/*      */     }
/*      */     
/* 1546 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1548 */       HornetQClientLogger.LOGGER.trace("nodeDown " + this + " nodeID=" + nodeID + " as being down", new Exception("trace"));
/*      */     }
/*      */     
/* 1551 */     this.topology.removeMember(eventTime, nodeID);
/*      */     
/* 1553 */     if (this.clusterConnection)
/*      */     {
/* 1555 */       updateArraysAndPairs();
/*      */     }
/*      */     else
/*      */     {
/* 1559 */       synchronized (this.topologyArrayGuard)
/*      */       {
/* 1561 */         if (this.topology.isEmpty())
/*      */         {
/*      */ 
/* 1564 */           this.receivedTopology = false;
/* 1565 */           this.topologyArray = null;
/*      */         }
/*      */         else
/*      */         {
/* 1569 */           updateArraysAndPairs();
/*      */           
/* 1571 */           if ((this.topology.nodes() == 1) && (this.topology.getMember(this.nodeID) != null))
/*      */           {
/*      */ 
/* 1574 */             this.receivedTopology = false;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyNodeUp(long uniqueEventID, String nodeID, String nodeName, Pair<TransportConfiguration, TransportConfiguration> connectorPair, boolean last)
/*      */   {
/* 1588 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1590 */       HornetQClientLogger.LOGGER.trace("NodeUp " + this + "::nodeID=" + nodeID + ", connectorPair=" + connectorPair, new Exception("trace"));
/*      */     }
/*      */     
/* 1593 */     TopologyMemberImpl member = new TopologyMemberImpl(nodeID, nodeName, (TransportConfiguration)connectorPair.getA(), (TransportConfiguration)connectorPair.getB());
/*      */     
/* 1595 */     this.topology.updateMember(uniqueEventID, nodeID, member);
/*      */     
/* 1597 */     TopologyMember actMember = this.topology.getMember(nodeID);
/*      */     
/* 1599 */     if ((actMember != null) && (actMember.getLive() != null) && (actMember.getBackup() != null))
/*      */     {
/* 1601 */       HashSet<ClientSessionFactory> clonedFactories = new HashSet();
/* 1602 */       synchronized (this.factories)
/*      */       {
/* 1604 */         clonedFactories.addAll(this.factories);
/*      */       }
/*      */       
/* 1607 */       for (ClientSessionFactory factory : clonedFactories)
/*      */       {
/* 1609 */         ((ClientSessionFactoryInternal)factory).setBackupConnector(actMember.getLive(), actMember.getBackup());
/*      */       }
/*      */     }
/*      */     
/* 1613 */     updateArraysAndPairs();
/*      */     
/* 1615 */     if (last)
/*      */     {
/* 1617 */       synchronized (this)
/*      */       {
/* 1619 */         this.receivedTopology = true;
/*      */         
/* 1621 */         notifyAll();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1629 */     if (this.identity != null)
/*      */     {
/* 1631 */       return "ServerLocatorImpl (identity=" + this.identity + ") [initialConnectors=" + Arrays.toString(this.initialConnectors == null ? new TransportConfiguration[0] : this.initialConnectors) + ", discoveryGroupConfiguration=" + this.discoveryGroupConfiguration + "]";
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1638 */     return "ServerLocatorImpl [initialConnectors=" + Arrays.toString(this.initialConnectors == null ? new TransportConfiguration[0] : this.initialConnectors) + ", discoveryGroupConfiguration=" + this.discoveryGroupConfiguration + "]";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void updateArraysAndPairs()
/*      */   {
/* 1647 */     synchronized (this.topologyArrayGuard)
/*      */     {
/* 1649 */       Collection<TopologyMemberImpl> membersCopy = this.topology.getMembers();
/*      */       
/* 1651 */       Pair<TransportConfiguration, TransportConfiguration>[] topologyArrayLocal = (Pair[])Array.newInstance(Pair.class, membersCopy.size());
/*      */       
/*      */ 
/*      */ 
/* 1655 */       int count = 0;
/* 1656 */       for (TopologyMemberImpl pair : membersCopy)
/*      */       {
/* 1658 */         topologyArrayLocal[(count++)] = pair.getConnector();
/*      */       }
/*      */       
/* 1661 */       this.topologyArray = topologyArrayLocal;
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void connectorsChanged(List<DiscoveryEntry> newConnectors)
/*      */   {
/* 1667 */     if (this.receivedTopology)
/*      */     {
/* 1669 */       return;
/*      */     }
/* 1671 */     TransportConfiguration[] newInitialconnectors = (TransportConfiguration[])Array.newInstance(TransportConfiguration.class, newConnectors.size());
/*      */     
/*      */ 
/* 1674 */     int count = 0;
/* 1675 */     for (DiscoveryEntry entry : newConnectors)
/*      */     {
/* 1677 */       newInitialconnectors[(count++)] = entry.getConnector();
/*      */       
/* 1679 */       if ((this.ha) && (this.topology.getMember(entry.getNodeID()) == null))
/*      */       {
/* 1681 */         TopologyMemberImpl member = new TopologyMemberImpl(entry.getNodeID(), null, entry.getConnector(), null);
/*      */         
/* 1683 */         this.topology.updateMember(0L, entry.getNodeID(), member);
/*      */       }
/*      */     }
/*      */     
/* 1687 */     this.initialConnectors = (newInitialconnectors.length == 0 ? null : newInitialconnectors);
/*      */     
/* 1689 */     if ((this.clusterConnection) && (!this.receivedTopology) && (getNumInitialConnectors() > 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1694 */       Runnable connectRunnable = new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*      */           try
/*      */           {
/* 1700 */             ServerLocatorImpl.this.connect();
/*      */           }
/*      */           catch (HornetQException e)
/*      */           {
/* 1704 */             HornetQClientLogger.LOGGER.errorConnectingToNodes(e);
/*      */           }
/*      */         }
/*      */       };
/* 1708 */       if (this.startExecutor != null)
/*      */       {
/* 1710 */         this.startExecutor.execute(connectRunnable);
/*      */       }
/*      */       else
/*      */       {
/* 1714 */         connectRunnable.run();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void factoryClosed(ClientSessionFactory factory)
/*      */   {
/* 1721 */     synchronized (this.factories)
/*      */     {
/* 1723 */       this.factories.remove(factory);
/*      */       
/* 1725 */       if ((!this.clusterConnection) && (this.factories.isEmpty()))
/*      */       {
/*      */ 
/* 1728 */         synchronized (this.topologyArrayGuard)
/*      */         {
/* 1730 */           this.receivedTopology = false;
/*      */           
/* 1732 */           this.topologyArray = null;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Topology getTopology()
/*      */   {
/* 1740 */     return this.topology;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setPacketDecoder(PacketDecoder packetDecoder)
/*      */   {
/* 1746 */     this.packetDecoder = packetDecoder;
/*      */   }
/*      */   
/*      */   public void addClusterTopologyListener(ClusterTopologyListener listener)
/*      */   {
/* 1751 */     this.topology.addClusterTopologyListener(listener);
/*      */   }
/*      */   
/*      */   public void removeClusterTopologyListener(ClusterTopologyListener listener)
/*      */   {
/* 1756 */     this.topology.removeClusterTopologyListener(listener);
/*      */   }
/*      */   
/*      */   private void addFactory(ClientSessionFactoryInternal factory)
/*      */   {
/* 1761 */     if (factory == null)
/*      */     {
/* 1763 */       return;
/*      */     }
/*      */     
/* 1766 */     if (isClosed())
/*      */     {
/* 1768 */       factory.close();
/* 1769 */       return;
/*      */     }
/*      */     
/* 1772 */     TransportConfiguration backup = null;
/*      */     
/* 1774 */     if (this.ha)
/*      */     {
/* 1776 */       backup = this.topology.getBackupForConnector((Connector)factory.getConnector());
/*      */     }
/*      */     
/* 1779 */     factory.setBackupConnector(factory.getConnectorConfiguration(), backup);
/*      */     
/* 1781 */     synchronized (this.factories)
/*      */     {
/* 1783 */       this.factories.add(factory);
/*      */     }
/*      */   }
/*      */   
/*      */   private void readObject(ObjectInputStream is) throws ClassNotFoundException, IOException
/*      */   {
/* 1789 */     is.defaultReadObject();
/* 1790 */     if (this.stateGuard == null)
/*      */     {
/* 1792 */       this.stateGuard = new String();
/*      */     }
/* 1794 */     if (this.topologyArrayGuard == null)
/*      */     {
/* 1796 */       this.topologyArrayGuard = new String();
/*      */     }
/*      */     
/* 1799 */     this.packetDecoder = ClientPacketDecoder.INSTANCE;
/*      */   }
/*      */   
/*      */   private final class StaticConnector implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 6772279632415242634L;
/*      */     private List<Connector> connectors;
/*      */     
/*      */     private StaticConnector() {}
/*      */     
/*      */     public ClientSessionFactory connect(boolean skipWarnings) throws HornetQException {
/* 1810 */       ServerLocatorImpl.this.assertOpen();
/*      */       
/* 1812 */       ServerLocatorImpl.this.initialise();
/*      */       
/* 1814 */       ClientSessionFactory csf = null;
/*      */       
/* 1816 */       createConnectors();
/*      */       
/*      */ 
/*      */       try
/*      */       {
/* 1821 */         int retryNumber = 0;
/* 1822 */         while ((csf == null) && (!ServerLocatorImpl.this.isClosed()))
/*      */         {
/* 1824 */           retryNumber++;
/* 1825 */           for (Connector conn : this.connectors)
/*      */           {
/* 1827 */             if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */             {
/* 1829 */               HornetQClientLogger.LOGGER.debug(this + "::Submitting connect towards " + conn);
/*      */             }
/*      */             
/* 1832 */             csf = conn.tryConnect();
/*      */             
/* 1834 */             if (csf != null)
/*      */             {
/* 1836 */               csf.getConnection().addFailureListener(new FailureListener()
/*      */               {
/*      */ 
/*      */                 public void connectionFailed(HornetQException exception, boolean failedOver)
/*      */                 {
/*      */ 
/* 1842 */                   if ((ServerLocatorImpl.this.clusterConnection) && (exception.getType() == HornetQExceptionType.DISCONNECTED))
/*      */                   {
/*      */                     try
/*      */                     {
/* 1846 */                       ServerLocatorImpl.this.start(ServerLocatorImpl.this.startExecutor);
/*      */ 
/*      */                     }
/*      */                     catch (Exception e)
/*      */                     {
/* 1851 */                       HornetQClientLogger.LOGGER.errorStartingLocator(e);
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 
/*      */ 
/*      */                 public String toString()
/*      */                 {
/* 1859 */                   return "FailureListener('restarts cluster connections')";
/*      */                 }
/*      */               });
/*      */               
/* 1863 */               if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */               {
/* 1865 */                 HornetQClientLogger.LOGGER.debug("Returning " + csf + " after " + retryNumber + " retries on StaticConnector " + ServerLocatorImpl.this);
/*      */               }
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1872 */               return csf;
/*      */             }
/*      */           }
/*      */           
/* 1876 */           if ((ServerLocatorImpl.this.initialConnectAttempts < 0) || (retryNumber <= ServerLocatorImpl.this.initialConnectAttempts))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 1881 */             if (ServerLocatorImpl.this.latch.await(ServerLocatorImpl.this.retryInterval, TimeUnit.MILLISECONDS)) {
/* 1882 */               return null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (RejectedExecutionException e) {
/* 1888 */         if ((ServerLocatorImpl.this.isClosed()) || (skipWarnings))
/* 1889 */           return null;
/* 1890 */         HornetQClientLogger.LOGGER.debug("Rejected execution", e);
/* 1891 */         throw e;
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1895 */         if ((ServerLocatorImpl.this.isClosed()) || (skipWarnings))
/* 1896 */           return null;
/* 1897 */         HornetQClientLogger.LOGGER.errorConnectingToNodes(e);
/* 1898 */         throw HornetQClientMessageBundle.BUNDLE.cannotConnectToStaticConnectors(e);
/*      */       }
/*      */       
/* 1901 */       if ((ServerLocatorImpl.this.isClosed()) || (skipWarnings))
/*      */       {
/* 1903 */         return null;
/*      */       }
/*      */       
/* 1906 */       HornetQClientLogger.LOGGER.errorConnectingToNodes(ServerLocatorImpl.this.traceException);
/* 1907 */       throw HornetQClientMessageBundle.BUNDLE.cannotConnectToStaticConnectors2();
/*      */     }
/*      */     
/*      */     private synchronized void createConnectors()
/*      */     {
/* 1912 */       if (this.connectors != null)
/*      */       {
/* 1914 */         for (Connector conn : this.connectors)
/*      */         {
/* 1916 */           if (conn != null)
/*      */           {
/* 1918 */             conn.disconnect();
/*      */           }
/*      */         }
/*      */       }
/* 1922 */       this.connectors = new ArrayList();
/* 1923 */       if (ServerLocatorImpl.this.initialConnectors != null)
/*      */       {
/* 1925 */         for (TransportConfiguration initialConnector : ServerLocatorImpl.this.initialConnectors)
/*      */         {
/* 1927 */           ClientSessionFactoryInternal factory = new ClientSessionFactoryImpl(ServerLocatorImpl.this, initialConnector, ServerLocatorImpl.this.callTimeout, ServerLocatorImpl.this.callFailoverTimeout, ServerLocatorImpl.this.clientFailureCheckPeriod, ServerLocatorImpl.this.connectionTTL, ServerLocatorImpl.this.retryInterval, ServerLocatorImpl.this.retryIntervalMultiplier, ServerLocatorImpl.this.maxRetryInterval, ServerLocatorImpl.this.reconnectAttempts, ServerLocatorImpl.this.threadPool, ServerLocatorImpl.this.scheduledThreadPool, ServerLocatorImpl.this.incomingInterceptors, ServerLocatorImpl.this.outgoingInterceptors, ServerLocatorImpl.this.packetDecoder);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1943 */           factory.disableFinalizeCheck();
/*      */           
/* 1945 */           this.connectors.add(new Connector(initialConnector, factory));
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public synchronized void disconnect()
/*      */     {
/* 1952 */       if (this.connectors != null)
/*      */       {
/* 1954 */         for (Connector connector : this.connectors)
/*      */         {
/* 1956 */           connector.disconnect();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     protected void finalize()
/*      */       throws Throwable
/*      */     {
/* 1964 */       if ((!ServerLocatorImpl.this.isClosed()) && (ServerLocatorImpl.this.finalizeCheck))
/*      */       {
/* 1966 */         HornetQClientLogger.LOGGER.serverLocatorNotClosed(ServerLocatorImpl.this.traceException, System.identityHashCode(this));
/*      */         
/* 1968 */         if (ServerLocatorImpl.finalizeCallback != null)
/*      */         {
/* 1970 */           ServerLocatorImpl.finalizeCallback.run();
/*      */         }
/*      */         
/* 1973 */         ServerLocatorImpl.this.close();
/*      */       }
/*      */       
/* 1976 */       super.finalize();
/*      */     }
/*      */     
/*      */ 
/*      */     private final class Connector
/*      */     {
/*      */       private final TransportConfiguration initialConnector;
/*      */       private volatile ClientSessionFactoryInternal factory;
/*      */       
/*      */       public Connector(TransportConfiguration initialConnector, ClientSessionFactoryInternal factory)
/*      */       {
/* 1987 */         this.initialConnector = initialConnector;
/* 1988 */         this.factory = factory;
/*      */       }
/*      */       
/*      */       public ClientSessionFactory tryConnect() throws HornetQException
/*      */       {
/* 1993 */         if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */         {
/* 1995 */           HornetQClientLogger.LOGGER.debug(this + "::Trying to connect to " + this.factory);
/*      */         }
/*      */         try
/*      */         {
/* 1999 */           ClientSessionFactoryInternal factoryToUse = this.factory;
/* 2000 */           if (factoryToUse != null)
/*      */           {
/* 2002 */             ServerLocatorImpl.this.addToConnecting(factoryToUse);
/*      */             
/*      */             try
/*      */             {
/* 2006 */               factoryToUse.connect(1, false);
/*      */             }
/*      */             finally
/*      */             {
/* 2010 */               ServerLocatorImpl.this.removeFromConnecting(factoryToUse);
/*      */             }
/*      */           }
/* 2013 */           return factoryToUse;
/*      */         }
/*      */         catch (HornetQException e)
/*      */         {
/* 2017 */           HornetQClientLogger.LOGGER.debug(this + "::Exception on establish connector initial connection", e); }
/* 2018 */         return null;
/*      */       }
/*      */       
/*      */ 
/*      */       public void disconnect()
/*      */       {
/* 2024 */         if (this.factory != null)
/*      */         {
/* 2026 */           this.factory.causeExit();
/* 2027 */           this.factory.cleanup();
/* 2028 */           this.factory = null;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */       public String toString()
/*      */       {
/* 2035 */         return "Connector [initialConnector=" + this.initialConnector + "]";
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void assertOpen()
/*      */   {
/* 2043 */     synchronized (this.stateGuard)
/*      */     {
/* 2045 */       if ((this.state != null) && (this.state != STATE.INITIALIZED))
/*      */       {
/* 2047 */         throw new IllegalStateException("Server locator is closed (maybe it was garbage collected)");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClosed()
/*      */   {
/* 2054 */     synchronized (this.stateGuard)
/*      */     {
/* 2056 */       return this.state != STATE.INITIALIZED;
/*      */     }
/*      */   }
/*      */   
/*      */   private Object writeReplace() throws ObjectStreamException
/*      */   {
/* 2062 */     ServerLocatorImpl clone = new ServerLocatorImpl(this);
/* 2063 */     return clone;
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ServerLocatorImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */