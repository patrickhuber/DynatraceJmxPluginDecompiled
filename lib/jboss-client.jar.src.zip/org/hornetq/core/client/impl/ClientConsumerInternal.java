package org.hornetq.core.client.impl;

import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.SimpleString;
import org.hornetq.api.core.client.ClientConsumer;
import org.hornetq.api.core.client.ClientMessage;
import org.hornetq.core.protocol.core.impl.wireformat.SessionQueueQueryResponseMessage;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveLargeMessage;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveMessage;
import org.hornetq.utils.FutureLatch;

public abstract interface ClientConsumerInternal
  extends ClientConsumer
{
  public abstract long getID();
  
  public abstract SimpleString getQueueName();
  
  public abstract SimpleString getFilterString();
  
  public abstract boolean isBrowseOnly();
  
  public abstract void handleMessage(SessionReceiveMessage paramSessionReceiveMessage)
    throws Exception;
  
  public abstract void handleLargeMessage(SessionReceiveLargeMessage paramSessionReceiveLargeMessage)
    throws Exception;
  
  public abstract void handleLargeMessageContinuation(SessionReceiveContinuationMessage paramSessionReceiveContinuationMessage)
    throws Exception;
  
  public abstract void flowControl(int paramInt, boolean paramBoolean)
    throws HornetQException;
  
  public abstract void clear(boolean paramBoolean)
    throws HornetQException;
  
  public abstract Thread prepareForClose(FutureLatch paramFutureLatch)
    throws HornetQException;
  
  public abstract void clearAtFailover();
  
  public abstract int getClientWindowSize();
  
  public abstract int getBufferSize();
  
  public abstract void cleanUp()
    throws HornetQException;
  
  public abstract void acknowledge(ClientMessage paramClientMessage)
    throws HornetQException;
  
  public abstract void individualAcknowledge(ClientMessage paramClientMessage)
    throws HornetQException;
  
  public abstract void flushAcks()
    throws HornetQException;
  
  public abstract void stop(boolean paramBoolean)
    throws HornetQException;
  
  public abstract void start();
  
  public abstract SessionQueueQueryResponseMessage getQueueInfo();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientConsumerInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */