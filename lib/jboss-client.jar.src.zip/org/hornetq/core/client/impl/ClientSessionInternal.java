package org.hornetq.core.client.impl;

import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.Message;
import org.hornetq.api.core.SimpleString;
import org.hornetq.api.core.client.ClientSession;
import org.hornetq.core.protocol.core.Channel;
import org.hornetq.core.protocol.core.CoreRemotingConnection;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveLargeMessage;
import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveMessage;
import org.hornetq.spi.core.protocol.RemotingConnection;

public abstract interface ClientSessionInternal
  extends ClientSession
{
  public abstract String getName();
  
  public abstract void acknowledge(long paramLong1, long paramLong2)
    throws HornetQException;
  
  public abstract void individualAcknowledge(long paramLong1, long paramLong2)
    throws HornetQException;
  
  public abstract boolean isCacheLargeMessageClient();
  
  public abstract int getMinLargeMessageSize();
  
  public abstract boolean isCompressLargeMessages();
  
  public abstract void expire(long paramLong1, long paramLong2)
    throws HornetQException;
  
  public abstract void addConsumer(ClientConsumerInternal paramClientConsumerInternal);
  
  public abstract void addProducer(ClientProducerInternal paramClientProducerInternal);
  
  public abstract void removeConsumer(ClientConsumerInternal paramClientConsumerInternal)
    throws HornetQException;
  
  public abstract void removeProducer(ClientProducerInternal paramClientProducerInternal);
  
  public abstract void handleReceiveMessage(long paramLong, SessionReceiveMessage paramSessionReceiveMessage)
    throws Exception;
  
  public abstract void handleReceiveLargeMessage(long paramLong, SessionReceiveLargeMessage paramSessionReceiveLargeMessage)
    throws Exception;
  
  public abstract void handleReceiveContinuation(long paramLong, SessionReceiveContinuationMessage paramSessionReceiveContinuationMessage)
    throws Exception;
  
  public abstract void preHandleFailover(CoreRemotingConnection paramCoreRemotingConnection);
  
  public abstract void handleFailover(CoreRemotingConnection paramCoreRemotingConnection, HornetQException paramHornetQException);
  
  public abstract RemotingConnection getConnection();
  
  public abstract Channel getChannel();
  
  public abstract void cleanUp(boolean paramBoolean)
    throws HornetQException;
  
  public abstract void returnBlocking();
  
  public abstract void setForceNotSameRM(boolean paramBoolean);
  
  public abstract ClientSessionFactoryInternal getSessionFactory();
  
  public abstract void workDone();
  
  public abstract void forceDelivery(long paramLong1, long paramLong2)
    throws HornetQException;
  
  public abstract void sendProducerCreditsMessage(int paramInt, SimpleString paramSimpleString);
  
  public abstract ClientProducerCredits getCredits(SimpleString paramSimpleString, boolean paramBoolean);
  
  public abstract void returnCredits(SimpleString paramSimpleString);
  
  public abstract void handleReceiveProducerCredits(SimpleString paramSimpleString, int paramInt);
  
  public abstract void handleReceiveProducerFailCredits(SimpleString paramSimpleString, int paramInt);
  
  public abstract ClientProducerCreditManager getProducerCreditManager();
  
  public abstract void setAddress(Message paramMessage, SimpleString paramSimpleString);
  
  public abstract void setPacketSize(int paramInt);
  
  public abstract void resetIfNeeded()
    throws HornetQException;
  
  public abstract void startCall();
  
  public abstract void endCall();
  
  public abstract void setStopSignal();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientSessionInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */