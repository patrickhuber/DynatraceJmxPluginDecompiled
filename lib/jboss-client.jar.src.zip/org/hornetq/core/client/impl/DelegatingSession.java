/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.Message;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.api.core.client.ClientConsumer;
/*     */ import org.hornetq.api.core.client.ClientMessage;
/*     */ import org.hornetq.api.core.client.ClientProducer;
/*     */ import org.hornetq.api.core.client.ClientSession.BindingQuery;
/*     */ import org.hornetq.api.core.client.ClientSession.QueueQuery;
/*     */ import org.hornetq.api.core.client.FailoverEventListener;
/*     */ import org.hornetq.api.core.client.SendAcknowledgementHandler;
/*     */ import org.hornetq.api.core.client.SessionFailureListener;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.protocol.core.Channel;
/*     */ import org.hornetq.core.protocol.core.CoreRemotingConnection;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveLargeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveMessage;
/*     */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*     */ import org.hornetq.utils.ConcurrentHashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingSession
/*     */   implements ClientSessionInternal
/*     */ {
/*     */   private final ClientSessionInternal session;
/*     */   private final Exception creationStack;
/*     */   private volatile boolean closed;
/*  55 */   private static Set<DelegatingSession> sessions = new ConcurrentHashSet();
/*     */   
/*     */   public static volatile boolean debug;
/*     */   
/*     */   public static void dumpSessionCreationStacks()
/*     */   {
/*  61 */     HornetQClientLogger.LOGGER.dumpingSessionStacks();
/*     */     
/*  63 */     for (DelegatingSession session : sessions)
/*     */     {
/*  65 */       HornetQClientLogger.LOGGER.dumpingSessionStack(session.creationStack);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/*  74 */     if ((!this.closed) && (!this.session.isClosed()))
/*     */     {
/*  76 */       HornetQClientLogger.LOGGER.clientSessionNotClosed(this.creationStack, System.identityHashCode(this));
/*     */       
/*  78 */       close();
/*     */     }
/*     */     
/*  81 */     super.finalize();
/*     */   }
/*     */   
/*     */   public DelegatingSession(ClientSessionInternal session)
/*     */   {
/*  86 */     this.session = session;
/*     */     
/*  88 */     this.creationStack = new Exception();
/*     */     
/*  90 */     if (debug)
/*     */     {
/*  92 */       sessions.add(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void acknowledge(long consumerID, long messageID) throws HornetQException
/*     */   {
/*  98 */     this.session.acknowledge(consumerID, messageID);
/*     */   }
/*     */   
/*     */   public void individualAcknowledge(long consumerID, long messageID) throws HornetQException
/*     */   {
/* 103 */     this.session.individualAcknowledge(consumerID, messageID);
/*     */   }
/*     */   
/*     */   public void addConsumer(ClientConsumerInternal consumer)
/*     */   {
/* 108 */     this.session.addConsumer(consumer);
/*     */   }
/*     */   
/*     */   public void addFailureListener(SessionFailureListener listener)
/*     */   {
/* 113 */     this.session.addFailureListener(listener);
/*     */   }
/*     */   
/*     */   public void addFailoverListener(FailoverEventListener listener)
/*     */   {
/* 118 */     this.session.addFailoverListener(listener);
/*     */   }
/*     */   
/*     */   public void addProducer(ClientProducerInternal producer)
/*     */   {
/* 123 */     this.session.addProducer(producer);
/*     */   }
/*     */   
/*     */   public ClientSession.BindingQuery bindingQuery(SimpleString address) throws HornetQException
/*     */   {
/* 128 */     return this.session.bindingQuery(address);
/*     */   }
/*     */   
/*     */   public void forceDelivery(long consumerID, long sequence) throws HornetQException
/*     */   {
/* 133 */     this.session.forceDelivery(consumerID, sequence);
/*     */   }
/*     */   
/*     */   public void cleanUp(boolean failingOver)
/*     */     throws HornetQException
/*     */   {
/* 139 */     this.session.cleanUp(failingOver);
/*     */   }
/*     */   
/*     */   public void close() throws HornetQException
/*     */   {
/* 144 */     this.closed = true;
/*     */     
/* 146 */     if (debug)
/*     */     {
/* 148 */       sessions.remove(this);
/*     */     }
/*     */     
/* 151 */     this.session.close();
/*     */   }
/*     */   
/*     */   public void commit() throws HornetQException
/*     */   {
/* 156 */     this.session.commit();
/*     */   }
/*     */   
/*     */   public void commit(Xid xid, boolean onePhase) throws XAException
/*     */   {
/* 161 */     this.session.commit(xid, onePhase);
/*     */   }
/*     */   
/*     */   public ClientMessage createMessage(boolean durable)
/*     */   {
/* 166 */     return this.session.createMessage(durable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientMessage createMessage(byte type, boolean durable, long expiration, long timestamp, byte priority)
/*     */   {
/* 175 */     return this.session.createMessage(type, durable, expiration, timestamp, priority);
/*     */   }
/*     */   
/*     */   public ClientMessage createMessage(byte type, boolean durable)
/*     */   {
/* 180 */     return this.session.createMessage(type, durable);
/*     */   }
/*     */   
/*     */ 
/*     */   public ClientConsumer createConsumer(SimpleString queueName, SimpleString filterString, boolean browseOnly)
/*     */     throws HornetQException
/*     */   {
/* 187 */     return this.session.createConsumer(queueName, filterString, browseOnly);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientConsumer createConsumer(SimpleString queueName, SimpleString filterString, int windowSize, int maxRate, boolean browseOnly)
/*     */     throws HornetQException
/*     */   {
/* 196 */     return this.session.createConsumer(queueName, filterString, windowSize, maxRate, browseOnly);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(SimpleString queueName, SimpleString filterString) throws HornetQException
/*     */   {
/* 201 */     return this.session.createConsumer(queueName, filterString);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(SimpleString queueName) throws HornetQException
/*     */   {
/* 206 */     return this.session.createConsumer(queueName);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(String queueName, String filterString, boolean browseOnly) throws HornetQException
/*     */   {
/* 211 */     return this.session.createConsumer(queueName, filterString, browseOnly);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ClientConsumer createConsumer(String queueName, String filterString, int windowSize, int maxRate, boolean browseOnly)
/*     */     throws HornetQException
/*     */   {
/* 220 */     return this.session.createConsumer(queueName, filterString, windowSize, maxRate, browseOnly);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(String queueName, String filterString) throws HornetQException
/*     */   {
/* 225 */     return this.session.createConsumer(queueName, filterString);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(String queueName) throws HornetQException
/*     */   {
/* 230 */     return this.session.createConsumer(queueName);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(SimpleString queueName, boolean browseOnly) throws HornetQException
/*     */   {
/* 235 */     return this.session.createConsumer(queueName, browseOnly);
/*     */   }
/*     */   
/*     */   public ClientConsumer createConsumer(String queueName, boolean browseOnly) throws HornetQException
/*     */   {
/* 240 */     return this.session.createConsumer(queueName, browseOnly);
/*     */   }
/*     */   
/*     */   public ClientProducer createProducer() throws HornetQException
/*     */   {
/* 245 */     return this.session.createProducer();
/*     */   }
/*     */   
/*     */   public ClientProducer createProducer(SimpleString address, int rate) throws HornetQException
/*     */   {
/* 250 */     return this.session.createProducer(address, rate);
/*     */   }
/*     */   
/*     */   public ClientProducer createProducer(SimpleString address) throws HornetQException
/*     */   {
/* 255 */     return this.session.createProducer(address);
/*     */   }
/*     */   
/*     */   public ClientProducer createProducer(String address) throws HornetQException
/*     */   {
/* 260 */     return this.session.createProducer(address);
/*     */   }
/*     */   
/*     */   public void createQueue(String address, String queueName) throws HornetQException
/*     */   {
/* 265 */     this.session.createQueue(address, queueName);
/*     */   }
/*     */   
/*     */   public void createQueue(SimpleString address, SimpleString queueName) throws HornetQException
/*     */   {
/* 270 */     this.session.createQueue(address, queueName);
/*     */   }
/*     */   
/*     */   public void createQueue(SimpleString address, SimpleString queueName, boolean durable) throws HornetQException
/*     */   {
/* 275 */     this.session.createQueue(address, queueName, durable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void createQueue(SimpleString address, SimpleString queueName, SimpleString filterString, boolean durable)
/*     */     throws HornetQException
/*     */   {
/* 283 */     this.session.createQueue(address, queueName, filterString, durable);
/*     */   }
/*     */   
/*     */   public void createQueue(String address, String queueName, boolean durable) throws HornetQException
/*     */   {
/* 288 */     this.session.createQueue(address, queueName, durable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void createQueue(String address, String queueName, String filterString, boolean durable)
/*     */     throws HornetQException
/*     */   {
/* 296 */     this.session.createQueue(address, queueName, filterString, durable);
/*     */   }
/*     */   
/*     */   public void createTemporaryQueue(SimpleString address, SimpleString queueName, SimpleString filter) throws HornetQException
/*     */   {
/* 301 */     this.session.createTemporaryQueue(address, queueName, filter);
/*     */   }
/*     */   
/*     */   public void createTemporaryQueue(SimpleString address, SimpleString queueName) throws HornetQException
/*     */   {
/* 306 */     this.session.createTemporaryQueue(address, queueName);
/*     */   }
/*     */   
/*     */   public void createTemporaryQueue(String address, String queueName, String filter) throws HornetQException
/*     */   {
/* 311 */     this.session.createTemporaryQueue(address, queueName, filter);
/*     */   }
/*     */   
/*     */   public void createTemporaryQueue(String address, String queueName) throws HornetQException
/*     */   {
/* 316 */     this.session.createTemporaryQueue(address, queueName);
/*     */   }
/*     */   
/*     */   public void deleteQueue(SimpleString queueName) throws HornetQException
/*     */   {
/* 321 */     this.session.deleteQueue(queueName);
/*     */   }
/*     */   
/*     */   public void deleteQueue(String queueName) throws HornetQException
/*     */   {
/* 326 */     this.session.deleteQueue(queueName);
/*     */   }
/*     */   
/*     */   public void end(Xid xid, int flags) throws XAException
/*     */   {
/* 331 */     this.session.end(xid, flags);
/*     */   }
/*     */   
/*     */   public void expire(long consumerID, long messageID) throws HornetQException
/*     */   {
/* 336 */     this.session.expire(consumerID, messageID);
/*     */   }
/*     */   
/*     */   public void forget(Xid xid) throws XAException
/*     */   {
/* 341 */     this.session.forget(xid);
/*     */   }
/*     */   
/*     */   public RemotingConnection getConnection()
/*     */   {
/* 346 */     return this.session.getConnection();
/*     */   }
/*     */   
/*     */   public int getMinLargeMessageSize()
/*     */   {
/* 351 */     return this.session.getMinLargeMessageSize();
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 356 */     return this.session.getName();
/*     */   }
/*     */   
/*     */   public int getTransactionTimeout() throws XAException
/*     */   {
/* 361 */     return this.session.getTransactionTimeout();
/*     */   }
/*     */   
/*     */   public int getVersion()
/*     */   {
/* 366 */     return this.session.getVersion();
/*     */   }
/*     */   
/*     */   public XAResource getXAResource()
/*     */   {
/* 371 */     return this.session.getXAResource();
/*     */   }
/*     */   
/*     */   public void preHandleFailover(CoreRemotingConnection connection)
/*     */   {
/* 376 */     this.session.preHandleFailover(connection);
/*     */   }
/*     */   
/*     */   public void handleFailover(CoreRemotingConnection backupConnection, HornetQException cause)
/*     */   {
/* 381 */     this.session.handleFailover(backupConnection, cause);
/*     */   }
/*     */   
/*     */   public void handleReceiveContinuation(long consumerID, SessionReceiveContinuationMessage continuation) throws Exception
/*     */   {
/* 386 */     this.session.handleReceiveContinuation(consumerID, continuation);
/*     */   }
/*     */   
/*     */   public void handleReceiveLargeMessage(long consumerID, SessionReceiveLargeMessage message) throws Exception
/*     */   {
/* 391 */     this.session.handleReceiveLargeMessage(consumerID, message);
/*     */   }
/*     */   
/*     */   public void handleReceiveMessage(long consumerID, SessionReceiveMessage message) throws Exception
/*     */   {
/* 396 */     this.session.handleReceiveMessage(consumerID, message);
/*     */   }
/*     */   
/*     */   public boolean isAutoCommitAcks()
/*     */   {
/* 401 */     return this.session.isAutoCommitAcks();
/*     */   }
/*     */   
/*     */   public boolean isAutoCommitSends()
/*     */   {
/* 406 */     return this.session.isAutoCommitSends();
/*     */   }
/*     */   
/*     */   public boolean isBlockOnAcknowledge()
/*     */   {
/* 411 */     return this.session.isBlockOnAcknowledge();
/*     */   }
/*     */   
/*     */   public boolean isCacheLargeMessageClient()
/*     */   {
/* 416 */     return this.session.isCacheLargeMessageClient();
/*     */   }
/*     */   
/*     */   public boolean isClosed()
/*     */   {
/* 421 */     return this.session.isClosed();
/*     */   }
/*     */   
/*     */   public boolean isSameRM(XAResource xares) throws XAException
/*     */   {
/* 426 */     return this.session.isSameRM(xares);
/*     */   }
/*     */   
/*     */   public boolean isXA()
/*     */   {
/* 431 */     return this.session.isXA();
/*     */   }
/*     */   
/*     */   public int prepare(Xid xid) throws XAException
/*     */   {
/* 436 */     return this.session.prepare(xid);
/*     */   }
/*     */   
/*     */   public ClientSession.QueueQuery queueQuery(SimpleString queueName) throws HornetQException
/*     */   {
/* 441 */     return this.session.queueQuery(queueName);
/*     */   }
/*     */   
/*     */   public Xid[] recover(int flag) throws XAException
/*     */   {
/* 446 */     return this.session.recover(flag);
/*     */   }
/*     */   
/*     */   public void removeConsumer(ClientConsumerInternal consumer) throws HornetQException
/*     */   {
/* 451 */     this.session.removeConsumer(consumer);
/*     */   }
/*     */   
/*     */   public boolean removeFailureListener(SessionFailureListener listener)
/*     */   {
/* 456 */     return this.session.removeFailureListener(listener);
/*     */   }
/*     */   
/*     */   public boolean removeFailoverListener(FailoverEventListener listener)
/*     */   {
/* 461 */     return this.session.removeFailoverListener(listener);
/*     */   }
/*     */   
/*     */   public void removeProducer(ClientProducerInternal producer)
/*     */   {
/* 466 */     this.session.removeProducer(producer);
/*     */   }
/*     */   
/*     */   public void returnBlocking()
/*     */   {
/* 471 */     this.session.returnBlocking();
/*     */   }
/*     */   
/*     */   public void rollback() throws HornetQException
/*     */   {
/* 476 */     this.session.rollback();
/*     */   }
/*     */   
/*     */   public boolean isRollbackOnly()
/*     */   {
/* 481 */     return this.session.isRollbackOnly();
/*     */   }
/*     */   
/*     */   public void rollback(boolean considerLastMessageAsDelivered) throws HornetQException
/*     */   {
/* 486 */     this.session.rollback(considerLastMessageAsDelivered);
/*     */   }
/*     */   
/*     */   public void rollback(Xid xid) throws XAException
/*     */   {
/* 491 */     this.session.rollback(xid);
/*     */   }
/*     */   
/*     */   public void setSendAcknowledgementHandler(SendAcknowledgementHandler handler)
/*     */   {
/* 496 */     this.session.setSendAcknowledgementHandler(handler);
/*     */   }
/*     */   
/*     */   public boolean setTransactionTimeout(int seconds) throws XAException
/*     */   {
/* 501 */     return this.session.setTransactionTimeout(seconds);
/*     */   }
/*     */   
/*     */   public void resetIfNeeded() throws HornetQException
/*     */   {
/* 506 */     this.session.resetIfNeeded();
/*     */   }
/*     */   
/*     */   public void start() throws HornetQException
/*     */   {
/* 511 */     this.session.start();
/*     */   }
/*     */   
/*     */   public void start(Xid xid, int flags) throws XAException
/*     */   {
/* 516 */     this.session.start(xid, flags);
/*     */   }
/*     */   
/*     */   public void stop() throws HornetQException
/*     */   {
/* 521 */     this.session.stop();
/*     */   }
/*     */   
/*     */   public ClientSessionFactoryInternal getSessionFactory()
/*     */   {
/* 526 */     return this.session.getSessionFactory();
/*     */   }
/*     */   
/*     */   public void setForceNotSameRM(boolean force)
/*     */   {
/* 531 */     this.session.setForceNotSameRM(force);
/*     */   }
/*     */   
/*     */   public void workDone()
/*     */   {
/* 536 */     this.session.workDone();
/*     */   }
/*     */   
/*     */   public void sendProducerCreditsMessage(int credits, SimpleString address)
/*     */   {
/* 541 */     this.session.sendProducerCreditsMessage(credits, address);
/*     */   }
/*     */   
/*     */   public ClientProducerCredits getCredits(SimpleString address, boolean anon)
/*     */   {
/* 546 */     return this.session.getCredits(address, anon);
/*     */   }
/*     */   
/*     */   public void returnCredits(SimpleString address)
/*     */   {
/* 551 */     this.session.returnCredits(address);
/*     */   }
/*     */   
/*     */   public void handleReceiveProducerCredits(SimpleString address, int credits)
/*     */   {
/* 556 */     this.session.handleReceiveProducerCredits(address, credits);
/*     */   }
/*     */   
/*     */   public void handleReceiveProducerFailCredits(SimpleString address, int credits)
/*     */   {
/* 561 */     this.session.handleReceiveProducerFailCredits(address, credits);
/*     */   }
/*     */   
/*     */   public ClientProducerCreditManager getProducerCreditManager()
/*     */   {
/* 566 */     return this.session.getProducerCreditManager();
/*     */   }
/*     */   
/*     */   public void setAddress(Message message, SimpleString address)
/*     */   {
/* 571 */     this.session.setAddress(message, address);
/*     */   }
/*     */   
/*     */   public void setPacketSize(int packetSize)
/*     */   {
/* 576 */     this.session.setPacketSize(packetSize);
/*     */   }
/*     */   
/*     */   public void addMetaData(String key, String data) throws HornetQException
/*     */   {
/* 581 */     this.session.addMetaData(key, data);
/*     */   }
/*     */   
/*     */   public boolean isCompressLargeMessages()
/*     */   {
/* 586 */     return this.session.isCompressLargeMessages();
/*     */   }
/*     */   
/*     */ 
/*     */   public String toString()
/*     */   {
/* 592 */     return "DelegatingSession [session=" + this.session + "]";
/*     */   }
/*     */   
/*     */ 
/*     */   public Channel getChannel()
/*     */   {
/* 598 */     return this.session.getChannel();
/*     */   }
/*     */   
/*     */   public void addUniqueMetaData(String key, String data)
/*     */     throws HornetQException
/*     */   {
/* 604 */     this.session.addUniqueMetaData(key, data);
/*     */   }
/*     */   
/*     */ 
/*     */   public void startCall()
/*     */   {
/* 610 */     this.session.startCall();
/*     */   }
/*     */   
/*     */   public void endCall()
/*     */   {
/* 615 */     this.session.endCall();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setStopSignal()
/*     */   {
/* 621 */     this.session.setStopSignal();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\DelegatingSession.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */