/*      */ package org.hornetq.core.client.impl;
/*      */ 
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import javax.transaction.xa.XAException;
/*      */ import javax.transaction.xa.XAResource;
/*      */ import javax.transaction.xa.Xid;
/*      */ import org.hornetq.api.core.HornetQBuffer;
/*      */ import org.hornetq.api.core.HornetQBuffers;
/*      */ import org.hornetq.api.core.HornetQException;
/*      */ import org.hornetq.api.core.HornetQExceptionType;
/*      */ import org.hornetq.api.core.Message;
/*      */ import org.hornetq.api.core.SimpleString;
/*      */ import org.hornetq.api.core.client.ClientConsumer;
/*      */ import org.hornetq.api.core.client.ClientMessage;
/*      */ import org.hornetq.api.core.client.ClientProducer;
/*      */ import org.hornetq.api.core.client.ClientSession.BindingQuery;
/*      */ import org.hornetq.api.core.client.ClientSession.QueueQuery;
/*      */ import org.hornetq.api.core.client.FailoverEventListener;
/*      */ import org.hornetq.api.core.client.SendAcknowledgementHandler;
/*      */ import org.hornetq.api.core.client.SessionFailureListener;
/*      */ import org.hornetq.core.client.HornetQClientLogger;
/*      */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*      */ import org.hornetq.core.protocol.core.Channel;
/*      */ import org.hornetq.core.protocol.core.CommandConfirmationHandler;
/*      */ import org.hornetq.core.protocol.core.CoreRemotingConnection;
/*      */ import org.hornetq.core.protocol.core.Packet;
/*      */ import org.hornetq.core.protocol.core.impl.PacketImpl;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.CreateQueueMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.CreateSessionMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.ReattachSessionMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.ReattachSessionResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.RollbackMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionAcknowledgeMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionAddMetaDataMessageV2;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionBindingQueryMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionBindingQueryResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionCloseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionConsumerFlowCreditMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionCreateConsumerMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionDeleteQueueMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionExpireMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionForceConsumerDelivery;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionIndividualAcknowledgeMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionQueueQueryMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionQueueQueryResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveLargeMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionRequestProducerCreditsMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionSendContinuationMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionSendMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionUniqueAddMetaDataMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAAfterFailedMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXACommitMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAEndMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAForgetMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAGetInDoubtXidsResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAGetTimeoutResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAJoinMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAPrepareMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAResumeMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXARollbackMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXASetTimeoutMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXASetTimeoutResponseMessage;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionXAStartMessage;
/*      */ import org.hornetq.core.remoting.FailureListener;
/*      */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*      */ import org.hornetq.spi.core.remoting.Connection;
/*      */ import org.hornetq.utils.IDGenerator;
/*      */ import org.hornetq.utils.SimpleIDGenerator;
/*      */ import org.hornetq.utils.TokenBucketLimiterImpl;
/*      */ import org.hornetq.utils.XidCodecSupport;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class ClientSessionImpl
/*      */   implements ClientSessionInternal, FailureListener, CommandConfirmationHandler
/*      */ {
/*  105 */   private final Map<String, String> metadata = new HashMap();
/*      */   
/*      */ 
/*      */   private final ClientSessionFactoryInternal sessionFactory;
/*      */   
/*      */ 
/*      */   private final String name;
/*      */   
/*      */ 
/*      */   private final String username;
/*      */   
/*      */ 
/*      */   private final String password;
/*      */   
/*      */   private final boolean xa;
/*      */   
/*      */   private final Executor executor;
/*      */   
/*      */   private final Executor flowControlExecutor;
/*      */   
/*      */   private volatile CoreRemotingConnection remotingConnection;
/*      */   
/*  127 */   private final Set<ClientProducerInternal> producers = new HashSet();
/*      */   
/*      */ 
/*  130 */   private final Map<Long, ClientConsumerInternal> consumers = new LinkedHashMap();
/*      */   
/*      */ 
/*      */   private volatile boolean closed;
/*      */   
/*      */   private final boolean autoCommitAcks;
/*      */   
/*      */   private final boolean preAcknowledge;
/*      */   
/*      */   private final boolean autoCommitSends;
/*      */   
/*      */   private final boolean blockOnAcknowledge;
/*      */   
/*      */   private final boolean autoGroup;
/*      */   
/*      */   private final int ackBatchSize;
/*      */   
/*      */   private final int consumerWindowSize;
/*      */   
/*      */   private final int consumerMaxRate;
/*      */   
/*      */   private final int confirmationWindowSize;
/*      */   
/*      */   private final int producerMaxRate;
/*      */   
/*      */   private final boolean blockOnNonDurableSend;
/*      */   
/*      */   private final boolean blockOnDurableSend;
/*      */   
/*      */   private final int minLargeMessageSize;
/*      */   
/*      */   private final boolean compressLargeMessages;
/*      */   
/*      */   private volatile int initialMessagePacketSize;
/*      */   
/*      */   private final boolean cacheLargeMessageClient;
/*      */   
/*      */   private final Channel channel;
/*      */   
/*      */   private final int version;
/*      */   
/*      */   private boolean forceNotSameRM;
/*      */   
/*  173 */   private final IDGenerator idGenerator = new SimpleIDGenerator(0L);
/*      */   
/*      */   private final ClientProducerCreditManager producerCreditManager;
/*      */   
/*      */   private volatile boolean started;
/*      */   
/*      */   private SendAcknowledgementHandler sendAckHandler;
/*      */   
/*      */   private volatile boolean rollbackOnly;
/*      */   
/*      */   private volatile boolean workDone;
/*      */   
/*      */   private final String groupID;
/*      */   
/*      */   private volatile boolean inClose;
/*      */   
/*  189 */   private volatile boolean mayAttemptToFailover = true;
/*      */   
/*      */   private volatile SimpleString defaultAddress;
/*      */   
/*  193 */   private boolean xaRetry = false;
/*      */   
/*      */ 
/*      */ 
/*      */   private Xid currentXID;
/*      */   
/*      */ 
/*      */ 
/*  201 */   private final AtomicInteger concurrentCall = new AtomicInteger(0);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ClientSessionImpl(ClientSessionFactoryInternal sessionFactory, String name, String username, String password, boolean xa, boolean autoCommitSends, boolean autoCommitAcks, boolean preAcknowledge, boolean blockOnAcknowledge, boolean autoGroup, int ackBatchSize, int consumerWindowSize, int consumerMaxRate, int confirmationWindowSize, int producerWindowSize, int producerMaxRate, boolean blockOnNonDurableSend, boolean blockOnDurableSend, boolean cacheLargeMessageClient, int minLargeMessageSize, boolean compressLargeMessages, int initialMessagePacketSize, String groupID, CoreRemotingConnection remotingConnection, int version, Channel channel, Executor executor, Executor flowControlExecutor)
/*      */     throws HornetQException
/*      */   {
/*  234 */     this.sessionFactory = sessionFactory;
/*      */     
/*  236 */     this.name = name;
/*      */     
/*  238 */     this.username = username;
/*      */     
/*  240 */     this.password = password;
/*      */     
/*  242 */     this.remotingConnection = remotingConnection;
/*      */     
/*  244 */     this.executor = executor;
/*      */     
/*  246 */     this.flowControlExecutor = flowControlExecutor;
/*      */     
/*  248 */     this.xa = xa;
/*      */     
/*  250 */     this.autoCommitAcks = autoCommitAcks;
/*      */     
/*  252 */     this.preAcknowledge = preAcknowledge;
/*      */     
/*  254 */     this.autoCommitSends = autoCommitSends;
/*      */     
/*  256 */     this.blockOnAcknowledge = blockOnAcknowledge;
/*      */     
/*  258 */     this.autoGroup = autoGroup;
/*      */     
/*  260 */     this.channel = channel;
/*      */     
/*  262 */     this.version = version;
/*      */     
/*  264 */     this.ackBatchSize = ackBatchSize;
/*      */     
/*  266 */     this.consumerWindowSize = consumerWindowSize;
/*      */     
/*  268 */     this.consumerMaxRate = consumerMaxRate;
/*      */     
/*  270 */     this.confirmationWindowSize = confirmationWindowSize;
/*      */     
/*  272 */     this.producerMaxRate = producerMaxRate;
/*      */     
/*  274 */     this.blockOnNonDurableSend = blockOnNonDurableSend;
/*      */     
/*  276 */     this.blockOnDurableSend = blockOnDurableSend;
/*      */     
/*  278 */     this.cacheLargeMessageClient = cacheLargeMessageClient;
/*      */     
/*  280 */     this.minLargeMessageSize = minLargeMessageSize;
/*      */     
/*  282 */     this.compressLargeMessages = compressLargeMessages;
/*      */     
/*  284 */     this.initialMessagePacketSize = initialMessagePacketSize;
/*      */     
/*  286 */     this.groupID = groupID;
/*      */     
/*  288 */     this.producerCreditManager = new ClientProducerCreditManagerImpl(this, producerWindowSize);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Channel getChannel()
/*      */   {
/*  296 */     return this.channel;
/*      */   }
/*      */   
/*      */   public void createQueue(SimpleString address, SimpleString queueName) throws HornetQException
/*      */   {
/*  301 */     internalCreateQueue(address, queueName, null, false, false);
/*      */   }
/*      */   
/*      */   public void createQueue(SimpleString address, SimpleString queueName, boolean durable) throws HornetQException
/*      */   {
/*  306 */     internalCreateQueue(address, queueName, null, durable, false);
/*      */   }
/*      */   
/*      */   public void createQueue(String address, String queueName, boolean durable) throws HornetQException
/*      */   {
/*  311 */     createQueue(SimpleString.toSimpleString(address), SimpleString.toSimpleString(queueName), durable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void createQueue(SimpleString address, SimpleString queueName, SimpleString filterString, boolean durable)
/*      */     throws HornetQException
/*      */   {
/*  319 */     internalCreateQueue(address, queueName, filterString, durable, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void createQueue(String address, String queueName, String filterString, boolean durable)
/*      */     throws HornetQException
/*      */   {
/*  327 */     createQueue(SimpleString.toSimpleString(address), SimpleString.toSimpleString(queueName), SimpleString.toSimpleString(filterString), durable);
/*      */   }
/*      */   
/*      */   public void createTemporaryQueue(SimpleString address, SimpleString queueName) throws HornetQException
/*      */   {
/*  332 */     internalCreateQueue(address, queueName, null, false, true);
/*      */   }
/*      */   
/*      */   public void createTemporaryQueue(String address, String queueName) throws HornetQException
/*      */   {
/*  337 */     internalCreateQueue(SimpleString.toSimpleString(address), SimpleString.toSimpleString(queueName), null, false, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void createTemporaryQueue(SimpleString address, SimpleString queueName, SimpleString filter)
/*      */     throws HornetQException
/*      */   {
/*  346 */     internalCreateQueue(address, queueName, filter, false, true);
/*      */   }
/*      */   
/*      */   public void createTemporaryQueue(String address, String queueName, String filter) throws HornetQException
/*      */   {
/*  351 */     internalCreateQueue(SimpleString.toSimpleString(address), SimpleString.toSimpleString(queueName), SimpleString.toSimpleString(filter), false, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteQueue(SimpleString queueName)
/*      */     throws HornetQException
/*      */   {
/*  360 */     checkClosed();
/*      */     
/*  362 */     startCall();
/*      */     try
/*      */     {
/*  365 */       this.channel.sendBlocking(new SessionDeleteQueueMessage(queueName), (byte)21);
/*      */     }
/*      */     finally
/*      */     {
/*  369 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public void deleteQueue(String queueName) throws HornetQException
/*      */   {
/*  375 */     deleteQueue(SimpleString.toSimpleString(queueName));
/*      */   }
/*      */   
/*      */   public ClientSession.QueueQuery queueQuery(SimpleString queueName) throws HornetQException
/*      */   {
/*  380 */     checkClosed();
/*      */     
/*  382 */     SessionQueueQueryMessage request = new SessionQueueQueryMessage(queueName);
/*      */     
/*      */ 
/*  385 */     startCall();
/*      */     try
/*      */     {
/*  388 */       SessionQueueQueryResponseMessage response = (SessionQueueQueryResponseMessage)this.channel.sendBlocking(request, (byte)46);
/*      */       
/*  390 */       return new QueueQueryImpl(response.isDurable(), response.getConsumerCount(), response.getMessageCount(), response.getFilterString(), response.getAddress(), response.isExists());
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/*      */ 
/*  399 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public ClientSession.BindingQuery bindingQuery(SimpleString address)
/*      */     throws HornetQException
/*      */   {
/*  406 */     checkClosed();
/*      */     
/*  408 */     SessionBindingQueryMessage request = new SessionBindingQueryMessage(address);
/*      */     
/*  410 */     SessionBindingQueryResponseMessage response = (SessionBindingQueryResponseMessage)this.channel.sendBlocking(request, (byte)50);
/*      */     
/*  412 */     return new BindingQueryImpl(response.isExists(), response.getQueueNames());
/*      */   }
/*      */   
/*      */   public void forceDelivery(long consumerID, long sequence) throws HornetQException
/*      */   {
/*  417 */     checkClosed();
/*      */     
/*  419 */     SessionForceConsumerDelivery request = new SessionForceConsumerDelivery(consumerID, sequence);
/*  420 */     this.channel.send(request);
/*      */   }
/*      */   
/*      */   public ClientConsumer createConsumer(SimpleString queueName) throws HornetQException
/*      */   {
/*  425 */     return createConsumer(queueName, null, false);
/*      */   }
/*      */   
/*      */   public ClientConsumer createConsumer(String queueName) throws HornetQException
/*      */   {
/*  430 */     return createConsumer(SimpleString.toSimpleString(queueName));
/*      */   }
/*      */   
/*      */   public ClientConsumer createConsumer(SimpleString queueName, SimpleString filterString) throws HornetQException
/*      */   {
/*  435 */     return createConsumer(queueName, filterString, this.consumerWindowSize, this.consumerMaxRate, false);
/*      */   }
/*      */   
/*      */   public void createQueue(String address, String queueName) throws HornetQException
/*      */   {
/*  440 */     createQueue(SimpleString.toSimpleString(address), SimpleString.toSimpleString(queueName));
/*      */   }
/*      */   
/*      */   public ClientConsumer createConsumer(String queueName, String filterString) throws HornetQException
/*      */   {
/*  445 */     return createConsumer(SimpleString.toSimpleString(queueName), SimpleString.toSimpleString(filterString));
/*      */   }
/*      */   
/*      */ 
/*      */   public ClientConsumer createConsumer(SimpleString queueName, SimpleString filterString, boolean browseOnly)
/*      */     throws HornetQException
/*      */   {
/*  452 */     return createConsumer(queueName, filterString, this.consumerWindowSize, this.consumerMaxRate, browseOnly);
/*      */   }
/*      */   
/*      */   public ClientConsumer createConsumer(SimpleString queueName, boolean browseOnly) throws HornetQException
/*      */   {
/*  457 */     return createConsumer(queueName, null, this.consumerWindowSize, this.consumerMaxRate, browseOnly);
/*      */   }
/*      */   
/*      */   public ClientConsumer createConsumer(String queueName, String filterString, boolean browseOnly) throws HornetQException
/*      */   {
/*  462 */     return createConsumer(SimpleString.toSimpleString(queueName), SimpleString.toSimpleString(filterString), browseOnly);
/*      */   }
/*      */   
/*      */ 
/*      */   public ClientConsumer createConsumer(String queueName, boolean browseOnly)
/*      */     throws HornetQException
/*      */   {
/*  469 */     return createConsumer(SimpleString.toSimpleString(queueName), null, browseOnly);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientConsumer createConsumer(SimpleString queueName, SimpleString filterString, int windowSize, int maxRate, boolean browseOnly)
/*      */     throws HornetQException
/*      */   {
/*  488 */     return internalCreateConsumer(queueName, filterString, windowSize, maxRate, browseOnly);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientConsumer createConsumer(String queueName, String filterString, int windowSize, int maxRate, boolean browseOnly)
/*      */     throws HornetQException
/*      */   {
/*  497 */     return createConsumer(SimpleString.toSimpleString(queueName), SimpleString.toSimpleString(filterString), windowSize, maxRate, browseOnly);
/*      */   }
/*      */   
/*      */   public ClientProducer createProducer() throws HornetQException
/*      */   {
/*  502 */     return createProducer((SimpleString)null);
/*      */   }
/*      */   
/*      */   public ClientProducer createProducer(SimpleString address) throws HornetQException
/*      */   {
/*  507 */     return createProducer(address, this.producerMaxRate);
/*      */   }
/*      */   
/*      */   public ClientProducer createProducer(String address) throws HornetQException
/*      */   {
/*  512 */     return createProducer(SimpleString.toSimpleString(address));
/*      */   }
/*      */   
/*      */   public ClientProducer createProducer(SimpleString address, int maxRate) throws HornetQException
/*      */   {
/*  517 */     return internalCreateProducer(address, maxRate);
/*      */   }
/*      */   
/*      */   public ClientProducer createProducer(String address, int rate) throws HornetQException
/*      */   {
/*  522 */     return createProducer(SimpleString.toSimpleString(address), rate);
/*      */   }
/*      */   
/*      */   public XAResource getXAResource()
/*      */   {
/*  527 */     return this;
/*      */   }
/*      */   
/*      */   private void rollbackOnFailover(boolean outcomeKnown) throws HornetQException
/*      */   {
/*  532 */     rollback(false);
/*      */     
/*  534 */     if (outcomeKnown)
/*      */     {
/*  536 */       throw HornetQClientMessageBundle.BUNDLE.txRolledBack();
/*      */     }
/*      */     
/*  539 */     throw HornetQClientMessageBundle.BUNDLE.txOutcomeUnknown();
/*      */   }
/*      */   
/*      */   public void commit() throws HornetQException
/*      */   {
/*  544 */     checkClosed();
/*      */     
/*  546 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/*  548 */       HornetQClientLogger.LOGGER.trace("Sending commit");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  554 */     if (this.rollbackOnly)
/*      */     {
/*  556 */       rollbackOnFailover(true);
/*      */     }
/*      */     
/*  559 */     flushAcks();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  564 */     if (this.rollbackOnly)
/*      */     {
/*  566 */       rollbackOnFailover(true);
/*      */     }
/*      */     try
/*      */     {
/*  570 */       this.channel.sendBlocking(new PacketImpl((byte)43), (byte)21);
/*      */     }
/*      */     catch (HornetQException e)
/*      */     {
/*  574 */       if ((e.getType() == HornetQExceptionType.UNBLOCKED) || (this.rollbackOnly))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  580 */         rollbackOnFailover(false);
/*      */       }
/*      */       else
/*      */       {
/*  584 */         throw e;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  589 */     if (this.rollbackOnly)
/*      */     {
/*  591 */       rollbackOnFailover(false);
/*      */     }
/*      */     
/*  594 */     this.workDone = false;
/*      */   }
/*      */   
/*      */   public boolean isRollbackOnly()
/*      */   {
/*  599 */     return this.rollbackOnly;
/*      */   }
/*      */   
/*      */   public void rollback() throws HornetQException
/*      */   {
/*  604 */     rollback(false);
/*      */   }
/*      */   
/*      */   public void rollback(boolean isLastMessageAsDelivered) throws HornetQException
/*      */   {
/*  609 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/*  611 */       HornetQClientLogger.LOGGER.trace("calling rollback(isLastMessageAsDelivered=" + isLastMessageAsDelivered + ")");
/*      */     }
/*  613 */     checkClosed();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  620 */     boolean wasStarted = this.started;
/*      */     
/*  622 */     if (wasStarted)
/*      */     {
/*  624 */       stop();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  629 */     for (ClientConsumerInternal consumer : cloneConsumers())
/*      */     {
/*  631 */       consumer.clear(true);
/*      */     }
/*      */     
/*      */ 
/*  635 */     flushAcks();
/*      */     
/*  637 */     this.channel.sendBlocking(new RollbackMessage(isLastMessageAsDelivered), (byte)21);
/*      */     
/*  639 */     if (wasStarted)
/*      */     {
/*  641 */       start();
/*      */     }
/*      */     
/*  644 */     this.rollbackOnly = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ClientMessage createMessage(byte type, boolean durable, long expiration, long timestamp, byte priority)
/*      */   {
/*  653 */     return new ClientMessageImpl(type, durable, expiration, timestamp, priority, this.initialMessagePacketSize);
/*      */   }
/*      */   
/*      */   public ClientMessage createMessage(byte type, boolean durable)
/*      */   {
/*  658 */     return createMessage(type, durable, 0L, System.currentTimeMillis(), (byte)4);
/*      */   }
/*      */   
/*      */   public ClientMessage createMessage(boolean durable)
/*      */   {
/*  663 */     return createMessage((byte)0, durable);
/*      */   }
/*      */   
/*      */   public boolean isClosed()
/*      */   {
/*  668 */     return this.closed;
/*      */   }
/*      */   
/*      */   public boolean isAutoCommitSends()
/*      */   {
/*  673 */     return this.autoCommitSends;
/*      */   }
/*      */   
/*      */   public boolean isAutoCommitAcks()
/*      */   {
/*  678 */     return this.autoCommitAcks;
/*      */   }
/*      */   
/*      */   public boolean isBlockOnAcknowledge()
/*      */   {
/*  683 */     return this.blockOnAcknowledge;
/*      */   }
/*      */   
/*      */   public boolean isXA()
/*      */   {
/*  688 */     return this.xa;
/*      */   }
/*      */   
/*      */   public void resetIfNeeded() throws HornetQException
/*      */   {
/*  693 */     if (this.rollbackOnly)
/*      */     {
/*  695 */       HornetQClientLogger.LOGGER.resettingSessionAfterFailure();
/*  696 */       rollback(false);
/*      */     }
/*      */   }
/*      */   
/*      */   public void start() throws HornetQException
/*      */   {
/*  702 */     checkClosed();
/*      */     
/*  704 */     if (!this.started)
/*      */     {
/*  706 */       for (ClientConsumerInternal clientConsumerInternal : cloneConsumers())
/*      */       {
/*  708 */         clientConsumerInternal.start();
/*      */       }
/*      */       
/*  711 */       this.channel.send(new PacketImpl((byte)67));
/*      */       
/*  713 */       this.started = true;
/*      */     }
/*      */   }
/*      */   
/*      */   public void stop() throws HornetQException
/*      */   {
/*  719 */     stop(true);
/*      */   }
/*      */   
/*      */   public void stop(boolean waitForOnMessage) throws HornetQException
/*      */   {
/*  724 */     checkClosed();
/*      */     
/*  726 */     if (this.started)
/*      */     {
/*  728 */       for (ClientConsumerInternal clientConsumerInternal : cloneConsumers())
/*      */       {
/*  730 */         clientConsumerInternal.stop(waitForOnMessage);
/*      */       }
/*      */       
/*  733 */       this.channel.sendBlocking(new PacketImpl((byte)68), (byte)21);
/*      */       
/*  735 */       this.started = false;
/*      */     }
/*      */   }
/*      */   
/*      */   public void addFailureListener(SessionFailureListener listener)
/*      */   {
/*  741 */     this.sessionFactory.addFailureListener(listener);
/*      */   }
/*      */   
/*      */   public boolean removeFailureListener(SessionFailureListener listener)
/*      */   {
/*  746 */     return this.sessionFactory.removeFailureListener(listener);
/*      */   }
/*      */   
/*      */   public void addFailoverListener(FailoverEventListener listener)
/*      */   {
/*  751 */     this.sessionFactory.addFailoverListener(listener);
/*      */   }
/*      */   
/*      */   public boolean removeFailoverListener(FailoverEventListener listener)
/*      */   {
/*  756 */     return this.sessionFactory.removeFailoverListener(listener);
/*      */   }
/*      */   
/*      */   public int getVersion()
/*      */   {
/*  761 */     return this.version;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMinLargeMessageSize()
/*      */   {
/*  769 */     return this.minLargeMessageSize;
/*      */   }
/*      */   
/*      */   public boolean isCompressLargeMessages()
/*      */   {
/*  774 */     return this.compressLargeMessages;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCacheLargeMessageClient()
/*      */   {
/*  782 */     return this.cacheLargeMessageClient;
/*      */   }
/*      */   
/*      */   public String getName()
/*      */   {
/*  787 */     return this.name;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void acknowledge(long consumerID, long messageID)
/*      */     throws HornetQException
/*      */   {
/*  796 */     if (this.preAcknowledge)
/*      */     {
/*  798 */       return;
/*      */     }
/*      */     
/*  801 */     checkClosed();
/*  802 */     if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */     {
/*  804 */       HornetQClientLogger.LOGGER.debug("client ack messageID = " + messageID);
/*      */     }
/*  806 */     SessionAcknowledgeMessage message = new SessionAcknowledgeMessage(consumerID, messageID, this.blockOnAcknowledge);
/*      */     
/*  808 */     startCall();
/*      */     try
/*      */     {
/*  811 */       if (this.blockOnAcknowledge)
/*      */       {
/*  813 */         this.channel.sendBlocking(message, (byte)21);
/*      */       }
/*      */       else
/*      */       {
/*  817 */         this.channel.sendBatched(message);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  822 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public void individualAcknowledge(long consumerID, long messageID)
/*      */     throws HornetQException
/*      */   {
/*  829 */     if (this.preAcknowledge)
/*      */     {
/*  831 */       return;
/*      */     }
/*      */     
/*  834 */     checkClosed();
/*      */     
/*  836 */     SessionIndividualAcknowledgeMessage message = new SessionIndividualAcknowledgeMessage(consumerID, messageID, this.blockOnAcknowledge);
/*      */     
/*      */ 
/*      */ 
/*  840 */     startCall();
/*      */     try
/*      */     {
/*  843 */       if (this.blockOnAcknowledge)
/*      */       {
/*  845 */         this.channel.sendBlocking(message, (byte)21);
/*      */       }
/*      */       else
/*      */       {
/*  849 */         this.channel.sendBatched(message);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*  854 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public void expire(long consumerID, long messageID) throws HornetQException
/*      */   {
/*  860 */     checkClosed();
/*      */     
/*      */ 
/*  863 */     if (!this.preAcknowledge)
/*      */     {
/*  865 */       SessionExpireMessage message = new SessionExpireMessage(consumerID, messageID);
/*      */       
/*  867 */       this.channel.send(message);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addConsumer(ClientConsumerInternal consumer)
/*      */   {
/*  873 */     synchronized (this.consumers)
/*      */     {
/*  875 */       this.consumers.put(Long.valueOf(consumer.getID()), consumer);
/*      */     }
/*      */   }
/*      */   
/*      */   public void addProducer(ClientProducerInternal producer)
/*      */   {
/*  881 */     synchronized (this.producers)
/*      */     {
/*  883 */       this.producers.add(producer);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeConsumer(ClientConsumerInternal consumer) throws HornetQException
/*      */   {
/*  889 */     synchronized (this.consumers)
/*      */     {
/*  891 */       this.consumers.remove(Long.valueOf(consumer.getID()));
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeProducer(ClientProducerInternal producer)
/*      */   {
/*  897 */     synchronized (this.producers)
/*      */     {
/*  899 */       this.producers.remove(producer);
/*      */     }
/*      */   }
/*      */   
/*      */   public void handleReceiveMessage(long consumerID, SessionReceiveMessage message) throws Exception
/*      */   {
/*  905 */     ClientConsumerInternal consumer = getConsumer(consumerID);
/*      */     
/*  907 */     if (consumer != null)
/*      */     {
/*  909 */       ClientMessageInternal clMessage = (ClientMessageInternal)message.getMessage();
/*      */       
/*  911 */       clMessage.setDeliveryCount(message.getDeliveryCount());
/*      */       
/*  913 */       clMessage.setFlowControlSize(message.getPacketSize());
/*      */       
/*  915 */       consumer.handleMessage(message);
/*      */     }
/*      */   }
/*      */   
/*      */   public void handleReceiveLargeMessage(long consumerID, SessionReceiveLargeMessage message) throws Exception
/*      */   {
/*  921 */     ClientConsumerInternal consumer = getConsumer(consumerID);
/*      */     
/*  923 */     if (consumer != null)
/*      */     {
/*  925 */       consumer.handleLargeMessage(message);
/*      */     }
/*      */   }
/*      */   
/*      */   public void handleReceiveContinuation(long consumerID, SessionReceiveContinuationMessage continuation) throws Exception
/*      */   {
/*  931 */     ClientConsumerInternal consumer = getConsumer(consumerID);
/*      */     
/*  933 */     if (consumer != null)
/*      */     {
/*  935 */       consumer.handleLargeMessageContinuation(continuation);
/*      */     }
/*      */   }
/*      */   
/*      */   public void close() throws HornetQException
/*      */   {
/*  941 */     if (this.closed)
/*      */     {
/*  943 */       HornetQClientLogger.LOGGER.debug("Session was already closed, giving up now, this=" + this);
/*  944 */       return;
/*      */     }
/*      */     
/*  947 */     if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */     {
/*  949 */       HornetQClientLogger.LOGGER.debug("Calling close on session " + this);
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*  954 */       closeChildren();
/*      */       
/*  956 */       synchronized (this)
/*      */       {
/*  958 */         this.producerCreditManager.close();
/*      */       }
/*  960 */       this.inClose = true;
/*  961 */       this.channel.sendBlocking(new SessionCloseMessage(), (byte)21);
/*      */ 
/*      */ 
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*      */ 
/*  968 */       HornetQClientLogger.LOGGER.trace("Failed to close session", e);
/*      */     }
/*      */     
/*  971 */     doCleanup(false);
/*      */   }
/*      */   
/*      */   public synchronized void cleanUp(boolean failingOver) throws HornetQException
/*      */   {
/*  976 */     if (this.closed)
/*      */     {
/*  978 */       return;
/*      */     }
/*      */     
/*  981 */     this.producerCreditManager.close();
/*      */     
/*  983 */     cleanUpChildren();
/*      */     
/*  985 */     doCleanup(failingOver);
/*      */   }
/*      */   
/*      */   public void setSendAcknowledgementHandler(SendAcknowledgementHandler handler)
/*      */   {
/*  990 */     this.channel.setCommandConfirmationHandler(this);
/*      */     
/*  992 */     this.sendAckHandler = handler;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void preHandleFailover(CoreRemotingConnection connection)
/*      */   {
/* 1000 */     this.channel.lock();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void handleFailover(CoreRemotingConnection backupConnection, HornetQException cause)
/*      */   {
/* 1007 */     synchronized (this)
/*      */     {
/* 1009 */       if (this.closed)
/*      */       {
/* 1011 */         return;
/*      */       }
/*      */       
/* 1014 */       boolean resetCreditManager = false;
/*      */       
/*      */       try
/*      */       {
/* 1018 */         this.channel.transferConnection(backupConnection);
/*      */         
/* 1020 */         backupConnection.syncIDGeneratorSequence(this.remotingConnection.getIDGeneratorSequence());
/*      */         
/* 1022 */         this.remotingConnection = backupConnection;
/*      */         
/* 1024 */         int lcid = this.channel.getLastConfirmedCommandID();
/*      */         
/* 1026 */         Packet request = new ReattachSessionMessage(this.name, lcid);
/*      */         
/* 1028 */         Channel channel1 = backupConnection.getChannel(1L, -1);
/*      */         
/* 1030 */         ReattachSessionResponseMessage response = (ReattachSessionResponseMessage)channel1.sendBlocking(request, (byte)33);
/*      */         
/* 1032 */         if (response.isReattached())
/*      */         {
/* 1034 */           if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */           {
/* 1036 */             HornetQClientLogger.LOGGER.debug("ClientSession reattached fine, replaying commands");
/*      */           }
/*      */           
/*      */ 
/* 1040 */           this.channel.replayCommands(response.getLastConfirmedCommandID());
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 1045 */           if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */           {
/* 1047 */             HornetQClientLogger.LOGGER.debug("ClientSession couldn't be reattached, creating a new session");
/*      */           }
/*      */           
/* 1050 */           for (ClientConsumerInternal consumer : cloneConsumers())
/*      */           {
/* 1052 */             consumer.clearAtFailover();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1067 */           if ((!this.inClose) && (this.mayAttemptToFailover))
/*      */           {
/* 1069 */             Packet createRequest = new CreateSessionMessage(this.name, this.channel.getID(), this.version, this.username, this.password, this.minLargeMessageSize, this.xa, this.autoCommitSends, this.autoCommitAcks, this.preAcknowledge, this.confirmationWindowSize, this.defaultAddress == null ? null : this.defaultAddress.toString());
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1082 */             boolean retry = false;
/*      */             do
/*      */             {
/*      */               try
/*      */               {
/* 1087 */                 channel1.sendBlocking(createRequest, (byte)31);
/* 1088 */                 retry = false;
/*      */ 
/*      */               }
/*      */               catch (HornetQException e)
/*      */               {
/* 1093 */                 if (e.getType() == HornetQExceptionType.SESSION_CREATION_REJECTED)
/*      */                 {
/* 1095 */                   HornetQClientLogger.LOGGER.retryCreateSessionSeverStarting(this.name);
/* 1096 */                   retry = true;
/*      */                   
/* 1098 */                   Thread.sleep(10L);
/*      */                 }
/*      */                 else
/*      */                 {
/* 1102 */                   throw e;
/*      */                 }
/*      */                 
/*      */               }
/* 1106 */             } while ((retry) && (!this.inClose));
/*      */             
/* 1108 */             this.channel.clearCommands();
/*      */             
/* 1110 */             for (Map.Entry<Long, ClientConsumerInternal> entry : this.consumers.entrySet())
/*      */             {
/* 1112 */               SessionQueueQueryResponseMessage queueInfo = ((ClientConsumerInternal)entry.getValue()).getQueueInfo();
/*      */               
/*      */ 
/*      */ 
/*      */ 
/* 1117 */               if (!queueInfo.isDurable())
/*      */               {
/* 1119 */                 CreateQueueMessage createQueueRequest = new CreateQueueMessage(queueInfo.getAddress(), queueInfo.getName(), queueInfo.getFilterString(), false, queueInfo.isTemporary(), false);
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1126 */                 sendPacketWithoutLock(createQueueRequest);
/*      */               }
/*      */               
/* 1129 */               SessionCreateConsumerMessage createConsumerRequest = new SessionCreateConsumerMessage(((Long)entry.getKey()).longValue(), ((ClientConsumerInternal)entry.getValue()).getQueueName(), ((ClientConsumerInternal)entry.getValue()).getFilterString(), ((ClientConsumerInternal)entry.getValue()).isBrowseOnly(), false);
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1138 */               sendPacketWithoutLock(createConsumerRequest);
/*      */               
/* 1140 */               int clientWindowSize = ((ClientConsumerInternal)entry.getValue()).getClientWindowSize();
/*      */               
/* 1142 */               if (clientWindowSize != 0)
/*      */               {
/* 1144 */                 SessionConsumerFlowCreditMessage packet = new SessionConsumerFlowCreditMessage(((Long)entry.getKey()).longValue(), clientWindowSize);
/*      */                 
/*      */ 
/* 1147 */                 sendPacketWithoutLock(packet);
/*      */ 
/*      */               }
/*      */               else
/*      */               {
/* 1152 */                 SessionConsumerFlowCreditMessage packet = new SessionConsumerFlowCreditMessage(((Long)entry.getKey()).longValue(), 1);
/*      */                 
/* 1154 */                 sendPacketWithoutLock(packet);
/*      */               }
/*      */             }
/*      */             
/* 1158 */             if (((!this.autoCommitAcks) || (!this.autoCommitSends)) && (this.workDone))
/*      */             {
/*      */ 
/*      */ 
/* 1162 */               this.rollbackOnly = true;
/*      */             }
/* 1164 */             if (this.currentXID != null)
/*      */             {
/* 1166 */               sendPacketWithoutLock(new SessionXAAfterFailedMessage(this.currentXID));
/* 1167 */               this.rollbackOnly = true;
/*      */             }
/*      */             
/*      */ 
/* 1171 */             if (this.started)
/*      */             {
/* 1173 */               for (ClientConsumerInternal consumer : cloneConsumers())
/*      */               {
/* 1175 */                 consumer.clearAtFailover();
/* 1176 */                 consumer.start();
/*      */               }
/*      */               
/* 1179 */               Packet packet = new PacketImpl((byte)67);
/*      */               
/* 1181 */               packet.setChannelID(this.channel.getID());
/*      */               
/* 1183 */               Connection conn = this.channel.getConnection().getTransportConnection();
/*      */               
/* 1185 */               HornetQBuffer buffer = packet.encode(this.channel.getConnection());
/*      */               
/* 1187 */               conn.write(buffer, false, false);
/*      */             }
/*      */             
/* 1190 */             resetCreditManager = true;
/*      */           }
/*      */           
/* 1193 */           this.channel.returnBlocking(cause);
/*      */         }
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/* 1198 */         HornetQClientLogger.LOGGER.failedToHandleFailover(t);
/*      */       }
/*      */       finally
/*      */       {
/* 1202 */         this.channel.setTransferring(false);
/* 1203 */         this.channel.unlock();
/*      */       }
/*      */       
/* 1206 */       if (resetCreditManager)
/*      */       {
/* 1208 */         this.producerCreditManager.reset();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     HashMap<String, String> metaDataToSend;
/*      */     
/*      */ 
/* 1217 */     synchronized (this.metadata)
/*      */     {
/* 1219 */       metaDataToSend = new HashMap(this.metadata);
/*      */     }
/*      */     
/*      */ 
/* 1223 */     for (Map.Entry<String, String> entries : metaDataToSend.entrySet())
/*      */     {
/* 1225 */       sendPacketWithoutLock(new SessionAddMetaDataMessageV2((String)entries.getKey(), (String)entries.getValue(), false));
/*      */     }
/*      */   }
/*      */   
/*      */   public void addMetaData(String key, String data) throws HornetQException
/*      */   {
/* 1231 */     synchronized (this.metadata)
/*      */     {
/* 1233 */       this.metadata.put(key, data);
/*      */     }
/*      */     
/* 1236 */     this.channel.sendBlocking(new SessionAddMetaDataMessageV2(key, data), (byte)21);
/*      */   }
/*      */   
/*      */   public void addUniqueMetaData(String key, String data) throws HornetQException
/*      */   {
/* 1241 */     this.channel.sendBlocking(new SessionUniqueAddMetaDataMessage(key, data), (byte)21);
/*      */   }
/*      */   
/*      */   public ClientSessionFactoryInternal getSessionFactory()
/*      */   {
/* 1246 */     return this.sessionFactory;
/*      */   }
/*      */   
/*      */   public void setAddress(Message message, SimpleString address)
/*      */   {
/* 1251 */     if (this.defaultAddress == null)
/*      */     {
/* 1253 */       this.defaultAddress = address;
/*      */       
/* 1255 */       message.setAddress(address);
/*      */ 
/*      */ 
/*      */     }
/* 1259 */     else if (!address.equals(this.defaultAddress))
/*      */     {
/* 1261 */       message.setAddress(address);
/*      */     }
/*      */     else
/*      */     {
/* 1265 */       message.setAddress(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void setPacketSize(int packetSize)
/*      */   {
/* 1272 */     if (packetSize > this.initialMessagePacketSize)
/*      */     {
/* 1274 */       this.initialMessagePacketSize = ((int)(packetSize * 1.2D));
/*      */     }
/*      */   }
/*      */   
/*      */   private void sendPacketWithoutLock(Packet packet)
/*      */   {
/* 1280 */     packet.setChannelID(this.channel.getID());
/*      */     
/* 1282 */     Connection conn = this.channel.getConnection().getTransportConnection();
/*      */     
/* 1284 */     HornetQBuffer buffer = packet.encode(this.channel.getConnection());
/*      */     
/* 1286 */     conn.write(buffer, false, false);
/*      */   }
/*      */   
/*      */   public void workDone()
/*      */   {
/* 1291 */     this.workDone = true;
/*      */   }
/*      */   
/*      */   public void returnBlocking()
/*      */   {
/* 1296 */     this.channel.returnBlocking();
/*      */   }
/*      */   
/*      */   public void sendProducerCreditsMessage(int credits, SimpleString address)
/*      */   {
/* 1301 */     this.channel.send(new SessionRequestProducerCreditsMessage(credits, address));
/*      */   }
/*      */   
/*      */   public synchronized ClientProducerCredits getCredits(SimpleString address, boolean anon)
/*      */   {
/* 1306 */     return this.producerCreditManager.getCredits(address, anon);
/*      */   }
/*      */   
/*      */   public void returnCredits(SimpleString address)
/*      */   {
/* 1311 */     this.producerCreditManager.returnCredits(address);
/*      */   }
/*      */   
/*      */   public void handleReceiveProducerCredits(SimpleString address, int credits)
/*      */   {
/* 1316 */     this.producerCreditManager.receiveCredits(address, credits);
/*      */   }
/*      */   
/*      */   public void handleReceiveProducerFailCredits(SimpleString address, int credits)
/*      */   {
/* 1321 */     this.producerCreditManager.receiveFailCredits(address, credits);
/*      */   }
/*      */   
/*      */   public ClientProducerCreditManager getProducerCreditManager()
/*      */   {
/* 1326 */     return this.producerCreditManager;
/*      */   }
/*      */   
/*      */   public void startCall()
/*      */   {
/* 1331 */     if (this.concurrentCall.incrementAndGet() > 1)
/*      */     {
/* 1333 */       HornetQClientLogger.LOGGER.invalidConcurrentSessionUsage(new Exception("trace"));
/*      */     }
/*      */   }
/*      */   
/*      */   public void endCall()
/*      */   {
/* 1339 */     this.concurrentCall.decrementAndGet();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void commandConfirmed(Packet packet)
/*      */   {
/* 1346 */     if (packet.getType() == 71)
/*      */     {
/* 1348 */       SessionSendMessage ssm = (SessionSendMessage)packet;
/*      */       
/* 1350 */       this.sendAckHandler.sendAcknowledged(ssm.getMessage());
/*      */     }
/* 1352 */     else if (packet.getType() == 73)
/*      */     {
/* 1354 */       SessionSendContinuationMessage scm = (SessionSendContinuationMessage)packet;
/* 1355 */       if (!scm.isContinues())
/*      */       {
/* 1357 */         this.sendAckHandler.sendAcknowledged(scm.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void commit(Xid xid, boolean onePhase)
/*      */     throws XAException
/*      */   {
/* 1368 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1370 */       HornetQClientLogger.LOGGER.trace("call commit(xid=" + convert(xid));
/*      */     }
/* 1372 */     checkXA();
/*      */     
/*      */ 
/* 1375 */     if (this.rollbackOnly)
/*      */     {
/* 1377 */       HornetQClientLogger.LOGGER.commitAfterFailover();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1383 */     SessionXACommitMessage packet = new SessionXACommitMessage(xid, onePhase);
/*      */     
/* 1385 */     startCall();
/*      */     try
/*      */     {
/* 1388 */       SessionXAResponseMessage response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */       
/* 1390 */       this.workDone = false;
/*      */       
/* 1392 */       if (response.isError())
/*      */       {
/* 1394 */         throw new XAException(response.getResponseCode());
/*      */       }
/*      */       
/* 1397 */       if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */       {
/* 1399 */         HornetQClientLogger.LOGGER.trace("finished commit on " + convert(xid) + " with response = " + response);
/*      */       }
/*      */     }
/*      */     catch (XAException xae)
/*      */     {
/* 1404 */       throw xae;
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1408 */       HornetQClientLogger.LOGGER.failoverDuringCommit();
/*      */       
/*      */ 
/* 1411 */       this.xaRetry = true;
/*      */       
/*      */ 
/* 1414 */       XAException xaException = new XAException(4);
/* 1415 */       xaException.initCause(t);
/* 1416 */       throw xaException;
/*      */     }
/*      */     finally
/*      */     {
/* 1420 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public void end(Xid xid, int flags) throws XAException
/*      */   {
/* 1426 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1428 */       HornetQClientLogger.LOGGER.trace("Calling end:: " + convert(xid) + ", flags=" + convertTXFlag(flags));
/*      */     }
/*      */     
/* 1431 */     checkXA();
/*      */     
/*      */     try
/*      */     {
/* 1435 */       if (this.rollbackOnly)
/*      */       {
/*      */         try
/*      */         {
/* 1439 */           rollback();
/*      */         }
/*      */         catch (Throwable ignored)
/*      */         {
/* 1443 */           HornetQClientLogger.LOGGER.debug("Error on rollback during end call!", ignored);
/*      */         }
/* 1445 */         throw new XAException(104);
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*      */         Packet packet;
/*      */         
/* 1452 */         if (flags == 33554432)
/*      */         {
/* 1454 */           packet = new PacketImpl((byte)58);
/*      */         } else { Packet packet;
/* 1456 */           if (flags == 67108864)
/*      */           {
/* 1458 */             packet = new SessionXAEndMessage(xid, false);
/*      */           } else { Packet packet;
/* 1460 */             if (flags == 536870912)
/*      */             {
/* 1462 */               packet = new SessionXAEndMessage(xid, true);
/*      */             }
/*      */             else
/*      */             {
/* 1466 */               throw new XAException(-5); }
/*      */           } }
/*      */         Packet packet;
/* 1469 */         flushAcks();
/*      */         
/*      */ 
/* 1472 */         startCall();
/*      */         SessionXAResponseMessage response;
/*      */         try {
/* 1475 */           response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */         }
/*      */         finally
/*      */         {
/* 1479 */           endCall();
/*      */         }
/*      */         
/* 1482 */         if (response.isError())
/*      */         {
/* 1484 */           throw new XAException(response.getResponseCode());
/*      */         }
/*      */       }
/*      */       catch (XAException xae)
/*      */       {
/* 1489 */         throw xae;
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/* 1493 */         HornetQClientLogger.LOGGER.errorCallingEnd(t);
/*      */         
/* 1495 */         XAException xaException = new XAException(-3);
/* 1496 */         xaException.initCause(t);
/* 1497 */         throw xaException;
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1502 */       this.currentXID = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public void forget(Xid xid) throws XAException
/*      */   {
/* 1508 */     checkXA();
/* 1509 */     startCall();
/*      */     try
/*      */     {
/* 1512 */       SessionXAResponseMessage response = (SessionXAResponseMessage)this.channel.sendBlocking(new SessionXAForgetMessage(xid), (byte)55);
/*      */       
/* 1514 */       if (response.isError())
/*      */       {
/* 1516 */         throw new XAException(response.getResponseCode());
/*      */       }
/*      */     }
/*      */     catch (XAException xae)
/*      */     {
/* 1521 */       throw xae;
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1526 */       XAException xaException = new XAException(-3);
/* 1527 */       xaException.initCause(t);
/* 1528 */       throw xaException;
/*      */     }
/*      */     finally
/*      */     {
/* 1532 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public int getTransactionTimeout() throws XAException
/*      */   {
/* 1538 */     checkXA();
/*      */     
/*      */     try
/*      */     {
/* 1542 */       SessionXAGetTimeoutResponseMessage response = (SessionXAGetTimeoutResponseMessage)this.channel.sendBlocking(new PacketImpl((byte)65), (byte)66);
/*      */       
/* 1544 */       return response.getTimeoutSeconds();
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1549 */       XAException xaException = new XAException(-3);
/* 1550 */       xaException.initCause(t);
/* 1551 */       throw xaException;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isSameRM(XAResource xares) throws XAException
/*      */   {
/* 1557 */     checkXA();
/*      */     
/* 1559 */     if (!(xares instanceof ClientSessionInternal))
/*      */     {
/* 1561 */       return false;
/*      */     }
/*      */     
/* 1564 */     if (this.forceNotSameRM)
/*      */     {
/* 1566 */       return false;
/*      */     }
/*      */     
/* 1569 */     ClientSessionInternal other = (ClientSessionInternal)xares;
/*      */     
/* 1571 */     return this.sessionFactory == other.getSessionFactory();
/*      */   }
/*      */   
/*      */   public int prepare(Xid xid) throws XAException
/*      */   {
/* 1576 */     checkXA();
/* 1577 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1579 */       HornetQClientLogger.LOGGER.trace("Calling prepare:: " + convert(xid));
/*      */     }
/*      */     
/*      */ 
/* 1583 */     if (this.rollbackOnly)
/*      */     {
/* 1585 */       throw new XAException(104);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1591 */     SessionXAPrepareMessage packet = new SessionXAPrepareMessage(xid);
/*      */     
/* 1593 */     startCall();
/*      */     try
/*      */     {
/* 1596 */       SessionXAResponseMessage response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */       
/* 1598 */       if (response.isError())
/*      */       {
/* 1600 */         throw new XAException(response.getResponseCode());
/*      */       }
/*      */       
/*      */ 
/* 1604 */       this.xaRetry = false;
/* 1605 */       return response.getResponseCode();
/*      */ 
/*      */     }
/*      */     catch (XAException xae)
/*      */     {
/* 1610 */       throw xae;
/*      */     }
/*      */     catch (HornetQException e)
/*      */     {
/* 1614 */       if (e.getType() == HornetQExceptionType.UNBLOCKED)
/*      */       {
/*      */         try
/*      */         {
/*      */ 
/* 1619 */           HornetQClientLogger.LOGGER.failoverDuringPrepare();
/* 1620 */           SessionXAResponseMessage response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */           
/* 1622 */           if (response.isError())
/*      */           {
/* 1624 */             throw new XAException(response.getResponseCode());
/*      */           }
/*      */           
/* 1627 */           this.xaRetry = false;
/* 1628 */           return response.getResponseCode();
/*      */ 
/*      */         }
/*      */         catch (Throwable t)
/*      */         {
/*      */ 
/* 1634 */           HornetQClientLogger.LOGGER.failoverDuringPrepareRollingBack();
/*      */           try
/*      */           {
/* 1637 */             rollback(false);
/*      */ 
/*      */           }
/*      */           catch (Throwable t)
/*      */           {
/* 1642 */             XAException xaException = new XAException(-3);
/* 1643 */             xaException.initCause(t);
/* 1644 */             throw xaException;
/*      */           }
/*      */           
/* 1647 */           HornetQClientLogger.LOGGER.errorDuringPrepare(e);
/*      */           
/* 1649 */           throw new XAException(104);
/*      */         }
/*      */       }
/* 1652 */       HornetQClientLogger.LOGGER.errorDuringPrepare(e);
/*      */       
/*      */ 
/* 1655 */       XAException xaException = new XAException(-3);
/* 1656 */       xaException.initCause(e);
/* 1657 */       throw xaException;
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1661 */       HornetQClientLogger.LOGGER.errorDuringPrepare(t);
/*      */       
/*      */ 
/* 1664 */       XAException xaException = new XAException(-3);
/* 1665 */       xaException.initCause(t);
/* 1666 */       throw xaException;
/*      */     }
/*      */     finally
/*      */     {
/* 1670 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   public Xid[] recover(int flags) throws XAException
/*      */   {
/* 1676 */     checkXA();
/*      */     
/* 1678 */     if ((flags & 0x1000000) == 16777216)
/*      */     {
/*      */       try
/*      */       {
/* 1682 */         SessionXAGetInDoubtXidsResponseMessage response = (SessionXAGetInDoubtXidsResponseMessage)this.channel.sendBlocking(new PacketImpl((byte)61), (byte)62);
/*      */         
/* 1684 */         List<Xid> xids = response.getXids();
/*      */         
/* 1686 */         return (Xid[])xids.toArray(new Xid[xids.size()]);
/*      */ 
/*      */ 
/*      */       }
/*      */       catch (Throwable t)
/*      */       {
/*      */ 
/* 1693 */         XAException xaException = new XAException(-3);
/* 1694 */         xaException.initCause(t);
/* 1695 */         throw xaException;
/*      */       }
/*      */     }
/*      */     
/* 1699 */     return new Xid[0];
/*      */   }
/*      */   
/*      */   public void rollback(Xid xid) throws XAException
/*      */   {
/* 1704 */     checkXA();
/*      */     
/* 1706 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1708 */       HornetQClientLogger.LOGGER.trace("Calling rollback:: " + convert(xid));
/*      */     }
/*      */     
/*      */     try
/*      */     {
/* 1713 */       boolean wasStarted = this.started;
/*      */       
/* 1715 */       if (wasStarted)
/*      */       {
/* 1717 */         stop(false);
/*      */       }
/*      */       
/*      */ 
/* 1721 */       for (ClientConsumerInternal consumer : cloneConsumers())
/*      */       {
/* 1723 */         consumer.clear(false);
/*      */       }
/*      */       
/* 1726 */       flushAcks();
/*      */       
/* 1728 */       SessionXARollbackMessage packet = new SessionXARollbackMessage(xid);
/*      */       
/*      */       SessionXAResponseMessage response;
/*      */       try
/*      */       {
/* 1733 */         response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */       }
/*      */       finally
/*      */       {
/* 1737 */         if (wasStarted)
/*      */         {
/* 1739 */           start();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1744 */       this.workDone = false;
/*      */       
/* 1746 */       if (response.isError())
/*      */       {
/* 1748 */         throw new XAException(response.getResponseCode());
/*      */       }
/*      */     }
/*      */     catch (XAException xae)
/*      */     {
/* 1753 */       throw xae;
/*      */     }
/*      */     catch (HornetQException e)
/*      */     {
/* 1757 */       if (e.getType() == HornetQExceptionType.UNBLOCKED)
/*      */       {
/*      */ 
/* 1760 */         this.xaRetry = true;
/* 1761 */         throw new XAException(4);
/*      */       }
/*      */       
/*      */ 
/* 1765 */       XAException xaException = new XAException(-3);
/* 1766 */       xaException.initCause(e);
/* 1767 */       throw xaException;
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1772 */       XAException xaException = new XAException(-3);
/* 1773 */       xaException.initCause(t);
/* 1774 */       throw xaException;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean setTransactionTimeout(int seconds) throws XAException
/*      */   {
/* 1780 */     checkXA();
/*      */     
/*      */     try
/*      */     {
/* 1784 */       SessionXASetTimeoutResponseMessage response = (SessionXASetTimeoutResponseMessage)this.channel.sendBlocking(new SessionXASetTimeoutMessage(seconds), (byte)64);
/*      */       
/* 1786 */       return response.isOK();
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1791 */       XAException xaException = new XAException(-3);
/* 1792 */       xaException.initCause(t);
/* 1793 */       throw xaException;
/*      */     }
/*      */   }
/*      */   
/*      */   public void start(Xid xid, int flags) throws XAException
/*      */   {
/* 1799 */     if (HornetQClientLogger.LOGGER.isTraceEnabled())
/*      */     {
/* 1801 */       HornetQClientLogger.LOGGER.trace("Calling start:: " + convert(xid) + " clientXID=" + xid + " flags = " + convertTXFlag(flags));
/*      */     }
/*      */     
/* 1804 */     checkXA();
/*      */     
/* 1806 */     Packet packet = null;
/*      */     
/*      */     try
/*      */     {
/* 1810 */       if (flags == 2097152)
/*      */       {
/* 1812 */         packet = new SessionXAJoinMessage(xid);
/*      */       }
/* 1814 */       else if (flags == 134217728)
/*      */       {
/* 1816 */         packet = new SessionXAResumeMessage(xid);
/*      */       }
/* 1818 */       else if (flags == 0)
/*      */       {
/*      */ 
/* 1821 */         packet = new SessionXAStartMessage(xid);
/*      */       }
/*      */       else
/*      */       {
/* 1825 */         throw new XAException(-5);
/*      */       }
/*      */       
/* 1828 */       SessionXAResponseMessage response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */       
/* 1830 */       this.currentXID = xid;
/*      */       
/* 1832 */       if (response.isError())
/*      */       {
/* 1834 */         HornetQClientLogger.LOGGER.errorCallingStart(response.getMessage(), Integer.valueOf(response.getResponseCode()));
/* 1835 */         throw new XAException(response.getResponseCode());
/*      */       }
/*      */     }
/*      */     catch (XAException xae)
/*      */     {
/* 1840 */       throw xae;
/*      */ 
/*      */     }
/*      */     catch (HornetQException e)
/*      */     {
/* 1845 */       if (e.getType() == HornetQExceptionType.UNBLOCKED)
/*      */       {
/*      */         try
/*      */         {
/* 1849 */           SessionXAResponseMessage response = (SessionXAResponseMessage)this.channel.sendBlocking(packet, (byte)55);
/*      */           
/* 1851 */           if (response.isError())
/*      */           {
/* 1853 */             HornetQClientLogger.LOGGER.errorCallingStart(response.getMessage(), Integer.valueOf(response.getResponseCode()));
/* 1854 */             throw new XAException(response.getResponseCode());
/*      */           }
/*      */         }
/*      */         catch (XAException xae)
/*      */         {
/* 1859 */           throw xae;
/*      */ 
/*      */         }
/*      */         catch (Throwable t)
/*      */         {
/* 1864 */           XAException xaException = new XAException(-3);
/* 1865 */           xaException.initCause(t);
/* 1866 */           throw xaException;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1871 */       XAException xaException = new XAException(-3);
/* 1872 */       xaException.initCause(e);
/* 1873 */       throw xaException;
/*      */ 
/*      */     }
/*      */     catch (Throwable t)
/*      */     {
/* 1878 */       XAException xaException = new XAException(-3);
/* 1879 */       xaException.initCause(t);
/* 1880 */       throw xaException;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void connectionFailed(HornetQException me, boolean failedOver)
/*      */   {
/*      */     try
/*      */     {
/* 1890 */       cleanUp(false);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1894 */       HornetQClientLogger.LOGGER.failedToCleanupSession(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForceNotSameRM(boolean force)
/*      */   {
/* 1903 */     this.forceNotSameRM = force;
/*      */   }
/*      */   
/*      */   public RemotingConnection getConnection()
/*      */   {
/* 1908 */     return this.remotingConnection;
/*      */   }
/*      */   
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1914 */     StringBuilder buffer = new StringBuilder();
/* 1915 */     synchronized (this.metadata)
/*      */     {
/* 1917 */       for (Map.Entry<String, String> entry : this.metadata.entrySet())
/*      */       {
/* 1919 */         buffer.append((String)entry.getKey() + "=" + (String)entry.getValue() + ",");
/*      */       }
/*      */     }
/*      */     
/* 1923 */     return "ClientSessionImpl [name=" + this.name + ", username=" + this.username + ", closed=" + this.closed + ", factory = " + this.sessionFactory + ", metaData=(" + buffer + ")]@" + Integer.toHexString(hashCode());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int calcWindowSize(int windowSize)
/*      */   {
/*      */     int clientWindowSize;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1938 */     if (windowSize == -1)
/*      */     {
/*      */ 
/*      */ 
/* 1942 */       clientWindowSize = -1;
/*      */     } else { int clientWindowSize;
/* 1944 */       if (windowSize == 0)
/*      */       {
/*      */ 
/* 1947 */         clientWindowSize = 0;
/*      */       } else { int clientWindowSize;
/* 1949 */         if (windowSize == 1)
/*      */         {
/*      */ 
/* 1952 */           clientWindowSize = 1;
/*      */         } else { int clientWindowSize;
/* 1954 */           if (windowSize > 1)
/*      */           {
/*      */ 
/* 1957 */             clientWindowSize = windowSize >> 1;
/*      */           }
/*      */           else
/*      */           {
/* 1961 */             throw HornetQClientMessageBundle.BUNDLE.invalidWindowSize(Integer.valueOf(windowSize)); }
/*      */         } } }
/*      */     int clientWindowSize;
/* 1964 */     return clientWindowSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClientConsumer internalCreateConsumer(SimpleString queueName, SimpleString filterString, int windowSize, int maxRate, boolean browseOnly)
/*      */     throws HornetQException
/*      */   {
/* 1981 */     checkClosed();
/*      */     
/* 1983 */     long consumerID = this.idGenerator.generateID();
/*      */     
/* 1985 */     SessionCreateConsumerMessage request = new SessionCreateConsumerMessage(consumerID, queueName, filterString, browseOnly, true);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1991 */     SessionQueueQueryResponseMessage queueInfo = (SessionQueueQueryResponseMessage)this.channel.sendBlocking(request, (byte)46);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1997 */     int clientWindowSize = calcWindowSize(windowSize);
/*      */     
/* 1999 */     ClientConsumerInternal consumer = new ClientConsumerImpl(this, consumerID, queueName, filterString, browseOnly, clientWindowSize, this.ackBatchSize, maxRate > 0 ? new TokenBucketLimiterImpl(maxRate, false) : null, this.executor, this.flowControlExecutor, this.channel, queueInfo, lookupTCCL());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2015 */     addConsumer(consumer);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2021 */     if (windowSize != 0)
/*      */     {
/* 2023 */       this.channel.send(new SessionConsumerFlowCreditMessage(consumerID, windowSize));
/*      */     }
/*      */     
/* 2026 */     return consumer;
/*      */   }
/*      */   
/*      */   private ClientProducer internalCreateProducer(SimpleString address, int maxRate) throws HornetQException
/*      */   {
/* 2031 */     checkClosed();
/*      */     
/* 2033 */     ClientProducerInternal producer = new ClientProducerImpl(this, address, maxRate == -1 ? null : new TokenBucketLimiterImpl(maxRate, false), (this.autoCommitSends) && (this.blockOnNonDurableSend), (this.autoCommitSends) && (this.blockOnDurableSend), this.autoGroup, this.groupID == null ? null : new SimpleString(this.groupID), this.minLargeMessageSize, this.channel);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2044 */     addProducer(producer);
/*      */     
/* 2046 */     return producer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void internalCreateQueue(SimpleString address, SimpleString queueName, SimpleString filterString, boolean durable, boolean temp)
/*      */     throws HornetQException
/*      */   {
/* 2055 */     checkClosed();
/*      */     
/* 2057 */     if ((durable) && (temp))
/*      */     {
/* 2059 */       throw HornetQClientMessageBundle.BUNDLE.queueMisConfigured();
/*      */     }
/*      */     
/* 2062 */     CreateQueueMessage request = new CreateQueueMessage(address, queueName, filterString, durable, temp, true);
/*      */     
/* 2064 */     startCall();
/*      */     try
/*      */     {
/* 2067 */       this.channel.sendBlocking(request, (byte)21);
/*      */     }
/*      */     finally
/*      */     {
/* 2071 */       endCall();
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkXA() throws XAException
/*      */   {
/* 2077 */     if (!this.xa)
/*      */     {
/* 2079 */       HornetQClientLogger.LOGGER.sessionNotXA();
/* 2080 */       throw new XAException(-3);
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkClosed() throws HornetQException
/*      */   {
/* 2086 */     if ((this.closed) || (this.inClose))
/*      */     {
/* 2088 */       throw HornetQClientMessageBundle.BUNDLE.sessionClosed();
/*      */     }
/*      */   }
/*      */   
/*      */   private ClassLoader lookupTCCL()
/*      */   {
/* 2094 */     (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public ClassLoader run()
/*      */       {
/* 2098 */         return Thread.currentThread().getContextClassLoader();
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ClientConsumerInternal getConsumer(long consumerID)
/*      */   {
/* 2110 */     synchronized (this.consumers)
/*      */     {
/* 2112 */       ClientConsumerInternal consumer = (ClientConsumerInternal)this.consumers.get(Long.valueOf(consumerID));
/* 2113 */       return consumer;
/*      */     }
/*      */   }
/*      */   
/*      */   private void doCleanup(boolean failingOver)
/*      */   {
/* 2119 */     if (this.remotingConnection != null)
/*      */     {
/* 2121 */       this.remotingConnection.removeFailureListener(this);
/*      */     }
/*      */     
/* 2124 */     if (HornetQClientLogger.LOGGER.isDebugEnabled())
/*      */     {
/* 2126 */       HornetQClientLogger.LOGGER.debug("calling cleanup on " + this);
/*      */     }
/*      */     
/* 2129 */     synchronized (this)
/*      */     {
/* 2131 */       this.closed = true;
/*      */       
/* 2133 */       this.channel.close();
/*      */       
/*      */ 
/*      */ 
/* 2137 */       this.channel.returnBlocking();
/*      */     }
/*      */     
/* 2140 */     this.sessionFactory.removeSession(this, failingOver);
/*      */   }
/*      */   
/*      */   private void cleanUpChildren() throws HornetQException
/*      */   {
/* 2145 */     Set<ClientConsumerInternal> consumersClone = cloneConsumers();
/*      */     
/* 2147 */     for (ClientConsumerInternal consumer : consumersClone)
/*      */     {
/* 2149 */       consumer.cleanUp();
/*      */     }
/*      */     
/* 2152 */     Set<ClientProducerInternal> producersClone = cloneProducers();
/*      */     
/* 2154 */     for (ClientProducerInternal producer : producersClone)
/*      */     {
/* 2156 */       producer.cleanUp();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private Set<ClientProducerInternal> cloneProducers()
/*      */   {
/*      */     Set<ClientProducerInternal> producersClone;
/*      */     
/*      */ 
/* 2167 */     synchronized (this.producers)
/*      */     {
/* 2169 */       producersClone = new HashSet(this.producers);
/*      */     }
/* 2171 */     return producersClone;
/*      */   }
/*      */   
/*      */   /* Error */
/*      */   private Set<ClientConsumerInternal> cloneConsumers()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield 10	org/hornetq/core/client/impl/ClientSessionImpl:consumers	Ljava/util/Map;
/*      */     //   4: dup
/*      */     //   5: astore_1
/*      */     //   6: monitorenter
/*      */     //   7: new 5	java/util/HashSet
/*      */     //   10: dup
/*      */     //   11: aload_0
/*      */     //   12: getfield 10	org/hornetq/core/client/impl/ClientSessionImpl:consumers	Ljava/util/Map;
/*      */     //   15: invokeinterface 383 1 0
/*      */     //   20: invokespecial 382	java/util/HashSet:<init>	(Ljava/util/Collection;)V
/*      */     //   23: aload_1
/*      */     //   24: monitorexit
/*      */     //   25: areturn
/*      */     //   26: astore_2
/*      */     //   27: aload_1
/*      */     //   28: monitorexit
/*      */     //   29: aload_2
/*      */     //   30: athrow
/*      */     // Line number table:
/*      */     //   Java source line #2179	-> byte code offset #0
/*      */     //   Java source line #2181	-> byte code offset #7
/*      */     //   Java source line #2182	-> byte code offset #26
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	this	ClientSessionImpl
/*      */     //   5	23	1	Ljava/lang/Object;	Object
/*      */     //   26	4	2	localObject1	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	25	26	finally
/*      */     //   26	29	26	finally
/*      */   }
/*      */   
/*      */   private void closeChildren()
/*      */     throws HornetQException
/*      */   {
/* 2187 */     Set<ClientConsumerInternal> consumersClone = cloneConsumers();
/*      */     
/* 2189 */     for (ClientConsumer consumer : consumersClone)
/*      */     {
/* 2191 */       consumer.close();
/*      */     }
/*      */     
/* 2194 */     Set<ClientProducerInternal> producersClone = cloneProducers();
/*      */     
/* 2196 */     for (ClientProducer producer : producersClone)
/*      */     {
/* 2198 */       producer.close();
/*      */     }
/*      */   }
/*      */   
/*      */   private void flushAcks() throws HornetQException
/*      */   {
/* 2204 */     for (ClientConsumerInternal consumer : cloneConsumers())
/*      */     {
/* 2206 */       consumer.flushAcks();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private static class BindingQueryImpl
/*      */     implements ClientSession.BindingQuery
/*      */   {
/*      */     private final boolean exists;
/*      */     private final ArrayList<SimpleString> queueNames;
/*      */     
/*      */     public BindingQueryImpl(boolean exists, List<SimpleString> queueNames)
/*      */     {
/* 2219 */       this.exists = exists;
/* 2220 */       this.queueNames = new ArrayList(queueNames);
/*      */     }
/*      */     
/*      */     public List<SimpleString> getQueueNames()
/*      */     {
/* 2225 */       return this.queueNames;
/*      */     }
/*      */     
/*      */     public boolean isExists()
/*      */     {
/* 2230 */       return this.exists;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private static class QueueQueryImpl
/*      */     implements ClientSession.QueueQuery
/*      */   {
/*      */     private final boolean exists;
/*      */     
/*      */ 
/*      */     private final boolean durable;
/*      */     
/*      */ 
/*      */     private final long messageCount;
/*      */     
/*      */ 
/*      */     private final SimpleString filterString;
/*      */     
/*      */     private final int consumerCount;
/*      */     
/*      */     private final SimpleString address;
/*      */     
/*      */ 
/*      */     public QueueQueryImpl(boolean durable, int consumerCount, long messageCount, SimpleString filterString, SimpleString address, boolean exists)
/*      */     {
/* 2257 */       this.durable = durable;
/* 2258 */       this.consumerCount = consumerCount;
/* 2259 */       this.messageCount = messageCount;
/* 2260 */       this.filterString = filterString;
/* 2261 */       this.address = address;
/* 2262 */       this.exists = exists;
/*      */     }
/*      */     
/*      */     public SimpleString getAddress()
/*      */     {
/* 2267 */       return this.address;
/*      */     }
/*      */     
/*      */     public int getConsumerCount()
/*      */     {
/* 2272 */       return this.consumerCount;
/*      */     }
/*      */     
/*      */     public SimpleString getFilterString()
/*      */     {
/* 2277 */       return this.filterString;
/*      */     }
/*      */     
/*      */     public long getMessageCount()
/*      */     {
/* 2282 */       return this.messageCount;
/*      */     }
/*      */     
/*      */     public boolean isDurable()
/*      */     {
/* 2287 */       return this.durable;
/*      */     }
/*      */     
/*      */     public boolean isExists()
/*      */     {
/* 2292 */       return this.exists;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Object convert(Xid xid)
/*      */   {
/* 2310 */     HornetQBuffer buffer = HornetQBuffers.dynamicBuffer(200);
/* 2311 */     XidCodecSupport.encodeXid(xid, buffer);
/*      */     
/* 2313 */     Object obj = XidCodecSupport.decodeXid(buffer);
/*      */     
/* 2315 */     return "xid=" + obj + ",clientXID=" + xid;
/*      */   }
/*      */   
/*      */   private String convertTXFlag(int flags)
/*      */   {
/* 2320 */     if (flags == 33554432)
/*      */     {
/* 2322 */       return "SESS_XA_SUSPEND";
/*      */     }
/* 2324 */     if (flags == 67108864)
/*      */     {
/* 2326 */       return "TMSUCCESS";
/*      */     }
/* 2328 */     if (flags == 536870912)
/*      */     {
/* 2330 */       return "TMFAIL";
/*      */     }
/* 2332 */     if (flags == 2097152)
/*      */     {
/* 2334 */       return "TMJOIN";
/*      */     }
/* 2336 */     if (flags == 134217728)
/*      */     {
/* 2338 */       return "TMRESUME";
/*      */     }
/* 2340 */     if (flags == 0)
/*      */     {
/*      */ 
/* 2343 */       return "TMNOFLAGS";
/*      */     }
/*      */     
/*      */ 
/* 2347 */     return "XAER_INVAL(" + flags + ")";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setStopSignal()
/*      */   {
/* 2354 */     this.mayAttemptToFailover = false;
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientSessionImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */