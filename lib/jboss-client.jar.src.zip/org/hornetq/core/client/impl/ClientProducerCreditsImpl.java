/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientProducerCreditsImpl
/*     */   implements ClientProducerCredits
/*     */ {
/*     */   private final Semaphore semaphore;
/*     */   private final int windowSize;
/*     */   private volatile boolean closed;
/*     */   private boolean blocked;
/*     */   private final SimpleString address;
/*     */   private final ClientSessionInternal session;
/*     */   private int pendingCredits;
/*     */   private int arriving;
/*     */   private int refCount;
/*     */   private boolean serverRespondedWithFail;
/*     */   
/*     */   public ClientProducerCreditsImpl(ClientSessionInternal session, SimpleString address, int windowSize)
/*     */   {
/*  55 */     this.session = session;
/*     */     
/*  57 */     this.address = address;
/*     */     
/*  59 */     this.windowSize = (windowSize / 2);
/*     */     
/*     */ 
/*     */ 
/*  63 */     this.semaphore = new Semaphore(0, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void init()
/*     */   {
/*  70 */     checkCredits(this.windowSize);
/*     */   }
/*     */   
/*     */   public void acquireCredits(int credits) throws InterruptedException, HornetQException
/*     */   {
/*  75 */     checkCredits(credits);
/*     */     
/*     */ 
/*     */     boolean tryAcquire;
/*     */     
/*  80 */     synchronized (this)
/*     */     {
/*  82 */       tryAcquire = this.semaphore.tryAcquire(credits);
/*     */     }
/*     */     
/*  85 */     if (!tryAcquire)
/*     */     {
/*  87 */       if (!this.closed)
/*     */       {
/*  89 */         this.blocked = true;
/*     */         try
/*     */         {
/*  92 */           while (!this.semaphore.tryAcquire(credits, 10L, TimeUnit.SECONDS))
/*     */           {
/*     */ 
/*     */ 
/*  96 */             HornetQClientLogger.LOGGER.outOfCreditOnFlowControl("" + this.address);
/*     */           }
/*     */         }
/*     */         finally
/*     */         {
/* 101 */           this.blocked = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 107 */     synchronized (this)
/*     */     {
/* 109 */       this.pendingCredits -= credits;
/*     */     }
/*     */     
/*     */ 
/* 113 */     synchronized (this)
/*     */     {
/* 115 */       if (this.serverRespondedWithFail)
/*     */       {
/* 117 */         this.serverRespondedWithFail = false;
/*     */         
/*     */ 
/* 120 */         this.semaphore.drainPermits();
/* 121 */         this.pendingCredits = 0;
/* 122 */         this.arriving = 0;
/*     */         
/* 124 */         throw HornetQClientMessageBundle.BUNDLE.addressIsFull(this.address.toString(), credits);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isBlocked()
/*     */   {
/* 131 */     return this.blocked;
/*     */   }
/*     */   
/*     */   public int getBalance()
/*     */   {
/* 136 */     return this.semaphore.availablePermits();
/*     */   }
/*     */   
/*     */   public void receiveCredits(int credits)
/*     */   {
/* 141 */     synchronized (this)
/*     */     {
/* 143 */       this.arriving -= credits;
/*     */     }
/*     */     
/* 146 */     this.semaphore.release(credits);
/*     */   }
/*     */   
/*     */   public void receiveFailCredits(int credits)
/*     */   {
/* 151 */     this.serverRespondedWithFail = true;
/*     */     
/* 153 */     receiveCredits(credits);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void reset()
/*     */   {
/* 160 */     this.semaphore.drainPermits();
/*     */     
/* 162 */     int beforeFailure = this.pendingCredits;
/*     */     
/* 164 */     this.pendingCredits = 0;
/* 165 */     this.arriving = 0;
/*     */     
/*     */ 
/*     */ 
/* 169 */     checkCredits(Math.max(this.windowSize * 2, beforeFailure));
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */   {
/* 175 */     this.closed = true;
/*     */     
/* 177 */     this.semaphore.release(1073741823);
/*     */   }
/*     */   
/*     */   public synchronized void incrementRefCount()
/*     */   {
/* 182 */     this.refCount += 1;
/*     */   }
/*     */   
/*     */   public synchronized int decrementRefCount()
/*     */   {
/* 187 */     return --this.refCount;
/*     */   }
/*     */   
/*     */   public synchronized void releaseOutstanding()
/*     */   {
/* 192 */     this.semaphore.drainPermits();
/*     */   }
/*     */   
/*     */   private void checkCredits(int credits)
/*     */   {
/* 197 */     int needed = Math.max(credits, this.windowSize);
/*     */     
/* 199 */     int toRequest = -1;
/*     */     
/* 201 */     synchronized (this)
/*     */     {
/* 203 */       if (this.semaphore.availablePermits() + this.arriving < needed)
/*     */       {
/* 205 */         toRequest = needed - this.arriving;
/*     */         
/* 207 */         this.pendingCredits += toRequest;
/* 208 */         this.arriving += toRequest;
/*     */       }
/*     */     }
/*     */     
/* 212 */     if (toRequest != -1)
/*     */     {
/* 214 */       requestCredits(toRequest);
/*     */     }
/*     */   }
/*     */   
/*     */   private void requestCredits(int credits)
/*     */   {
/* 220 */     this.session.sendProducerCreditsMessage(credits, this.address);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientProducerCreditsImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */