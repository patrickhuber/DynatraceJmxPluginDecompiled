/*      */ package org.hornetq.core.client.impl;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.RandomAccessFile;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.channels.FileChannel;
/*      */ import java.nio.channels.GatheringByteChannel;
/*      */ import java.nio.channels.ScatteringByteChannel;
/*      */ import java.util.concurrent.LinkedBlockingQueue;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import org.hornetq.api.core.HornetQBuffer;
/*      */ import org.hornetq.api.core.HornetQBuffers;
/*      */ import org.hornetq.api.core.HornetQException;
/*      */ import org.hornetq.api.core.HornetQExceptionType;
/*      */ import org.hornetq.api.core.HornetQInterruptedException;
/*      */ import org.hornetq.api.core.SimpleString;
/*      */ import org.hornetq.core.client.HornetQClientLogger;
/*      */ import org.hornetq.core.client.HornetQClientMessageBundle;
/*      */ import org.hornetq.core.protocol.core.Packet;
/*      */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*      */ import org.hornetq.utils.UTF8Util;
/*      */ import org.jboss.netty.buffer.ChannelBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LargeMessageControllerImpl
/*      */   implements LargeMessageController
/*      */ {
/*      */   private static final String READ_ONLY_ERROR_MESSAGE = "This is a read-only buffer, setOperations are not supported";
/*      */   private final ClientConsumerInternal consumerInternal;
/*   61 */   private final LinkedBlockingQueue<SessionReceiveContinuationMessage> packets = new LinkedBlockingQueue();
/*      */   
/*   63 */   private volatile SessionReceiveContinuationMessage currentPacket = null;
/*      */   
/*      */   private final long totalSize;
/*      */   
/*      */   private final int bufferSize;
/*      */   
/*   69 */   private boolean streamEnded = false;
/*      */   
/*   71 */   private boolean streamClosed = false;
/*      */   
/*      */   private final long readTimeout;
/*      */   
/*   75 */   private long readerIndex = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   80 */   private boolean packetAdded = false;
/*      */   
/*   82 */   private long packetPosition = -1L;
/*      */   
/*   84 */   private long lastIndex = 0L;
/*      */   
/*   86 */   private long packetLastPosition = -1L;
/*      */   
/*      */ 
/*      */   private OutputStream outStream;
/*      */   
/*      */ 
/*      */   private volatile Exception handledException;
/*      */   
/*      */   private final FileCache fileCache;
/*      */   
/*   96 */   private boolean local = false;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LargeMessageControllerImpl(ClientConsumerInternal consumerInternal, long totalSize, long readTimeout)
/*      */   {
/*  105 */     this(consumerInternal, totalSize, readTimeout, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public LargeMessageControllerImpl(ClientConsumerInternal consumerInternal, long totalSize, long readTimeout, File cachedFile)
/*      */   {
/*  113 */     this(consumerInternal, totalSize, readTimeout, cachedFile, 10240);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LargeMessageControllerImpl(ClientConsumerInternal consumerInternal, long totalSize, long readTimeout, File cachedFile, int bufferSize)
/*      */   {
/*  122 */     this.consumerInternal = consumerInternal;
/*  123 */     this.readTimeout = readTimeout;
/*  124 */     this.totalSize = totalSize;
/*  125 */     if (cachedFile == null)
/*      */     {
/*  127 */       this.fileCache = null;
/*      */     }
/*      */     else
/*      */     {
/*  131 */       this.fileCache = new FileCache(cachedFile);
/*      */     }
/*  133 */     this.bufferSize = bufferSize;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setLocal(boolean local)
/*      */   {
/*  140 */     this.local = local;
/*      */   }
/*      */   
/*      */   public void discardUnusedPackets()
/*      */   {
/*  145 */     if (this.outStream == null)
/*      */     {
/*  147 */       if (this.local) return;
/*      */       try
/*      */       {
/*  150 */         checkForPacket(this.totalSize - 1L);
/*      */       }
/*      */       catch (Throwable ignored) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addPacket(SessionReceiveContinuationMessage packet)
/*      */   {
/*  165 */     int flowControlCredit = 0;
/*  166 */     boolean continues = false;
/*      */     
/*  168 */     synchronized (this)
/*      */     {
/*  170 */       this.packetAdded = true;
/*  171 */       if (this.outStream != null)
/*      */       {
/*      */         try
/*      */         {
/*  175 */           if (!packet.isContinues())
/*      */           {
/*  177 */             this.streamEnded = true;
/*      */           }
/*      */           
/*  180 */           if (this.fileCache != null)
/*      */           {
/*  182 */             this.fileCache.cachePackage(packet.getBody());
/*      */           }
/*      */           
/*  185 */           this.outStream.write(packet.getBody());
/*      */           
/*  187 */           flowControlCredit = packet.getPacketSize();
/*      */           
/*  189 */           continues = packet.isContinues();
/*      */           
/*  191 */           notifyAll();
/*      */           
/*  193 */           if (this.streamEnded)
/*      */           {
/*  195 */             this.outStream.close();
/*      */           }
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*  200 */           HornetQClientLogger.LOGGER.errorAddingPacket(e);
/*  201 */           this.handledException = e;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  206 */         if (this.fileCache != null)
/*      */         {
/*      */           try
/*      */           {
/*  210 */             this.fileCache.cachePackage(packet.getBody());
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*  214 */             HornetQClientLogger.LOGGER.errorAddingPacket(e);
/*  215 */             this.handledException = e;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*  220 */         this.packets.offer(packet);
/*      */       }
/*      */     }
/*      */     
/*  224 */     if (flowControlCredit != 0)
/*      */     {
/*      */       try
/*      */       {
/*  228 */         this.consumerInternal.flowControl(flowControlCredit, !continues);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  232 */         HornetQClientLogger.LOGGER.errorAddingPacket(e);
/*  233 */         this.handledException = e;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void cancel()
/*      */   {
/*  240 */     this.handledException = HornetQClientMessageBundle.BUNDLE.largeMessageInterrupted();
/*      */     
/*  242 */     synchronized (this)
/*      */     {
/*  244 */       int totalSize = 0;
/*  245 */       Packet polledPacket = null;
/*  246 */       while ((polledPacket = (Packet)this.packets.poll()) != null)
/*      */       {
/*  248 */         totalSize += polledPacket.getPacketSize();
/*      */       }
/*      */       
/*      */       try
/*      */       {
/*  253 */         this.consumerInternal.flowControl(totalSize, false);
/*      */ 
/*      */       }
/*      */       catch (Exception ignored)
/*      */       {
/*  258 */         HornetQClientLogger.LOGGER.errorCallingCancel(ignored);
/*      */       }
/*      */       
/*  261 */       this.packets.offer(new SessionReceiveContinuationMessage());
/*  262 */       this.streamEnded = true;
/*  263 */       this.streamClosed = true;
/*      */       
/*  265 */       notifyAll();
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void close()
/*      */   {
/*  271 */     if (this.fileCache != null)
/*      */     {
/*  273 */       this.fileCache.close();
/*      */     }
/*      */   }
/*      */   
/*      */   public void setOutputStream(OutputStream output)
/*      */     throws HornetQException
/*      */   {
/*  280 */     int totalFlowControl = 0;
/*  281 */     boolean continues = false;
/*      */     
/*  283 */     synchronized (this)
/*      */     {
/*  285 */       if (this.currentPacket != null)
/*      */       {
/*  287 */         sendPacketToOutput(output, this.currentPacket);
/*  288 */         this.currentPacket = null;
/*      */       }
/*  290 */       while (this.handledException == null)
/*      */       {
/*  292 */         SessionReceiveContinuationMessage packet = (SessionReceiveContinuationMessage)this.packets.poll();
/*  293 */         if (packet == null) {
/*      */           break;
/*      */         }
/*      */         
/*  297 */         totalFlowControl += packet.getPacketSize();
/*      */         
/*  299 */         continues = packet.isContinues();
/*  300 */         sendPacketToOutput(output, packet);
/*      */       }
/*      */       
/*  303 */       checkException();
/*  304 */       this.outStream = output;
/*      */     }
/*      */     
/*  307 */     if (totalFlowControl > 0)
/*      */     {
/*  309 */       this.consumerInternal.flowControl(totalFlowControl, !continues);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized void saveBuffer(OutputStream output) throws HornetQException
/*      */   {
/*  315 */     if (this.streamClosed)
/*      */     {
/*  317 */       throw HornetQClientMessageBundle.BUNDLE.largeMessageLostSession();
/*      */     }
/*  319 */     setOutputStream(output);
/*  320 */     waitCompletion(0L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public synchronized boolean waitCompletion(long timeWait)
/*      */     throws HornetQException
/*      */   {
/*  329 */     if (this.outStream == null)
/*      */     {
/*      */ 
/*  332 */       return false;
/*      */     }
/*      */     
/*      */     long timeOut;
/*      */     
/*      */     long timeOut;
/*      */     
/*  339 */     if (timeWait != 0L)
/*      */     {
/*  341 */       timeOut = System.currentTimeMillis() + timeWait;
/*      */     }
/*      */     else
/*      */     {
/*  345 */       timeOut = System.currentTimeMillis() + this.readTimeout;
/*      */     }
/*      */     
/*  348 */     while ((!this.streamEnded) && (this.handledException == null))
/*      */     {
/*      */       try
/*      */       {
/*  352 */         wait(timeWait == 0L ? this.readTimeout : timeWait);
/*      */       }
/*      */       catch (InterruptedException e)
/*      */       {
/*  356 */         throw new HornetQInterruptedException(e);
/*      */       }
/*      */       
/*  359 */       if ((!this.streamEnded) && (this.handledException == null))
/*      */       {
/*  361 */         if ((timeWait != 0L) && (System.currentTimeMillis() > timeOut))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  367 */           throw HornetQClientMessageBundle.BUNDLE.timeoutOnLargeMessage();
/*      */         }
/*  369 */         if ((System.currentTimeMillis() > timeOut) && (!this.packetAdded))
/*      */         {
/*      */ 
/*      */ 
/*  373 */           throw HornetQClientMessageBundle.BUNDLE.timeoutOnLargeMessage();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  378 */     checkException();
/*      */     
/*  380 */     return this.streamEnded;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void checkException()
/*      */     throws HornetQException
/*      */   {
/*  391 */     if (this.handledException != null)
/*      */     {
/*  393 */       if ((this.handledException instanceof HornetQException))
/*      */       {
/*  395 */         throw ((HornetQException)this.handledException);
/*      */       }
/*      */       
/*      */ 
/*  399 */       throw new HornetQException(HornetQExceptionType.LARGE_MESSAGE_ERROR_BODY, "Error on saving LargeMessageBufferImpl", this.handledException);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int capacity()
/*      */   {
/*  411 */     return -1;
/*      */   }
/*      */   
/*      */   public byte readByte()
/*      */   {
/*  416 */     return getByte(this.readerIndex++);
/*      */   }
/*      */   
/*      */ 
/*      */   public byte getByte(int index)
/*      */   {
/*  422 */     return getByte(index);
/*      */   }
/*      */   
/*      */   private byte getByte(long index)
/*      */   {
/*  427 */     checkForPacket(index);
/*      */     
/*  429 */     if ((this.fileCache != null) && (index < this.packetPosition))
/*      */     {
/*  431 */       return this.fileCache.getByteFromCache(index);
/*      */     }
/*      */     
/*      */ 
/*  435 */     return this.currentPacket.getBody()[((int)(index - this.packetPosition))];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void getBytes(int index, HornetQBuffer dst, int dstIndex, int length)
/*      */   {
/*  442 */     byte[] destBytes = new byte[length];
/*  443 */     getBytes(index, destBytes);
/*  444 */     dst.setBytes(dstIndex, destBytes);
/*      */   }
/*      */   
/*      */   private void getBytes(long index, HornetQBuffer dst, int dstIndex, int length)
/*      */   {
/*  449 */     byte[] destBytes = new byte[length];
/*  450 */     getBytes(index, destBytes);
/*  451 */     dst.setBytes(dstIndex, destBytes);
/*      */   }
/*      */   
/*      */ 
/*      */   public void getBytes(int index, byte[] dst, int dstIndex, int length)
/*      */   {
/*  457 */     byte[] bytesToGet = new byte[length];
/*      */     
/*  459 */     getBytes(index, bytesToGet);
/*      */     
/*  461 */     System.arraycopy(bytesToGet, 0, dst, dstIndex, length);
/*      */   }
/*      */   
/*      */   public void getBytes(long index, byte[] dst, int dstIndex, int length)
/*      */   {
/*  466 */     byte[] bytesToGet = new byte[length];
/*      */     
/*  468 */     getBytes(index, bytesToGet);
/*      */     
/*  470 */     System.arraycopy(bytesToGet, 0, dst, dstIndex, length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void getBytes(int index, ByteBuffer dst)
/*      */   {
/*  476 */     byte[] bytesToGet = new byte[dst.remaining()];
/*  477 */     getBytes(index, bytesToGet);
/*  478 */     dst.put(bytesToGet);
/*      */   }
/*      */   
/*      */   public void getBytes(long index, ByteBuffer dst)
/*      */   {
/*  483 */     byte[] bytesToGet = new byte[dst.remaining()];
/*  484 */     getBytes(index, bytesToGet);
/*  485 */     dst.put(bytesToGet);
/*      */   }
/*      */   
/*      */   public void getBytes(int index, OutputStream out, int length) throws IOException
/*      */   {
/*  490 */     byte[] bytesToGet = new byte[length];
/*  491 */     getBytes(index, bytesToGet);
/*  492 */     out.write(bytesToGet);
/*      */   }
/*      */   
/*      */   public void getBytes(long index, OutputStream out, int length) throws IOException
/*      */   {
/*  497 */     byte[] bytesToGet = new byte[length];
/*  498 */     getBytes(index, bytesToGet);
/*  499 */     out.write(bytesToGet);
/*      */   }
/*      */   
/*      */   public int getBytes(int index, GatheringByteChannel out, int length) throws IOException
/*      */   {
/*  504 */     byte[] bytesToGet = new byte[length];
/*  505 */     getBytes(index, bytesToGet);
/*  506 */     return out.write(ByteBuffer.wrap(bytesToGet));
/*      */   }
/*      */   
/*      */   public int getInt(int index)
/*      */   {
/*  511 */     return (getByte(index) & 0xFF) << 24 | (getByte(index + 1) & 0xFF) << 16 | (getByte(index + 2) & 0xFF) << 8 | (getByte(index + 3) & 0xFF) << 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getInt(long index)
/*      */   {
/*  518 */     return (getByte(index) & 0xFF) << 24 | (getByte(index + 1L) & 0xFF) << 16 | (getByte(index + 2L) & 0xFF) << 8 | (getByte(index + 3L) & 0xFF) << 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(int index)
/*      */   {
/*  526 */     return (getByte(index) & 0xFF) << 56 | (getByte(index + 1) & 0xFF) << 48 | (getByte(index + 2) & 0xFF) << 40 | (getByte(index + 3) & 0xFF) << 32 | (getByte(index + 4) & 0xFF) << 24 | (getByte(index + 5) & 0xFF) << 16 | (getByte(index + 6) & 0xFF) << 8 | (getByte(index + 7) & 0xFF) << 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long getLong(long index)
/*      */   {
/*  537 */     return (getByte(index) & 0xFF) << 56 | (getByte(index + 1L) & 0xFF) << 48 | (getByte(index + 2L) & 0xFF) << 40 | (getByte(index + 3L) & 0xFF) << 32 | (getByte(index + 4L) & 0xFF) << 24 | (getByte(index + 5L) & 0xFF) << 16 | (getByte(index + 6L) & 0xFF) << 8 | (getByte(index + 7L) & 0xFF) << 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public short getShort(int index)
/*      */   {
/*  549 */     return (short)(getByte(index) << 8 | getByte(index + 1) & 0xFF);
/*      */   }
/*      */   
/*      */   public short getShort(long index)
/*      */   {
/*  554 */     return (short)(getByte(index) << 8 | getByte(index + 1L) & 0xFF);
/*      */   }
/*      */   
/*      */   private int getUnsignedMedium(int index)
/*      */   {
/*  559 */     return (getByte(index) & 0xFF) << 16 | (getByte(index + 1) & 0xFF) << 8 | (getByte(index + 2) & 0xFF) << 0;
/*      */   }
/*      */   
/*      */   public int getUnsignedMedium(long index)
/*      */   {
/*  564 */     return (getByte(index) & 0xFF) << 16 | (getByte(index + 1L) & 0xFF) << 8 | (getByte(index + 2L) & 0xFF) << 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public void setByte(int index, byte value)
/*      */   {
/*  570 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(int index, HornetQBuffer src, int srcIndex, int length)
/*      */   {
/*  576 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(int index, byte[] src, int srcIndex, int length)
/*      */   {
/*  582 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setBytes(int index, ByteBuffer src)
/*      */   {
/*  588 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setInt(int index, int value)
/*      */   {
/*  594 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setLong(int index, long value)
/*      */   {
/*  600 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void setShort(int index, short value)
/*      */   {
/*  606 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public ByteBuffer toByteBuffer(int index, int length)
/*      */   {
/*  612 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public int readerIndex()
/*      */   {
/*  617 */     return (int)this.readerIndex;
/*      */   }
/*      */   
/*      */   public void readerIndex(int readerIndex)
/*      */   {
/*      */     try
/*      */     {
/*  624 */       checkForPacket(readerIndex);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  628 */       HornetQClientLogger.LOGGER.errorReadingIndex(e);
/*  629 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*  631 */     this.readerIndex = readerIndex;
/*      */   }
/*      */   
/*      */   public int writerIndex()
/*      */   {
/*  636 */     return (int)this.totalSize;
/*      */   }
/*      */   
/*      */   public long getSize()
/*      */   {
/*  641 */     return this.totalSize;
/*      */   }
/*      */   
/*      */   public void writerIndex(int writerIndex)
/*      */   {
/*  646 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setIndex(int readerIndex, int writerIndex)
/*      */   {
/*      */     try
/*      */     {
/*  653 */       checkForPacket(readerIndex);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  657 */       HornetQClientLogger.LOGGER.errorSettingIndex(e);
/*  658 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*  660 */     this.readerIndex = readerIndex;
/*      */   }
/*      */   
/*      */ 
/*      */   public void clear() {}
/*      */   
/*      */ 
/*      */   public boolean readable()
/*      */   {
/*  669 */     return true;
/*      */   }
/*      */   
/*      */   public boolean writable()
/*      */   {
/*  674 */     return false;
/*      */   }
/*      */   
/*      */   public int readableBytes()
/*      */   {
/*  679 */     long readableBytes = this.totalSize - this.readerIndex;
/*      */     
/*  681 */     if (readableBytes > 2147483647L)
/*      */     {
/*  683 */       return Integer.MAX_VALUE;
/*      */     }
/*      */     
/*      */ 
/*  687 */     return (int)(this.totalSize - this.readerIndex);
/*      */   }
/*      */   
/*      */ 
/*      */   public int writableBytes()
/*      */   {
/*  693 */     return 0;
/*      */   }
/*      */   
/*      */   public void markReaderIndex()
/*      */   {
/*  698 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void resetReaderIndex()
/*      */   {
/*      */     try
/*      */     {
/*  705 */       checkForPacket(0L);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  709 */       HornetQClientLogger.LOGGER.errorReSettingIndex(e);
/*  710 */       throw new RuntimeException(e.getMessage(), e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void markWriterIndex()
/*      */   {
/*  716 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void resetWriterIndex()
/*      */   {
/*  721 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void discardReadBytes()
/*      */   {
/*  726 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public short getUnsignedByte(int index)
/*      */   {
/*  731 */     return (short)(getByte(index) & 0xFF);
/*      */   }
/*      */   
/*      */   public int getUnsignedShort(int index)
/*      */   {
/*  736 */     return getShort(index) & 0xFFFF;
/*      */   }
/*      */   
/*      */   public int getMedium(int index)
/*      */   {
/*  741 */     int value = getUnsignedMedium(index);
/*  742 */     if ((value & 0x800000) != 0)
/*      */     {
/*  744 */       value |= 0xFF000000;
/*      */     }
/*  746 */     return value;
/*      */   }
/*      */   
/*      */   public long getUnsignedInt(int index)
/*      */   {
/*  751 */     return getInt(index) & 0xFFFFFFFF;
/*      */   }
/*      */   
/*      */ 
/*      */   public void getBytes(int index, byte[] dst)
/*      */   {
/*  757 */     for (int i = 0; i < dst.length; i++)
/*      */     {
/*  759 */       dst[i] = getByte(index++);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void getBytes(long index, byte[] dst)
/*      */   {
/*  766 */     for (int i = 0; i < dst.length; i++)
/*      */     {
/*  768 */       dst[i] = getByte(index++);
/*      */     }
/*      */   }
/*      */   
/*      */   public void getBytes(int index, HornetQBuffer dst)
/*      */   {
/*  774 */     getBytes(index, dst, dst.writableBytes());
/*      */   }
/*      */   
/*      */   public void getBytes(int index, HornetQBuffer dst, int length)
/*      */   {
/*  779 */     if (length > dst.writableBytes())
/*      */     {
/*  781 */       throw new IndexOutOfBoundsException();
/*      */     }
/*  783 */     getBytes(index, dst, dst.writerIndex(), length);
/*  784 */     dst.writerIndex(dst.writerIndex() + length);
/*      */   }
/*      */   
/*      */   public void setBytes(int index, byte[] src)
/*      */   {
/*  789 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setBytes(int index, HornetQBuffer src)
/*      */   {
/*  794 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setBytes(int index, HornetQBuffer src, int length)
/*      */   {
/*  799 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setZero(int index, int length)
/*      */   {
/*  804 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public short readUnsignedByte()
/*      */   {
/*  809 */     return (short)(readByte() & 0xFF);
/*      */   }
/*      */   
/*      */   public short readShort()
/*      */   {
/*  814 */     short v = getShort(this.readerIndex);
/*  815 */     this.readerIndex += 2L;
/*  816 */     return v;
/*      */   }
/*      */   
/*      */   public int readUnsignedShort()
/*      */   {
/*  821 */     return readShort() & 0xFFFF;
/*      */   }
/*      */   
/*      */   public int readMedium()
/*      */   {
/*  826 */     int value = readUnsignedMedium();
/*  827 */     if ((value & 0x800000) != 0)
/*      */     {
/*  829 */       value |= 0xFF000000;
/*      */     }
/*  831 */     return value;
/*      */   }
/*      */   
/*      */   public int readUnsignedMedium()
/*      */   {
/*  836 */     int v = getUnsignedMedium(this.readerIndex);
/*  837 */     this.readerIndex += 3L;
/*  838 */     return v;
/*      */   }
/*      */   
/*      */   public int readInt()
/*      */   {
/*  843 */     int v = getInt(this.readerIndex);
/*  844 */     this.readerIndex += 4L;
/*  845 */     return v;
/*      */   }
/*      */   
/*      */   public int readInt(int pos)
/*      */   {
/*  850 */     int v = getInt(pos);
/*  851 */     return v;
/*      */   }
/*      */   
/*      */   public long readUnsignedInt()
/*      */   {
/*  856 */     return readInt() & 0xFFFFFFFF;
/*      */   }
/*      */   
/*      */   public long readLong()
/*      */   {
/*  861 */     long v = getLong(this.readerIndex);
/*  862 */     this.readerIndex += 8L;
/*  863 */     return v;
/*      */   }
/*      */   
/*      */   public void readBytes(byte[] dst, int dstIndex, int length)
/*      */   {
/*  868 */     getBytes(this.readerIndex, dst, dstIndex, length);
/*  869 */     this.readerIndex += length;
/*      */   }
/*      */   
/*      */   public void readBytes(byte[] dst)
/*      */   {
/*  874 */     readBytes(dst, 0, dst.length);
/*      */   }
/*      */   
/*      */   public void readBytes(HornetQBuffer dst)
/*      */   {
/*  879 */     readBytes(dst, dst.writableBytes());
/*      */   }
/*      */   
/*      */   public void readBytes(HornetQBuffer dst, int length)
/*      */   {
/*  884 */     if (length > dst.writableBytes())
/*      */     {
/*  886 */       throw new IndexOutOfBoundsException();
/*      */     }
/*  888 */     readBytes(dst, dst.writerIndex(), length);
/*  889 */     dst.writerIndex(dst.writerIndex() + length);
/*      */   }
/*      */   
/*      */   public void readBytes(HornetQBuffer dst, int dstIndex, int length)
/*      */   {
/*  894 */     getBytes(this.readerIndex, dst, dstIndex, length);
/*  895 */     this.readerIndex += length;
/*      */   }
/*      */   
/*      */   public void readBytes(ByteBuffer dst)
/*      */   {
/*  900 */     int length = dst.remaining();
/*  901 */     getBytes(this.readerIndex, dst);
/*  902 */     this.readerIndex += length;
/*      */   }
/*      */   
/*      */   public int readBytes(GatheringByteChannel out, int length) throws IOException
/*      */   {
/*  907 */     int readBytes = getBytes((int)this.readerIndex, out, length);
/*  908 */     this.readerIndex += readBytes;
/*  909 */     return readBytes;
/*      */   }
/*      */   
/*      */   public void readBytes(OutputStream out, int length) throws IOException
/*      */   {
/*  914 */     getBytes(this.readerIndex, out, length);
/*  915 */     this.readerIndex += length;
/*      */   }
/*      */   
/*      */ 
/*      */   public void skipBytes(int length)
/*      */   {
/*  921 */     long newReaderIndex = this.readerIndex + length;
/*  922 */     checkForPacket(newReaderIndex);
/*  923 */     this.readerIndex = newReaderIndex;
/*      */   }
/*      */   
/*      */   public void writeByte(byte value)
/*      */   {
/*  928 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeShort(short value)
/*      */   {
/*  933 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeMedium(int value)
/*      */   {
/*  938 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeInt(int value)
/*      */   {
/*  943 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeLong(long value)
/*      */   {
/*  948 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeBytes(byte[] src, int srcIndex, int length)
/*      */   {
/*  953 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeBytes(byte[] src)
/*      */   {
/*  958 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeBytes(HornetQBuffer src)
/*      */   {
/*  963 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeBytes(HornetQBuffer src, int length)
/*      */   {
/*  968 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeBytes(ByteBuffer src)
/*      */   {
/*  973 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public int writeBytes(InputStream in, int length) throws IOException
/*      */   {
/*  978 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public int writeBytes(ScatteringByteChannel in, int length) throws IOException
/*      */   {
/*  983 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeZero(int length)
/*      */   {
/*  988 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public ByteBuffer toByteBuffer()
/*      */   {
/*  993 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public ByteBuffer[] toByteBuffers()
/*      */   {
/*  998 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public ByteBuffer[] toByteBuffers(int index, int length)
/*      */   {
/* 1003 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public String toString(String charsetName)
/*      */   {
/* 1008 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public Object getUnderlyingBuffer()
/*      */   {
/* 1013 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean readBoolean()
/*      */   {
/* 1019 */     return readByte() != 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public char readChar()
/*      */   {
/* 1025 */     return (char)readShort();
/*      */   }
/*      */   
/*      */   public char getChar(int index)
/*      */   {
/* 1030 */     return (char)getShort(index);
/*      */   }
/*      */   
/*      */   public double getDouble(int index)
/*      */   {
/* 1035 */     return Double.longBitsToDouble(getLong(index));
/*      */   }
/*      */   
/*      */   public float getFloat(int index)
/*      */   {
/* 1040 */     return Float.intBitsToFloat(getInt(index));
/*      */   }
/*      */   
/*      */   public HornetQBuffer readBytes(int length)
/*      */   {
/* 1045 */     byte[] bytesToGet = new byte[length];
/* 1046 */     getBytes(this.readerIndex, bytesToGet);
/* 1047 */     this.readerIndex += length;
/* 1048 */     return HornetQBuffers.wrappedBuffer(bytesToGet);
/*      */   }
/*      */   
/*      */ 
/*      */   public double readDouble()
/*      */   {
/* 1054 */     return Double.longBitsToDouble(readLong());
/*      */   }
/*      */   
/*      */ 
/*      */   public float readFloat()
/*      */   {
/* 1060 */     return Float.intBitsToFloat(readInt());
/*      */   }
/*      */   
/*      */ 
/*      */   public SimpleString readNullableSimpleString()
/*      */   {
/* 1066 */     int b = readByte();
/* 1067 */     if (b == 0)
/*      */     {
/* 1069 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1073 */     return readSimpleString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String readNullableString()
/*      */   {
/* 1080 */     int b = readByte();
/* 1081 */     if (b == 0)
/*      */     {
/* 1083 */       return null;
/*      */     }
/*      */     
/*      */ 
/* 1087 */     return readString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public SimpleString readSimpleString()
/*      */   {
/* 1094 */     int len = readInt();
/* 1095 */     byte[] data = new byte[len];
/* 1096 */     readBytes(data);
/* 1097 */     return new SimpleString(data);
/*      */   }
/*      */   
/*      */ 
/*      */   public String readString()
/*      */   {
/* 1103 */     int len = readInt();
/*      */     
/* 1105 */     if (len < 9)
/*      */     {
/* 1107 */       char[] chars = new char[len];
/* 1108 */       for (int i = 0; i < len; i++)
/*      */       {
/* 1110 */         chars[i] = ((char)readShort());
/*      */       }
/* 1112 */       return new String(chars);
/*      */     }
/* 1114 */     if (len < 4095)
/*      */     {
/* 1116 */       return readUTF();
/*      */     }
/*      */     
/*      */ 
/* 1120 */     return readSimpleString().toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String readUTF()
/*      */   {
/* 1127 */     return UTF8Util.readUTF(this);
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeBoolean(boolean val)
/*      */   {
/* 1133 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeChar(char val)
/*      */   {
/* 1139 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeDouble(double val)
/*      */   {
/* 1145 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void writeFloat(float val)
/*      */   {
/* 1152 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void writeNullableSimpleString(SimpleString val)
/*      */   {
/* 1159 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeNullableString(String val)
/*      */   {
/* 1165 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeSimpleString(SimpleString val)
/*      */   {
/* 1171 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeString(String val)
/*      */   {
/* 1177 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */ 
/*      */   public void writeUTF(String utf)
/*      */   {
/* 1183 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public HornetQBuffer copy()
/*      */   {
/* 1188 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public HornetQBuffer slice(int index, int length)
/*      */   {
/* 1193 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void sendPacketToOutput(OutputStream output, SessionReceiveContinuationMessage packet)
/*      */     throws HornetQException
/*      */   {
/*      */     try
/*      */     {
/* 1205 */       output.write(packet.getBody());
/* 1206 */       if (!packet.isContinues())
/*      */       {
/* 1208 */         this.streamEnded = true;
/* 1209 */         output.close();
/*      */       }
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1214 */       throw HornetQClientMessageBundle.BUNDLE.errorWritingLargeMessage(e);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   private void popPacket()
/*      */   {
/*      */     try
/*      */     {
/* 1223 */       if (this.streamEnded)
/*      */       {
/*      */ 
/* 1226 */         throw new IndexOutOfBoundsException();
/*      */       }
/*      */       
/* 1229 */       int sizeToAdd = this.currentPacket != null ? this.currentPacket.getBody().length : 1;
/* 1230 */       this.currentPacket = ((SessionReceiveContinuationMessage)this.packets.poll(this.readTimeout, TimeUnit.SECONDS));
/* 1231 */       if (this.currentPacket == null)
/*      */       {
/* 1233 */         throw new IndexOutOfBoundsException();
/*      */       }
/*      */       
/* 1236 */       if (this.currentPacket.getBody() == null)
/*      */       {
/* 1238 */         this.currentPacket = null;
/* 1239 */         this.streamEnded = true;
/* 1240 */         throw new IndexOutOfBoundsException();
/*      */       }
/*      */       
/* 1243 */       this.consumerInternal.flowControl(this.currentPacket.getPacketSize(), !this.currentPacket.isContinues());
/*      */       
/* 1245 */       this.packetPosition += sizeToAdd;
/*      */       
/* 1247 */       this.packetLastPosition = (this.packetPosition + this.currentPacket.getBody().length);
/*      */     }
/*      */     catch (IndexOutOfBoundsException e)
/*      */     {
/* 1251 */       throw e;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1255 */       throw new RuntimeException(e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkForPacket(long index)
/*      */   {
/* 1261 */     if (this.outStream != null)
/*      */     {
/* 1263 */       throw new IllegalAccessError("Can't read the messageBody after setting outputStream");
/*      */     }
/*      */     
/* 1266 */     if (index >= this.totalSize)
/*      */     {
/* 1268 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/* 1271 */     if (this.streamClosed)
/*      */     {
/* 1273 */       throw new IllegalAccessError("The consumer associated with this large message was closed before the body was read");
/*      */     }
/*      */     
/* 1276 */     if (this.fileCache == null)
/*      */     {
/* 1278 */       if (index < this.lastIndex)
/*      */       {
/* 1280 */         throw new IllegalAccessError("LargeMessage have read-only and one-way buffers");
/*      */       }
/* 1282 */       this.lastIndex = index;
/*      */     }
/*      */     
/* 1285 */     while ((index >= this.packetLastPosition) && (!this.streamEnded))
/*      */     {
/* 1287 */       popPacket();
/*      */     }
/*      */   }
/*      */   
/*      */   private final class FileCache
/*      */   {
/*      */     ByteBuffer readCache;
/*      */     
/*      */     public FileCache(File cachedFile) {
/* 1296 */       this.cachedFile = cachedFile;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1301 */     long readCachePositionStart = 2147483647L;
/*      */     
/* 1303 */     long readCachePositionEnd = -1L;
/*      */     
/*      */     private final File cachedFile;
/*      */     
/*      */     private volatile RandomAccessFile cachedRAFile;
/*      */     
/*      */     private volatile FileChannel cachedChannel;
/*      */     
/*      */ 
/*      */     private synchronized void readCache(long position)
/*      */     {
/*      */       try
/*      */       {
/* 1316 */         if ((position < this.readCachePositionStart) || (position > this.readCachePositionEnd))
/*      */         {
/*      */ 
/* 1319 */           checkOpen();
/*      */           
/* 1321 */           if (position > this.cachedChannel.size())
/*      */           {
/* 1323 */             throw new ArrayIndexOutOfBoundsException("position > " + this.cachedChannel.size());
/*      */           }
/*      */           
/* 1326 */           this.readCachePositionStart = (position / LargeMessageControllerImpl.this.bufferSize * LargeMessageControllerImpl.this.bufferSize);
/*      */           
/* 1328 */           this.cachedChannel.position(this.readCachePositionStart);
/*      */           
/* 1330 */           if (this.readCache == null)
/*      */           {
/* 1332 */             this.readCache = ByteBuffer.allocate(LargeMessageControllerImpl.this.bufferSize);
/*      */           }
/*      */           
/* 1335 */           this.readCache.clear();
/*      */           
/* 1337 */           this.readCachePositionEnd = (this.readCachePositionStart + this.cachedChannel.read(this.readCache) - 1L);
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/* 1342 */         HornetQClientLogger.LOGGER.errorReadingCache(e);
/* 1343 */         throw new RuntimeException(e.getMessage(), e);
/*      */       }
/*      */       finally
/*      */       {
/* 1347 */         close();
/*      */       }
/*      */     }
/*      */     
/*      */     public synchronized byte getByteFromCache(long position)
/*      */     {
/* 1353 */       readCache(position);
/*      */       
/* 1355 */       return this.readCache.get((int)(position - this.readCachePositionStart));
/*      */     }
/*      */     
/*      */     public void cachePackage(byte[] body)
/*      */       throws Exception
/*      */     {
/* 1361 */       checkOpen();
/*      */       
/* 1363 */       this.cachedChannel.position(this.cachedChannel.size());
/* 1364 */       this.cachedChannel.write(ByteBuffer.wrap(body));
/*      */       
/* 1366 */       close();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public void checkOpen()
/*      */       throws FileNotFoundException
/*      */     {
/* 1374 */       if ((this.cachedFile != null) || (!this.cachedChannel.isOpen()))
/*      */       {
/* 1376 */         this.cachedRAFile = new RandomAccessFile(this.cachedFile, "rw");
/*      */         
/* 1378 */         this.cachedChannel = this.cachedRAFile.getChannel();
/*      */       }
/*      */     }
/*      */     
/*      */     public void close()
/*      */     {
/* 1384 */       if ((this.cachedChannel != null) && (this.cachedChannel.isOpen()))
/*      */       {
/*      */         try
/*      */         {
/* 1388 */           this.cachedChannel.close();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1392 */           HornetQClientLogger.LOGGER.errorClosingCache(e);
/*      */         }
/* 1394 */         this.cachedChannel = null;
/*      */       }
/*      */       
/* 1397 */       if (this.cachedRAFile != null)
/*      */       {
/*      */         try
/*      */         {
/* 1401 */           this.cachedRAFile.close();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1405 */           HornetQClientLogger.LOGGER.errorClosingCache(e);
/*      */         }
/* 1407 */         this.cachedRAFile = null;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     protected void finalize()
/*      */     {
/* 1415 */       close();
/* 1416 */       if ((this.cachedFile != null) && (this.cachedFile.exists()))
/*      */       {
/*      */         try
/*      */         {
/* 1420 */           this.cachedFile.delete();
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/* 1424 */           HornetQClientLogger.LOGGER.errorFinalisingCache(e);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public ChannelBuffer channelBuffer()
/*      */   {
/* 1433 */     return null;
/*      */   }
/*      */   
/*      */   public HornetQBuffer copy(int index, int length)
/*      */   {
/* 1438 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public HornetQBuffer duplicate()
/*      */   {
/* 1443 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public HornetQBuffer readSlice(int length)
/*      */   {
/* 1448 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setChar(int index, char value)
/*      */   {
/* 1453 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setDouble(int index, double value)
/*      */   {
/* 1458 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void setFloat(int index, float value)
/*      */   {
/* 1463 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public HornetQBuffer slice()
/*      */   {
/* 1468 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */   
/*      */   public void writeBytes(HornetQBuffer src, int srcIndex, int length)
/*      */   {
/* 1473 */     throw new IllegalAccessError("This is a read-only buffer, setOperations are not supported");
/*      */   }
/*      */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\LargeMessageControllerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */