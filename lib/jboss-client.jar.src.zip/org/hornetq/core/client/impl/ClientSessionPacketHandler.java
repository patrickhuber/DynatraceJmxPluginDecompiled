/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.protocol.core.Channel;
/*     */ import org.hornetq.core.protocol.core.ChannelHandler;
/*     */ import org.hornetq.core.protocol.core.Packet;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.HornetQExceptionMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionProducerCreditsFailMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionProducerCreditsMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveContinuationMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveLargeMessage;
/*     */ import org.hornetq.core.protocol.core.impl.wireformat.SessionReceiveMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ClientSessionPacketHandler
/*     */   implements ChannelHandler
/*     */ {
/*     */   private final ClientSessionInternal clientSession;
/*     */   private final Channel channel;
/*     */   
/*     */   ClientSessionPacketHandler(ClientSessionInternal clientSesssion, Channel channel)
/*     */   {
/*  48 */     this.clientSession = clientSesssion;
/*     */     
/*  50 */     this.channel = channel;
/*     */   }
/*     */   
/*     */   public void handlePacket(Packet packet)
/*     */   {
/*  55 */     byte type = packet.getType();
/*     */     
/*     */     try
/*     */     {
/*  59 */       switch (type)
/*     */       {
/*     */ 
/*     */       case 77: 
/*  63 */         SessionReceiveContinuationMessage continuation = (SessionReceiveContinuationMessage)packet;
/*     */         
/*  65 */         this.clientSession.handleReceiveContinuation(continuation.getConsumerID(), continuation);
/*     */         
/*  67 */         break;
/*     */       
/*     */ 
/*     */       case 75: 
/*  71 */         SessionReceiveMessage message = (SessionReceiveMessage)packet;
/*     */         
/*  73 */         this.clientSession.handleReceiveMessage(message.getConsumerID(), message);
/*     */         
/*  75 */         break;
/*     */       
/*     */ 
/*     */       case 76: 
/*  79 */         SessionReceiveLargeMessage message = (SessionReceiveLargeMessage)packet;
/*     */         
/*  81 */         this.clientSession.handleReceiveLargeMessage(message.getConsumerID(), message);
/*     */         
/*  83 */         break;
/*     */       
/*     */ 
/*     */       case 80: 
/*  87 */         SessionProducerCreditsMessage message = (SessionProducerCreditsMessage)packet;
/*     */         
/*  89 */         this.clientSession.handleReceiveProducerCredits(message.getAddress(), message.getCredits());
/*     */         
/*  91 */         break;
/*     */       
/*     */ 
/*     */       case 82: 
/*  95 */         SessionProducerCreditsFailMessage message = (SessionProducerCreditsFailMessage)packet;
/*     */         
/*  97 */         this.clientSession.handleReceiveProducerFailCredits(message.getAddress(), message.getCredits());
/*     */         
/*  99 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */       case 20: 
/* 105 */         HornetQExceptionMessage mem = (HornetQExceptionMessage)packet;
/*     */         
/* 107 */         HornetQClientLogger.LOGGER.receivedExceptionAsynchronously(mem.getException());
/*     */         
/* 109 */         break;
/*     */       
/*     */ 
/*     */       default: 
/* 113 */         throw new IllegalStateException("Invalid packet: " + type);
/*     */       }
/*     */       
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 119 */       HornetQClientLogger.LOGGER.failedToHandlePacket(e);
/*     */     }
/*     */     
/* 122 */     this.channel.confirm(packet);
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientSessionPacketHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */