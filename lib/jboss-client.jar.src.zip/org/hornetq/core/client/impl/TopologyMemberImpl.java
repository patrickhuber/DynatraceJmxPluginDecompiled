/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import org.hornetq.api.core.Pair;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.api.core.client.TopologyMember;
/*     */ import org.hornetq.spi.core.protocol.RemotingConnection;
/*     */ import org.hornetq.spi.core.remoting.Connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TopologyMemberImpl
/*     */   implements TopologyMember
/*     */ {
/*     */   private static final long serialVersionUID = 1123652191795626133L;
/*     */   private final Pair<TransportConfiguration, TransportConfiguration> connector;
/*     */   private final String nodeName;
/*  35 */   private transient long uniqueEventID = System.currentTimeMillis();
/*     */   
/*     */   private final String nodeId;
/*     */   
/*     */ 
/*     */   public TopologyMemberImpl(String nodeId, String nodeName, TransportConfiguration a, TransportConfiguration b)
/*     */   {
/*  42 */     this.nodeId = nodeId;
/*  43 */     this.nodeName = nodeName;
/*  44 */     this.connector = new Pair(a, b);
/*  45 */     this.uniqueEventID = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */ 
/*     */   public TransportConfiguration getLive()
/*     */   {
/*  51 */     return (TransportConfiguration)this.connector.getA();
/*     */   }
/*     */   
/*     */ 
/*     */   public TransportConfiguration getBackup()
/*     */   {
/*  57 */     return (TransportConfiguration)this.connector.getB();
/*     */   }
/*     */   
/*     */   public void setBackup(TransportConfiguration param)
/*     */   {
/*  62 */     this.connector.setB(param);
/*     */   }
/*     */   
/*     */   public void setLive(TransportConfiguration param)
/*     */   {
/*  67 */     this.connector.setA(param);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getNodeId()
/*     */   {
/*  73 */     return this.nodeId;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getUniqueEventID()
/*     */   {
/*  79 */     return this.uniqueEventID;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getBackupGroupName()
/*     */   {
/*  85 */     return this.nodeName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUniqueEventID(long uniqueEventID)
/*     */   {
/*  93 */     this.uniqueEventID = uniqueEventID;
/*     */   }
/*     */   
/*     */   public Pair<TransportConfiguration, TransportConfiguration> getConnector()
/*     */   {
/*  98 */     return this.connector;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isMember(RemotingConnection connection)
/*     */   {
/* 104 */     TransportConfiguration connectorConfig = connection.getTransportConnection() != null ? connection.getTransportConnection().getConnectorConfig() : null;
/*     */     
/* 106 */     return isMember(connectorConfig);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isMember(TransportConfiguration configuration)
/*     */   {
/* 112 */     if (((getConnector().getA() != null) && (((TransportConfiguration)getConnector().getA()).equals(configuration))) || ((getConnector().getB() != null) && (((TransportConfiguration)getConnector().getB()).equals(configuration))))
/*     */     {
/*     */ 
/* 115 */       return true;
/*     */     }
/*     */     
/*     */ 
/* 119 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 127 */     return "TopologyMember[name = " + this.nodeName + ", connector=" + this.connector + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\TopologyMemberImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */