package org.hornetq.core.client.impl;

import org.hornetq.api.core.client.ClientMessage;
import org.hornetq.core.message.impl.MessageInternal;

public abstract interface ClientMessageInternal
  extends ClientMessage, MessageInternal
{
  public abstract int getFlowControlSize();
  
  public abstract void setFlowControlSize(int paramInt);
  
  public abstract void onReceipt(ClientConsumerInternal paramClientConsumerInternal);
  
  public abstract void discardBody();
  
  public abstract boolean isCompressed();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientMessageInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */