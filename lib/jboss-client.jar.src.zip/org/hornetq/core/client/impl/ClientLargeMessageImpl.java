/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.Message;
/*     */ import org.hornetq.core.buffers.impl.ResetLimitWrappedHornetQBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClientLargeMessageImpl
/*     */   extends ClientMessageImpl
/*     */   implements ClientLargeMessageInternal
/*     */ {
/*     */   private LargeMessageController largeMessageController;
/*     */   private long largeMessageSize;
/*     */   
/*     */   public void setLargeMessageSize(long largeMessageSize)
/*     */   {
/*  45 */     this.largeMessageSize = largeMessageSize;
/*     */   }
/*     */   
/*     */   public long getLargeMessageSize()
/*     */   {
/*  50 */     return this.largeMessageSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEncodeSize()
/*     */   {
/*  64 */     if (this.bodyBuffer != null)
/*     */     {
/*  66 */       return super.getEncodeSize();
/*     */     }
/*     */     
/*     */ 
/*  70 */     return 8 + getHeadersAndPropertiesEncodeSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLargeMessage()
/*     */   {
/*  80 */     return true;
/*     */   }
/*     */   
/*     */   public void setLargeMessageController(LargeMessageController controller)
/*     */   {
/*  85 */     this.largeMessageController = controller;
/*     */   }
/*     */   
/*     */   public void checkCompletion() throws HornetQException
/*     */   {
/*  90 */     checkBuffer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public HornetQBuffer getBodyBuffer()
/*     */   {
/*     */     try
/*     */     {
/*  99 */       checkBuffer();
/*     */     }
/*     */     catch (HornetQException e)
/*     */     {
/* 103 */       throw new RuntimeException(e.getMessage(), e);
/*     */     }
/*     */     
/* 106 */     return this.bodyBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getBodySize()
/*     */   {
/* 112 */     return getLongProperty(Message.HDR_LARGE_BODY_SIZE).intValue();
/*     */   }
/*     */   
/*     */   public LargeMessageController getLargeMessageController()
/*     */   {
/* 117 */     return this.largeMessageController;
/*     */   }
/*     */   
/*     */   public void saveToOutputStream(OutputStream out)
/*     */     throws HornetQException
/*     */   {
/* 123 */     if (this.bodyBuffer != null)
/*     */     {
/*     */ 
/* 126 */       super.saveToOutputStream(out);
/*     */     }
/*     */     else
/*     */     {
/* 130 */       this.largeMessageController.saveBuffer(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setOutputStream(OutputStream out)
/*     */     throws HornetQException
/*     */   {
/* 137 */     if (this.bodyBuffer != null)
/*     */     {
/* 139 */       super.setOutputStream(out);
/*     */     }
/*     */     else
/*     */     {
/* 143 */       this.largeMessageController.setOutputStream(out);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean waitOutputStreamCompletion(long timeMilliseconds)
/*     */     throws HornetQException
/*     */   {
/* 150 */     if (this.bodyBuffer != null)
/*     */     {
/* 152 */       return super.waitOutputStreamCompletion(timeMilliseconds);
/*     */     }
/*     */     
/*     */ 
/* 156 */     return this.largeMessageController.waitCompletion(timeMilliseconds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void discardBody()
/*     */   {
/* 163 */     if (this.bodyBuffer != null)
/*     */     {
/* 165 */       super.discardBody();
/*     */     }
/*     */     else
/*     */     {
/* 169 */       this.largeMessageController.discardUnusedPackets();
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkBuffer() throws HornetQException
/*     */   {
/* 175 */     if (this.bodyBuffer == null)
/*     */     {
/*     */ 
/* 178 */       long bodySize = this.largeMessageSize + 17L;
/* 179 */       if (bodySize > 2147483647L)
/*     */       {
/* 181 */         bodySize = 2147483647L;
/*     */       }
/* 183 */       createBody((int)bodySize);
/*     */       
/* 185 */       this.bodyBuffer = new ResetLimitWrappedHornetQBuffer(17, this.buffer, this);
/*     */       
/* 187 */       this.largeMessageController.saveBuffer(new HornetQOutputStream(this.bodyBuffer));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class HornetQOutputStream
/*     */     extends OutputStream
/*     */   {
/*     */     private final HornetQBuffer bufferOut;
/*     */     
/*     */     HornetQOutputStream(HornetQBuffer out)
/*     */     {
/* 199 */       this.bufferOut = out;
/*     */     }
/*     */     
/*     */     public void write(int b)
/*     */       throws IOException
/*     */     {
/* 205 */       this.bufferOut.writeByte((byte)(b & 0xFF));
/*     */     }
/*     */   }
/*     */   
/*     */   public void retrieveExistingData(ClientMessageImpl clMessage)
/*     */   {
/* 211 */     this.messageID = clMessage.getMessageID();
/* 212 */     this.address = clMessage.getAddress();
/* 213 */     setUserID(clMessage.getUserID());
/*     */     
/* 215 */     this.type = clMessage.getType();
/* 216 */     this.durable = clMessage.isDurable();
/* 217 */     setExpiration(clMessage.getExpiration());
/* 218 */     this.timestamp = clMessage.getTimestamp();
/* 219 */     this.priority = clMessage.getPriority();
/* 220 */     this.properties = clMessage.getProperties();
/* 221 */     this.largeMessageSize = clMessage.getLongProperty(HDR_LARGE_BODY_SIZE).longValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientLargeMessageImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */