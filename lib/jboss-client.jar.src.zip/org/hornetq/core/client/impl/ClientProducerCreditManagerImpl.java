/*     */ package org.hornetq.core.client.impl;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientProducerCreditManagerImpl
/*     */   implements ClientProducerCreditManager
/*     */ {
/*     */   public static final int MAX_UNREFERENCED_CREDITS_CACHE_SIZE = 1000;
/*  31 */   private final Map<SimpleString, ClientProducerCredits> producerCredits = new LinkedHashMap();
/*     */   
/*  33 */   private final Map<SimpleString, ClientProducerCredits> unReferencedCredits = new LinkedHashMap();
/*     */   
/*     */   private final ClientSessionInternal session;
/*     */   
/*     */   private int windowSize;
/*     */   
/*     */   public ClientProducerCreditManagerImpl(ClientSessionInternal session, int windowSize)
/*     */   {
/*  41 */     this.session = session;
/*     */     
/*  43 */     this.windowSize = windowSize;
/*     */   }
/*     */   
/*     */   public synchronized ClientProducerCredits getCredits(SimpleString address, boolean anon)
/*     */   {
/*  48 */     if (this.windowSize == -1)
/*     */     {
/*  50 */       return ClientProducerCreditsNoFlowControl.instance;
/*     */     }
/*     */     
/*     */ 
/*  54 */     boolean needInit = false;
/*     */     
/*     */     ClientProducerCredits credits;
/*  57 */     synchronized (this)
/*     */     {
/*  59 */       credits = (ClientProducerCredits)this.producerCredits.get(address);
/*     */       
/*  61 */       if (credits == null)
/*     */       {
/*     */ 
/*  64 */         credits = new ClientProducerCreditsImpl(this.session, address, this.windowSize);
/*  65 */         needInit = true;
/*     */         
/*  67 */         this.producerCredits.put(address, credits);
/*     */       }
/*     */       
/*  70 */       if (!anon)
/*     */       {
/*  72 */         credits.incrementRefCount();
/*     */         
/*     */ 
/*  75 */         this.unReferencedCredits.remove(address);
/*     */       }
/*     */       else
/*     */       {
/*  79 */         addToUnReferencedCache(address, credits);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  86 */     if (needInit)
/*     */     {
/*  88 */       credits.init();
/*     */     }
/*     */     
/*  91 */     return credits;
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void returnCredits(SimpleString address)
/*     */   {
/*  97 */     ClientProducerCredits credits = (ClientProducerCredits)this.producerCredits.get(address);
/*     */     
/*  99 */     if ((credits != null) && (credits.decrementRefCount() == 0))
/*     */     {
/* 101 */       addToUnReferencedCache(address, credits);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void receiveCredits(SimpleString address, int credits)
/*     */   {
/* 107 */     ClientProducerCredits cr = (ClientProducerCredits)this.producerCredits.get(address);
/*     */     
/* 109 */     if (cr != null)
/*     */     {
/* 111 */       cr.receiveCredits(credits);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void receiveFailCredits(SimpleString address, int credits)
/*     */   {
/* 117 */     ClientProducerCredits cr = (ClientProducerCredits)this.producerCredits.get(address);
/*     */     
/* 119 */     if (cr != null)
/*     */     {
/* 121 */       cr.receiveFailCredits(credits);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void reset()
/*     */   {
/* 127 */     for (ClientProducerCredits credits : this.producerCredits.values())
/*     */     {
/* 129 */       credits.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void close()
/*     */   {
/* 135 */     this.windowSize = -1;
/*     */     
/* 137 */     for (ClientProducerCredits credits : this.producerCredits.values())
/*     */     {
/* 139 */       credits.close();
/*     */     }
/*     */     
/* 142 */     this.producerCredits.clear();
/*     */     
/* 144 */     this.unReferencedCredits.clear();
/*     */   }
/*     */   
/*     */   public synchronized int creditsMapSize()
/*     */   {
/* 149 */     return this.producerCredits.size();
/*     */   }
/*     */   
/*     */   public synchronized int unReferencedCreditsSize()
/*     */   {
/* 154 */     return this.unReferencedCredits.size();
/*     */   }
/*     */   
/*     */   private void addToUnReferencedCache(SimpleString address, ClientProducerCredits credits)
/*     */   {
/* 159 */     this.unReferencedCredits.put(address, credits);
/*     */     
/* 161 */     if (this.unReferencedCredits.size() > 1000)
/*     */     {
/*     */ 
/*     */ 
/* 165 */       Iterator<Map.Entry<SimpleString, ClientProducerCredits>> iter = this.unReferencedCredits.entrySet().iterator();
/*     */       
/* 167 */       Map.Entry<SimpleString, ClientProducerCredits> oldest = (Map.Entry)iter.next();
/*     */       
/* 169 */       iter.remove();
/*     */       
/* 171 */       removeEntry((SimpleString)oldest.getKey(), (ClientProducerCredits)oldest.getValue());
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeEntry(SimpleString address, ClientProducerCredits credits)
/*     */   {
/* 177 */     this.producerCredits.remove(address);
/*     */     
/* 179 */     credits.releaseOutstanding();
/*     */     
/* 181 */     credits.close();
/*     */   }
/*     */   
/*     */   static class ClientProducerCreditsNoFlowControl
/*     */     implements ClientProducerCredits
/*     */   {
/* 187 */     static ClientProducerCreditsNoFlowControl instance = new ClientProducerCreditsNoFlowControl();
/*     */     
/*     */ 
/*     */     public void acquireCredits(int credits)
/*     */       throws InterruptedException
/*     */     {}
/*     */     
/*     */ 
/*     */     public void receiveCredits(int credits) {}
/*     */     
/*     */ 
/*     */     public void receiveFailCredits(int credits) {}
/*     */     
/*     */ 
/*     */     public boolean isBlocked()
/*     */     {
/* 203 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void init() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void reset() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public void close() {}
/*     */     
/*     */ 
/*     */     public void incrementRefCount() {}
/*     */     
/*     */ 
/*     */     public int decrementRefCount()
/*     */     {
/* 224 */       return 1;
/*     */     }
/*     */     
/*     */     public void releaseOutstanding() {}
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientProducerCreditManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */