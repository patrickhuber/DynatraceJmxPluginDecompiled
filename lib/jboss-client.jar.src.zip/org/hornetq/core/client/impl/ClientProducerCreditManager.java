package org.hornetq.core.client.impl;

import org.hornetq.api.core.SimpleString;

public abstract interface ClientProducerCreditManager
{
  public abstract ClientProducerCredits getCredits(SimpleString paramSimpleString, boolean paramBoolean);
  
  public abstract void returnCredits(SimpleString paramSimpleString);
  
  public abstract void receiveCredits(SimpleString paramSimpleString, int paramInt);
  
  public abstract void receiveFailCredits(SimpleString paramSimpleString, int paramInt);
  
  public abstract void reset();
  
  public abstract void close();
  
  public abstract int creditsMapSize();
  
  public abstract int unReferencedCreditsSize();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ClientProducerCreditManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */