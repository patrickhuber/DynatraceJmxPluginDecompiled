package org.hornetq.core.client.impl;

import java.util.concurrent.Executor;
import org.hornetq.api.core.HornetQException;
import org.hornetq.api.core.Pair;
import org.hornetq.api.core.TransportConfiguration;
import org.hornetq.api.core.client.ClientSessionFactory;
import org.hornetq.api.core.client.ServerLocator;
import org.hornetq.core.protocol.core.impl.PacketDecoder;

public abstract interface ServerLocatorInternal
  extends ServerLocator
{
  public abstract void start(Executor paramExecutor)
    throws Exception;
  
  public abstract void factoryClosed(ClientSessionFactory paramClientSessionFactory);
  
  public abstract AfterConnectInternalListener getAfterConnectInternalListener();
  
  public abstract void setAfterConnectionInternalListener(AfterConnectInternalListener paramAfterConnectInternalListener);
  
  public abstract void setIdentity(String paramString);
  
  public abstract void setNodeID(String paramString);
  
  public abstract String getNodeID();
  
  public abstract void cleanup();
  
  public abstract void resetToInitialConnectors();
  
  public abstract ClientSessionFactoryInternal connect()
    throws HornetQException;
  
  public abstract ClientSessionFactoryInternal connectNoWarnings()
    throws HornetQException;
  
  public abstract void notifyNodeUp(long paramLong, String paramString1, String paramString2, Pair<TransportConfiguration, TransportConfiguration> paramPair, boolean paramBoolean);
  
  public abstract void notifyNodeDown(long paramLong, String paramString);
  
  public abstract void setClusterConnection(boolean paramBoolean);
  
  public abstract boolean isClusterConnection();
  
  public abstract TransportConfiguration getClusterTransportConfiguration();
  
  public abstract void setClusterTransportConfiguration(TransportConfiguration paramTransportConfiguration);
  
  public abstract Topology getTopology();
  
  public abstract void setPacketDecoder(PacketDecoder paramPacketDecoder);
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\impl\ServerLocatorInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */