/*     */ package org.hornetq.core.client;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Arrays;
/*     */ import org.hornetq.api.core.HornetQAddressFullException;
/*     */ import org.hornetq.api.core.HornetQConnectionTimedOutException;
/*     */ import org.hornetq.api.core.HornetQDisconnectedException;
/*     */ import org.hornetq.api.core.HornetQIllegalStateException;
/*     */ import org.hornetq.api.core.HornetQInterceptorRejectedPacketException;
/*     */ import org.hornetq.api.core.HornetQInternalErrorException;
/*     */ import org.hornetq.api.core.HornetQLargeMessageException;
/*     */ import org.hornetq.api.core.HornetQLargeMessageInterruptedException;
/*     */ import org.hornetq.api.core.HornetQNotConnectedException;
/*     */ import org.hornetq.api.core.HornetQObjectClosedException;
/*     */ import org.hornetq.api.core.HornetQTransactionOutcomeUnknownException;
/*     */ import org.hornetq.api.core.HornetQTransactionRolledBackException;
/*     */ import org.hornetq.api.core.HornetQUnBlockedException;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public class HornetQClientMessageBundle_$bundle implements java.io.Serializable, HornetQClientMessageBundle
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String projectCode = "HQ";
/*  24 */   public static final bundle INSTANCE = new bundle();
/*     */   
/*     */   private static final String closeListenerCannotBeNull = "Close Listener cannot be null";
/*     */   
/*     */   private static final String mustBeDouble = "Element {0} requires a valid Double value, but '{1}' cannot be parsed as a Double";
/*     */   private static final String mustBeBoolean = "Element {0} requires a valid Boolean value, but '{1}' cannot be parsed as a Boolean";
/*     */   private static final String connectionTimedOutInInitialBroadcast = "Timed out waiting to receive initial broadcast from cluster";
/*     */   private static final String noTCForSessionFactory = "Couldn't select a TransportConfiguration to create SessionFactory";
/*     */   private static final String noOperationMapped = "No operation mapped to int {0}";
/*     */   private static final String txOutcomeUnknown = "The transaction was rolled back on failover however commit may have been succesful";
/*     */   private static final String oneNodeHasChildren = "one node has children and the other doesn't";
/*     */   private static final String errorReadingBody = "Error reading the LargeMessageBody";
/*     */   private static final String noChannelToClose = "Cannot find channel with id {0} to close";
/*     */   private static final String failedToCreateSession = "Failed to create session";
/*     */   private static final String errorWritingLargeMessage = "Error writing body of message";
/*     */   private static final String errorSavingBody = "Error saving the message body";
/*     */   private static final String secondNodeNull = "the second node to be compared is null";
/*     */   private static final String cannotConnectToServers = "Cannot connect to server(s). Tried with all available servers.";
/*     */   private static final String nodeHasDifferentChildNumber = "nodes hava a different number of children";
/*     */   private static final String connectionDestroyed = "Connection is destroyed";
/*     */   private static final String invalidWindowSize = "Invalid window size {0}";
/*     */   private static final String nodeHaveDifferentNames = "nodes have different node names";
/*     */   private static final String noCodec = "No available codec to decode password!";
/*     */   private static final String interceptorRejectedPacket = "Interceptor {0} rejected packet in a blocking call. This call will never complete.";
/*     */   private static final String nullListener = "Invalid argument null listener";
/*     */   private static final String attsDontMatch = "attribute {0}={1} doesn't match";
/*     */   private static final String failedToInitialiseSessionFactory = "Failed to initialise session factory";
/*     */   private static final String channelDisconnected = "Channel disconnected";
/*     */   private static final String failListenerCannotBeNull = "Fail Listener cannot be null";
/*     */   private static final String connectionExists = "Connection already exists with id {0}";
/*     */   private static final String messageHandlerSet = "Cannot call receive(...) - a MessageHandler is set";
/*     */   private static final String nettyError = "Exception in Netty transport";
/*     */   private static final String invalidEncodeType = "Invalid type: {0}";
/*     */   private static final String inReceive = "Cannot set MessageHandler - consumer is in receive(...)";
/*     */   private static final String consumerClosed = "Consumer is closed";
/*     */   private static final String queueMisConfigured = "Queue can not be both durable and temporary";
/*     */   private static final String firstNodeNull = "the first node to be compared is null";
/*     */   private static final String nodeHaveDifferentAttNumber = "nodes hava a different number of attributes";
/*     */   private static final String addressIsFull = "Address \"{0}\" is full. Message encode size = {1}B";
/*     */   private static final String producerClosed = "Producer is closed";
/*     */   private static final String connectionTimedOut = "Did not receive data from server for {0}";
/*     */   private static final String errorClosingLargeMessage = "Error closing stream from LargeMessageBody";
/*     */   private static final String mustBeLong = "Element {0} requires a valid Long value, but '{1}' cannot be parsed as a Long";
/*     */   private static final String connectionTimedOutOnReceiveTopology = "Timed out waiting to receive cluster topology. Group:{0}";
/*     */   private static final String invalidCommandID = "Invalid last Received Command ID: {0}";
/*     */   private static final String mustBeInteger = "Element {0} requires a valid Integer value, but '{1}' cannot be parsed as a Integer";
/*     */   private static final String cannotConnectToStaticConnectors2 = "Failed to connect to any static connectors";
/*     */   private static final String failedToGetDecoder = "Failed to get decoder";
/*     */   private static final String largeMessageInterrupted = "Large Message Transmission interrupted on consumer shutdown.";
/*     */   private static final String timedOutSendingPacket = "Timed out waiting for response when sending packet {0}";
/*     */   private static final String largeMessageLostSession = "The large message lost connection with its session, either because of a rollback or a closed session";
/*     */   private static final String cannotConnectToStaticConnectors = "Failed to connect to any static connectors";
/*     */   private static final String errordecodingPassword = "Error decoding password";
/*     */   private static final String timeoutOnLargeMessage = "Timeout waiting for LargeMessage Body";
/*     */   private static final String invalidManagementParam = "Params for management operations must be of the following type: int long double String boolean Map or array thereof but found {0}";
/*     */   private static final String txRolledBack = "The transaction was rolled back on failover to a backup server";
/*     */   private static final String sessionClosed = "Session is closed";
/*     */   private static final String disconnected = "The connection was disconnected because of server shutdown";
/*     */   private static final String clientSessionClosed = "ClientSession closed while creating session";
/*     */   private static final String clietSessionInternal = "Internal Error! ClientSessionFactoryImpl::createSessionInternal just reached a condition that was not supposed to happen. Please inform this condition to the HornetQ team";
/*     */   private static final String invalidType = "Invalid type: {0}";
/*     */   private static final String headerSizeTooBig = "Header size ({0}) is too big, use the messageBody for large data, or increase minLargeMessageSize";
/*     */   private static final String unblockingACall = "Connection failure detected. Unblocking a blocking call that will never get a response";
/*     */   private static final String nullHandler = "Invalid argument null handler";
/*     */   
/*     */   protected bundle readResolve()
/*     */   {
/*  91 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException closeListenerCannotBeNull()
/*     */   {
/*  96 */     IllegalArgumentException result = new IllegalArgumentException("HQ119039: " + closeListenerCannotBeNull$str());
/*  97 */     StackTraceElement[] st = result.getStackTrace();
/*  98 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/*  99 */     return result;
/*     */   }
/*     */   
/*     */   protected String closeListenerCannotBeNull$str() {
/* 103 */     return "Close Listener cannot be null";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException mustBeDouble(Node elem, String value)
/*     */   {
/* 108 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119053: " + mustBeDouble$str(), new Object[] { elem, value }));
/* 109 */     StackTraceElement[] st = result.getStackTrace();
/* 110 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 111 */     return result;
/*     */   }
/*     */   
/*     */   protected String mustBeDouble$str() {
/* 115 */     return "Element {0} requires a valid Double value, but '{1}' cannot be parsed as a Double";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException mustBeBoolean(Node elem, String value)
/*     */   {
/* 120 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119052: " + mustBeBoolean$str(), new Object[] { elem, value }));
/* 121 */     StackTraceElement[] st = result.getStackTrace();
/* 122 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   protected String mustBeBoolean$str() {
/* 127 */     return "Element {0} requires a valid Boolean value, but '{1}' cannot be parsed as a Boolean";
/*     */   }
/*     */   
/*     */   public final HornetQConnectionTimedOutException connectionTimedOutInInitialBroadcast()
/*     */   {
/* 132 */     HornetQConnectionTimedOutException result = new HornetQConnectionTimedOutException("HQ119012: " + connectionTimedOutInInitialBroadcast$str());
/* 133 */     StackTraceElement[] st = result.getStackTrace();
/* 134 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   protected String connectionTimedOutInInitialBroadcast$str() {
/* 139 */     return "Timed out waiting to receive initial broadcast from cluster";
/*     */   }
/*     */   
/*     */   public final HornetQIllegalStateException noTCForSessionFactory()
/*     */   {
/* 144 */     HornetQIllegalStateException result = new HornetQIllegalStateException("HQ119024: " + noTCForSessionFactory$str());
/* 145 */     StackTraceElement[] st = result.getStackTrace();
/* 146 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 147 */     return result;
/*     */   }
/*     */   
/*     */   protected String noTCForSessionFactory$str() {
/* 151 */     return "Couldn't select a TransportConfiguration to create SessionFactory";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException noOperationMapped(Integer operation)
/*     */   {
/* 156 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119036: " + noOperationMapped$str(), new Object[] { operation }));
/* 157 */     StackTraceElement[] st = result.getStackTrace();
/* 158 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 159 */     return result;
/*     */   }
/*     */   
/*     */   protected String noOperationMapped$str() {
/* 163 */     return "No operation mapped to int {0}";
/*     */   }
/*     */   
/*     */   public final HornetQTransactionOutcomeUnknownException txOutcomeUnknown()
/*     */   {
/* 168 */     HornetQTransactionOutcomeUnknownException result = new HornetQTransactionOutcomeUnknownException("HQ119031: " + txOutcomeUnknown$str());
/* 169 */     StackTraceElement[] st = result.getStackTrace();
/* 170 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 171 */     return result;
/*     */   }
/*     */   
/*     */   protected String txOutcomeUnknown$str() {
/* 175 */     return "The transaction was rolled back on failover however commit may have been succesful";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException oneNodeHasChildren()
/*     */   {
/* 180 */     IllegalArgumentException result = new IllegalArgumentException("HQ119050: " + oneNodeHasChildren$str());
/* 181 */     StackTraceElement[] st = result.getStackTrace();
/* 182 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 183 */     return result;
/*     */   }
/*     */   
/*     */   protected String oneNodeHasChildren$str() {
/* 187 */     return "one node has children and the other doesn't";
/*     */   }
/*     */   
/*     */   public final HornetQLargeMessageException errorReadingBody(Exception e)
/*     */   {
/* 192 */     HornetQLargeMessageException result = new HornetQLargeMessageException("HQ119026: " + errorReadingBody$str());
/* 193 */     result.initCause(e);
/* 194 */     StackTraceElement[] st = result.getStackTrace();
/* 195 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 196 */     return result;
/*     */   }
/*     */   
/*     */   protected String errorReadingBody$str() {
/* 200 */     return "Error reading the LargeMessageBody";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException noChannelToClose(Long id)
/*     */   {
/* 205 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119038: " + noChannelToClose$str(), new Object[] { id }));
/* 206 */     StackTraceElement[] st = result.getStackTrace();
/* 207 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 208 */     return result;
/*     */   }
/*     */   
/*     */   protected String noChannelToClose$str() {
/* 212 */     return "Cannot find channel with id {0} to close";
/*     */   }
/*     */   
/*     */   public final HornetQInternalErrorException failedToCreateSession(Throwable t)
/*     */   {
/* 217 */     HornetQInternalErrorException result = new HornetQInternalErrorException("HQ119001: " + failedToCreateSession$str(), t);
/* 218 */     StackTraceElement[] st = result.getStackTrace();
/* 219 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 220 */     return result;
/*     */   }
/*     */   
/*     */   protected String failedToCreateSession$str() {
/* 224 */     return "Failed to create session";
/*     */   }
/*     */   
/*     */   public final HornetQLargeMessageException errorWritingLargeMessage(Exception e)
/*     */   {
/* 229 */     HornetQLargeMessageException result = new HornetQLargeMessageException("HQ119029: " + errorWritingLargeMessage$str());
/* 230 */     result.initCause(e);
/* 231 */     StackTraceElement[] st = result.getStackTrace();
/* 232 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 233 */     return result;
/*     */   }
/*     */   
/*     */   protected String errorWritingLargeMessage$str() {
/* 237 */     return "Error writing body of message";
/*     */   }
/*     */   
/*     */   public final HornetQLargeMessageException errorSavingBody(Exception e)
/*     */   {
/* 242 */     HornetQLargeMessageException result = new HornetQLargeMessageException("HQ119025: " + errorSavingBody$str());
/* 243 */     result.initCause(e);
/* 244 */     StackTraceElement[] st = result.getStackTrace();
/* 245 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 246 */     return result;
/*     */   }
/*     */   
/*     */   protected String errorSavingBody$str() {
/* 250 */     return "Error saving the message body";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException secondNodeNull()
/*     */   {
/* 255 */     IllegalArgumentException result = new IllegalArgumentException("HQ119046: " + secondNodeNull$str());
/* 256 */     StackTraceElement[] st = result.getStackTrace();
/* 257 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 258 */     return result;
/*     */   }
/*     */   
/*     */   protected String secondNodeNull$str() {
/* 262 */     return "the second node to be compared is null";
/*     */   }
/*     */   
/*     */   public final HornetQNotConnectedException cannotConnectToServers()
/*     */   {
/* 267 */     HornetQNotConnectedException result = new HornetQNotConnectedException("HQ119007: " + cannotConnectToServers$str());
/* 268 */     StackTraceElement[] st = result.getStackTrace();
/* 269 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 270 */     return result;
/*     */   }
/*     */   
/*     */   protected String cannotConnectToServers$str() {
/* 274 */     return "Cannot connect to server(s). Tried with all available servers.";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException nodeHasDifferentChildNumber()
/*     */   {
/* 279 */     IllegalArgumentException result = new IllegalArgumentException("HQ119051: " + nodeHasDifferentChildNumber$str());
/* 280 */     StackTraceElement[] st = result.getStackTrace();
/* 281 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 282 */     return result;
/*     */   }
/*     */   
/*     */   protected String nodeHasDifferentChildNumber$str() {
/* 286 */     return "nodes hava a different number of children";
/*     */   }
/*     */   
/*     */   public final HornetQNotConnectedException connectionDestroyed()
/*     */   {
/* 291 */     HornetQNotConnectedException result = new HornetQNotConnectedException("HQ119010: " + connectionDestroyed$str());
/* 292 */     StackTraceElement[] st = result.getStackTrace();
/* 293 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 294 */     return result;
/*     */   }
/*     */   
/*     */   protected String connectionDestroyed$str() {
/* 298 */     return "Connection is destroyed";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException invalidWindowSize(Integer size)
/*     */   {
/* 303 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119035: " + invalidWindowSize$str(), new Object[] { size }));
/* 304 */     StackTraceElement[] st = result.getStackTrace();
/* 305 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 306 */     return result;
/*     */   }
/*     */   
/*     */   protected String invalidWindowSize$str() {
/* 310 */     return "Invalid window size {0}";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException nodeHaveDifferentNames()
/*     */   {
/* 315 */     IllegalArgumentException result = new IllegalArgumentException("HQ119047: " + nodeHaveDifferentNames$str());
/* 316 */     StackTraceElement[] st = result.getStackTrace();
/* 317 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 318 */     return result;
/*     */   }
/*     */   
/*     */   protected String nodeHaveDifferentNames$str() {
/* 322 */     return "nodes have different node names";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException noCodec()
/*     */   {
/* 327 */     IllegalArgumentException result = new IllegalArgumentException("HQ119044: " + noCodec$str());
/* 328 */     StackTraceElement[] st = result.getStackTrace();
/* 329 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 330 */     return result;
/*     */   }
/*     */   
/*     */   protected String noCodec$str() {
/* 334 */     return "No available codec to decode password!";
/*     */   }
/*     */   
/*     */   public final HornetQInterceptorRejectedPacketException interceptorRejectedPacket(String interceptionResult)
/*     */   {
/* 339 */     HornetQInterceptorRejectedPacketException result = new HornetQInterceptorRejectedPacketException(MessageFormat.format("HQ119059: " + interceptorRejectedPacket$str(), new Object[] { interceptionResult }));
/* 340 */     StackTraceElement[] st = result.getStackTrace();
/* 341 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 342 */     return result;
/*     */   }
/*     */   
/*     */   protected String interceptorRejectedPacket$str() {
/* 346 */     return "Interceptor {0} rejected packet in a blocking call. This call will never complete.";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException nullListener()
/*     */   {
/* 351 */     IllegalArgumentException result = new IllegalArgumentException("HQ119042: " + nullListener$str());
/* 352 */     StackTraceElement[] st = result.getStackTrace();
/* 353 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 354 */     return result;
/*     */   }
/*     */   
/*     */   protected String nullListener$str() {
/* 358 */     return "Invalid argument null listener";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException attsDontMatch(String name, String value)
/*     */   {
/* 363 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119049: " + attsDontMatch$str(), new Object[] { name, value }));
/* 364 */     StackTraceElement[] st = result.getStackTrace();
/* 365 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 366 */     return result;
/*     */   }
/*     */   
/*     */   protected String attsDontMatch$str() {
/* 370 */     return "attribute {0}={1} doesn't match";
/*     */   }
/*     */   
/*     */   public final HornetQInternalErrorException failedToInitialiseSessionFactory(Exception e)
/*     */   {
/* 375 */     HornetQInternalErrorException result = new HornetQInternalErrorException("HQ119004: " + failedToInitialiseSessionFactory$str(), e);
/* 376 */     StackTraceElement[] st = result.getStackTrace();
/* 377 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 378 */     return result;
/*     */   }
/*     */   
/*     */   protected String failedToInitialiseSessionFactory$str() {
/* 382 */     return "Failed to initialise session factory";
/*     */   }
/*     */   
/*     */   public final HornetQNotConnectedException channelDisconnected()
/*     */   {
/* 387 */     HornetQNotConnectedException result = new HornetQNotConnectedException("HQ119006: " + channelDisconnected$str());
/* 388 */     StackTraceElement[] st = result.getStackTrace();
/* 389 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 390 */     return result;
/*     */   }
/*     */   
/*     */   protected String channelDisconnected$str() {
/* 394 */     return "Channel disconnected";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException failListenerCannotBeNull()
/*     */   {
/* 399 */     IllegalArgumentException result = new IllegalArgumentException("HQ119040: " + failListenerCannotBeNull$str());
/* 400 */     StackTraceElement[] st = result.getStackTrace();
/* 401 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 402 */     return result;
/*     */   }
/*     */   
/*     */   protected String failListenerCannotBeNull$str() {
/* 406 */     return "Fail Listener cannot be null";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException connectionExists(Object id)
/*     */   {
/* 411 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119041: " + connectionExists$str(), new Object[] { id }));
/* 412 */     StackTraceElement[] st = result.getStackTrace();
/* 413 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 414 */     return result;
/*     */   }
/*     */   
/*     */   protected String connectionExists$str() {
/* 418 */     return "Connection already exists with id {0}";
/*     */   }
/*     */   
/*     */   public final HornetQIllegalStateException messageHandlerSet()
/*     */   {
/* 423 */     HornetQIllegalStateException result = new HornetQIllegalStateException("HQ119020: " + messageHandlerSet$str());
/* 424 */     StackTraceElement[] st = result.getStackTrace();
/* 425 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 426 */     return result;
/*     */   }
/*     */   
/*     */   protected String messageHandlerSet$str() {
/* 430 */     return "Cannot call receive(...) - a MessageHandler is set";
/*     */   }
/*     */   
/*     */   public final HornetQInternalErrorException nettyError()
/*     */   {
/* 435 */     HornetQInternalErrorException result = new HornetQInternalErrorException("HQ119005: " + nettyError$str());
/* 436 */     StackTraceElement[] st = result.getStackTrace();
/* 437 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 438 */     return result;
/*     */   }
/*     */   
/*     */   protected String nettyError$str() {
/* 442 */     return "Exception in Netty transport";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException invalidEncodeType(Object type)
/*     */   {
/* 447 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119033: " + invalidEncodeType$str(), new Object[] { type }));
/* 448 */     StackTraceElement[] st = result.getStackTrace();
/* 449 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 450 */     return result;
/*     */   }
/*     */   
/*     */   protected String invalidEncodeType$str() {
/* 454 */     return "Invalid type: {0}";
/*     */   }
/*     */   
/*     */   public final HornetQIllegalStateException inReceive()
/*     */   {
/* 459 */     HornetQIllegalStateException result = new HornetQIllegalStateException("HQ119021: " + inReceive$str());
/* 460 */     StackTraceElement[] st = result.getStackTrace();
/* 461 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 462 */     return result;
/*     */   }
/*     */   
/*     */   protected String inReceive$str() {
/* 466 */     return "Cannot set MessageHandler - consumer is in receive(...)";
/*     */   }
/*     */   
/*     */   public final HornetQObjectClosedException consumerClosed()
/*     */   {
/* 471 */     HornetQObjectClosedException result = new HornetQObjectClosedException("HQ119017: " + consumerClosed$str());
/* 472 */     StackTraceElement[] st = result.getStackTrace();
/* 473 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 474 */     return result;
/*     */   }
/*     */   
/*     */   protected String consumerClosed$str() {
/* 478 */     return "Consumer is closed";
/*     */   }
/*     */   
/*     */   public final HornetQInternalErrorException queueMisConfigured()
/*     */   {
/* 483 */     HornetQInternalErrorException result = new HornetQInternalErrorException("HQ119003: " + queueMisConfigured$str());
/* 484 */     StackTraceElement[] st = result.getStackTrace();
/* 485 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 486 */     return result;
/*     */   }
/*     */   
/*     */   protected String queueMisConfigured$str() {
/* 490 */     return "Queue can not be both durable and temporary";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException firstNodeNull()
/*     */   {
/* 495 */     IllegalArgumentException result = new IllegalArgumentException("HQ119045: " + firstNodeNull$str());
/* 496 */     StackTraceElement[] st = result.getStackTrace();
/* 497 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 498 */     return result;
/*     */   }
/*     */   
/*     */   protected String firstNodeNull$str() {
/* 502 */     return "the first node to be compared is null";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException nodeHaveDifferentAttNumber()
/*     */   {
/* 507 */     IllegalArgumentException result = new IllegalArgumentException("HQ119048: " + nodeHaveDifferentAttNumber$str());
/* 508 */     StackTraceElement[] st = result.getStackTrace();
/* 509 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 510 */     return result;
/*     */   }
/*     */   
/*     */   protected String nodeHaveDifferentAttNumber$str() {
/* 514 */     return "nodes hava a different number of attributes";
/*     */   }
/*     */   
/*     */   public final HornetQAddressFullException addressIsFull(String addressName, int size)
/*     */   {
/* 519 */     HornetQAddressFullException result = new HornetQAddressFullException(MessageFormat.format("HQ119058: " + addressIsFull$str(), new Object[] { addressName, Integer.valueOf(size) }));
/* 520 */     StackTraceElement[] st = result.getStackTrace();
/* 521 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 522 */     return result;
/*     */   }
/*     */   
/*     */   protected String addressIsFull$str() {
/* 526 */     return "Address \"{0}\" is full. Message encode size = {1}B";
/*     */   }
/*     */   
/*     */   public final HornetQObjectClosedException producerClosed()
/*     */   {
/* 531 */     HornetQObjectClosedException result = new HornetQObjectClosedException("HQ119018: " + producerClosed$str());
/* 532 */     StackTraceElement[] st = result.getStackTrace();
/* 533 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 534 */     return result;
/*     */   }
/*     */   
/*     */   protected String producerClosed$str() {
/* 538 */     return "Producer is closed";
/*     */   }
/*     */   
/*     */   public final HornetQConnectionTimedOutException connectionTimedOut(org.hornetq.spi.core.remoting.Connection transportConnection)
/*     */   {
/* 543 */     HornetQConnectionTimedOutException result = new HornetQConnectionTimedOutException(MessageFormat.format("HQ119011: " + connectionTimedOut$str(), new Object[] { transportConnection }));
/* 544 */     StackTraceElement[] st = result.getStackTrace();
/* 545 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 546 */     return result;
/*     */   }
/*     */   
/*     */   protected String connectionTimedOut$str() {
/* 550 */     return "Did not receive data from server for {0}";
/*     */   }
/*     */   
/*     */   public final HornetQLargeMessageException errorClosingLargeMessage(Exception e)
/*     */   {
/* 555 */     HornetQLargeMessageException result = new HornetQLargeMessageException("HQ119027: " + errorClosingLargeMessage$str());
/* 556 */     result.initCause(e);
/* 557 */     StackTraceElement[] st = result.getStackTrace();
/* 558 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 559 */     return result;
/*     */   }
/*     */   
/*     */   protected String errorClosingLargeMessage$str() {
/* 563 */     return "Error closing stream from LargeMessageBody";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException mustBeLong(Node elem, String value)
/*     */   {
/* 568 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119055: " + mustBeLong$str(), new Object[] { elem, value }));
/* 569 */     StackTraceElement[] st = result.getStackTrace();
/* 570 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 571 */     return result;
/*     */   }
/*     */   
/*     */   protected String mustBeLong$str() {
/* 575 */     return "Element {0} requires a valid Long value, but '{1}' cannot be parsed as a Long";
/*     */   }
/*     */   
/*     */   public final HornetQConnectionTimedOutException connectionTimedOutOnReceiveTopology(org.hornetq.core.cluster.DiscoveryGroup discoveryGroup)
/*     */   {
/* 580 */     HornetQConnectionTimedOutException result = new HornetQConnectionTimedOutException(MessageFormat.format("HQ119013: " + connectionTimedOutOnReceiveTopology$str(), new Object[] { discoveryGroup }));
/* 581 */     StackTraceElement[] st = result.getStackTrace();
/* 582 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 583 */     return result;
/*     */   }
/*     */   
/*     */   protected String connectionTimedOutOnReceiveTopology$str() {
/* 587 */     return "Timed out waiting to receive cluster topology. Group:{0}";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException invalidCommandID(Integer lastReceivedCommandID)
/*     */   {
/* 592 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119037: " + invalidCommandID$str(), new Object[] { lastReceivedCommandID }));
/* 593 */     StackTraceElement[] st = result.getStackTrace();
/* 594 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 595 */     return result;
/*     */   }
/*     */   
/*     */   protected String invalidCommandID$str() {
/* 599 */     return "Invalid last Received Command ID: {0}";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException mustBeInteger(Node elem, String value)
/*     */   {
/* 604 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119054: " + mustBeInteger$str(), new Object[] { elem, value }));
/* 605 */     StackTraceElement[] st = result.getStackTrace();
/* 606 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 607 */     return result;
/*     */   }
/*     */   
/*     */   protected String mustBeInteger$str() {
/* 611 */     return "Element {0} requires a valid Integer value, but '{1}' cannot be parsed as a Integer";
/*     */   }
/*     */   
/*     */   public final HornetQNotConnectedException cannotConnectToStaticConnectors2()
/*     */   {
/* 616 */     HornetQNotConnectedException result = new HornetQNotConnectedException("HQ119009: " + cannotConnectToStaticConnectors2$str());
/* 617 */     StackTraceElement[] st = result.getStackTrace();
/* 618 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 619 */     return result;
/*     */   }
/*     */   
/*     */   protected String cannotConnectToStaticConnectors2$str() {
/* 623 */     return "Failed to connect to any static connectors";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException failedToGetDecoder(Exception e)
/*     */   {
/* 628 */     IllegalArgumentException result = new IllegalArgumentException("HQ119056: " + failedToGetDecoder$str(), e);
/* 629 */     StackTraceElement[] st = result.getStackTrace();
/* 630 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 631 */     return result;
/*     */   }
/*     */   
/*     */   protected String failedToGetDecoder$str() {
/* 635 */     return "Failed to get decoder";
/*     */   }
/*     */   
/*     */   public final HornetQLargeMessageInterruptedException largeMessageInterrupted()
/*     */   {
/* 640 */     HornetQLargeMessageInterruptedException result = new HornetQLargeMessageInterruptedException("HQ119060: " + largeMessageInterrupted$str());
/* 641 */     StackTraceElement[] st = result.getStackTrace();
/* 642 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 643 */     return result;
/*     */   }
/*     */   
/*     */   protected String largeMessageInterrupted$str() {
/* 647 */     return "Large Message Transmission interrupted on consumer shutdown.";
/*     */   }
/*     */   
/*     */   public final HornetQConnectionTimedOutException timedOutSendingPacket(Byte type)
/*     */   {
/* 652 */     HornetQConnectionTimedOutException result = new HornetQConnectionTimedOutException(MessageFormat.format("HQ119014: " + timedOutSendingPacket$str(), new Object[] { type }));
/* 653 */     StackTraceElement[] st = result.getStackTrace();
/* 654 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 655 */     return result;
/*     */   }
/*     */   
/*     */   protected String timedOutSendingPacket$str() {
/* 659 */     return "Timed out waiting for response when sending packet {0}";
/*     */   }
/*     */   
/*     */   public final HornetQIllegalStateException largeMessageLostSession()
/*     */   {
/* 664 */     HornetQIllegalStateException result = new HornetQIllegalStateException("HQ119023: " + largeMessageLostSession$str());
/* 665 */     StackTraceElement[] st = result.getStackTrace();
/* 666 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 667 */     return result;
/*     */   }
/*     */   
/*     */   protected String largeMessageLostSession$str() {
/* 671 */     return "The large message lost connection with its session, either because of a rollback or a closed session";
/*     */   }
/*     */   
/*     */   public final HornetQNotConnectedException cannotConnectToStaticConnectors(Exception e)
/*     */   {
/* 676 */     HornetQNotConnectedException result = new HornetQNotConnectedException("HQ119008: " + cannotConnectToStaticConnectors$str());
/* 677 */     result.initCause(e);
/* 678 */     StackTraceElement[] st = result.getStackTrace();
/* 679 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 680 */     return result;
/*     */   }
/*     */   
/*     */   protected String cannotConnectToStaticConnectors$str() {
/* 684 */     return "Failed to connect to any static connectors";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException errordecodingPassword(Exception e)
/*     */   {
/* 689 */     IllegalArgumentException result = new IllegalArgumentException("HQ119057: " + errordecodingPassword$str(), e);
/* 690 */     StackTraceElement[] st = result.getStackTrace();
/* 691 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 692 */     return result;
/*     */   }
/*     */   
/*     */   protected String errordecodingPassword$str() {
/* 696 */     return "Error decoding password";
/*     */   }
/*     */   
/*     */   public final HornetQLargeMessageException timeoutOnLargeMessage()
/*     */   {
/* 701 */     HornetQLargeMessageException result = new HornetQLargeMessageException("HQ119028: " + timeoutOnLargeMessage$str());
/* 702 */     StackTraceElement[] st = result.getStackTrace();
/* 703 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 704 */     return result;
/*     */   }
/*     */   
/*     */   protected String timeoutOnLargeMessage$str() {
/* 708 */     return "Timeout waiting for LargeMessage Body";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException invalidManagementParam(Object type)
/*     */   {
/* 713 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119034: " + invalidManagementParam$str(), new Object[] { type }));
/* 714 */     StackTraceElement[] st = result.getStackTrace();
/* 715 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 716 */     return result;
/*     */   }
/*     */   
/*     */   protected String invalidManagementParam$str() {
/* 720 */     return "Params for management operations must be of the following type: int long double String boolean Map or array thereof but found {0}";
/*     */   }
/*     */   
/*     */   public final HornetQTransactionRolledBackException txRolledBack()
/*     */   {
/* 725 */     HornetQTransactionRolledBackException result = new HornetQTransactionRolledBackException("HQ119030: " + txRolledBack$str());
/* 726 */     StackTraceElement[] st = result.getStackTrace();
/* 727 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 728 */     return result;
/*     */   }
/*     */   
/*     */   protected String txRolledBack$str() {
/* 732 */     return "The transaction was rolled back on failover to a backup server";
/*     */   }
/*     */   
/*     */   public final HornetQObjectClosedException sessionClosed()
/*     */   {
/* 737 */     HornetQObjectClosedException result = new HornetQObjectClosedException("HQ119019: " + sessionClosed$str());
/* 738 */     StackTraceElement[] st = result.getStackTrace();
/* 739 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 740 */     return result;
/*     */   }
/*     */   
/*     */   protected String sessionClosed$str() {
/* 744 */     return "Session is closed";
/*     */   }
/*     */   
/*     */   public final HornetQDisconnectedException disconnected()
/*     */   {
/* 749 */     HornetQDisconnectedException result = new HornetQDisconnectedException("HQ119015: " + disconnected$str());
/* 750 */     StackTraceElement[] st = result.getStackTrace();
/* 751 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 752 */     return result;
/*     */   }
/*     */   
/*     */   protected String disconnected$str() {
/* 756 */     return "The connection was disconnected because of server shutdown";
/*     */   }
/*     */   
/*     */   public final HornetQInternalErrorException clientSessionClosed()
/*     */   {
/* 761 */     HornetQInternalErrorException result = new HornetQInternalErrorException("HQ119000: " + clientSessionClosed$str());
/* 762 */     StackTraceElement[] st = result.getStackTrace();
/* 763 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 764 */     return result;
/*     */   }
/*     */   
/*     */   protected String clientSessionClosed$str() {
/* 768 */     return "ClientSession closed while creating session";
/*     */   }
/*     */   
/*     */   public final HornetQInternalErrorException clietSessionInternal()
/*     */   {
/* 773 */     HornetQInternalErrorException result = new HornetQInternalErrorException("HQ119002: " + clietSessionInternal$str());
/* 774 */     StackTraceElement[] st = result.getStackTrace();
/* 775 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 776 */     return result;
/*     */   }
/*     */   
/*     */   protected String clietSessionInternal$str() {
/* 780 */     return "Internal Error! ClientSessionFactoryImpl::createSessionInternal just reached a condition that was not supposed to happen. Please inform this condition to the HornetQ team";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException invalidType(Object type)
/*     */   {
/* 785 */     IllegalArgumentException result = new IllegalArgumentException(MessageFormat.format("HQ119032: " + invalidType$str(), new Object[] { type }));
/* 786 */     StackTraceElement[] st = result.getStackTrace();
/* 787 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 788 */     return result;
/*     */   }
/*     */   
/*     */   protected String invalidType$str() {
/* 792 */     return "Invalid type: {0}";
/*     */   }
/*     */   
/*     */   public final HornetQIllegalStateException headerSizeTooBig(Integer headerSize)
/*     */   {
/* 797 */     HornetQIllegalStateException result = new HornetQIllegalStateException(MessageFormat.format("HQ119022: " + headerSizeTooBig$str(), new Object[] { headerSize }));
/* 798 */     StackTraceElement[] st = result.getStackTrace();
/* 799 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 800 */     return result;
/*     */   }
/*     */   
/*     */   protected String headerSizeTooBig$str() {
/* 804 */     return "Header size ({0}) is too big, use the messageBody for large data, or increase minLargeMessageSize";
/*     */   }
/*     */   
/*     */   public final HornetQUnBlockedException unblockingACall(Throwable t)
/*     */   {
/* 809 */     HornetQUnBlockedException result = new HornetQUnBlockedException("HQ119016: " + unblockingACall$str());
/* 810 */     result.initCause(t);
/* 811 */     StackTraceElement[] st = result.getStackTrace();
/* 812 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 813 */     return result;
/*     */   }
/*     */   
/*     */   protected String unblockingACall$str() {
/* 817 */     return "Connection failure detected. Unblocking a blocking call that will never get a response";
/*     */   }
/*     */   
/*     */   public final IllegalArgumentException nullHandler()
/*     */   {
/* 822 */     IllegalArgumentException result = new IllegalArgumentException("HQ119043: " + nullHandler$str());
/* 823 */     StackTraceElement[] st = result.getStackTrace();
/* 824 */     result.setStackTrace((StackTraceElement[])Arrays.copyOfRange(st, 1, st.length));
/* 825 */     return result;
/*     */   }
/*     */   
/*     */   protected String nullHandler$str() {
/* 829 */     return "Invalid argument null handler";
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\client\HornetQClientMessageBundle_$bundle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */