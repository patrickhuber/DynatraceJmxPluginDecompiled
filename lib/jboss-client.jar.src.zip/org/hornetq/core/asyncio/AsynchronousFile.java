package org.hornetq.core.asyncio;

import java.nio.ByteBuffer;
import org.hornetq.api.core.HornetQException;

public abstract interface AsynchronousFile
{
  public abstract void close()
    throws InterruptedException, HornetQException;
  
  public abstract void open(String paramString, int paramInt)
    throws HornetQException;
  
  public abstract long size()
    throws HornetQException;
  
  public abstract void write(long paramLong1, long paramLong2, ByteBuffer paramByteBuffer, AIOCallback paramAIOCallback);
  
  public abstract void writeInternal(long paramLong1, long paramLong2, ByteBuffer paramByteBuffer)
    throws HornetQException;
  
  public abstract void read(long paramLong1, long paramLong2, ByteBuffer paramByteBuffer, AIOCallback paramAIOCallback)
    throws HornetQException;
  
  public abstract void fill(long paramLong1, int paramInt, long paramLong2, byte paramByte)
    throws HornetQException;
  
  public abstract void setBufferCallback(BufferCallback paramBufferCallback);
  
  public abstract int getBlockSize();
}


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\asyncio\AsynchronousFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */