/*     */ package org.hornetq.core.asyncio.impl;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.FileLock;
/*     */ import java.util.PriorityQueue;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*     */ import org.hornetq.api.core.HornetQException;
/*     */ import org.hornetq.api.core.HornetQExceptionType;
/*     */ import org.hornetq.core.asyncio.AIOCallback;
/*     */ import org.hornetq.core.asyncio.AsynchronousFile;
/*     */ import org.hornetq.core.asyncio.BufferCallback;
/*     */ import org.hornetq.core.asyncio.IOExceptionListener;
/*     */ import org.hornetq.journal.HornetQJournalLogger;
/*     */ import org.hornetq.utils.ReusableLatch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsynchronousFileImpl
/*     */   implements AsynchronousFile
/*     */ {
/*  48 */   private static final AtomicInteger totalMaxIO = new AtomicInteger(0);
/*     */   
/*  50 */   private static boolean loaded = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int EXPECTED_NATIVE_VERSION = 51;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private final AtomicLong nextWritingSequence = new AtomicLong(0L);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private long nextReadSequence = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private final PriorityQueue<CallbackHolder> pendingCallbacks = new PriorityQueue();
/*     */   
/*     */   public static void addMax(int io)
/*     */   {
/*  79 */     totalMaxIO.addAndGet(io);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getTotalMaxIO()
/*     */   {
/*  87 */     return totalMaxIO.get();
/*     */   }
/*     */   
/*     */   public static void resetMaxAIO()
/*     */   {
/*  92 */     totalMaxIO.set(0);
/*     */   }
/*     */   
/*     */   private static boolean loadLibrary(String name)
/*     */   {
/*     */     try
/*     */     {
/*  99 */       HornetQJournalLogger.LOGGER.trace(name + " being loaded");
/* 100 */       System.loadLibrary(name);
/* 101 */       if (getNativeVersion() != 51)
/*     */       {
/* 103 */         HornetQJournalLogger.LOGGER.incompatibleNativeLibrary();
/* 104 */         return false;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 109 */       setNanoSleepInterval(1);
/* 110 */       return true;
/*     */ 
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 115 */       HornetQJournalLogger.LOGGER.debug(name + " -> error loading the native library", e); }
/* 116 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 123 */     String[] libraries = { "HornetQAIO", "HornetQAIO64", "HornetQAIO32", "HornetQAIO_ia64" };
/*     */     
/* 125 */     for (String library : libraries)
/*     */     {
/* 127 */       if (loadLibrary(library))
/*     */       {
/* 129 */         loaded = true;
/* 130 */         break;
/*     */       }
/*     */       
/*     */ 
/* 134 */       HornetQJournalLogger.LOGGER.debug("Library " + library + " not found!");
/*     */     }
/*     */     
/*     */ 
/* 138 */     if (!loaded)
/*     */     {
/* 140 */       HornetQJournalLogger.LOGGER.debug("Couldn't locate LibAIO Wrapper");
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isLoaded()
/*     */   {
/* 146 */     return loaded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 151 */   private boolean opened = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private String fileName;
/*     */   
/*     */ 
/* 158 */   private final Lock callbackLock = new ReentrantLock();
/*     */   
/* 160 */   private final ReusableLatch pollerLatch = new ReusableLatch();
/*     */   
/*     */   private volatile Runnable poller;
/*     */   
/*     */   private int maxIO;
/*     */   
/* 166 */   private final Lock writeLock = new ReentrantReadWriteLock().writeLock();
/*     */   
/* 168 */   private final ReusableLatch pendingWrites = new ReusableLatch();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private Semaphore maxIOSemaphore;
/*     */   
/*     */ 
/*     */ 
/*     */   private BufferCallback bufferCallback;
/*     */   
/*     */ 
/*     */ 
/*     */   private final IOExceptionListener ioExceptionListener;
/*     */   
/*     */ 
/*     */ 
/*     */   private ByteBuffer handler;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Executor writeExecutor;
/*     */   
/*     */ 
/*     */ 
/*     */   private final Executor pollerExecutor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AsynchronousFileImpl(Executor writeExecutor, Executor pollerExecutor, IOExceptionListener ioExceptionListener)
/*     */   {
/* 200 */     this.writeExecutor = writeExecutor;
/* 201 */     this.pollerExecutor = pollerExecutor;
/* 202 */     this.ioExceptionListener = ioExceptionListener;
/*     */   }
/*     */   
/*     */   public AsynchronousFileImpl(Executor writeExecutor, Executor pollerExecutor)
/*     */   {
/* 207 */     this(writeExecutor, pollerExecutor, null);
/*     */   }
/*     */   
/*     */   public void open(String fileName1, int maxIOArgument) throws HornetQException
/*     */   {
/* 212 */     this.writeLock.lock();
/*     */     
/*     */     try
/*     */     {
/* 216 */       if (this.opened)
/*     */       {
/* 218 */         throw new IllegalStateException("AsynchronousFile is already opened");
/*     */       }
/*     */       
/* 221 */       this.maxIO = maxIOArgument;
/* 222 */       this.maxIOSemaphore = new Semaphore(this.maxIO);
/*     */       
/* 224 */       this.fileName = fileName1;
/*     */       
/*     */       try
/*     */       {
/* 228 */         this.handler = init(fileName1, this.maxIO, HornetQJournalLogger.LOGGER);
/*     */       }
/*     */       catch (HornetQException e)
/*     */       {
/* 232 */         HornetQException ex = null;
/* 233 */         if (e.getType() == HornetQExceptionType.NATIVE_ERROR_CANT_INITIALIZE_AIO)
/*     */         {
/* 235 */           ex = new HornetQException(e.getType(), "Can't initialize AIO. Currently AIO in use = " + totalMaxIO.get() + ", trying to allocate more " + maxIOArgument, e);
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 243 */           ex = e;
/*     */         }
/* 245 */         throw ex;
/*     */       }
/* 247 */       this.opened = true;
/* 248 */       addMax(this.maxIO);
/* 249 */       this.nextWritingSequence.set(0L);
/* 250 */       this.nextReadSequence = 0L;
/*     */     }
/*     */     finally
/*     */     {
/* 254 */       this.writeLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws InterruptedException, HornetQException
/*     */   {
/* 260 */     checkOpened();
/*     */     
/* 262 */     this.writeLock.lock();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 267 */       while (!this.pendingWrites.await(60000L))
/*     */       {
/* 269 */         HornetQJournalLogger.LOGGER.couldNotGetLock(this.fileName);
/*     */       }
/*     */       
/* 272 */       while (!this.maxIOSemaphore.tryAcquire(this.maxIO, 60L, TimeUnit.SECONDS))
/*     */       {
/* 274 */         HornetQJournalLogger.LOGGER.couldNotGetLock(this.fileName);
/*     */       }
/*     */       
/* 277 */       this.maxIOSemaphore = null;
/* 278 */       if (this.poller != null)
/*     */       {
/* 280 */         stopPoller();
/*     */       }
/*     */       
/* 283 */       if (this.handler != null)
/*     */       {
/* 285 */         closeInternal(this.handler);
/* 286 */         addMax(-this.maxIO);
/*     */       }
/* 288 */       this.opened = false;
/* 289 */       this.handler = null;
/*     */     }
/*     */     finally
/*     */     {
/* 293 */       this.writeLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeInternal(long positionToWrite, long size, ByteBuffer bytes)
/*     */     throws HornetQException
/*     */   {
/*     */     try
/*     */     {
/* 302 */       writeInternal(this.handler, positionToWrite, size, bytes);
/*     */     }
/*     */     catch (HornetQException e)
/*     */     {
/* 306 */       fireExceptionListener(e.getType().getCode(), e.getMessage());
/* 307 */       throw e;
/*     */     }
/* 309 */     if (this.bufferCallback != null)
/*     */     {
/* 311 */       this.bufferCallback.bufferDone(bytes);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(final long position, long size, final ByteBuffer directByteBuffer, AIOCallback aioCallback)
/*     */   {
/* 321 */     if (aioCallback == null)
/*     */     {
/* 323 */       throw new NullPointerException("Null Callback");
/*     */     }
/*     */     
/* 326 */     checkOpened();
/* 327 */     if (this.poller == null)
/*     */     {
/* 329 */       startPoller();
/*     */     }
/*     */     
/* 332 */     this.pendingWrites.countUp();
/*     */     
/* 334 */     if (this.writeExecutor != null)
/*     */     {
/* 336 */       this.maxIOSemaphore.acquireUninterruptibly();
/*     */       
/* 338 */       this.writeExecutor.execute(new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 342 */           long sequence = AsynchronousFileImpl.this.nextWritingSequence.getAndIncrement();
/*     */           
/*     */           try
/*     */           {
/* 346 */             AsynchronousFileImpl.this.write(AsynchronousFileImpl.this.handler, sequence, position, directByteBuffer, this.val$directByteBuffer, this.val$aioCallback);
/*     */           }
/*     */           catch (HornetQException e)
/*     */           {
/* 350 */             AsynchronousFileImpl.this.callbackError(this.val$aioCallback, sequence, this.val$directByteBuffer, e.getType().getCode(), e.getMessage());
/*     */           }
/*     */           catch (RuntimeException e)
/*     */           {
/* 354 */             AsynchronousFileImpl.this.callbackError(this.val$aioCallback, sequence, this.val$directByteBuffer, HornetQExceptionType.INTERNAL_ERROR.getCode(), e.getMessage());
/*     */           }
/*     */           
/*     */         }
/*     */         
/*     */ 
/*     */       });
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 365 */       this.maxIOSemaphore.acquireUninterruptibly();
/*     */       
/* 367 */       long sequence = this.nextWritingSequence.getAndIncrement();
/*     */       
/*     */       try
/*     */       {
/* 371 */         write(this.handler, sequence, position, size, directByteBuffer, aioCallback);
/*     */       }
/*     */       catch (HornetQException e)
/*     */       {
/* 375 */         callbackError(aioCallback, sequence, directByteBuffer, e.getType().getCode(), e.getMessage());
/*     */       }
/*     */       catch (RuntimeException e)
/*     */       {
/* 379 */         callbackError(aioCallback, sequence, directByteBuffer, HornetQExceptionType.INTERNAL_ERROR.getCode(), e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void read(long position, long size, ByteBuffer directByteBuffer, AIOCallback aioPackage)
/*     */     throws HornetQException
/*     */   {
/* 390 */     checkOpened();
/* 391 */     if (this.poller == null)
/*     */     {
/* 393 */       startPoller();
/*     */     }
/* 395 */     this.pendingWrites.countUp();
/* 396 */     this.maxIOSemaphore.acquireUninterruptibly();
/*     */     try
/*     */     {
/* 399 */       read(this.handler, position, size, directByteBuffer, aioPackage);
/*     */ 
/*     */     }
/*     */     catch (HornetQException e)
/*     */     {
/* 404 */       this.maxIOSemaphore.release();
/* 405 */       this.pendingWrites.countDown();
/* 406 */       throw e;
/*     */ 
/*     */     }
/*     */     catch (RuntimeException e)
/*     */     {
/* 411 */       this.maxIOSemaphore.release();
/* 412 */       this.pendingWrites.countDown();
/* 413 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   public long size() throws HornetQException
/*     */   {
/* 419 */     checkOpened();
/* 420 */     return size0(this.handler);
/*     */   }
/*     */   
/*     */   public void fill(long position, int blocks, long size, byte fillChar) throws HornetQException
/*     */   {
/* 425 */     checkOpened();
/*     */     try
/*     */     {
/* 428 */       fill(this.handler, position, blocks, size, fillChar);
/*     */     }
/*     */     catch (HornetQException e)
/*     */     {
/* 432 */       fireExceptionListener(e.getType().getCode(), e.getMessage());
/* 433 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   public int getBlockSize()
/*     */   {
/* 439 */     return 512;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized ByteBuffer newBuffer(int size)
/*     */   {
/* 449 */     if (size % 512 != 0)
/*     */     {
/* 451 */       throw new RuntimeException("Buffer size needs to be aligned to 512");
/*     */     }
/*     */     
/* 454 */     return newNativeBuffer(size);
/*     */   }
/*     */   
/*     */   public void setBufferCallback(BufferCallback callback)
/*     */   {
/* 459 */     this.bufferCallback = callback;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ByteBuffer getHandler()
/*     */   {
/* 467 */     return this.handler;
/*     */   }
/*     */   
/*     */   public static void clearBuffer(ByteBuffer buffer)
/*     */   {
/* 472 */     resetBuffer(buffer, buffer.limit());
/* 473 */     buffer.position(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void finalize()
/*     */   {
/* 481 */     if (this.opened)
/*     */     {
/* 483 */       HornetQJournalLogger.LOGGER.fileFinalizedWhileOpen(this.fileName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void callbackDone(AIOCallback callback, long sequence, ByteBuffer buffer)
/*     */   {
/* 491 */     this.maxIOSemaphore.release();
/*     */     
/* 493 */     this.pendingWrites.countDown();
/*     */     
/* 495 */     this.callbackLock.lock();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 500 */       if (sequence == -1L)
/*     */       {
/* 502 */         callback.done();
/*     */ 
/*     */ 
/*     */       }
/* 506 */       else if (sequence == this.nextReadSequence)
/*     */       {
/* 508 */         this.nextReadSequence += 1L;
/* 509 */         callback.done();
/* 510 */         flushCallbacks();
/*     */       }
/*     */       else
/*     */       {
/* 514 */         this.pendingCallbacks.add(new CallbackHolder(sequence, callback));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 519 */       if ((this.bufferCallback != null) && (buffer != null))
/*     */       {
/* 521 */         this.bufferCallback.bufferDone(buffer);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 526 */       this.callbackLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   private void flushCallbacks()
/*     */   {
/* 532 */     while ((!this.pendingCallbacks.isEmpty()) && (((CallbackHolder)this.pendingCallbacks.peek()).sequence == this.nextReadSequence))
/*     */     {
/* 534 */       CallbackHolder holder = (CallbackHolder)this.pendingCallbacks.poll();
/* 535 */       if (holder.isError())
/*     */       {
/* 537 */         ErrorCallback error = (ErrorCallback)holder;
/* 538 */         holder.callback.onError(error.errorCode, error.message);
/*     */       }
/*     */       else
/*     */       {
/* 542 */         holder.callback.done();
/*     */       }
/* 544 */       this.nextReadSequence += 1L;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void callbackError(AIOCallback callback, long sequence, ByteBuffer buffer, int errorCode, String errorMessage)
/*     */   {
/* 556 */     HornetQJournalLogger.LOGGER.callbackError(errorMessage);
/*     */     
/* 558 */     fireExceptionListener(errorCode, errorMessage);
/*     */     
/* 560 */     this.maxIOSemaphore.release();
/*     */     
/* 562 */     this.pendingWrites.countDown();
/*     */     
/* 564 */     this.callbackLock.lock();
/*     */     
/*     */     try
/*     */     {
/* 568 */       if (sequence == -1L)
/*     */       {
/* 570 */         callback.onError(errorCode, errorMessage);
/*     */ 
/*     */ 
/*     */       }
/* 574 */       else if (sequence == this.nextReadSequence)
/*     */       {
/* 576 */         this.nextReadSequence += 1L;
/* 577 */         callback.onError(errorCode, errorMessage);
/* 578 */         flushCallbacks();
/*     */       }
/*     */       else
/*     */       {
/* 582 */         this.pendingCallbacks.add(new ErrorCallback(sequence, callback, errorCode, errorMessage));
/*     */       }
/*     */       
/*     */     }
/*     */     finally
/*     */     {
/* 588 */       this.callbackLock.unlock();
/*     */     }
/*     */     
/*     */ 
/* 592 */     if ((this.bufferCallback != null) && (buffer != null))
/*     */     {
/* 594 */       this.bufferCallback.bufferDone(buffer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fireExceptionListener(int errorCode, String errorMessage)
/*     */   {
/* 606 */     HornetQJournalLogger.LOGGER.ioError(errorCode, errorMessage);
/* 607 */     if (this.ioExceptionListener != null)
/*     */     {
/* 609 */       this.ioExceptionListener.onIOException(HornetQExceptionType.getType(errorCode).createException(errorMessage), errorMessage);
/*     */     }
/*     */   }
/*     */   
/*     */   private void pollEvents()
/*     */   {
/* 615 */     if (!this.opened)
/*     */     {
/* 617 */       return;
/*     */     }
/* 619 */     internalPollEvents(this.handler);
/*     */   }
/*     */   
/*     */   private void startPoller()
/*     */   {
/* 624 */     this.writeLock.lock();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 629 */       if (this.poller == null)
/*     */       {
/* 631 */         this.pollerLatch.countUp();
/* 632 */         this.poller = new PollerRunnable();
/*     */         try
/*     */         {
/* 635 */           this.pollerExecutor.execute(this.poller);
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 639 */           HornetQJournalLogger.LOGGER.errorStartingPoller(ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 645 */       this.writeLock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkOpened()
/*     */   {
/* 651 */     if (!this.opened)
/*     */     {
/* 653 */       throw new RuntimeException("File is not opened");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void stopPoller()
/*     */     throws HornetQException, InterruptedException
/*     */   {
/* 663 */     stopPoller(this.handler);
/*     */     
/*     */ 
/* 666 */     this.pollerLatch.await();
/*     */   }
/*     */   
/*     */   public static FileLock lock(int handle)
/*     */   {
/* 671 */     if (flock(handle))
/*     */     {
/* 673 */       return new HornetQFileLock(handle);
/*     */     }
/*     */     
/*     */ 
/* 677 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static native int openFile(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */   public static native void closeFile(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   private static native boolean flock(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */   private static native void resetBuffer(ByteBuffer paramByteBuffer, int paramInt);
/*     */   
/*     */ 
/*     */   public static native void destroyBuffer(ByteBuffer paramByteBuffer);
/*     */   
/*     */ 
/*     */   public static native void setNanoSleepInterval(int paramInt);
/*     */   
/*     */ 
/*     */   public static native void nanoSleep();
/*     */   
/*     */ 
/*     */   private static native ByteBuffer newNativeBuffer(long paramLong);
/*     */   
/*     */ 
/*     */   private static native ByteBuffer init(String paramString, int paramInt, HornetQJournalLogger paramHornetQJournalLogger)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private native long size0(ByteBuffer paramByteBuffer)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private native void write(ByteBuffer paramByteBuffer1, long paramLong1, long paramLong2, long paramLong3, ByteBuffer paramByteBuffer2, AIOCallback paramAIOCallback)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private native void writeInternal(ByteBuffer paramByteBuffer1, long paramLong1, long paramLong2, ByteBuffer paramByteBuffer2)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private native void read(ByteBuffer paramByteBuffer1, long paramLong1, long paramLong2, ByteBuffer paramByteBuffer2, AIOCallback paramAIOCallback)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private static native void fill(ByteBuffer paramByteBuffer, long paramLong1, int paramInt, long paramLong2, byte paramByte)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private static native void closeInternal(ByteBuffer paramByteBuffer)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private static native void stopPoller(ByteBuffer paramByteBuffer)
/*     */     throws HornetQException;
/*     */   
/*     */ 
/*     */   private static native int getNativeVersion();
/*     */   
/*     */ 
/*     */   private static native void internalPollEvents(ByteBuffer paramByteBuffer);
/*     */   
/*     */ 
/*     */   private static class CallbackHolder
/*     */     implements Comparable<CallbackHolder>
/*     */   {
/*     */     final long sequence;
/*     */     
/*     */     final AIOCallback callback;
/*     */     
/*     */ 
/*     */     public boolean isError()
/*     */     {
/* 757 */       return false;
/*     */     }
/*     */     
/*     */     public CallbackHolder(long sequence, AIOCallback callback)
/*     */     {
/* 762 */       this.sequence = sequence;
/* 763 */       this.callback = callback;
/*     */     }
/*     */     
/*     */ 
/*     */     public int compareTo(CallbackHolder o)
/*     */     {
/* 769 */       if (this == o)
/* 770 */         return 0;
/* 771 */       if (this.sequence <= o.sequence)
/*     */       {
/* 773 */         return -1;
/*     */       }
/*     */       
/*     */ 
/* 777 */       return 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 787 */       return super.hashCode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 796 */       return super.equals(obj);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static final class ErrorCallback
/*     */     extends AsynchronousFileImpl.CallbackHolder
/*     */   {
/*     */     final int errorCode;
/*     */     final String message;
/*     */     
/*     */     public boolean isError()
/*     */     {
/* 809 */       return true;
/*     */     }
/*     */     
/*     */     public ErrorCallback(long sequence, AIOCallback callback, int errorCode, String message)
/*     */     {
/* 814 */       super(callback);
/*     */       
/* 816 */       this.errorCode = errorCode;
/*     */       
/* 818 */       this.message = message;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 827 */       return super.hashCode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 836 */       return super.equals(obj);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class PollerRunnable
/*     */     implements Runnable
/*     */   {
/*     */     PollerRunnable() {}
/*     */     
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/* 850 */         AsynchronousFileImpl.this.pollEvents();
/*     */ 
/*     */ 
/*     */       }
/*     */       finally
/*     */       {
/*     */ 
/* 857 */         AsynchronousFileImpl.this.poller = null;
/* 858 */         AsynchronousFileImpl.this.pollerLatch.countDown();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\asyncio\impl\AsynchronousFileImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */