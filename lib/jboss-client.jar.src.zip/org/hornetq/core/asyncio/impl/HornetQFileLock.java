/*    */ package org.hornetq.core.asyncio.impl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.nio.channels.FileChannel;
/*    */ import java.nio.channels.FileLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HornetQFileLock
/*    */   extends FileLock
/*    */ {
/*    */   private final int handle;
/*    */   
/*    */   protected HornetQFileLock(int handle)
/*    */   {
/* 31 */     super((FileChannel)null, 0L, 0L, false);
/* 32 */     this.handle = handle;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isValid()
/*    */   {
/* 38 */     return true;
/*    */   }
/*    */   
/*    */   public void release()
/*    */     throws IOException
/*    */   {
/* 44 */     AsynchronousFileImpl.closeFile(this.handle);
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\asyncio\impl\HornetQFileLock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */