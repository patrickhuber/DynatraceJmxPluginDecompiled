/*     */ package org.hornetq.core.cluster;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.hornetq.api.core.BroadcastEndpoint;
/*     */ import org.hornetq.api.core.BroadcastEndpointFactory;
/*     */ import org.hornetq.api.core.HornetQBuffer;
/*     */ import org.hornetq.api.core.HornetQBuffers;
/*     */ import org.hornetq.api.core.HornetQInterruptedException;
/*     */ import org.hornetq.api.core.SimpleString;
/*     */ import org.hornetq.api.core.TransportConfiguration;
/*     */ import org.hornetq.api.core.management.CoreNotificationType;
/*     */ import org.hornetq.core.client.HornetQClientLogger;
/*     */ import org.hornetq.core.server.HornetQComponent;
/*     */ import org.hornetq.core.server.management.Notification;
/*     */ import org.hornetq.core.server.management.NotificationService;
/*     */ import org.hornetq.utils.TypedProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DiscoveryGroup
/*     */   implements HornetQComponent
/*     */ {
/*  52 */   private static final boolean isTrace = HornetQClientLogger.LOGGER.isTraceEnabled();
/*     */   
/*  54 */   private final List<DiscoveryListener> listeners = new ArrayList();
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private Thread thread;
/*     */   
/*     */   private boolean received;
/*     */   
/*  62 */   private final Object waitLock = new Object();
/*     */   
/*  64 */   private final Map<String, DiscoveryEntry> connectors = new ConcurrentHashMap();
/*     */   
/*     */   private final long timeout;
/*     */   
/*     */   private volatile boolean started;
/*     */   
/*     */   private final String nodeID;
/*     */   
/*  72 */   private final Map<String, String> uniqueIDMap = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final BroadcastEndpoint endpoint;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final NotificationService notificationService;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DiscoveryGroup(String nodeID, String name, long timeout, BroadcastEndpointFactory endpointFactory, NotificationService service)
/*     */     throws Exception
/*     */   {
/*  92 */     this.nodeID = nodeID;
/*  93 */     this.name = name;
/*  94 */     this.timeout = timeout;
/*  95 */     this.endpoint = endpointFactory.createBroadcastEndpoint();
/*  96 */     this.notificationService = service;
/*     */   }
/*     */   
/*     */   public synchronized void start() throws Exception
/*     */   {
/* 101 */     if (this.started)
/*     */     {
/* 103 */       return;
/*     */     }
/*     */     
/* 106 */     this.endpoint.openClient();
/*     */     
/* 108 */     this.started = true;
/*     */     
/* 110 */     this.thread = new Thread(new DiscoveryRunnable(), "hornetq-discovery-group-thread-" + this.name);
/*     */     
/* 112 */     this.thread.setDaemon(true);
/*     */     
/* 114 */     this.thread.start();
/*     */     
/* 116 */     if (this.notificationService != null)
/*     */     {
/* 118 */       TypedProperties props = new TypedProperties();
/*     */       
/* 120 */       props.putSimpleStringProperty(new SimpleString("name"), new SimpleString(this.name));
/*     */       
/* 122 */       Notification notification = new Notification(this.nodeID, CoreNotificationType.DISCOVERY_GROUP_STARTED, props);
/*     */       
/* 124 */       this.notificationService.sendNotification(notification);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void internalRunning()
/*     */     throws Exception
/*     */   {
/* 134 */     this.endpoint.openClient();
/* 135 */     this.started = true;
/* 136 */     DiscoveryRunnable runnable = new DiscoveryRunnable();
/* 137 */     runnable.run();
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 142 */     synchronized (this)
/*     */     {
/* 144 */       if (!this.started)
/*     */       {
/* 146 */         return;
/*     */       }
/*     */       
/* 149 */       this.started = false;
/*     */     }
/*     */     
/* 152 */     synchronized (this.waitLock)
/*     */     {
/* 154 */       this.waitLock.notifyAll();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 159 */       this.endpoint.close(false);
/*     */     }
/*     */     catch (Exception e1)
/*     */     {
/* 163 */       HornetQClientLogger.LOGGER.errorStoppingDiscoveryBroadcastEndpoint(this.endpoint, e1);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 168 */       if (this.thread != null)
/*     */       {
/* 170 */         this.thread.interrupt();
/* 171 */         this.thread.join(10000L);
/* 172 */         if (this.thread.isAlive())
/*     */         {
/* 174 */           HornetQClientLogger.LOGGER.timedOutStoppingDiscovery();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 180 */       throw new HornetQInterruptedException(e);
/*     */     }
/*     */     
/* 183 */     this.thread = null;
/*     */     
/* 185 */     if (this.notificationService != null)
/*     */     {
/* 187 */       TypedProperties props = new TypedProperties();
/* 188 */       props.putSimpleStringProperty(new SimpleString("name"), new SimpleString(this.name));
/* 189 */       Notification notification = new Notification(this.nodeID, CoreNotificationType.DISCOVERY_GROUP_STOPPED, props);
/*     */       try
/*     */       {
/* 192 */         this.notificationService.sendNotification(notification);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 196 */         HornetQClientLogger.LOGGER.errorSendingNotifOnDiscoveryStop(e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isStarted()
/*     */   {
/* 203 */     return this.started;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 208 */     return this.name;
/*     */   }
/*     */   
/*     */   public synchronized List<DiscoveryEntry> getDiscoveryEntries()
/*     */   {
/* 213 */     List<DiscoveryEntry> list = new ArrayList();
/*     */     
/* 215 */     list.addAll(this.connectors.values());
/*     */     
/* 217 */     return list;
/*     */   }
/*     */   
/*     */   public boolean waitForBroadcast(long timeout)
/*     */   {
/* 222 */     synchronized (this.waitLock)
/*     */     {
/* 224 */       long start = System.currentTimeMillis();
/*     */       
/* 226 */       long toWait = timeout;
/*     */       
/* 228 */       while ((this.started) && (!this.received) && ((toWait > 0L) || (timeout == 0L)))
/*     */       {
/*     */         try
/*     */         {
/* 232 */           this.waitLock.wait(toWait);
/*     */         }
/*     */         catch (InterruptedException e)
/*     */         {
/* 236 */           throw new HornetQInterruptedException(e);
/*     */         }
/*     */         
/* 239 */         if (timeout != 0L)
/*     */         {
/* 241 */           long now = System.currentTimeMillis();
/*     */           
/* 243 */           toWait -= now - start;
/*     */           
/* 245 */           start = now;
/*     */         }
/*     */       }
/*     */       
/* 249 */       boolean ret = this.received;
/*     */       
/* 251 */       this.received = false;
/*     */       
/* 253 */       return ret;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkUniqueID(String originatingNodeID, String uniqueID)
/*     */   {
/* 263 */     String currentUniqueID = (String)this.uniqueIDMap.get(originatingNodeID);
/*     */     
/* 265 */     if (currentUniqueID == null)
/*     */     {
/* 267 */       this.uniqueIDMap.put(originatingNodeID, uniqueID);
/*     */ 
/*     */ 
/*     */     }
/* 271 */     else if (!currentUniqueID.equals(uniqueID))
/*     */     {
/* 273 */       HornetQClientLogger.LOGGER.multipleServersBroadcastingSameNode(originatingNodeID);
/* 274 */       this.uniqueIDMap.put(originatingNodeID, uniqueID);
/*     */     }
/*     */   }
/*     */   
/*     */   class DiscoveryRunnable implements Runnable
/*     */   {
/*     */     DiscoveryRunnable() {}
/*     */     
/*     */     public void run() {
/* 283 */       byte[] data = null;
/*     */       
/* 285 */       while (DiscoveryGroup.this.started)
/*     */       {
/*     */         try
/*     */         {
/*     */ 
/*     */           try
/*     */           {
/* 292 */             data = DiscoveryGroup.this.endpoint.receiveBroadcast();
/* 293 */             if (data == null)
/*     */             {
/* 295 */               if (DiscoveryGroup.this.started)
/*     */               {
/*     */ 
/*     */ 
/* 299 */                 HornetQClientLogger.LOGGER.warn("Unexpected null data received from DiscoveryEndpoint");
/*     */               }
/* 301 */               break;
/*     */             }
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 306 */             if (!DiscoveryGroup.this.started)
/*     */             {
/* 308 */               return;
/*     */             }
/*     */             
/*     */ 
/* 312 */             HornetQClientLogger.LOGGER.errorReceivingPAcketInDiscovery(e);
/*     */           }
/*     */           
/*     */ 
/* 316 */           HornetQBuffer buffer = HornetQBuffers.wrappedBuffer(data);
/*     */           
/* 318 */           String originatingNodeID = buffer.readString();
/*     */           
/* 320 */           String uniqueID = buffer.readString();
/*     */           
/* 322 */           DiscoveryGroup.this.checkUniqueID(originatingNodeID, uniqueID);
/*     */           
/* 324 */           if (DiscoveryGroup.this.nodeID.equals(originatingNodeID))
/*     */           {
/* 326 */             if (DiscoveryGroup.this.checkExpiration())
/*     */             {
/* 328 */               DiscoveryGroup.this.callListeners();
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 334 */             int size = buffer.readInt();
/*     */             
/* 336 */             boolean changed = false;
/*     */             
/* 338 */             DiscoveryEntry[] entriesRead = new DiscoveryEntry[size];
/*     */             
/* 340 */             for (int i = 0; i < size; i++)
/*     */             {
/* 342 */               TransportConfiguration connector = new TransportConfiguration();
/*     */               
/* 344 */               connector.decode(buffer);
/*     */               
/* 346 */               entriesRead[i] = new DiscoveryEntry(originatingNodeID, connector, System.currentTimeMillis());
/*     */             }
/*     */             
/* 349 */             synchronized (DiscoveryGroup.this)
/*     */             {
/* 351 */               for (DiscoveryEntry entry : entriesRead)
/*     */               {
/* 353 */                 if (DiscoveryGroup.this.connectors.put(originatingNodeID, entry) == null)
/*     */                 {
/* 355 */                   changed = true;
/*     */                 }
/*     */               }
/*     */               
/* 359 */               changed = (changed) || (DiscoveryGroup.this.checkExpiration());
/*     */             }
/*     */             
/*     */ 
/* 363 */             if ((changed) && (DiscoveryGroup.this.started))
/*     */             {
/* 365 */               if (DiscoveryGroup.isTrace)
/*     */               {
/* 367 */                 HornetQClientLogger.LOGGER.trace("Connectors changed on Discovery:");
/* 368 */                 for (DiscoveryEntry connector : DiscoveryGroup.this.connectors.values())
/*     */                 {
/* 370 */                   HornetQClientLogger.LOGGER.trace(connector);
/*     */                 }
/*     */               }
/* 373 */               DiscoveryGroup.this.callListeners();
/*     */             }
/*     */             
/* 376 */             synchronized (DiscoveryGroup.this.waitLock)
/*     */             {
/* 378 */               DiscoveryGroup.this.received = true;
/*     */               
/* 380 */               DiscoveryGroup.this.waitLock.notifyAll();
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Throwable e) {
/* 385 */           HornetQClientLogger.LOGGER.failedToReceiveDatagramInDiscovery(e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public synchronized void registerListener(DiscoveryListener listener)
/*     */   {
/* 394 */     this.listeners.add(listener);
/*     */     
/* 396 */     if (!this.connectors.isEmpty())
/*     */     {
/* 398 */       listener.connectorsChanged(getDiscoveryEntries());
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void unregisterListener(DiscoveryListener listener)
/*     */   {
/* 404 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   private void callListeners()
/*     */   {
/* 409 */     for (DiscoveryListener listener : this.listeners)
/*     */     {
/*     */       try
/*     */       {
/* 413 */         listener.connectorsChanged(getDiscoveryEntries());
/*     */ 
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 418 */         HornetQClientLogger.LOGGER.failedToCallListenerInDiscovery(t);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean checkExpiration()
/*     */   {
/* 425 */     boolean changed = false;
/* 426 */     long now = System.currentTimeMillis();
/*     */     
/* 428 */     Iterator<Map.Entry<String, DiscoveryEntry>> iter = this.connectors.entrySet().iterator();
/*     */     
/*     */ 
/*     */ 
/* 432 */     while (iter.hasNext())
/*     */     {
/* 434 */       Map.Entry<String, DiscoveryEntry> entry = (Map.Entry)iter.next();
/*     */       
/* 436 */       if (((DiscoveryEntry)entry.getValue()).getLastUpdate() + this.timeout <= now)
/*     */       {
/* 438 */         if (isTrace)
/*     */         {
/* 440 */           HornetQClientLogger.LOGGER.trace("Timed out node on discovery:" + entry.getValue());
/*     */         }
/* 442 */         iter.remove();
/*     */         
/* 444 */         changed = true;
/*     */       }
/*     */     }
/*     */     
/* 448 */     return changed;
/*     */   }
/*     */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\cluster\DiscoveryGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */