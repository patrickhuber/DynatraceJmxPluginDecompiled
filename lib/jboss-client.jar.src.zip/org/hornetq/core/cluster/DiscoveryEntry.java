/*    */ package org.hornetq.core.cluster;
/*    */ 
/*    */ import org.hornetq.api.core.TransportConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DiscoveryEntry
/*    */ {
/*    */   private final String nodeID;
/*    */   private final TransportConfiguration connector;
/*    */   private final long lastUpdate;
/*    */   
/*    */   public DiscoveryEntry(String nodeID, TransportConfiguration connector, long lastUpdate)
/*    */   {
/* 34 */     this.nodeID = nodeID;
/* 35 */     this.connector = connector;
/* 36 */     this.lastUpdate = lastUpdate;
/*    */   }
/*    */   
/*    */   public String getNodeID()
/*    */   {
/* 41 */     return this.nodeID;
/*    */   }
/*    */   
/*    */   public TransportConfiguration getConnector()
/*    */   {
/* 46 */     return this.connector;
/*    */   }
/*    */   
/*    */   public long getLastUpdate()
/*    */   {
/* 51 */     return this.lastUpdate;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 57 */     return "DiscoveryEntry[nodeID=" + this.nodeID + ", connector=" + this.connector + ", lastUpdate=" + this.lastUpdate + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\jboss-client.jar!\org\hornetq\core\cluster\DiscoveryEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */