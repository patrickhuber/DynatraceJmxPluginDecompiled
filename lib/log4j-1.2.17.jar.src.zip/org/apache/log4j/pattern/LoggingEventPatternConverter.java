/*    */ package org.apache.log4j.pattern;
/*    */ 
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class LoggingEventPatternConverter
/*    */   extends PatternConverter
/*    */ {
/*    */   protected LoggingEventPatternConverter(String name, String style)
/*    */   {
/* 38 */     super(name, style);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void format(LoggingEvent paramLoggingEvent, StringBuffer paramStringBuffer);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void format(Object obj, StringBuffer output)
/*    */   {
/* 53 */     if ((obj instanceof LoggingEvent)) {
/* 54 */       format((LoggingEvent)obj, output);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean handlesThrowable()
/*    */   {
/* 68 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\PRH7261\Downloads\com.dynatrace.diagnostics.plugin.jmx_1.0.9.jar!\lib\log4j-1.2.17.jar!\org\apache\log4j\pattern\LoggingEventPatternConverter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       0.7.1
 */